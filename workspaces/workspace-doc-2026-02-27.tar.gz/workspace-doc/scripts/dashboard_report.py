#!/usr/bin/env python3
"""
Dashboard report for Edward Mills: tasks, medications, appointments.
"""
import os
import sys
import json
import requests
from datetime import datetime, timezone, timedelta
# Add scripts directory to path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(script_dir, 'scripts'))
from dart_client import DartClient

# Notion config
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}
DATA_SOURCE_ID = "30dd323b-89ec-81b7-a294-000b99a37429"

def iso_to_datetime(iso_str: str) -> datetime:
    iso_str = iso_str.replace('Z', '+00:00')
    return datetime.fromisoformat(iso_str)

def fetch_tasks():
    """Return list of Edward Mills tasks with age."""
    client = DartClient()
    tasks_resp = client.list_tasks()
    results = tasks_resp.get('results', [])
    edward_tasks = [t for t in results if t.get('dartboard', '').startswith('Edward Mills/') or 'patient-edward-mills' in t.get('tags', [])]
    now = datetime.now(timezone.utc)
    for task in edward_tasks:
        updated_at = iso_to_datetime(task.get('updatedAt'))
        age = now - updated_at
        task['age_days'] = age.days + age.seconds / 86400
        task['is_stale'] = age > timedelta(days=7)
    return edward_tasks

def fetch_appointments():
    """Return upcoming appointments from Notion."""
    today = datetime.now().date().isoformat()
    filter_payload = {
        "filter": {
            "and": [
                {"property": "Event Type", "select": {"equals": "Appointment"}},
                {"property": "Date", "date": {"on_or_after": today}}
            ]
        },
        "sorts": [{"property": "Date", "direction": "ascending"}]
    }
    resp = requests.post(
        f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query",
        headers=NOTION_HEADERS,
        json=filter_payload
    )
    if resp.status_code != 200:
        print(f"Notion query failed: {resp.status_code}", file=sys.stderr)
        return []
    data = resp.json()
    appointments = []
    for result in data.get('results', []):
        props = result.get('properties', {})
        name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', 'No name')
        date = props.get('Date', {}).get('date', {}).get('start', '')
        hospital = props.get('Hospital', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
        status = props.get('Status', {}).get('select', {}).get('name', '')
        appointments.append({
            'name': name,
            'date': date,
            'hospital': hospital,
            'status': status
        })
    return appointments

def get_current_location():
    """Read current location from file."""
    location_file = os.path.join(os.path.dirname(__file__), '..', 'current_location.txt')
    try:
        with open(location_file, 'r') as f:
            location = f.read().strip()
        return location if location else "Location unknown"
    except FileNotFoundError:
        return "Location unknown"

def main():
    tasks = fetch_tasks()
    appointments = fetch_appointments()
    
    now = datetime.now(timezone.utc)
    print(f"🏥 **Edward Mills Dashboard** – {now.date()}")
    print()
    
    # Appointments
    if appointments:
        print("**Next Appointment**")
        for apt in appointments[:2]:  # show up to 2
            print(f"• {apt['name']} – {apt['date']} ({apt['hospital']}) – {apt['status']}")
    else:
        print("**Next Appointment:** None scheduled")
    print()
    
    # Current Location
    location = get_current_location()
    print(f"**Current Location:** {location}")
    print()
    
    # Cancellation reminders
    cancellation_tasks = [t for t in tasks if 'cancellation' in t.get('tags', [])]
    if cancellation_tasks:
        print("**Today's Actions:**")
        for t in cancellation_tasks:
            print(f"• 📞 Call to cancel: {t['title']}")
        print()
    
    # Tasks summary
    stale_count = sum(1 for t in tasks if t['is_stale'])
    doing_count = sum(1 for t in tasks if t['status'] == 'Doing')
    todo_count = sum(1 for t in tasks if t['status'] == 'To-do')
    print(f"**Tasks:** {len(tasks)} total ({doing_count} Doing, {todo_count} To‑do)")
    if stale_count:
        print(f"🚨 **Stale tasks:** {stale_count} (>7 days)")
    else:
        print(f"✅ All tasks updated within 7 days.")
    print()
    
    # Stale task list (if any)
    stale_tasks = [t for t in tasks if t['is_stale']]
    if stale_tasks:
        print("**Stale tasks:**")
        for t in stale_tasks:
            print(f"• [{t['title']}]({t['htmlUrl']}) – updated {t['age_days']:.1f} days ago")
        print()
    
    # Active & Next Tasks
    doing_tasks = [t for t in tasks if t['status'] == 'Doing']
    todo_tasks = [t for t in tasks if t['status'] == 'To-do']
    
    # Sort todo by age (oldest first) to show next items
    todo_tasks.sort(key=lambda x: x['age_days'], reverse=False)  # oldest first
    
    # Combine: doing first, then todo, up to 3 total
    display_tasks = doing_tasks[:3]  # show all doing tasks, but limit to 3
    remaining_slots = 3 - len(display_tasks)
    if remaining_slots > 0:
        display_tasks.extend(todo_tasks[:remaining_slots])
    
    if display_tasks:
        print("**Active & Next Tasks:**")
        for t in display_tasks:
            emoji = "🔄 " if t['status'] == 'Doing' else ""
            stale_mark = " ⚠️" if t['is_stale'] else ""
            print(f"• {emoji}[{t['title']}]({t['htmlUrl']}) – {t['status']} ({t['age_days']:.1f} days ago{stale_mark})")
    else:
        print("**Active & Next Tasks:** No active or pending tasks.")

if __name__ == "__main__":
    main()