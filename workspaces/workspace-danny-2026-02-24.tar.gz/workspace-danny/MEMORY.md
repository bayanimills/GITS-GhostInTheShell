# MEMORY.md - Quick Reference

## Active Projects
- **Danny workspace setup** – memory framework established, daily logs operational
- **Polymarket trading automation** – AI Divergence Scanner and Mert Sniper deployed
- **Cron job monitoring** – real-time execution tracking with quiet hours enforcement

## Recent Decisions
- **Quiet hours (23:00‑07:00)** implemented across all trading scripts – suppress non‑trade output
- **AI Divergence Scanner** configured with 10% threshold, 30‑min scans, Telegram announcements
- **Mert Sniper** configured with 65% conviction threshold, 10‑min scans, smart sizing (5% of balance)
- **Log‑first verification** – all cron job updates verified against actual log files before delivery

## User Preferences (Updated 2026‑02‑23)
- **Reporting protocol:** Only notify when positions are taken (trades executed)
- **Do NOT report:** Routine Mert Sniper scan outcomes or AI Divergence updates unless they result in a position
- **Continue with:** 8am & 8pm overviews including position status and expected returns

## Trading Insights (2026‑02‑23)
- **Weather markets** showed highest divergence (±32%) early morning but dropped below threshold by 09:09
- **Election markets** (Nepal Congress) provided stable medium‑conviction opportunities (+11‑17%)
- **New opportunities emerged:** Elon Musk tweet‑count markets (±20%/13.6%), Netflix show (+20%)
- **Near‑expiry conviction trading** requires ≥65% split – markets remained balanced (46‑54% splits)
- **Order execution issues** encountered: decimal precision errors, liquidity gaps in order books
- **Significant trading activity:** 20 trades executed via other strategies/manual trading
- **Portfolio volatility:** Balance dropped from $162.24 to $82.90 by evening, exposure fluctuated $0‑$108
- **Current status (21:58):** $82.90 balance, $108.29 exposure (9 positions) – high‑risk leveraged state

## Action Items
- **Today's resolutions (Feb 24):** Elon Musk tweet‑count markets, Netflix show
- Monitor portfolio leverage risk – exposure ($108.29) > balance ($82.90)
- Review Seattle precipitation market opportunities before Feb 28 resolution
- Consider adjusting Mert Sniper parameters if conviction thresholds too restrictive
- Maintain log‑verification discipline for all cron job updates

## Notes
- Created by maintenance review on 2026-02-21.
- Updated with trading operations insights on 2026-02-23.
- 8pm overview delivered late (00:16 AM Feb 24) – portfolio leveraged at $82.90 balance, $108.29 exposure.
