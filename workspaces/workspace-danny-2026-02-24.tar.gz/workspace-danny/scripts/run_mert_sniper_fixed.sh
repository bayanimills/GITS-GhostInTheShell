#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Run Mert Sniper with timeout to prevent hanging
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

# Use timeout command to prevent indefinite hanging (60 seconds timeout)
TIMEOUT=60
OUTPUT=$(timeout $TIMEOUT python3 mert_sniper.py --live --smart-sizing --expiry 60 --set min_split=0.65 2>&1)
TIMEOUT_STATUS=$?

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Check if timeout occurred
if [ $TIMEOUT_STATUS -eq 124 ]; then
    echo "ERROR: Script timed out after ${TIMEOUT} seconds" >> "$LOG_FILE"
    echo "Mert Sniper: TIMEOUT - script took too long (${TIMEOUT}s)"
    exit 1
fi

# Extract trade count
TRADES=$(echo "$OUTPUT" | grep "Trades executed:" | awk '{print $3}')
NEAR=$(echo "$OUTPUT" | grep "Near expiry:" | awk '{print $3}')

if [ -z "$TRADES" ]; then
    TRADES=0
fi

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

if [ "$TRADES" -gt 0 ]; then
    # Trades executed — output full summary
    echo "$OUTPUT" | grep -A10 "Summary:"
elif [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours, no trade — stay silent (no output)
    exit 0
else
    # Daytime, no trade — output concise status
    echo "Mert Sniper: ${NEAR:-0} markets near expiry, ${TRADES} trades (60min, 65% split)."
fi