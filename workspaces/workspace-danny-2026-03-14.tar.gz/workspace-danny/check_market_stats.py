#!/usr/bin/env python3
"""Check market statistics to understand current conditions."""

import os
import sys
from datetime import datetime, timezone
from collections import defaultdict

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
        
    client = SimmerClient(api_key=api_key)
    
    print("Fetching markets...")
    markets = client.get_markets(limit=200, status='active')
    print(f"Total active markets: {len(markets)}")
    
    # Analyze probability distribution
    prob_buckets = defaultdict(int)
    valid_markets = 0
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
            
        p = market.current_probability
        valid_markets += 1
        
        # Bucket probabilities
        if p < 0.1:
            prob_buckets['0-10%'] += 1
        elif p < 0.2:
            prob_buckets['10-20%'] += 1
        elif p < 0.3:
            prob_buckets['20-30%'] += 1
        elif p < 0.4:
            prob_buckets['30-40%'] += 1
        elif p < 0.5:
            prob_buckets['40-50%'] += 1
        elif p < 0.6:
            prob_buckets['50-60%'] += 1
        elif p < 0.7:
            prob_buckets['60-70%'] += 1
        elif p < 0.8:
            prob_buckets['70-80%'] += 1
        elif p < 0.9:
            prob_buckets['80-90%'] += 1
        else:
            prob_buckets['90-100%'] += 1
    
    print(f"\nValid markets with probabilities: {valid_markets}")
    print("\nProbability Distribution:")
    for bucket in sorted(prob_buckets.keys()):
        count = prob_buckets[bucket]
        percentage = (count / valid_markets) * 100
        print(f"  {bucket}: {count} markets ({percentage:.1f}%)")
    
    # Check for markets with probabilities in tradable ranges
    print("\nMarkets in potentially tradable ranges:")
    print("  Low probability (5-30%): Looking for BUY YES opportunities")
    print("  High probability (70-95%): Looking for BUY NO opportunities")
    
    low_prob_markets = []
    high_prob_markets = []
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
            
        p = market.current_probability
        question = market.question[:50] + "..." if len(market.question) > 50 else market.question
        
        if 0.05 <= p <= 0.3:
            low_prob_markets.append((p, question, market.id))
        elif 0.7 <= p <= 0.95:
            high_prob_markets.append((p, question, market.id))
    
    print(f"\nLow probability markets (5-30%): {len(low_prob_markets)}")
    for p, q, _ in sorted(low_prob_markets, key=lambda x: x[0])[:5]:  # Show top 5
        print(f"  {p:.1%}: {q}")
    
    print(f"\nHigh probability markets (70-95%): {len(high_prob_markets)}")
    for p, q, _ in sorted(high_prob_markets, key=lambda x: x[0], reverse=True)[:5]:  # Show top 5
        print(f"  {p:.1%}: {q}")
    
    # Check expiry times
    print("\nChecking expiry times...")
    current_time = datetime.now(timezone.utc)
    expiry_buckets = defaultdict(int)
    
    for market in markets:
        if not hasattr(market, 'expires_at') or not market.expires_at:
            continue
            
        time_to_expiry = (market.expires_at - current_time).total_seconds() / 3600  # hours
        
        if time_to_expiry < 1:
            expiry_buckets['<1h'] += 1
        elif time_to_expiry < 6:
            expiry_buckets['1-6h'] += 1
        elif time_to_expiry < 24:
            expiry_buckets['6-24h'] += 1
        elif time_to_expiry < 72:
            expiry_buckets['1-3d'] += 1
        else:
            expiry_buckets['>3d'] += 1
    
    print("Time to Expiry Distribution:")
    total_with_expiry = sum(expiry_buckets.values())
    for bucket in ['<1h', '1-6h', '6-24h', '1-3d', '>3d']:
        count = expiry_buckets[bucket]
        if total_with_expiry > 0:
            percentage = (count / total_with_expiry) * 100
            print(f"  {bucket}: {count} markets ({percentage:.1f}%)")
    
    print(f"\nCurrent Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())