#!/usr/bin/env python3
"""
Diagnostic script to examine current market data.
"""

import os
import sys
from datetime import datetime, timezone, timedelta

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                try:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
                except ValueError:
                    continue

API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("ERROR: simmer_sdk not installed")
    sys.exit(1)

def main():
    print("Market Diagnostic Scan")
    print("=" * 80)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print()
    
    # Initialize client
    client = SimmerClient(api_key=API_KEY)
    
    # Fetch markets
    print("Fetching markets...")
    markets = client.get_markets(limit=150, status='active')
    print(f"Total active markets: {len(markets)}")
    print()
    
    # Analyze market characteristics
    now = datetime.now(timezone.utc)
    
    categories = {}
    probability_ranges = {
        '0-10%': 0,
        '10-20%': 0,
        '20-30%': 0,
        '30-40%': 0,
        '40-50%': 0,
        '50-60%': 0,
        '60-70%': 0,
        '70-80%': 0,
        '80-90%': 0,
        '90-100%': 0
    }
    
    expiry_ranges = {
        '<1 hour': 0,
        '1-2 hours': 0,
        '2-6 hours': 0,
        '6-12 hours': 0,
        '12-24 hours': 0,
        '>24 hours': 0
    }
    
    valid_markets = 0
    
    for market in markets:
        # Check for probability
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
            
        p = market.current_probability
        
        # Categorize probability
        if p <= 0.1:
            probability_ranges['0-10%'] += 1
        elif p <= 0.2:
            probability_ranges['10-20%'] += 1
        elif p <= 0.3:
            probability_ranges['20-30%'] += 1
        elif p <= 0.4:
            probability_ranges['30-40%'] += 1
        elif p <= 0.5:
            probability_ranges['40-50%'] += 1
        elif p <= 0.6:
            probability_ranges['50-60%'] += 1
        elif p <= 0.7:
            probability_ranges['60-70%'] += 1
        elif p <= 0.8:
            probability_ranges['70-80%'] += 1
        elif p <= 0.9:
            probability_ranges['80-90%'] += 1
        else:
            probability_ranges['90-100%'] += 1
        
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            expiry = market.expires_at
            hours_left = (expiry - now).total_seconds() / 3600
            
            if hours_left < 1:
                expiry_ranges['<1 hour'] += 1
            elif hours_left < 2:
                expiry_ranges['1-2 hours'] += 1
            elif hours_left < 6:
                expiry_ranges['2-6 hours'] += 1
            elif hours_left < 12:
                expiry_ranges['6-12 hours'] += 1
            elif hours_left < 24:
                expiry_ranges['12-24 hours'] += 1
            else:
                expiry_ranges['>24 hours'] += 1
        
        # Track categories
        category = getattr(market, 'category', 'Unknown')
        categories[category] = categories.get(category, 0) + 1
        
        valid_markets += 1
    
    print(f"Markets with probability data: {valid_markets}/{len(markets)}")
    print()
    
    print("PROBABILITY DISTRIBUTION")
    print("-" * 40)
    for range_name, count in probability_ranges.items():
        if count > 0:
            percentage = (count / valid_markets) * 100
            print(f"{range_name}: {count} markets ({percentage:.1f}%)")
    
    print()
    print("TIME TO EXPIRY")
    print("-" * 40)
    total_with_expiry = sum(expiry_ranges.values())
    for range_name, count in expiry_ranges.items():
        if count > 0:
            percentage = (count / total_with_expiry) * 100 if total_with_expiry > 0 else 0
            print(f"{range_name}: {count} markets ({percentage:.1f}%)")
    
    print()
    print("CATEGORIES")
    print("-" * 40)
    for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        percentage = (count / valid_markets) * 100
        print(f"{category}: {count} markets ({percentage:.1f}%)")
    
    print()
    print("SAMPLE MARKETS")
    print("-" * 40)
    
    # Show sample of markets
    sample_count = 0
    for market in markets:
        if sample_count >= 10:
            break
            
        if hasattr(market, 'current_probability') and market.current_probability is not None:
            p = market.current_probability
            question = getattr(market, 'question', 'No question')[:60]
            category = getattr(market, 'category', 'Unknown')
            
            expiry_info = ""
            if hasattr(market, 'expires_at') and market.expires_at:
                hours_left = (market.expires_at - now).total_seconds() / 3600
                expiry_info = f", expires in {hours_left:.1f}h"
            
            print(f"{p:.1%}: {question}... [{category}{expiry_info}]")
            sample_count += 1
    
    print()
    print("ANALYSIS")
    print("-" * 40)
    
    # Count markets in "tradable" ranges (20-80% probability)
    tradable_count = 0
    for range_name in ['20-30%', '30-40%', '40-50%', '50-60%', '60-70%', '70-80%']:
        tradable_count += probability_ranges[range_name]
    
    print(f"Markets in 20-80% probability range: {tradable_count}/{valid_markets} ({tradable_count/valid_markets*100:.1f}%)")
    
    # Count markets with reasonable expiry (>2 hours)
    reasonable_expiry = 0
    for range_name in ['2-6 hours', '6-12 hours', '12-24 hours', '>24 hours']:
        reasonable_expiry += expiry_ranges[range_name]
    
    if total_with_expiry > 0:
        print(f"Markets with >2 hours to expiry: {reasonable_expiry}/{total_with_expiry} ({reasonable_expiry/total_with_expiry*100:.1f}%)")
    else:
        print(f"Markets with expiry data: {total_with_expiry}/{valid_markets}")
    
    print()
    print("RECOMMENDATIONS")
    print("-" * 40)
    
    if tradable_count == 0:
        print("❌ No markets in tradable probability range (20-80%)")
        print("   Most markets are at extreme probabilities (likely resolved)")
    else:
        print(f"✅ {tradable_count} markets in tradable range")
        
    if reasonable_expiry == 0:
        print("❌ No markets with sufficient time to expiry (>2 hours)")
        print("   Most markets are expiring soon")
    else:
        print(f"✅ {reasonable_expiry} markets with sufficient time")
    
    print()
    print("=" * 80)
    print("DIAGNOSTIC COMPLETE")

if __name__ == "__main__":
    main()