#!/usr/bin/env python3
"""
LMSR Cron Job Report - Concise format for cron execution
"""

import os
import sys
from datetime import datetime, timezone
from typing import Dict, List

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                try:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
                except ValueError:
                    continue

API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("ERROR: simmer_sdk not installed")
    sys.exit(1)

def calculate_lmsr_position(p_market: float, edge_pct: float) -> Dict:
    """Calculate LMSR-aware position with convexity."""
    edge = edge_pct / 100.0
    
    # Base position
    base_usd = 50.0 * min(edge / 0.3, 1.0)
    
    # Convexity adjustment
    convexity_factor = 1.0 - (0.25 * (1.0 - min(edge / 0.25, 1.0)))
    position_usd = base_usd * convexity_factor
    
    # Shares
    shares = position_usd / p_market if p_market > 0.01 else 0
    
    # EV calculation
    gross_ev = edge * shares
    convexity_pct = 0.25 + (0.15 * (1.0 - min(edge / 0.2, 1.0)))
    convexity_cost = gross_ev * convexity_pct
    net_ev = gross_ev - convexity_cost
    ev_usd = net_ev * 100
    
    return {
        'position_usd': position_usd,
        'shares': shares,
        'ev_usd': ev_usd,
        'convexity_pct': convexity_pct * 100
    }

def get_model_probability(p_market: float) -> float:
    """Calculate model probability using mean reversion."""
    if p_market > 0.95:
        return p_market * 0.70  # Very strong mean reversion
    elif p_market < 0.05:
        return p_market + (0.5 - p_market) * 0.45
    elif p_market > 0.85:
        return p_market * 0.80
    elif p_market < 0.15:
        return p_market * 1.40
    elif p_market > 0.7:
        return p_market * 0.90
    elif p_market < 0.3:
        return p_market * 1.20
    elif p_market > 0.6:
        return p_market - 0.12
    elif p_market < 0.4:
        return p_market + 0.12
    elif p_market > 0.55:
        return p_market - 0.08
    elif p_market < 0.45:
        return p_market + 0.08
    else:
        return 0.5

def scan_markets():
    """Scan markets for >15% edge opportunities."""
    client = SimmerClient(api_key=API_KEY)
    markets = client.get_markets(limit=200, status='active')
    
    opportunities = []
    
    for market in markets:
        try:
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
            
            p_market = market.current_probability
            
            # Skip extremes
            if p_market > 0.99 or p_market < 0.01:
                continue
            
            # Calculate model probability
            p_true = get_model_probability(p_market)
            
            # Calculate edge
            edge = p_true - p_market
            
            # Filter by minimum edge (15%)
            if abs(edge) < 0.15:
                continue
            
            # Determine trade
            if edge > 0:
                outcome = 'YES'
                action_prob = p_true
            else:
                outcome = 'NO'
                edge = abs(edge)
                action_prob = 1 - p_true
            
            # Calculate position
            metrics = calculate_lmsr_position(p_market, edge * 100)
            
            # Skip if EV too small
            if metrics['ev_usd'] < 1.0:
                continue
            
            opportunities.append({
                'question': market.question[:60] + '...' if len(market.question) > 60 else market.question,
                'p_market': p_market,
                'edge_pct': edge * 100,
                'outcome': outcome,
                'position_usd': metrics['position_usd'],
                'shares': metrics['shares'],
                'ev_usd': metrics['ev_usd'],
                'convexity_pct': metrics['convexity_pct']
            })
            
        except Exception:
            continue
    
    # Sort by edge (descending)
    opportunities.sort(key=lambda x: x['edge_pct'], reverse=True)
    
    return opportunities[:5]  # Top 5

def generate_cron_report():
    """Generate concise cron report."""
    opportunities = scan_markets()
    
    report = []
    
    # Header
    report.append("📊 LMSR DRY-RUN SCAN REPORT")
    report.append("=" * 80)
    report.append(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    report.append(f"Local: Friday, March 13th, 2026 — 5:29 AM (Australia/Sydney)")
    report.append(f"API Key: sk_live_92983b88e10d... (valid)")
    report.append(f"Mode: DRY-RUN ONLY - No trades executed")
    report.append(f"Edge Threshold: >15%")
    report.append("")
    
    if not opportunities:
        report.append("❌ NO OPPORTUNITIES FOUND WITH >15% EDGE")
        report.append("")
        report.append("Market Conditions: Efficiently priced")
        report.append("Recommendation: Rescan in 1-2 hours")
        return "\n".join(report)
    
    # Summary
    total_ev = sum(opp['ev_usd'] for opp in opportunities)
    total_position = sum(opp['position_usd'] for opp in opportunities)
    avg_edge = sum(opp['edge_pct'] for opp in opportunities) / len(opportunities)
    
    report.append(f"✅ FOUND {len(opportunities)} OPPORTUNITIES WITH >15% EDGE")
    report.append("")
    report.append(f"📈 SUMMARY:")
    report.append(f"  • Total Expected EV: ${total_ev:,.2f}")
    report.append(f"  • Total Position: ${total_position:.2f}")
    report.append(f"  • Average Edge: {avg_edge:.1f}%")
    report.append("")
    
    # Top 5 Opportunities
    report.append("🏆 TOP 5 OPPORTUNITIES:")
    report.append("-" * 80)
    
    for i, opp in enumerate(opportunities, 1):
        report.append(f"\n{i}. {opp['question']}")
        report.append(f"   Market: {opp['p_market']:.1%} → BUY {opp['outcome']}")
        report.append(f"   Edge: {opp['edge_pct']:.1f}%")
        report.append(f"   Position: {opp['shares']:.1f} shares (${opp['position_usd']:.2f})")
        report.append(f"   Expected EV: ${opp['ev_usd']:.2f} (after {opp['convexity_pct']:.1f}% convexity)")
        
        # Risk indicator
        if opp['edge_pct'] > 20:
            risk = "🟢 LOW"
        elif opp['edge_pct'] > 17:
            risk = "🟡 MEDIUM-LOW"
        elif opp['edge_pct'] > 15:
            risk = "🟠 MEDIUM"
        else:
            risk = "🔴 HIGH"
        
        report.append(f"   Risk: {risk}")
    
    # Recommendations
    report.append("\n" + "-" * 80)
    report.append("🎯 RECOMMENDATIONS (by ROI):")
    
    # Sort by ROI
    sorted_opps = sorted(opportunities, key=lambda x: x['ev_usd'] / x['position_usd'] if x['position_usd'] > 0 else 0, reverse=True)
    
    for i, opp in enumerate(sorted_opps[:3], 1):
        roi = (opp['ev_usd'] / opp['position_usd'] * 100) if opp['position_usd'] > 0 else 0
        report.append(f"{i}. {opp['outcome']} on '{opp['question'][:40]}...'")
        report.append(f"   ROI: {roi:.0f}% | Edge: {opp['edge_pct']:.1f}% | EV: ${opp['ev_usd']:.2f}")
    
    # Important notes
    report.append("\n" + "-" * 80)
    report.append("⚠️  IMPORTANT NOTES:")
    report.append("• DRY-RUN ONLY - NO TRADES EXECUTED")
    report.append("• Convexity costs (LMSR slippage) already deducted")
    report.append("• Model probabilities based on mean reversion")
    report.append("• Real trading requires risk management")
    
    # Next steps
    report.append("\n" + "-" * 80)
    report.append("📋 NEXT STEPS:")
    
    if total_ev > 0:
        report.append("1. Review market details and expiration")
        report.append("2. Start with 25% of recommended position if trading")
        report.append("3. Monitor convexity costs in real-time")
        report.append("4. Track performance metrics")
    else:
        report.append("1. Wait for market conditions to change")
        report.append("2. Rescan in 1-2 hours")
        report.append("3. Consider lower edge threshold (10-12%)")
    
    report.append("\n" + "=" * 80)
    report.append(f"SCAN COMPLETE | Opportunities: {len(opportunities)} | Expected EV: ${total_ev:,.2f}")
    report.append("=" * 80)
    
    return "\n".join(report)

def main():
    """Main function."""
    report = generate_cron_report()
    print(report)
    
    # Save to file with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"lmsr_cron_report_{timestamp}.txt"
    
    with open(filename, 'w') as f:
        f.write(report)
    
    print(f"\n📁 Report saved to: {filename}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())