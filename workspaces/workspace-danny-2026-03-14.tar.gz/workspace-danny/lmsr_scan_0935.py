#!/usr/bin/env python3
"""
LMSR Scan - 9:35 AM AEST
Critical scan during US pre-market activity (9:30 PM ET).
"""

import os
import sys
from datetime import datetime, timezone

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class USPreMarketActiveAnalyzer:
    """Analyzer for 9:35 AM AEST (US pre-market active)."""
    
    def __init__(self):
        # Market type configurations for active US pre-market
        self.configs = {
            'crypto': {
                'edge_mult': 0.59,      # 59% of distance
                'base_conv': 0.16,      # 16% base (improving with US activity)
                'prob_factor': 0.26,    # Probability impact
                'min_ev': 45.0,         # Minimum EV
                'position_mult': 0.90   # Position multiplier
            },
            'sports': {
                'edge_mult': 0.53,
                'base_conv': 0.20,
                'prob_factor': 0.28,
                'min_ev': 40.0,
                'position_mult': 0.85
            },
            'esports': {
                'edge_mult': 0.63,
                'base_conv': 0.19,
                'prob_factor': 0.27,
                'min_ev': 43.0,
                'position_mult': 0.88
            },
            'weather': {
                'edge_mult': 0.48,
                'base_conv': 0.22,
                'prob_factor': 0.29,
                'min_ev': 35.0,
                'position_mult': 0.83
            },
            'politics': {
                'edge_mult': 0.51,
                'base_conv': 0.21,
                'prob_factor': 0.28,
                'min_ev': 38.0,
                'position_mult': 0.84
            },
            'other': {
                'edge_mult': 0.50,
                'base_conv': 0.22,
                'prob_factor': 0.28,
                'min_ev': 35.0,
                'position_mult': 0.83
            }
        }
        
        # Strategic parameters for US pre-market active
        self.primary_threshold = 0.15  # 15%
        self.secondary_threshold = 0.12  # 12%
        self.exploratory_threshold = 0.10  # 10% (now primary test)
        self.max_position = 36.0  # Increased for US pre-market
        self.size_factor = 0.06   # Reduced size impact
    
    def classify_market(self, question):
        """Classify market type."""
        q = question.lower()
        
        if any(word in q for word in ['bitcoin', 'ethereum', 'solana', 'xrp', 'crypto']):
            return 'crypto'
        elif any(word in q for word in ['spread', 'nba', 'soccer', 'football', 'basketball']):
            return 'sports'
        elif any(word in q for word in ['lol', 'esports', 'rainbow', 'siege', 'dota']):
            return 'esports'
        elif any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return 'weather'
        elif any(word in q for word in ['election', 'politic', 'ukraine', 'trump', 'biden']):
            return 'politics'
        else:
            return 'other'
    
    def analyze_opportunity(self, market_prob, question):
        """Analyze market for trading opportunity."""
        # Filter extreme probabilities
        if market_prob < 0.07 or market_prob > 0.93:
            return None
        
        # Filter very low/high probabilities
        if market_prob < 0.15 or market_prob > 0.85:
            # Allow but note for convexity
            pass
        
        # Classify market
        market_type = self.classify_market(question)
        config = self.configs[market_type]
        
        # Calculate distance from 50%
        distance = abs(0.5 - market_prob)
        
        # Gross edge
        gross_edge = distance * config['edge_mult']
        
        if gross_edge < self.exploratory_threshold:  # Use exploratory as primary filter
            return None
        
        # Determine trade direction
        if market_prob < 0.5:
            outcome = "YES"
            trade_prob = market_prob
        else:
            outcome = "NO"
            trade_prob = 1 - market_prob
        
        # Position sizing (US pre-market active)
        max_shares = self.max_position / trade_prob if trade_prob > 0 else 0
        
        # Edge-based scaling
        edge_ratio = min(gross_edge / 0.3, 1.0)
        shares = max_shares * (edge_ratio ** 0.80) * config['position_mult']
        
        # Convexity cost (improving with US activity)
        prob_factor = 2 * abs(trade_prob - 0.5) * config['prob_factor']
        size_factor = min(shares / 130, 1.0) * self.size_factor
        
        convexity_pct = config['base_conv'] + prob_factor + size_factor
        convexity_pct = min(convexity_pct, 0.56)  # Max 56%
        
        # Net edge after convexity
        net_edge = gross_edge * (1 - convexity_pct)
        
        # Check all thresholds
        meets_primary = net_edge >= self.primary_threshold
        meets_secondary = net_edge >= self.secondary_threshold
        meets_exploratory = net_edge >= self.exploratory_threshold
        
        if not meets_exploratory:
            return None
        
        # Expected value
        ev = net_edge * shares * 100
        
        if ev < config['min_ev']:
            return None
        
        # Calculate metrics
        cost = shares * trade_prob
        roi = (ev / cost * 100) if cost > 0 else 0
        
        return {
            'market_type': market_type,
            'gross_edge': gross_edge,
            'net_edge': net_edge,
            'convexity_pct': convexity_pct * 100,
            'outcome': outcome,
            'shares': shares,
            'cost': cost,
            'ev': ev,
            'roi': roi,
            'trade_prob': trade_prob,
            'distance': distance,
            'edge_mult': config['edge_mult'],
            'meets_primary': meets_primary,
            'meets_secondary': meets_secondary,
            'meets_exploratory': meets_exploratory
        }

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    client = SimmerClient(api_key=api_key)
    analyzer = USPreMarketActiveAnalyzer()
    current_time = datetime.now(timezone.utc)
    
    print("=" * 80)
    print("LMSR CRITICAL SCAN REPORT - US PRE-MARKET ACTIVE")
    print("=" * 80)
    print(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}... (validated)")
    print(f"Primary Threshold: >{analyzer.primary_threshold:.0%} (after convexity)")
    print(f"Secondary Threshold: >{analyzer.secondary_threshold:.0%} (strategic)")
    print(f"Exploratory Threshold: >{analyzer.exploratory_threshold:.0%} (primary test)")
    print(f"Max Position: ${analyzer.max_position:.2f}")
    print(f"Scan Time: 9:35 AM AEST (US pre-market active - 9:30 PM ET)")
    print()
    
    # Fetch markets
    print("Fetching and analyzing markets...")
    markets = client.get_markets(limit=120, status='active')
    
    opportunities = []
    stats = {
        'total': len(markets),
        'with_prob': 0,
        'viable': 0,      # 7-93%
        'tradable': 0,    # 15-85%
        'by_type': {mtype: 0 for mtype in analyzer.configs.keys()}
    }
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
        
        stats['with_prob'] += 1
        p = market.current_probability
        
        # Count viable ranges
        if 0.07 <= p <= 0.93:
            stats['viable'] += 1
        if 0.15 <= p <= 0.85:
            stats['tradable'] += 1
        
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 2700:  # <45 minutes
                continue
        
        question = market.question if hasattr(market, 'question') else ""
        
        # Analyze
        analysis = analyzer.analyze_opportunity(p, question)
        if analysis:
            mtype = analysis['market_type']
            stats['by_type'][mtype] += 1
            
            opportunities.append({
                'id': market.id,
                'question': question[:60] + "..." if len(question) > 60 else question,
                'market_prob': p,
                'analysis': analysis
            })
    
    # Sort by net edge
    opportunities.sort(key=lambda x: x['analysis']['net_edge'], reverse=True)
    
    # Print statistics
    print(f"\nMarket Statistics (9:35 AM AEST):")
    print(f"  Total markets: {stats['total']}")
    print(f"  With probabilities: {stats['with_prob']}")
    print(f"  Viable markets (7-93%): {stats['viable']}")
    print(f"  Tradable markets (15-85%): {stats['tradable']}")
    
    print(f"\nMarkets by type:")
    for mtype, count in stats['by_type'].items():
        if count > 0:
            print(f"  {mtype.upper()}: {count}")
    
    print(f"\nOpportunities found: {len(opportunities)}")
    
    # Threshold analysis
    primary_opps = [o for o in opportunities if o['analysis']['meets_primary']]
    secondary_opps = [o for o in opportunities if o['analysis']['meets_secondary']]
    exploratory_opps = [o for o in opportunities if o['analysis']['meets_exploratory']]
    
    print(f"\nThreshold Analysis:")
    print(f"  Opportunities >{analyzer.primary_threshold:.0%}: {len(primary_opps)}")
    print(f"  Opportunities >{analyzer.secondary_threshold:.0%}: {len(secondary_opps)}")
    print(f"  Opportunities >{analyzer.exploratory_threshold:.0%}: {len(exploratory_opps)}")
    
    # Generate report
    if not opportunities:
        print("\n" + "=" * 80)
        print("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("=" * 80)
        
        print(f"\n9:35 AM AEST Critical Assessment:")
        print(f"• Time: US pre-market active (9:30 PM ET)")
        print(f"• Efficiency: Persistently exceptional")
        print(f"• Convexity: 16-56% range (significant improvement)")
        print(f"• Activity: US pre-market not creating opportunities")
        
        print(f"\nUS Pre-Market Active Parameters:")
        for mtype, config in analyzer.configs.items():
            print(f"  {mtype.upper()}: {config['edge_mult']:.0%} edge, {config['base_conv']:.0%} base convexity")
        
        print(f"\nThreshold Analysis Results:")
        print(f"  Primary threshold ({analyzer.primary_threshold:.0%}): 0 opportunities")
        print(f"  Secondary threshold ({analyzer.secondary_threshold:.0%}): 0 opportunities")
        print(f"  Exploratory threshold ({analyzer.exploratory_threshold:.0%}): 0 opportunities")
        
        print(f"\nCritical Implications:")
        print(f"  1. US pre-market activity not creating trading opportunities")
        print(f"  2. Market efficiency remains structural")
        print(f"  3. Even 10% threshold yields no opportunities")
        print(f"  4. Consider strategy overhaul or pause")
        
        print(f"\nRecommendations:")
        print(f"  1. Wait for US market open (4:00 AM AEST tomorrow)")
        print(f"  2. Consider strategy diversification")
        print(f"  3. Next scan at 10:00 AM AEST")
        print(f"  4. Monitor for efficiency break")
        
    else:
        print(f"\n✅ FOUND {len(opportunities)} OPPORTUNITIES")
        
        # Separate by threshold
        if primary_opps:
            print(f"\nTOP PRIMARY OPPORTUNITIES (>15% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(primary_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} ✅ PRIMARY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        elif secondary_opps:
            print(f"\nTOP SECONDARY OPPORTUNITIES (12-15% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(secondary_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} ⚠️ SECONDARY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        elif exploratory_opps:
            print(f"\nTOP EXPLORATORY OPPORTUNITIES (10-12% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(exploratory_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} 🔍 EXPLORATORY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        # Portfolio summary
        display_opps = primary_opps or secondary_opps or exploratory_opps[:5]
        total_ev = sum(o['analysis']['ev'] for o in display_opps[:5])
        total_cost = sum(o['analysis']['cost'] for o in display_opps[:5])
        
