#!/usr/bin/env python3
"""
LMSR Realistic Dry-Run Scan
Conservative probability model with proper convexity and risk management.
"""

import os
import sys
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Tuple, Optional

try:
    from simmer_sdk import SimmerClient
    SIMMER_AVAILABLE = True
except ImportError:
    SIMMER_AVAILABLE = False
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class RealisticLMSRAnalyzer:
    """Conservative LMSR analyzer with realistic edge detection."""
    
    def __init__(self):
        self.min_edge = 0.15  # 15% minimum edge
        self.max_position_usd = 25.0  # Conservative position size
        self.liquidity_param = 50.0  # Conservative liquidity assumption
        
    def calculate_realistic_probability(self, market_prob: float, market_type: str, 
                                       question: str) -> float:
        """
        Conservative probability model.
        Returns realistic probability estimate with small edges only.
        """
        # Skip extreme probabilities
        if market_prob > 0.95 or market_prob < 0.05:
            return market_prob  # No edge in extreme markets
            
        # Different strategies for different market types
        question_lower = question.lower()
        
        # 1. Esports markets - often efficient but can have small edges
        if any(word in question_lower for word in ['lol', 'league', 'esports', 'rainbow', 'siege']):
            # Esports markets can be volatile but generally efficient
            if market_prob > 0.7:
                return market_prob * 0.85  # 15% correction
            elif market_prob < 0.3:
                return market_prob * 1.3  # 30% increase
            else:
                return 0.5  # No strong view for middle probabilities
                
        # 2. Sports spreads - generally efficient
        elif 'spread' in question_lower:
            if market_prob > 0.6:
                return market_prob - 0.1  # 10% correction
            elif market_prob < 0.4:
                return market_prob + 0.1  # 10% increase
            else:
                return 0.5
                
        # 3. Weather markets - check if reasonable
        elif any(word in question_lower for word in ['temperature', 'weather', '°c', '°f']):
            # Weather forecasts are generally accurate
            # Small mean reversion only
            return 0.5 + (0.5 - market_prob) * 0.15
            
        # 4. Crypto markets - high volatility, potential for small edges
        elif any(word in question_lower for word in ['bitcoin', 'solana', 'xrp', 'crypto']):
            if market_prob > 0.7:
                return market_prob * 0.9  # 10% correction
            elif market_prob < 0.3:
                return market_prob * 1.2  # 20% increase
            else:
                return 0.5
                
        # 5. Political markets - can have biases
        elif any(word in question_lower for word in ['election', 'ukraine', 'politic']):
            if market_prob > 0.6:
                return market_prob - 0.08  # 8% correction
            elif market_prob < 0.4:
                return market_prob + 0.08  # 8% increase
            else:
                return 0.5
                
        # 6. Default: very conservative mean reversion
        else:
            return 0.5 + (0.5 - market_prob) * 0.1  # Only 10% mean reversion
    
    def calculate_convexity_impact(self, market_prob: float, shares: float) -> float:
        """
        Calculate convexity impact (slippage) for LMSR.
        More conservative than previous model.
        """
        # Simplified convexity model
        # Impact increases with position size and probability extremity
        base_impact = 0.05  # 5% base impact
        prob_factor = 4 * market_prob * (1 - market_prob)  # Max at 0.5, min at extremes
        size_factor = min(shares / 100, 1.0)  # Cap at 100 shares
        
        return base_impact * prob_factor * size_factor
    
    def calculate_optimal_position(self, p_true: float, p_market: float, 
                                  outcome: str) -> Tuple[float, float]:
        """
        Calculate optimal position with conservative assumptions.
        """
        if outcome == "YES":
            edge = p_true - p_market
            trade_prob = p_market
        else:  # NO
            edge = (1 - p_true) - (1 - p_market)
            trade_prob = 1 - p_market
            
        if edge < self.min_edge:
            return 0.0, 0.0
            
        # Maximum shares based on position limit
        max_shares = self.max_position_usd / trade_prob if trade_prob > 0 else 0
        
        # Conservative position sizing
        # Start with small position and increase if edge is large
        position_multiplier = min(edge / 0.3, 1.0)  # Cap at 30% edge
        shares = max_shares * position_multiplier * 0.5  # 50% of maximum
        
        # Apply convexity cost
        convexity_cost = self.calculate_convexity_impact(trade_prob, shares)
        net_edge = edge * (1 - convexity_cost)
        
        # Calculate expected value
        ev_usd = net_edge * shares * 100  # Convert to USD
        
        # Ensure positive EV
        if ev_usd <= 0:
            return 0.0, 0.0
            
        return shares, ev_usd
    
    def analyze_markets(self, client: SimmerClient) -> List[Dict]:
        """Analyze all active markets."""
        current_time = datetime.now(timezone.utc)
        
        print("Fetching active markets...")
        markets = client.get_markets(limit=150, status='active')
        print(f"Found {len(markets)} active markets")
        
        opportunities = []
        
        for market in markets:
            # Skip if no probability
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            p_market = market.current_probability
            
            # Skip extreme probabilities
            if p_market > 0.98 or p_market < 0.02:
                continue
                
            # Check expiry
            if hasattr(market, 'expires_at') and market.expires_at:
                time_to_expiry = (market.expires_at - current_time).total_seconds()
                if time_to_expiry < 3600:  # Skip markets expiring in <1 hour
                    continue
                    
            # Get question
            question = market.question if hasattr(market, 'question') else ""
            
            # Calculate realistic probability
            p_true = self.calculate_realistic_probability(p_market, "", question)
            
            # Determine trade direction
            if p_true > p_market:
                edge = p_true - p_market
                outcome = "YES"
                trade_prob = p_market
            elif p_true < p_market:
                edge = p_market - p_true
                outcome = "NO"
                trade_prob = 1 - p_market
            else:
                continue
                
            # Check minimum edge
            if edge < self.min_edge:
                continue
                
            # Calculate optimal position
            shares, ev_usd = self.calculate_optimal_position(p_true, p_market, outcome)
            
            if shares <= 0 or ev_usd <= 0:
                continue
                
            # Classify market type
            market_type = self.classify_market(question)
            
            opportunities.append({
                'id': market.id,
                'question': question[:70] + "..." if len(question) > 70 else question,
                'market_prob': p_market,
                'model_prob': p_true,
                'edge': edge,
                'outcome': outcome,
                'shares': shares,
                'position_cost': shares * trade_prob,
                'expected_ev': ev_usd,
                'type': market_type,
                'expiry': market.expires_at if hasattr(market, 'expires_at') else None
            })
            
        # Sort by edge (most conservative metric)
        opportunities.sort(key=lambda x: x['edge'], reverse=True)
        
        return opportunities[:10]  # Return top 10 by edge
    
    def classify_market(self, question: str) -> str:
        """Classify market type."""
        q = question.lower()
        
        if any(word in q for word in ['lol', 'league', 'esports', 'rainbow', 'siege', 'dota']):
            return "Esports"
        elif any(word in q for word in ['spread', 'nba', 'nfl', 'mlb', 'soccer', 'football']):
            return "Sports"
        elif any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return "Weather"
        elif any(word in q for word in ['bitcoin', 'solana', 'xrp', 'ethereum', 'crypto']):
            return "Crypto"
        elif any(word in q for word in ['election', 'ukraine', 'politic', 'trump', 'biden']):
            return "Politics"
        else:
            return "Other"


def main():
    """Main execution."""
    
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
        
    try:
        client = SimmerClient(api_key=api_key)
    except Exception as e:
        print(f"Error initializing client: {e}")
        sys.exit(1)
        
    analyzer = RealisticLMSRAnalyzer()
    
    print("\n" + "="*80)
    print("LMSR REALISTIC DRY-RUN SCAN")
    print("="*80)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}...")
    print(f"Minimum Edge: {analyzer.min_edge:.0%}")
    print(f"Max Position: ${analyzer.max_position_usd:.2f}")
    print()
    
    opportunities = analyzer.analyze_markets(client)
    
    print("\n" + "="*80)
    print("SCAN RESULTS")
    print("="*80)
    print(f"Opportunities Found: {len(opportunities)}")
    
    if opportunities:
        print(f"\nTOP {len(opportunities)} OPPORTUNITIES (Sorted by Edge):")
        print("-"*80)
        
        total_ev = 0
        total_cost = 0
        
        for i, opp in enumerate(opportunities, 1):
            print(f"\n{i}. {opp['question']}")
            print(f"   Type: {opp['type']}")
            print(f"   Market: {opp['market_prob']:.1%} | Model: {opp['model_prob']:.1%}")
            print(f"   Edge: {opp['edge']:+.1%}")
            print(f"   Action: BUY {opp['outcome']}")
            print(f"   Shares: {opp['shares']:.1f}")
            print(f"   Cost: ${opp['position_cost']:.2f}")
            print(f"   Expected EV: ${opp['expected_ev']:.2f}")
            
            if opp.get('expiry'):
                expiry_str = opp['expiry'].strftime('%Y-%m-%d %H:%M UTC')
                print(f"   Expires: {expiry_str}")
                
            total_ev += opp['expected_ev']
            total_cost += opp['position_cost']
            
        print("\n" + "="*80)
        print("PORTFOLIO SUMMARY")
        print("="*80)
        print(f"Total Opportunities: {len(opportunities)}")
        print(f"Total Position Cost: ${total_cost:.2f}")
        print(f"Total Expected EV: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            print(f"Expected ROI: {roi:.1f}%")
            
        # Analyze by type
        type_counts = {}
        for opp in opportunities:
            t = opp['type']
            type_counts[t] = type_counts.get(t, 0) + 1
            
        print(f"\nOpportunity Distribution:")
        for t, count in sorted(type_counts.items()):
            print(f"  {t}: {count}")
            
        # Risk metrics
        avg_edge = sum(o['edge'] for o in opportunities) / len(opportunities)
        max_edge = max(o['edge'] for o in opportunities)
        min_edge = min(o['edge'] for o in opportunities)
        
        print(f"\nRisk Metrics:")
        print(f"  Average Edge: {avg_edge:.1%}")
        print(f"  Max Edge: {max_edge:.1%}")
        print(f"  Min Edge: {min_edge:.1%}")
        
        print(f"\nPosition Sizing:")
        avg_cost = total_cost / len(opportunities) if opportunities else 0
        print(f"  Average Position: ${avg_cost:.2f}")
        print(f"  Max Single Position: ${max(o['position_cost'] for o in opportunities):.2f}")
        
    else:
        print("\n❌ NO ACTIONABLE OPPORTUNITIES")
        print("\nAnalysis:")
        print("1. No markets meet the 15% minimum edge requirement")
        print("2. Current market conditions may be efficient")
        print("3. Consider the following:")
        print("   - Lower minimum edge threshold (currently 15%)")
        print("   - Review probability model assumptions")
        print("   - Check for data quality issues")
        print("   - Wait for more volatile market conditions")
    
    print("\n" + "="*80)
    print("DRY-RUN STATUS: COMPLETE")
    print("No trades were executed.")
    print("="*80)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())