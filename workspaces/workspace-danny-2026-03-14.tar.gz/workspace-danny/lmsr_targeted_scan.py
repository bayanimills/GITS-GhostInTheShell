#!/usr/bin/env python3
"""
LMSR Targeted Scan - Looking for borderline opportunities
"""

import os
import sys
from datetime import datetime, timezone
import math

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

def calculate_simple_edge(market_prob: float) -> float:
    """Simple mean reversion edge calculation."""
    if market_prob > 0.95 or market_prob < 0.05:
        return 0.0
    return abs(0.5 - market_prob) * 0.4  # 40% of distance to 50%

def calculate_position(market_prob: float, edge: float, outcome: str) -> tuple:
    """Calculate position size and EV."""
    if edge < 0.12:  # Lower threshold for borderline
        return 0.0, 0.0
        
    trade_prob = market_prob if outcome == "YES" else (1 - market_prob)
    if trade_prob <= 0:
        return 0.0, 0.0
        
    # Conservative position
    max_shares = 15.0 / trade_prob  # $15 max position
    shares = max_shares * min(edge / 0.3, 1.0) * 0.6  # 60% of max
    
    # Convexity cost
    convexity = 0.2 + 0.3 * abs(trade_prob - 0.5) * 2  # 20-50% cost
    net_edge = edge * (1 - convexity)
    
    if net_edge <= 0:
        return 0.0, 0.0
        
    ev = net_edge * shares * 100
    return shares, ev

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
        
    client = SimmerClient(api_key=api_key)
    current_time = datetime.now(timezone.utc)
    
    print("Running targeted LMSR scan...")
    markets = client.get_markets(limit=100, status='active')
    
    opportunities = []
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
            
        p = market.current_probability
        
        # Skip extremes
        if p > 0.98 or p < 0.02:
            continue
            
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 3600:  # <1 hour
                continue
        
        # Calculate edge
        edge = calculate_simple_edge(p)
        
        if edge <= 0:
            continue
            
        # Determine outcome
        if p < 0.5:
            outcome = "YES"
        else:
            outcome = "NO"
            
        # Calculate position
        shares, ev = calculate_position(p, edge, outcome)
        
        if shares <= 0 or ev <= 0:
            continue
            
        opportunities.append({
            'question': market.question[:70] + "..." if len(market.question) > 70 else market.question,
            'market_prob': p,
            'edge': edge,
            'outcome': outcome,
            'shares': shares,
            'cost': shares * (p if outcome == "YES" else (1 - p)),
            'ev': ev
        })
    
    # Sort by edge
    opportunities.sort(key=lambda x: x['edge'], reverse=True)
    
    # Generate report
    print("\n" + "="*80)
    print("LMSR TARGETED SCAN REPORT")
    print("="*80)
    print(f"Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"Minimum Edge: 12% (lowered for borderline detection)")
    print(f"Max Position: $15.00")
    print()
    
    if not opportunities:
        print("❌ NO OPPORTUNITIES FOUND (even at 12% edge)")
        print("\nMarket Analysis:")
        print("• Current conditions extremely efficient")
        print("• Consider waiting for market-moving events")
        print("• Next scan recommended in 2-3 hours")
    else:
        print(f"Found {len(opportunities)} borderline opportunities (12-15% edge):")
        print("-"*80)
        
        for i, opp in enumerate(opportunities[:5], 1):  # Top 5 only
            print(f"\n{i}. {opp['question']}")
            print(f"   Market: {opp['market_prob']:.1%} | Edge: {opp['edge']:.1%}")
            print(f"   Action: BUY {opp['outcome']}")
            print(f"   Shares: {opp['shares']:.1f} | Cost: ${opp['cost']:.2f}")
            print(f"   Expected EV: ${opp['ev']:.2f}")
            
            # Risk assessment
            if opp['edge'] < 0.15:
                print(f"   ⚠️  BORDERLINE: Edge below 15% threshold")
            else:
                print(f"   ✅ MEETS 15% THRESHOLD")
        
        print("\n" + "="*80)
        print("RISK ASSESSMENT")
        print("="*80)
        print("Borderline opportunities (12-15% edge) carry higher risk:")
        print("• Convexity costs may eliminate edge entirely")
        print("• Small probability estimation errors significant")
        print("• Market efficiency suggests limited mispricing")
        print("• Recommended: Wait for clearer opportunities")
    
    print("\n" + "="*80)
    print("DRY-RUN STATUS: COMPLETE")
    print("No trades executed.")
    print("="*80)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())