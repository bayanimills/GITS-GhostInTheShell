#!/usr/bin/env python3
"""
Live Trading Configuration for LMSR Trading System
Small positions ($1-5) with proper risk management.
"""

import os
import json
from datetime import datetime
from typing import Dict, List, Tuple

class LiveTradingConfig:
    """
    Configuration for safe, small-position live trading.
    """
    
    def __init__(self, total_capital: float = 100.0):
        """
        Initialize with conservative risk parameters.
        
        Args:
            total_capital: Total trading capital in USD
        """
        self.total_capital = total_capital
        
        # RISK PARAMETERS (Conservative)
        self.max_position_size = 5.0  # $5 max per trade
        self.max_daily_loss = 20.0    # $20 max daily loss
        self.max_concurrent_trades = 3  # Max 3 open positions
        self.min_edge = 0.15           # 15% minimum edge
        self.max_drawdown = 0.30       # 30% max drawdown from peak
        
        # TRADING PARAMETERS
        self.liquidity_param = 100.0   # LMSR b parameter
        self.convexity_buffer = 0.1    # 10% buffer for convexity costs
        self.min_time_to_resolve = 3600  # 1 hour minimum
        
        # TRACKING
        self.daily_pnl = 0.0
        self.open_positions = []
        self.trade_history = []
        self.peak_balance = total_capital
        
    def can_trade(self, market, edge: float, position_size: float) -> Tuple[bool, str]:
        """
        Check if a trade is allowed given risk limits.
        
        Returns:
            (allowed, reason)
        """
        reasons = []
        
        # 1. Edge check
        if abs(edge) < self.min_edge:
            reasons.append(f"Edge {edge:.1%} < minimum {self.min_edge:.0%}")
        
        # 2. Position size check
        if position_size > self.max_position_size:
            reasons.append(f"Position ${position_size:.2f} > max ${self.max_position_size:.2f}")
        
        # 3. Daily loss check
        if self.daily_pnl <= -self.max_daily_loss:
            reasons.append(f"Daily loss ${-self.daily_pnl:.2f} > max ${self.max_daily_loss:.2f}")
        
        # 4. Concurrent trades check
        if len(self.open_positions) >= self.max_concurrent_trades:
            reasons.append(f"{len(self.open_positions)} open trades > max {self.max_concurrent_trades}")
        
        # 5. Drawdown check
        current_balance = self.total_capital + self.daily_pnl
        drawdown = (self.peak_balance - current_balance) / self.peak_balance
        if drawdown > self.max_drawdown:
            reasons.append(f"Drawdown {drawdown:.1%} > max {self.max_drawdown:.0%}")
        
        # 6. Time to resolve check
        if hasattr(market, 'resolves_at'):
            try:
                resolves_at = datetime.fromisoformat(market.resolves_at.replace('Z', '+00:00'))
                time_to_resolve = (resolves_at - datetime.now()).total_seconds()
                if time_to_resolve < self.min_time_to_resolve:
                    reasons.append(f"Resolves in {time_to_resolve/3600:.1f}h < minimum {self.min_time_to_resolve/3600:.0f}h")
            except:
                pass
        
        if reasons:
            return False, " | ".join(reasons)
        return True, "OK"
    
    def calculate_position_size(self, p_market: float, edge: float) -> float:
        """
        Calculate optimal position size with risk limits.
        """
        if edge <= 0:
            return 0.0
        
        # Kelly-like sizing with convexity buffer
        price_per_share = p_market if edge > 0 else (1 - p_market)
        
        # Base Kelly fraction
        kelly_fraction = edge / price_per_share
        
        # Apply convexity buffer
        effective_fraction = kelly_fraction * (1 - self.convexity_buffer)
        
        # Calculate position size
        position = effective_fraction * self.total_capital
        
        # Apply risk limits
        position = min(position, self.max_position_size)
        
        # Ensure minimum trade size (at least $0.50 to be meaningful)
        if position < 0.5:
            return 0.0
        
        return round(position, 2)  # Round to cents
    
    def record_trade(self, market, outcome: str, shares: float, 
                    entry_price: float, estimated_pnl: float):
        """
        Record a trade for tracking.
        """
        trade = {
            'timestamp': datetime.now().isoformat(),
            'market_id': market.id,
            'market_question': market.question[:100] if hasattr(market, 'question') else 'Unknown',
            'outcome': outcome,
            'shares': shares,
            'entry_price': entry_price,
            'estimated_pnl': estimated_pnl,
            'status': 'open'
        }
        
        self.open_positions.append(trade)
        self.trade_history.append(trade)
        
        # Update estimated P&L
        self.daily_pnl += estimated_pnl
        
        # Update peak balance
        current_balance = self.total_capital + self.daily_pnl
        self.peak_balance = max(self.peak_balance, current_balance)
    
    def close_position(self, market_id: str, exit_price: float, actual_pnl: float):
        """
        Close a position and update tracking.
        """
        for i, trade in enumerate(self.open_positions):
            if trade['market_id'] == market_id:
                trade['exit_price'] = exit_price
                trade['actual_pnl'] = actual_pnl
                trade['status'] = 'closed'
                trade['closed_at'] = datetime.now().isoformat()
                
                # Update daily P&L with actual instead of estimated
                self.daily_pnl = self.daily_pnl - trade['estimated_pnl'] + actual_pnl
                
                # Remove from open positions
                self.open_positions.pop(i)
                break
    
    def get_status(self) -> Dict:
        """
        Get current trading status.
        """
        current_balance = self.total_capital + self.daily_pnl
        drawdown = (self.peak_balance - current_balance) / self.peak_balance if self.peak_balance > 0 else 0.0
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_capital': self.total_capital,
            'current_balance': current_balance,
            'daily_pnl': self.daily_pnl,
            'peak_balance': self.peak_balance,
            'drawdown': drawdown,
            'open_positions': len(self.open_positions),
            'max_position_size': self.max_position_size,
            'max_daily_loss': self.max_daily_loss,
            'remaining_daily_loss': self.max_daily_loss + self.daily_pnl,  # Positive = available
            'can_trade': self.daily_pnl > -self.max_daily_loss and drawdown <= self.max_drawdown
        }
    
    def reset_daily(self):
        """Reset daily tracking (call at start of each day)."""
        self.daily_pnl = 0.0
        # Note: open positions remain open


def create_safe_trading_plan():
    """
    Create a safe trading plan for starting with small positions.
    """
    plan = {
        'phase': 'Initial Testing',
        'duration': '1-2 weeks',
        'goal': 'Validate edge and risk management',
        'parameters': {
            'total_capital': 100.0,
            'max_position_size': 5.0,
            'max_daily_loss': 20.0,
            'max_concurrent_trades': 3,
            'min_edge': 0.15,
            'stop_loss_per_trade': 0.5,  # 50% of position
            'take_profit_per_trade': 1.0,  # 100% of position
        },
        'daily_routine': [
            '08:00 - Check overnight positions',
            '09:00 - Morning scan for opportunities',
            '12:00 - Midday scan and position review',
            '15:00 - Afternoon scan',
            '18:00 - End-of-day review and planning',
            '21:00 - Evening scan (if markets active)'
        ],
        'success_metrics': {
            'win_rate': '>55%',
            'average_edge': '>5% after convexity',
            'sharpe_ratio': '>1.0',
            'max_drawdown': '<20%',
            'daily_ev': '$10-20 with $5 positions'
        },
        'escalation_criteria': {
            'phase_2': 'After 10 winning trades or 1 week',
            'phase_2_params': {
                'max_position_size': 10.0,
                'max_daily_loss': 40.0,
                'min_edge': 0.12
            },
            'phase_3': 'After 50 winning trades or 1 month',
            'phase_3_params': {
                'max_position_size': 20.0,
                'max_daily_loss': 80.0,
                'min_edge': 0.10
            }
        }
    }
    
    return plan


if __name__ == "__main__":
    print("="*70)
    print("LIVE TRADING CONFIGURATION - SMALL POSITIONS")
    print("="*70)
    
    # Create config
    config = LiveTradingConfig(total_capital=100.0)
    
    # Show status
    status = config.get_status()
    print(f"\n📊 INITIAL STATUS:")
    print(f"  Total capital: ${status['total_capital']:.2f}")
    print(f"  Max position size: ${config.max_position_size:.2f}")
    print(f"  Max daily loss: ${config.max_daily_loss:.2f}")
    print(f"  Max concurrent trades: {config.max_concurrent_trades}")
    print(f"  Min edge: {config.min_edge:.0%}")
    
    # Show trading plan
    plan = create_safe_trading_plan()
    print(f"\n🎯 TRADING PLAN: {plan['phase']}")
    print(f"  Duration: {plan['duration']}")
    print(f"  Goal: {plan['goal']}")
    
    print(f"\n📈 SUCCESS METRICS:")
    for metric, target in plan['success_metrics'].items():
        print(f"  {metric.replace('_', ' ').title()}: {target}")
    
    print(f"\n🚀 ESCALATION PATH:")
    for phase, criteria in plan['escalation_criteria'].items():
        if 'params' in criteria:
            print(f"  {phase}: {criteria}")
    
    print(f"\n" + "="*70)
    print("READY FOR LIVE TRADING WITH:")
    print("1. Conservative risk limits")
    print("2. Small position sizes ($1-5)")
    print("3. Daily loss limits ($20 max)")
    print("4. Performance tracking")
    print("5. Clear escalation path")
    print("="*70)