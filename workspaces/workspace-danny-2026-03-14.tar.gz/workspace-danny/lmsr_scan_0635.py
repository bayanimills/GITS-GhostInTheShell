#!/usr/bin/env python3
"""
LMSR Scan - 6:35 AM AEST
Optimized scan with market-type specific edge detection.
"""

import os
import sys
from datetime import datetime, timezone

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class MarketAnalyzer:
    """Market analyzer with type-specific parameters."""
    
    def __init__(self):
        # Market type configurations
        self.configs = {
            'crypto': {
                'edge_multiplier': 0.52,  # 52% of distance
                'base_convexity': 0.20,   # 20% base cost
                'prob_factor': 0.32,      # Probability impact
                'min_ev': 15.0            # Minimum EV
            },
            'esports': {
                'edge_multiplier': 0.56,
                'base_convexity': 0.23,
                'prob_factor': 0.30,
                'min_ev': 12.0
            },
            'sports': {
                'edge_multiplier': 0.46,
                'base_convexity': 0.24,
                'prob_factor': 0.31,
                'min_ev': 10.0
            },
            'weather': {
                'edge_multiplier': 0.41,
                'base_convexity': 0.26,
                'prob_factor': 0.33,
                'min_ev': 8.0
            },
            'politics': {
                'edge_multiplier': 0.44,
                'base_convexity': 0.25,
                'prob_factor': 0.32,
                'min_ev': 10.0
            },
            'other': {
                'edge_multiplier': 0.43,
                'base_convexity': 0.26,
                'prob_factor': 0.31,
                'min_ev': 8.0
            }
        }
        
        # Global parameters
        self.min_edge = 0.15
        self.max_position = 24.0  # Increased for 6:35 AM scan
        self.size_factor = 0.12   # Size impact on convexity
    
    def classify_market(self, question):
        """Classify market type."""
        q = question.lower()
        
        if any(word in q for word in ['bitcoin', 'ethereum', 'solana', 'xrp', 'crypto']):
            return 'crypto'
        elif any(word in q for word in ['lol', 'esports', 'rainbow', 'siege', 'dota']):
            return 'esports'
        elif any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return 'weather'
        elif any(word in q for word in ['spread', 'nba', 'soccer', 'football', 'basketball']):
            return 'sports'
        elif any(word in q for word in ['election', 'politic', 'ukraine', 'trump', 'biden']):
            return 'politics'
        else:
            return 'other'
    
    def analyze(self, market_prob, question):
        """Analyze market for opportunities."""
        if market_prob > 0.97 or market_prob < 0.03:
            return None
        
        # Classify market
        market_type = self.classify_market(question)
        config = self.configs[market_type]
        
        # Calculate distance from 50%
        distance = abs(0.5 - market_prob)
        
        # Gross edge
        gross_edge = distance * config['edge_multiplier']
        
        if gross_edge < self.min_edge:
            return None
        
        # Determine trade direction
        if market_prob < 0.5:
            outcome = "YES"
            trade_prob = market_prob
        else:
            outcome = "NO"
            trade_prob = 1 - market_prob
        
        # Position sizing
        max_shares = self.max_position / trade_prob if trade_prob > 0 else 0
        
        # Edge-based scaling
        edge_ratio = min(gross_edge / 0.3, 1.0)
        shares = max_shares * (edge_ratio ** 0.65) * 0.72
        
        # Convexity cost
        prob_factor = 2 * abs(trade_prob - 0.5) * config['prob_factor']
        size_factor = min(shares / 80, 1.0) * self.size_factor
        
        convexity_pct = config['base_convexity'] + prob_factor + size_factor
        convexity_pct = min(convexity_pct, 0.68)  # Max 68%
        
        # Net edge
        net_edge = gross_edge * (1 - convexity_pct)
        
        if net_edge < self.min_edge:
            return None
        
        # Expected value
        ev = net_edge * shares * 100
        
        if ev < config['min_ev']:
            return None
        
        return {
            'market_type': market_type,
            'gross_edge': gross_edge,
            'net_edge': net_edge,
            'convexity_pct': convexity_pct * 100,
            'outcome': outcome,
            'shares': shares,
            'cost': shares * trade_prob,
            'ev': ev,
            'trade_prob': trade_prob,
            'edge_mult': config['edge_multiplier']
        }

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    client = SimmerClient(api_key=api_key)
    analyzer = MarketAnalyzer()
    current_time = datetime.now(timezone.utc)
    
    print("=" * 80)
    print("LMSR DRY-RUN SCAN REPORT")
    print("=" * 80)
    print(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}... (validated)")
    print(f"Minimum Edge: >15% (after convexity costs)")
    print(f"Max Position: ${analyzer.max_position:.2f}")
    print(f"Scan Time: 6:35 AM AEST (pre-market)")
    print()
    
    # Fetch markets
    print("Fetching and analyzing markets...")
    markets = client.get_markets(limit=110, status='active')
    
    opportunities = []
    type_counts = {mtype: 0 for mtype in analyzer.configs.keys()}
    type_counts['total'] = len(markets)
    type_counts['tradable'] = 0
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
        
        p = market.current_probability
        
        # Basic filters
        if p > 0.97 or p < 0.03:
            continue
        
        type_counts['tradable'] += 1
        
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 6000:  # <1.67 hours
                continue
        
        question = market.question if hasattr(market, 'question') else ""
        
        # Analyze
        analysis = analyzer.analyze(p, question)
        if analysis:
            mtype = analysis['market_type']
            type_counts[mtype] += 1
            
            opportunities.append({
                'id': market.id,
                'question': question[:68] + "..." if len(question) > 68 else question,
                'market_prob': p,
                'analysis': analysis
            })
    
    # Sort by net edge
    opportunities.sort(key=lambda x: x['analysis']['net_edge'], reverse=True)
    
    # Print statistics
    print(f"\nMarket Statistics:")
    print(f"  Total markets: {type_counts['total']}")
    print(f"  Tradable markets: {type_counts['tradable']}")
    print(f"  Crypto markets found: {type_counts['crypto']}")
    print(f"  Esports markets found: {type_counts['esports']}")
    print(f"  Sports markets found: {type_counts['sports']}")
    print(f"  Weather markets found: {type_counts['weather']}")
    print(f"  Politics markets found: {type_counts['politics']}")
    print(f"  Other markets found: {type_counts['other']}")
    print(f"  Opportunities found: {len(opportunities)}")
    
    # Generate report
    if not opportunities:
        print("\n" + "=" * 80)
        print("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("=" * 80)
        
        print("\n6:35 AM AEST Market Analysis:")
        print("• Time: Pre-market, Asian markets opening")
        print("• Efficiency: Still high (overnight carryover)")
        print("• Convexity: 20-68% range (type-dependent)")
        print("• Activity: Gradually increasing from overnight lows")
        
        print("\nMarket Type Configurations:")
        for mtype, config in analyzer.configs.items():
            print(f"  {mtype.upper()}: {config['edge_multiplier']:.0%} edge multiplier")
        
        print("\nConvexity Base Costs:")
        for mtype, config in analyzer.configs.items():
            print(f"  {mtype.upper()}: {config['base_convexity']:.0%} base + probability factor")
        
        print("\nRecommendations:")
        print("  1. Wait for US pre-market activity (7:00 PM ET)")
        print("  2. Monitor crypto markets (24/7, most active overnight)")
        print("  3. Next scan at 7:00 AM AEST (European influence)")
        print("  4. Consider 12% edge threshold for pre-market scans")
        
    else:
        print(f"\n✅ FOUND {len(opportunities)} OPPORTUNITIES")
        print("\nTOP 5 OPPORTUNITIES (Sorted by Net Edge):")
        print("-" * 80)
        
        total_ev = 0
        total_cost = 0
        net_edges = []
        
        for i, opp in enumerate(opportunities[:5], 1):
            analysis = opp['analysis']
            
            print(f"\n{i}. {opp['question']}")
            print(f"   Type: {analysis['market_type'].upper()}")
            print(f"   Market Probability: {opp['market_prob']:.1%}")
            print(f"   Distance from 50%: {abs(0.5 - opp['market_prob']):.1%}")
            print(f"   Edge Model: {analysis['edge_mult']:.0%} of distance")
            print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
            print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
            print(f"   Net Edge: {analysis['net_edge']:.1%} ✅")
            print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
            print(f"   Shares: {analysis['shares']:.1f}")
            print(f"   Position Cost: ${analysis['cost']:.2f}")
            print(f"   Expected EV: ${analysis['ev']:.2f}")
            
            total_ev += analysis['ev']
            total_cost += analysis['cost']
            net_edges.append(analysis['net_edge'])
        
        print("\n" + "=" * 80)
        print("PORTFOLIO SUMMARY")
        print("=" * 80)
        print(f"Total Opportunities: {min(5, len(opportunities))}")
        print(f"Total Investment: ${total_cost:.2f}")
        print(f"Total Expected EV: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            print(f"Expected ROI: {roi:.1f}%")
            print(f"Return per Dollar: ${total_ev/total_cost:.2f}")
        
        # Detailed analysis
        avg_edge = sum(net_edges) / len(net_edges)
        max_edge = max(net_edges)
        min_edge = min(net_edges)
        
        print(f"\nDETAILED ANALYSIS:")
        print(f"  Average Net Edge: {avg_edge:.1%}")
        print(f"  Maximum Net Edge: {max_edge:.1%}")
        print(f"  Minimum Net Edge: {min_edge:.1%}")
        print(f"  Edge Range: {min_edge:.1%} - {max_edge:.1%}")
        
        # Market type distribution
        opp_types = {}
        for opp in opportunities[:5]:
            mtype = opp['analysis']['market_type']
            opp_types[mtype] = opp_types.get(mtype, 0) + 1
        
        print(f"\nOPPORTUNITY DISTRIBUTION:")
        for mtype, count in sorted(opp_types.items()):
            print(f"  {mtype.upper()}: {count}")
        
        print(f"\n6:35 AM AEST TIME ANALYSIS:")
        print(f"  • Pre-market conditions")
        print(f"  • Asian markets opening")
        print(f"  • European influence beginning")
        print(f"  • Conservative parameters applied")
        
        print(f"\nTRADING RECOMMENDATION:")
        if len(opportunities) >= 4 and avg_edge > 0.17:
            print("  ✅ STRONG OPPORTUNITIES - Consider trading")
            print("  ⚠️  Start with 70% of calculated positions")
            print("  📊 Monitor execution closely")
        elif len(opportunities) >= 3 and avg_edge > 0.16:
            print("  ⚠️  MODERATE OPPORTUNITIES - Trade cautiously")
            print("  🔍 Consider top 3 opportunities only")
            print("  💰 Use 60% position sizes")
        else:
            print("  ⚠️  LIMITED OPPORTUNITIES - Consider waiting")
            print("  🔄 Wait for more/better opportunities")
            print("  📈 Monitor market developments")
    
    print("\n" + "=" * 80)
    print("DRY-RUN STATUS: COMPLETE")
    print("No trades were executed.")
    print("=" * 80)
    
    # Save report
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    with open(f"lmsr_0635_report_{timestamp}.txt", 'w') as f:
        f.write(f"LMSR Scan Report - 6:35 AM AEST\n")
        f.write(f"Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')}\n")
        f.write("="*60 + "\n")
        
        if opportunities:
            f.write(f"\nFound {len(opportunities)} opportunities:\n")
            for i, opp in enumerate(opportunities[:5], 1):
                analysis = opp['analysis']
                f.write(f"\n{i}. {opp['question']}\n")
                f.write(f"   Market: {opp['market_prob']:.1%} | Net Edge: {analysis['net_edge']:.1%}\n")
                f.write(f"   Action: BUY {analysis['outcome']} | Cost: ${analysis['cost']:.2f}\n")
                f.write(f"   EV: ${analysis['ev']:.2f} | Type: {analysis['market_type']}\n")
        else:
            f.write("\nNo opportunities meeting 15% edge requirement.\n")
    
    print(f"\nDetailed report saved to: lmsr_0635_report_{timestamp}.txt")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())