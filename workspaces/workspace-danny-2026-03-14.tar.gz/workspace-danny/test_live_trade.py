#!/usr/bin/env python3
"""
Test a live trade with the safe configuration.
This simulates what would happen when we execute.
"""

from live_trading_config import LiveTradingConfig
from datetime import datetime, timedelta

def test_trade_scenario():
    """Test various trade scenarios with the risk management."""
    
    print("="*70)
    print("LIVE TRADE TEST SCENARIOS")
    print("Testing risk management with $1-5 positions")
    print("="*70)
    
    # Initialize with $100 capital
    config = LiveTradingConfig(total_capital=100.0)
    
    # Scenario 1: Valid trade
    print("\n1. VALID TRADE SCENARIO:")
    print("-"*40)
    
    # Simulate market data
    class MockMarket:
        id = "test_market_123"
        question = "Will Bitcoin reach $100,000 by June 2026?"
        resolves_at = (datetime.now() + timedelta(hours=24)).isoformat()
    
    market = MockMarket()
    edge = 0.20  # 20% edge
    p_market = 0.45  # Market says 45%
    
    # Calculate position size
    position_size = config.calculate_position_size(p_market, edge)
    
    # Check if trade is allowed
    allowed, reason = config.can_trade(market, edge, position_size)
    
    print(f"   Market: {market.question[:50]}...")
    print(f"   Edge: {edge:.1%}")
    print(f"   Position size: ${position_size:.2f}")
    print(f"   Allowed: {'✅ YES' if allowed else '❌ NO'}")
    if not allowed:
        print(f"   Reason: {reason}")
    
    if allowed:
        # Simulate trade execution
        entry_price = p_market
        shares = position_size / entry_price
        estimated_pnl = shares * edge * 100  # Convert to USD
        
        config.record_trade(
            market=market,
            outcome="YES",
            shares=shares,
            entry_price=entry_price,
            estimated_pnl=estimated_pnl
        )
        
        print(f"   Trade executed: BUY YES @ {shares:.1f} shares")
        print(f"   Estimated P&L: ${estimated_pnl:.2f}")
    
    # Scenario 2: Edge too small
    print("\n2. EDGE TOO SMALL SCENARIO:")
    print("-"*40)
    
    small_edge = 0.10  # 10% edge (below 15% minimum)
    position_size = config.calculate_position_size(p_market, small_edge)
    allowed, reason = config.can_trade(market, small_edge, position_size)
    
    print(f"   Edge: {small_edge:.1%} (minimum: {config.min_edge:.0%})")
    print(f"   Position size: ${position_size:.2f}")
    print(f"   Allowed: {'✅ YES' if allowed else '❌ NO'}")
    if not allowed:
        print(f"   Reason: {reason}")
    
    # Scenario 3: Position too large
    print("\n3. POSITION TOO LARGE SCENARIO:")
    print("-"*40)
    
    large_edge = 0.30  # 30% edge
    # Force a large position (simulate miscalculation)
    large_position = 10.0  # $10 > $5 max
    allowed, reason = config.can_trade(market, large_edge, large_position)
    
    print(f"   Edge: {large_edge:.1%}")
    print(f"   Position size: ${large_position:.2f} (max: ${config.max_position_size:.2f})")
    print(f"   Allowed: {'✅ YES' if allowed else '❌ NO'}")
    if not allowed:
        print(f"   Reason: {reason}")
    
    # Scenario 4: Daily loss limit reached
    print("\n4. DAILY LOSS LIMIT SCENARIO:")
    print("-"*40)
    
    # Simulate bad day
    config.daily_pnl = -25.0  # Already lost $25 today
    allowed, reason = config.can_trade(market, edge, position_size)
    
    print(f"   Daily P&L: ${config.daily_pnl:.2f} (limit: -${config.max_daily_loss:.2f})")
    print(f"   Allowed: {'✅ YES' if allowed else '❌ NO'}")
    if not allowed:
        print(f"   Reason: {reason}")
    
    # Reset for next test
    config.daily_pnl = 0.0
    
    # Scenario 5: Too many concurrent trades
    print("\n5. TOO MANY CONCURRENT TRADES:")
    print("-"*40)
    
    # Simulate having max trades open
    for i in range(config.max_concurrent_trades):
        mock_market = MockMarket()
        mock_market.id = f"market_{i}"
        config.record_trade(
            market=mock_market,
            outcome="YES",
            shares=1.0,
            entry_price=0.5,
            estimated_pnl=0.1
        )
    
    allowed, reason = config.can_trade(market, edge, position_size)
    
    print(f"   Open positions: {len(config.open_positions)} (max: {config.max_concurrent_trades})")
    print(f"   Allowed: {'✅ YES' if allowed else '❌ NO'}")
    if not allowed:
        print(f"   Reason: {reason}")
    
    # Show final status
    print("\n" + "="*70)
    print("FINAL TRADING STATUS:")
    print("-"*70)
    
    status = config.get_status()
    for key, value in status.items():
        if key not in ['timestamp', 'can_trade']:
            if isinstance(value, float):
                if 'drawdown' in key:
                    print(f"  {key.replace('_', ' ').title()}: {value:.1%}")
                elif 'pnl' in key or 'capital' in key or 'balance' in key:
                    print(f"  {key.replace('_', ' ').title()}: ${value:.2f}")
                else:
                    print(f"  {key.replace('_', ' ').title()}: {value}")
            else:
                print(f"  {key.replace('_', ' ').title()}: {value}")
    
    print(f"  Can Trade: {'✅ YES' if status['can_trade'] else '❌ NO'}")
    
    print("\n" + "="*70)
    print("KEY TAKEAWAYS:")
    print("1. System prevents overtrading and large losses")
    print("2. Multiple safety checks before any trade")
    print("3. Small positions ($1-5) limit risk")
    print("4. Daily loss limit protects from bad days")
    print("5. Ready for safe live trading")
    print("="*70)


if __name__ == "__main__":
    test_trade_scenario()