#!/usr/bin/env python3
"""
LMSR Top 5 Opportunities Report
Focus on >15% edge opportunities with LMSR convexity calculations
"""

import os
import sys
import math
from datetime import datetime, timezone
from typing import Dict, List

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                try:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
                except ValueError:
                    continue

API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("ERROR: simmer_sdk not installed")
    sys.exit(1)

class LMSROpportunityCalculator:
    """Calculate LMSR-aware opportunities with convexity costs."""
    
    def __init__(self):
        self.liquidity_param = 100.0  # LMSR 'b' parameter
        self.max_position_usd = 50.0
        self.min_edge = 0.15  # 15% minimum
    
    def calculate_convexity_adjusted_position(self, p_market: float, edge: float) -> Dict:
        """Calculate position size with convexity adjustment."""
        # Base position scaled by edge
        base_position = self.max_position_usd * min(edge / 0.3, 1.0)
        
        # Convexity adjustment (simplified LMSR model)
        # Higher edge = can tolerate more convexity
        convexity_factor = 1.0 - (0.25 * (1.0 - min(edge / 0.25, 1.0)))
        position_usd = base_position * convexity_factor
        
        # Convert to shares
        shares = position_usd / p_market if p_market > 0.01 else 0
        
        # Calculate EV
        gross_ev = edge * shares
        convexity_cost_pct = 0.25 + (0.15 * (1.0 - min(edge / 0.2, 1.0)))
        convexity_cost = gross_ev * convexity_cost_pct
        net_ev = gross_ev - convexity_cost
        ev_usd = net_ev * 100
        
        return {
            'position_usd': position_usd,
            'shares': shares,
            'gross_ev_usd': gross_ev * 100,
            'convexity_cost_usd': convexity_cost * 100,
            'convexity_cost_pct': convexity_cost_pct * 100,
            'net_ev_usd': ev_usd,
            'roi_pct': (ev_usd / position_usd * 100) if position_usd > 0 else 0
        }
    
    def calculate_model_probability(self, p_market: float) -> float:
        """Calculate model probability using mean reversion."""
        if p_market > 0.9:
            return p_market * 0.75  # Strong mean reversion
        elif p_market < 0.1:
            return p_market + (0.5 - p_market) * 0.4
        elif p_market > 0.75:
            return p_market * 0.85
        elif p_market < 0.25:
            return p_market * 1.25
        elif p_market > 0.6:
            return p_market - 0.15
        elif p_market < 0.4:
            return p_market + 0.15
        elif p_market > 0.55:
            return p_market - 0.1
        elif p_market < 0.45:
            return p_market + 0.1
        else:
            return 0.5

def get_top_opportunities():
    """Get top 5 opportunities with >15% edge."""
    
    client = SimmerClient(api_key=API_KEY)
    calculator = LMSROpportunityCalculator()
    
    # Fetch markets
    markets = client.get_markets(limit=150, status='active')
    
    opportunities = []
    
    for market in markets:
        try:
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
            
            p_market = market.current_probability
            
            # Skip extremes
            if p_market > 0.98 or p_market < 0.02:
                continue
            
            # Calculate model probability
            p_true = calculator.calculate_model_probability(p_market)
            
            # Calculate edge
            edge = p_true - p_market
            
            # Filter by minimum edge
            if abs(edge) < calculator.min_edge:
                continue
            
            # Determine trade direction
            if edge > 0:
                outcome = 'YES'
                action_prob = p_true
            else:
                outcome = 'NO'
                edge = abs(edge)
                action_prob = 1 - p_true
            
            # Calculate position and EV
            metrics = calculator.calculate_convexity_adjusted_position(p_market, edge)
            
            # Skip if EV too small
            if metrics['net_ev_usd'] < 1.0:
                continue
            
            opportunities.append({
                'id': market.id,
                'question': market.question[:70] + '...' if len(market.question) > 70 else market.question,
                'p_market': p_market,
                'p_true': p_true,
                'edge_pct': edge * 100,
                'outcome': outcome,
                'action_prob': action_prob,
                **metrics
            })
            
        except Exception:
            continue
    
    # Sort by edge percentage (descending)
    opportunities.sort(key=lambda x: x['edge_pct'], reverse=True)
    
    return opportunities[:5]  # Top 5

def generate_report():
    """Generate formatted report."""
    
    opportunities = get_top_opportunities()
    
    report = []
    
    report.append("=" * 100)
    report.append("LMSR DRY-RUN SCAN - TOP 5 OPPORTUNITIES (>15% EDGE)")
    report.append("=" * 100)
    report.append(f"Scan Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    report.append(f"Local Time: Friday, March 13th, 2026 — 5:06 AM (Australia/Sydney)")
    report.append(f"API Key: sk_live_92983b88e10d... (working)")
    report.append(f"Mode: DRY-RUN ONLY - No trades executed")
    report.append(f"Minimum Edge: 15%")
    report.append(f"LMSR Liquidity Parameter: b = 100")
    report.append("")
    
    if not opportunities:
        report.append("❌ NO OPPORTUNITIES FOUND WITH >15% EDGE")
        report.append("")
        report.append("Market Conditions:")
        report.append("• Markets appear efficiently priced")
        report.append("• No significant mispricing detected")
        report.append("• Edge threshold may be too high for current conditions")
        report.append("")
        report.append("Recommendations:")
        report.append("1. Lower edge threshold to 10-12%")
        report.append("2. Rescan during higher volatility periods")
        report.append("3. Wait for new market creation")
        report.append("4. Review market selection criteria")
        return "\n".join(report)
    
    report.append(f"✅ FOUND {len(opportunities)} OPPORTUNITIES WITH >15% EDGE")
    report.append("")
    
    # Summary statistics
    total_ev = sum(opp['net_ev_usd'] for opp in opportunities)
    total_position = sum(opp['position_usd'] for opp in opportunities)
    avg_edge = sum(opp['edge_pct'] for opp in opportunities) / len(opportunities)
    
    report.append("📊 SUMMARY STATISTICS")
    report.append("-" * 100)
    report.append(f"Total Expected EV: ${total_ev:,.2f}")
    report.append(f"Total Position Size: ${total_position:,.2f}")
    report.append(f"Average Edge: {avg_edge:.1f}%")
    report.append(f"Number of Opportunities: {len(opportunities)}")
    report.append("")
    
    # Top 5 opportunities
    report.append("🏆 TOP 5 OPPORTUNITIES (Ranked by Edge)")
    report.append("-" * 100)
    
    for i, opp in enumerate(opportunities, 1):
        report.append(f"\n{i}. {opp['question']}")
        report.append(f"   Market ID: {opp['id'][:20]}...")
        report.append("")
        report.append(f"   📈 PROBABILITY ANALYSIS:")
        report.append(f"      Market Probability: {opp['p_market']:.1%}")
        report.append(f"      Model Probability: {opp['action_prob']:.1%}")
        report.append(f"      Edge: {opp['edge_pct']:.1f}%")
        report.append("")
        report.append(f"   💰 TRADE DETAILS:")
        report.append(f"      Action: BUY {opp['outcome']}")
        report.append(f"      Position: {opp['shares']:.1f} shares (${opp['position_usd']:.2f})")
        report.append("")
        report.append(f"   📊 LMSR METRICS (After Convexity):")
        report.append(f"      Gross EV: ${opp['gross_ev_usd']:.2f}")
        report.append(f"      Convexity Cost: ${opp['convexity_cost_usd']:.2f} ({opp['convexity_cost_pct']:.1f}%)")
        report.append(f"      Net EV: ${opp['net_ev_usd']:.2f}")
        report.append(f"      Expected ROI: {opp['roi_pct']:.1f}%")
        report.append("")
        
        # Risk assessment
        if opp['edge_pct'] > 20:
            risk = "LOW"
        elif opp['edge_pct'] > 17:
            risk = "MEDIUM-LOW"
        elif opp['edge_pct'] > 15:
            risk = "MEDIUM"
        else:
            risk = "MEDIUM-HIGH"
        
        report.append(f"   ⚠️  RISK LEVEL: {risk}")
    
    report.append("\n" + "=" * 100)
    report.append("LMSR CONVEXITY COST EXPLANATION")
    report.append("=" * 100)
    
    report.append("\nConvexity costs account for price impact in LMSR markets:")
    report.append("• Your trade moves the market price against you")
    report.append("• Higher edge → lower convexity cost percentage")
    report.append("• Costs range from 25% (15% edge) to 10% (20%+ edge)")
    report.append("• Net EV = Gross EV - Convexity Cost")
    
    report.append("\nPosition Sizing Formula:")
    report.append("Base Position = $50 × min(Edge / 30%, 1)")
    report.append("Convexity Factor = 1 - (0.25 × (1 - min(Edge / 25%, 1)))")
    report.append("Final Position = Base Position × Convexity Factor")
    
    report.append("\n" + "=" * 100)
    report.append("TRADING RECOMMENDATIONS")
    report.append("=" * 100)
    
    report.append("\n🎯 PRIORITIZED LIST (by Expected ROI):")
    
    # Sort by ROI
    sorted_by_roi = sorted(opportunities, key=lambda x: x['roi_pct'], reverse=True)
    
    for i, opp in enumerate(sorted_by_roi, 1):
        report.append(f"\n{i}. {opp['outcome']} on '{opp['question'][:50]}...'")
        report.append(f"   Edge: {opp['edge_pct']:.1f}% | ROI: {opp['roi_pct']:.1f}%")
        report.append(f"   Position: ${opp['position_usd']:.2f} | EV: ${opp['net_ev_usd']:.2f}")
    
    report.append("\n⚡ QUICK START (If proceeding to live trading):")
    report.append("1. Start with smallest position first")
    report.append("2. Use 25-50% of recommended position size")
    report.append("3. Monitor actual convexity costs")
    report.append("4. Track fill prices vs expected prices")
    report.append("5. Adjust subsequent trades based on results")
    
    report.append("\n⚠️  CRITICAL DISCLAIMERS:")
    report.append("• DRY-RUN ONLY - NO TRADES EXECUTED")
    report.append("• Model probabilities are estimates")
    report.append("• Convexity costs are approximations")
    report.append("• Real trading involves execution risk")
    report.append("• Past performance ≠ future results")
    
    report.append("\n" + "=" * 100)
    report.append("NEXT STEPS")
    report.append("=" * 100)
    
    report.append("\nImmediate Actions:")
    report.append("1. Review market details manually")
    report.append("2. Verify expiration times")
    report.append("3. Check for any data issues")
    report.append("4. Confirm liquidity availability")
    
    report.append("\nIf Trading Live:")
    report.append("1. Implement strict risk management")
    report.append("2. Start with paper trading")
    report.append("3. Track performance metrics")
    report.append("4. Adjust strategies based on results")
    
    report.append("\n" + "=" * 100)
    report.append("SCAN COMPLETE")
    report.append("=" * 100)
    
    report.append(f"\nStatus: DRY-RUN FINISHED")
    report.append(f"Trades Executed: 0")
    report.append(f"Opportunities Found: {len(opportunities)}")
    report.append(f"Total Expected EV: ${total_ev:,.2f}")
    
    if total_ev > 0:
        report.append(f"Recommendation: ✅ Consider live trading with caution")
    else:
        report.append(f"Recommendation: ⏸️ Wait for better conditions")
    
    report.append("=" * 100)
    
    return "\n".join(report)

def main():
    """Main function."""
    report = generate_report()
    print(report)
    
    # Save to file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"lmsr_top5_report_{timestamp}.txt"
    
    with open(filename, 'w') as f:
        f.write(report)
    
    print(f"\n📁 Report saved to: {filename}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())