#!/usr/bin/env python3
"""
LMSR Comprehensive Dry-Run Scan
Final report with detailed analysis and realistic opportunities.
"""

import os
import sys
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Tuple, Optional

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class ComprehensiveLMSRScanner:
    """Comprehensive scanner with multiple edge detection strategies."""
    
    def __init__(self):
        self.min_edge = 0.15  # 15% minimum edge
        self.max_position_usd = 20.0  # Conservative position
        self.liquidity_param = 200.0  # LMSR liquidity parameter
        
    def lmsr_price(self, quantities: List[float], outcome: int) -> float:
        """Calculate LMSR price."""
        if self.liquidity_param <= 0:
            return 0.5
            
        exponents = [q / self.liquidity_param for q in quantities]
        max_exp = max(exponents)
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        
        if sum_exp == 0:
            return 1.0 / len(quantities)
            
        return exp_terms[outcome] / sum_exp
    
    def calculate_edge_strategies(self, market_prob: float, question: str) -> List[Tuple[str, float]]:
        """
        Calculate edges using multiple strategies.
        Returns list of (strategy_name, edge_percentage)
        """
        strategies = []
        q = question.lower()
        
        # Strategy 1: Simple mean reversion
        # Assumes probabilities tend to revert to 50%
        mean_reversion_edge = abs(0.5 - market_prob) * 0.3  # 30% of distance to 50%
        if mean_reversion_edge > 0:
            strategies.append(("Mean Reversion", mean_reversion_edge))
        
        # Strategy 2: Extreme probability correction
        # Markets at extremes often overstate certainty
        if market_prob > 0.8:
            correction = (market_prob - 0.8) * 0.4  # 40% correction for >80%
            strategies.append(("Extreme Correction", correction))
        elif market_prob < 0.2:
            correction = (0.2 - market_prob) * 0.4  # 40% correction for <20%
            strategies.append(("Extreme Correction", correction))
        
        # Strategy 3: Market-type specific edges
        if any(word in q for word in ['temperature', 'weather']):
            # Weather markets: forecasts are good but can have small errors
            weather_edge = abs(0.5 - market_prob) * 0.2  # 20% of distance
            if weather_edge > 0:
                strategies.append(("Weather Model", weather_edge))
        
        elif any(word in q for word in ['bitcoin', 'solana', 'xrp', 'crypto']):
            # Crypto: higher volatility, potential for larger edges
            crypto_edge = abs(0.5 - market_prob) * 0.4  # 40% of distance
            if crypto_edge > 0:
                strategies.append(("Crypto Volatility", crypto_edge))
        
        elif any(word in q for word in ['lol', 'esports', 'rainbow', 'siege']):
            # Esports: can have informational edges
            esports_edge = abs(0.5 - market_prob) * 0.35  # 35% of distance
            if esports_edge > 0:
                strategies.append(("Esports Info", esports_edge))
        
        # Strategy 4: Time-based edge (if we have expiry)
        # Markets closer to expiry have less time for mean reversion
        
        return strategies
    
    def calculate_optimal_trade(self, market_prob: float, strategies: List[Tuple[str, float]], 
                               question: str) -> Optional[Dict]:
        """
        Calculate optimal trade based on strategies.
        """
        if not strategies:
            return None
            
        # Use the maximum edge from all strategies
        max_edge = max(edge for _, edge in strategies)
        best_strategy = next(name for name, edge in strategies if edge == max_edge)
        
        if max_edge < self.min_edge:
            return None
            
        # Determine trade direction
        if market_prob < 0.5:
            outcome = "YES"
            trade_prob = market_prob
            # Edge is for YES side (market underrating YES)
            effective_edge = max_edge
        else:
            outcome = "NO"
            trade_prob = 1 - market_prob
            # Edge is for NO side (market underrating NO)
            effective_edge = max_edge
        
        # Position sizing with convexity consideration
        # Base position: $20 / trade_prob
        base_shares = self.max_position_usd / trade_prob if trade_prob > 0 else 0
        
        # Adjust for edge strength (square root scaling)
        edge_scaling = math.sqrt(min(max_edge / 0.3, 1.0))  # Cap at 30% edge
        shares = base_shares * edge_scaling * 0.7  # 70% of theoretical max
        
        # Convexity cost (simplified)
        # Higher cost for larger positions and more extreme probabilities
        convexity_factor = 0.15 + 0.25 * abs(trade_prob - 0.5) * 2  # 15-40%
        convexity_cost = effective_edge * convexity_factor
        
        # Net edge after convexity
        net_edge = effective_edge - convexity_cost
        
        if net_edge <= 0:
            return None
            
        # Expected value
        ev_usd = net_edge * shares * 100  # Convert to USD
        
        # Minimum EV requirement
        if ev_usd < 1.0:  # At least $1 expected value
            return None
            
        return {
            'market_prob': market_prob,
            'edge': max_edge,
            'net_edge': net_edge,
            'strategy': best_strategy,
            'outcome': outcome,
            'shares': shares,
            'cost': shares * trade_prob,
            'ev': ev_usd,
            'convexity_cost_pct': convexity_factor * 100
        }
    
    def scan_markets(self, client: SimmerClient) -> List[Dict]:
        """Scan all markets for opportunities."""
        current_time = datetime.now(timezone.utc)
        
        print("Scanning active markets...")
        markets = client.get_markets(limit=150, status='active')
        
        opportunities = []
        
        for market in markets:
            # Skip if no probability
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            p = market.current_probability
            
            # Skip extremes (likely resolved)
            if p > 0.98 or p < 0.02:
                continue
                
            # Skip if expiring soon (<2 hours)
            if hasattr(market, 'expires_at') and market.expires_at:
                time_to_expiry = (market.expires_at - current_time).total_seconds()
                if time_to_expiry < 7200:
                    continue
            
            question = market.question if hasattr(market, 'question') else ""
            
            # Calculate edge strategies
            strategies = self.calculate_edge_strategies(p, question)
            
            # Calculate optimal trade
            trade = self.calculate_optimal_trade(p, strategies, question)
            
            if trade:
                opportunities.append({
                    'id': market.id,
                    'question': (question[:60] + "...") if len(question) > 60 else question,
                    'market_type': self.classify_market(question),
                    'trade': trade,
                    'expiry': market.expires_at if hasattr(market, 'expires_at') else None
                })
        
        # Sort by net edge (after convexity)
        opportunities.sort(key=lambda x: x['trade']['net_edge'], reverse=True)
        
        return opportunities[:5]  # Return top 5
    
    def classify_market(self, question: str) -> str:
        """Classify market type."""
        q = question.lower()
        
        if any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return "Weather"
        elif any(word in q for word in ['bitcoin', 'solana', 'xrp', 'ethereum', 'crypto']):
            return "Crypto"
        elif any(word in q for word in ['lol', 'league', 'esports', 'rainbow', 'siege']):
            return "Esports"
        elif any(word in q for word in ['spread', 'nba', 'nfl', 'soccer', 'football']):
            return "Sports"
        elif any(word in q for word in ['election', 'politic', 'ukraine', 'starmer']):
            return "Politics"
        else:
            return "Other"


def generate_report(opportunities: List[Dict]) -> str:
    """Generate comprehensive report."""
    current_time = datetime.now(timezone.utc)
    local_time = datetime.now()
    
    report_lines = []
    
    report_lines.append("=" * 80)
    report_lines.append("LMSR COMPREHENSIVE DRY-RUN SCAN REPORT")
    report_lines.append("=" * 80)
    report_lines.append(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    report_lines.append(f"Local Time: {local_time.strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    report_lines.append(f"Minimum Edge: 15% | Max Position: $20.00")
    report_lines.append("")
    
    if not opportunities:
        report_lines.append("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        report_lines.append("")
        report_lines.append("MARKET ANALYSIS:")
        report_lines.append("• Current market conditions appear efficiently priced")
        report_lines.append("• No markets meet the 15% minimum edge requirement")
        report_lines.append("• This is common during stable market periods")
        report_lines.append("")
        report_lines.append("RECOMMENDATIONS:")
        report_lines.append("1. Wait for more volatile market conditions")
        report_lines.append("2. Consider lowering edge requirement to 10%")
        report_lines.append("3. Focus on specific market types (Crypto, Esports)")
        report_lines.append("4. Check during major news events or market openings")
    else:
        report_lines.append(f"✅ FOUND {len(opportunities)} ACTIONABLE OPPORTUNITIES")
        report_lines.append("")
        report_lines.append("TOP OPPORTUNITIES (Sorted by Net Edge After Convexity):")
        report_lines.append("-" * 80)
        
        total_cost = 0
        total_ev = 0
        
        for i, opp in enumerate(opportunities, 1):
            trade = opp['trade']
            
            report_lines.append(f"\n{i}. {opp['question']}")
            report_lines.append(f"   Type: {opp['market_type']}")
            report_lines.append(f"   Market Probability: {trade['market_prob']:.1%}")
            report_lines.append(f"   Strategy: {trade['strategy']}")
            report_lines.append(f"   Gross Edge: {trade['edge']:.1%}")
            report_lines.append(f"   Convexity Cost: {trade['convexity_cost_pct']:.1f}%")
            report_lines.append(f"   Net Edge: {trade['net_edge']:.1%}")
            report_lines.append(f"   Action: BUY {trade['outcome']}")
            report_lines.append(f"   Shares: {trade['shares']:.1f}")
            report_lines.append(f"   Cost: ${trade['cost']:.2f}")
            report_lines.append(f"   Expected EV: ${trade['ev']:.2f}")
            
            if opp.get('expiry'):
                expiry_str = opp['expiry'].strftime('%Y-%m-%d %H:%M UTC')
                time_to_expiry = (opp['expiry'] - current_time).total_seconds() / 3600
                report_lines.append(f"   Expires: {expiry_str} ({time_to_expiry:.1f} hours)")
            
            total_cost += trade['cost']
            total_ev += trade['ev']
        
        report_lines.append("\n" + "=" * 80)
        report_lines.append("PORTFOLIO ANALYSIS")
        report_lines.append("=" * 80)
        report_lines.append(f"Total Opportunities: {len(opportunities)}")
        report_lines.append(f"Total Investment Required: ${total_cost:.2f}")
        report_lines.append(f"Total Expected Value: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            report_lines.append(f"Expected ROI: {roi:.1f}%")
            report_lines.append(f"Expected Return per Dollar: ${total_ev/total_cost:.2f}")
        
        # Risk metrics
        avg_net_edge = sum(o['trade']['net_edge'] for o in opportunities) / len(opportunities)
        max_net_edge = max(o['trade']['net_edge'] for o in opportunities)
        min_net_edge = min(o['trade']['net_edge'] for o in opportunities)
        
        report_lines.append(f"\nRISK METRICS:")
        report_lines.append(f"  Average Net Edge: {avg_net_edge:.1%}")
        report_lines.append(f"  Maximum Net Edge: {max_net_edge:.1%}")
        report_lines.append(f"  Minimum Net Edge: {min_net_edge:.1%}")
        report_lines.append(f"  Position Concentration: ${max(o['trade']['cost'] for o in opportunities):.2f} max")
        
        # Market type distribution
        type_counts = {}
        for opp in opportunities:
            t = opp['market_type']
            type_counts[t] = type_counts.get(t, 0) + 1
        
        report_lines.append(f"\nOPPORTUNITY DISTRIBUTION:")
        for t, count in sorted(type_counts.items()):
            report_lines.append(f"  {t}: {count} opportunities")
        
        report_lines.append(f"\nCONVEXITY ANALYSIS:")
        report_lines.append(f"  • All calculations include LMSR convexity costs")
        report_lines.append(f"  • Costs range from 15-40% of gross edge")
        report_lines.append(f"  • Net edge = Gross edge - Convexity cost")
        report_lines.append(f"  • Higher costs for extreme probabilities & larger positions")
        
        report_lines.append(f"\nTRADING RECOMMENDATIONS:")
        if len(opportunities) >= 3:
            report_lines.append("1. Consider trading all opportunities for diversification")
            report_lines.append("2. Start with smaller positions to test strategy")
            report_lines.append("3. Monitor convexity impact during execution")
        else:
            report_lines.append("1. Limited opportunities - consider waiting for more")
            report_lines.append("2. Focus on highest edge opportunities only")
            report_lines.append("3. Be prepared for potential model error")
    
    report_lines.append("\n" + "=" * 80)
    report_lines.append("DRY-RUN STATUS: COMPLETE")
    report_lines.append("No actual trades were executed.")
    report_lines.append("Live trading requires:")
    report_lines.append("1. Setting dry_run=False in trading script")
    report_lines.append("2. Sufficient SIM balance in wallet")
    report_lines.append("3. Proper risk management controls")
    report_lines.append("=" * 80)
    
    return "\n".join(report_lines)


def main():
    """Main execution."""
    
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    try:
        client = SimmerClient(api_key=api_key)
        print("✅ Simmer client initialized successfully")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    
    scanner = ComprehensiveLMSRScanner()
    
    print("Running comprehensive LMSR scan...")
    opportunities = scanner.scan_markets(client)
    
    report = generate_report(opportunities)
    print("\n" + report)
    
    # Also save report to file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"lmsr_scan_report_{timestamp}.txt"
    with open(filename, 'w') as f:
        f.write(report)
    
    print(f"\nReport saved to: {filename}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())