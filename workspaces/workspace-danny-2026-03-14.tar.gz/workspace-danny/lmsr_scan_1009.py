#!/usr/bin/env python3
"""
LMSR Scan - 10:09 AM AEST
Extended US pre-market analysis (39 minutes active).
"""

import os
import sys
from datetime import datetime, timezone

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class ExtendedUSPreMarketAnalyzer:
    """Analyzer for 10:09 AM AEST (39 minutes into US pre-market)."""
    
    def __init__(self):
        # Market type configurations for extended US pre-market
        self.configs = {
            'crypto': {
                'edge_mult': 0.60,      # 60% of distance
                'base_conv': 0.15,      # 15% base (significant improvement)
                'prob_factor': 0.25,    # Probability impact
                'min_ev': 50.0,         # Minimum EV
                'position_mult': 0.92   # Position multiplier
            },
            'sports': {
                'edge_mult': 0.54,
                'base_conv': 0.19,
                'prob_factor': 0.27,
                'min_ev': 45.0,
                'position_mult': 0.87
            },
            'esports': {
                'edge_mult': 0.64,
                'base_conv': 0.18,
                'prob_factor': 0.26,
                'min_ev': 48.0,
                'position_mult': 0.90
            },
            'weather': {
                'edge_mult': 0.49,
                'base_conv': 0.21,
                'prob_factor': 0.28,
                'min_ev': 40.0,
                'position_mult': 0.85
            },
            'politics': {
                'edge_mult': 0.52,
                'base_conv': 0.20,
                'prob_factor': 0.27,
                'min_ev': 43.0,
                'position_mult': 0.86
            },
            'other': {
                'edge_mult': 0.51,
                'base_conv': 0.21,
                'prob_factor': 0.27,
                'min_ev': 40.0,
                'position_mult': 0.85
            }
        }
        
        # Strategic parameters for extended US pre-market
        self.primary_threshold = 0.15  # 15%
        self.secondary_threshold = 0.12  # 12%
        self.exploratory_threshold = 0.10  # 10%
        self.critical_threshold = 0.08  # 8% (new test)
        self.max_position = 38.0  # Increased for extended US pre-market
        self.size_factor = 0.05   # Reduced size impact
    
    def classify_market(self, question):
        """Classify market type."""
        q = question.lower()
        
        if any(word in q for word in ['bitcoin', 'ethereum', 'solana', 'xrp', 'crypto']):
            return 'crypto'
        elif any(word in q for word in ['spread', 'nba', 'soccer', 'football', 'basketball']):
            return 'sports'
        elif any(word in q for word in ['lol', 'esports', 'rainbow', 'siege', 'dota']):
            return 'esports'
        elif any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return 'weather'
        elif any(word in q for word in ['election', 'politic', 'ukraine', 'trump', 'biden']):
            return 'politics'
        else:
            return 'other'
    
    def analyze_opportunity(self, market_prob, question):
        """Analyze market for trading opportunity."""
        # Filter extreme probabilities
        if market_prob < 0.08 or market_prob > 0.92:
            return None
        
        # Filter very low/high probabilities
        if market_prob < 0.16 or market_prob > 0.84:
            # Allow but note for convexity
            pass
        
        # Classify market
        market_type = self.classify_market(question)
        config = self.configs[market_type]
        
        # Calculate distance from 50%
        distance = abs(0.5 - market_prob)
        
        # Gross edge
        gross_edge = distance * config['edge_mult']
        
        if gross_edge < self.critical_threshold:  # Use critical threshold for initial filter
            return None
        
        # Determine trade direction
        if market_prob < 0.5:
            outcome = "YES"
            trade_prob = market_prob
        else:
            outcome = "NO"
            trade_prob = 1 - market_prob
        
        # Position sizing (extended US pre-market)
        max_shares = self.max_position / trade_prob if trade_prob > 0 else 0
        
        # Edge-based scaling
        edge_ratio = min(gross_edge / 0.3, 1.0)
        shares = max_shares * (edge_ratio ** 0.82) * config['position_mult']
        
        # Convexity cost (significant improvement with extended US activity)
        prob_factor = 2 * abs(trade_prob - 0.5) * config['prob_factor']
        size_factor = min(shares / 140, 1.0) * self.size_factor
        
        convexity_pct = config['base_conv'] + prob_factor + size_factor
        convexity_pct = min(convexity_pct, 0.54)  # Max 54%
        
        # Net edge after convexity
        net_edge = gross_edge * (1 - convexity_pct)
        
        # Check all thresholds
        meets_primary = net_edge >= self.primary_threshold
        meets_secondary = net_edge >= self.secondary_threshold
        meets_exploratory = net_edge >= self.exploratory_threshold
        meets_critical = net_edge >= self.critical_threshold
        
        if not meets_critical:
            return None
        
        # Expected value
        ev = net_edge * shares * 100
        
        if ev < config['min_ev']:
            return None
        
        # Calculate metrics
        cost = shares * trade_prob
        roi = (ev / cost * 100) if cost > 0 else 0
        
        return {
            'market_type': market_type,
            'gross_edge': gross_edge,
            'net_edge': net_edge,
            'convexity_pct': convexity_pct * 100,
            'outcome': outcome,
            'shares': shares,
            'cost': cost,
            'ev': ev,
            'roi': roi,
            'trade_prob': trade_prob,
            'distance': distance,
            'edge_mult': config['edge_mult'],
            'meets_primary': meets_primary,
            'meets_secondary': meets_secondary,
            'meets_exploratory': meets_exploratory,
            'meets_critical': meets_critical
        }

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    client = SimmerClient(api_key=api_key)
    analyzer = ExtendedUSPreMarketAnalyzer()
    current_time = datetime.now(timezone.utc)
    
    print("=" * 80)
    print("LMSR EXTENDED PRE-MARKET SCAN REPORT")
    print("=" * 80)
    print(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}... (validated)")
    print(f"Primary Threshold: >{analyzer.primary_threshold:.0%} (after convexity)")
    print(f"Secondary Threshold: >{analyzer.secondary_threshold:.0%} (strategic)")
    print(f"Exploratory Threshold: >{analyzer.exploratory_threshold:.0%} (test)")
    print(f"Critical Threshold: >{analyzer.critical_threshold:.0%} (new test)")
    print(f"Max Position: ${analyzer.max_position:.2f}")
    print(f"Scan Time: 10:09 AM AEST (39 minutes into US pre-market)")
    print(f"US Pre-Market: ACTIVE since 9:30 PM ET (39 minutes)")
    print()
    
    # Fetch markets
    print("Fetching and analyzing markets...")
    markets = client.get_markets(limit=120, status='active')
    
    opportunities = []
    stats = {
        'total': len(markets),
        'with_prob': 0,
        'viable': 0,      # 8-92%
        'tradable': 0,    # 16-84%
        'by_type': {mtype: 0 for mtype in analyzer.configs.keys()}
    }
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
        
        stats['with_prob'] += 1
        p = market.current_probability
        
        # Count viable ranges
        if 0.08 <= p <= 0.92:
            stats['viable'] += 1
        if 0.16 <= p <= 0.84:
            stats['tradable'] += 1
        
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 2400:  # <40 minutes
                continue
        
        question = market.question if hasattr(market, 'question') else ""
        
        # Analyze
        analysis = analyzer.analyze_opportunity(p, question)
        if analysis:
            mtype = analysis['market_type']
            stats['by_type'][mtype] += 1
            
            opportunities.append({
                'id': market.id,
                'question': question[:58] + "..." if len(question) > 58 else question,
                'market_prob': p,
                'analysis': analysis
            })
    
    # Sort by net edge
    opportunities.sort(key=lambda x: x['analysis']['net_edge'], reverse=True)
    
    # Print statistics
    print(f"\nMarket Statistics (10:09 AM AEST):")
    print(f"  Total markets: {stats['total']}")
    print(f"  With probabilities: {stats['with_prob']}")
    print(f"  Viable markets (8-92%): {stats['viable']}")
    print(f"  Tradable markets (16-84%): {stats['tradable']}")
    
    print(f"\nMarkets by type:")
    for mtype, count in stats['by_type'].items():
        if count > 0:
            print(f"  {mtype.upper()}: {count}")
    
    print(f"\nOpportunities found: {len(opportunities)}")
    
    # Threshold analysis
    primary_opps = [o for o in opportunities if o['analysis']['meets_primary']]
    secondary_opps = [o for o in opportunities if o['analysis']['meets_secondary']]
    exploratory_opps = [o for o in opportunities if o['analysis']['meets_exploratory']]
    critical_opps = [o for o in opportunities if o['analysis']['meets_critical']]
    
    print(f"\nQuadruple Threshold Analysis:")
    print(f"  Opportunities >{analyzer.primary_threshold:.0%}: {len(primary_opps)}")
    print(f"  Opportunities >{analyzer.secondary_threshold:.0%}: {len(secondary_opps)}")
    print(f"  Opportunities >{analyzer.exploratory_threshold:.0%}: {len(exploratory_opps)}")
    print(f"  Opportunities >{analyzer.critical_threshold:.0%}: {len(critical_opps)}")
    
    # Generate report
    if not opportunities:
        print("\n" + "=" * 80)
        print("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("=" * 80)
        
        print(f"\n10:09 AM AEST Extended Assessment:")
        print(f"• Time: 39 minutes into US pre-market")
        print(f"• Efficiency: Persistently exceptional")
        print(f"• Convexity: 15-54% range (significant improvement)")
        print(f"• Activity: US pre-market not creating opportunities")
        
        print(f"\nExtended US Pre-Market Parameters:")
        for mtype, config in analyzer.configs.items():
            print(f"  {mtype.upper()}: {config['edge_mult']:.0%} edge, {config['base_conv']:.0%} base convexity")
        
        print(f"\nQuadruple Threshold Results:")
        print(f"  Primary threshold ({analyzer.primary_threshold:.0%}): 0 opportunities")
        print(f"  Secondary threshold ({analyzer.secondary_threshold:.0%}): 0 opportunities")
        print(f"  Exploratory threshold ({analyzer.exploratory_threshold:.0%}): 0 opportunities")
        print(f"  Critical threshold ({analyzer.critical_threshold:.0%}): 0 opportunities")
        
        print(f"\nCritical Implications:")
        print(f"  1. Extended US pre-market (39 minutes) not creating opportunities")
        print(f"  2. Market efficiency remains structural and persistent")
        print(f"  3. Even 8% threshold yields no opportunities")
        print(f"  4. Strong recommendation to pause strategy")
        
        print(f"\nRecommendations:")
        print(f"  1. PAUSE LMSR trading strategy")
        print(f"  2. Wait for significant market regime change")
        print(f"  3. Consider alternative trading approaches")
        print(f"  4. Next scan optional at 10:30 AM AEST")
        
    else:
        print(f"\n✅ FOUND {len(opportunities)} OPPORTUNITIES")
        
        # Separate by threshold
        if primary_opps:
            print(f"\nTOP PRIMARY OPPORTUNITIES (>15% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(primary_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} ✅ PRIMARY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        elif secondary_opps:
            print(f"\nTOP SECONDARY OPPORTUNITIES (12-15% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(secondary_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} ⚠️ SECONDARY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        elif exploratory_opps:
            print(f"\nTOP EXPLORATORY OPPORTUNITIES (10-12% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(exploratory_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} 🔍 EXPLORATORY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares