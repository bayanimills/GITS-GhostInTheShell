#!/usr/bin/env python3
"""
LMSR Scan - 7:05 AM AEST
Morning scan with improved filtering for viable markets.
"""

import os
import sys
from datetime import datetime, timezone

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

def analyze_market_opportunity(market_prob, question, current_time):
    """
    Analyze a market for viable trading opportunities.
    Returns detailed analysis or None if not viable.
    """
    # Filter out extreme probabilities (likely resolved)
    if market_prob < 0.05 or market_prob > 0.95:
        return None
    
    # Filter out very low probabilities (high convexity)
    if market_prob < 0.08 or market_prob > 0.92:
        # Allow but with higher convexity costs
        pass
    
    # Classify market type
    q_lower = question.lower()
    
    if any(word in q_lower for word in ['bitcoin', 'ethereum', 'solana', 'xrp', 'crypto']):
        market_type = "Crypto"
        edge_multiplier = 0.53  # 53% of distance
        base_convexity = 0.21   # 21% base
        min_ev = 20.0
    elif any(word in q_lower for word in ['lol', 'esports', 'rainbow', 'siege', 'dota']):
        market_type = "Esports"
        edge_multiplier = 0.57
        base_convexity = 0.24
        min_ev = 18.0
    elif any(word in q_lower for word in ['spread', 'nba', 'soccer', 'football', 'basketball']):
        market_type = "Sports"
        edge_multiplier = 0.47
        base_convexity = 0.25
        min_ev = 15.0
    elif any(word in q_lower for word in ['temperature', 'weather', '°c', '°f']):
        market_type = "Weather"
        edge_multiplier = 0.42
        base_convexity = 0.27
        min_ev = 12.0
    elif any(word in q_lower for word in ['election', 'politic', 'ukraine', 'trump', 'biden']):
        market_type = "Politics"
        edge_multiplier = 0.45
        base_convexity = 0.26
        min_ev = 15.0
    else:
        market_type = "Other"
        edge_multiplier = 0.44
        base_convexity = 0.27
        min_ev = 12.0
    
    # Calculate distance from 50%
    distance = abs(0.5 - market_prob)
    
    # Gross edge
    gross_edge = distance * edge_multiplier
    
    # Minimum edge check (15% gross as starting point)
    if gross_edge < 0.15:
        return None
    
    # Determine trade direction
    if market_prob < 0.5:
        outcome = "YES"
        trade_prob = market_prob
    else:
        outcome = "NO"
        trade_prob = 1 - market_prob
    
    # Position sizing (7:05 AM parameters)
    max_position_usd = 26.0  # Increased for morning scan
    max_shares = max_position_usd / trade_prob if trade_prob > 0 else 0
    
    # Conservative scaling based on edge strength
    edge_ratio = min(gross_edge / 0.3, 1.0)
    shares = max_shares * (edge_ratio ** 0.68) * 0.75  # 75% of scaled max
    
    # Convexity cost calculation (morning adjustments)
    prob_factor = 2 * abs(trade_prob - 0.5) * 0.31  # Probability impact
    size_factor = min(shares / 85, 1.0) * 0.11  # Size impact
    
    convexity_pct = base_convexity + prob_factor + size_factor
    convexity_pct = min(convexity_pct, 0.66)  # Max 66% cost
    
    # Net edge after convexity
    net_edge = gross_edge * (1 - convexity_pct)
    
    # Final edge check (15% minimum)
    if net_edge < 0.15:
        return None
    
    # Expected value
    ev_usd = net_edge * shares * 100  # $1 per share
    
    # Minimum EV requirement
    if ev_usd < min_ev:
        return None
    
    # Calculate position metrics
    cost_usd = shares * trade_prob
    roi_pct = (ev_usd / cost_usd * 100) if cost_usd > 0 else 0
    
    return {
        'market_type': market_type,
        'gross_edge': gross_edge,
        'net_edge': net_edge,
        'convexity_pct': convexity_pct * 100,
        'outcome': outcome,
        'shares': shares,
        'cost': cost_usd,
        'ev': ev_usd,
        'roi': roi_pct,
        'trade_prob': trade_prob,
        'edge_mult': edge_multiplier,
        'distance': distance
    }

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    client = SimmerClient(api_key=api_key)
    current_time = datetime.now(timezone.utc)
    
    print("=" * 80)
    print("LMSR DRY-RUN SCAN REPORT")
    print("=" * 80)
    print(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}... (validated)")
    print(f"Minimum Edge: >15% (after convexity costs)")
    print(f"Max Position: $26.00")
    print(f"Scan Time: 7:05 AM AEST (morning market open)")
    print()
    
    # Fetch markets
    print("Fetching and analyzing markets...")
    markets = client.get_markets(limit=120, status='active')
    
    opportunities = []
    market_stats = {
        'total': len(markets),
        'with_prob': 0,
        'viable_range': 0,  # 5-95%
        'tradable_range': 0,  # 8-92% (better convexity)
        'expiring_soon': 0
    }
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
        
        market_stats['with_prob'] += 1
        p = market.current_probability
        
        # Count viable ranges
        if 0.05 <= p <= 0.95:
            market_stats['viable_range'] += 1
        if 0.08 <= p <= 0.92:
            market_stats['tradable_range'] += 1
        
        # Check expiry (more lenient for morning)
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 4800:  # <1.33 hours
                market_stats['expiring_soon'] += 1
                continue
        
        question = market.question if hasattr(market, 'question') else ""
        
        # Analyze market
        analysis = analyze_market_opportunity(p, question, current_time)
        if analysis:
            opportunities.append({
                'id': market.id,
                'question': question[:72] + "..." if len(question) > 72 else question,
                'market_prob': p,
                'analysis': analysis
            })
    
    # Sort by net edge
    opportunities.sort(key=lambda x: x['analysis']['net_edge'], reverse=True)
    
    # Print statistics
    print(f"\nMarket Statistics (7:05 AM AEST):")
    print(f"  Total markets: {market_stats['total']}")
    print(f"  With probabilities: {market_stats['with_prob']}")
    print(f"  Viable range (5-95%): {market_stats['viable_range']}")
    print(f"  Tradable range (8-92%): {market_stats['tradable_range']}")
    print(f"  Expiring soon (<1.33h): {market_stats['expiring_soon']}")
    print(f"  Opportunities found: {len(opportunities)}")
    
    # Generate report
    if not opportunities:
        print("\n" + "=" * 80)
        print("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("=" * 80)
        
        print("\n7:05 AM AEST Market Analysis:")
        print("• Time: Morning, Asian markets active")
        print("• Efficiency: Still high from overnight")
        print("• Convexity: 21-66% range (type-dependent)")
        print("• Activity: Increasing but not yet optimal")
        
        print("\nMarket Type Edge Multipliers:")
        print("  Crypto: 53% of distance from 50%")
        print("  Esports: 57% of distance from 50%")
        print("  Sports: 47% of distance from 50%")
        print("  Weather: 42% of distance from 50%")
        print("  Politics: 45% of distance from 50%")
        print("  Other: 44% of distance from 50%")
        
        print("\nConvexity Base Costs (7:05 AM):")
        print("  Crypto: 21% base (lower for 24/7 markets)")
        print("  Esports: 24% base")
        print("  Sports: 25% base")
        print("  Weather: 27% base (higher uncertainty)")
        print("  Politics: 26% base")
        print("  Other: 27% base")
        
        print("\nMorning Trading Recommendations:")
        print("  1. Wait for European market close (8:00 AM AEST)")
        print("  2. Focus on Crypto markets (most active overnight)")
        print("  3. Consider 12% edge threshold for morning scans")
        print("  4. Next optimal scan: 8:00 AM AEST")
        
    else:
        print(f"\n✅ FOUND {len(opportunities)} OPPORTUNITIES")
        print("\nTOP 5 OPPORTUNITIES (Sorted by Net Edge):")
        print("-" * 80)
        
        total_ev = 0
        total_cost = 0
        net_edges = []
        
        for i, opp in enumerate(opportunities[:5], 1):
            analysis = opp['analysis']
            
            print(f"\n{i}. {opp['question']}")
            print(f"   Type: {analysis['market_type'].upper()}")
            print(f"   Market Probability: {opp['market_prob']:.1%}")
            print(f"   Distance from 50%: {analysis['distance']:.1%}")
            print(f"   Edge Model: {analysis['edge_mult']:.0%} of distance")
            print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
            print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
            print(f"   Net Edge: {analysis['net_edge']:.1%} ✅")
            print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
            print(f"   Shares: {analysis['shares']:.1f}")
            print(f"   Position Cost: ${analysis['cost']:.2f}")
            print(f"   Expected EV: ${analysis['ev']:.2f}")
            print(f"   Expected ROI: {analysis['roi']:.1f}%")
            
            total_ev += analysis['ev']
            total_cost += analysis['cost']
            net_edges.append(analysis['net_edge'])
        
        print("\n" + "=" * 80)
        print("PORTFOLIO SUMMARY")
        print("=" * 80)
        print(f"Total Opportunities: {min(5, len(opportunities))}")
        print(f"Total Investment: ${total_cost:.2f}")
        print(f"Total Expected EV: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            print(f"Portfolio ROI: {roi:.1f}%")
            print(f"Return per Dollar: ${total_ev/total_cost:.2f}")
        
        # Detailed analysis
        avg_edge = sum(net_edges) / len(net_edges)
        max_edge = max(net_edges)
        min_edge = min(net_edges)
        
        print(f"\nDETAILED ANALYSIS:")
        print(f"  Average Net Edge: {avg_edge:.1%}")
        print(f"  Maximum Net Edge: {max_edge:.1%}")
        print(f"  Minimum Net Edge: {min_edge:.1%}")
        print(f"  Edge Range: {min_edge:.1%} - {max_edge:.1%}")
        
        # Market type distribution
        opp_types = {}
        for opp in opportunities[:5]:
            mtype = opp['analysis']['market_type']
            opp_types[mtype] = opp_types.get(mtype, 0) + 1
        
        print(f"\nOPPORTUNITY DISTRIBUTION:")
        for mtype, count in sorted(opp_types.items()):
            print(f"  {mtype.upper()}: {count}")
        
        print(f"\n7:05 AM AEST TIME ANALYSIS:")
        print(f"  • Morning market conditions")
        print(f"  • Asian markets fully open")
        print(f"  • European markets closing soon")
        print(f"  • US markets closed for 10+ hours")
        
        print(f"\nTRADING RECOMMENDATION:")
        if len(opportunities) >= 4 and avg_edge > 0.18:
            print("  ✅ STRONG OPPORTUNITIES - Consider trading")
            print("  ⚠️  Start with 80% of calculated positions")
            print("  📊 Monitor Asian market influence")
        elif len(opportunities) >= 3 and avg_edge > 0.16:
            print("  ⚠️  MODERATE OPPORTUNITIES - Trade cautiously")
            print("  🔍 Consider top 3 opportunities only")
            print("  💰 Use 70% position sizes")
        else:
            print("  ⚠️  LIMITED OPPORTUNITIES - Consider waiting")
            print("  🔄 Wait for European market close (8:00 AM)")
            print("  📈 Monitor for improving conditions")
    
    print("\n" + "=" * 80)
    print("DRY-RUN STATUS: COMPLETE")
    print("No trades were executed.")
    print("=" * 80)
    
    # Save report
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    with open(f"lmsr_0705_report_{timestamp}.txt", 'w') as f:
        f.write(f"LMSR Scan Report - 7:05 AM AEST\n")
        f.write(f"Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')}\n")
        f.write("="*60 + "\n")
        
        if opportunities:
            f.write(f"\nFound {len(opportunities)} opportunities:\n")
            for i, opp in enumerate(opportunities[:5], 1):
                analysis = opp['analysis']
                f.write(f"\n{i}. {opp['question']}\n")
                f.write(f"   Market: {opp['market_prob']:.1%} | Net Edge: {analysis['net_edge']:.1%}\n")
                f.write(f"   Action: BUY {analysis['outcome']} | Cost: ${analysis['cost']:.2f}\n")
                f.write(f"   EV: ${analysis['ev']:.2f} | ROI: {analysis['roi']:.1f}%\n")
        else:
            f.write("\nNo opportunities meeting 15% edge requirement.\n")
    
    print(f"\nDetailed report saved to: lmsr_0705_report_{timestamp}.txt")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())