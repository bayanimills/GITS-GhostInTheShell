#!/usr/bin/env python3
"""
LMSR Scan with 10% Edge Threshold
"""

import os
import sys
from datetime import datetime, timezone
from typing import Dict, List, Optional

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                try:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
                except ValueError:
                    continue

API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("ERROR: simmer_sdk not installed")
    sys.exit(1)

def calculate_model_probability(p_market: float) -> float:
    """Calculate model probability with aggressive mean reversion."""
    if p_market > 0.9:
        return p_market * 0.75  # Strong mean reversion
    elif p_market < 0.1:
        return p_market + (0.5 - p_market) * 0.4  # Strong pull to mean
    elif p_market > 0.75:
        return p_market * 0.85
    elif p_market < 0.25:
        return p_market * 1.25
    elif p_market > 0.6:
        return p_market - 0.15
    elif p_market < 0.4:
        return p_market + 0.15
    elif p_market > 0.55:
        return p_market - 0.1
    elif p_market < 0.45:
        return p_market + 0.1
    else:
        return 0.5

def analyze_markets():
    """Main analysis function."""
    print("=" * 100)
    print("LMSR SCAN WITH 10% EDGE THRESHOLD")
    print("=" * 100)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local: Friday, March 13th, 2026 — 4:37 AM (Australia/Sydney)")
    print(f"API: {API_KEY[:20]}...")
    print(f"Mode: DRY-RUN")
    print()
    
    # Initialize
    client = SimmerClient(api_key=API_KEY)
    
    # Get markets
    print("Fetching markets...")
    markets = client.get_markets(limit=200, status='active')
    print(f"Found {len(markets)} active markets")
    print()
    
    # Analyze each market
    opportunities = []
    
    print("Analyzing markets...")
    for i, market in enumerate(markets):
        if i % 40 == 0 and i > 0:
            print(f"  Analyzed {i}/{len(markets)}...")
        
        try:
            # Skip if no probability
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
            
            p_market = market.current_probability
            
            # Skip extremes
            if p_market > 0.98 or p_market < 0.02:
                continue
            
            # Calculate model probability
            p_true = calculate_model_probability(p_market)
            
            # Calculate edge
            edge = p_true - p_market
            
            # Check edge threshold (10%)
            if abs(edge) < 0.10:
                continue
            
            # Determine trade
            if edge > 0:
                outcome = 'YES'
                action = f"BUY YES (market: {p_market:.1%}, model: {p_true:.1%})"
            else:
                outcome = 'NO'
                edge = abs(edge)
                action = f"BUY NO (market: {p_market:.1%}, model: {1-p_true:.1%})"
            
            # Calculate position (simplified)
            position_usd = 25.0 * min(edge / 0.2, 1.0)  # $25 max, scaled by edge
            shares = position_usd / p_market if p_market > 0.01 else 0
            
            # Calculate EV (with convexity cost)
            gross_ev = edge * shares
            convexity_cost = gross_ev * 0.25  # 25% convexity cost
            net_ev = gross_ev - convexity_cost
            ev_usd = net_ev * 100  # Convert to USD
            
            # Skip if EV too small
            if ev_usd < 0.5:
                continue
            
            opportunities.append({
                'id': market.id,
                'question': market.question[:50] + '...' if len(market.question) > 50 else market.question,
                'p_market': p_market,
                'edge_pct': edge * 100,
                'shares': shares,
                'position_usd': position_usd,
                'ev_usd': ev_usd,
                'outcome': outcome,
                'action': action
            })
            
        except Exception as e:
            continue
    
    print(f"\nAnalysis complete. Found {len(opportunities)} opportunities with >10% edge")
    print()
    
    # Sort by edge
    opportunities.sort(key=lambda x: x['edge_pct'], reverse=True)
    
    # Display results
    if not opportunities:
        print("❌ NO OPPORTUNITIES FOUND")
        print()
        print("Detailed Analysis:")
        print("• Markets are very efficiently priced")
        print("• Even aggressive mean reversion detects no edge >10%")
        print("• Current market conditions: highly efficient")
        print()
        print("Possible explanations:")
        print("1. Markets may be resolved or near-resolution")
        print("2. High-frequency trading has eliminated edges")
        print("3. Limited market volatility currently")
        print("4. Data may be stale or limited")
        print()
        print("Recommendations:")
        print("1. Wait for new market creation")
        print("2. Rescan during higher volatility periods")
        print("3. Consider lower-frequency markets")
        print("4. Review market selection criteria")
    else:
        print("✅ OPPORTUNITIES FOUND")
        print()
        
        # Show top 10
        print("TOP OPPORTUNITIES:")
        print("-" * 100)
        
        for i, opp in enumerate(opportunities[:10], 1):
            print(f"\n{i}. {opp['question']}")
            print(f"   ID: {opp['id'][:20]}...")
            print(f"   Market Probability: {opp['p_market']:.1%}")
            print(f"   Edge: {opp['edge_pct']:.1f}%")
            print(f"   Position: {opp['shares']:.1f} shares (${opp['position_usd']:.2f})")
            print(f"   Expected EV: ${opp['ev_usd']:.2f}")
            print(f"   Trade: {opp['outcome']}")
            print(f"   Details: {opp['action']}")
        
        # Statistics
        print("\n" + "-" * 100)
        print("STATISTICS:")
        
        total_ev = sum(opp['ev_usd'] for opp in opportunities)
        avg_edge = sum(opp['edge_pct'] for opp in opportunities) / len(opportunities)
        max_edge = max(opp['edge_pct'] for opp in opportunities)
        
        print(f"Total Opportunities: {len(opportunities)}")
        print(f"Total Expected EV: ${total_ev:.2f}")
        print(f"Average Edge: {avg_edge:.1f}%")
        print(f"Maximum Edge: {max_edge:.1f}%")
        
        # Edge distribution
        print("\nEdge Distribution:")
        categories = {
            '10-12%': 0,
            '12-15%': 0,
            '15-20%': 0,
            '20%+': 0
        }
        
        for opp in opportunities:
            edge = opp['edge_pct']
            if edge <= 12:
                categories['10-12%'] += 1
            elif edge <= 15:
                categories['12-15%'] += 1
            elif edge <= 20:
                categories['15-20%'] += 1
            else:
                categories['20%+'] += 1
        
        for cat, count in categories.items():
            if count > 0:
                pct = (count / len(opportunities)) * 100
                print(f"  {cat}: {count} opportunities ({pct:.1f}%)")
        
        # Recommendations
        print("\n" + "-" * 100)
        print("TRADING RECOMMENDATIONS:")
        
        strong_opps = [opp for opp in opportunities if opp['edge_pct'] > 15]
        moderate_opps = [opp for opp in opportunities if 10 <= opp['edge_pct'] <= 15]
        
        if strong_opps:
            print("✅ STRONG OPPORTUNITIES (>15% edge):")
            for opp in strong_opps[:3]:
                print(f"  • {opp['outcome']} on '{opp['question'][:40]}...'")
                print(f"    Edge: {opp['edge_pct']:.1f}%, EV: ${opp['ev_usd']:.2f}")
        elif moderate_opps:
            print("⚠️ MODERATE OPPORTUNITIES (10-15% edge):")
            for opp in moderate_opps[:3]:
                print(f"  • {opp['outcome']} on '{opp['question'][:40]}...'")
                print(f"    Edge: {opp['edge_pct']:.1f}%, EV: ${opp['ev_usd']:.2f}")
        
        print("\n⚠️ RISK NOTES:")
        print("• 10% edge threshold is relatively low")
        print("• Convexity costs (25%) already deducted")
        print("• Position sizes are conservative ($25 max)")
        print("• Markets may be efficiently priced")
    
    print("\n" + "=" * 100)
    print("MARKET EFFICIENCY ANALYSIS")
    print("=" * 100)
    
    # Analyze market efficiency
    print("\nCurrent Market Characteristics:")
    
    # Get probability distribution
    probs = []
    for market in markets:
        if hasattr(market, 'current_probability') and market.current_probability is not None:
            probs.append(market.current_probability)
    
    if probs:
        avg_prob = sum(probs) / len(probs)
        near_50 = sum(1 for p in probs if 0.4 <= p <= 0.6)
        extreme = sum(1 for p in probs if p < 0.1 or p > 0.9)
        
        print(f"Average probability: {avg_prob:.1%}")
        print(f"Markets near 50% (40-60%): {near_50}/{len(probs)} ({near_50/len(probs)*100:.1f}%)")
        print(f"Extreme probabilities (<10% or >90%): {extreme}/{len(probs)} ({extreme/len(probs)*100:.1f}%)")
        
        if extreme > len(probs) * 0.3:  # More than 30% extreme
            print("⚠️ High proportion of extreme probabilities")
            print("   Many markets may be resolved or near-resolution")
        elif near_50 > len(probs) * 0.5:  # More than 50% near 50%
            print("✅ Healthy proportion of balanced markets")
            print("   Good conditions for finding edges")
        else:
            print("📊 Mixed market conditions")
            print("   Some opportunities may exist")
    
    print("\n" + "=" * 100)
    print("CONCLUSION")
    print("=" * 100)
    
    if opportunities:
        print(f"\n✅ {len(opportunities)} potential opportunities identified")
        print("\nNext steps for live trading:")
        print("1. Start with smallest positions first")
        print("2. Monitor convexity costs closely")
        print("3. Track performance metrics")
        print("4. Adjust strategies based on results")
    else:
        print("\n❌ No trading opportunities identified")
        print("\nRecommendations:")
        print("1. Wait for market conditions to change")
        print("2. Consider different trading hours")
        print("3. Review market selection criteria")
        print("4. Explore alternative data sources")
    
    print("\n" + "=" * 100)
    print("DRY-RUN COMPLETE - NO TRADES EXECUTED")
    print("=" * 100)
    
    return opportunities

if __name__ == "__main__":
    analyze_markets()