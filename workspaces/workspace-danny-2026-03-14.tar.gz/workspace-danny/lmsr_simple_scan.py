#!/usr/bin/env python3
"""
Simple LMSR Scanner - Find opportunities with >15% edge
"""

import os
import sys
import math
from datetime import datetime, timezone
from typing import Dict, List, Optional

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                try:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
                except ValueError:
                    continue

API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("ERROR: simmer_sdk not installed")
    sys.exit(1)

class SimpleLMSRScanner:
    """Simple LMSR scanner focusing on >15% edge opportunities."""
    
    def __init__(self):
        self.min_edge = 0.15  # 15% minimum edge
        self.liquidity_param = 100.0
    
    def calculate_edge(self, p_market: float) -> float:
        """Calculate edge using mean reversion strategy."""
        # Strong mean reversion for extreme probabilities
        if p_market > 0.85:
            p_true = p_market * 0.80  # 20% mean reversion
        elif p_market < 0.15:
            p_true = p_market + (0.5 - p_market) * 0.3  # Pull toward mean
        elif p_market > 0.7:
            p_true = p_market * 0.88  # 12% mean reversion
        elif p_market < 0.3:
            p_true = p_market * 1.15  # 15% mean reversion
        elif p_market > 0.55:
            p_true = p_market - 0.08  # 8% correction
        elif p_market < 0.45:
            p_true = p_market + 0.08  # 8% correction
        else:
            p_true = 0.5  # Neutral at 45-55%
        
        return p_true - p_market
    
    def calculate_position(self, edge: float, p_market: float) -> float:
        """Calculate position size based on edge and convexity."""
        if edge <= 0:
            return 0.0
        
        # Base position: $50 max, scaled by edge strength
        base_position = 50.0 * min(abs(edge) / 0.3, 1.0)
        
        # Adjust for convexity (more convexity cost for larger positions)
        convexity_factor = 1.0 - (base_position / 200.0)  # 200 is liquidity estimate
        
        position = base_position * convexity_factor
        
        # Convert to shares
        shares = position / p_market if p_market > 0.01 else 0
        
        return shares
    
    def calculate_ev(self, edge: float, shares: float, p_market: float) -> float:
        """Calculate expected value."""
        if edge <= 0 or shares <= 0:
            return 0.0
        
        # Gross EV
        gross_ev = edge * shares
        
        # Convexity cost (simplified)
        convexity_cost = gross_ev * 0.3  # Assume 30% convexity cost
        
        net_ev = gross_ev - convexity_cost
        
        # Convert to USD
        ev_usd = net_ev * 100
        
        return ev_usd
    
    def analyze_market(self, market) -> Optional[Dict]:
        """Analyze a single market."""
        try:
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                return None
            
            p_market = market.current_probability
            
            # Skip extreme probabilities
            if p_market > 0.95 or p_market < 0.05:
                return None
            
            # Calculate edge
            edge = self.calculate_edge(p_market)
            
            # Check if edge meets threshold
            if abs(edge) < self.min_edge:
                return None
            
            # Determine trade direction
            if edge > 0:
                outcome = 'YES'
            else:
                outcome = 'NO'
                edge = abs(edge)  # Use absolute value
            
            # Calculate position
            shares = self.calculate_position(edge, p_market)
            
            # Skip if position too small
            if shares < 1.0:
                return None
            
            # Calculate EV
            ev_usd = self.calculate_ev(edge, shares, p_market)
            
            # Skip if EV too small
            if ev_usd < 1.0:
                return None
            
            # Position size in USD
            position_usd = shares * p_market
            
            return {
                'market_id': market.id,
                'question': market.question[:60] + '...' if len(market.question) > 60 else market.question,
                'p_market': p_market,
                'edge_pct': edge * 100,
                'shares': shares,
                'position_usd': position_usd,
                'ev_usd': ev_usd,
                'outcome': outcome,
                'category': getattr(market, 'category', 'Unknown')
            }
            
        except Exception as e:
            print(f"Error analyzing market: {e}")
            return None

def main():
    print("=" * 100)
    print("LMSR DRY-RUN SCAN - REAL MARKETS")
    print("=" * 100)
    print(f"Scan Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: Friday, March 13th, 2026 — 4:37 AM (Australia/Sydney)")
    print(f"API Key: {API_KEY[:20]}...")
    print(f"Minimum Edge: 15%")
    print(f"Mode: DRY-RUN ONLY - No trades executed")
    print()
    
    # Initialize
    client = SimmerClient(api_key=API_KEY)
    scanner = SimpleLMSRScanner()
    
    # Fetch markets
    print("Fetching active markets...")
    markets = client.get_markets(limit=150, status='active')
    print(f"Retrieved {len(markets)} active markets")
    print()
    
    # Analyze markets
    print("Analyzing for opportunities with >15% edge...")
    opportunities = []
    
    for i, market in enumerate(markets):
        if i % 30 == 0 and i > 0:
            print(f"  Processed {i}/{len(markets)} markets...")
        
        result = scanner.analyze_market(market)
        if result:
            opportunities.append(result)
    
    print(f"\nFound {len(opportunities)} opportunities with >15% edge")
    print()
    
    # Sort by edge (descending)
    opportunities.sort(key=lambda x: x['edge_pct'], reverse=True)
    
    # Display results
    if not opportunities:
        print("❌ NO OPPORTUNITIES FOUND WITH >15% EDGE")
        print()
        print("Market Analysis:")
        print("• Current markets appear efficiently priced")
        print("• No significant mispricing detected")
        print("• Edge threshold of 15% may be too high for current conditions")
        print()
        print("Recommendations:")
        print("1. Lower edge threshold to 10-12%")
        print("2. Wait for market volatility to increase")
        print("3. Rescan in 1-2 hours")
        print("4. Consider alternative trading strategies")
    else:
        print("✅ OPPORTUNITIES FOUND")
        print()
        
        # Top 5 opportunities
        print("TOP 5 OPPORTUNITIES:")
        print("-" * 100)
        
        for i, opp in enumerate(opportunities[:5], 1):
            print(f"\n{i}. {opp['question']}")
            print(f"   Market ID: {opp['market_id'][:20]}...")
            print(f"   Market Probability: {opp['p_market']:.1%}")
            print(f"   Edge: {opp['edge_pct']:.1f}%")
            print(f"   Position: {opp['shares']:.1f} shares (${opp['position_usd']:.2f})")
            print(f"   Expected EV: ${opp['ev_usd']:.2f}")
            print(f"   Trade: BUY {opp['outcome']}")
            print(f"   Category: {opp['category']}")
        
        # Summary statistics
        print("\n" + "-" * 100)
        print("SUMMARY STATISTICS:")
        print(f"Total Opportunities: {len(opportunities)}")
        
        total_ev = sum(opp['ev_usd'] for opp in opportunities)
        avg_edge = sum(opp['edge_pct'] for opp in opportunities) / len(opportunities)
        total_position = sum(opp['position_usd'] for opp in opportunities)
        
        print(f"Total Expected EV: ${total_ev:.2f}")
        print(f"Average Edge: {avg_edge:.1f}%")
        print(f"Total Position Size: ${total_position:.2f}")
        
        # Edge distribution
        print("\nEdge Distribution:")
        strong = sum(1 for opp in opportunities if opp['edge_pct'] > 20)
        moderate = sum(1 for opp in opportunities if 15 <= opp['edge_pct'] <= 20)
        
        print(f"Strong (>20%): {strong} opportunities")
        print(f"Moderate (15-20%): {moderate} opportunities")
        
        # Recommendations
        print("\n" + "-" * 100)
        print("TRADING RECOMMENDATIONS:")
        
        if strong > 0:
            print("✅ STRONG OPPORTUNITIES AVAILABLE")
            print("   Consider these for potential trading:")
            for opp in [o for o in opportunities if o['edge_pct'] > 20][:2]:
                print(f"   • {opp['outcome']} on '{opp['question'][:40]}...'")
                print(f"     Edge: {opp['edge_pct']:.1f}%, EV: ${opp['ev_usd']:.2f}")
        elif moderate > 0:
            print("⚠️ MODERATE OPPORTUNITIES")
            print("   Consider with caution:")
            for opp in [o for o in opportunities if 15 <= o['edge_pct'] <= 20][:2]:
                print(f"   • {opp['outcome']} on '{opp['question'][:40]}...'")
                print(f"     Edge: {opp['edge_pct']:.1f}%, EV: ${opp['ev_usd']:.2f}")
        
        print("\n⚠️ IMPORTANT NOTES:")
        print("• This is a DRY-RUN - no trades executed")
        print("• Edge calculations are estimates")
        print("• Convexity costs are approximated")
        print("• Real trading requires risk management")
    
    print("\n" + "=" * 100)
    print("LMSR CONVEXITY ANALYSIS")
    print("=" * 100)
    print("\nConvexity Costs Considered:")
    print("• 30% convexity cost applied to gross EV")
    print("• Position sizing accounts for liquidity impact")
    print("• LMSR liquidity parameter: b = 100")
    print("• Trade size limited to minimize slippage")
    
    print("\n" + "=" * 100)
    print("NEXT STEPS")
    print("=" * 100)
    
    if opportunities:
        print("\nIf proceeding to live trading:")
        print("1. Start with 20-30% of recommended position size")
        print("2. Monitor convexity costs in real-time")
        print("3. Set stop-losses if available")
        print("4. Track performance and adjust strategies")
    else:
        print("\nRecommended actions:")
        print("1. Rescan with lower edge threshold (10-12%)")
        print("2. Wait for market conditions to change")
        print("3. Check for new market creation")
        print("4. Review alternative trading strategies")
    
    print("\n" + "=" * 100)
    print("DRY-RUN COMPLETE")
    print("=" * 100)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())