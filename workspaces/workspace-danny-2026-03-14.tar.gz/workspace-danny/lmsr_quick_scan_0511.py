#!/usr/bin/env python3
"""
LMSR Quick Scan - 5:11 AM AEST
"""

import os
import sys
from datetime import datetime, timezone
import math

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    client = SimmerClient(api_key=api_key)
    current_time = datetime.now(timezone.utc)
    
    # Parameters
    MIN_EDGE = 0.15
    MAX_POSITION = 25.0
    LIQUIDITY = 100.0
    
    print("=" * 80)
    print("LMSR DRY-RUN SCAN REPORT")
    print("=" * 80)
    print(f"Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}...")
    print(f"Minimum Edge: {MIN_EDGE:.0%}")
    print(f"Max Position: ${MAX_POSITION:.2f}")
    print()
    
    # Fetch markets
    print("Scanning markets...")
    markets = client.get_markets(limit=120, status='active')
    print(f"Markets scanned: {len(markets)}")
    
    opportunities = []
    
    for market in markets:
        # Skip if no probability
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
            
        p = market.current_probability
        
        # Basic filters
        if p > 0.98 or p < 0.02:
            continue
            
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 7200:  # <2 hours
                continue
        
        # Calculate edge (conservative mean reversion)
        distance = abs(0.5 - p)
        gross_edge = distance * 0.45  # 45% of distance
        
        if gross_edge < MIN_EDGE:
            continue
            
        # Determine trade
        if p < 0.5:
            outcome = "YES"
            trade_prob = p
        else:
            outcome = "NO"
            trade_prob = 1 - p
        
        # Position sizing
        max_shares = MAX_POSITION / trade_prob if trade_prob > 0 else 0
        edge_ratio = min(gross_edge / 0.3, 1.0)  # Cap at 30% edge
        shares = max_shares * (edge_ratio ** 0.5) * 0.7  # Conservative
        
        # Convexity cost
        base_cost = 0.25
        prob_factor = 2 * abs(trade_prob - 0.5)  # 0-1 range
        size_factor = min(shares / 80, 1.0)
        convexity_pct = base_cost + 0.25 * prob_factor + 0.1 * size_factor
        convexity_pct = min(convexity_pct, 0.55)  # Max 55%
        
        # Net edge
        net_edge = gross_edge * (1 - convexity_pct)
        
        if net_edge < MIN_EDGE:
            continue
            
        # Expected value
        ev = net_edge * shares * 100  # $1 per share
        
        opportunities.append({
            'question': market.question[:75] + "..." if len(market.question) > 75 else market.question,
            'market_prob': p,
            'gross_edge': gross_edge,
            'net_edge': net_edge,
            'convexity_pct': convexity_pct * 100,
            'outcome': outcome,
            'shares': shares,
            'cost': shares * trade_prob,
            'ev': ev,
            'id': market.id
        })
    
    # Sort by net edge
    opportunities.sort(key=lambda x: x['net_edge'], reverse=True)
    
    # Report
    if not opportunities:
        print("\n❌ NO OPPORTUNITIES FOUND")
        print("\nAnalysis:")
        print("• No markets maintain >15% edge after convexity costs")
        print("• Current market conditions: Efficiently priced")
        print("• Convexity costs: 25-55% of gross edge")
        print("• Recommendation: Wait for more volatile conditions")
    else:
        print(f"\n✅ FOUND {len(opportunities)} OPPORTUNITIES")
        print("\nTOP 5 OPPORTUNITIES (after convexity):")
        print("-" * 80)
        
        total_ev = 0
        total_cost = 0
        
        for i, opp in enumerate(opportunities[:5], 1):
            print(f"\n{i}. {opp['question']}")
            print(f"   Market: {opp['market_prob']:.1%}")
            print(f"   Gross Edge: {opp['gross_edge']:.1%} → Net: {opp['net_edge']:.1%}")
            print(f"   Convexity Cost: {opp['convexity_pct']:.1f}%")
            print(f"   Action: BUY {opp['outcome']}")
            print(f"   Shares: {opp['shares']:.1f} | Cost: ${opp['cost']:.2f}")
            print(f"   Expected EV: ${opp['ev']:.2f}")
            
            total_ev += opp['ev']
            total_cost += opp['cost']
        
        print("\n" + "=" * 80)
        print("PORTFOLIO SUMMARY")
        print("=" * 80)
        print(f"Opportunities: {min(5, len(opportunities))}")
        print(f"Total Investment: ${total_cost:.2f}")
        print(f"Total Expected EV: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            print(f"Expected ROI: {roi:.1f}%")
        
        # Risk metrics
        avg_edge = sum(o['net_edge'] for o in opportunities[:5]) / min(5, len(opportunities))
        print(f"\nRisk Metrics:")
        print(f"  Average Net Edge: {avg_edge:.1%}")
        print(f"  Max Position: ${max(o['cost'] for o in opportunities[:5]):.2f}")
        
        print(f"\nConvexity Analysis:")
        print(f"  • All calculations include convexity costs")
        print(f"  • Costs range: 25-55% of gross edge")
        print(f"  • Higher for extreme probabilities & larger positions")
    
    print("\n" + "=" * 80)
    print("DRY-RUN STATUS: COMPLETE")
    print("No trades were executed.")
    print("=" * 80)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())