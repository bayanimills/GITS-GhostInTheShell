#!/usr/bin/env python3
"""
LMSR Scan - 8:35 AM AEST
Strategic scan with threshold analysis and market efficiency assessment.
"""

import os
import sys
from datetime import datetime, timezone

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class StrategicMarketAnalyzer:
    """Analyzer with strategic threshold analysis."""
    
    def __init__(self, test_thresholds=[0.15, 0.12]):
        # Market type configurations for 8:35 AM
        self.configs = {
            'crypto': {
                'edge_mult': 0.57,      # 57% of distance
                'base_conv': 0.18,      # 18% base (improving)
                'prob_factor': 0.28,    # Probability impact
                'min_ev': 35.0,         # Minimum EV
                'position_mult': 0.85   # Position multiplier
            },
            'sports': {
                'edge_mult': 0.51,
                'base_conv': 0.22,
                'prob_factor': 0.30,
                'min_ev': 30.0,
                'position_mult': 0.80
            },
            'esports': {
                'edge_mult': 0.61,
                'base_conv': 0.21,
                'prob_factor': 0.29,
                'min_ev': 32.0,
                'position_mult': 0.83
            },
            'weather': {
                'edge_mult': 0.46,
                'base_conv': 0.24,
                'prob_factor': 0.31,
                'min_ev': 25.0,
                'position_mult': 0.78
            },
            'politics': {
                'edge_mult': 0.49,
                'base_conv': 0.23,
                'prob_factor': 0.30,
                'min_ev': 28.0,
                'position_mult': 0.79
            },
            'other': {
                'edge_mult': 0.48,
                'base_conv': 0.24,
                'prob_factor': 0.30,
                'min_ev': 25.0,
                'position_mult': 0.78
            }
        }
        
        # Strategic parameters
        self.primary_threshold = test_thresholds[0]  # 15%
        self.secondary_threshold = test_thresholds[1]  # 12%
        self.max_position = 32.0  # Increased for morning
        self.size_factor = 0.08   # Reduced size impact
    
    def classify_market(self, question):
        """Classify market type."""
        q = question.lower()
        
        if any(word in q for word in ['bitcoin', 'ethereum', 'solana', 'xrp', 'crypto']):
            return 'crypto'
        elif any(word in q for word in ['spread', 'nba', 'soccer', 'football', 'basketball']):
            return 'sports'
        elif any(word in q for word in ['lol', 'esports', 'rainbow', 'siege', 'dota']):
            return 'esports'
        elif any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return 'weather'
        elif any(word in q for word in ['election', 'politic', 'ukraine', 'trump', 'biden']):
            return 'politics'
        else:
            return 'other'
    
    def analyze_opportunity(self, market_prob, question):
        """Analyze market for trading opportunity."""
        # Filter extreme probabilities
        if market_prob < 0.05 or market_prob > 0.95:
            return None
        
        # Filter very low/high probabilities
        if market_prob < 0.12 or market_prob > 0.88:
            # Allow but note for convexity
            pass
        
        # Classify market
        market_type = self.classify_market(question)
        config = self.configs[market_type]
        
        # Calculate distance from 50%
        distance = abs(0.5 - market_prob)
        
        # Gross edge
        gross_edge = distance * config['edge_mult']
        
        if gross_edge < self.secondary_threshold:  # Use secondary threshold for initial filter
            return None
        
        # Determine trade direction
        if market_prob < 0.5:
            outcome = "YES"
            trade_prob = market_prob
        else:
            outcome = "NO"
            trade_prob = 1 - market_prob
        
        # Position sizing
        max_shares = self.max_position / trade_prob if trade_prob > 0 else 0
        
        # Edge-based scaling
        edge_ratio = min(gross_edge / 0.3, 1.0)
        shares = max_shares * (edge_ratio ** 0.75) * config['position_mult']
        
        # Convexity cost
        prob_factor = 2 * abs(trade_prob - 0.5) * config['prob_factor']
        size_factor = min(shares / 110, 1.0) * self.size_factor
        
        convexity_pct = config['base_conv'] + prob_factor + size_factor
        convexity_pct = min(convexity_pct, 0.60)  # Max 60%
        
        # Net edge after convexity
        net_edge = gross_edge * (1 - convexity_pct)
        
        # Check both thresholds
        meets_primary = net_edge >= self.primary_threshold
        meets_secondary = net_edge >= self.secondary_threshold
        
        if not meets_secondary:
            return None
        
        # Expected value
        ev = net_edge * shares * 100
        
        if ev < config['min_ev']:
            return None
        
        # Calculate metrics
        cost = shares * trade_prob
        roi = (ev / cost * 100) if cost > 0 else 0
        
        return {
            'market_type': market_type,
            'gross_edge': gross_edge,
            'net_edge': net_edge,
            'convexity_pct': convexity_pct * 100,
            'outcome': outcome,
            'shares': shares,
            'cost': cost,
            'ev': ev,
            'roi': roi,
            'trade_prob': trade_prob,
            'distance': distance,
            'edge_mult': config['edge_mult'],
            'meets_primary': meets_primary,
            'meets_secondary': meets_secondary
        }

def main():
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
    
    client = SimmerClient(api_key=api_key)
    analyzer = StrategicMarketAnalyzer(test_thresholds=[0.15, 0.12])
    current_time = datetime.now(timezone.utc)
    
    print("=" * 80)
    print("LMSR STRATEGIC SCAN REPORT")
    print("=" * 80)
    print(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Local Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    print(f"API Key: {api_key[:20]}... (validated)")
    print(f"Primary Threshold: >{analyzer.primary_threshold:.0%} (after convexity)")
    print(f"Secondary Threshold: >{analyzer.secondary_threshold:.0%} (strategic test)")
    print(f"Max Position: ${analyzer.max_position:.2f}")
    print(f"Scan Time: 8:35 AM AEST (strategic assessment)")
    print()
    
    # Fetch markets
    print("Fetching and analyzing markets...")
    markets = client.get_markets(limit=120, status='active')
    
    opportunities = []
    stats = {
        'total': len(markets),
        'with_prob': 0,
        'viable': 0,      # 5-95%
        'tradable': 0,    # 12-88%
        'by_type': {mtype: 0 for mtype in analyzer.configs.keys()}
    }
    
    for market in markets:
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            continue
        
        stats['with_prob'] += 1
        p = market.current_probability
        
        # Count viable ranges
        if 0.05 <= p <= 0.95:
            stats['viable'] += 1
        if 0.12 <= p <= 0.88:
            stats['tradable'] += 1
        
        # Check expiry
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            if time_to_expiry < 3300:  # <55 minutes
                continue
        
        question = market.question if hasattr(market, 'question') else ""
        
        # Analyze
        analysis = analyzer.analyze_opportunity(p, question)
        if analysis:
            mtype = analysis['market_type']
            stats['by_type'][mtype] += 1
            
            opportunities.append({
                'id': market.id,
                'question': question[:65] + "..." if len(question) > 65 else question,
                'market_prob': p,
                'analysis': analysis
            })
    
    # Sort by net edge
    opportunities.sort(key=lambda x: x['analysis']['net_edge'], reverse=True)
    
    # Print statistics
    print(f"\nMarket Statistics (8:35 AM AEST):")
    print(f"  Total markets: {stats['total']}")
    print(f"  With probabilities: {stats['with_prob']}")
    print(f"  Viable markets (5-95%): {stats['viable']}")
    print(f"  Tradable markets (12-88%): {stats['tradable']}")
    
    print(f"\nMarkets by type:")
    for mtype, count in stats['by_type'].items():
        if count > 0:
            print(f"  {mtype.upper()}: {count}")
    
    print(f"\nOpportunities found: {len(opportunities)}")
    
    # Threshold analysis
    primary_opps = [o for o in opportunities if o['analysis']['meets_primary']]
    secondary_opps = [o for o in opportunities if o['analysis']['meets_secondary']]
    
    print(f"\nThreshold Analysis:")
    print(f"  Opportunities >{analyzer.primary_threshold:.0%}: {len(primary_opps)}")
    print(f"  Opportunities >{analyzer.secondary_threshold:.0%}: {len(secondary_opps)}")
    
    # Generate report
    if not opportunities:
        print("\n" + "=" * 80)
        print("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("=" * 80)
        
        print(f"\n8:35 AM AEST Strategic Assessment:")
        print(f"• Time: Morning, approaching US pre-market")
        print(f"• Efficiency: Persistently exceptional")
        print(f"• Convexity: 18-60% range (continuing improvement)")
        print(f"• Activity: Good, but efficiency dominates")
        
        print(f"\nStrategic Parameters:")
        for mtype, config in analyzer.configs.items():
            print(f"  {mtype.upper()}: {config['edge_mult']:.0%} edge, {config['base_conv']:.0%} base convexity")
        
        print(f"\nThreshold Analysis Results:")
        print(f"  Primary threshold ({analyzer.primary_threshold:.0%}): 0 opportunities")
        print(f"  Secondary threshold ({analyzer.secondary_threshold:.0%}): 0 opportunities")
        
        print(f"\nStrategic Implications:")
        print(f"  1. Market efficiency remains exceptionally high")
        print(f"  2. Even 12% threshold yields no opportunities")
        print(f"  3. Consider further threshold reduction to 10%")
        print(f"  4. Monitor for US pre-market volatility (9:30 PM ET)")
        
        print(f"\nRecommendations:")
        print(f"  1. Wait for US market influence (9:30 PM ET)")
        print(f"  2. Consider threshold reduction strategy")
        print(f"  3. Next scan at 9:00 AM AEST")
        print(f"  4. Focus on Crypto markets (most responsive)")
        
    else:
        print(f"\n✅ FOUND {len(opportunities)} OPPORTUNITIES")
        
        # Separate by threshold
        if primary_opps:
            print(f"\nTOP PRIMARY OPPORTUNITIES (>15% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(primary_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} ✅ PRIMARY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        if secondary_opps and not primary_opps:
            print(f"\nTOP SECONDARY OPPORTUNITIES (12-15% net edge):")
            print("-" * 80)
            
            for i, opp in enumerate(secondary_opps[:5], 1):
                analysis = opp['analysis']
                
                print(f"\n{i}. {opp['question']}")
                print(f"   Type: {analysis['market_type'].upper()}")
                print(f"   Market Probability: {opp['market_prob']:.1%}")
                print(f"   Distance from 50%: {analysis['distance']:.1%}")
                print(f"   Gross Edge: {analysis['gross_edge']:.1%}")
                print(f"   Convexity Cost: {analysis['convexity_pct']:.1f}%")
                print(f"   Net Edge: {analysis['net_edge']:.1%} ⚠️ SECONDARY")
                print(f"   Action: BUY {analysis['outcome']} @ {analysis['trade_prob']:.1%}")
                print(f"   Shares: {analysis['shares']:.1f}")
                print(f"   Position Cost: ${analysis['cost']:.2f}")
                print(f"   Expected EV: ${analysis['ev']:.2f}")
                print(f"   Expected ROI: {analysis['roi']:.1f}%")
        
        # Portfolio summary
        total_ev = sum(o['analysis']['ev'] for o in opportunities[:5])
        total_cost = sum(o['analysis']['cost'] for o in opportunities[:5])
        
        print("\n" + "=" * 80)
        print("PORTFOLIO SUMMARY")
        print("=" * 80)
        print(f"Total Opportunities: {min(5, len(opportunities))}")
        print(f"Total Investment: ${total_cost:.2f}")
        print(f"Total Expected EV: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            print(f"Portfolio ROI: {roi:.1f}%")
            print(f"Return per Dollar: ${total_ev/total_cost:.2f}")
        
        # Strategic analysis
        print(f"\nSTRATEGIC ANALYSIS:")
        print(f"  Primary threshold opportunities: {len(primary_opps)}")
        print(f"  Secondary threshold opportunities: {len(secondary_opps)}")
        
        if primary_opps:
            print(f"  Recommendation: ✅ TRADE PRIMARY OPPORTUNITIES")
            print(f"  Position sizing: Use 90% of calculated positions")
        elif secondary_opps:
            print(f"  Recommendation: ⚠️ CONSIDER SECONDARY OPPORTUNITIES")
            print(f"  Position sizing: Use 75% of calculated positions")
            print(f"  Risk: Lower edge buffer (12-15% vs 15%+)")
        else:
            print(f"  Recommendation: ❌ NO TRADE")
            print(f"  Rationale: No opportunities meet either threshold")
    
    print("\n" + "=" * 80)
    print("DRY-RUN STATUS: COMPLETE")
    print("No trades were executed.")
    print("=" * 80)
    
    # Save strategic report
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    with open(f"lmsr_0835_strategic_report_{timestamp}.txt", 'w') as f:
        f.write(f"LMSR Strategic Scan Report - 8:35 AM AEST\n")
        f.write(f"Time: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')}\n")
        f.write("="*60 + "\n")
        
        f.write(f"\nThreshold Analysis:\n")
        f.write(f"  Primary (>15%): {len(primary_opps)} opportunities\n")
        f.write