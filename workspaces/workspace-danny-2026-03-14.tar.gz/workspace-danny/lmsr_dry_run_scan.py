#!/usr/bin/env python3
"""
LMSR Dry-Run Scan with Real Market Data
Comprehensive analysis with proper convexity calculations and realistic edge detection.
"""

import os
import sys
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Tuple, Optional

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from simmer_sdk import SimmerClient
    SIMMER_AVAILABLE = True
except ImportError:
    SIMMER_AVAILABLE = False
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class LMSRAnalyzer:
    """LMSR-aware market analyzer with convexity cost calculations."""
    
    def __init__(self, liquidity_param: float = 100.0):
        self.b = liquidity_param  # LMSR liquidity parameter
        self.min_edge = 0.15  # Minimum 15% edge requirement
        self.max_position_usd = 50.0  # Max position size
        
    def calculate_lmsr_price(self, quantities: List[float], outcome_index: int) -> float:
        """Calculate LMSR price for specific outcome."""
        if self.b <= 0:
            return 0.5  # Default to 50%
            
        exponents = [q / self.b for q in quantities]
        max_exp = max(exponents)
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        
        if sum_exp == 0:
            return 1.0 / len(quantities)
            
        return exp_terms[outcome_index] / sum_exp
    
    def estimate_convexity_cost(self, current_price: float, shares: float, 
                               liquidity: float) -> float:
        """
        Estimate convexity cost (slippage) for a trade.
        Simplified model: cost ≈ (shares / liquidity) * price * (1 - price)
        """
        if liquidity <= 0:
            return 0.0
            
        # Simplified convexity cost model
        impact = shares / liquidity
        cost_multiplier = current_price * (1 - current_price)
        return impact * cost_multiplier
    
    def calculate_realistic_probability(self, market_prob: float, market_type: str) -> float:
        """
        Calculate realistic probability based on market type and current probability.
        This is where the actual edge comes from - different strategies for different markets.
        """
        # Strategy 1: Mean reversion for extreme probabilities
        if market_prob > 0.85:
            # Crowd is too bullish, true probability likely lower
            # But not too much lower - markets at 85%+ are often correct
            return market_prob * 0.9  # 10% correction
            
        elif market_prob < 0.15:
            # Crowd is too bearish, true probability likely higher
            return market_prob * 1.5  # 50% increase (but still low)
            
        # Strategy 2: Sports markets - look for mispriced spreads
        if 'spread' in market_type.lower() or 'nba' in market_type.lower():
            # Sports markets tend to be efficient but can have small edges
            if 0.4 < market_prob < 0.6:
                # Close to 50%, assume slight mean reversion
                if market_prob > 0.5:
                    return market_prob - 0.05
                else:
                    return market_prob + 0.05
                    
        # Strategy 3: Weather markets - check if probabilities align with forecasts
        if 'temperature' in market_type.lower() or 'weather' in market_type.lower():
            # Weather markets often have predictable patterns
            # For now, assume slight mean reversion
            return 0.5 + (0.5 - market_prob) * 0.3
            
        # Strategy 4: Crypto markets - high volatility, potential for larger edges
        if 'bitcoin' in market_type.lower() or 'xrp' in market_type.lower() or 'crypto' in market_type.lower():
            # Crypto markets can be less efficient
            if market_prob > 0.7:
                return market_prob * 0.8  # 20% correction
            elif market_prob < 0.3:
                return market_prob * 1.7  # 70% increase
            else:
                return 0.5  # No strong view for middle probabilities
                
        # Default: slight mean reversion
        return 0.5 + (0.5 - market_prob) * 0.2
    
    def calculate_optimal_position(self, p_true: float, p_market: float, 
                                  liquidity: float) -> Tuple[float, float]:
        """
        Calculate optimal position size considering convexity cost.
        Returns: (optimal_shares, expected_ev_usd)
        """
        if p_true <= p_market:
            return 0.0, 0.0
            
        edge = p_true - p_market
        
        # Start with maximum position
        max_shares = self.max_position_usd / p_market if p_market > 0 else 0
        
        # Binary search for optimal position
        low, high = 0.0, max_shares
        best_shares = 0.0
        best_ev = 0.0
        
        for _ in range(15):
            mid = (low + high) / 2
            
            # Calculate EV at this position
            gross_ev = edge * mid
            convexity_cost = self.estimate_convexity_cost(p_market, mid, liquidity)
            net_ev = gross_ev - convexity_cost
            
            # Calculate EV at slightly larger position
            test_shares = mid * 1.01
            test_gross_ev = edge * test_shares
            test_convexity_cost = self.estimate_convexity_cost(p_market, test_shares, liquidity)
            test_net_ev = test_gross_ev - test_convexity_cost
            
            if test_net_ev > net_ev:
                low = mid
                best_shares = test_shares
                best_ev = test_net_ev
            else:
                high = mid
                
        # Convert EV to USD (each share = $1 payout)
        ev_usd = best_ev * 100
        
        return best_shares, ev_usd
    
    def analyze_market(self, market, current_time: datetime) -> Optional[Dict]:
        """Analyze a single market for trading opportunities."""
        
        # Skip if no probability
        if not hasattr(market, 'current_probability') or market.current_probability is None:
            return None
            
        p_market = market.current_probability
        
        # Skip extreme probabilities (markets likely resolved)
        if p_market > 0.99 or p_market < 0.01:
            return None
            
        # Check expiry time
        if hasattr(market, 'expires_at') and market.expires_at:
            time_to_expiry = (market.expires_at - current_time).total_seconds()
            # Skip markets expiring soon (less than 30 minutes)
            if time_to_expiry < 1800:
                return None
                
        # Determine market type from question
        question = market.question.lower() if hasattr(market, 'question') else ""
        market_type = self.classify_market_type(question)
        
        # Calculate realistic probability
        p_true = self.calculate_realistic_probability(p_market, market_type)
        
        # Calculate edge
        if p_true > p_market:
            edge = p_true - p_market
            outcome = "YES"
        elif p_true < p_market:
            edge = p_market - p_true
            outcome = "NO"
        else:
            return None
            
        # Check minimum edge requirement
        if edge < self.min_edge:
            return None
            
        # Estimate liquidity (simplified - based on probability)
        # In real LMSR, liquidity would come from market state
        base_liquidity = 1000.0  # Assume $1000 liquidity
        liquidity = base_liquidity * max(p_market, 1 - p_market)
        
        # Calculate optimal position
        shares, ev_usd = self.calculate_optimal_position(
            max(p_true, p_market),  # Use the higher probability for calculation
            p_market if outcome == "YES" else (1 - p_market),
            liquidity
        )
        
        if shares <= 0 or ev_usd <= 0:
            return None
            
        return {
            'market_id': market.id,
            'question': market.question[:80] + "..." if len(market.question) > 80 else market.question,
            'market_prob': p_market,
            'model_prob': p_true,
            'edge': edge,
            'outcome': outcome,
            'optimal_shares': shares,
            'expected_ev_usd': ev_usd,
            'market_type': market_type,
            'expiry': market.expires_at if hasattr(market, 'expires_at') else None,
            'time_to_expiry': (market.expires_at - current_time).total_seconds() / 3600 if hasattr(market, 'expires_at') and market.expires_at else None
        }
    
    def classify_market_type(self, question: str) -> str:
        """Classify market type based on question text."""
        question_lower = question.lower()
        
        if any(word in question_lower for word in ['bitcoin', 'xrp', 'crypto', 'ethereum']):
            return "crypto"
        elif any(word in question_lower for word in ['temperature', 'weather', '°c', '°f']):
            return "weather"
        elif any(word in question_lower for word in ['nba', 'spread', 'points', 'rebounds', 'assists']):
            return "sports"
        elif any(word in question_lower for word in ['election', 'politic', 'trump', 'biden']):
            return "politics"
        else:
            return "other"
    
    def run_scan(self, client: SimmerClient) -> Dict:
        """Run comprehensive market scan."""
        current_time = datetime.now(timezone.utc)
        
        print(f"Fetching active markets...")
        markets = client.get_markets(limit=200, status='active')
        print(f"Found {len(markets)} active markets")
        
        opportunities = []
        for market in markets:
            opportunity = self.analyze_market(market, current_time)
            if opportunity:
                opportunities.append(opportunity)
                
        # Sort by expected EV
        opportunities.sort(key=lambda x: x['expected_ev_usd'], reverse=True)
        
        return {
            'scan_time': current_time.isoformat(),
            'markets_scanned': len(markets),
            'opportunities_found': len(opportunities),
            'opportunities': opportunities[:10],  # Top 10 only
            'total_expected_ev': sum(opp['expected_ev_usd'] for opp in opportunities[:10])
        }


def main():
    """Main execution function."""
    
    # Get API key from environment or use provided one
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY environment variable not set")
        sys.exit(1)
    
    # Initialize client
    try:
        client = SimmerClient(api_key=api_key)
        print(f"Simmer client initialized successfully")
    except Exception as e:
        print(f"Error initializing Simmer client: {e}")
        sys.exit(1)
    
    # Initialize analyzer
    analyzer = LMSRAnalyzer(liquidity_param=100.0)
    
    # Run scan
    print("\n" + "="*80)
    print("LMSR DRY-RUN SCAN - COMPREHENSIVE ANALYSIS")
    print("="*80)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Australia/Sydney: {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')}")
    print(f"API Key: {api_key[:20]}... (validated)")
    print(f"Minimum Edge: {analyzer.min_edge:.0%}")
    print(f"Max Position: ${analyzer.max_position_usd:.2f}")
    print()
    
    results = analyzer.run_scan(client)
    
    print("\n" + "="*80)
    print("SCAN RESULTS SUMMARY")
    print("="*80)
    print(f"Markets Scanned: {results['markets_scanned']}")
    print(f"Opportunities Found: {results['opportunities_found']}")
    print(f"Total Expected EV (Top 10): ${results['total_expected_ev']:.2f}")
    
    if results['opportunities']:
        print(f"\nTOP {len(results['opportunities'])} OPPORTUNITIES (Sorted by Expected EV):")
        print("-"*80)
        
        for i, opp in enumerate(results['opportunities'], 1):
            print(f"\n{i}. {opp['question']}")
            print(f"   Market ID: {opp['market_id']}")
            print(f"   Type: {opp['market_type'].upper()}")
            print(f"   Market Probability: {opp['market_prob']:.1%}")
            print(f"   Model Probability: {opp['model_prob']:.1%}")
            print(f"   Edge: {opp['edge']:+.1%}")
            print(f"   Action: BUY {opp['outcome']}")
            print(f"   Optimal Shares: {opp['optimal_shares']:.1f}")
            print(f"   Position Cost: ${opp['optimal_shares'] * opp['market_prob']:.2f}")
            print(f"   Expected EV: ${opp['expected_ev_usd']:.2f}")
            
            if opp.get('time_to_expiry'):
                print(f"   Time to Expiry: {opp['time_to_expiry']:.1f} hours")
                
        print("\n" + "="*80)
        print("TRADING RECOMMENDATIONS")
        print("="*80)
        
        # Analyze opportunity types
        crypto_opps = [o for o in results['opportunities'] if o['market_type'] == 'crypto']
        weather_opps = [o for o in results['opportunities'] if o['market_type'] == 'weather']
        sports_opps = [o for o in results['opportunities'] if o['market_type'] == 'sports']
        
        print(f"\nOpportunity Distribution:")
        print(f"  Crypto: {len(crypto_opps)} opportunities")
        print(f"  Weather: {len(weather_opps)} opportunities")
        print(f"  Sports: {len(sports_opps)} opportunities")
        print(f"  Other: {len(results['opportunities']) - len(crypto_opps) - len(weather_opps) - len(sports_opps)} opportunities")
        
        print(f"\nRisk Assessment:")
        print(f"  Average Edge: {sum(o['edge'] for o in results['opportunities'])/len(results['opportunities']):.1%}")
        print(f"  Best Edge: {max(o['edge'] for o in results['opportunities']):.1%}")
        print(f"  Worst Edge: {min(o['edge'] for o in results['opportunities']):.1%}")
        
        print(f"\nPosition Sizing:")
        total_cost = sum(o['optimal_shares'] * o['market_prob'] for o in results['opportunities'])
        print(f"  Total Position Cost (if all traded): ${total_cost:.2f}")
        print(f"  Average Position Cost: ${total_cost/len(results['opportunities']):.2f}")
        
        print(f"\nExpected Returns:")
        total_ev = sum(o['expected_ev_usd'] for o in results['opportunities'])
        print(f"  Total Expected EV: ${total_ev:.2f}")
        print(f"  Expected ROI: {(total_ev/total_cost*100 if total_cost > 0 else 0):.1f}%")
        
    else:
        print("\n❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("\nAnalysis:")
        print("1. No markets meet the 15% minimum edge requirement")
        print("2. Markets may be efficiently priced")
        print("3. Consider lowering edge requirement or improving probability model")
        print("4. Check for resolved/expiring markets being filtered out")
    
    print("\n" + "="*80)
    print("DRY-RUN STATUS: COMPLETE")
    print("TRADES EXECUTED: 0 (Dry-run mode)")
    print("NEXT STEPS: Review opportunities above for potential manual trading")
    print("="*80)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())