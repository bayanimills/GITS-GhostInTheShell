#!/usr/bin/env python3
"""
LMSR Final Dry-Run Scan
Properly calibrated with realistic edge detection and convexity costs.
"""

import os
import sys
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Tuple

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class FinalLMSRScanner:
    """Final calibrated scanner with proper risk management."""
    
    def __init__(self):
        self.min_edge = 0.15  # 15% minimum edge
        self.max_position_usd = 10.0  # Very conservative position size
        self.base_liquidity = 500.0  # Assume $500 liquidity per market
        
    def get_conservative_edge(self, market_prob: float, question: str) -> float:
        """
        Get conservative edge estimate.
        Returns 0 if no edge, positive value if edge exists.
        """
        # Skip extreme probabilities
        if market_prob > 0.95 or market_prob < 0.05:
            return 0.0
            
        q = question.lower()
        
        # Very conservative edge estimates
        # Maximum edge is 20% for the most mispriced markets
        
        # 1. Weather markets - forecasts are generally accurate
        if any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            # Small mean reversion
            if market_prob > 0.7:
                return min((market_prob - 0.7) * 0.3, 0.15)  # Max 15% edge
            elif market_prob < 0.3:
                return min((0.3 - market_prob) * 0.3, 0.15)
            else:
                return 0.0
                
        # 2. Crypto markets - can be volatile
        elif any(word in q for word in ['bitcoin', 'solana', 'xrp', 'ethereum', 'crypto']):
            if market_prob > 0.75:
                return min((market_prob - 0.75) * 0.4, 0.2)  # Max 20% edge
            elif market_prob < 0.25:
                return min((0.25 - market_prob) * 0.4, 0.2)
            else:
                return 0.0
                
        # 3. Sports markets - generally efficient
        elif any(word in q for word in ['spread', 'nba', 'nfl', 'soccer', 'football']):
            if market_prob > 0.65:
                return min((market_prob - 0.65) * 0.3, 0.15)
            elif market_prob < 0.35:
                return min((0.35 - market_prob) * 0.3, 0.15)
            else:
                return 0.0
                
        # 4. Esports - can have small edges
        elif any(word in q for word in ['lol', 'league', 'esports', 'rainbow', 'siege']):
            if market_prob > 0.8:
                return min((market_prob - 0.8) * 0.5, 0.25)  # Max 25% edge
            elif market_prob < 0.2:
                return min((0.2 - market_prob) * 0.5, 0.25)
            else:
                return 0.0
                
        # 5. Default - very conservative
        else:
            if market_prob > 0.8:
                return min((market_prob - 0.8) * 0.2, 0.1)  # Max 10% edge
            elif market_prob < 0.2:
                return min((0.2 - market_prob) * 0.2, 0.1)
            else:
                return 0.0
    
    def calculate_position(self, market_prob: float, edge: float, outcome: str) -> Tuple[float, float]:
        """
        Calculate position size and expected value.
        Returns: (shares, expected_ev_usd)
        """
        if edge < self.min_edge:
            return 0.0, 0.0
            
        # Trade probability
        trade_prob = market_prob if outcome == "YES" else (1 - market_prob)
        
        if trade_prob <= 0:
            return 0.0, 0.0
            
        # Maximum shares based on position limit
        max_shares = self.max_position_usd / trade_prob
        
        # Position sizing based on edge strength
        # Use square root scaling for risk management
        edge_ratio = min(edge / 0.3, 1.0)  # Cap at 30% edge
        shares = max_shares * (edge_ratio ** 0.5)  # Square root scaling
        
        # Convexity cost (slippage)
        # Higher for larger positions and more extreme probabilities
        convexity_factor = 0.1 + 0.3 * (abs(trade_prob - 0.5) * 2)  # 10-40% cost
        size_factor = min(shares / 50, 1.0)  # Cap at 50 shares
        convexity_cost = edge * convexity_factor * size_factor
        
        # Net edge after convexity
        net_edge = edge - convexity_cost
        
        if net_edge <= 0:
            return 0.0, 0.0
            
        # Expected value in USD
        ev_usd = net_edge * shares * 100  # Each share = $1 payout
        
        return shares, ev_usd
    
    def run_scan(self, client: SimmerClient) -> List[Dict]:
        """Run the final scan."""
        current_time = datetime.now(timezone.utc)
        
        print("Fetching active markets...")
        markets = client.get_markets(limit=200, status='active')
        print(f"Found {len(markets)} active markets")
        
        opportunities = []
        
        for market in markets:
            # Basic validation
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            p_market = market.current_probability
            
            # Skip extremes
            if p_market > 0.98 or p_market < 0.02:
                continue
                
            # Check expiry
            if hasattr(market, 'expires_at') and market.expires_at:
                time_to_expiry = (market.expires_at - current_time).total_seconds()
                if time_to_expiry < 7200:  # Skip markets expiring in <2 hours
                    continue
                    
            # Get question
            question = market.question if hasattr(market, 'question') else ""
            
            # Get conservative edge
            edge = self.get_conservative_edge(p_market, question)
            
            if edge <= 0:
                continue
                
            # Determine direction
            # For positive edge, we think market is wrong in current direction
            # So if market says YES is likely (p_market > 0.5), we think NO has edge
            if p_market > 0.5:
                outcome = "NO"
                trade_prob = 1 - p_market
                # Edge is for the NO side
            else:
                outcome = "YES"
                trade_prob = p_market
                # Edge is for the YES side
                
            # Calculate position
            shares, ev_usd = self.calculate_position(p_market, edge, outcome)
            
            if shares <= 0 or ev_usd <= 0:
                continue
                
            # Classify market
            market_type = self.classify_market(question)
            
            opportunities.append({
                'id': market.id,
                'question': (question[:60] + "...") if len(question) > 60 else question,
                'market_prob': p_market,
                'edge': edge,
                'outcome': outcome,
                'shares': shares,
                'cost': shares * trade_prob,
                'ev': ev_usd,
                'type': market_type,
                'expiry': market.expires_at if hasattr(market, 'expires_at') else None,
                'time_to_expiry': time_to_expiry / 3600 if hasattr(market, 'expires_at') else None
            })
            
        # Sort by edge percentage
        opportunities.sort(key=lambda x: x['edge'], reverse=True)
        
        return opportunities[:5]  # Return top 5 only
    
    def classify_market(self, question: str) -> str:
        """Simple market classification."""
        q = question.lower()
        
        if any(word in q for word in ['temperature', 'weather', '°c', '°f']):
            return "Weather"
        elif any(word in q for word in ['bitcoin', 'solana', 'xrp', 'ethereum', 'crypto']):
            return "Crypto"
        elif any(word in q for word in ['spread', 'nba', 'nfl', 'soccer', 'football', 'basketball']):
            return "Sports"
        elif any(word in q for word in ['lol', 'league', 'esports', 'rainbow', 'siege', 'dota']):
            return "Esports"
        elif any(word in q for word in ['election', 'politic', 'ukraine', 'starmer', 'trump']):
            return "Politics"
        else:
            return "Other"


def format_report(opportunities: List[Dict]) -> str:
    """Format the scan report."""
    current_time = datetime.now(timezone.utc)
    local_time = datetime.now()
    
    report = []
    report.append("=" * 80)
    report.append("LMSR DRY-RUN SCAN REPORT")
    report.append("=" * 80)
    report.append(f"Scan Time: {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    report.append(f"Local Time: {local_time.strftime('%A, %B %d, %Y — %I:%M %p')} (Australia/Sydney)")
    report.append(f"Minimum Edge: 15% | Max Position: $10.00")
    report.append("")
    
    if not opportunities:
        report.append("❌ NO ACTIONABLE OPPORTUNITIES FOUND")
        report.append("")
        report.append("Analysis:")
        report.append("• No markets meet the 15% minimum edge requirement")
        report.append("• Current market conditions appear efficient")
        report.append("• Consider waiting for more volatile conditions")
    else:
        report.append(f"✅ FOUND {len(opportunities)} ACTIONABLE OPPORTUNITIES")
        report.append("")
        report.append("TOP OPPORTUNITIES (Sorted by Edge):")
        report.append("-" * 80)
        
        total_cost = 0
        total_ev = 0
        
        for i, opp in enumerate(opportunities, 1):
            report.append(f"\n{i}. {opp['question']}")
            report.append(f"   Market: {opp['market_prob']:.1%} | Edge: {opp['edge']:+.1%}")
            report.append(f"   Action: BUY {opp['outcome']} ({opp['type']})")
            report.append(f"   Shares: {opp['shares']:.1f} | Cost: ${opp['cost']:.2f}")
            report.append(f"   Expected EV: ${opp['ev']:.2f}")
            
            if opp.get('time_to_expiry'):
                report.append(f"   Expires in: {opp['time_to_expiry']:.1f} hours")
                
            total_cost += opp['cost']
            total_ev += opp['ev']
            
        report.append("\n" + "=" * 80)
        report.append("PORTFOLIO SUMMARY")
        report.append("=" * 80)
        report.append(f"Total Opportunities: {len(opportunities)}")
        report.append(f"Total Investment: ${total_cost:.2f}")
        report.append(f"Total Expected EV: ${total_ev:.2f}")
        
        if total_cost > 0:
            roi = (total_ev / total_cost) * 100
            report.append(f"Expected ROI: {roi:.1f}%")
            
        # Type distribution
        type_counts = {}
        for opp in opportunities:
            t = opp['type']
            type_counts[t] = type_counts.get(t, 0) + 1
            
        report.append(f"\nOpportunity Distribution:")
        for t, count in sorted(type_counts.items()):
            report.append(f"  {t}: {count}")
            
        # Risk metrics
        avg_edge = sum(o['edge'] for o in opportunities) / len(opportunities)
        max_edge = max(o['edge'] for o in opportunities)
        
        report.append(f"\nRisk Metrics:")
        report.append(f"  Average Edge: {avg_edge:.1%}")
        report.append(f"  Maximum Edge: {max_edge:.1%}")
        report.append(f"  Position Sizing: Conservative (max ${max(o['cost'] for o in opportunities):.2f} each)")
        
        report.append(f"\nConvexity Considerations:")
        report.append(f"  • All EV calculations include convexity cost (slippage)")
        report.append(f"  • Costs range from 10-40% of gross edge")
        report.append(f"  • Larger positions incur higher convexity costs")
        
    report.append("\n" + "=" * 80)
    report.append("DRY-RUN STATUS: COMPLETE")
    report.append("No trades were executed.")
    report.append("=" * 80)
    
    return "\n".join(report)


def main():
    """Main execution."""
    
    api_key = os.environ.get("SIMMER_API_KEY")
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        sys.exit(1)
        
    try:
        client = SimmerClient(api_key=api_key)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
        
    scanner = FinalLMSRScanner()
    
    print("Running final LMSR dry-run scan...")
    opportunities = scanner.run_scan(client)
    
    report = format_report(opportunities)
    print(report)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())