#!/usr/bin/env python3
"""
Flexible LMSR Scanner with Real Market Data
Scans for opportunities with adjustable edge thresholds.
"""

import os
import sys
import math
import json
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Optional

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                try:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
                except ValueError:
                    continue

API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

try:
    from simmer_sdk import SimmerClient
    SIMMER_AVAILABLE = True
except ImportError:
    print("ERROR: simmer_sdk not installed")
    sys.exit(1)

class FlexibleLMSRScanner:
    """Flexible LMSR scanner with multiple edge detection strategies."""
    
    def __init__(self, min_edge: float = 0.10, max_position: float = 50.0):
        """
        Initialize scanner.
        
        Args:
            min_edge: Minimum edge percentage (default 10%)
            max_position: Maximum position size in USD
        """
        self.min_edge = min_edge
        self.max_position = max_position
        self.liquidity_param = 100.0  # LMSR 'b' parameter
        
        # Edge detection strategies
        self.strategies = [
            self.mean_reversion_strategy,
            self.momentum_strategy,
            self.volatility_strategy,
            self.statistical_arbitrage_strategy
        ]
    
    def lmsr_price(self, quantities: List[float], outcome_idx: int) -> float:
        """Calculate LMSR price."""
        if self.liquidity_param <= 0:
            return 0.5
            
        exponents = [q / self.liquidity_param for q in quantities]
        max_exp = max(exponents)
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        
        if sum_exp == 0:
            return 1.0 / len(quantities)
            
        return exp_terms[outcome_idx] / sum_exp
    
    def convexity_cost(self, current_q: List[float], outcome_idx: int, shares: float) -> float:
        """Estimate convexity cost."""
        price_before = self.lmsr_price(current_q, outcome_idx)
        
        q_after = current_q.copy()
        q_after[outcome_idx] += shares
        price_after = self.lmsr_price(q_after, outcome_idx)
        
        return (price_after - price_before) * shares
    
    def estimate_liquidity(self, p_market: float) -> List[float]:
        """Estimate market liquidity."""
        base_liquidity = 150.0
        
        yes_liquidity = base_liquidity * p_market
        no_liquidity = base_liquidity * (1 - p_market)
        
        min_liquidity = 20.0
        yes_liquidity = max(yes_liquidity, min_liquidity)
        no_liquidity = max(no_liquidity, min_liquidity)
        
        return [yes_liquidity, no_liquidity]
    
    def mean_reversion_strategy(self, p_market: float) -> float:
        """Mean reversion: extreme probabilities tend to revert."""
        if p_market > 0.85:
            # Very high - likely overconfident
            return p_market * 0.82
        elif p_market < 0.15:
            # Very low - likely undervalued
            return p_market + (0.5 - p_market) * 0.25
        elif p_market > 0.7:
            # High - moderate mean reversion
            return p_market * 0.92
        elif p_market < 0.3:
            # Low - moderate mean reversion
            return p_market * 1.12
        else:
            # Moderate - slight regression to mean
            if p_market > 0.5:
                return p_market - 0.04
            else:
                return p_market + 0.04
    
    def momentum_strategy(self, p_market: float) -> float:
        """Momentum: trends tend to continue in short term."""
        # For crypto up/down markets, momentum might be stronger
        # This is a simplified version
        if 0.4 <= p_market <= 0.6:
            # Near 50% - random walk, no strong momentum
            return p_market
        elif p_market > 0.6:
            # Above 60% - momentum continues upward
            return min(p_market * 1.05, 0.95)
        else:
            # Below 40% - momentum continues downward
            return max(p_market * 0.95, 0.05)
    
    def volatility_strategy(self, p_market: float) -> float:
        """Volatility: high volatility markets tend to mean revert more."""
        # Markets near 50% have highest volatility
        distance_from_50 = abs(p_market - 0.5)
        volatility_factor = 1.0 - distance_from_50 * 1.5
        
        if p_market > 0.5:
            return p_market * volatility_factor
        else:
            return p_market / volatility_factor
    
    def statistical_arbitrage_strategy(self, p_market: float) -> float:
        """Statistical arbitrage: look for mispricing relative to similar markets."""
        # Simplified: assume all markets are fairly priced on average
        # In reality, would compare to correlated markets
        return 0.5  # Neutral view
    
    def calculate_model_probability(self, p_market: float, market_data: Dict) -> float:
        """Combine multiple strategies for robust probability estimate."""
        strategies = [
            self.mean_reversion_strategy(p_market),
            self.momentum_strategy(p_market),
            self.volatility_strategy(p_market)
        ]
        
        # Weighted average (favor mean reversion)
        weights = [0.5, 0.3, 0.2]
        weighted_sum = sum(s * w for s, w in zip(strategies, weights))
        
        # Ensure bounds
        return max(0.01, min(0.99, weighted_sum))
    
    def calculate_optimal_position(self, p_true: float, p_market: float,
                                 current_q: List[float], outcome_idx: int) -> Tuple[float, float]:
        """Calculate optimal position with convexity consideration."""
        if abs(p_true - p_market) < self.min_edge:
            return 0.0, 0.0
            
        edge_per_share = p_true - p_market if p_true > p_market else p_market - p_true
        
        # Determine direction
        if p_true > p_market:
            direction = 1  # Buy YES
        else:
            direction = -1  # Buy NO
            # For NO position, adjust probabilities
            p_true = 1 - p_true
            p_market = 1 - p_market
            edge_per_share = p_true - p_market
        
        # Binary search for optimal position
        max_shares = self.max_position / max(p_market, 0.01)
        low, high = 0.0, max_shares
        best_shares = 0.0
        best_ev = 0.0
        
        for _ in range(12):
            mid = (low + high) / 2
            
            gross_ev = edge_per_share * mid
            convexity = self.convexity_cost(current_q, 0 if direction == 1 else 1, mid)
            net_ev = gross_ev - convexity
            
            # Test slightly larger
            test_shares = mid * 1.03
            test_gross = edge_per_share * test_shares
            test_convexity = self.convexity_cost(current_q, 0 if direction == 1 else 1, test_shares)
            test_net = test_gross - test_convexity
            
            if test_net > net_ev:
                low = mid
                best_shares = test_shares
                best_ev = test_net
            else:
                high = mid
        
        # Apply safety buffer (15%)
        optimal_shares = best_shares * 0.85
        
        # Recalculate with buffer
        gross_ev = edge_per_share * optimal_shares
        convexity = self.convexity_cost(current_q, 0 if direction == 1 else 1, optimal_shares)
        final_ev = gross_ev - convexity
        
        return optimal_shares, final_ev
    
    def analyze_market(self, market) -> Optional[Dict]:
        """Analyze a single market."""
        try:
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                return None
                
            p_market = market.current_probability
            
            # Skip extreme probabilities
            if p_market > 0.98 or p_market < 0.02:
                return None
            
            # Get market info
            market_data = {
                'id': market.id,
                'question': market.question if hasattr(market, 'question') else '',
                'category': getattr(market, 'category', 'Unknown')
            }
            
            # Calculate model probability
            p_true = self.calculate_model_probability(p_market, market_data)
            
            # Calculate edge
            edge = p_true - p_market
            
            # Skip if edge too small
            if abs(edge) < self.min_edge:
                return None
            
            # Determine trade direction
            if edge > 0:
                outcome = 'YES'
                outcome_idx = 0
            else:
                outcome = 'NO'
                outcome_idx = 1
                edge = abs(edge)  # Use absolute value
            
            # Estimate liquidity
            current_q = self.estimate_liquidity(p_market)
            
            # Calculate optimal position
            shares, ev = self.calculate_optimal_position(
                p_true, p_market, current_q, outcome_idx
            )
            
            # Convert to USD
            ev_usd = ev * 100
            position_usd = shares * p_market
            
            # Skip if EV too small
            if ev_usd < 0.5:
                return None
            
            return {
                'market_id': market.id,
                'question': market.question[:70] + '...' if len(market.question) > 70 else market.question,
                'p_market': p_market,
                'p_true': p_true,
                'edge_pct': edge * 100,
                'optimal_shares': shares,
                'position_usd': position_usd,
                'expected_ev_usd': ev_usd,
                'outcome': outcome,
                'category': market_data['category']
            }
            
        except Exception as e:
            print(f"Error analyzing market: {e}")
            return None

def format_opportunities(opportunities: List[Dict], min_edge: float) -> str:
    """Format opportunities for display."""
    output = []
    
    output.append("=" * 100)
    output.append(f"FLEXIBLE LMSR SCAN RESULTS (Min Edge: {min_edge*100:.0f}%)")
    output.append("=" * 100)
    output.append(f"Scan Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    output.append(f"Local Time: Friday, March 13th, 2026 — 4:37 AM (Australia/Sydney)")
    output.append(f"API Key: sk_live_92983b88e10d...")
    output.append(f"Mode: DRY-RUN ONLY")
    output.append("")
    
    if not opportunities:
        output.append(f"❌ NO OPPORTUNITIES FOUND WITH >{min_edge*100:.0f}% EDGE")
        output.append("")
        output.append("Market Analysis:")
        output.append("• Most markets are efficiently priced")
        output.append("• Current strategies may not detect sufficient edge")
        output.append("• Consider adjusting edge threshold or strategies")
        output.append("")
        output.append("Next steps:")
        output.append("1. Lower edge threshold (e.g., to 8%)")
        output.append("2. Add more sophisticated strategies")
        output.append("3. Wait for market volatility")
        output.append("4. Rescan in 30-60 minutes")
        return "\n".join(output)
    
    # Sort by edge percentage
    opportunities.sort(key=lambda x: x['edge_pct'], reverse=True)
    
    output.append(f"✅ FOUND {len(opportunities)} OPPORTUNITIES")
    output.append("")
    
    # Summary
    total_ev = sum(opp['expected_ev_usd'] for opp in opportunities)
    avg_edge = sum(opp['edge_pct'] for opp in opportunities) / len(opportunities)
    total_position = sum(opp['position_usd'] for opp in opportunities)
    
    output.append("📊 SUMMARY")
    output.append("-" * 100)
    output.append(f"Total Expected EV: ${total_ev:.2f}")
    output.append(f"Average Edge: {avg_edge:.1f}%")
    output.append(f"Total Position Size: ${total_position:.2f}")
    output.append(f"Number of Opportunities: {len(opportunities)}")
    output.append("")
    
    # Top opportunities
    output.append("🏆 TOP OPPORTUNITIES")
    output.append("-" * 100)
    
    for i, opp in enumerate(opportunities[:10], 1):
        output.append(f"\n{i}. {opp['question']}")
        output.append(f"   ID: {opp['market_id'][:20]}...")
        output.append(f"   Category: {opp['category']}")
        output.append(f"   Market: {opp['p_market']:.1%} | Model: {opp['p_true']:.1%}")
        output.append(f"   Edge: {opp['edge_pct']:.1f}%")
        output.append(f"   Shares: {opp['optimal_shares']:.1f} (${opp['position_usd']:.2f})")
        output.append(f"   Expected EV: ${opp['expected_ev_usd']:.2f}")
        output.append(f"   Trade: BUY {opp['outcome']}")
        
        # Quality rating
        if opp['edge_pct'] > 20:
            rating = "⭐⭐⭐⭐⭐ EXCELLENT"
        elif opp['edge_pct'] > 15:
            rating = "⭐⭐⭐⭐ VERY GOOD"
        elif opp['edge_pct'] > 12:
            rating = "⭐⭐⭐ GOOD"
        elif opp['edge_pct'] > 10:
            rating = "⭐⭐ FAIR"
        else:
            rating = "⭐ MARGINAL"
            
        output.append(f"   Quality: {rating}")
    
    output.append("\n" + "=" * 100)
    output.append("STRATEGY BREAKDOWN")
    output.append("=" * 100)
    
    output.append("\nEdge Detection Strategies Used:")
    output.append("1. Mean Reversion (50% weight)")
    output.append("   • Extreme probabilities tend to revert to mean")
    output.append("   • Crowd often overreacts")
    
    output.append("\n2. Momentum (30% weight)")
    output.append("   • Short-term trends tend to continue")
    output.append("   • Especially relevant for crypto markets")
    
    output.append("\n3. Volatility (20% weight)")
    output.append("   • High volatility increases mean reversion")
    output.append("   • Markets near 50% are most volatile")
    
    output.append("\n" + "=" * 100)
    output.append("RISK MANAGEMENT")
    output.append("=" * 100)
    
    output.append("\nBuilt-in Safeguards:")
    output.append("• 15% convexity buffer on position sizing")
    output.append("• Maximum position: $50 per trade")
    output.append("• Skip extreme probabilities (<2% or >98%)")
    output.append("• Minimum EV filter: $0.50")
    
    output.append("\nConvexity Costs:")
    output.append("• LMSR liquidity parameter: b = 100")
    output.append("• Price impact calculated for each trade")
    output.append("• Optimal position considers slippage")
    
    output.append("\n" + "=" * 100)
    output.append("RECOMMENDATIONS")
    output.append("=" * 100)
    
    if opportunities:
        output.append("\n✅ TRADING OPPORTUNITIES IDENTIFIED")
        output.append("\nRecommended actions:")
        
        # Group by edge strength
        strong_edges = [opp for opp in opportunities if opp['edge_pct'] > 15]
        moderate_edges = [opp for opp in opportunities if 10 <= opp['edge_pct'] <= 15]
        
        if strong_edges:
            output.append(f"\nSTRONG EDGES ({len(strong_edges)} opportunities):")
            for opp in strong_edges[:3]:
                output.append(f"• {opp['outcome']} on '{opp['question'][:40]}...'")
                output.append(f"  Edge: {opp['edge_pct']:.1f}%, EV: ${opp['expected_ev_usd']:.2f}")
        
        if moderate_edges:
            output.append(f"\nMODERATE EDGES ({len(moderate_edges)} opportunities):")
            for opp in moderate_edges[:2]:
                output.append(f"• {opp['outcome']} on '{opp['question'][:40]}...'")
                output.append(f"  Edge: {opp['edge_pct']:.1f}%, EV