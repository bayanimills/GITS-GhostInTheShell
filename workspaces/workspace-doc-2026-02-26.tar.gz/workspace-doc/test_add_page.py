import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

database_id = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

payload = {
    'parent': {'database_id': database_id},
    'properties': {
        'Name': {'title': [{'text': {'content': 'Test Task'}}]},
        'Category': {'select': {'name': 'Legal'}},
        'Status': {'select': {'name': 'Not Started'}},
        'Priority': {'select': {'name': 'High'}},
        'Notes': {'rich_text': [{'text': {'content': 'Sample note'}}]},
        'Assigned To': {'rich_text': []},
        'Due Date': {'date': {'start': '2026-03-01'}},
        'Completed Date': {'date': None},
        'Documents': {'files': []},
        'Dart Task ID': {'rich_text': []},
        'Related Person': {'rich_text': []}
    }
}

print('Payload:', json.dumps(payload, indent=2))
url = 'https://api.notion.com/v1/pages'
resp = requests.post(url, headers=HEADERS, json=payload)
print(f'Status: {resp.status_code}')
print(f'Response: {resp.text}')
if resp.status_code != 200:
    try:
        print(f'Error: {resp.json()}')
    except:
        pass