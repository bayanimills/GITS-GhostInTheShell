#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Try with page_size
payload = {"page_size": 5}
resp = requests.post(f"https://api.notion.com/v1/databases/{db_id}/query", headers=headers, json=payload)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    data = resp.json()
    print(json.dumps(data, indent=2)[:1000])
else:
    print(f"Error: {resp.text}")