#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Try GET database
print("GET database...")
resp = requests.get(f"https://api.notion.com/v1/databases/{db_id}", headers=headers)
print(f"GET status: {resp.status_code}")
if resp.status_code == 200:
    print(f"Title: {resp.json().get('title', [{}])[0].get('text', {}).get('content', '')}")
    print(f"Properties: {list(resp.json().get('properties', {}).keys())}")
else:
    print(f"GET error: {resp.text[:200]}")

# Try POST query with empty dict
print("\nPOST query...")
resp = requests.post(f"https://api.notion.com/v1/databases/{db_id}/query", headers=headers, json={})
print(f"POST status: {resp.status_code}")
if resp.status_code != 200:
    print(f"POST error: {resp.text[:500]}")

# Try POST with page_size
print("\nPOST query with page_size...")
resp = requests.post(f"https://api.notion.com/v1/databases/{db_id}/query", headers=headers, json={"page_size": 5})
print(f"POST with page_size status: {resp.status_code}")
if resp.status_code != 200:
    print(f"POST error: {resp.text[:500]}")