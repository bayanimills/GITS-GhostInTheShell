#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
pid = "30ed323b-89ec-8129-8a8b-f979d5321eb4"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
}

print(f"GET page {pid}")
resp = requests.get(f"https://api.notion.com/v1/pages/{pid}", headers=headers)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    print(json.dumps(resp.json(), indent=2))
else:
    print(resp.text)