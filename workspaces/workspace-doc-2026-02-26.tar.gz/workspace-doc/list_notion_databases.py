#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

payload = {"filter": {"property": "object", "value": "data_source"}}
resp = requests.post("https://api.notion.com/v1/search", headers=headers, json=payload)
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Found {len(results)} databases:")
    for r in results:
        db_id = r['id']
        data_source_id = r.get('data_source_id', db_id)
        title = ""
        if 'title' in r:
            for t in r['title']:
                if 'text' in t:
                    title += t['text']['content']
        else:
            # try icon
            icon = r.get('icon', {})
            if 'emoji' in icon:
                title = icon['emoji']
        parent_type = r['parent']['type']
        parent_id = r['parent'].get(parent_type + '_id') or r['parent'].get('database_id') or r['parent'].get('page_id') or r['parent'].get('workspace_id')
        print(f"  - {db_id} (data_source {data_source_id}) parent {parent_type} {parent_id} '{title}'")
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)