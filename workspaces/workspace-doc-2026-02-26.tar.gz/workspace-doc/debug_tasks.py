import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
resp = client.session.get('https://app.dartai.com/api/v0/public/tasks/list', params={'limit': 2})
print('Status:', resp.status_code)
print('Body:', resp.text)
print('---')
try:
    data = resp.json()
    print(json.dumps(data, indent=2))
except:
    pass