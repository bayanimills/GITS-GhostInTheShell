#!/usr/bin/env python3
"""
Dart Public API client.
Requires environment variable DART_API_TOKEN (Bearer token).
"""

import os
import json
import sys
import yaml
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

# Load OpenAPI spec for schema reference
SPEC_PATH = Path(__file__).parent.parent / "dart_openapi.yaml"

class DartClient:
    BASE_URL = "https://app.dartai.com/api/v0/public"
    
    def __init__(self, token: Optional[str] = None):
        self.token = token or os.getenv("DART_API_TOKEN")
        if not self.token:
            raise ValueError(
                "DART_API_TOKEN environment variable not set. "
                "Set it to your Bearer token."
            )
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        resp = self.session.request(method, url, **kwargs)
        resp.raise_for_status()
        return resp.json() if resp.content else None
    
    # --- Tasks ---
    def list_tasks(self, **params) -> List[Dict]:
        """List tasks with optional filtering."""
        return self._request("GET", "/tasks/list", params=params)
    
    def get_task(self, task_id: str) -> Dict:
        """Retrieve a single task by ID."""
        response = self._request("GET", f"/tasks/{task_id}")
        return response.get("item", response)
    
    def create_task(self, title: str, **kwargs) -> Dict:
        """Create a new task."""
        payload = {"title": title, **kwargs}
        wrapped = {"item": payload}
        response = self._request("POST", "/tasks", json=wrapped)
        return response.get("item", response)
    
    def update_task(self, task_id: str, **kwargs) -> Dict:
        """Update an existing task."""
        wrapped = {"item": {"id": task_id, **kwargs}}
        response = self._request("PUT", f"/tasks/{task_id}", json=wrapped)
        return response.get("item", response)
    
    def move_task(self, task_id: str, folder_id: str) -> Dict:
        """Move task to another folder."""
        return self._request("POST", f"/tasks/{task_id}/move", json={"folder": folder_id})
    
    def attach_url_to_task(self, task_id: str, url: str, title: Optional[str] = None) -> Dict:
        """Attach a URL as an attachment to a task."""
        payload = {"url": url}
        if title:
            payload["title"] = title
        return self._request("POST", f"/tasks/{task_id}/attachments/from-url", json=payload)
    
    def track_time(self, task_id: str, minutes: int, note: Optional[str] = None) -> Dict:
        """Log time tracking entry for a task."""
        payload = {"minutes": minutes}
        if note:
            payload["note"] = note
        return self._request("POST", f"/tasks/{task_id}/time-tracking", json=payload)
    
    # --- Docs ---
    def list_docs(self, **params) -> List[Dict]:
        """List documents."""
        return self._request("GET", "/docs/list", params=params)
    
    def get_doc(self, doc_id: str) -> Dict:
        """Retrieve a single document by ID."""
        response = self._request("GET", f"/docs/{doc_id}")
        return response.get("item", response)
    
    def create_doc(self, title: str, content: str, **kwargs) -> Dict:
        """Create a new document."""
        payload = {"title": title, "content": content, **kwargs}
        wrapped = {"item": payload}
        response = self._request("POST", "/docs", json=wrapped)
        return response.get("item", response)
    
    def update_doc(self, doc_id: str, **kwargs) -> Dict:
        """Update an existing document."""
        wrapped = {"item": kwargs}
        response = self._request("PUT", f"/docs/{doc_id}", json=wrapped)
        return response.get("item", response)
    
    # --- Comments ---
    def list_comments(self, **params) -> List[Dict]:
        """List comments (requires task_id filter)."""
        return self._request("GET", "/comments/list", params=params)
    
    def create_comment(self, task_id: str, text: str, **kwargs) -> Dict:
        """Create a comment on a task."""
        payload = {"task": task_id, "text": text, **kwargs}
        wrapped = {"item": payload}
        response = self._request("POST", "/comments", json=wrapped)
        return response.get("item", response)
    
    # --- Folders ---
    def get_folder(self, folder_id: str) -> Dict:
        """Retrieve folder by ID."""
        response = self._request("GET", f"/folders/{folder_id}")
        return response.get("item", response)
    
    def update_folder(self, folder_id: str, **kwargs) -> Dict:
        """Update folder."""
        wrapped = {"item": kwargs}
        response = self._request("PUT", f"/folders/{folder_id}", json=wrapped)
        return response.get("item", response)
    
    # --- Views ---
    def get_view(self, view_id: str) -> Dict:
        """Retrieve view by ID."""
        response = self._request("GET", f"/views/{view_id}")
        return response.get("item", response)
    
    def update_view(self, view_id: str, **kwargs) -> Dict:
        """Update view."""
        wrapped = {"item": kwargs}
        response = self._request("PUT", f"/views/{view_id}", json=wrapped)
        return response.get("item", response)
    
    # --- Utility ---
    def health(self) -> bool:
        """Check if API is accessible and token is valid."""
        try:
            self._request("GET", "/config")
            return True
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                return False
            raise
    
    def load_spec(self) -> Dict:
        """Load OpenAPI spec as dict."""
        with open(SPEC_PATH, "r") as f:
            return yaml.safe_load(f)


def main():
    """Simple CLI for testing."""
    if len(sys.argv) < 2:
        print("Usage: dart_client.py <command> [args]")
        print("Commands: health, list-tasks, create-task <title>, get-task <id>")
        sys.exit(1)
    
    client = DartClient()
    cmd = sys.argv[1]
    
    try:
        if cmd == "health":
            ok = client.health()
            print("Healthy" if ok else "Unauthorized")
        elif cmd == "list-tasks":
            tasks = client.list_tasks()
            print(json.dumps(tasks, indent=2))
        elif cmd == "create-task":
            if len(sys.argv) < 3:
                print("Missing title")
                sys.exit(1)
            title = sys.argv[2]
            task = client.create_task(title)
            print(json.dumps(task, indent=2))
        elif cmd == "get-task":
            if len(sys.argv) < 3:
                print("Missing task ID")
                sys.exit(1)
            task = client.get_task(sys.argv[2])
            print(json.dumps(task, indent=2))
        else:
            print(f"Unknown command: {cmd}")
    except requests.exceptions.HTTPError as e:
        print(f"HTTP error: {e.response.status_code} - {e.response.text}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()