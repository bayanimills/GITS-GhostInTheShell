#!/usr/bin/env python3
import os
import requests
import json
import time

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

patient_tasks_db = "37691f15-655f-4a54-a3eb-915692442433"
resp = requests.get(f"https://api.notion.com/v1/databases/{patient_tasks_db}", headers=headers)
if resp.status_code != 200:
    print(f"Error fetching database: {resp.text}")
    sys.exit(1)
db = resp.json()
data_source_id = db["data_sources"][0]["id"]
print(f"Data source ID: {data_source_id}")

# 1. Add a test page
payload = {
    "parent": {"database_id": patient_tasks_db},
    "properties": {
        "Name": {"title": [{"text": {"content": "Test Task"}}]},
        "Status": {"select": {"name": "To-do"}},
        "Dart Task ID": {"rich_text": [{"text": {"content": "test123"}}]},
        "Last Synced": {"date": {"start": "2026-02-21T05:30:00Z"}}
    }
}
resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
print(f"Add page status: {resp.status_code}")
if resp.status_code >= 400:
    print(resp.text)
    sys.exit(1)
page = resp.json()
page_id = page["id"]
print(f"Created page {page_id}")
time.sleep(1)  # allow propagation

# 2. Query with filter
url = f"https://api.notion.com/v1/data_sources/{data_source_id}/query"
filter_payload = {
    "filter": {
        "property": "Dart Task ID",
        "rich_text": {"contains": "test123"}
    }
}
print(f"\nQuery filter payload: {json.dumps(filter_payload, indent=2)}")
resp = requests.post(url, headers=headers, json=filter_payload)
print(f"Filter query status: {resp.status_code}")
if resp.status_code == 200:
    data = resp.json()
    print(f"Results: {len(data.get('results', []))}")
    for r in data.get("results", []):
        print(json.dumps(r, indent=2))
else:
    print(resp.text)

# 3. Query without filter to see all
print("\n--- Query all ---")
resp = requests.post(url, headers=headers, json={})
if resp.status_code == 200:
    data = resp.json()
    print(f"Total entries: {len(data.get('results', []))}")
else:
    print(resp.text)