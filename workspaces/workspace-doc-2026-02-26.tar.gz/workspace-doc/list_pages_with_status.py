#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
                     headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Error: {resp.text}")
    exit(1)

pages = resp.json().get('results', [])
print(f"Total pages in query: {len(pages)}")
print("")
for page in pages:
    pid = page['id']
    archived = page.get('archived', False)
    props = page.get('properties', {})
    name_obj = props.get('Name', {}).get('title', [])
    name = name_obj[0].get('text', {}).get('content', '').strip() if name_obj else 'Unknown'
    notes_obj = props.get('Notes', {}).get('rich_text', [])
    notes = notes_obj[0].get('text', {}).get('content', '') if notes_obj else ''
    website = props.get('Website', {}).get('url', '')
    is_real = ('agedcareguide.com.au' in website) or ('Source: agedcareguide.com.au' in notes)
    print(f"{name}")
    print(f"  ID: {pid}")
    print(f"  Archived: {archived}")
    print(f"  Real: {is_real}")
    print(f"  Website: {website}")
    print()