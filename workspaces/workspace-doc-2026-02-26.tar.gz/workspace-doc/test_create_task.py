import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
payload = {
    'title': 'Test EOL Task',
    'dartboard': 'Edward Mills/Tasks',
    'tags': ['patient-edward-mills', 'end-of-life', 'test'],
    'dueAt': '2026-03-01'
}
print('Payload:', json.dumps(payload, indent=2))
try:
    resp = client.session.post('https://app.dartai.com/api/v0/public/tasks',
                               json={'item': payload})
    print('Status:', resp.status_code)
    print('Response:', resp.text)
except Exception as e:
    print('Error:', e)