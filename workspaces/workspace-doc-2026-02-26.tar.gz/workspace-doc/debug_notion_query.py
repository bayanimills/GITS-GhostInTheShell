#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Database IDs
patient_tasks_db = "37691f15-655f-4a54-a3eb-915692442433"
# Get data source ID
resp = requests.get(f"https://api.notion.com/v1/databases/{patient_tasks_db}", headers=headers)
if resp.status_code != 200:
    print(f"Error fetching database: {resp.text}")
    sys.exit(1)
db = resp.json()
data_source_id = db["data_sources"][0]["id"]
print(f"Data source ID: {data_source_id}")
print(f"Database title: {db['title'][0]['text']['content']}")

# Get data source properties
resp2 = requests.get(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers)
if resp2.status_code == 200:
    ds = resp2.json()
    print("Data source properties:")
    for key, val in ds.get("properties", {}).items():
        print(f"  {key}: {val}")
else:
    print(f"Error fetching data source: {resp2.text}")

# Try a simple query with no filter
url = f"https://api.notion.com/v1/data_sources/{data_source_id}/query"
payload = {}
resp3 = requests.post(url, headers=headers, json=payload)
print(f"\nQuery (no filter) status: {resp3.status_code}")
if resp3.status_code == 200:
    data = resp3.json()
    results = data.get("results", [])
    print(f"Number of entries: {len(results)}")
    if results:
        first = results[0]
        print("First entry:")
        print(json.dumps(first, indent=2))
else:
    print(resp3.text)