#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "30dd323b-89ec-8152-99a3-c4d72376bdeb"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/databases/{db_id}/query", headers=headers, json={})
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Found {len(results)} pages")
    if results:
        page = results[0]
        props = page.get('properties', {})
        print("Property keys:", list(props.keys()))
        for k, v in props.items():
            print(f"\n{k}:")
            print(json.dumps(v, indent=2)[:200])
else:
    print(f"Error {resp.status_code}: {resp.text[:500]}")