# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.

## AgentMail

- **Inbox:** `ewm-contact@agentmail.to` (display name "Aloysius Bexley")
- **API key:** `AGENTMAIL_API_KEY` environment variable
- **Python SDK:** `agentmail` (installed in workspace‑aria venv)
- **Monitor script:** `scripts/monitor_agentmail.py`
- **Send script:** `scripts/send_agentmail.py`
- **State file:** `state/agentmail_last_seen.txt`
- **Cron job:** AgentMail Monitor (removed as of 2026‑02‑21)
- **Usage:** Monitor for new emails; notifications sent to Telegram.
