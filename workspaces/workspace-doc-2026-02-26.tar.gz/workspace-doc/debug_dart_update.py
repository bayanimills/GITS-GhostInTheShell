#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
stroke_id = 'YhH8uggrObRf'

task = client.get_task(stroke_id)
print("Current description length:", len(task.get('description', '')))
print("First 200 chars:", repr(task.get('description', '')[:200]))
print("Has 'stroke_event_data'?", 'stroke_event_data' in task.get('description', ''))

# Try update with minimal change
new_desc = task.get('description', '') + "\n\n*JSON block appended*"
print("\nAttempting update...")
try:
    updated = client.update_task(stroke_id, description=new_desc)
    print("✅ Update succeeded")
except Exception as e:
    print(f"❌ Update failed: {e}")
    if hasattr(e, 'response'):
        print(f"Response status: {e.response.status_code}")
        print(f"Response body: {e.response.text[:500]}")