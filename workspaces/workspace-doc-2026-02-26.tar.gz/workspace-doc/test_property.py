#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

payload = {
    "parent": {"database_id": db_id},
    "properties": {
        "Name": {"title": [{"text": {"content": "Test with Service Type"}}]},
        "Service Type": {"select": {"name": "Nursing Home"}}
    }
}

resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
print(resp.status_code)
print(resp.text[:500])