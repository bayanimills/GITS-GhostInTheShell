import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient

client = DartClient()
tasks = client.list_tasks(limit=5)
print(f'Found {len(tasks)} tasks')
for i, t in enumerate(tasks):
    print(f'{i+1}. {t.get("title")} (id: {t.get("id")})')
    print(f'   folder: {t.get("folder")}')
    print(f'   tags: {t.get("tags")}')
    print()