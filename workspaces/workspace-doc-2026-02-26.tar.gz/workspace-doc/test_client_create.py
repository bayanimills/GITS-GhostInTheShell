import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
task = client.create_task(
    title='Test Client Create',
    dartboard='Edward Mills/Tasks',
    tags=['patient-edward-mills', 'test'],
    dueAt='2026-03-01'
)
print(json.dumps(task, indent=2))