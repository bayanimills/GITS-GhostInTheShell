#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
}

resp = requests.get(f"https://api.notion.com/v1/databases/{db_id}", headers=headers)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    data = resp.json()
    print(f"Title: {data.get('title', [{}])[0].get('text', {}).get('content', '')}")
    print(f"Properties: {list(data.get('properties', {}).keys())}")
else:
    print(f"Error: {resp.text}")