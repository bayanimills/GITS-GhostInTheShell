#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

db_id = "84d36add-88f4-43df-a1bf-f9d7e99cf23f"
resp = requests.get(f"https://api.notion.com/v1/databases/{db_id}", headers=headers)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    db = resp.json()
    print("Keys:", db.keys())
    if 'properties' in db:
        print("Properties:")
        for key, val in db['properties'].items():
            print(f"  {key}: {val}")
    else:
        print("No properties field")
    # print(json.dumps(db, indent=2))
else:
    print(resp.text)