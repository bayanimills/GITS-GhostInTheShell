---
name: nighttime-autonomous-work
version: 1.0.0
description: Autonomous nighttime task execution with persistent tracking and periodic check-ins. Enables agents to work through queued tasks during overnight hours with safety boundaries and progress tracking.
metadata:
  openclaw:
    emoji: "🌙"
    category: automation
    requires:
      bins: ["python3", "cron"]
---

# Nighttime Autonomous Work Skill 🌙

## Purpose
Enables agents to autonomously execute queued tasks during nighttime hours (23:00-07:00 local time) with persistent tracking, periodic check-ins every 2 hours, and safety boundaries that prevent destructive actions or external communications.

## When to Use This Skill
Use this skill when:
- You have approved autonomous work to perform during overnight hours
- You need persistent tracking of task completion across multiple check-ins
- You want to ensure safety boundaries are respected (internal optimization only)
- You need to integrate with the agent-autonomy-kit task queue system

## When NOT to Use This Skill
- For time-sensitive tasks requiring immediate human review
- For tasks involving external communications or destructive actions
- When working outside the designated nighttime hours (23:00-07:00)
- For one-off tasks better handled through direct execution

## Core Concepts

### Governance Gate Policy (AWS3 Production)
**Status**: Applied as of AWS3 production release (2026-02-24)
- **Governance gates are deprecated** for AWS3 production. 
- **No /gov_* dependencies**: All `/gov_*` invocation dependencies have been removed from AWS execution paths.
- **No blocking on governance**: AWS task execution does not block on governance plugin checks.
- **AWS-native safety only**: Safety maintained via:
  - Task safety checks (internal/non-destructive)
  - Permission levels (presence-aware graduated autonomy)
  - Retry/backoff mechanisms with circuit‑breaker
  - Status telemetry (human‑visible monitoring)
- **Documentation updated**: All references to governance gating removed from AWS documentation.
- **Validation**: `autonomous-check.py` compiles and runs without governance dependencies.

### 1. Persistent Task Tracking
- `nighttime-activities.md` file tracks all tasks with status (pending, in-progress, completed, blocked)
- Each task includes timestamps (created, started, completed), priority, and context
- File is updated after each task execution

### 2. Periodic Check-Ins
- Cron job runs every 2 hours during nighttime window (23:00, 01:00, 03:00, 05:00)
- Each check-in reads `nighttime-activities.md`, picks next pending task, executes it
- Progress is logged to memory file and task status updated

### 3. Safety Boundaries
- **Internal only**: No external communications, API calls, or config changes
- **Non-destructive**: No file deletions, permission changes, or destructive operations
- **Rollback capability**: All file changes tracked with ability to revert
- **Time-bound**: Only operates within designated nighttime window

### 4. Integration with Agent-Autonomy-Kit
- Can pull tasks from `tasks/QUEUE.md` if `nighttime-activities.md` is empty
- Follows similar Ready/In Progress/Blocked/Done status model
- Compatible with proactive heartbeat patterns

## Templates & Tools

### Nighttime Activities Template (`nighttime-activities.md`)
```markdown
# Nighttime Autonomous Work - [DATE]

## Summary
- **Status**: [Active/Completed]
- **Last check-in**: [TIMESTAMP]
- **Tasks completed**: X of Y
- **Next check-in**: [TIMESTAMP]

## Tasks

### [PRIORITY] [TASK TITLE]
- **Status**: pending/in-progress/completed/blocked
- **Created**: [TIMESTAMP]
- **Started**: [TIMESTAMP]
- **Completed**: [TIMESTAMP]
- **Description**: [Brief task description]
- **Context**: [Relevant context or references]
- **Safety check**: [Internal/non-destructive verified]

### [Example Task]
- **Status**: completed
- **Created**: 2026-02-22 22:36 AEST
- **Started**: 2026-02-22 23:00 AEST  
- **Completed**: 2026-02-22 23:45 AEST
- **Description**: Update Kaira's USER.md with reasoning-framework guidance
- **Context**: PRJ-20260222-7143 Systematic Reasoning Protocol Rollout
- **Safety check**: internal/non-destructive verified
```

### Nighttime Check Script (`nighttime-check.py`)
```python
#!/usr/bin/env python3
"""
Nighttime autonomous work check-in script.
Runs every 2 hours during nighttime window (23:00-07:00).
"""
import sys
import os
import datetime
import subprocess
from pathlib import Path

# Configuration
WORKSPACE = os.environ.get("OPENCLAW_WORKSPACE", "/home/agent/.openclaw/workspace")
ACTIVITIES_FILE = Path(WORKSPACE) / "nighttime-activities.md"
MEMORY_DIR = Path(WORKSPACE) / "memory"
CRON_LOG = Path(WORKSPACE) / "logs" / "nighttime-check.log"

def main():
    """Main check-in function."""
    # 1. Verify we're in nighttime window (23:00-07:00 local time)
    if not in_nighttime_window():
        print("Outside nighttime window (23:00-07:00). Exiting.")
        return 0
    
    # 2. Read activities file, find next pending task
    task = get_next_pending_task()
    if not task:
        print("No pending tasks found.")
        return 0
    
    # 3. Execute task with safety boundaries
    result = execute_task_safely(task)
    
    # 4. Update activities file and log to memory
    update_task_status(task, result)
    log_to_memory(task, result)
    
    return 0 if result["success"] else 1

if __name__ == "__main__":
    sys.exit(main())
```

## Step-by-Step Workflow

### 1. Initial Setup
```bash
# Clone/copy skill to your workspace
cp -r /home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/* .

# Create nighttime-activities.md from template
cp templates/nighttime-activities.md nighttime-activities.md

# Customize with your tasks
nano nighttime-activities.md

# Install cron job
./setup-cron.sh
```

### 2. Daily Preparation (Evening)
```bash
# Review and update nighttime-activities.md with next day's tasks
# Ensure all tasks respect safety boundaries (internal/non-destructive)
# Verify cron job is active: crontab -l | grep nighttime-check
```

### 3. Nighttime Execution (Autonomous)
- Cron triggers `nighttime-check.py` every 2 hours (23:00, 01:00, 03:00, 05:00)
- Script picks next pending task, executes it with safety checks
- Updates `nighttime-activities.md` and logs to `memory/YYYY-MM-DD.md`
- Continues until all tasks complete or morning arrives (07:00)

### 4. Morning Review
```bash
# Check completion status
grep -A5 "## Summary" nighttime-activities.md

# Review memory log for details
tail -20 memory/$(date +%Y-%m-%d).md

# Plan next evening's tasks based on progress
```

## Integration with OpenClaw Ecosystem

### Memory Framework
- Each task execution logged to `memory/YYYY-MM-DD.md` with `#nighttime-work` tag
- Summary of nighttime work added to daily memory entry
- Failed tasks flagged for morning review

### File-Editing Protocol
- All file changes made during nighttime work include descriptive comments
- Changes are reversible with backup copies created before modification
- Follows comment-consistency patterns from file-editing-protocol skill

### Project Management
- Complex nighttime work items can reference project IDs (e.g., `PRJ-20260222-7143`)
- Progress tracked against project milestones
- Nighttime work can include project-specific tasks (template updates, documentation)

### Agent Coordination
- Kaira agent manages versioning and rollout of this skill
- Updates to `WORKFLOW_AUTO.md` templates communicated to Kaira
- Multi-agent nighttime coordination possible (different agents, different tasks)

## Safety Protocols

### Execution Boundaries
1. **Time boundary**: Only 23:00-07:00 local time
2. **Action boundary**: Internal optimization only (no external comms)
3. **Destruction boundary**: No deletions, permission changes, or irreversible actions
4. **Scope boundary**: Only within workspace directory (no system changes)

### Emergency Stop
- Remove cron job: `crontab -e` and delete nighttime-check line
- Delete `nighttime-activities.md` to halt all pending work
- Manual intervention via direct session access

### Rollback Procedure
```bash
# View backup of changed files
find /home/agent/.openclaw/workspace -name "*.backup.*" -mtime -1

# Restore from backup
cp file.backup.12345678 file
```

## Cron Configuration

### Default Schedule
```cron
# Nighttime autonomous work check-ins
0 23,1,3,5 * * * cd /home/agent/.openclaw/workspace && python3 skills/nighttime-autonomous-work/nighttime-check.py >> logs/nighttime-check.log 2>&1
```

### Installation Script (`setup-cron.sh`)
```bash
#!/bin/bash
# Adds nighttime-check cron job to current user's crontab
CRON_LINE="0 23,1,3,5 * * * cd /home/agent/.openclaw/workspace && python3 skills/nighttime-autonomous-work/nighttime-check.py >> logs/nighttime-check.log 2>&1"
(crontab -l 2>/dev/null | grep -v "nighttime-check"; echo "$CRON_LINE") | crontab -
echo "Nighttime autonomous work cron job installed."
```

## Version History
- **1.0.0** (2026-02-22): Initial release with persistent tracking, safety boundaries, cron integration
- **Future**: Integration with agent-autonomy-kit, multi-agent coordination, dashboard reporting

---
*Created as part of PRJ-20260222-7143 Systematic Reasoning Protocol Rollout*
*Maintainer: The Architect (main agent)*
*Rollout coordination: Kaira (delegation agent)*