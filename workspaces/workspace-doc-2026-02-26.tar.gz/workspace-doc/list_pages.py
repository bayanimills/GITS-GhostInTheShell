#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query", headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Failed: {resp.text}")
    exit(1)

pages = resp.json().get('results', [])
print(f"Total pages: {len(pages)}")
for page in pages:
    props = page.get('properties', {})
    name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', '')
    address = props.get('Address', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
    suburb = props.get('Suburb', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
    postcode = props.get('Postcode', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
    print(f"{name}")
    print(f"  Address: {address}")
    print(f"  Suburb: {suburb}")
    print(f"  Postcode: {postcode}")
    print()