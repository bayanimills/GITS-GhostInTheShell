import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

parent_page_id = '30dd323b-89ec-8064-ba6e-c5ca7689ed67'

# Minimal properties
properties = {
    'Name': {'title': {}},
    'Status': {
        'select': {
            'options': [
                {'name': 'Todo', 'color': 'red'},
                {'name': 'Done', 'color': 'green'}
            ]
        }
    }
}

payload = {
    'parent': {'page_id': parent_page_id},
    'title': [{'text': {'content': 'Test Database'}}],
    'properties': properties,
    'is_inline': True
}

url = 'https://api.notion.com/v1/data_sources'
resp = requests.post(url, headers=HEADERS, json=payload)
print(f'Status: {resp.status_code}')
print(f'Response: {resp.text}')
if resp.status_code != 200:
    print(f'Error: {resp.json()}')