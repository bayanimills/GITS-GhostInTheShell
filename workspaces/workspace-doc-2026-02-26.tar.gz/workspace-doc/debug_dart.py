#!/usr/bin/env python3
import os
import requests
import json

env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val

token = os.getenv("DART_API_TOKEN")
if not token:
    print("No token")
    exit(1)

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json",
}
resp = requests.get("https://app.dartai.com/api/v0/public/tasks/list", headers=headers)
print(f"Status: {resp.status_code}")
print(resp.text)
# try with limit param
resp2 = requests.get("https://app.dartai.com/api/v0/public/tasks/list?limit=5", headers=headers)
print("\nWith limit:")
print(resp2.text)