#!/usr/bin/env python3
import os
import requests
import json

token = os.environ.get('DART_API_TOKEN')
if not token:
    print("No token")
    exit(1)

stroke_id = 'YhH8uggrObRf'
url = f'https://app.dartai.com/api/v0/public/tasks/{stroke_id}'
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json',
}

# Get current task
resp = requests.get(url, headers=headers)
task = resp.json().get('item', resp.json())
desc = task.get('description', '')
print(f"Current desc length: {len(desc)}")

# Try update with id in item
new_desc = desc + "\n\n*Test append*"
payload = {
    "item": {
        "id": stroke_id,
        "description": new_desc
    }
}
print("Payload:", json.dumps(payload, indent=2))
resp = requests.put(url, headers=headers, json=payload)
print(f"Status: {resp.status_code}")
if resp.status_code != 200:
    print(f"Error: {resp.text}")
else:
    print("Success")