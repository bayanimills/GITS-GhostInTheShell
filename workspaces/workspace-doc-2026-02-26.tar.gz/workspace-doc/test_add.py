#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

database_id = "84d36add-88f4-43df-a1bf-f9d7e99cf23f"

payload = {
    "parent": {"database_id": database_id},
    "properties": {
        "Name": {"title": [{"text": {"content": "Test Medication"}}]},
        "Dose": {"rich_text": [{"text": {"content": "5 mg"}}]},
        "Frequency": {"select": {"name": "daily"}},
        "Prescribing Doctor": {"rich_text": [{"text": {"content": "Dr. Test"}}]},
        "Status": {"select": {"name": "Active"}}
    }
}

resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
print(f"Status: {resp.status_code}")
if resp.status_code >= 400:
    print(resp.text)
else:
    print("Success")
    print(json.dumps(resp.json(), indent=2))