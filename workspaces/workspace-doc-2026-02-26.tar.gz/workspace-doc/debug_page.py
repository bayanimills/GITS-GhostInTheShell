#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query", headers=headers, json={"page_size": 1})
if resp.status_code == 200:
    data = resp.json()
    page = data['results'][0]
    print(json.dumps(page, indent=2))
else:
    print(resp.text)