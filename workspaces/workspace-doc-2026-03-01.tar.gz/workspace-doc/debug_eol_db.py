#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

response = requests.post(
    f'https://api.notion.com/v1/databases/{DATABASE_ID}/query',
    headers=headers,
    json={}
)

if response.status_code != 200:
    print(f"Error: {response.status_code} {response.text}")
    exit(1)

data = response.json()
results = data.get('results', [])
print(f"Total pages: {len(results)}")
for i, page in enumerate(results[:3]):
    print(f"\nPage {i}:")
    print(f"  ID: {page['id']}")
    props = page.get('properties', {})
    for key, val in props.items():
        print(f"  {key}: {val.get('type')}")
        if val.get('type') == 'title':
            title = val.get('title', [{}])[0].get('plain_text', '')
            print(f"    -> {title}")
        elif val.get('type') == 'select':
            select = val.get('select', {})
            if select:
                print(f"    -> {select.get('name')}")
        elif val.get('type') == 'date':
            date = val.get('date', {})
            if date:
                print(f"    -> {date.get('start')}")

# Count duplicates
task_counts = {}
for page in results:
    props = page.get('properties', {})
    task = props.get('Task', {}).get('title', [{}])[0].get('plain_text', '')
    task_counts[task] = task_counts.get(task, 0) + 1

print("\nDuplicate tasks:")
for task, count in task_counts.items():
    if count > 1:
        print(f"  {task}: {count} times")