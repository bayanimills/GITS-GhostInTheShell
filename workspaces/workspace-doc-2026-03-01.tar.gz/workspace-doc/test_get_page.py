#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
page_id = '30ed323b-89ec-81b2-a4c8-c63260027302'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28'
}

url = f'https://api.notion.com/v1/pages/{page_id}'
print(f"GET {url}")
response = requests.get(url, headers=headers)
print(f"Status: {response.status_code}")
if response.status_code == 200:
    data = response.json()
    print(f"Page properties keys: {list(data.get('properties', {}).keys())}")
else:
    print(f"Response: {response.text}")