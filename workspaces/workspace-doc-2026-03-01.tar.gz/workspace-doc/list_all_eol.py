#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

response = requests.post(
    f'https://api.notion.com/v1/databases/{DATABASE_ID}/query',
    headers=headers,
    json={}
)

if response.status_code != 200:
    print(f"Error: {response.status_code} {response.text}")
    exit(1)

data = response.json()
results = data.get('results', [])
print(f"Total tasks: {len(results)}")
print()
for page in results:
    props = page.get('properties', {})
    task = props.get('Task', {}).get('title', [{}])[0].get('plain_text', '')
    status = props.get('Status', {}).get('select', {})
    status_name = status.get('name') if status else 'None'
    due = props.get('Due Date', {}).get('date', {})
    due_date = due.get('start') if due else 'None'
    priority = props.get('Priority', {}).get('select', {})
    priority_name = priority.get('name') if priority else 'None'
    print(f"{task} | Status: {status_name} | Due: {due_date} | Priority: {priority_name}")