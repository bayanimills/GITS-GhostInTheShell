#!/usr/bin/env python3
import os
import requests
import json

DART_API_TOKEN = os.environ.get('DART_API_TOKEN', 'dsa_a7b1005833763314be91a023ad521d628e98f9413932f6a0a3e6fdd52f807ae3')
BASE_URL = 'https://app.dartai.com/api/v0/public'

headers = {
    'Authorization': f'Bearer {DART_API_TOKEN}',
    'Content-Type': 'application/json'
}

tid = 'v9xc8FDPj37G'
response = requests.get(f'{BASE_URL}/tasks/{tid}', headers=headers)
print(f"Status: {response.status_code}")
print(f"Headers: {response.headers}")
print(f"Raw content: {response.text}")
try:
    data = response.json()
    print(f"JSON keys: {list(data.keys())}")
    if 'item' in data:
        print(f"Item keys: {list(data['item'].keys())}")
        print(f"Item: {json.dumps(data['item'], indent=2)}")
    else:
        print(f"Data: {json.dumps(data, indent=2)}")
except:
    pass