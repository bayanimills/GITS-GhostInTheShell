#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

response = requests.post(
    f'https://api.notion.com/v1/databases/{DATABASE_ID}/query',
    headers=headers,
    json={}
)

if response.status_code != 200:
    print(f"Error: {response.status_code} {response.text}")
    exit(1)

data = response.json()
results = data.get('results', [])
print(f"Found {len(results)} tasks")
if results:
    # Examine first page properties
    page = results[0]
    props = page.get('properties', {})
    print("\nProperty keys:")
    for key, val in props.items():
        print(f"  {key}: {val.get('type', 'unknown')}")
    print("\nSample task:")
    task_name = props.get('Task', {}).get('title', [{}])[0].get('plain_text', '')
    print(f"Task: {task_name}")
    for key, val in props.items():
        if val.get('type') == 'select':
            select_val = val.get('select', {}).get('name')
            print(f"{key}: {select_val}")
        elif val.get('type') == 'date':
            date_val = val.get('date', {}).get('start')
            print(f"{key}: {date_val}")
        elif val.get('type') == 'title':
            pass
        else:
            print(f"{key}: {val}")