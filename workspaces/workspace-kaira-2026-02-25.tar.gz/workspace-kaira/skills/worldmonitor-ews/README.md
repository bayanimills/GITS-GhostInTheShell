# WorldMonitor EWS (Early Warning System)

Keyless MVP monitoring of public signals: earthquakes, BTC price, news keywords, outage status.

## Quick Start

1. **Clone/copy** this skill into your OpenClaw workspace.
2. **Install dependencies**:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
3. **Copy example config**:
   ```bash
   cp config.example.yaml config.yaml
   ```
4. **Edit `config.yaml`** with your thresholds, keywords, etc.
5. **Test dry‑run**:
   ```bash
   python3 worldmonitor-ews.py --config config.yaml --dry-run
   ```
6. **Integrate with OpenClaw cron** (see below).

## OpenClaw Cron Integration

Create a cron job that runs the script periodically and delivers alerts to a desired channel.

### Using OpenClaw's cron tool (JSON):
```json
{
  "schedule": {
    "kind": "cron",
    "expr": "*/5 * * * *",
    "tz": "Australia/Sydney"
  },
  "payload": {
    "kind": "exec",
    "command": "cd /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews && python3 worldmonitor-ews.py --config config.yaml --channel telegram --target '@yourchannel'",
    "background": false
  },
  "delivery": {
    "mode": "announce",
    "channel": "telegram",
    "target": "@yourchannel"
  }
}
```

### Using system cron:
Create a wrapper script `ews-cron.sh`:
```bash
#!/bin/bash
cd /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews
python3 worldmonitor-ews.py --config config.yaml --channel telegram --target "@yourchannel" >> logs/ews.log 2>&1
```
Then add to crontab (every 5 minutes):
```cron
*/5 * * * * /path/to/ews-cron.sh
```

## Signal Sources

- **USGS Earthquakes**: Past hour, magnitude ≥ warning threshold.
- **CoinGecko BTC**: 24h percentage change, thresholds for drops.
- **RSS News**: Placeholder; keyword matching (requires feedparser for full implementation).
- **Public Outage Endpoints**: GitHub Status, Cloudflare, AWS (configurable).

## Quiet‑Hours Suppression

By default, alerts are suppressed between **22:00‑07:00 Sydney time** (configurable).  
CRITICAL‑severity events bypass suppression.

## Deduplication

Events are deduplicated using a local state file (`.worldmonitor-state.json`).  
Retention period defaults to 24 hours.

## Adding API Keys (Optional)

Extend the configuration with an `api_keys` section and add new poller modules for authenticated sources.  
Store secrets in environment variables or `.env` file.

## Files

- `SKILL.md` – Full documentation
- `worldmonitor-ews.py` – Main Python script
- `config.example.yaml` – Example configuration
- `requirements.txt` – Python dependencies
- `README.md` – This quick start guide

## License

OpenClaw Skill – Use freely within OpenClaw ecosystem.