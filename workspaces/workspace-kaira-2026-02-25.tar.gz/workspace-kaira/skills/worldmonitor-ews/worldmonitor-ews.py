#!/usr/bin/env python3
"""
WorldMonitor EWS - Keyless MVP Early Warning System
Polls public signals, applies severity thresholds, suppresses quiet hours, deduplicates events.
Outputs alert/digest payloads (dry-run) or sends via OpenClaw channel.
"""

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any
from zoneinfo import ZoneInfo

import requests
import yaml

# Default config file
DEFAULT_CONFIG = "config.yaml"
# Default state file (relative to script directory)
DEFAULT_STATE_FILE = ".worldmonitor-state.json"
# Default quiet hours (22:00-07:00 Sydney)
DEFAULT_QUIET_START = "22:00"
DEFAULT_QUIET_END = "07:00"
DEFAULT_TZ = "Australia/Sydney"

# Severity levels
SEVERITY_INFO = "INFO"
SEVERITY_WARNING = "WARNING"
SEVERITY_CRITICAL = "CRITICAL"

# Mapping from source to event ID key
SOURCE_KEYS = {
    "earthquake": "id",
    "btc_price": "timestamp",
    "news": "link",
    "outage": "url",
}

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------
def load_config(config_path: str) -> Dict:
    """Load YAML configuration."""
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    # Set defaults if missing
    config.setdefault("thresholds", {})
    config.setdefault("quiet_hours", {})
    config["quiet_hours"].setdefault("enabled", True)
    config["quiet_hours"].setdefault("start", DEFAULT_QUIET_START)
    config["quiet_hours"].setdefault("end", DEFAULT_QUIET_END)
    config["quiet_hours"].setdefault("timezone", DEFAULT_TZ)
    config["quiet_hours"].setdefault("bypass_severities", [SEVERITY_CRITICAL])
    config.setdefault("deduplication", {})
    config["deduplication"].setdefault("state_file", DEFAULT_STATE_FILE)
    config["deduplication"].setdefault("retention_hours", 24)
    config.setdefault("behavior_profile", {})
    config["behavior_profile"].setdefault("user_bias", "neutral")  # risk_averse, opportunity_seeking, neutral
    config["behavior_profile"].setdefault("risk_mode", "medium")   # low, medium, high
    config["behavior_profile"].setdefault("focus_topics", [])
    config["behavior_profile"].setdefault("counter_signals_enabled", False)
    config["behavior_profile"].setdefault("quiet_hours", None)     # optional override
    config["behavior_profile"].setdefault("sensitivity", 0.5)      # 0-1 scale
    config.setdefault("output", {})
    config["output"].setdefault("dry_run", True)
    config["output"].setdefault("format", "json")
    config["output"].setdefault("include_debug", False)
    return config


# ----------------------------------------------------------------------
# Deduplication State
# ----------------------------------------------------------------------
def load_state(state_file: str) -> Dict:
    """Load deduplication and history state from JSON file."""
    path = Path(state_file)
    if not path.exists():
        return {"duplicates": {}, "history": {}}
    try:
        with open(path, "r") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        logging.warning(f"Failed to load state file {state_file}: {e}")
        return {"duplicates": {}, "history": {}}
    
    # Backward compatibility: if raw dict has no 'duplicates' key, treat entire dict as duplicates
    if "duplicates" not in raw:
        return {"duplicates": raw, "history": {}}
    # Ensure history exists
    raw.setdefault("history", {})
    return raw


def save_state(state: Dict, state_file: str) -> None:
    """Save deduplication state to JSON file."""
    path = Path(state_file)
    try:
        with open(path, "w") as f:
            json.dump(state, f, indent=2)
    except IOError as e:
        logging.error(f"Failed to save state file {state_file}: {e}")


def is_duplicate(event: Dict, source: str, state: Dict, retention_hours: int) -> bool:
    """Check if event is duplicate based on source+event_id within retention period."""
    # Get duplicates map (support both old flat state and new nested)
    duplicates = state.get("duplicates", state)
    now = time.time()
    event_id = event.get("event_id")
    if not event_id:
        # Fallback: hash of relevant fields
        import hashlib
        key = f"{source}:{json.dumps(event, sort_keys=True)}"
        event_id = hashlib.sha256(key.encode()).hexdigest()[:16]
        event["event_id"] = event_id

    state_key = f"{source}:{event_id}"
    if state_key in duplicates:
        timestamp = duplicates[state_key]
        if now - timestamp < retention_hours * 3600:
            return True
    # Not duplicate, store for future
    duplicates[state_key] = now
    # Ensure duplicates map is stored back to state (if nested)
    if "duplicates" in state:
        state["duplicates"] = duplicates
    return False


# ----------------------------------------------------------------------
# Quiet Hours Logic
# ----------------------------------------------------------------------
def in_quiet_hours(config: Dict) -> bool:
    """Return True if current time is within configured quiet hours."""
    if not config["quiet_hours"]["enabled"]:
        return False
    tz = ZoneInfo(config["quiet_hours"]["timezone"])
    now = datetime.now(tz)
    start_str = config["quiet_hours"]["start"]
    end_str = config["quiet_hours"]["end"]
    # Parse times (simple HH:MM)
    start_h, start_m = map(int, start_str.split(":"))
    end_h, end_m = map(int, end_str.split(":"))
    start_time = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
    end_time = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)
    # Handle overnight window (e.g., 22:00 to 07:00)
    if start_time > end_time:
        # Window crosses midnight; current time is after start or before end
        if now >= start_time or now < end_time:
            return True
    else:
        if start_time <= now < end_time:
            return True
    return False


def should_suppress(severity: str, config: Dict, force: bool) -> bool:
    """Determine if alert should be suppressed due to quiet hours."""
    if force:
        return False
    if not in_quiet_hours(config):
        return False
    # Check if severity bypasses quiet hours
    if severity in config["quiet_hours"]["bypass_severities"]:
        return False
    return True


# ----------------------------------------------------------------------
# Signal Pollers
# ----------------------------------------------------------------------
def poll_usgs_earthquakes(config: Dict) -> List[Dict]:
    """Fetch recent earthquakes from USGS."""
    url = "https://earthquake.usgs.gov/fdsnws/event/1/query"
    params = {
        "format": "geojson",
        "starttime": (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat() + "Z",
        "minmagnitude": config["thresholds"].get("earthquake", {}).get("magnitude_warning", 4.0),
        "orderby": "time",
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        events = []
        for feat in data.get("features", []):
            props = feat["properties"]
            geometry = feat["geometry"]
            event = {
                "source": "earthquake",
                "event_id": feat["id"],
                "title": props["title"],
                "magnitude": props["mag"],
                "place": props["place"],
                "time": props["time"],
                "url": props["url"],
                "coordinates": geometry["coordinates"],
                "severity": SEVERITY_INFO,  # will be adjusted later
            }
            events.append(event)
        return events
    except requests.RequestException as e:
        logging.error(f"USGS earthquake poll failed: {e}")
        return []


def poll_coingecko_btc(config: Dict) -> List[Dict]:
    """Fetch BTC price and 24h change from CoinGecko."""
    url = "https://api.coingecko.com/api/v3/simple/price"
    params = {
        "ids": "bitcoin",
        "vs_currencies": "usd",
        "include_24hr_change": "true",
        "include_last_updated_at": "true",
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        btc = data.get("bitcoin", {})
        price = btc.get("usd")
        change_24h = btc.get("usd_24h_change")
        last_updated = btc.get("last_updated_at")
        if price is None or change_24h is None:
            return []
        event = {
            "source": "btc_price",
            "event_id": str(last_updated) if last_updated else str(int(time.time())),
            "price_usd": price,
            "change_24h_percent": change_24h,
            "last_updated": last_updated,
            "severity": SEVERITY_INFO,
        }
        return [event]
    except requests.RequestException as e:
        logging.error(f"CoinGecko BTC poll failed: {e}")
        return []


def poll_rss_news(config: Dict) -> List[Dict]:
    """Placeholder: would parse RSS feeds for keywords."""
    # For MVP, we simulate a single news item.
    # In a real implementation, use feedparser or similar.
    keywords = config["thresholds"].get("news", {}).get("keywords", [])
    if not keywords:
        return []
    # Simulate finding a news item containing keyword "earthquake"
    # This is a placeholder; replace with actual RSS parsing.
    event = {
        "source": "news",
        "event_id": str(int(time.time())),
        "title": "Simulated news: Major earthquake hits region",
        "link": "https://example.com/news/123",
        "description": "Placeholder for actual RSS content.",
        "keywords_matched": ["earthquake"],
        "severity": SEVERITY_INFO,
    }
    return [event]


def poll_public_outage(config: Dict) -> List[Dict]:
    """Poll public outage endpoints (e.g., GitHub Status)."""
    endpoints = config["thresholds"].get("outage", {}).get("endpoints", [])
    events = []
    for url in endpoints:
        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            # Handle list responses (some endpoints return list)
            if isinstance(data, list) and len(data) > 0:
                item = data[0]
            else:
                item = data
            # Extract status indicator from common patterns
            status = "unknown"
            if isinstance(item, dict):
                # GitHub style: status.indicator
                status_obj = item.get("status")
                if isinstance(status_obj, dict):
                    status = status_obj.get("indicator", "unknown")
                elif isinstance(status_obj, str):
                    status = status_obj
                # Fallback: top-level indicator
                if status == "unknown":
                    status = item.get("indicator", "unknown")
            description = item.get("page", {}).get("description", "") if isinstance(item, dict) else ""
            updated = item.get("page", {}).get("updated_at", "") if isinstance(item, dict) else ""
            event = {
                "source": "outage",
                "event_id": url + ":" + str(updated),
                "url": url,
                "status": status,
                "description": description,
                "updated": updated,
                "severity": SEVERITY_INFO,
            }
            events.append(event)
        except requests.RequestException as e:
            logging.error(f"Outage endpoint {url} failed: {e}")
    return events


# ----------------------------------------------------------------------
# Severity Evaluation
# ----------------------------------------------------------------------
def evaluate_severity(event: Dict, config: Dict) -> str:
    """Assign severity based on thresholds."""
    source = event["source"]
    thresholds = config["thresholds"].get(source, {})
    if source == "earthquake":
        mag = event["magnitude"]
        crit = thresholds.get("magnitude_critical", 6.0)
        warn = thresholds.get("magnitude_warning", 4.5)
        if mag >= crit:
            return SEVERITY_CRITICAL
        if mag >= warn:
            return SEVERITY_WARNING
        return SEVERITY_INFO
    elif source == "btc_price":
        change = event["change_24h_percent"]
        crit = thresholds.get("percent_change_critical", 15.0)
        warn = thresholds.get("percent_change_warning", 5.0)
        # Negative change (drop) is concerning
        if change <= -crit:
            return SEVERITY_CRITICAL
        if change <= -warn:
            return SEVERITY_WARNING
        return SEVERITY_INFO
    elif source == "news":
        # If keyword matched, treat as WARNING (could be configurable)
        if event.get("keywords_matched"):
            return SEVERITY_WARNING
        return SEVERITY_INFO
    elif source == "outage":
        status = event.get("status", "").lower()
        if status in ["critical", "major"]:
            return SEVERITY_CRITICAL
        if status in ["minor", "maintenance"]:
            return SEVERITY_WARNING
        return SEVERITY_INFO
    else:
        return SEVERITY_INFO


# ----------------------------------------------------------------------
# Output & Delivery
# ----------------------------------------------------------------------
def create_alert_payload(event: Dict) -> Dict:
    """Create a single alert payload."""
    return {
        "type": "alert",
        "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
        "severity": event["severity"],
        "source": event["source"],
        "data": event,
    }


def create_digest_payload(events: List[Dict]) -> Dict:
    """Create a digest payload for multiple lower‑severity events."""
    return {
        "type": "digest",
        "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
        "count": len(events),
        "events": events,
    }


def output_payload(payload: Dict, config: Dict, channel: Optional[str], target: Optional[str]):
    """Output payload: print if dry‑run, else send via OpenClaw channel."""
    if config["output"]["dry_run"] or not channel or not target:
        # Dry‑run or missing channel args → print JSON
        print(json.dumps(payload, indent=2))
        # TODO: In a real OpenClaw integration you would call the channel plugin.
        # For now, logging.
        logging.info(f"Dry‑run payload: {payload['type']} with severity {payload.get('severity', 'N/A')}")
    else:
        # This is where you would invoke OpenClaw's message tool.
        # For MVP, we just log.
        logging.info(f"Would send to {channel}:{target} – {payload['type']}")
        # Placeholder for actual delivery
        print(json.dumps(payload, indent=2))


# ----------------------------------------------------------------------
# Main Workflow
# ----------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="WorldMonitor EWS")
    parser.add_argument("--config", default=DEFAULT_CONFIG, help="Path to config YAML")
    parser.add_argument("--channel", help="OpenClaw channel (e.g., telegram)")
    parser.add_argument("--target", help="Channel target (e.g., '@channel')")
    parser.add_argument("--force", action="store_true", help="Ignore quiet‑hour suppression")
    parser.add_argument("--dry-run", action="store_true", help="Force dry‑run (print payloads)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    # Load config
    if not Path(args.config).exists():
        logging.error(f"Config file not found: {args.config}")
        sys.exit(1)
    config = load_config(args.config)
    if args.dry_run:
        config["output"]["dry_run"] = True

    # Load deduplication state
    state_file = config["deduplication"]["state_file"]
    retention = config["deduplication"]["retention_hours"]
    state = load_state(state_file)

    # Poll each source
    all_events = []
    pollers = [
        ("earthquake", poll_usgs_earthquakes),
        ("btc_price", poll_coingecko_btc),
        ("news", poll_rss_news),
        ("outage", poll_public_outage),
    ]
    for source, poller in pollers:
        events = poller(config)
        for event in events:
            event["severity"] = evaluate_severity(event, config)
            # Deduplicate
            if is_duplicate(event, source, state, retention):
                logging.debug(f"Duplicate event {event.get('event_id')} from {source}")
                continue
            all_events.append(event)

    # Save updated state
    save_state(state, state_file)

    # Split by severity
    critical_events = [e for e in all_events if e["severity"] == SEVERITY_CRITICAL]
    warning_events = [e for e in all_events if e["severity"] == SEVERITY_WARNING]
    info_events = [e for e in all_events if e["severity"] == SEVERITY_INFO]

    # Process critical events (always deliver, unless suppressed by quiet hours)
    for event in critical_events:
        if should_suppress(event["severity"], config, args.force):
            logging.info(f"Suppressed CRITICAL event during quiet hours: {event.get('title', event['source'])}")
            continue
        payload = create_alert_payload(event)
        output_payload(payload, config, args.channel, args.target)

    # Process warning events (deliver if not suppressed)
    for event in warning_events:
        if should_suppress(event["severity"], config, args.force):
            logging.debug(f"Suppressed WARNING event during quiet hours: {event.get('title', event['source'])}")
            continue
        payload = create_alert_payload(event)
        output_payload(payload, config, args.channel, args.target)

    # Bundle info events into a digest (if any)
    if info_events:
        # Suppress digest during quiet hours unless force
        if not should_suppress(SEVERITY_INFO, config, args.force):
            digest = create_digest_payload(info_events)
            output_payload(digest, config, args.channel, args.target)
        else:
            logging.debug(f"Suppressed INFO digest during quiet hours ({len(info_events)} events)")

    logging.info(f"Processing complete: {len(critical_events)} critical, {len(warning_events)} warning, {len(info_events)} info events.")


if __name__ == "__main__":
    main()