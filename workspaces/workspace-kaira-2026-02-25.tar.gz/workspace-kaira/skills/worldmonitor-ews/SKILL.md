---
name: worldmonitor-ews
version: 1.0.0
description: Keyless MVP Early Warning System (EWS) for monitoring public signals with severity thresholds, quiet-hours suppression, and deduplication. Provides alert/digest payloads for OpenClaw integration.
metadata:
  openclaw:
    emoji: "🚨"
    category: monitoring
    requires:
      bins: ["python3", "curl"]
---

# WorldMonitor EWS Skill 🚨

## Purpose
A lightweight Early Warning System that polls **keyless/public signals** (RSS/news feeds, USGS earthquakes, CoinGecko BTC price, optional public outage endpoints) and generates alerts based on configurable severity thresholds. Designed for **MVP/keyless-first** operation, with optional API-key enhancements for richer data sources.

## Scope
- **Keyless-first**: Uses only publicly accessible endpoints that require no authentication
- **Threshold-based severity**: Configurable thresholds per signal type (e.g., earthquake magnitude > 5.0, BTC price drop > 10%)
- **Quiet-hours suppression**: 22:00‑07:00 Sydney time (AEST/AEDT), with CRITICAL‑severity bypass
- **Deduplication**: Local state file prevents duplicate alerts for the same event
- **Dry‑run mode**: Outputs alert/digest payloads without sending (when no channel arguments provided)
- **OpenClaw integration**: Ready for cron‑based periodic execution and channel delivery

## When to Use This Skill
- You need a simple, self‑contained monitoring solution that works out‑of‑the‑box (no API keys)
- You want to be alerted about significant earthquakes, BTC price moves, or news matching keywords
- You need quiet‑hours suppression to avoid disturbances during sleep (22:00‑07:00 Sydney)
- You plan to integrate monitoring into OpenClaw’s cron system for regular checks

## When NOT to Use This Skill
- For high‑frequency or real‑time monitoring (polling intervals > 5 minutes)
- When you require proprietary/commercial data sources that require paid API keys (use optional enhancement)
- For mission‑critical production alerts without human verification

## Core Components

### 1. Signal Pollers
- **USGS Earthquakes** (`earthquake.usgs.gov/fdsnws/event/1/query`) – past hour, magnitude ≥ config threshold
- **CoinGecko BTC price** (`api.coingecko.com/api/v3/simple/price`) – percentage change vs. threshold
- **RSS/News placeholder** (`http://feeds.bbci.co.uk/news/rss.xml` or similar) – keyword matching
- **Public outage endpoint** (optional, e.g., `http://status.github.com/api/v2/status.json`) – status change detection

### 2. Severity Engine
Each signal is assigned a severity based on configurable thresholds:
- **INFO**: Below threshold or normal status
- **WARNING**: Threshold crossed but not critical
- **CRITICAL**: Severe threshold (e.g., magnitude ≥ 6.0, price drop ≥ 20%)

### 3. Quiet‑Hours Suppression
- **Time window**: 22:00‑07:00 Sydney time (Australia/Sydney)
- **Bypass**: CRITICAL‑severity alerts still delivered
- **Configurable**: Time range and timezone can be adjusted in config

### 4. Deduplication
- **State file**: `.worldmonitor-state.json` stores last‑seen event IDs/timestamps
- **Key**: `source` + `event_id` (or hash of relevant fields)
- **Retention**: Configurable retention period (default 24 hours)

### 5. Output Payloads
- **Alert**: Single high‑severity event with all context
- **Digest**: Batch of lower‑severity events for periodic summary
- **Format**: JSON structure ready for OpenClaw channel delivery

## Configuration

### Config Template (`config.yaml`)
```yaml
# Signal thresholds
thresholds:
  earthquake:
    magnitude_warning: 4.5
    magnitude_critical: 6.0
    regions: ["global", "pacific", "asia"]
  btc_price:
    percent_change_warning: 5.0
    percent_change_critical: 15.0
    timeframe: "1h"   # 1h, 24h, 7d
  news:
    keywords:
      - "earthquake"
      - "tsunami"
      - "outage"
      - "critical"
      - "emergency"
    sources:
      - "http://feeds.bbci.co.uk/news/rss.xml"
      - "https://www.nasa.gov/rss/dyn/breaking_news.rss"
  outage:
    endpoints:
      - "https://status.github.com/api/v2/status.json"

# Quiet hours (Sydney time)
quiet_hours:
  enabled: true
  start: "22:00"
  end: "07:00"
  timezone: "Australia/Sydney"
  bypass_severities: ["CRITICAL"]

# Deduplication
deduplication:
  state_file: ".worldmonitor-state.json"
  retention_hours: 24

# Polling intervals (seconds) – used by cron, not by script directly
polling_intervals:
  earthquake: 300
  btc_price: 300
  news: 600
  outage: 300

# Output
output:
  dry_run: true   # If true, only print payloads, don't send
  format: "json"
  include_debug: false
```

## Runnable Starter Script (`worldmonitor-ews.py`)

The main Python script implements the polling, threshold evaluation, quiet‑hours logic, deduplication, and payload generation. It is designed to be run directly for testing and via OpenClaw cron for production.

### Features
- **Safe/non‑destructive**: No deletions, only reads public endpoints and writes local state file
- **Modular pollers**: Each signal type in separate function for easy extension
- **Graceful degradation**: If a source fails, others continue
- **Detailed logging**: Console output with timestamps and severity tags

### Usage
```bash
# Dry‑run (print payloads to stdout)
python3 worldmonitor-ews.py --config config.yaml

# With channel delivery (requires OpenClaw channel arguments)
python3 worldmonitor-ews.py --config config.yaml --channel telegram --target "@yourchannel"

# Force send (ignore quiet hours)
python3 worldmonitor-ews.py --config config.yaml --force

# Help
python3 worldmonitor-ews.py --help
```

## README: Running Locally & Wiring into OpenClaw Cron

### 1. Running Locally
```bash
cd /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews
cp config.example.yaml config.yaml
# Edit config.yaml with your thresholds, keywords, etc.
python3 worldmonitor-ews.py --config config.yaml
```

The script will:
- Poll each configured source
- Apply thresholds and severity mapping
- Check quiet‑hours (unless `--force` used)
- Deduplicate against previous runs
- Output JSON payloads to stdout (dry‑run) or send via OpenClaw channel (if channel args provided)

### 2. Wiring into OpenClaw Cron
Create a cron job that runs the script periodically and delivers alerts to a desired channel.

**Example cron configuration (JSON) for OpenClaw’s cron tool:**
```json
{
  "schedule": {
    "kind": "cron",
    "expr": "*/5 * * * *",
    "tz": "Australia/Sydney"
  },
  "payload": {
    "kind": "exec",
    "command": "cd /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews && python3 worldmonitor-ews.py --config config.yaml --channel telegram --target '@yourchannel'",
    "background": false
  },
  "delivery": {
    "mode": "announce",
    "channel": "telegram",
    "target": "@yourchannel"
  }
}
```

**Simpler approach: Use a shell script and system cron**
```bash
# Create a wrapper script ews-cron.sh
#!/bin/bash
cd /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews
python3 worldmonitor-ews.py --config config.yaml --channel telegram --target "@yourchannel" >> logs/ews.log 2>&1

# Add to crontab (every 5 minutes)
*/5 * * * * /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews/ews-cron.sh
```

### 3. Testing the Integration
1. Run the script manually with `--dry-run` to verify payloads
2. Test with `--force` during quiet hours to ensure CRITICAL bypass works
3. Run a single cron iteration using `openclaw cron create` with a one‑time schedule
4. Check logs and channel for expected alerts

## Optional Integration Note: Adding API Keys Later

The MVP is designed to work without any authentication. However, you can enhance it with API keys for richer data sources:

### 1. Extend Configuration
Add an `api_keys` section to `config.yaml`:
```yaml
api_keys:
  newsapi: "your_newsapi_key"
  twitter: "bearer_token"
  custom_endpoint:
    url: "https://api.example.com/alerts"
    headers:
      Authorization: "Bearer YOUR_TOKEN"
```

### 2. Add New Poller Modules
Create new Python functions that use authenticated requests, e.g.:
```python
def poll_newsapi(api_key, keywords):
    # Use NewsAPI to get articles matching keywords
    pass

def poll_twitter(bearer_token, search_query):
    # Use Twitter API v2 recent search
    pass
```

### 3. Update Severity Logic
Define thresholds for the new sources (e.g., tweet volume spike, sentiment score).

### 4. Environment Variables for Secrets
For security, store API keys in environment variables and reference them in config:
```yaml
api_keys:
  newsapi: "${NEWSAPI_KEY}"
```
Then set `NEWSAPI_KEY` in the cron environment or a `.env` file loaded by the script.

**Important**: Never commit API keys to version control. Use `.env.example` template and keep `.env` in `.gitignore`.

## Files Created
- `SKILL.md` – This documentation
- `worldmonitor-ews.py` – Main runnable Python script
- `config.example.yaml` – Example configuration file
- `requirements.txt` – Python dependencies (requests, pyyaml, python‑dotenv)
- `README.md` – Quick start guide (optional, covered in SKILL.md)

## Validation
- Script syntax validated with `python3 -m py_compile worldmonitor-ews.py`
- Configuration validated with `yamllint config.example.yaml`
- Safe/non‑destructive: no external writes except local state file

## Next Commands to Run
1. `cd /home/agent/.openclaw/workspace-kaira/skills/worldmonitor-ews`
2. `python3 -m venv venv && source venv/bin/activate`
3. `pip install -r requirements.txt`
4. `cp config.example.yaml config.yaml`
5. Edit `config.yaml` with your thresholds/keywords
6. `python3 worldmonitor-ews.py --config config.yaml --dry-run`
7. If satisfied, set up cron as described above.

---
*Created as part of worldmonitor‑EWS MVP scaffolding*
*Maintainer: Kaira (delegation agent)*
