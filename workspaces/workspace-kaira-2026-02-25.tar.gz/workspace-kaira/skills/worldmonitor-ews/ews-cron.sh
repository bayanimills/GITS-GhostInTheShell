#!/bin/bash
# Wrapper script for WorldMonitor EWS cron execution.
# Set environment variables, activate virtualenv, run with channel args.

cd "$(dirname "$0")"

# Optional: activate virtualenv if you use one
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
fi

# Load environment variables from .env if present
if [ -f .env ]; then
    set -a
    source .env
    set +a
fi

# Run the monitor with your channel configuration
python3 worldmonitor-ews.py \
    --config config.yaml \
    --channel telegram \
    --target "@yourchannel" \
    >> logs/ews.log 2>&1

# If you want to keep dry‑run (no sending), omit --channel and --target
# python3 worldmonitor-ews.py --config config.yaml --dry-run >> logs/ews.log 2>&1