---
name: scraper-ews
version: 0.1.0
summary: Collection-only scraper layer for EWS/PDE pipelines (keyless-first, deterministic).
---

# scraper-ews

## Trigger
Run when downstream EWS/PDE pipeline needs **fresh collected events** from public sources.

Typical triggers:
- Scheduled pull (cron)
- Manual dry-run for testing
- Backfill from fixtures

## Scope (strict)
This skill is **collection layer only**:
1. Fetch (public/keyless endpoints or local fixtures)
2. Parse source payloads into records
3. Normalize into canonical event schema
4. Dedupe against local state
5. Output JSONL for downstream EWS/PDE

## Out of Scope
- No strategy, decisioning, escalation, or action recommendations
- No alert routing/channel messaging
- No risk scoring beyond simple source-derived hints

## Safety & Constraints
- Keyless-first by default
- Deterministic mode supported via fixtures (no network)
- Non-destructive (writes only to local `output/` and dedupe state file)
- Bounded retries with exponential backoff
- Per-host rate limiting

## Canonical Event Schema
Output is JSONL where each line is one canonical event:

```json
{
  "schema": "ews.pde.event.v1",
  "event_id": "string",
  "fingerprint": "sha256-hex",
  "source": "usgs|github_status|...",
  "event_type": "earthquake|service_status|...",
  "occurred_at": "ISO8601 UTC",
  "collected_at": "ISO8601 UTC",
  "title": "string",
  "summary": "string",
  "severity_hint": "info|warning|critical",
  "location": {"lat": 0.0, "lon": 0.0, "label": "optional"},
  "tags": ["string"],
  "raw_ref": "source-local reference",
  "meta": {"key": "value"}
}
```

## Files
- `scripts/run_scraper.py` – orchestrator
- `scripts/fetch.py` – fetch stage
- `scripts/parse.py` – parse stage
- `scripts/normalize.py` – canonical mapping
- `scripts/dedupe.py` – dedupe stage
- `scripts/rate_limit.py` – per-host limiter
- `scripts/backoff.py` – deterministic exponential backoff helper
- `config.template.yaml` – config template
- `fixtures/raw/*.json` – sample raw payloads
- `fixtures/expected/*.jsonl` – expected canonical outputs

## Usage
```bash
cd /home/agent/.openclaw/workspace-kaira/skills/scraper-ews
python3 scripts/run_scraper.py --config config.template.yaml --fixture --out output/events.jsonl
```

Live keyless fetch:
```bash
python3 scripts/run_scraper.py --config config.template.yaml --out output/events-live.jsonl
```

## Validation
```bash
python3 -m py_compile scripts/*.py
python3 scripts/run_scraper.py --config config.template.yaml --fixture --out output/events.jsonl
wc -l output/events.jsonl
```
