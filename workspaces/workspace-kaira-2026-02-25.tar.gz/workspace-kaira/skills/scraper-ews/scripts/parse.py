from __future__ import annotations


def parse_usgs(payload: dict) -> list[dict]:
    records: list[dict] = []
    for feat in payload.get("features", []):
        props = feat.get("properties", {})
        coords = (feat.get("geometry") or {}).get("coordinates", [None, None])
        records.append(
            {
                "source": "usgs",
                "source_id": feat.get("id"),
                "event_type": "earthquake",
                "title": props.get("title", "Earthquake"),
                "summary": props.get("place", ""),
                "occurred_ms": props.get("time"),
                "magnitude": props.get("mag"),
                "lon": coords[0],
                "lat": coords[1],
                "raw_ref": props.get("url", ""),
            }
        )
    return records


def parse_github_status(payload: dict) -> list[dict]:
    status = (payload.get("status") or {}).get("indicator", "unknown")
    desc = (payload.get("status") or {}).get("description", "")
    return [
        {
            "source": "github_status",
            "source_id": f"github:{status}",
            "event_type": "service_status",
            "title": "GitHub Status",
            "summary": desc,
            "occurred_iso": payload.get("page", {}).get("updated_at"),
            "status": status,
            "raw_ref": "https://www.githubstatus.com/api/v2/status.json",
        }
    ]


def parse_payloads(payloads: dict) -> list[dict]:
    all_records: list[dict] = []
    if "usgs" in payloads and "_error" not in payloads["usgs"]:
        all_records.extend(parse_usgs(payloads["usgs"]))
    if "github_status" in payloads and "_error" not in payloads["github_status"]:
        all_records.extend(parse_github_status(payloads["github_status"]))
    return all_records
