from __future__ import annotations

import time
from collections import defaultdict


class HostRateLimiter:
    """Simple per-host min-interval limiter."""

    def __init__(self, min_interval_seconds: float = 1.0):
        self.min_interval_seconds = max(0.0, min_interval_seconds)
        self._last = defaultdict(float)

    def wait(self, host: str) -> None:
        now = time.monotonic()
        delta = now - self._last[host]
        remain = self.min_interval_seconds - delta
        if remain > 0:
            time.sleep(remain)
        self._last[host] = time.monotonic()
