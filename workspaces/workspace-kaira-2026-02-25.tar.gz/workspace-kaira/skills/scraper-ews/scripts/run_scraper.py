#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from common import ensure_parent, load_yaml
from dedupe import dedupe, load_seen, save_seen
from fetch import fetch_fixtures, fetch_live
from normalize import normalize
from parse import parse_payloads


def main() -> int:
    ap = argparse.ArgumentParser(description="scraper-ews collection pipeline")
    ap.add_argument("--config", required=True)
    ap.add_argument("--fixture", action="store_true", help="Use local fixtures for deterministic run")
    ap.add_argument("--out", required=True, help="Output JSONL path")
    args = ap.parse_args()

    cfg = load_yaml(args.config)
    sources = cfg.get("sources", [])
    source_names = [s["name"] for s in sources]

    if args.fixture:
        payloads = fetch_fixtures(cfg["fixtures"]["raw_dir"], source_names)
    else:
        payloads = fetch_live(
            sources=sources,
            min_interval_seconds=cfg.get("network", {}).get("min_interval_seconds", 1.0),
            attempts=cfg.get("network", {}).get("attempts", 3),
            timeout_seconds=cfg.get("network", {}).get("timeout_seconds", 10),
        )

    records = parse_payloads(payloads)
    events = normalize(records)

    dedupe_file = cfg.get("dedupe", {}).get("state_file", "output/.seen.json")
    seen = load_seen(dedupe_file)
    unique = dedupe(events, seen)
    save_seen(dedupe_file, seen)

    ensure_parent(args.out)
    with open(args.out, "w", encoding="utf-8") as f:
        for event in unique:
            f.write(json.dumps(event, sort_keys=True) + "\n")

    print(json.dumps({"records": len(records), "events": len(events), "unique": len(unique), "out": args.out}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
