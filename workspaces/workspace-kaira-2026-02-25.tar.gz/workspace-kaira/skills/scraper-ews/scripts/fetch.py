from __future__ import annotations

import json
import time
from pathlib import Path
from urllib.parse import urlparse

import requests

from backoff import backoff_delays
from rate_limit import HostRateLimiter


def fetch_live(sources: list[dict], min_interval_seconds: float, attempts: int, timeout_seconds: int) -> dict:
    limiter = HostRateLimiter(min_interval_seconds=min_interval_seconds)
    out: dict[str, dict] = {}

    for source in sources:
        name = source["name"]
        url = source["url"]
        host = urlparse(url).netloc
        limiter.wait(host)
        last_err = None
        for delay in backoff_delays(attempts=attempts):
            try:
                resp = requests.get(url, timeout=timeout_seconds)
                resp.raise_for_status()
                out[name] = resp.json()
                last_err = None
                break
            except Exception as e:  # noqa: BLE001
                last_err = str(e)
                time.sleep(delay)
        if last_err is not None and name not in out:
            out[name] = {"_error": last_err}
    return out


def fetch_fixtures(fixtures_dir: str, source_names: list[str]) -> dict:
    out: dict[str, dict] = {}
    for name in source_names:
        path = Path(fixtures_dir) / f"{name}.json"
        with open(path, "r", encoding="utf-8") as f:
            out[name] = json.load(f)
    return out
