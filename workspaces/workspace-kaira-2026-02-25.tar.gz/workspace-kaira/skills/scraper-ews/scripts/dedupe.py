from __future__ import annotations

import json
from pathlib import Path


def load_seen(path: str) -> set[str]:
    p = Path(path)
    if not p.exists():
        return set()
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    return set(data.get("fingerprints", []))


def save_seen(path: str, seen: set[str], cap: int = 5000) -> None:
    values = list(seen)
    if len(values) > cap:
        values = values[-cap:]
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"fingerprints": values}, f, indent=2)


def dedupe(events: list[dict], seen: set[str]) -> list[dict]:
    out: list[dict] = []
    for event in events:
        fp = event.get("fingerprint")
        if not fp or fp in seen:
            continue
        seen.add(fp)
        out.append(event)
    return out
