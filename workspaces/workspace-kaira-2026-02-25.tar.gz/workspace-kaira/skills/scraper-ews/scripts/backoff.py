from __future__ import annotations


def backoff_delays(base_seconds: float = 0.5, factor: float = 2.0, attempts: int = 3, max_seconds: float = 8.0) -> list[float]:
    """Deterministic exponential backoff delays (no jitter)."""
    delays = []
    current = base_seconds
    for _ in range(max(0, attempts)):
        delays.append(min(current, max_seconds))
        current *= factor
    return delays
