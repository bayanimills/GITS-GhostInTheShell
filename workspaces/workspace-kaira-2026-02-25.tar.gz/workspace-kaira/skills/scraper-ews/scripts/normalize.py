from __future__ import annotations

from datetime import datetime, timezone

from common import sha256_obj, utc_now_iso


def _iso_from_ms(ms: int | None) -> str:
    if not ms:
        return utc_now_iso()
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def severity_hint(record: dict) -> str:
    if record.get("event_type") == "earthquake":
        mag = record.get("magnitude") or 0
        if mag >= 6.0:
            return "critical"
        if mag >= 4.5:
            return "warning"
        return "info"
    if record.get("event_type") == "service_status":
        status = (record.get("status") or "").lower()
        if status in {"critical", "major_outage"}:
            return "critical"
        if status in {"minor", "degraded_performance"}:
            return "warning"
        return "info"
    return "info"


def normalize(records: list[dict]) -> list[dict]:
    collected = utc_now_iso()
    events: list[dict] = []
    for r in records:
        occurred = r.get("occurred_iso") or _iso_from_ms(r.get("occurred_ms"))
        base = {
            "schema": "ews.pde.event.v1",
            "event_id": f"{r.get('source')}:{r.get('source_id')}",
            "source": r.get("source"),
            "event_type": r.get("event_type"),
            "occurred_at": occurred,
            "collected_at": collected,
            "title": r.get("title", ""),
            "summary": r.get("summary", ""),
            "severity_hint": severity_hint(r),
            "location": {
                "lat": r.get("lat"),
                "lon": r.get("lon"),
                "label": r.get("summary", ""),
            },
            "tags": [r.get("source"), r.get("event_type")],
            "raw_ref": r.get("raw_ref", ""),
            "meta": {"source_id": r.get("source_id")},
        }
        base["fingerprint"] = sha256_obj({k: base[k] for k in ["event_id", "occurred_at", "title", "summary", "source", "event_type"]})
        events.append(base)
    return events
