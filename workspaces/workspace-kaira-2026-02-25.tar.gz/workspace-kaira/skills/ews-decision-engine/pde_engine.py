#!/usr/bin/env python3
"""
EWS/PDE Decision Engine (intelligence layer only)
- Consumes canonical normalized events (JSONL)
- Produces decision cards: act | wait | ignore
- Deterministic logic only (no orchestration/execution)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from typing import Any, Dict, List, Optional, Tuple


SEVERITY_ORDER = {"INFO": 1, "LOW": 2, "MEDIUM": 3, "HIGH": 4, "CRITICAL": 5}


@dataclass
class DecisionContext:
    now_utc: datetime
    now_local: datetime
    in_quiet_hours: bool


def iso_now_utc() -> datetime:
    return datetime.now(timezone.utc)


def parse_iso8601(ts: str) -> datetime:
    # Support trailing Z
    if ts.endswith("Z"):
        ts = ts[:-1] + "+00:00"
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            items.append(json.loads(line))
    return items


def save_json(path: str, data: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def stable_event_key(event: Dict[str, Any]) -> str:
    event_id = str(event.get("event_id", ""))
    source = str(event.get("source", ""))
    signal = str(event.get("signal_type", ""))
    ts = str(event.get("event_time", ""))
    raw = f"{source}|{signal}|{event_id}|{ts}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def in_time_window(now_local: datetime, start_hhmm: str, end_hhmm: str) -> bool:
    start_h, start_m = map(int, start_hhmm.split(":"))
    end_h, end_m = map(int, end_hhmm.split(":"))
    mins = now_local.hour * 60 + now_local.minute
    start = start_h * 60 + start_m
    end = end_h * 60 + end_m
    if start <= end:
        return start <= mins < end
    # Overnight window (e.g., 22:00 -> 07:00)
    return mins >= start or mins < end


def severity_score(severity: str) -> float:
    return float(SEVERITY_ORDER.get(severity.upper(), 1)) / 5.0


def trend_bonus(event: Dict[str, Any], trend_cfg: Dict[str, Any]) -> Tuple[float, str]:
    trend = event.get("trend") or {}
    direction = str(trend.get("direction", "flat")).lower()
    slope = float(trend.get("slope", 0.0) or 0.0)
    accel = float(trend.get("acceleration", 0.0) or 0.0)

    up_bonus = float(trend_cfg.get("up_bonus", 0.10))
    accel_bonus = float(trend_cfg.get("acceleration_bonus", 0.05))

    bonus = 0.0
    reasons: List[str] = []
    if direction == "up":
        bonus += up_bonus
        reasons.append(f"trend up (+{up_bonus:.2f})")
    if accel > 0 and slope > 0:
        bonus += accel_bonus
        reasons.append(f"positive acceleration (+{accel_bonus:.2f})")
    return bonus, "; ".join(reasons) if reasons else "no strong trend signal"


def behavior_adjustment(event: Dict[str, Any], beh_cfg: Dict[str, Any]) -> Tuple[float, str]:
    behavior = event.get("behavior") or {}
    baseline_dev = float(behavior.get("baseline_deviation", 0.0) or 0.0)
    pct95 = float(behavior.get("historical_p95", 0.0) or 0.0)

    high_dev_threshold = float(beh_cfg.get("high_deviation_threshold", 2.0))
    high_dev_bonus = float(beh_cfg.get("high_deviation_bonus", 0.12))
    p95_bonus = float(beh_cfg.get("p95_exceed_bonus", 0.08))

    adj = 0.0
    notes: List[str] = []
    if baseline_dev >= high_dev_threshold:
        adj += high_dev_bonus
        notes.append(f"baseline deviation {baseline_dev:.2f}σ (+{high_dev_bonus:.2f})")
    if pct95 > 0 and baseline_dev >= pct95:
        adj += p95_bonus
        notes.append(f"deviation exceeds p95 {pct95:.2f}σ (+{p95_bonus:.2f})")
    return adj, "; ".join(notes) if notes else "behavior within normal bounds"


def decide_action(conf: float, rules: Dict[str, Any]) -> str:
    act_t = float(rules.get("act_threshold", 0.80))
    wait_t = float(rules.get("wait_threshold", 0.55))
    if conf >= act_t:
        return "act"
    if conf >= wait_t:
        return "wait"
    return "ignore"


def confidence_gate(action: str, conf: float, gate_cfg: Dict[str, Any]) -> Tuple[str, Optional[str]]:
    min_act = float(gate_cfg.get("min_confidence_for_act", 0.80))
    min_wait = float(gate_cfg.get("min_confidence_for_wait", 0.55))

    if action == "act" and conf < min_act:
        return "wait", f"gated: act requires >= {min_act:.2f}"
    if action == "wait" and conf < min_wait:
        return "ignore", f"gated: wait requires >= {min_wait:.2f}"
    return action, None


def is_deduped_or_cooldown(
    event_key: str,
    event: Dict[str, Any],
    state: Dict[str, Any],
    now_utc: datetime,
    dedupe_cfg: Dict[str, Any],
) -> Tuple[bool, str]:
    records = state.setdefault("seen", {})
    dedupe_hours = float(dedupe_cfg.get("dedupe_window_hours", 24))
    cooldown_min = int(dedupe_cfg.get("cooldown_minutes", 30))

    item = records.get(event_key)
    if not item:
        return False, ""

    seen_at = parse_iso8601(item["seen_at"])
    age_hours = (now_utc - seen_at).total_seconds() / 3600.0
    if age_hours <= dedupe_hours:
        return True, f"deduped within {dedupe_hours:g}h window"

    source_signal = f"{event.get('source')}|{event.get('signal_type')}"
    last_by_signal = state.setdefault("last_by_signal", {}).get(source_signal)
    if last_by_signal:
        last_ts = parse_iso8601(last_by_signal)
        age_min = (now_utc - last_ts).total_seconds() / 60.0
        if age_min < cooldown_min:
            return True, f"cooldown active ({age_min:.1f}m < {cooldown_min}m)"

    return False, ""


def register_state(
    event_key: str,
    event: Dict[str, Any],
    state: Dict[str, Any],
    now_utc: datetime,
) -> None:
    state.setdefault("seen", {})[event_key] = {
        "seen_at": now_utc.isoformat(),
        "event_id": event.get("event_id"),
        "source": event.get("source"),
        "signal_type": event.get("signal_type"),
    }
    source_signal = f"{event.get('source')}|{event.get('signal_type')}"
    state.setdefault("last_by_signal", {})[source_signal] = now_utc.isoformat()


def compute_confidence(event: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[float, List[str]]:
    weights = cfg["weights"]

    sev_component = severity_score(str(event.get("severity", "INFO"))) * float(weights.get("severity", 0.55))
    trend_component, trend_note = trend_bonus(event, cfg.get("trend", {}))
    trend_component *= float(weights.get("trend", 0.20))
    beh_component, beh_note = behavior_adjustment(event, cfg.get("behavior", {}))
    beh_component *= float(weights.get("behavior", 0.20))

    recency_hours = 999.0
    if event.get("event_time"):
        recency_hours = (iso_now_utc() - parse_iso8601(event["event_time"])).total_seconds() / 3600.0
    recency_boost = float(weights.get("recency", 0.05)) if recency_hours <= 1 else 0.0

    confidence = max(0.0, min(1.0, sev_component + trend_component + beh_component + recency_boost))

    rationale = [
        f"severity component={sev_component:.2f}",
        f"trend: {trend_note}",
        f"behavior: {beh_note}",
        f"recency boost={recency_boost:.2f}",
    ]
    return confidence, rationale


def build_decision_card(
    event: Dict[str, Any],
    action: str,
    confidence: float,
    rationale: List[str],
    ctx: DecisionContext,
    controls: List[str],
) -> Dict[str, Any]:
    return {
        "card_type": "ews_decision",
        "schema_version": "1.0",
        "event_id": event.get("event_id"),
        "source": event.get("source"),
        "signal_type": event.get("signal_type"),
        "severity": event.get("severity"),
        "decision": action,
        "confidence": round(confidence, 3),
        "rationale": rationale,
        "controls_applied": controls,
        "quiet_hours_active": ctx.in_quiet_hours,
        "decision_time_utc": ctx.now_utc.isoformat(),
        "decision_time_local": ctx.now_local.isoformat(),
        "constraints": {
            "no_execution": True,
            "layer": "intelligence_only",
        },
    }


def outcome_logger_append(path: str, card: Dict[str, Any], event_key: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    record = {
        "event_key": event_key,
        "decision": card["decision"],
        "confidence": card["confidence"],
        "event_id": card.get("event_id"),
        "source": card.get("source"),
        "signal_type": card.get("signal_type"),
        "severity": card.get("severity"),
        "decision_time_utc": card.get("decision_time_utc"),
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def deterministic_tuner_recommendation(log_path: str) -> Dict[str, Any]:
    """
    Deterministic tuner: suggests threshold changes from outcome distribution.
    No ML, no randomness.
    """
    if not os.path.exists(log_path):
        return {"status": "no_data", "recommendation": "none"}

    counts = {"act": 0, "wait": 0, "ignore": 0}
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            d = rec.get("decision")
            if d in counts:
                counts[d] += 1

    total = sum(counts.values())
    if total == 0:
        return {"status": "no_data", "recommendation": "none"}

    act_ratio = counts["act"] / total
    ignore_ratio = counts["ignore"] / total

    # Fixed deterministic policy
    if act_ratio > 0.60:
        return {
            "status": "recommend",
            "reason": "act ratio high",
            "set": {"act_threshold": 0.85},
            "metrics": counts,
        }
    if ignore_ratio > 0.70:
        return {
            "status": "recommend",
            "reason": "ignore ratio high",
            "set": {"wait_threshold": 0.50},
            "metrics": counts,
        }
    return {"status": "stable", "recommendation": "keep", "metrics": counts}


def build_context(cfg: Dict[str, Any], now_override: Optional[str]) -> DecisionContext:
    tz_name = cfg["quiet_hours"].get("timezone", "Australia/Sydney")
    now_utc = parse_iso8601(now_override) if now_override else iso_now_utc()
    now_local = now_utc.astimezone(ZoneInfo(tz_name))

    qh = cfg.get("quiet_hours", {})
    in_qh = bool(qh.get("enabled", True)) and in_time_window(
        now_local,
        qh.get("start", "22:00"),
        qh.get("end", "07:00"),
    )
    return DecisionContext(now_utc=now_utc, now_local=now_local, in_quiet_hours=in_qh)


def process_events(events: List[Dict[str, Any]], cfg: Dict[str, Any], state_path: str, outcome_log_path: str, now_override: Optional[str]) -> Dict[str, Any]:
    state = load_json(state_path) if os.path.exists(state_path) else {}
    ctx = build_context(cfg, now_override)

    cards: List[Dict[str, Any]] = []

    for ev in events:
        controls: List[str] = []
        key = stable_event_key(ev)

        skip, reason = is_deduped_or_cooldown(key, ev, state, ctx.now_utc, cfg["controls"])
        if skip:
            controls.append(reason)
            card = build_decision_card(
                ev,
                action="ignore",
                confidence=0.0,
                rationale=["suppressed by control", reason],
                ctx=ctx,
                controls=controls,
            )
            cards.append(card)
            outcome_logger_append(outcome_log_path, card, key)
            continue

        confidence, rationale = compute_confidence(ev, cfg)
        action = decide_action(confidence, cfg["decision_rules"])

        if ctx.in_quiet_hours and action == "act":
            bypass = cfg["quiet_hours"].get("bypass_severities", ["CRITICAL"])
            if str(ev.get("severity", "")).upper() not in [s.upper() for s in bypass]:
                action = "wait"
                controls.append("quiet-hours downgrade act->wait")

        gated_action, gate_note = confidence_gate(action, confidence, cfg["confidence_gating"])
        if gate_note:
            controls.append(gate_note)
        action = gated_action

        card = build_decision_card(ev, action, confidence, rationale, ctx, controls)
        cards.append(card)

        register_state(key, ev, state, ctx.now_utc)
        outcome_logger_append(outcome_log_path, card, key)

    save_json(state_path, state)
    tuning = deterministic_tuner_recommendation(outcome_log_path)
    return {
        "engine": "ews-pde",
        "mode": "decision_only",
        "cards": cards,
        "tuner": tuning,
    }


def validate_event_schema(event: Dict[str, Any]) -> List[str]:
    required = ["event_id", "event_time", "source", "signal_type", "severity"]
    errs: List[str] = []
    for k in required:
        if k not in event:
            errs.append(f"missing required field: {k}")
    sev = str(event.get("severity", "")).upper()
    if sev and sev not in SEVERITY_ORDER:
        errs.append(f"invalid severity: {sev}")
    try:
        if event.get("event_time"):
            parse_iso8601(str(event["event_time"]))
    except Exception:
        errs.append("invalid event_time (ISO-8601 required)")
    return errs


def main() -> int:
    parser = argparse.ArgumentParser(description="EWS/PDE decision engine (intelligence layer only)")
    parser.add_argument("--config", required=True, help="Path to config JSON")
    parser.add_argument("--input", required=True, help="Path to canonical normalized events JSONL")
    parser.add_argument("--state", default="state/pde-state.json", help="State file path")
    parser.add_argument("--outcome-log", default="state/outcome-log.jsonl", help="Outcome logger path")
    parser.add_argument("--output", default="-", help="Output JSON path or '-' for stdout")
    parser.add_argument("--now", default=None, help="Override current UTC time ISO-8601")
    parser.add_argument("--validate-only", action="store_true", help="Validate input schema and exit")
    args = parser.parse_args()

    cfg = load_json(args.config)
    events = load_jsonl(args.input)

    all_errs: List[str] = []
    for idx, ev in enumerate(events):
        errs = validate_event_schema(ev)
        if errs:
            all_errs.extend([f"event[{idx}] {e}" for e in errs])

    if all_errs:
        print(json.dumps({"ok": False, "errors": all_errs}, indent=2))
        return 2

    if args.validate_only:
        print(json.dumps({"ok": True, "validated_events": len(events)}, indent=2))
        return 0

    result = process_events(
        events=events,
        cfg=cfg,
        state_path=args.state,
        outcome_log_path=args.outcome_log,
        now_override=args.now,
    )

    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output == "-":
        print(payload)
    else:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(payload)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
