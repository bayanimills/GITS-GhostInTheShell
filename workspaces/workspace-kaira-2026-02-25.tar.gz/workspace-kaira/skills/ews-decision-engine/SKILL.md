---
name: ews-decision-engine
version: 1.0.0
description: Deterministic EWS/PDE intelligence layer that converts canonical normalized events into decision cards (act/wait/ignore) with confidence, rationale, and control annotations.
metadata:
  openclaw:
    category: intelligence
    requires:
      bins: ["python3"]
---

# EWS Decision Engine (PDE Layer)

## Purpose
This skill is the **intelligence/decision layer only** for EWS.
It **does not orchestrate or execute actions**.

It consumes canonical normalized events and outputs deterministic decision cards:
- `act`
- `wait`
- `ignore`

Each card includes:
- confidence score
- rationale
- controls applied (quiet-hours, gating, dedupe/cooldown)

## Scope
- Severity evaluation (`INFO/LOW/MEDIUM/HIGH/CRITICAL`)
- Trend spotting (`direction`, `slope`, `acceleration`)
- Behavior-aware insight (baseline deviation vs historical profile)
- Deterministic PDE decisioning
- Outcome logging (JSONL)
- Deterministic tuner recommendations

## Out of Scope (Hard Constraint)
- No message sending
- No agent/tool orchestration
- No workflow execution
- No side-effectful remediation

This layer only emits cards and logs.

## Canonical Input Contract (Normalized Event)
Input format: JSONL (`one event per line`)

Required fields:
- `event_id` (string)
- `event_time` (ISO-8601)
- `source` (string)
- `signal_type` (string)
- `severity` (`INFO|LOW|MEDIUM|HIGH|CRITICAL`)

Optional intelligence fields:
- `trend.direction` (`up|down|flat`)
- `trend.slope` (number)
- `trend.acceleration` (number)
- `behavior.baseline_deviation` (number, sigma-like)
- `behavior.historical_p95` (number)
- `metrics` (object)

## Output Contract (Decision Card)
Each output card includes:
- `card_type: ews_decision`
- `event_id, source, signal_type, severity`
- `decision: act|wait|ignore`
- `confidence: 0..1`
- `rationale: string[]`
- `controls_applied: string[]`
- `quiet_hours_active: bool`
- `constraints.no_execution: true`

## Deterministic PDE Logic
Confidence is a bounded weighted sum:

`confidence = severity_component + trend_component + behavior_component + recency_boost`

Controls in order:
1. **Deduplication / cooldown** (may force `ignore`)
2. **Base decision thresholds** (`act`, `wait`, `ignore`)
3. **Quiet-hours control** (`act -> wait` unless bypass severity)
4. **Confidence gating** (degrade decision when below minimums)

No randomness, no model inference.

## Control Features
### Quiet Hours
- Default: `22:00-07:00` Australia/Sydney
- Bypass severities configurable (default `CRITICAL`)

### Confidence Gating
- `min_confidence_for_act`
- `min_confidence_for_wait`

### Deduplication + Cooldown
- Event hash dedupe window (hours)
- Source+signal cooldown (minutes)

## Files
- `pde_engine.py` — deterministic decision engine
- `config.example.json` — thresholds/weights/control config
- `examples/input_events.jsonl` — canonical sample events
- `examples/dry_run_output.json` — generated dry-run output
- `state/` — local state + outcomes during runs

## Commands
```bash
cd /home/agent/.openclaw/workspace-kaira/skills/ews-decision-engine

# 1) Syntax validation
python3 -m py_compile pde_engine.py

# 2) Input contract validation
python3 pde_engine.py \
  --config config.example.json \
  --input examples/input_events.jsonl \
  --validate-only

# 3) Deterministic dry-run example
python3 pde_engine.py \
  --config config.example.json \
  --input examples/input_events.jsonl \
  --state state/pde-state.json \
  --outcome-log state/outcome-log.jsonl \
  --now 2026-02-24T04:38:00Z \
  --output examples/dry_run_output.json

# 4) View output
cat examples/dry_run_output.json
```

## Expected Dry-Run Behavior (example)
With the provided sample:
- `evt-001` (HIGH + trend up + behavior deviation) → likely `wait` during quiet hours
- `evt-002` (MEDIUM, flat trend) → likely `ignore`
- `evt-003` (CRITICAL) → likely `act` even during quiet hours (bypass)
- duplicate `evt-001` entry → `ignore` due to dedupe

## Evidence Checklist
- [x] Syntax compiles (`py_compile`)
- [x] Schema validation passes (`--validate-only`)
- [x] Dry-run output generated (`examples/dry_run_output.json`)
- [x] Deterministic tuner output included in run payload
