# Mission Control × Bayani AWS3/EWS Integration Plan

## 1) What Mission Control is (fit-for-purpose summary)

Mission Control is a **Next.js + SQLite orchestration dashboard** for OpenClaw agent operations.

Core capabilities:
- Task intake + Kanban workflow (`planning → inbox → assigned → in_progress → testing → review → done`)
- Planning sessions (LLM Q&A with persisted planning state)
- Task dispatch to OpenClaw sessions via Gateway RPC (`chat.send`)
- Activity + deliverables logging
- Real-time updates via SSE
- Automated QA gate (`/api/tasks/:id/test`) using Playwright + CSS/resource error checks

Net: It is a strong **operator UI and control plane** over OpenClaw agents, with explicit task lifecycle telemetry.

---

## 2) Quick start for Bayani environment

### Dependencies
- Node.js 20+ recommended
- npm
- OpenClaw Gateway reachable (local/remote)
- Chromium runtime deps (already handled by Playwright package + host/container setup)

### Boot
```bash
git clone https://github.com/crshdn/mission-control.git
cd mission-control
npm install
cp .env.example .env.local
```

Set required envs:
- `OPENCLAW_GATEWAY_URL`
- `OPENCLAW_GATEWAY_TOKEN` (required for secured/remote gateway)
- `MC_API_TOKEN` (required for production API protection)
- `WEBHOOK_SECRET` (required if using completion webhooks)

Run:
```bash
openclaw gateway start
npm run dev
# http://localhost:4000
```

Production:
```bash
npm run build
npm run start
```

Docker path exists (`Dockerfile`, `docker-compose.yml`) with persistent volumes for DB and workspace.

---

## 3) Strengths, risks, production-readiness

### Strengths
- Clean API surface for orchestration (`/api/tasks/*`, `/api/openclaw/*`, `/api/webhooks/*`)
- Explicit data model with migrations (`better-sqlite3`, WAL enabled)
- Real-time visibility through SSE broadcast bus
- Practical automation support (subagent/session registration, deliverables tracking)
- Built-in QA stage (browser tests + CSS + resource checks)
- Auth/webhook security hooks available (token + HMAC)

### Risks / Gaps
- **Auth disabled by default** unless `MC_API_TOKEN` is set (easy to misdeploy)
- SSE is in-process memory client registry (works single instance; needs pub/sub for horizontal scale)
- SQLite is fine for single node/small team; may bottleneck with high-concurrency workloads
- Some route logic depends on convention-heavy messaging (`TASK_COMPLETE:` parsing)
- API token compare is direct string compare (acceptable, but constant-time compare is better)
- No obvious built-in rate limiting / abuse controls at API layer

### Production-readiness verdict
- **Ready for controlled production** (single region, moderate load, internal network)
- **Needs hardening** before enterprise-scale multi-instance deployment:
  1. External state/event bus (Redis/NATS) for SSE fan-out
  2. Reverse-proxy rate limits + WAF + strict network segmentation
  3. Postgres migration path if concurrency/reporting grows

---

## 4) How it maps to Bayani AWS3/EWS

Assumed Bayani pattern:
- **AWS3** = autonomous workflow engine / scheduler / orchestrator policy framework
- **EWS** = event/workflow signaling + execution streams

Recommended mapping:

- AWS3 becomes the **policy brain** and “why/when” engine.
- Mission Control becomes **human-visible orchestration cockpit** and task ledger.
- EWS transports status/events bidirectionally.

### Integration contract
1. AWS3 creates/upserts tasks in Mission Control (`POST /api/tasks`) with metadata tags.
2. Mission Control drives planning/dispatch and records agent work.
3. Mission Control emits events (SSE/webhook bridge) into EWS topics:
   - `task_created`, `task_updated`, `agent_spawned`, `agent_completed`, `deliverable_added`, `test_passed/failed`.
4. AWS3 consumes EWS events for policy decisions (retry, escalate, re-route, notify).
5. Human approvals in MC (`review → done`) produce EWS approval events for downstream automation.

---

## 5) Concrete implementation opportunities

### Quick wins (1–2 days)
- Enforce production env guard: fail startup if `NODE_ENV=production` and `MC_API_TOKEN` empty.
- Add API gateway/nginx rate limits for `/api/*` and webhook endpoints.
- Add Bayani metadata fields (or `metadata` JSON) to tasks for AWS3 correlation IDs.
- Build tiny EWS bridge service consuming `/api/events/stream` and publishing normalized events.

### Week plan (5 working days)
1. Define canonical event schema (`trace_id`, `workflow_id`, `task_id`, `agent_id`, `status`, `ts`).
2. Implement MC→EWS bridge with replay/backoff/dead-letter handling.
3. Implement AWS3→MC task ingestion adapter + idempotency keys.
4. Add operational dashboards (queue depth, cycle time, fail rate, stuck tasks).
5. Add runbooks for retries, manual override, incident handling.

### Month roadmap (3–4 weeks)
- Replace in-memory SSE broadcast with Redis pub/sub or NATS for multi-instance scaling.
- Introduce Postgres option + migration for larger throughput.
- Add RBAC/tenant isolation for workspace-level access control.
- Add signed internal service auth (mTLS/JWT service principals) for AWS3/EWS integrations.
- Build compliance/audit layer (immutable event log + approval trails).

---

## 6) Security/safety guardrails (recommended)

1. **Mandatory secrets in prod**
   - `MC_API_TOKEN`, `WEBHOOK_SECRET`, gateway token must be non-empty.
2. **Network segmentation**
   - Expose UI publicly only behind reverse proxy; keep internal APIs private where possible.
3. **Webhook authenticity**
   - Keep HMAC validation required in non-dev; rotate secrets quarterly.
4. **Least privilege**
   - Separate operator UI auth from machine-to-machine credentials.
5. **Rate limiting + payload limits**
   - Especially for `/api/files/upload`, webhook, and task mutation endpoints.
6. **Path safety**
   - Keep relative path validation (already present); add allowlisted extensions and max file size.
7. **Auditability**
   - Persist actor identity on all status transitions and approvals.
8. **Fail-safe workflow**
   - Never auto-approve `review → done` without explicit policy + deliverable checks.
9. **Chaos/failure planning**
   - Define behavior for gateway offline, test runner failure, duplicate events, and partial dispatch.

---

## Suggested pilot architecture (Bayani)

- `aws3-controller` (policy/scheduling)
- `mission-control` (UI + orchestration API)
- `ews-event-bus` (Kafka/NATS/SNS+SQS)
- `mc-ews-bridge` (SSE/webhook translator)
- `openclaw-gateway` (agent runtime)

Start with single instance MC + SQLite for pilot; harden/scale after proving event contract and approval loops.
