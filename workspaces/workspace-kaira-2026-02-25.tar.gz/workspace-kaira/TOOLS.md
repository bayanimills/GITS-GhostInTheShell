# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

## Workspace Scripts

### Backup & Recovery
- `backup.sh` – Git-based workspace backup (commits changes, logs to memory)
- `backup_workflow_files.sh` – Backup WORKFLOW_AUTO.md files before version upgrades
- `restore_memory.py` – Restore memory file with pre-compaction section (used for post-compaction audit recovery)

### Maintenance
- `check_workflow_versions.sh` – Check WORKFLOW_AUTO.md version across all agents
- `check_workflow_v3_compliance.sh` – Validate v3.0.0 feature adoption
- `transform_v2_to_v3_simple.py` – Transform v2.0.0 to v3.0.0 preserving agent-specific content
- `transform_v2_to_v3.py` – Legacy transformation script
- `append_memory.py` – Append text to memory file
- `update_bootstrap.py` – Update bootstrap script
- `replace_block.py` – Replace text block in file
- `update_report.py` – Update report templates

### Autonomous Workflow System
- `phase3-autonomous/autonomous-check-v3.py` – Advanced autonomous work with presence detection
- `phase3-autonomous/seed-detection.py` – Detect seed tasks in logs
- `phase3-autonomous/comment-validation.py` – Validate code comments
- `phase3-autonomous/test_presence.py` – Test presence detection
- `phase3-autonomous/add-comment-headers.sh` – Add comment headers to files

### Utility Scripts
- `scripts/validate-canonicals.py` – Validate canonical references in core files
- `telegram_functions.py` – Telegram utility functions
- `temp_functions.py` – Temporary functions
- `add_telegram_call.py` – Add Telegram call
- `add_naws_cron.sh` – Add NAWS cron job
- `install-aws-with-bootstrap.sh` – Install AWS with bootstrap

## NAWS (Nighttime Autonomous Work System)
- **Schedule**: `0 23,1,3,5 * * *` (Sydney time) – 23:00, 01:00, 03:00, 05:00
- **Script**: `nighttime-check.py` in `/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/`
- **Task queue**: `nighttime-activities.md`
- **Logs**: `logs/nighttime-check.log`
- **Safety**: Internal/non‑destructive only, 23:00‑07:00 window

## Autonomous Workflow System (AWS) v2.0 (24/7 expansion)
- **Script**: `autonomous-check.py` in `/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/` (primary)
- **Enhanced Script**: `phase3-autonomous/autonomous-check-v3.py` – Advanced autonomous work with presence detection
- **Features**: Presence detection, graduated permission levels, 24/7 operation
- **Presence levels**: ACTIVE (<5m), IDLE (5-60m), ABSENT (>60m)
- **Permission mapping**: ACTIVE→read‑only, IDLE→internal‑write, ABSENT/NIGHT→full‑autonomy
- **Test cron**: `*/30 * * * *` for Kaira workspace (testing phase)
- **Override**: Create `~/.openclaw‑autonomy‑pause` to manually pause autonomy
- **Logs**: `logs/autonomous-check.log` (primary), `logs/autonomous-check-v3.log` (enhanced)

## Workspace Location
- Primary workspace: `/home/agent/.openclaw/workspace-kaira`
- Memory logs: `memory/YYYY-MM-DD.md`
- Backups: `backups/` directory

---

Add whatever helps you do your job. This is your cheat sheet.
