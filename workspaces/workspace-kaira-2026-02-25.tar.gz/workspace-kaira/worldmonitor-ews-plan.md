# WorldMonitor Early Warning System (EWS) Integration Plan

## 1. Quick Repo Assessment

### What It Does
WorldMonitor is a real‑time global intelligence dashboard that aggregates and analyzes 150+ RSS feeds, live video streams, satellite data, ADS‑B/AIS tracking, conflict reports (ACLED/UCDP), cyber threat IOCs, market/crypto signals, and infrastructure status across 35+ interactive map layers. It provides:

- **AI‑synthesized briefs** (local/cloud LLM fallback chain)
- **Country Instability Index** (CII) for 22 tier‑1 nations
- **Multi‑source signal fusion** with anomaly detection (Z‑score baselines)
- **Interactive 3D globe** with toggleable data layers
- **Desktop app (Tauri)** + installable PWA
- **17 typed gRPC/HTTP services** (news, conflict, unrest, intelligence, cyber, market, climate, etc.)

### Strengths
- **Comprehensive coverage** – geopolitics, military, infrastructure, markets, crypto, cyber, natural disasters
- **Real‑time/low‑latency** – RSS feeds polled continuously, video streams scraped every 5 min, aircraft/vessels updated every 30 s–2 min
- **AI‑powered analysis** – LLM summarization, threat classification, focal‑point detection, trending‑keyword spikes
- **Local‑first architecture** – Ollama/LM Studio support; sidecar runs 60+ API handlers locally
- **Multi‑variant views** – Geopolitical, Tech, Finance variants from same codebase
- **Open source & free** – no vendor lock‑in, extensible proto‑based API contracts

### Limits
- **API‑key dependent** – many data sources require external keys (Finnhub, FRED, EIA, Wingbits, ACLED, etc.)
- **Tier‑1 country bias** – CII and deep intel only for 22 nations; other countries get limited coverage
- **Complex deployment** – full self‑hosting requires Node.js/Redis/PostGIS; cloud API may have rate limits
- **Update cadence varies** – some sources are near‑real‑time (ADS‑B, AIS, RSS), others are hourly/daily (UCDP, HAPI, economic indicators)
- **No built‑in alerting** – dashboard is visualization‑focused; proactive notifications need to be built externally

### Data Sources (Partial List)
- **News/Unrest**: 150+ RSS feeds, GDELT, ACLED protests, UCDP conflicts, HAPI humanitarian data
- **Military/Strategic**: ADS‑B (OpenSky), AIS (AISStream), military bases, nuclear facilities
- **Infrastructure**: Undersea cables (NGA warnings), internet outages (Cloudflare Radar), datacenters, pipelines
- **Cyber**: Threat intel feeds (C2, malware, phishing)
- **Markets/Crypto**: 92 stock exchanges, CoinGecko prices, BTC ETF flows, Fear & Greed Index
- **Natural Disasters**: USGS earthquakes, NASA FIRMS fires, GDACS alerts
- **Climate/Weather**: Open‑Meteo, NASA EONET
- **Demographics**: WorldPop density, UNHCR displacement

### Update Cadence
- **RSS feeds**: continuous polling (circuit‑breaker protected)
- **Video streams**: YouTube live detection every 5 min
- **Aircraft/vessels**: 30 s – 2 min (depending on source)
- **Conflict/unrest events**: ACLED/UCDP hourly (cached with 1‑hour TTL)
- **Market data**: 1‑minute intervals for crypto, 15‑min for equities
- **Infrastructure status**: 5‑min checks for internet outages, cable warnings
- **AI summaries**: 24‑hour cache deduplication across users

---

## 2. EWS Use‑Cases for Bayani

### Crypto/Bitcoin Relevance
- **Regulatory news** – SEC, FCA, MAS, PBoC announcements; keyword monitors for “crypto ban”, “CBDC”, “stablecoin”
- **Market sentiment** – Fear & Greed Index, BTC spot ETF flows, stablecoin peg health
- **Macro signals** – JPY liquidity, QQQ/XLP regime, central bank rate changes (FRED data)
- **Infrastructure disruptions** – internet outages affecting exchanges, undersea cable cuts
- **Cyber threats** – exchange‑targeted malware, phishing IOCs, ransomware

### Geopolitical Risk (APAC Focus)
- **South China Sea / Taiwan Strait** – military flights, naval vessel surges, AIS chokepoint detection
- **Regional conflicts** – Korea DMZ, India‑Pakistan, Myanmar, Philippines insurgency
- **Social unrest** – protests in Hong Kong, Thailand, Indonesia; correlated with internet shutdowns
- **Natural disasters** – earthquakes (Japan, Indonesia), typhoons (Philippines), floods (China) – potential supply‑chain & mining‑farm impacts

### Critical Alerts vs. Daily Digest
- **Critical Alerts** (immediate notification)
  - Military aircraft incursions (Taiwan ADIZ, South China Sea)
  - High‑fatality conflict events (>10 deaths) in APAC
  - Internet outages affecting major financial hubs (SG, HK, Tokyo)
  - Crypto‑relevant regulatory announcements (SEC lawsuit, China crackdown)
  - Severe natural disasters (M6.5+ earthquakes, Category 4+ typhoons)
  - Cyber threat IOCs linked to exchanges/wallets
- **Daily Digest** (morning summary)
  - Overnight risk‑score changes for APAC countries
  - Protest count spikes (GDELT/ACLED)
  - Market moves (BTC price ±5%, Fear & Greed shift)
  - Trending keywords in crypto/regulatory news
  - Infrastructure advisories (cable repairs, port disruptions)

---

## 3. Concrete Integration Design with OpenClaw/AWS

### Trigger Categories & Severity Thresholds
| Category | Sub‑category | Severity Thresholds |
|----------|--------------|---------------------|
| **Geopolitical** | Conflict (ACLED) | INFO: 1–5 deaths; WARNING: 6–20 deaths; CRITICAL: >20 deaths |
| | Unrest (protests) | INFO: <100 participants; WARNING: 100–1000; CRITICAL: >1000 + fatalities |
| | Military flights | INFO: routine patrol; WARNING: unusual grouping (≥3 fighters); CRITICAL: incursion + escort |
| **Infrastructure** | Internet outages | INFO: single ASN; WARNING: multiple ASNs in country; CRITICAL: major IXP/cloud region |
| | Undersea cable advisory | INFO: planned maintenance; WARNING: fault detected; CRITICAL: multiple cables cut |
| **Cyber** | Threat IOC | INFO: phishing URL; WARNING: C2 server; CRITICAL: ransomware targeting exchanges |
| **Markets/Crypto** | BTC price move | INFO: ±2% in 1h; WARNING: ±5% in 1h; CRITICAL: ±10% in 1h + high volume |
| | Fear & Greed Index | INFO: change ±5; WARNING: shift from Extreme Fear/Greed; CRITICAL: rapid plunge (<10) |
| **Natural Disasters** | Earthquake | INFO: M4.5–5.5; WARNING: M5.5–6.5; CRITICAL: M6.5+ near population center |
| | Wildfire | INFO: single hotspot; WARNING: cluster near infrastructure; CRITICAL: urban interface |

### Message Formats
- **Urgent Alert** (CRITICAL/WARNING)
  ```
  [SEVERITY] [CATEGORY] – [LOCATION]
  [Brief description]
  🔗 [Link to map/dashboard]
  📊 [Metrics: deaths, magnitude, etc.]
  ⏰ [Timestamp UTC]
  ```
- **Daily Digest** (morning)
  ```
  🌍 WorldMonitor EWS Digest – YYYY‑MM‑DD
  ⚠️ Critical events (N)
  ⚠️ Warnings (M)
  ℹ️ Info updates (K)

  [Category breakdown with bullet points]

  📈 Risk‑score changes: [country]+/-[points]
  🔥 Trending keywords: [keyword1], [keyword2]
  ```

### Cron/Heartbeat Strategy
- **High‑frequency checks (every 5 min)** – conflict/unrest, military flights, internet outages, BTC price
- **Medium‑frequency (every 30 min)** – cyber IOCs, cable advisories, earthquake feeds
- **Daily digest (07:00 Sydney time)** – compile overnight events, risk‑score deltas, keyword trends
- **Use OpenClaw cron** for precise schedules; **heartbeat** for combined status checks (every 30 min) when presence is idle.

### Noise‑Reduction Rules & Quiet‑Hours Behavior
- **Deduplication** – same event ID not re‑alerted within cooldown window (1h for INFO, 3h for WARNING, 6h for CRITICAL)
- **Multi‑source confirmation** – require at least two independent sources (e.g., ACLED + GDELT) for CRITICAL unrest events
- **Quiet hours** – 22:00–07:00 Sydney time; suppress INFO/WARNING alerts, only deliver CRITICAL (configurable)
- **Geographic filtering** – focus on APAC (10°S–50°N, 90°E–160°E) plus global crypto‑relevant regions (USA, EU, China)
- **Keyword whitelist/blacklist** – ignore common false‑positive terms (e.g., “crypto” in gaming news).

---

## 4. MVP Implementation Plan (Step‑by‑Step)

### Step 1 – Environment Setup
1. **Deploy WorldMonitor sidecar** locally (or use cloud API `worldmonitor.app`).
   - If local: clone repo, install dependencies, configure `.env` with required API keys.
   - If cloud: note rate limits; obtain API key if needed.
2. **Verify API endpoints** – test `/api/conflict/v1/list‑acled‑events`, `/api/intelligence/v1/get‑risk‑scores`, etc.

### Step 2 – OpenClaw Script Development
3. **Create a Python/Node.js script** in workspace that:
   - Polls relevant WorldMonitor endpoints (see Appendix for endpoint list).
   - Applies threshold logic to filter events.
   - Formats alerts/digests.
   - Sends messages via OpenClaw `message` tool (Telegram).
4. **Store state** – keep last‑processed event IDs/timestamps in a JSON file to avoid repeats.

### Step 3 – Alert Configuration
5. **Define trigger categories** in a config YAML/JSON (copy from Section 3).
6. **Set up cron jobs** in OpenClaw:
   - `*/5 * * * *` for high‑frequency checks.
   - `*/30 * * * *` for medium‑frequency.
   - `0 7 * * *` for daily digest (Sydney time).
7. **Implement quiet‑hours logic** – skip non‑critical alerts between 22:00–07:00 AEST.

### Step 4 – Testing & Iteration
8. **Run in dry‑run mode** for 24 h, log would‑be alerts.
9. **Adjust thresholds** based on false‑positive rate.
10. **Add keyword filters** for crypto‑specific noise.

### Step 5 – Production Deployment
11. **Move script to persistent location** (e.g., `~/.openclaw/scripts/worldmonitor‑ews`).
12. **Set up error monitoring** – log failures, alert on script crashes.
13. **Document operational procedures** – how to update API keys, modify thresholds.

### Optional Advanced Roadmap
- **Integrate with AWS Lambda** for scalable polling; store state in DynamoDB.
- **Add machine‑learning anomaly detection** on top of WorldMonitor signals.
- **Create a dedicated dashboard** (Grafana) for EWS metrics.
- **Link to automated trading bots** – trigger hedge orders on CRITICAL geopolitical events.
- **Expand to monitor deep‑web/telegram crypto sentiment** via additional scrapers.

---

## 5. Risk Analysis & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| **False positives** (keyword noise, normal military exercises) | Alert fatigue, loss of trust | Multi‑source confirmation; increase severity thresholds; human‑in‑the‑loop for CRITICAL. |
| **Source reliability** (some RSS feeds may be biased/unverified) | Inaccurate alerts | Prefer curated feeds (ACLED, GDELT, official advisories); cross‑check with official sources. |
| **Latency** (data may be 15–60 min old) | Delayed warning | Prioritize real‑time sources (ADS‑B, AIS, RSS); accept latency for non‑time‑critical events. |
| **Over‑alerting** (too many INFO/WARNING events) | Notification spam | Aggressive deduplication; quiet‑hours; digest‑only for lower‑severity. |
| **API rate limits** (cloud WorldMonitor or upstream sources) | Missed events | Implement exponential backoff; cache responses; fall back to alternative sources. |
| **System downtime** (sidecar crashes, network issues) | Silent failure | Health‑check cron; alert on missed heartbeats; redundant polling from two regions. |

---

## 6. Recommended Config Defaults for Bayani (Start Tomorrow)

### Geographic Focus
- **APAC bounding box**: 10°S–50°N, 90°E–160°E (includes China, Japan, Korea, Taiwan, SEA, Australia).
- **Global crypto‑relevant**: USA (‑125°–‑65°, 25°–50°), EU (‑10°–30°, 35°–60°).

### Trigger Priorities (Start With)
1. **Military flights** in Taiwan Strait & South China Sea (any unusual grouping).
2. **Internet outages** affecting Singapore, Hong Kong, Tokyo, Sydney.
3. **BTC price moves** ±5% in 1 h.
4. **Earthquakes** M6.0+ within 100 km of major cities.
5. **Cyber IOCs** tagged “cryptocurrency‑exchange” or “ransomware”.
6. **Regulatory keywords**: “SEC”, “FCA”, “MAS”, “PBoC”, “crypto ban”, “stablecoin”.

### Alert Channels
- **Telegram** (current OpenClaw channel) for immediate alerts.
- **Daily digest** as a single morning message.

### Quiet Hours
- **22:00 – 07:00 Sydney time (AEST)** – suppress INFO/WARNING; only CRITICAL alerts.
- Override via environment variable `EWS_QUIET_HOURS_OFF`.

### Initial Severity Thresholds (Conservative)
- Conflict deaths: CRITICAL >20, WARNING >5, INFO ≥1.
- Protest size: CRITICAL >1000, WARNING >100.
- BTC price: CRITICAL ±10% in 1 h, WARNING ±5%.
- Earthquake: CRITICAL M6.5+, WARNING M5.5+.

---

## Appendix – Relevant WorldMonitor API Endpoints

| Service | Endpoint | Description | Suggested Poll Interval |
|---------|----------|-------------|-------------------------|
| **Conflict** | `/api/conflict/v1/list‑acled‑events` | ACLED conflict events (fatalities, location) | 5 min |
| **Unrest** | `/api/unrest/v1/list‑unrest‑events` | Protest/riot events (ACLED+GDELT) | 5 min |
| **Intelligence** | `/api/intelligence/v1/get‑risk‑scores` | Country instability & risk scores | 30 min |
| **Intelligence** | `/api/intelligence/v1/search‑gdelt‑documents` | News articles by keyword | 5 min |
| **Cyber** | `/api/cyber/v1/list‑iocs` | Cyber threat indicators | 30 min |
| **Market** | `/api/market/v1/get‑crypto‑snapshot` | BTC/ETH prices, Fear & Greed | 1 min |
| **Infrastructure** | `/api/infrastructure/v1/list‑outage‑alerts` | Internet outage alerts | 5 min |
| **Seismology** | `/api/seismology/v1/list‑earthquakes` | USGS earthquakes M4.5+ | 1 min |
| **Aviation** | `/api/aviation/v1/list‑military‑flights` | Military ADS‑B tracks | 2 min |
| **Maritime** | `/api/maritime/v1/list‑vessel‑snapshots` | Naval vessel AIS positions | 5 min |

> Note: Endpoint paths may vary slightly; consult the generated OpenAPI spec (`/api/docs`).

## Appendix B – Sample Configuration File

```yaml
# worldmonitor-ews-config.yaml
# Place in ~/.openclaw/workspace-kaira/config/

# Geographic filters
regions:
  apac:
    bbox: [10, -50, 90, 160]  # south, north, west, east
    enabled: true
  crypto_global:
    bbox: [25, 50, -125, -65]  # USA
    enabled: true
  europe:
    bbox: [35, 60, -10, 30]
    enabled: false

# Trigger thresholds
thresholds:
  conflict_deaths:
    critical: 20
    warning: 5
    info: 1
  protest_size:
    critical: 1000
    warning: 100
  btc_price_change_1h:
    critical: 10.0  # percent
    warning: 5.0
  earthquake_magnitude:
    critical: 6.5
    warning: 5.5
  military_flight_grouping:
    critical: 3   # ≥3 fighters
    warning: 2

# Keyword monitors (crypto/regulatory)
keywords:
  include:
    - 'SEC'
    - 'FCA'
    - 'MAS'
    - 'PBoC'
    - 'crypto ban'
    - 'stablecoin'
    - 'Bitcoin ETF'
    - 'ransomware'
    - 'exchange hack'
  exclude:
    - 'crypto game'
    - 'crypto wallet promo'

# Alerting
quiet_hours:
  start: '22:00'   # Sydney time
  end: '07:00'
  suppress_levels: ["INFO", "WARNING"]

# WorldMonitor API
api:
  base_url: 'http://localhost:3000/api'  # local sidecar
  # base_url: 'https://worldmonitor.app/api'  # cloud
  api_key: "${WORLDMONITOR_API_KEY}"  # env var
  poll_intervals:
    high_frequency: 300    # seconds
    medium_frequency: 1800
    daily_digest: '0 7 * * *'  # cron expression (Sydney)
```

---

## Next Steps
1. **Clone WorldMonitor repo** and set up sidecar (or decide to use cloud API).
2. **Write the polling script** (Python example provided in `scripts/`).
3. **Configure OpenClaw cron jobs** with the above intervals.
4. **Run a 24‑h dry‑run** and adjust thresholds.
5. **Go live** and monitor alert quality.

**Time estimate**: 2–3 days for MVP, 1 week for polished production system.

---
*Last updated: 2026‑02‑24*  
*Review by: Sub‑agent (worldmonitor‑ews‑review)*