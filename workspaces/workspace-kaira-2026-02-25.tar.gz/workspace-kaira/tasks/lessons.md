# AWS3 Lessons

## Purpose
Capture corrections and anti-repeat rules so mistakes are not repeated.

## Entry Template

### YYYY-MM-DD HH:MM (AEST)
- **Trigger / Correction:**
- **What went wrong:**
- **Root cause:**
- **Rule to prevent repeat:**
- **Concrete change made (file/process):**
- **How to verify this rule is working:**
- **Tags:** #lesson #aws3

---

## Standing Rules
1. For non-trivial work: plan first, then execute.
2. Prefer subagent-first execution for medium/large tasks.
3. Verify before done (tests/logs/observable evidence).
4. Keep fixes simple, minimal-impact, and reversible.
5. After user correction, record lesson immediately.
