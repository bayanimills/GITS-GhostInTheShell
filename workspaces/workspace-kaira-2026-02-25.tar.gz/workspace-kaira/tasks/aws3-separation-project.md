# AWS3 Layer Separation Project

## Objective
Split system into three clean layers and deliver production-ready flow:
1) AWS Skill = orchestration only
2) Scraper Skill = collection/normalization
3) EWS/PDE Skill = intelligence/decisioning

## Workstreams
- WS1: AWS refactor + adapter boundary
- WS2: Scraper skill packaging and validation
- WS3: EWS/PDE skill packaging and validation
- WS4: Integration contracts, runbooks, rollout docs

## Success Criteria
- Canonical event schema in place
- AWS consumes decision cards (not raw scraping logic)
- Scraper emits normalized events
- EWS emits decision cards (act/wait/ignore + confidence)
- Dry-run and live-run validation evidence captured
- Migration docs for other agents included

## Governance
- Sub-agent-first execution
- Safety: non-destructive changes only
- Evidence-first completion (logs/commands/files)
