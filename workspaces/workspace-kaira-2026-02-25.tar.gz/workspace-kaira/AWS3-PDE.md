# AWS3-PDE MVP Design (Personal Decision Engine)

## 1) Purpose
AWS3-PDE is a deterministic decision layer that sits above AWS/EWS signal ingestion and turns raw signals into **actionable decision cards**:
- **act**: execute playbook / notify immediately
- **wait**: hold and watch for confirmation
- **ignore**: log only, suppress noise

Primary context optimization: **Bayani** (Bitcoin + macro/geopolitical APAC focus, contrarian-aware).

---

## 2) Architecture

```text
AWS/EWS signal stream (JSON events)
        ↓
   PDE scorer (relevance / urgency / risk-fit)
        ↓
confidence + policy gates (dedupe/cooldown/quiet hours)
        ↓
decision classifier (act/wait/ignore)
        ↓
decision cards + persisted decisions.jsonl
        ↓
outcome logger (1h/24h/7d labels)
        ↓
tuner (rule-based suggestions to weights/thresholds)
```

### Components
- `integrations/aws3-pde/pde.py`
  - Ingest events JSON
  - Score each event
  - Apply safety/noise policy
  - Emit decision cards + top recommendation
  - Persist decisions to local JSONL store
- `integrations/aws3-pde/outcome_logger.py`
  - Record delayed outcomes for each decision ID (`good|neutral|bad`) at 1h/24h/7d
- `integrations/aws3-pde/tuner.py`
  - Deterministic rule engine that reviews outcomes and suggests config patches

---

## 3) Data Model

## Input Event (minimum practical fields)
```json
{
  "id": "sig-001",
  "source": "ews:asia-macro-wire",
  "title": "PBoC liquidity signal",
  "topic": "macro",
  "region": "APAC",
  "tags": ["liquidity", "bitcoin"],
  "signal_time": "2026-02-23T16:10:00Z",
  "source_reliability": 0.82,
  "market_impact": 0.78,
  "time_sensitivity": 0.81,
  "uncertainty": 0.32,
  "contrarian_signal": 0.64
}
```

## Decision Card Schema
```json
{
  "card_id": "string",
  "event_id": "string",
  "title": "string",
  "topic": "string",
  "region": "string",
  "recommendation": "act|wait|ignore",
  "scores": {
    "relevance": 0.0,
    "urgency": 0.0,
    "risk_fit": 0.0,
    "blended": 0.0,
    "confidence": 0.0
  },
  "reasons": ["policy_or_score_reason"],
  "actions": {
    "act": "execute playbook + alert user",
    "wait": "monitor 30-120m for confirmation",
    "ignore": "log only"
  },
  "created_at": "ISO-8601"
}
```

## Local Stores
- `state/decisions.jsonl`: append-only decision records (one line per decision)
- `state/outcomes.jsonl`: append-only outcome labels tied to `decision_id`

---

## 4) Scoring Logic (Deterministic)

Each event gets 3 dimensions in `[0,1]`:

- **Relevance**
  - Topic/tag alignment with Bayani focus (`bitcoin`, `macro`, `geopolitics`, `apac-policy`, `liquidity`)
  - APAC bonus
  - Source reliability boost
  - Noise-topic penalty (e.g., memecoin noise)

- **Urgency**
  - Weighted from `time_sensitivity`, `market_impact`, and inverse uncertainty

- **Risk-fit**
  - Matches user risk posture (`moderate-contrarian` boosts contrarian signal weight)
  - Also uses reliability and inverse uncertainty

Blended score:

`blended = w_rel * relevance + w_urg * urgency + w_risk * risk_fit`

Default weights:
- relevance: `0.45`
- urgency: `0.30`
- risk_fit: `0.25`

---

## 5) Confidence Model

Confidence is independent from blended score and reflects trustworthiness:
- source reliability
- inverse uncertainty
- low spread between dimensions (consistency)

`confidence = 0.45*reliability + 0.35*(1-uncertainty) + 0.20*(1-spread)`

Gate:
- If `confidence < confidence_min` (default `0.55`) ⇒ downgrade to `wait`

---

## 6) Decision Classification

Order of operations:
1. Confidence gate
2. Dedupe gate
3. Cooldown gate
4. Quiet-hours gate
5. Threshold classification

Threshold defaults:
- `act_min = 0.70`
- `wait_min = 0.45`
- below wait_min ⇒ `ignore`

---

## 7) Safety & Noise Controls

Implemented controls:
- **Dedupe**: fingerprint event keys and suppress repeats within `dedupe_window_minutes` (default 120)
- **Cooldown**: if recent `act`, subsequent events within `cooldown_minutes` (default 30) downgrade to `wait`
- **Confidence gating**: low-confidence signals blocked from immediate act
- **Quiet hours**: `23:00-07:00` default behavior `act_only_if_critical=true` (requires very high blended score)
- **Local-only persistence**: no destructive/system external side effects

---

## 8) Tuning Loop (Deterministic, No Heavy ML)

Input:
- decisions + realized outcomes (`good|neutral|bad`) at 1h/24h/7d

Method:
- convert outcomes to score (`+1,0,-1`)
- horizon-weighted aggregate per decision (`1h=0.2`, `24h=0.35`, `7d=0.45`)
- evaluate policy quality by recommendation class

Rule examples implemented:
- If `act` underperforms: raise `act_min`, reduce urgency weight
- If `wait` outperforms `act`: increase relevance/risk-fit weights
- If many high-confidence misses: raise `confidence_min`
- If ignored signals perform badly: lower `wait_min`

Output:
- Suggested config patch JSON (human-reviewed before applying)

---

## 9) AWS/EWS Integration Note

## How to call PDE from AWS3 flow
From AWS3 ingest/bridge step after collecting event batch:

```bash
python3 integrations/aws3-pde/pde.py \
  --events /tmp/aws3-events.json \
  --config integrations/aws3-pde/config.example.yaml \
  --out /tmp/pde-output.json
```

Parse `/tmp/pde-output.json`:
- `top_recommendation`
- `top_card`
- `decision_cards[]`

Use `top_card.recommendation` to route:
- `act` → trigger playbook + high-priority alert
- `wait` → queue monitoring check/re-eval
- `ignore` → log only

## Include PDE summary in Telegram status/alerts
Suggested message template from AWS3 status publisher:

```text
PDE: ACT (0.846, conf 0.752)
Signal: PBoC liquidity signal + offshore CNH tightening
Reason: score_above_act
Cards: act=1 wait=2 ignore=0
```

For multi-card alerts, include top 1-2 cards + reason tags.

---

## 10) Validation Performed
- Syntax checks passed:
  - `python3 -m py_compile integrations/aws3-pde/pde.py integrations/aws3-pde/outcome_logger.py integrations/aws3-pde/tuner.py`
- Dry run completed with sample events:
  - generated sample decision output and persisted decisions
- Outcome logging + tuner dry run completed:
  - produced sample tuning suggestion JSON

---

## 11) Files Delivered
- `AWS3-PDE.md`
- `integrations/aws3-pde/pde.py`
- `integrations/aws3-pde/outcome_logger.py`
- `integrations/aws3-pde/tuner.py`
- `integrations/aws3-pde/config.example.yaml`
- `integrations/aws3-pde/samples/sample-events.json`
- `integrations/aws3-pde/samples/sample-decision-output.json`
- `integrations/aws3-pde/samples/sample-tuning-output.json`
- `integrations/aws3-pde/state/decisions.jsonl` (generated by dry-run)
- `integrations/aws3-pde/state/outcomes.jsonl` (generated by dry-run)
