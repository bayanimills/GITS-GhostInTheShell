# Senate Economics Committee Member Sweep (Economics Standing Committees)

- Total unique participating members identified: **60**
- Note: APH page currently shows **no upcoming hearings scheduled** for this committee page.

## Participating members (unique union of Legislation + References pages)

1. Penny Allman-Payne
2. Michelle Ananda-Rajah
3. Alex Antic
4. Wendy Askew
5. Ralph Babet
6. Sean Bell
7. Leah Blyth
8. Andrew Bragg
9. Slade Brockman
10. Carol Brown
11. Ross Cadell
12. Michaelia Cash
13. Claire Chandler
14. Raff Ciccone
15. Richard Colbeck
16. Jessica Collins
17. Dorinda Cox
18. Josh Dolega
19. Richard Dowling
20. Jonathon Duniam
21. Mehreen Faruqi
22. Varun Ghosh
23. Karen Grogan
24. Pauline Hanson
25. Sarah Hanson-Young
26. Sarah Henderson
27. Steph Hodgins-May
28. Maria Kovacic
29. Jacqui Lambie
30. Kerrynne Liddle
31. Susan McDonald
32. James McGrath
33. Bridget McKenzie
34. Andrew McLachlan
35. Corinne Mulholland
36. Matt O'Sullivan
37. James Paterson
38. Fatima Payman
39. Barbara Pocock
40. David Pocock
41. Helen Polley
42. Jacinta Nampijinpa Price
43. Malcolm Roberts
44. Anne Ruston
45. Paul Scarr
46. Dave Sharma
47. Tony Sheldon
48. David Shoebridge
49. Marielle Smith
50. Dean Smith
51. Jordon Steele-John
52. Glenn Sterle
53. Jana Stewart
54. Lidia Thorpe
55. Tammy Tyrrell
56. Charlotte Walker
57. Larissa Waters
58. Peter Whish-Wilson
59. Ellie Whiteaker
60. Tyron Whitten