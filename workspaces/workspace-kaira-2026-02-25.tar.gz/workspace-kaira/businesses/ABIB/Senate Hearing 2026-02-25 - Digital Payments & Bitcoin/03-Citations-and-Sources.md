# Citations and Sources

- APH Economics Legislation Committee Membership: https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Economics/Legislation_Committee_Membership
- APH Economics References Committee Membership: https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Economics/References_Committee_Membership
- APH Economics Upcoming Hearings: https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Economics/Upcoming_hearings
- RBA Opening Statement to the Inquiry into Schemes, Digital Wallets and Innovation in the Payments Sector (24 Feb 2026): https://www.rba.gov.au/speeches/2026/sp-so-2026-02-24-2.html
- Parliamentary Library Bills Digest No. 40 (2025–26): Corporations Amendment (Digital Assets Framework) Bill 2025 (PDF provided by user in chat, Feb 2026 excerpt).
