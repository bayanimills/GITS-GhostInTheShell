# Hearing Brief Draft

## Scope
Digital payment systems with Bitcoin-specific evidence and policy relevance.
