# AWS3 Layered Stack (Scraper → EWS/PDE → AWS) MVP

This package wires existing components into a practical, non-destructive integration path:

1. `integrations/scrapling-ews` produces canonical event records.
2. `integrations/aws3-pde` scores and emits decision cards.
3. `scripts/scraper_pde_aws_pipeline.py` builds AWS task payload from top decision card.
4. Existing `mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs` handles dry-run/live task ingestion.

## Included
- `docs/contracts.md` – canonical contract definitions
- `docs/schemas/*.schema.json` – event + decision-card JSON schemas
- `scripts/scraper_pde_aws_pipeline.py` – adapter pipeline wiring
- `RUNBOOK.md` – startup, dry-run, live-run, rollback
- `MIGRATION.md` – rollout guide for other agents
- `evidence/` + `state/` – verification artifacts

## MVP status
- ✅ Safe dry-run path is ready now.
- ✅ Existing adapters reused (no destructive core changes).
- ⚠️ Live-run requires Mission Control reachable + valid `.env` token config.
