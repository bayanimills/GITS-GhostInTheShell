# Runbook: AWS3 Layered Stack MVP

## Start order
1. Prepare `.env` for Mission Control ingest adapter.
2. Run scraper dry-run (fixtures or live sources).
3. Run layered pipeline (PDE + task payload + ingest dry-run).
4. Optional: switch ingest to live (remove `--dry-run`).

## Prerequisites
```bash
cd /home/agent/.openclaw/workspace-kaira
cp integrations/mission-control-aws3-ews-mvp/config/.env.example \
   integrations/mission-control-aws3-ews-mvp/config/.env
```
Set at least:
- `MISSION_CONTROL_BASE_URL`
- `MC_API_TOKEN` (required in production)

## Dry-run
```bash
# 1) Produce deterministic scraper events from fixtures
python3 integrations/scrapling-ews/scrapling_ews.py \
  --config integrations/scrapling-ews/config.template.yaml \
  --fixtures integrations/scrapling-ews/fixtures \
  --output integrations/scrapling-ews/state/normalized-events.json \
  --state integrations/scrapling-ews/state/dedupe-state.json \
  --print-summary

# 2) Execute wired pipeline (non-destructive)
python3 integrations/aws3-layered-stack/scripts/scraper_pde_aws_pipeline.py --dry-run
```

Expected dry-run outputs:
- `integrations/aws3-layered-stack/state/pde-output.json`
- `integrations/aws3-layered-stack/state/task-payload.json`
- `integrations/aws3-layered-stack/evidence/pipeline-evidence.json`

## Live-run
```bash
# Ensure Mission Control is up and token is valid
python3 integrations/aws3-layered-stack/scripts/scraper_pde_aws_pipeline.py
```

## Rollback
- Stop running commands/processes (pipeline is one-shot, no daemon install).
- Revert to dry-run by adding `--dry-run`.
- Ignore/remove generated files in `integrations/aws3-layered-stack/state`.
- No core code in Mission Control/AWS3-PDE is modified by runtime execution.

## Safety
- Default operational recommendation: run dry-run first every deployment.
- All state is file-based and local for auditability.
- No destructive actions in this package.
