# Migration Guide: Roll out AWS3 Layered Stack to another agent workspace

## Goal
Replicate the same Scraper → PDE → AWS wiring with minimal risk.

## Steps
1. Copy folder:
   - `integrations/aws3-layered-stack/`
2. Confirm dependencies exist in target workspace:
   - `integrations/scrapling-ews/`
   - `integrations/aws3-pde/`
   - `integrations/mission-control-aws3-ews-mvp/`
3. Copy/configure env:
   - `integrations/mission-control-aws3-ews-mvp/config/.env`
4. Run syntax + dry-run before any live command.
5. Capture evidence JSON and append review log entry.

## Porting knobs
- `--workflow-id` in pipeline script per agent/workspace.
- scraper config target selectors/keywords (`scrapling-ews/config.template.yaml`).
- PDE tuning (`aws3-pde/config.example.yaml` or local override).

## Minimum acceptance criteria
- Dry-run completes with:
  - canonical events validated
  - decision cards generated
  - ingest dry-run output present
- Evidence file written under `integrations/aws3-layered-stack/evidence/`.
- `tasks/review.md` contains concrete command/log proof.

## External dependencies (live mode)
- Reachable Mission Control API endpoint.
- Valid `MC_API_TOKEN` and any required auth for EWS HTTP path.
