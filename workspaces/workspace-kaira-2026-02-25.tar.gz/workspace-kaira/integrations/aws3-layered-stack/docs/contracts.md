# AWS3 Layered Stack Contracts (Canonical)

## 1) Canonical Event Contract
Schema: `docs/schemas/aws3-canonical-event.schema.json`

Purpose: transport-neutral normalized signal record (Scraper/EWS output) for PDE input.

Minimum required fields:
- `id`, `source`, `title`, `topic`, `region`, `signal_time`
- scoring inputs: `source_reliability`, `market_impact`, `time_sensitivity`, `uncertainty`, `contrarian_signal`

## 2) Decision Card Contract
Schema: `docs/schemas/aws3-decision-card.schema.json`

Purpose: deterministic PDE output card used for task generation and operator review.

Minimum required fields:
- identifiers: `card_id`, `event_id`
- decision: `recommendation` (`act|wait|ignore`), `scores`, `reasons`
- traceability: `created_at`

## 3) Task Payload Contract (adapter output)
Adapter emits payload compatible with existing Mission Control ingest adapter:
- `workflow_id` (string)
- `trace_id` (string)
- `idempotency_key` (string)
- `task` object with `title`, `description`, optional `priority`, `status`

This payload is consumed by:
`integrations/mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs`

## 4) Layer wiring
1. Scraper produces canonical event list JSON.
2. PDE reads canonical events and emits decision cards.
3. AWS adapter picks top `act` (or fallback top card if configured) and builds ingest task payload.
4. Existing AWS3 task-ingest adapter posts to MC (dry-run/live).
