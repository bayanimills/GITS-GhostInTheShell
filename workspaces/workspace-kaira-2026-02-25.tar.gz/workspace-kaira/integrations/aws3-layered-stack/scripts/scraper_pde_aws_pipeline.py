#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any, Dict, List

REQUIRED_EVENT_FIELDS = {
    "id", "source", "title", "topic", "region", "signal_time",
    "source_reliability", "market_impact", "time_sensitivity", "uncertainty", "contrarian_signal"
}

REQUIRED_CARD_FIELDS = {
    "card_id", "event_id", "title", "topic", "region", "recommendation", "scores", "reasons", "actions", "created_at"
}


def run(cmd: List[str], cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=str(cwd), text=True, capture_output=True, check=True)


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def validate_records(records: List[Dict[str, Any]], required: set[str], kind: str) -> None:
    if not records:
        raise ValueError(f"{kind}: no records found")
    for i, rec in enumerate(records):
        missing = sorted(required - set(rec.keys()))
        if missing:
            raise ValueError(f"{kind}: record index {i} missing fields: {missing}")


def make_payload(card: Dict[str, Any], workflow_id: str) -> Dict[str, Any]:
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d%H%M%S")
    trace_id = f"trace-{card['card_id'][:8]}-{ts}"
    idem = hashlib.sha256(f"{workflow_id}:{card['card_id']}".encode("utf-8")).hexdigest()[:20]

    rec = card.get("recommendation", "wait")
    priority = "high" if rec == "act" else "normal"
    status = "inbox"

    title = f"AWS3 {rec.upper()}: {card['title'][:96]}"
    desc = (
        f"PDE recommendation={rec}; blended={card['scores'].get('blended')}; confidence={card['scores'].get('confidence')}\\n"
        f"Reasons: {', '.join(card.get('reasons', []))}\\n"
        f"Event={card.get('event_id')} Card={card.get('card_id')}"
    )

    return {
        "workflow_id": workflow_id,
        "trace_id": trace_id,
        "idempotency_key": idem,
        "task": {
            "title": title,
            "description": desc,
            "priority": priority,
            "status": status,
        },
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Scraper -> PDE -> AWS adapter pipeline")
    ap.add_argument("--workspace", default="/home/agent/.openclaw/workspace-kaira")
    ap.add_argument("--workflow-id", default="aws3-layered-stack-mvp")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--scraper-events", default="integrations/scrapling-ews/state/normalized-events.json")
    ap.add_argument("--pde-out", default="integrations/aws3-layered-stack/state/pde-output.json")
    ap.add_argument("--task-payload", default="integrations/aws3-layered-stack/state/task-payload.json")
    ap.add_argument("--evidence", default="integrations/aws3-layered-stack/evidence/pipeline-evidence.json")
    args = ap.parse_args()

    ws = Path(args.workspace)
    scraper_events = ws / args.scraper_events
    pde_out = ws / args.pde_out
    task_payload = ws / args.task_payload
    evidence = ws / args.evidence

    pde_out.parent.mkdir(parents=True, exist_ok=True)
    task_payload.parent.mkdir(parents=True, exist_ok=True)
    evidence.parent.mkdir(parents=True, exist_ok=True)

    records = load_json(scraper_events, default=[])
    validate_records(records, REQUIRED_EVENT_FIELDS, "canonical-event")

    pde_cmd = [
        "python3", "integrations/aws3-pde/pde.py",
        "--events", str(scraper_events),
        "--config", "integrations/aws3-pde/config.example.yaml",
        "--out", str(pde_out),
    ]
    pde_run = run(pde_cmd, ws)

    pde_json = load_json(pde_out, default={})
    cards = pde_json.get("decision_cards", [])
    validate_records(cards, REQUIRED_CARD_FIELDS, "decision-card")

    top = pde_json.get("top_card") or cards[0]
    payload = make_payload(top, args.workflow_id)
    task_payload.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    ingest_cmd = [
        "node",
        "integrations/mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs",
        "--env", "integrations/mission-control-aws3-ews-mvp/config/.env",
        "--payload", str(task_payload),
    ]
    if args.dry_run:
        ingest_cmd.append("--dry-run")

    ingest_run = run(ingest_cmd, ws)

    ev = {
        "ts": dt.datetime.now(dt.timezone.utc).isoformat(),
        "mode": "dry-run" if args.dry_run else "live",
        "inputs": {
            "scraper_events": str(scraper_events),
            "count": len(records),
        },
        "outputs": {
            "pde_out": str(pde_out),
            "decision_cards": len(cards),
            "task_payload": str(task_payload),
        },
        "commands": {
            "pde": {"cmd": pde_cmd, "stdout": pde_run.stdout.strip()},
            "ingest": {"cmd": ingest_cmd, "stdout": ingest_run.stdout.strip()},
        },
    }
    evidence.write_text(json.dumps(ev, indent=2, ensure_ascii=False), encoding="utf-8")

    print(json.dumps({
        "status": "ok",
        "mode": ev["mode"],
        "records": len(records),
        "cards": len(cards),
        "task_payload": str(task_payload),
        "evidence": str(evidence),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
