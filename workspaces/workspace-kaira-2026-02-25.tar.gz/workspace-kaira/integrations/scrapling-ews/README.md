# Scrapling → AWS3/EWS Integration Prototype (MVP)

This integration adds **HTML page scraping coverage** to Bayani's existing EWS stack while keeping the pipeline deterministic and keyless-first.

## 1) Repo review: where Scrapling helps EWS

### Existing strengths found
- `skills/worldmonitor-ews/worldmonitor-ews.py`
  - Good baseline pollers (USGS, CoinGecko, RSS placeholder)
  - Existing dedupe/quiet-hour suppression patterns
- `integrations/aws3-pde/pde.py`
  - Deterministic scoring + classification (`act/wait/ignore`)
  - Expects event records with fields like:
    - `source`, `topic`, `title`, `region`, `tags`, `signal_time`
    - `source_reliability`, `market_impact`, `time_sensitivity`, `uncertainty`, `contrarian_signal`
- `integrations/mission-control-aws3-ews-mvp/`
  - Envelope contract for downstream publishing

### Gaps Scrapling can improve
- WorldMonitor currently has a simulated RSS parser and limited direct HTML extraction.
- Important geopolitical/crypto/APAC headlines are often only on site pages (not always clean APIs).
- Adding robust DOM extraction increases:
  - **Coverage** (more target sources)
  - **Freshness** (headline-level updates)
  - **Signal quality** (keyword-based quality + source weighting)

### Why this prototype is practical
- Keeps existing AWS3-PDE schema compatibility.
- Adds bounded retries, robots checks, dedupe TTL, and noise filters.
- Uses optional Scrapling with deterministic BeautifulSoup fallback, so pipeline still runs if Scrapling is not installed.

---

## 2) Deliverables included

Path: `integrations/scrapling-ews/`

- `scrapling_ews.py` — runnable prototype scraper/normalizer
- `config.template.yaml` — target/selectors/cadence template
- `fixtures/*.html` — deterministic dry-run fixtures
- `state/` — output + dedupe state

### Setup notes

```bash
cd /home/agent/.openclaw/workspace-kaira/integrations/scrapling-ews

# Optional: create venv for Scrapling install
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install requests pyyaml beautifulsoup4 lxml
# optional, if available in your environment:
pip install scrapling
```

Run deterministic dry-run (fixtures, no external network):

```bash
python3 scrapling_ews.py \
  --config config.template.yaml \
  --fixtures fixtures \
  --output state/normalized-events.json \
  --state state/dedupe-state.json \
  --print-summary
```

Run live targets:

```bash
python3 scrapling_ews.py \
  --config config.template.yaml \
  --output state/normalized-events.json \
  --state state/dedupe-state.json \
  --print-summary
```

---

## 3) Normalized event shape (AWS3-PDE compatible)

Each emitted event includes:
- `id`, `source`, `title`, `summary`, `url`
- `topic`, `region`, `tags`, `sentiment`, `signal_time`
- `source_reliability`, `market_impact`, `time_sensitivity`, `uncertainty`, `contrarian_signal`
- `quality_score`, `dedupe_fp`

Output file is a JSON array suitable for direct ingest by PDE:

```bash
python3 ../aws3-pde/pde.py --events state/normalized-events.json
```

(Use PDE config/decisions-store args as needed.)

---

## 4) Safety notes

- **Robots compliance**: checks `robots.txt` when `runtime.respect_robots=true`.
- **Rate limiting**: `inter_target_sleep_seconds` and bounded retries.
- **Backoff**: deterministic backoff list (default `[1,2,4]`) for 429/5xx/transient errors.
- **Failure handling**: per-target failures are captured in summary; pipeline continues for remaining targets.
- **Fallback behavior**:
  - If Scrapling unavailable, BeautifulSoup parser is used.
  - If one selector set fails, additional selectors can be configured.
- **No secrets required**: keyless public URLs by default.

---

## 5) Integration note (AWS3-PDE / worldmonitor-ews)

### Option A: Feed directly into AWS3-PDE
1. Schedule `scrapling_ews.py` (cron/systemd/OpenClaw task).
2. Write `state/normalized-events.json`.
3. Run PDE against that file:
   - `integrations/aws3-pde/pde.py --events state/normalized-events.json ...`

### Option B: Merge into worldmonitor-ews
- Add a new poller wrapper in `skills/worldmonitor-ews/worldmonitor-ews.py` that executes/embeds this extraction logic.
- Map output events into worldmonitor severity path (INFO/WARNING/CRITICAL) while retaining `quality_score`.
- Reuse worldmonitor dedupe/quiet-hour behavior for channel notifications.

Recommendation: start with Option A for least invasive rollout, then consolidate into worldmonitor once selectors stabilize.
