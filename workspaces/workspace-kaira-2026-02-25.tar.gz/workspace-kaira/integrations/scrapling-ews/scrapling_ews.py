#!/usr/bin/env python3
"""
Scrapling → AWS3/EWS integration prototype (MVP)

Key goals:
- Keyless-first scraping from public pages/feeds
- Optional Scrapling usage with deterministic fallback parser
- Normalize records into AWS3-PDE-friendly event shape
- Deduplicate + basic quality scoring/noise suppression
- Respect robots + rate limits + bounded retry/backoff
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
import yaml
from bs4 import BeautifulSoup


DEFAULT_TIMEOUT = 15
DEFAULT_USER_AGENT = "Bayani-EWS-Scrapling/0.1 (+non-commercial research)"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def stable_hash(payload: Dict[str, Any], n: int = 16) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:n]


def clean_text(v: Optional[str]) -> str:
    return " ".join((v or "").split()).strip()


def load_yaml(path: Path) -> Dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


@dataclass
class Target:
    name: str
    url: str
    topic: str
    region: str
    cadence_seconds: int
    source_reliability: float
    selectors: Dict[str, Any]
    tags: List[str]


class OptionalScraplingParser:
    """Best-effort adaptor. Falls back to BeautifulSoup if Scrapling unavailable/unknown API."""

    def __init__(self) -> None:
        self.available = False
        self._module = None
        try:
            import scrapling  # type: ignore

            self._module = scrapling
            self.available = True
        except Exception:
            self.available = False

    def select_all(self, html: str, selector: str):
        # Known-stable fallback
        soup = BeautifulSoup(html, "lxml")
        return soup.select(selector)


def robots_allowed(url: str, user_agent: str, timeout: int = 10) -> bool:
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    rp = RobotFileParser()
    rp.set_url(robots_url)
    try:
        rp.read()
        return rp.can_fetch(user_agent, url)
    except Exception:
        # Fail-open for MVP, but caller can force strict block if needed.
        return True


def fetch_with_retry(url: str, headers: Dict[str, str], timeout: int, retries: int, backoff: List[float]) -> Tuple[int, str]:
    last_err = None
    for i in range(retries + 1):
        try:
            r = requests.get(url, headers=headers, timeout=timeout)
            if r.status_code in (429, 500, 502, 503, 504):
                if i < retries:
                    sleep_s = backoff[min(i, len(backoff) - 1)]
                    time.sleep(sleep_s)
                    continue
            r.raise_for_status()
            return r.status_code, r.text
        except Exception as e:
            last_err = e
            if i < retries:
                sleep_s = backoff[min(i, len(backoff) - 1)]
                time.sleep(sleep_s)
    raise RuntimeError(f"fetch failed for {url}: {last_err}")


def parse_target_html(target: Target, html: str, parser: OptionalScraplingParser) -> List[Dict[str, Any]]:
    sel = target.selectors
    item_selectors: List[str] = sel.get("item", [])
    title_selector = sel.get("title", "a")
    link_selector = sel.get("link", "a")
    summary_selector = sel.get("summary", "")
    time_selector = sel.get("time", "time")

    nodes = []
    for item_sel in item_selectors:
        nodes = parser.select_all(html, item_sel)
        if nodes:
            break

    out: List[Dict[str, Any]] = []
    for node in nodes:
        # bs4 node API
        title_el = node.select_one(title_selector) if hasattr(node, "select_one") else None
        link_el = node.select_one(link_selector) if hasattr(node, "select_one") else None
        summary_el = node.select_one(summary_selector) if summary_selector and hasattr(node, "select_one") else None
        time_el = node.select_one(time_selector) if time_selector and hasattr(node, "select_one") else None

        title = clean_text(title_el.get_text(" ", strip=True) if title_el else node.get_text(" ", strip=True))
        href = ""
        if link_el is not None:
            href = link_el.get("href", "") or ""
        url = urljoin(target.url, href)
        summary = clean_text(summary_el.get_text(" ", strip=True) if summary_el else "")
        published = clean_text((time_el.get("datetime") if time_el else "") or (time_el.get_text(" ", strip=True) if time_el else ""))

        if not title or not url:
            continue

        out.append(
            {
                "source": target.name,
                "title": title,
                "url": url,
                "summary": summary,
                "published_raw": published,
                "topic": target.topic,
                "region": target.region,
                "tags": list(target.tags),
                "source_reliability": float(target.source_reliability),
            }
        )
    return out


def normalize_event(raw: Dict[str, Any], keyword_weights: Dict[str, float]) -> Dict[str, Any]:
    text = f"{raw.get('title','')} {raw.get('summary','')}".lower()
    kw_hits = [k for k in keyword_weights.keys() if k.lower() in text]
    kw_score = sum(keyword_weights[k] for k in kw_hits) if kw_hits else 0.0

    market_impact = min(1.0, 0.35 + 0.15 * len(kw_hits))
    time_sensitivity = 0.65 if any(k in text for k in ["now", "breaking", "urgent", "hack", "ban", "explosion"]) else 0.45
    uncertainty = 0.35 if raw.get("source_reliability", 0.5) >= 0.7 else 0.55
    sentiment = "negative" if any(k in text for k in ["war", "sanction", "exploit", "outage", "ban", "attack"]) else "neutral"
    contrarian_signal = 0.65 if any(k in text for k in ["panic", "sell-off", "ban", "liquidation"]) else 0.45

    event_key = {
        "source": raw.get("source"),
        "title": raw.get("title"),
        "url": raw.get("url"),
        "topic": raw.get("topic"),
    }
    eid = stable_hash(event_key, n=20)

    return {
        "id": f"scr-{eid}",
        "source": raw.get("source"),
        "title": raw.get("title"),
        "summary": raw.get("summary", ""),
        "url": raw.get("url"),
        "topic": raw.get("topic", "geopolitics"),
        "region": raw.get("region", "global"),
        "tags": sorted(set(raw.get("tags", []) + kw_hits)),
        "sentiment": sentiment,
        "signal_time": utc_now_iso(),
        "published_raw": raw.get("published_raw", ""),
        "source_reliability": round(float(raw.get("source_reliability", 0.5)), 2),
        "market_impact": round(market_impact, 2),
        "time_sensitivity": round(time_sensitivity, 2),
        "uncertainty": round(uncertainty, 2),
        "contrarian_signal": round(contrarian_signal, 2),
        "quality_score": round(min(1.0, 0.4 * raw.get("source_reliability", 0.5) + 0.2 * min(1.0, kw_score) + 0.2 * market_impact + 0.2 * time_sensitivity), 2),
    }


def suppress_noise(events: Iterable[Dict[str, Any]], min_quality: float, blocked_keywords: List[str], min_title_chars: int) -> List[Dict[str, Any]]:
    out = []
    for e in events:
        title = e.get("title", "")
        title_l = title.lower()
        if len(title) < min_title_chars:
            continue
        if any(b.lower() in title_l for b in blocked_keywords):
            continue
        if float(e.get("quality_score", 0.0)) < min_quality:
            continue
        out.append(e)
    return out


def dedupe(events: Iterable[Dict[str, Any]], state: Dict[str, Any], ttl_hours: int) -> List[Dict[str, Any]]:
    now = time.time()
    seen = state.setdefault("seen", {})
    fresh: List[Dict[str, Any]] = []

    # prune
    ttl_s = ttl_hours * 3600
    for k, ts in list(seen.items()):
        if now - float(ts) > ttl_s:
            seen.pop(k, None)

    for e in events:
        fp = stable_hash({"source": e.get("source"), "title": e.get("title"), "url": e.get("url")}, n=18)
        if fp in seen:
            continue
        seen[fp] = now
        e["dedupe_fp"] = fp
        fresh.append(e)
    return fresh


def load_targets(cfg: Dict[str, Any]) -> List[Target]:
    targets = []
    for t in cfg.get("targets", []):
        targets.append(
            Target(
                name=t["name"],
                url=t["url"],
                topic=t.get("topic", "geopolitics"),
                region=t.get("region", "global"),
                cadence_seconds=int(t.get("cadence_seconds", 300)),
                source_reliability=float(t.get("source_reliability", 0.6)),
                selectors=t.get("selectors", {}),
                tags=t.get("tags", []),
            )
        )
    return targets


def run(config_path: Path, output_path: Path, state_path: Path, fixtures_dir: Optional[Path] = None) -> Dict[str, Any]:
    cfg = load_yaml(config_path)
    parser = OptionalScraplingParser()
    targets = load_targets(cfg)

    runtime = cfg.get("runtime", {})
    headers = {"User-Agent": runtime.get("user_agent", DEFAULT_USER_AGENT)}
    timeout = int(runtime.get("timeout_seconds", DEFAULT_TIMEOUT))
    retries = int(runtime.get("retries", 2))
    backoff = list(runtime.get("backoff_seconds", [1, 2, 4]))
    respect_robots = bool(runtime.get("respect_robots", True))

    keyword_weights = cfg.get("scoring", {}).get("keyword_weights", {})
    blocked_keywords = cfg.get("noise", {}).get("blocked_keywords", ["sponsored", "advertisement", "opinion"]) 
    min_title_chars = int(cfg.get("noise", {}).get("min_title_chars", 18))
    min_quality = float(cfg.get("noise", {}).get("min_quality", 0.45))
    dedupe_ttl_hours = int(cfg.get("dedupe", {}).get("ttl_hours", 24))

    state = load_json(state_path, {"seen": {}})
    raw_items: List[Dict[str, Any]] = []
    failures: List[Dict[str, str]] = []

    for target in targets:
        try:
            if respect_robots and not (fixtures_dir and fixtures_dir.exists()):
                if not robots_allowed(target.url, headers["User-Agent"]):
                    failures.append({"target": target.name, "error": "blocked_by_robots"})
                    continue

            if fixtures_dir and (fixtures_dir / f"{target.name}.html").exists():
                html = (fixtures_dir / f"{target.name}.html").read_text(encoding="utf-8")
            else:
                _, html = fetch_with_retry(target.url, headers=headers, timeout=timeout, retries=retries, backoff=backoff)

            raw_items.extend(parse_target_html(target, html, parser))
            # polite pacing between domains/targets
            time.sleep(float(runtime.get("inter_target_sleep_seconds", 0.5)))
        except Exception as e:
            failures.append({"target": target.name, "error": str(e)})

    normalized = [normalize_event(x, keyword_weights) for x in raw_items]
    filtered = suppress_noise(normalized, min_quality=min_quality, blocked_keywords=blocked_keywords, min_title_chars=min_title_chars)
    fresh = dedupe(filtered, state, ttl_hours=dedupe_ttl_hours)
    save_json(state_path, state)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(fresh, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "ts": utc_now_iso(),
        "targets": len(targets),
        "raw_items": len(raw_items),
        "normalized": len(normalized),
        "after_noise": len(filtered),
        "after_dedupe": len(fresh),
        "scrapling_available": parser.available,
        "output": str(output_path),
        "failures": failures,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Scrapling integration prototype for AWS3/EWS")
    ap.add_argument("--config", default="config.template.yaml", help="YAML config path")
    ap.add_argument("--output", default="state/normalized-events.json", help="Where normalized events JSON array is written")
    ap.add_argument("--state", default="state/dedupe-state.json", help="State file for dedupe fingerprints")
    ap.add_argument("--fixtures", default="", help="Optional fixtures directory for deterministic dry-runs")
    ap.add_argument("--print-summary", action="store_true", help="Print run summary JSON")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    summary = run(
        config_path=Path(args.config),
        output_path=Path(args.output),
        state_path=Path(args.state),
        fixtures_dir=Path(args.fixtures) if args.fixtures else None,
    )

    if args.print_summary:
        print(json.dumps(summary, indent=2, ensure_ascii=False))
    else:
        print(f"ok: wrote {summary['after_dedupe']} events -> {summary['output']}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
