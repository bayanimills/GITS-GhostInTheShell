#!/usr/bin/env python3
"""Outcome logger for AWS3-PDE decisions.

Records realized outcomes at 1h/24h/7d horizons for later tuning.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser(description="Record outcome labels for PDE decisions")
    ap.add_argument("--decision-id", required=True)
    ap.add_argument("--horizon", required=True, choices=["1h", "24h", "7d"])
    ap.add_argument("--outcome", required=True, choices=["good", "neutral", "bad"])
    ap.add_argument("--notes", default="")
    ap.add_argument("--outcomes-store", default="integrations/aws3-pde/state/outcomes.jsonl")
    ap.add_argument("--metadata", help="Optional JSON object")
    args = ap.parse_args()

    metadata = json.loads(args.metadata) if args.metadata else {}

    row = {
        "decision_id": args.decision_id,
        "horizon": args.horizon,
        "outcome": args.outcome,
        "notes": args.notes,
        "metadata": metadata,
        "logged_at": _iso_now(),
    }

    _append_jsonl(Path(args.outcomes_store), row)
    print(json.dumps({"ok": True, "logged": row}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
