#!/usr/bin/env python3
"""Deterministic tuner for AWS3-PDE.

Uses logged outcomes to suggest weight and threshold updates.
No heavy ML. Rule-based adjustments only.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List


OUTCOME_SCORE = {"good": 1.0, "neutral": 0.0, "bad": -1.0}


def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _index_outcomes(outcomes: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    idx: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in outcomes:
        idx[row["decision_id"]].append(row)
    return idx


def _weighted_outcome(rows: List[Dict[str, Any]]) -> float:
    # More weight for longer horizon quality.
    horizon_w = {"1h": 0.2, "24h": 0.35, "7d": 0.45}
    s = 0.0
    w = 0.0
    for r in rows:
        hw = horizon_w.get(r.get("horizon", "1h"), 0.2)
        s += hw * OUTCOME_SCORE.get(r.get("outcome", "neutral"), 0.0)
        w += hw
    return s / w if w else 0.0


def suggest(decisions: List[Dict[str, Any]], outcomes: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Dict[str, Any]:
    by_id = _index_outcomes(outcomes)

    with_outcomes = []
    for d in decisions:
        oid = d.get("decision_id")
        rows = by_id.get(oid, [])
        if not rows:
            continue
        perf = _weighted_outcome(rows)
        with_outcomes.append((d, perf))

    if not with_outcomes:
        return {
            "message": "No overlapping decisions/outcomes yet; no tuning suggestion.",
            "suggested_config_patch": {},
            "stats": {"matched": 0},
        }

    act_perf = []
    wait_perf = []
    ignore_perf = []

    high_conf_bad = 0
    high_conf_total = 0

    for d, perf in with_outcomes:
        rec = d.get("recommendation")
        if rec == "act":
            act_perf.append(perf)
        elif rec == "wait":
            wait_perf.append(perf)
        else:
            ignore_perf.append(perf)

        conf = float(d.get("scores", {}).get("confidence", 0.0))
        if conf >= 0.75:
            high_conf_total += 1
            if perf < 0:
                high_conf_bad += 1

    def avg(xs: List[float]) -> float:
        return sum(xs) / len(xs) if xs else 0.0

    act_avg = avg(act_perf)
    wait_avg = avg(wait_perf)
    ign_avg = avg(ignore_perf)

    current = cfg
    patch: Dict[str, Any] = {"weights": {}, "thresholds": {}}
    notes: List[str] = []

    # Rule 1: if act underperforms, raise act threshold and lower urgency weight slightly.
    if act_perf and act_avg < -0.15:
        patch["thresholds"]["act_min"] = round(min(0.9, current["thresholds"]["act_min"] + 0.03), 3)
        patch["weights"]["urgency"] = round(max(0.15, current["weights"]["urgency"] - 0.03), 3)
        notes.append("Act decisions underperforming: tighten act gate, reduce urgency overreaction.")

    # Rule 2: if wait outperforms act by margin, reward relevance/risk-fit focus.
    if wait_perf and act_perf and (wait_avg - act_avg) > 0.2:
        patch["weights"]["relevance"] = round(min(0.65, current["weights"]["relevance"] + 0.02), 3)
        patch["weights"]["risk_fit"] = round(min(0.55, current["weights"]["risk_fit"] + 0.02), 3)
        notes.append("Wait better than act: bias toward relevance/risk-fit confirmation.")

    # Rule 3: if many high-confidence misses, increase confidence floor.
    if high_conf_total >= 5 and (high_conf_bad / high_conf_total) > 0.3:
        patch["thresholds"]["confidence_min"] = round(
            min(0.85, current["thresholds"]["confidence_min"] + 0.04), 3
        )
        notes.append("High-confidence misses elevated: raise confidence minimum.")

    # Rule 4: if ignore strongly negative, lower wait threshold to catch opportunities.
    if ignore_perf and ign_avg < -0.2:
        patch["thresholds"]["wait_min"] = round(max(0.3, current["thresholds"]["wait_min"] - 0.03), 3)
        notes.append("Ignored events performed poorly: lower wait_min to surface more candidates.")

    # Normalize if no concrete changes.
    patch = {
        "weights": {k: v for k, v in patch["weights"].items() if v is not None},
        "thresholds": {k: v for k, v in patch["thresholds"].items() if v is not None},
    }

    return {
        "message": "Tuning suggestion generated.",
        "suggested_config_patch": patch,
        "notes": notes,
        "stats": {
            "matched": len(with_outcomes),
            "act_avg": round(act_avg, 3),
            "wait_avg": round(wait_avg, 3),
            "ignore_avg": round(ign_avg, 3),
            "high_conf_bad_ratio": round((high_conf_bad / high_conf_total), 3) if high_conf_total else None,
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Deterministic tuner for AWS3-PDE")
    ap.add_argument("--decisions-store", default="integrations/aws3-pde/state/decisions.jsonl")
    ap.add_argument("--outcomes-store", default="integrations/aws3-pde/state/outcomes.jsonl")
    ap.add_argument("--config", help="Path to config JSON (or JSON-formatted .yaml file)")
    ap.add_argument("--out", help="Write suggestion JSON to file")
    args = ap.parse_args()

    cfg_path = Path(args.config) if args.config else None
    if cfg_path:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    else:
        from pde import DEFAULT_CONFIG

        cfg = DEFAULT_CONFIG

    decisions = _load_jsonl(Path(args.decisions_store))
    outcomes = _load_jsonl(Path(args.outcomes_store))
    result = suggest(decisions, outcomes, cfg)

    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
