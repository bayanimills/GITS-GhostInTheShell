#!/usr/bin/env python3
"""AWS3-PDE MVP

Deterministic Personal Decision Engine for AWS/EWS signals.

Features:
- Ingest signal events JSON (list of events)
- Score relevance, urgency, and risk-fit
- Emit decision cards (act/wait/ignore)
- Persist decisions to local JSONL store
- Safety/noise controls: dedupe, cooldown, confidence gate, quiet-hours
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


DEFAULT_CONFIG = {
    "profile": {
        "owner": "Bayani",
        "region": "APAC",
        "risk_posture": "moderate-contrarian",
        "focus_topics": ["bitcoin", "macro", "geopolitics", "apac-policy", "liquidity"],
        "avoid_topics": ["memecoin-noise"],
    },
    "weights": {
        "relevance": 0.45,
        "urgency": 0.30,
        "risk_fit": 0.25,
    },
    "thresholds": {
        "act_min": 0.70,
        "wait_min": 0.45,
        "confidence_min": 0.55,
    },
    "safety": {
        "dedupe_window_minutes": 120,
        "cooldown_minutes": 30,
        "max_act_per_hour": 3,
        "quiet_hours": {"start": "23:00", "end": "07:00", "act_only_if_critical": True},
    },
}


def _load_yaml_like(path: Optional[Path]) -> Dict[str, Any]:
    """Very small YAML-like reader: supports JSON, else fallback defaults.

    To keep MVP dependency-free, config file may be JSON or omitted.
    If config is YAML, user should convert to JSON or install a YAML parser externally.
    """
    if not path:
        return DEFAULT_CONFIG
    text = path.read_text(encoding="utf-8")
    # Try JSON first for deterministic/no-dependency behavior.
    try:
        cfg = json.loads(text)
        return _merge(DEFAULT_CONFIG, cfg)
    except json.JSONDecodeError:
        # Minimal best-effort for key: value YAML fragments is intentionally omitted.
        # Keep behavior explicit/safe.
        raise ValueError(
            "Config parsing failed. Use JSON content in config file for this MVP (config.example.yaml includes JSON-compatible structure)."
        )


def _merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _event_fingerprint(event: Dict[str, Any]) -> str:
    key_fields = {
        "source": event.get("source"),
        "topic": event.get("topic"),
        "title": event.get("title"),
        "region": event.get("region"),
        "sentiment": event.get("sentiment"),
        "signal_time": event.get("signal_time"),
    }
    raw = json.dumps(key_fields, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _parse_hhmm(v: str) -> Tuple[int, int]:
    hh, mm = v.split(":", 1)
    return int(hh), int(mm)


def _in_quiet_hours(now_utc: datetime, quiet: Dict[str, Any]) -> bool:
    # Treat timestamps as local wall-clock in Sydney-optimized deployments if local timezone used externally.
    # Here we use UTC hour-only check if no tz conversion layer exists.
    start_h, start_m = _parse_hhmm(quiet["start"])
    end_h, end_m = _parse_hhmm(quiet["end"])
    now_m = now_utc.hour * 60 + now_utc.minute
    start = start_h * 60 + start_m
    end = end_h * 60 + end_m
    if start <= end:
        return start <= now_m < end
    return now_m >= start or now_m < end


@dataclass
class Score:
    relevance: float
    urgency: float
    risk_fit: float
    blended: float
    confidence: float


def clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def score_event(event: Dict[str, Any], cfg: Dict[str, Any]) -> Score:
    focus_topics = set(t.lower() for t in cfg["profile"].get("focus_topics", []))
    avoid_topics = set(t.lower() for t in cfg["profile"].get("avoid_topics", []))

    topic = str(event.get("topic", "")).lower()
    tags = set(t.lower() for t in event.get("tags", []))
    region = str(event.get("region", "")).lower()
    source_reliability = float(event.get("source_reliability", 0.5))
    market_impact = float(event.get("market_impact", 0.5))
    time_sensitivity = float(event.get("time_sensitivity", 0.5))
    uncertainty = float(event.get("uncertainty", 0.5))
    contrarian_signal = float(event.get("contrarian_signal", 0.5))

    rel = 0.2
    if topic in focus_topics:
        rel += 0.35
    if tags & focus_topics:
        rel += 0.2
    if topic in avoid_topics:
        rel -= 0.25
    if "apac" in region:
        rel += 0.1
    rel += 0.15 * source_reliability
    relevance = clamp01(rel)

    urgency = clamp01(0.5 * time_sensitivity + 0.35 * market_impact + 0.15 * (1 - uncertainty))

    risk_posture = cfg["profile"].get("risk_posture", "moderate")
    if "contrarian" in risk_posture:
        risk_fit = clamp01(0.45 * contrarian_signal + 0.25 * source_reliability + 0.30 * (1 - uncertainty))
    else:
        risk_fit = clamp01(0.15 * contrarian_signal + 0.40 * source_reliability + 0.45 * (1 - uncertainty))

    w = cfg["weights"]
    blended = clamp01(w["relevance"] * relevance + w["urgency"] * urgency + w["risk_fit"] * risk_fit)

    # Confidence should reward reliable low-uncertainty inputs and consensus among dimensions.
    spread = max(relevance, urgency, risk_fit) - min(relevance, urgency, risk_fit)
    confidence = clamp01(0.45 * source_reliability + 0.35 * (1 - uncertainty) + 0.20 * (1 - spread))

    return Score(relevance, urgency, risk_fit, blended, confidence)


def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def classify(score: Score, cfg: Dict[str, Any], policy: Dict[str, Any]) -> Tuple[str, List[str]]:
    reasons: List[str] = []
    t = cfg["thresholds"]
    if score.confidence < t["confidence_min"]:
        reasons.append("confidence_below_min")
        return "wait", reasons

    if policy.get("deduped", False):
        reasons.append("dedupe_window")
        return "ignore", reasons

    if policy.get("cooldown_active", False):
        reasons.append("cooldown_active")
        return "wait", reasons

    if policy.get("quiet_hours", False) and policy.get("act_only_if_critical", True):
        if score.blended < 0.85:
            reasons.append("quiet_hours_non_critical")
            return "wait", reasons

    if score.blended >= t["act_min"]:
        reasons.append("score_above_act")
        return "act", reasons
    if score.blended >= t["wait_min"]:
        reasons.append("score_above_wait")
        return "wait", reasons

    reasons.append("score_below_wait")
    return "ignore", reasons


def _policy_flags(event: Dict[str, Any], history: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Dict[str, Any]:
    now = datetime.now(timezone.utc)
    fp = _event_fingerprint(event)
    dedupe_mins = int(cfg["safety"].get("dedupe_window_minutes", 120))
    cooldown_mins = int(cfg["safety"].get("cooldown_minutes", 30))

    deduped = False
    cooldown_active = False

    for row in reversed(history):
        ts = datetime.fromisoformat(row["created_at"])
        age_m = (now - ts).total_seconds() / 60
        if age_m > max(dedupe_mins, cooldown_mins):
            break
        if row.get("event_fingerprint") == fp and age_m <= dedupe_mins:
            deduped = True
        if row.get("recommendation") == "act" and age_m <= cooldown_mins:
            cooldown_active = True

    q = cfg["safety"].get("quiet_hours", {})
    quiet = _in_quiet_hours(now, q) if q else False

    return {
        "deduped": deduped,
        "cooldown_active": cooldown_active,
        "quiet_hours": quiet,
        "act_only_if_critical": bool(q.get("act_only_if_critical", True)),
    }


def build_card(event: Dict[str, Any], score: Score, recommendation: str, reasons: List[str]) -> Dict[str, Any]:
    return {
        "card_id": hashlib.sha256(f"{event.get('id','')}|{_iso_now()}".encode()).hexdigest()[:20],
        "event_id": event.get("id"),
        "title": event.get("title", "Untitled signal"),
        "topic": event.get("topic"),
        "region": event.get("region"),
        "recommendation": recommendation,
        "scores": {
            "relevance": round(score.relevance, 3),
            "urgency": round(score.urgency, 3),
            "risk_fit": round(score.risk_fit, 3),
            "blended": round(score.blended, 3),
            "confidence": round(score.confidence, 3),
        },
        "reasons": reasons,
        "actions": {
            "act": "execute playbook + alert user",
            "wait": "monitor 30-120m for confirmation",
            "ignore": "log only",
        },
        "created_at": _iso_now(),
    }


def run(events: List[Dict[str, Any]], cfg: Dict[str, Any], decisions_store: Path) -> Dict[str, Any]:
    history = _load_jsonl(decisions_store)
    cards: List[Dict[str, Any]] = []

    for ev in events:
        s = score_event(ev, cfg)
        policy = _policy_flags(ev, history, cfg)
        recommendation, reasons = classify(s, cfg, policy)
        card = build_card(ev, s, recommendation, reasons)
        cards.append(card)

        store_row = {
            "decision_id": card["card_id"],
            "event_id": ev.get("id"),
            "event_fingerprint": _event_fingerprint(ev),
            "recommendation": recommendation,
            "scores": card["scores"],
            "reasons": reasons,
            "created_at": card["created_at"],
            "topic": ev.get("topic"),
            "region": ev.get("region"),
            "source": ev.get("source"),
        }
        _append_jsonl(decisions_store, store_row)
        history.append(store_row)

    ranked = sorted(cards, key=lambda c: c["scores"]["blended"], reverse=True)
    top = ranked[0] if ranked else None

    summary = {
        "generated_at": _iso_now(),
        "count": len(cards),
        "top_recommendation": top["recommendation"] if top else None,
        "top_card": top,
        "decision_cards": ranked,
    }
    return summary


def main() -> None:
    ap = argparse.ArgumentParser(description="AWS3-PDE deterministic decision engine")
    ap.add_argument("--events", required=True, help="Path to input events JSON (list)")
    ap.add_argument("--config", help="Path to JSON-formatted config (can use .yaml filename)")
    ap.add_argument(
        "--decisions-store",
        default="integrations/aws3-pde/state/decisions.jsonl",
        help="JSONL path for persisted decisions",
    )
    ap.add_argument("--out", help="Write result JSON to file")
    args = ap.parse_args()

    cfg = _load_yaml_like(Path(args.config)) if args.config else DEFAULT_CONFIG
    events = json.loads(Path(args.events).read_text(encoding="utf-8"))
    if not isinstance(events, list):
        raise ValueError("events file must be a JSON array")

    result = run(events, cfg, Path(args.decisions_store))

    out_text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.out:
        Path(args.out).write_text(out_text + "\n", encoding="utf-8")
    else:
        print(out_text)


if __name__ == "__main__":
    main()
