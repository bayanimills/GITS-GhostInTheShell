# AWS3-PDE MVP

Deterministic Personal Decision Engine for AWS/EWS signal events.

## Quick start

```bash
# 1) Run PDE on sample events
python3 integrations/aws3-pde/pde.py \
  --events integrations/aws3-pde/samples/sample-events.json \
  --config integrations/aws3-pde/config.example.yaml \
  --out integrations/aws3-pde/samples/sample-decision-output.json

# 2) Log outcomes (example)
python3 integrations/aws3-pde/outcome_logger.py --decision-id <DECISION_ID> --horizon 1h --outcome good --notes "confirmed"
python3 integrations/aws3-pde/outcome_logger.py --decision-id <DECISION_ID> --horizon 24h --outcome neutral
python3 integrations/aws3-pde/outcome_logger.py --decision-id <DECISION_ID> --horizon 7d --outcome bad

# 3) Produce tuning suggestions
python3 integrations/aws3-pde/tuner.py \
  --config integrations/aws3-pde/config.example.yaml \
  --out integrations/aws3-pde/samples/sample-tuning-output.json

# 4) Validate syntax
python3 -m py_compile integrations/aws3-pde/pde.py integrations/aws3-pde/outcome_logger.py integrations/aws3-pde/tuner.py
```

## AWS3 flow integration

```bash
python3 integrations/aws3-pde/pde.py --events /tmp/aws3-events.json --out /tmp/pde-output.json
```

Then use `/tmp/pde-output.json.top_card` in AWS Telegram status:

```text
PDE: ACT (0.846, conf 0.752) | Signal: PBoC liquidity signal + offshore CNH tightening | Reason: score_above_act
```
