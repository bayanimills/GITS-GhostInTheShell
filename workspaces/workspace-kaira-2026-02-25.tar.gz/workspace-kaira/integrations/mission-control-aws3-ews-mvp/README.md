# Mission Control × AWS3/EWS MVP Integration Kit

Practical, reversible integration artifacts for Bayani workspace.

## Included
- `scripts/aws3-task-ingest.mjs` — AWS3 -> Mission Control task ingestion with idempotency
- `scripts/mc-ews-bridge.mjs` — Mission Control SSE -> normalized EWS envelope publisher
- `scripts/mock-ews-endpoint.mjs` — local test receiver for HTTP publish mode
- `scripts/mock-mc-sse-server.mjs` — local mock Mission Control SSE source for bridge verification
- `config/.env.example` — secure defaults template (prod secrets required)
- `docs/event-contract.md` + JSON schema
- `RUNBOOK.md` — startup/testing instructions

## Security defaults
- In `NODE_ENV=production`, scripts fail fast when required secrets are missing.
- No permissive production fallback for tokens/secrets.
- No destructive operations.

## Quick start
```bash
cp integrations/mission-control-aws3-ews-mvp/config/.env.example integrations/mission-control-aws3-ews-mvp/config/.env
node integrations/mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs \
  --env integrations/mission-control-aws3-ews-mvp/config/.env \
  --payload integrations/mission-control-aws3-ews-mvp/examples/sample-task.json \
  --dry-run
```

Then follow `RUNBOOK.md` for live bridge testing.
