# Runbook: Mission Control × AWS3/EWS MVP Integration

## 1) Prepare environment
```bash
cd /home/agent/.openclaw/workspace-kaira
cp integrations/mission-control-aws3-ews-mvp/config/.env.example integrations/mission-control-aws3-ews-mvp/config/.env
```

Edit `config/.env`:
- Set `MISSION_CONTROL_BASE_URL`
- Set `MC_API_TOKEN` if MC auth is enabled
- Choose `EWS_PUBLISH_MODE` (`stdout`, `file`, or `http`)
- For `http`, set `EWS_HTTP_ENDPOINT`, `EWS_HTTP_BEARER_TOKEN`, `WEBHOOK_SECRET`

## 2) Validate scripts
```bash
node --check integrations/mission-control-aws3-ews-mvp/scripts/common.mjs
node --check integrations/mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs
node --check integrations/mission-control-aws3-ews-mvp/scripts/mc-ews-bridge.mjs
node --check integrations/mission-control-aws3-ews-mvp/scripts/mock-ews-endpoint.mjs
```

## 3) Dry-run AWS3 task ingestion
```bash
node integrations/mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs \
  --env integrations/mission-control-aws3-ews-mvp/config/.env \
  --payload integrations/mission-control-aws3-ews-mvp/examples/sample-task.json \
  --dry-run
```

## 4) Live test path (local)
1. Ensure Mission Control is running (`npm run dev` in `mission-control/`)
2. Start mock EWS endpoint (optional if using HTTP mode):
```bash
PORT=8787 node integrations/mission-control-aws3-ews-mvp/scripts/mock-ews-endpoint.mjs
```
3. Start bridge:
```bash
node integrations/mission-control-aws3-ews-mvp/scripts/mc-ews-bridge.mjs \
  --env integrations/mission-control-aws3-ews-mvp/config/.env
```
4. Create task from AWS3 adapter:
```bash
node integrations/mission-control-aws3-ews-mvp/scripts/aws3-task-ingest.mjs \
  --env integrations/mission-control-aws3-ews-mvp/config/.env \
  --payload integrations/mission-control-aws3-ews-mvp/examples/sample-task.json
```
5. Confirm normalized event arrived in:
- stdout (bridge logs), or
- `state/ews-events.jsonl`, or
- `state/mock-ews-received.jsonl`

## 4b) Fully mocked integration test (no Mission Control dependency)
```bash
PORT=4011 node integrations/mission-control-aws3-ews-mvp/scripts/mock-mc-sse-server.mjs
```
Then in another terminal:
```bash
MISSION_CONTROL_BASE_URL=http://127.0.0.1:4011 EWS_PUBLISH_MODE=stdout \
  node integrations/mission-control-aws3-ews-mvp/scripts/mc-ews-bridge.mjs --once
```

## 5) Operational checks
- Bridge reconnects with exponential backoff if SSE drops.
- Ingestion is idempotent via `IDEMPOTENCY_STORE_PATH`.
- Production mode (`NODE_ENV=production`) enforces secret presence.

## 6) Rollback
- Stop bridge and ingest scripts (no persistent daemon installed).
- Remove/ignore integration folder; no core MC code modified by this MVP.
