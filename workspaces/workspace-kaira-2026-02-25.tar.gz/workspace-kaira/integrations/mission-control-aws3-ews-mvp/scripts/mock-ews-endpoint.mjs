#!/usr/bin/env node
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const port = Number(process.env.PORT || 8787);
const out = process.env.OUT || './integrations/mission-control-aws3-ews-mvp/state/mock-ews-received.jsonl';
fs.mkdirSync(path.dirname(out), { recursive: true });

const server = http.createServer((req, res) => {
  if (req.method !== 'POST') {
    res.statusCode = 405;
    res.end('method not allowed');
    return;
  }

  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => {
    const body = Buffer.concat(chunks).toString('utf8');
    fs.appendFileSync(out, body + '\n');
    res.statusCode = 202;
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ ok: true }));
  });
});

server.listen(port, () => {
  console.log(`mock ews listening on http://127.0.0.1:${port}`);
});
