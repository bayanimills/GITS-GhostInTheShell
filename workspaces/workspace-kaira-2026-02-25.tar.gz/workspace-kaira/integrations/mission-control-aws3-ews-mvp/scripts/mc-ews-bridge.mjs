#!/usr/bin/env node
import path from 'node:path';
import {
  appendJsonl,
  loadEnvFile,
  parseTaggedValue,
  randomId,
  requireProductionSecrets,
  signPayload,
} from './common.mjs';

const argv = process.argv.slice(2);
const getArg = (name, fallback = null) => {
  const i = argv.indexOf(name);
  return i === -1 ? fallback : (argv[i + 1] ?? fallback);
};
const hasArg = (name) => argv.includes(name);

loadEnvFile(getArg('--env', path.resolve('integrations/mission-control-aws3-ews-mvp/config/.env')));
const baseUrl = process.env.MISSION_CONTROL_BASE_URL || 'http://127.0.0.1:4000';
const mode = process.env.EWS_PUBLISH_MODE || 'stdout';
const filePath = process.env.EWS_FILE_PATH || './integrations/mission-control-aws3-ews-mvp/state/ews-events.jsonl';
const httpEndpoint = process.env.EWS_HTTP_ENDPOINT || '';
const httpToken = process.env.EWS_HTTP_BEARER_TOKEN || '';
const webhookSecret = process.env.WEBHOOK_SECRET || '';

if (mode === 'http') {
  requireProductionSecrets(['MC_API_TOKEN', 'EWS_HTTP_BEARER_TOKEN', 'WEBHOOK_SECRET']);
} else {
  requireProductionSecrets(['MC_API_TOKEN']);
}

const once = hasArg('--once');

function normalize(raw) {
  const p = raw.payload || {};
  const desc = p.description || p.message || p.summary || '';
  const taskId = p.task_id || p.taskId || p.id || 'unknown';
  const workflowId = parseTaggedValue(desc, 'aws3.workflow_id') || 'unknown';
  const traceId = parseTaggedValue(desc, 'aws3.trace_id') || randomId('trace');
  const idem = parseTaggedValue(desc, 'aws3.idempotency_key');

  return {
    event_id: randomId('evt'),
    event_type: raw.type,
    source: 'mission-control',
    ts: new Date().toISOString(),
    trace_id: traceId,
    workflow_id: workflowId,
    task_id: taskId,
    agent_id: p.agent_id || p.assigned_agent_id || null,
    status: p.status || null,
    idempotency_key: idem || null,
    data: p,
  };
}

async function publish(event) {
  if (mode === 'stdout') {
    console.log(JSON.stringify(event));
    return;
  }
  if (mode === 'file') {
    appendJsonl(filePath, event);
    return;
  }
  if (mode === 'http') {
    if (!httpEndpoint) throw new Error('EWS_HTTP_ENDPOINT is required for http mode');
    const payload = JSON.stringify(event);
    const sig = signPayload(payload, webhookSecret);
    const headers = { 'content-type': 'application/json' };
    if (httpToken) headers.authorization = `Bearer ${httpToken}`;
    if (sig) headers['x-signature-sha256'] = sig;
    const res = await fetch(httpEndpoint, { method: 'POST', headers, body: payload });
    if (!res.ok) {
      throw new Error(`EWS publish failed (${res.status}): ${await res.text()}`);
    }
    return;
  }
  throw new Error(`Unsupported EWS_PUBLISH_MODE: ${mode}`);
}

async function connectLoop() {
  let attempt = 0;
  const base = Number(process.env.BRIDGE_RECONNECT_BASE_MS || 1000);
  const max = Number(process.env.BRIDGE_RECONNECT_MAX_MS || 30000);

  while (true) {
    const token = process.env.MC_API_TOKEN;
    const streamUrl = token ? `${baseUrl}/api/events/stream?token=${encodeURIComponent(token)}` : `${baseUrl}/api/events/stream`;

    try {
      const res = await fetch(streamUrl, {
        headers: token ? { authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok || !res.body) throw new Error(`SSE connect failed (${res.status})`);

      attempt = 0;
      const reader = res.body
        .pipeThrough(new TextDecoderStream())
        .getReader();

      let buffer = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += value;

        const chunks = buffer.split('\n\n');
        buffer = chunks.pop() || '';

        for (const chunk of chunks) {
          const dataLine = chunk.split('\n').find((line) => line.startsWith('data: '));
          if (!dataLine) continue;
          const raw = JSON.parse(dataLine.slice(6));
          const normalized = normalize(raw);
          await publish(normalized);
          if (once) return;
        }
      }
      throw new Error('SSE stream ended');
    } catch (err) {
      attempt += 1;
      const wait = Math.min(base * (2 ** (attempt - 1)), max);
      console.error(`[bridge] reconnect in ${wait}ms after error: ${err.message}`);
      await new Promise((r) => setTimeout(r, wait));
    }
  }
}

connectLoop().catch((err) => {
  console.error('[bridge] fatal:', err);
  process.exit(1);
});
