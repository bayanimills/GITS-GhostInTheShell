#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import {
  loadEnvFile,
  requireProductionSecrets,
  authHeaders,
  readJson,
  writeJson,
} from './common.mjs';

const argv = process.argv.slice(2);
const getArg = (name, fallback = null) => {
  const idx = argv.indexOf(name);
  if (idx === -1) return fallback;
  return argv[idx + 1] ?? fallback;
};
const hasArg = (name) => argv.includes(name);

loadEnvFile(getArg('--env', path.resolve('integrations/mission-control-aws3-ews-mvp/config/.env')));
requireProductionSecrets(['MC_API_TOKEN']);

const baseUrl = process.env.MISSION_CONTROL_BASE_URL || 'http://127.0.0.1:4000';
const storePath = process.env.IDEMPOTENCY_STORE_PATH || './integrations/mission-control-aws3-ews-mvp/state/idempotency-store.json';
const dryRun = hasArg('--dry-run');

const payloadPath = getArg('--payload');
if (!payloadPath) {
  console.error('Usage: aws3-task-ingest.mjs --payload <task.json> [--dry-run] [--env <file>]');
  process.exit(2);
}

const body = JSON.parse(fs.readFileSync(payloadPath, 'utf8'));
if (!body?.task?.title) {
  throw new Error('Invalid payload: task.title is required');
}
if (!body.workflow_id || !body.trace_id || !body.idempotency_key) {
  throw new Error('Invalid payload: workflow_id, trace_id, idempotency_key are required');
}

const store = readJson(storePath, { sent: {} });
if (store.sent[body.idempotency_key]) {
  console.log(JSON.stringify({
    status: 'deduplicated',
    idempotency_key: body.idempotency_key,
    existing_task_id: store.sent[body.idempotency_key],
  }, null, 2));
  process.exit(0);
}

const existingDescription = body.task.description || '';
const hasWorkflowTag = /\[aws3\.workflow_id=/.test(existingDescription);
const hasTraceTag = /\[aws3\.trace_id=/.test(existingDescription);
const hasIdempotencyTag = /\[aws3\.idempotency_key=/.test(existingDescription);

const tags = [
  hasWorkflowTag ? null : `[aws3.workflow_id=${body.workflow_id}]`,
  hasTraceTag ? null : `[aws3.trace_id=${body.trace_id}]`,
  hasIdempotencyTag ? null : `[aws3.idempotency_key=${body.idempotency_key}]`,
].filter(Boolean).join(' ');

const task = {
  title: body.task.title,
  description: `${existingDescription} ${tags}`.trim(),
  priority: body.task.priority || process.env.AWS3_DEFAULT_PRIORITY || 'normal',
  status: body.task.status || process.env.AWS3_DEFAULT_STATUS || 'inbox',
  workspace_id: body.task.workspace_id || process.env.AWS3_DEFAULT_WORKSPACE_ID || 'default',
  business_id: body.task.business_id || process.env.AWS3_DEFAULT_BUSINESS_ID || 'default',
  assigned_agent_id: body.task.assigned_agent_id || null,
  due_date: body.task.due_date || null,
};

if (dryRun) {
  console.log(JSON.stringify({
    status: 'dry_run',
    would_post_to: `${baseUrl}/api/tasks`,
    task,
  }, null, 2));
  process.exit(0);
}

const res = await fetch(`${baseUrl}/api/tasks`, {
  method: 'POST',
  headers: authHeaders(),
  body: JSON.stringify(task),
});

if (!res.ok) {
  const text = await res.text();
  throw new Error(`Task create failed (${res.status}): ${text}`);
}

const created = await res.json();
store.sent[body.idempotency_key] = created.id;
writeJson(storePath, store);

console.log(JSON.stringify({
  status: 'created',
  task_id: created.id,
  idempotency_key: body.idempotency_key,
  workflow_id: body.workflow_id,
  trace_id: body.trace_id,
}, null, 2));
