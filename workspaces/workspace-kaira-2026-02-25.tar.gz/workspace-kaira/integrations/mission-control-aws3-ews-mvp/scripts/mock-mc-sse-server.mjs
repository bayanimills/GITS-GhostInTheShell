#!/usr/bin/env node
import http from 'node:http';

const port = Number(process.env.PORT || 4011);

const server = http.createServer((req, res) => {
  if (req.url?.startsWith('/api/events/stream')) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });

    const payload = {
      type: 'task_created',
      payload: {
        id: 'task_mock_001',
        status: 'inbox',
        description: 'Mock task [aws3.workflow_id=wf-mock-01] [aws3.trace_id=trace-mock-01] [aws3.idempotency_key=idem-mock-01]'
      }
    };

    res.write(`data: ${JSON.stringify(payload)}\n\n`);
    setTimeout(() => res.end(), 300);
    return;
  }

  res.statusCode = 404;
  res.end('not found');
});

server.listen(port, () => {
  console.log(`mock mission-control sse on http://127.0.0.1:${port}`);
});
