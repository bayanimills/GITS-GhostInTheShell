#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export function loadEnvFile(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return;
  const raw = fs.readFileSync(filePath, 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq <= 0) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    if (!(key in process.env)) process.env[key] = value;
  }
}

export function requireProductionSecrets(keys) {
  const isProd = (process.env.NODE_ENV || 'development') === 'production';
  if (!isProd) return;
  const missing = keys.filter((k) => !process.env[k] || !process.env[k].trim());
  if (missing.length) {
    throw new Error(`Missing required production secrets: ${missing.join(', ')}`);
  }
}

export function authHeaders() {
  const headers = { 'content-type': 'application/json' };
  const token = process.env.MC_API_TOKEN;
  if (token) headers.authorization = `Bearer ${token}`;
  return headers;
}

export function ensureDirForFile(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

export function appendJsonl(filePath, data) {
  ensureDirForFile(filePath);
  fs.appendFileSync(filePath, JSON.stringify(data) + '\n', 'utf8');
}

export function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

export function writeJson(filePath, value) {
  ensureDirForFile(filePath);
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), 'utf8');
}

export function signPayload(payload, secret) {
  if (!secret) return null;
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function randomId(prefix = 'evt') {
  return `${prefix}_${crypto.randomBytes(8).toString('hex')}`;
}

export function parseTaggedValue(text, tag) {
  if (!text) return null;
  const regex = new RegExp(`\\[${tag}=([^\\]]+)\\]`);
  const m = text.match(regex);
  return m?.[1] ?? null;
}
