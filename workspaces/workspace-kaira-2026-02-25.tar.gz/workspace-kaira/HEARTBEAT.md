# HEARTBEAT.md - Kaira's Periodic Checks

## Tasks to perform during heartbeats

### System Health Checks (every 2 hours)
1. **Check workspace integrity** - Verify all identity files exist
2. **Verify GITS connection** - Test git remote connectivity
3. **Check memory usage** - Monitor workspace memory consumption

### Agent Coordination (every 4 hours)
1. **Check Jarvis status** - Verify main agent is operational
2. **Review task queue** - Check for pending delegated tasks
3. **Update status report** - Document current operational state

### Geopolitical Monitoring (every 4 hours, rotate with Agent Coordination)
1. **Check major news sources** - Scan for significant geopolitical events
2. **Assess event significance** - Apply urgency categorization (high/medium/low)
3. **Model downstream effects** - For each significant event, outline likely downstream effects (market, policy, security, supply chain, payments/crypto rails)
4. **Define time windows** - For each downstream effect, estimate expected time-to-impact window (e.g., 0-24h, 1-7d, 1-4w, 1-3m)
5. **Assign probability** - Estimate statistical chance (%) for each stated downstream effect with confidence note
6. **Determine reporting need** - Decide if immediate alert or next heartbeat update
7. **Document findings** - Record events in memory log with assessment, effects, windows, and probabilities
8. **Develop sensitivity** - Note patterns in user's interest areas for future reference

### Self-Maintenance (daily)
1. **Run workspace backup** - Execute backup.sh to commit changes
2. **Review memory logs** - Archive old logs, summarize learnings
3. **Update documentation** - Keep recovery procedures current
4. **Test recovery scripts** - Verify multi-agent restoration works
5. **Check NAWS execution logs** - Verify last night's autonomous tasks completed
6. **Monitor Autonomous Workflow System** - Check `logs/autonomous-check.log` for errors, verify presence detection accuracy

## Implementation Notes
- Use `session_status` to check model and token usage
- Use `sessions_list` to check other agent activity
- Use `cron list` to verify scheduled jobs
- Log findings to `memory/YYYY-MM-DD.md`

## Alert Thresholds
- **Critical**: Identity files missing, GITS unreachable > 24h, Major geopolitical crisis (active conflict, severe market disruption)
- **Warning**: High memory usage (>80%), Jarvis offline > 2h, Significant geopolitical development (sanctions, major elections, regulatory changes), Autonomous system errors > 3 consecutive runs
- **Info**: Routine checks completed, no issues found, General political developments for awareness, Autonomous system operating normally