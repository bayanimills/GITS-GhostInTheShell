# Hotel Availability Tracking

Tracking ongoing availability for preferred hotels when accommodation needed for **ABIB (Australian Bitcoin Industry Body)** events, SBA workshops, or other events.

**Context:** User is CEO of ABIB; these hotels are preferred for ABIB‑related stays in Canberra.

## Preferred Hotels

### The Sebel
- **Location:** 197 London Circuit, 2601 Canberra, Australia
- **Preferred booking site:** Booking.com
- **Notes:** Good experience previously. Booking confirmation: 5110676977 (PIN: 7180). Executive King Room.
- **Last checked:** 2026-01-19 (last booking)
- **Next check due:** 2026-03-01 (monthly check)

### The Pinnacle
- **Location:** 11 Ovens St, Kingston ACT 2604
- **Preferred booking site:** domahotels.com.au (direct booking)
- **Notes:** Good experience previously. Tax invoice available.
- **Last checked:** 2026-02-25 (last stay)
- **Next check due:** 2026-03-01 (monthly check)

## Tracking Logic

**Triggers for needing accommodation:**
- ABIB (Australian Bitcoin Industry Body) events (as CEO)
- SBA packing events (multi‑day workshops)
- Other calendar events tagged with location requiring overnight stay
- Manual request

**Check frequency:** Monthly reminder to review availability (1st of each month)
**Booking lead time:** 2–4 weeks before event

## History

- **2026‑02‑28:** Tracking initiated per user request. Hotels added to monitoring list.