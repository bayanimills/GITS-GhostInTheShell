const { Client } = require('@notionhq/client');

// Using the correct API token that worked earlier
const notion = new Client({
  auth: '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'
});

async function checkDashboardProperly() {
  console.log('Checking Working Groups Dashboard properly...\n');
  
  const dashboardId = '1ddd323b89ec80e78ba3e8a3e38d2d0a';
  
  try {
    // Get the dashboard page
    const page = await notion.pages.retrieve({ page_id: dashboardId });
    const title = page.properties?.title?.title?.[0]?.plain_text || 'Working Groups Dashboard';
    
    console.log(`📊 Dashboard: ${title}`);
    console.log(`ID: ${dashboardId}`);
    console.log(`Last edited: ${page.last_edited_time}`);
    console.log();
    
    // Get ALL blocks (not just first 100)
    let allBlocks = [];
    let hasMore = true;
    let startCursor = undefined;
    
    while (hasMore) {
      const response = await notion.blocks.children.list({
        block_id: dashboardId,
        start_cursor: startCursor,
        page_size: 100
      });
      
      allBlocks = [...allBlocks, ...response.results];
      hasMore = response.has_more;
      startCursor = response.next_cursor;
    }
    
    console.log(`Found ${allBlocks.length} total blocks\n`);
    
    // Look for databases, linked pages, lists
    console.log('🔍 SEARCHING FOR WORKING GROUP CONTENT:\n');
    
    let foundWorkingGroups = [];
    let foundDatabases = [];
    let foundLinkedPages = [];
    
    allBlocks.forEach((block, i) => {
      const type = block.type;
      
      console.log(`${i + 1}. Block type: ${type}`);
      
      if (type === 'child_database') {
        const dbTitle = block.child_database?.title || 'Untitled Database';
        foundDatabases.push({ title: dbTitle, id: block.id });
        console.log(`   🗃️ DATABASE: ${dbTitle} (${block.id})`);
      }
      else if (type === 'child_page') {
        const pageTitle = block.child_page?.title || 'Untitled Page';
        foundLinkedPages.push({ title: pageTitle, id: block.id });
        console.log(`   📄 LINKED PAGE: ${pageTitle} (${block.id})`);
      }
      else if (type === 'bulleted_list_item' || type === 'numbered_list_item') {
        const richText = block[type]?.rich_text || [];
        if (richText.length > 0) {
          const text = richText.map(rt => rt.plain_text).join('');
          console.log(`   📝 LIST ITEM: ${text.substring(0, 100)}...`);
          
          // Check if it mentions working groups
          if (text.toLowerCase().includes('working group') || 
              text.toLowerCase().includes('group')) {
            foundWorkingGroups.push(text);
          }
        }
      }
      else if (type === 'paragraph') {
        const richText = block.paragraph?.rich_text || [];
        if (richText.length > 0) {
          const text = richText.map(rt => rt.plain_text).join('');
          console.log(`   📄 PARAGRAPH: ${text.substring(0, 100)}...`);
        }
      }
      else if (type === 'heading_1' || type === 'heading_2' || type === 'heading_3') {
        const text = block[type]?.rich_text?.[0]?.plain_text || '';
        console.log(`   🏷️ HEADING: ${text}`);
      }
      
      console.log();
    });
    
    // Summary
    console.log('='.repeat(60));
    console.log('\n📋 DASHBOARD CONTENT SUMMARY:\n');
    
    if (foundDatabases.length > 0) {
      console.log('🗃️ DATABASES FOUND:');
      foundDatabases.forEach((db, i) => {
        console.log(`  ${i + 1}. ${db.title} (${db.id})`);
      });
      console.log();
    }
    
    if (foundLinkedPages.length > 0) {
      console.log('📄 LINKED PAGES FOUND:');
      foundLinkedPages.forEach((page, i) => {
        console.log(`  ${i + 1}. ${page.title} (${page.id})`);
      });
      console.log();
    }
    
    if (foundWorkingGroups.length > 0) {
      console.log('👥 WORKING GROUP MENTIONS FOUND:');
      foundWorkingGroups.forEach((wg, i) => {
        console.log(`  ${i + 1}. ${wg}`);
      });
      console.log();
    }
    
    // Check if we should query any databases found
    if (foundDatabases.length > 0) {
      console.log('💡 RECOMMENDATION:');
      console.log('Check these databases for working group lists or tracking');
      console.log('They may contain the full list of working groups');
    }
    
    return {
      title,
      blocks: allBlocks,
      databases: foundDatabases,
      linkedPages: foundLinkedPages,
      workingGroupMentions: foundWorkingGroups
    };
    
  } catch (error) {
    console.error(`❌ Error: ${error.message}`);
    if (error.code) console.error(`Error code: ${error.code}`);
    return null;
  }
}

checkDashboardProperly();