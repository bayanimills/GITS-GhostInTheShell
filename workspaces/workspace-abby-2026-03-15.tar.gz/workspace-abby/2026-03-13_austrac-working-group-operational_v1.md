# AUSTRAC Working Group - Operational Summary

## Executive Summary
**Source**: Notion page migration (to be deprecated)  
**Status**: Active regulatory engagement group  
**Focus**: Australian Transaction Reports and Analysis Centre (AUSTRAC) compliance  
**Confidentiality**: Information falls under Non-Disclosure Agreements  

---

## Key Information

### Working Group Purpose
- Industry collaboration with AUSTRAC on regulatory compliance
- Virtual Asset Service Provider (VASP) engagement
- AML/CTF (Anti-Money Laundering/Counter-Terrorism Financing) rule development
- Regulatory feedback and consultation processes

### Critical Dates Timeline

#### ✅ **COMPLETED**
- **2025, February 14th** - Public Consultation on new AML/CTF Rules
- **2025, March 31st** - Tranche 1 is LIVE

#### 🔄 **CURRENT/UPCOMING**
- **2026, March 31st** - Implementation of Travel / Value Transfer Rule
- **2026, December** - IFT (International Funds Transfer) Reporting

#### 📅 **RECENT ENGAGEMENT**
- **July 3, 2025** - Virtual Asset Working Group meeting

---

## Operational Structure

### Working Group Components

#### 1. **Personnel Database**
- **Location**: Notion database (to be migrated)
- **Purpose**: Track AUSTRAC industry working group contacts
- **Status**: Requires migration to Nextcloud/CRM system

#### 2. **AUSTRAC Engagement Tracking**
- **Location**: Notion database (to be migrated)
- **Content**: Meeting notes, correspondence, action items
- **Status**: Requires migration to Nextcloud

#### 3. **Meetings Database**
- **Location**: Notion database (to be migrated)
- **Purpose**: Schedule and track AUSTRAC engagement meetings
- **Status**: Requires migration to Nextcloud calendar system

---

## Workflow Process

### Standard Operating Procedure

```mermaid
graph TD
    A[Identify Regulatory Concern] --> B[Create Concern Page]
    B --> C[Collect Documents & Questions]
    C --> D[Working Group Comments]
    D --> E[Draft Response]
    E --> F[Refine Response]
    F --> G[Communications Review]
    G --> H[Publication/Delivery]
```

### Step-by-Step Process

1. **Concern Identification**
   - Monitor regulatory developments
   - Identify impact on Bitcoin industry
   - Prioritize based on urgency and impact

2. **Documentation Phase**
   - Create dedicated page for each concern
   - Collect relevant documents, regulations, questions
   - Enable working group comments and feedback

3. **Response Development**
   - Draft initial response based on Bitcoin industry perspective
   - Incorporate Austrian economics principles
   - Align with ABIB policy positions

4. **Refinement Process**
   - Working group review and feedback
   - Legal and compliance review
   - Strategic alignment check

5. **Publication/Delivery**
   - Communications team review
   - Format for appropriate channel (submission, meeting, etc.)
   - Delivery and follow-up tracking

---

## Strategic Goals

### Primary Objectives
1. **Regulatory Clarity** - Advocate for clear, sensible Bitcoin regulation
2. **Industry Protection** - Ensure regulations don't harm legitimate Bitcoin businesses
3. **Compliance Support** - Help Australian Bitcoin businesses comply with AML/CTF
4. **Relationship Building** - Maintain constructive engagement with AUSTRAC

### Key Focus Areas
- **Travel Rule Implementation** (2026 deadline)
- **IFT Reporting Requirements** (2026 deadline)
- **VASP Registration and Compliance**
- **De-banking Protection** for Bitcoin businesses

---

## Migration Status

### Source Information
- **Original Platform**: Notion
- **Page ID**: `174d323b89ec8009b337c0d9f31bee47`
- **Created**: 2025-01-07
- **Last Updated**: 2025-07-08
- **Extracted**: 2026-03-13

### Migration Details
- **Extracted By**: Abby (AI Operations & Strategy Lead)
- **Migration Reason**: Notion page deprecation, centralized operations
- **Destination**: Nextcloud operational system
- **Status**: ✅ Content migrated, ⚠️ Databases require separate migration

### Nextcloud Location
```
ABIB-Admin/operations/abby/01-policy/regulatory-tracking/austrac/
├── 2026-03-13_notion_austrac-working-group_v1.md (this file)
├── 2026-03-13_notion_austrac-working-group-raw_v1.md (raw extraction)
└── [Future: Database exports, meeting notes, correspondence]
```

---

## Action Items

### Immediate (Next 7 days)
1. ✅ Extract content from Notion (COMPLETED)
2. ⚠️ Migrate AUSTRAC Personnel database (PENDING)
3. ⚠️ Migrate AUSTRAC Meetings database (PENDING)
4. ⚠️ Migrate AUSTRAC engagement tracking database (PENDING)

### Short-term (Next 30 days)
1. Set up regular AUSTRAC monitoring system
2. Create regulatory calendar with key dates
3. Establish workflow automation for responses
4. Develop template library for common submissions

### Medium-term (Next 90 days)
1. Implement CRM integration for relationship tracking
2. Create compliance guidance for Australian Bitcoin businesses
3. Develop educational materials on AUSTRAC requirements
4. Establish metrics for regulatory engagement effectiveness

---

## Related Resources

### ABIB Policy Framework
- Energy & Climate policy position
- Tax Reform advocacy
- Privacy & Freedom of Speech protection
- Financial Self-Sovereignty principles

### Australian Regulatory Context
- ASIC (Australian Securities and Investments Commission)
- Treasury digital assets framework
- RBA (Reserve Bank of Australia) payments system
- APRA (Australian Prudential Regulation Authority) banking regulations

### Bitcoin Industry Context
- OrangeLabel.io (250+ Bitcoin-accepting businesses)
- Australian Bitcoin mining operations
- Exchange and custody service providers
- Education and community organizations

---

## Contact & Coordination

### ABIB Team
- **Bayani Mills** - CEO, Strategic direction
- **Daniel Wilczynski** - Policy development
- **Elmo Stoop** - Regulatory engagement
- **Ben Dickens** - Board oversight

### Operational Support
- **Abby** - AI Operations & Strategy Lead (this system)
- **Donna** - Executive operations coordination
- **The Doc** - Document processing and management

### External Coordination
- AUSTRAC Industry Working Group members
- Virtual Asset Service Providers (VASPs)
- Legal and compliance partners
- Industry associations and advocacy groups

---

**Last Updated**: 2026-03-13  
**Next Review**: 2026-04-13  
**Version**: v1.0  
**Status**: Operational foundation established, migration in progress