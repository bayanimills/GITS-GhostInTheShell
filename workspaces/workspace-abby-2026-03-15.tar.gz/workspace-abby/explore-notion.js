const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function exploreNotion() {
  try {
    console.log('Exploring Notion workspace for ABIB operations...\n');
    
    // Get user information
    const users = await notion.users.list({});
    console.log(`Workspace Users: ${users.results.length}`);
    users.results.forEach((user, i) => {
      console.log(`  ${i + 1}. ${user.name || 'Unknown'} (${user.type})`);
    });
    
    console.log('\n--- Searching for ABIB-related content ---\n');
    
    // Search for ABIB or Bitcoin related pages
    const searchResponse = await notion.search({
      query: 'ABIB Bitcoin Australia',
      filter: {
        property: 'object',
        value: 'page'
      },
      sort: {
        direction: 'descending',
        timestamp: 'last_edited_time'
      }
    });
    
    console.log(`Found ${searchResponse.results.length} pages matching search query`);
    
    if (searchResponse.results.length > 0) {
      console.log('\nTop 10 matching pages:');
      searchResponse.results.slice(0, 10).forEach((page, i) => {
        const title = page.properties?.title?.title?.[0]?.plain_text || 
                     page.properties?.Name?.title?.[0]?.plain_text ||
                     'Untitled';
        console.log(`${i + 1}. "${title}" (${page.id})`);
        console.log(`   Last edited: ${page.last_edited_time}`);
        console.log(`   URL: https://www.notion.so/${page.id.replace(/-/g, '')}`);
        console.log('');
      });
    }
    
    // Let's also check for databases specifically
    console.log('--- Checking for databases ---\n');
    
    // Try a different approach to find databases
    const dbSearch = await notion.search({
      filter: {
        property: 'object',
        value: 'database'
      }
    });
    
    console.log(`Found ${dbSearch.results.length} databases total`);
    
    // Look for databases with actual content
    const databasesWithContent = dbSearch.results.filter(db => 
      db.title && db.title.length > 0 && 
      db.title[0].plain_text && 
      db.title[0].plain_text !== 'Untitled'
    );
    
    console.log(`Databases with proper titles: ${databasesWithContent.length}`);
    
    if (databasesWithContent.length > 0) {
      console.log('\nDatabases with titles:');
      databasesWithContent.forEach((db, i) => {
        console.log(`${i + 1}. "${db.title[0].plain_text}" (${db.id})`);
      });
    }
    
    // Create a test page for ABIB operations
    console.log('\n--- Creating ABIB Operations Test Page ---\n');
    
    try {
      const newPage = await notion.pages.create({
        parent: {
          type: 'page_id',
          page_id: searchResponse.results[0]?.id || dbSearch.results[0]?.id || '309d323b-89ec-80d7-abb7-dcf9ee7aefeb'
        },
        properties: {
          title: {
            title: [
              {
                type: 'text',
                text: {
                  content: 'ABIB Operations - Abby Test Page'
                }
              }
            ]
          }
        },
        children: [
          {
            object: 'block',
            type: 'heading_2',
            heading_2: {
              rich_text: [{ type: 'text', text: { content: 'Australian Bitcoin Industry Body Operations' } }]
            }
          },
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'This is a test page created by Abby, AI Operations & Strategy Lead for ABIB. Testing Notion integration for Bitcoin advancement operations in Australia.'
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Policy tracking and regulatory monitoring' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Educational content development' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Research and data analysis' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Operational workflow management' }
                }
              ]
            }
          }
        ]
      });
      
      console.log('✅ Successfully created ABIB test page!');
      console.log(`Page ID: ${newPage.id}`);
      console.log(`Page URL: https://www.notion.so/${newPage.id.replace(/-/g, '')}`);
      
    } catch (createError) {
      console.log('Note: Could not create test page (may need different permissions)');
      console.log('Error:', createError.message);
    }
    
    return {
      users: users.results,
      pages: searchResponse.results,
      databases: dbSearch.results
    };
    
  } catch (error) {
    console.error('Error exploring Notion:', error.message);
    return null;
  }
}

exploreNotion();