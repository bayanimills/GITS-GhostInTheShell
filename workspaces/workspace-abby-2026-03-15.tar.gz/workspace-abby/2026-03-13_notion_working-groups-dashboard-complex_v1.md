# Working Groups Dashboard

**Source**: Notion Working Groups Dashboard
**Page ID**: 1ddd323b89ec80e78ba3e8a3e38d2d0a
**Created**: 2025-04-22T02:03:00.000Z
**Last Updated**: 2026-03-13T13:11:00.000Z
**Status**: Actively used (updated today)

---


<div class="columns">

<div class="column">

  > **Callout**: Working Groups are being converted into an accessible ‘Teamspace’.
All pages should be accessible by all in this group.

- Bayani, April 2025


</div>

<div class="column">

  > **Callout**: Fortnightly Video Call
Next: June 15th

Add to your Calendar

  📄 **Linked Page**: Our Next Steps


</div>

</div>

> **Callout**: Welcome to ABIB Notion! 

- Our Vision
is of Australia on a Bitcoin Standard.

- Our Mission
is to be a voice for the Australian Bitcoin Industry in it’s advancement of Bitcoin.

- Grants

<div class="columns">

<div class="column">

  ---


</div>

<div class="column">

  ---

  📄 **Linked Page**: Business Adoption

  📄 **Linked Page**: Communications & Outreach

  📄 **Linked Page**: Mining & Energy

  📄 **Linked Page**: Community Voices

  📄 **Linked Page**: AUSPOL

  📄 **Linked Page**: ABIB x RBA

  📄 **Linked Page**: Policy Working Group

  📄 **Linked Page**: Financial Inclusion Working Group

  📄 **Linked Page**: Education

  ---

  📄 **Linked Page**: Resources

  📄 **Linked Page**: Resource Library

  📄 **Linked Page**: ABIB Policies

  📄 **Linked Page**: Strategic Roadmap 2025-2030


</div>

</div>

---


<div class="columns">

<div class="column">


</div>

<div class="column">

  Website: [bitcoinindustrybody.org.au](http://bitcoinindustrybody.org.au/) 
Join: [http://bitcoinindustrybody.org.au/join](http://bitcoinindustrybody.org.au/join)


</div>

</div>

---

---

## 🚨 CRITICAL FINDING

This dashboard was **updated today (2026-03-13T13:11:00.000Z)**, indicating it is actively used.

### Structure Analysis:
1. **Column Lists**: Likely organizing working groups into categories
2. **Callout Blocks**: Important instructions or notes
3. **Complex Layout**: Not simple text - needs proper extraction

### Migration Impact:
- We may have missed working groups listed in column layouts
- The dashboard coordinates ALL working groups, not just regulatory
- Need to extract complete structure before deprecation
