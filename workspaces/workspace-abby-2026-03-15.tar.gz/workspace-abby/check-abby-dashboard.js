const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function checkAbbyDashboard() {
  console.log('Checking Abby Dashboard in Notion...\n');
  
  try {
    // The Abby dashboard ID from earlier
    const abbyPageId = '322d323b-89ec-81de-99cd-cf22e8374597';
    
    console.log(`Fetching Abby dashboard: ${abbyPageId}`);
    
    // Get the page
    const page = await notion.pages.retrieve({ page_id: abbyPageId });
    const title = page.properties?.title?.title?.[0]?.plain_text || 'Untitled';
    console.log(`Title: ${title}`);
    console.log(`Created: ${page.created_time}`);
    console.log(`Last edited: ${page.last_edited_time}`);
    
    // Get page content
    const blocks = await notion.blocks.children.list({
      block_id: abbyPageId,
      page_size: 100
    });
    
    console.log(`\n📋 DASHBOARD CONTENT (${blocks.results.length} blocks):\n`);
    
    blocks.results.forEach((block, index) => {
      const type = block.type;
      
      if (type === 'heading_1' || type === 'heading_2' || type === 'heading_3') {
        const text = block[type]?.rich_text?.[0]?.plain_text || '';
        const level = type === 'heading_1' ? '#' : type === 'heading_2' ? '##' : '###';
        console.log(`${level} ${text}`);
      } 
      else if (type === 'paragraph') {
        const text = block.paragraph?.rich_text?.[0]?.plain_text || '';
        if (text) console.log(text);
      }
      else if (type === 'bulleted_list_item') {
        const text = block.bulleted_list_item?.rich_text?.[0]?.plain_text || '';
        if (text) console.log(`• ${text}`);
      }
      else if (type === 'numbered_list_item') {
        const text = block.numbered_list_item?.rich_text?.[0]?.plain_text || '';
        if (text) console.log(`${index + 1}. ${text}`);
      }
      else if (type === 'to_do') {
        const text = block.to_do?.rich_text?.[0]?.plain_text || '';
        const checked = block.to_do?.checked ? '✅' : '☐';
        if (text) console.log(`${checked} ${text}`);
      }
      else if (type === 'callout') {
        const text = block.callout?.rich_text?.[0]?.plain_text || '';
        if (text) console.log(`💡 ${text}`);
      }
      else if (type === 'child_page' || type === 'child_database') {
        const childTitle = block[type]?.title || 'Untitled';
        const icon = type === 'child_page' ? '📄' : '🗃️';
        console.log(`${icon} ${childTitle}`);
      }
    });
    
    // Check for child pages/databases
    const childPages = blocks.results.filter(b => b.type === 'child_page' || b.type === 'child_database');
    if (childPages.length > 0) {
      console.log('\n🔗 CHILD PAGES/DATABASES:');
      childPages.forEach((child, i) => {
        const type = child.type === 'child_page' ? 'Page' : 'Database';
        const title = child[child.type]?.title || 'Untitled';
        console.log(`${i + 1}. ${type}: ${title}`);
      });
    }
    
    // Check the Policy Tracking database if it exists
    console.log('\n🔍 CHECKING POLICY TRACKING DATABASE:');
    const policyDbId = '542499ed-648b-44f3-8120-fc232cf0bc78';
    
    try {
      const database = await notion.databases.retrieve({ database_id: policyDbId });
      console.log(`Database: ${database.title[0]?.plain_text || 'Untitled'}`);
      
      // Query for entries
      const response = await notion.databases.query({
        database_id: policyDbId,
        page_size: 10
      });
      
      console.log(`Entries in database: ${response.results.length}`);
      
      if (response.results.length > 0) {
        console.log('\nCurrent entries:');
        response.results.forEach((page, i) => {
          const title = page.properties?.Name?.title?.[0]?.plain_text || 
                       page.properties?.title?.title?.[0]?.plain_text ||
                       'Untitled';
          console.log(`${i + 1}. ${title}`);
        });
      }
    } catch (dbError) {
      console.log('Could not access policy database:', dbError.message);
    }
    
    return { page, blocks, childPages };
    
  } catch (error) {
    console.error('Error checking Abby dashboard:', error.message);
    return null;
  }
}

checkAbbyDashboard().then(result => {
  if (result) {
    console.log('\n✅ Abby dashboard check complete!');
  }
});