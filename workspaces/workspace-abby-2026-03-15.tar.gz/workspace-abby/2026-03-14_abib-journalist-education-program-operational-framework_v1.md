# ABIB Journalist Education Program - Operational Framework
## Based on ABIB Journalist Framework PDF (Strategic Framework v1.0, 2025)

**Source**: `abib-journalist-framework.pdf` (83 KB, React component export)  
**Location**: `ABIB-Admin/operations/abby/02-working-groups/02-community-engagement/02-communications/`  
**Documentation Created**: March 14, 2026  
**Purpose**: Extract and operationalize the journalist education program framework for implementation

---

## Executive Summary

The ABIB Journalist Education Program is a comprehensive, multi-phase initiative designed to improve Bitcoin journalism accuracy in Australia through education, resource provision, and relationship building. The program is built on four governing pillars and follows a phased rollout over 2+ years, with the ultimate goal of becoming the reference point for Bitcoin journalism in Australia.

### Core Philosophy
- **Editorial Independence**: Zero editorial input over journalistic output
- **Utility First**: Make journalists better at covering Bitcoin, not promote ABIB
- **Evidence-Based**: Cite primary sources, show uncertainty ranges
- **Long-Term Relationships**: Build trust over years, not chase quarterly metrics

---

## 1. Governing Pillars

### 1.1 Editorial Independence
**Core Principle**: ABIB has zero editorial input over journalistic output

**Implementation Requirements**:
- Published, board-ratified independence charter on website
- No sponsored content or advertorial relationships
- Diverse advisory panel including industry critics
- Transparent funding disclosure
- Never ask for favourable coverage

**Operational Standards**:
- All program materials must pass editorial independence review
- Advisory panel must include non-industry voices
- Funding sources publicly disclosed quarterly
- No quid pro quo arrangements with journalists

### 1.2 Utility First
**Core Principle**: Every program element must make journalists better at covering Bitcoin

**Implementation Requirements**:
- Fact-check service with sub-4-hour turnaround
- Expert directory with response-time commitments
- Methodology explainers, not marketing copy
- Public acknowledgment when ABIB data requires correction

**Operational Standards**:
- Response time SLA: 4 hours for fact-check requests
- Expert commitment: 24-hour response time guarantee
- Content review: Quarterly accuracy drift assessment
- Correction protocol: Transparent error acknowledgment process

### 1.3 Evidence-Based Content
**Core Principle**: All published materials cite primary sources; no proprietary claims without peer review

**Implementation Requirements**:
- Source hierarchy: academic > government > independent research > industry
- Preferred data sources: Cambridge CBECI, ABS, APRA data
- Uncertainty ranges shown, not suppressed
- Quarterly content review for accuracy drift

**Operational Standards**:
- Source verification: All claims must have primary source citation
- Data transparency: Uncertainty and limitations clearly stated
- Content review: Quarterly accuracy assessment
- Peer review: Proprietary claims require external validation

### 1.4 Long-Term Relationships
**Core Principle**: Program success measured in trust built over years, not media mentions

**Implementation Requirements**:
- No cold pitching through program channels
- Engage journalists who have been critical — they matter most
- Make disengagement easy; never chase
- Build relationships, not transactions

**Operational Standards**:
- Outreach protocol: Editor introductions only, no cold outreach
- Critical engagement: Prioritize relationships with skeptical journalists
- Exit protocol: Easy unsubscribe, no follow-up pressure
- Relationship tracking: Long-term engagement metrics

---

## 2. Target Audience Segments

### 2.1 Tier 1: Finance & Tech Beat Reporters
**Priority**: Highest  
**Venues**: AFR, The Australian, SMH Money, iTnews  
**Needs**: Deep technical accuracy, reliable expert access on deadline  
**Approach**: Direct outreach via editor introductions; off-record briefings  
**Key Metrics**: Fact-check utilization, expert directory usage

### 2.2 Tier 1: Freelancers
**Priority**: Highest  
**Venues**: Multiple publications; high mobility  
**Needs**: Trusted source network; faster than in-house researchers  
**Approach**: MEAA partnership; journalism association channels  
**Key Metrics**: Repeat engagement, resource hub usage

### 2.3 Tier 2: General Assignment Reporters
**Priority**: Medium  
**Venues**: ABC, Guardian, news.com.au  
**Needs**: Accessible primers, quick context on breaking crypto news  
**Approach**: Resource hub + rapid-response channel; reactive not proactive  
**Key Metrics**: Response time, accuracy improvement

### 2.4 Tier 3: Senior Editors & Producers
**Priority**: Low  
**Venues**: All major desks  
**Needs**: Framing context; editorial policy on crypto coverage  
**Approach**: Annual roundtables; policy briefings  
**Key Metrics**: Policy adoption, editorial guidance usage

---

## 3. Phased Implementation Roadmap

### Phase 1: Foundation (Months 1–3)
**Tagline**: "Build the infrastructure before the outreach"

**Objectives**:
1. Establish governance framework and editorial independence policy
2. Develop core resource hub content and fact-check database
3. Build expert referral network (internal + external voices)
4. Define success metrics and baseline media accuracy audit

**Deliverables**:
| Deliverable | Owner | Priority | Status |
|-------------|-------|----------|--------|
| Editorial Independence Charter | Board | Critical | Required |
| Resource Hub v1 (10+ explainers) | Content Lead | Critical | Required |
| Expert Directory (30+ contacts) | Outreach Lead | High | Required |
| Journalist CRM Setup | Ops | High | Required |
| Baseline Media Accuracy Audit | Research | Medium | Required |

**Risks**:
- Rushing to launch before credibility infrastructure is ready
- Expert directory skewed too heavily toward industry insiders

### Phase 2: Soft Launch (Months 4–6)
**Tagline**: "Earn trust with your first 20 journalists before scaling"

**Objectives**:
1. Pilot fact-check service with 15–20 pre-selected journalists
2. Run first 3 off-the-record technical briefing sessions
3. Establish rapid response channel (Signal / dedicated email)
4. Collect qualitative feedback and iterate

**Deliverables**:
| Deliverable | Owner | Priority | Status |
|-------------|-------|----------|--------|
| Fact-Check Service Beta | Policy Lead | Critical | Required |
| Journalist Briefing Series (x3) | Events | High | Required |
| Rapid Response Protocol | Comms | High | Required |
| Pilot Cohort Feedback Report | Research | Medium | Required |

**Risks**:
- Pilot journalists feel they're being managed, not educated
- Slow response times damage credibility early

### Phase 3: Expansion (Months 7–12)
**Tagline**: "Scale what works; formalise the program architecture"

**Objectives**:
1. Open program to all journalists, freelancers, and journalism students
2. Launch journalist fellowship / embed program
3. Partner with MEAA and journalism schools
4. Publish first annual Media Accuracy Report

**Deliverables**:
| Deliverable | Owner | Priority | Status |
|-------------|-------|----------|--------|
| Open Resource Hub Launch | Content Lead | Critical | Required |
| Fellowship Program (2 cohorts/year) | Program Lead | High | Required |
| MEAA / University MoUs | CEO | High | Required |
| Annual Media Accuracy Report | Research | High | Required |
| Advisory Panel Established | Board | Critical | Required |

**Risks**:
- Advisory panel lacks genuine independence
- Fellowship program perceived as junket / industry capture

### Phase 4: Maturity (Year 2+)
**Tagline**: "Become the reference point for Bitcoin journalism in Australia"

**Objectives**:
1. Achieve unprompted citation by major mastheads
2. Expand expert network to international voices
3. Run annual journalist-of-the-year award (accuracy-focused)
4. Develop curriculum for university journalism programs

**Deliverables**:
| Deliverable | Owner | Priority | Status |
|-------------|-------|----------|--------|
| University Curriculum Module | Content Lead | High | Required |
| Annual Accuracy Award | Events | Medium | Required |
| International Expert Network | Outreach Lead | Medium | Required |
| Program Impact Report (annual) | Research | High | Required |

**Risks**:
- Complacency as program matures — content becoming stale
- Mission drift toward PR function

---

## 4. Success Metrics Framework

### 4.1 Core Metrics
| Metric | Cadence | Type | Target |
|--------|---------|------|--------|
| Fact-check requests handled | Monthly | Volume | 20+/month |
| Response time (median) | Monthly | Quality | <4 hours |
| Pre-publication accuracy rate | Quarterly | Outcome | 95%+ |
| Journalist repeat engagement rate | Quarterly | Relationship | 60%+ |
| Published corrections attributable to program contact | Quarterly | Outcome | Tracked |
| Resource hub unique visitors (journo-verified) | Monthly | Reach | 100+/month |
| Expert directory utilisation | Monthly | Volume | 15+/month |
| Qualitative NPS from pilot cohort | Bi-annual | Quality | +50 |
| Media accuracy baseline vs. current (annual audit) | Annual | Outcome | 25% improvement |

### 4.2 Metric Types & Colors
- **Volume** (Orange): Quantitative activity metrics
- **Quality** (Blue): Service quality and satisfaction
- **Outcome** (Green): Impact and accuracy improvements
- **Relationship** (Purple): Engagement and relationship depth
- **Reach** (Pink): Audience size and penetration

### 4.3 Anchor Metric: Annual Media Accuracy Audit
**Scope**: Top 12–15 Australian mastheads  
**Methodology**: Published rubric, independent scorer  
**Baseline**: Completed in Phase 1 before any outreach  
**Publication**: Annual report; publicly released  
**Purpose**: Most important longitudinal metric showing whether program is working

**Audit Rubric Components**:
1. **Terminology Accuracy**: Correct use of Bitcoin vs. cryptocurrency terms
2. **Technical Accuracy**: Blockchain, mining, Lightning Network explanations
3. **Context Provision**: Historical, economic, and regulatory context
4. **Source Diversity**: Range of expert voices cited
5. **Risk Disclosure**: Balanced coverage of risks and benefits
6. **Correction Handling**: Transparency in error correction

---

## 5. Operational Systems & Infrastructure

### 5.1 Resource Hub Requirements
**Content Types**:
1. **Technical Explainers**: Blockchain, mining, Lightning Network, privacy
2. **Economic Context**: Austrian economics, sound money, monetary policy
3. **Regulatory Overview**: ASIC, AUSTRAC, Treasury frameworks
4. **Data Sources**: ABS, RBA, Cambridge CBECI, APRA data guides
5. **Expert Directory**: Verified experts with response-time commitments
6. **Fact-Check Database**: Common misconceptions and corrections

**Technical Requirements**:
- Journalist verification system
- Search functionality with filters
- Mobile-responsive design
- Secure document sharing
- Analytics tracking (journo-specific)

### 5.2 Fact-Check Service Protocol
**Request Channels**:
1. **Dedicated Email**: factcheck@bitcoinindustrybody.org.au
2. **Signal Channel**: Verified journalist access only
3. **Web Form**: Resource hub integration

**Response Protocol**:
1. **Triage**: Category assignment (urgent/standard/complex)
2. **Research**: Primary source verification
3. **Drafting**: Clear, evidence-based response
4. **Review**: Peer review for accuracy
5. **Delivery**: Within 4-hour SLA for urgent requests

**Quality Assurance**:
- All responses cite primary sources
- Uncertainty ranges clearly stated
- Peer review for complex queries
- Response time tracking and reporting

### 5.3 Expert Network Management
**Expert Categories**:
1. **Technical**: Developers, engineers, protocol experts
2. **Economic**: Academics, researchers, economists
3. **Regulatory**: Lawyers, compliance experts
4. **Industry**: Business leaders, exchange operators
5. **Community**: Long-term holders, educators

**Commitment Requirements**:
- 24-hour response time commitment
- Availability for brief interviews
- Willingness to be quoted
- Disclosure of potential conflicts

**Management System**:
- CRM integration
- Availability calendar
- Expertise tagging
- Performance tracking

### 5.4 Journalist Relationship Management
**CRM Requirements**:
- Journalist verification and profiling
- Interaction history tracking
- Preference management
- Engagement scoring
- Compliance tracking (GDPR, privacy)

**Communication Protocol**:
- No unsolicited outreach
- Editor introductions only
- Opt-in communication preferences
- Easy unsubscribe process

**Relationship Building**:
- Off-record briefing sessions
- Technical deep-dive workshops
- Annual roundtables
- Fellowship programs

---

## 6. Governance & Compliance

### 6.1 Editorial Independence Charter
**Required Components**:
1. **Independence Statement**: Clear separation from editorial influence
2. **Advisory Panel Composition**: Diverse membership requirements
3. **Funding Transparency**: Public disclosure requirements
4. **Content Review Process**: Independent accuracy verification
5. **Correction Policy**: Transparent error correction process

**Approval Process**:
- Board ratification required
- Public publication on website
- Annual review and reaffirmation
- Independent audit provision

### 6.2 Advisory Panel
**Composition Requirements**:
- Minimum 50% non-industry members
- Academic representation
- Journalism ethics experts
- Consumer advocacy representation
- Independent chairperson

**Responsibilities**:
- Program oversight and guidance
- Editorial independence monitoring
- Content accuracy review
- Annual program evaluation
- Public reporting

### 6.3 Funding & Transparency
**Disclosure Requirements**:
- Quarterly funding source reporting
- Program budget publication
- Expense categorization
- Independent financial audit
- Conflict of interest declarations

**Funding Principles**:
- No conditional funding
- No editorial influence provisions
- Transparent allocation
- Multi-year sustainability planning

### 6.4 Privacy & Data Protection
**Journalist Data**:
- Opt-in consent required
- Purpose limitation principle
- Data minimization approach
- Secure storage and processing
- Right to erasure provision

**Expert Data**:
- Consent for publication
- Contact preference management
- Conflict of interest disclosure
- Performance data protection

---

## 7. Risk Management Framework

### 7.1 Program Risks
| Risk | Likelihood | Impact | Mitigation Strategy |
|------|------------|--------|---------------------|
| Editorial independence perception | Medium | High | Transparent charter, diverse advisory panel |
| Slow response times | High | High | SLA commitments, resource allocation |
| Expert network bias | Medium | Medium | Diversity requirements, rotation system |
| Mission drift to PR function | Low | High | Clear metrics, independent oversight |
| Content accuracy drift | Medium | Medium | Quarterly reviews, peer validation |
| Journalist disengagement | Medium | Medium | Utility focus, no pressure tactics |

### 7.2 Reputation Risks
**Industry Capture Perception**:
- Diverse advisory panel composition
- Transparent funding sources
- Independent content validation
- Critical journalist engagement

**Credibility Risks**:
- Fact-check accuracy verification
- Source hierarchy adherence
- Error correction transparency
- Response time consistency

**Relationship Risks**:
- No unsolicited outreach policy
- Easy disengagement process
- Respect for journalistic independence
- Long-term relationship focus

### 7.3 Operational Risks
**Resource Constraints**:
- Phased implementation approach
- Clear priority setting
- Volunteer expert network
- Scalable systems design

**Quality Consistency**:
- Standardized response templates
- Peer review processes
- Training and onboarding
- Performance monitoring

**Sustainability Risks**:
- Multi-year funding planning
- Diverse revenue streams
- Cost-effective operations
- Impact measurement for continued support

---

## 8. Implementation Timeline & Milestones

### Year 1: Foundation & Launch
**Q1 (Months 1-3)**: Infrastructure Development
- Editorial independence charter ratification
- Resource hub v1 development (10+ explainers)
- Expert directory establishment (30+ contacts)
- Baseline media accuracy audit

**Q2 (Months 4-6)**: Soft Launch
- Fact-check service beta launch
- First 3 briefing sessions
- Rapid response protocol implementation
- Pilot cohort feedback collection

**Q3-Q4 (Months 7-12)**: Expansion
- Open resource hub launch
- Fellowship program development
- MEAA/university partnerships
- First annual media accuracy report

### Year 2: Maturity & Scale
**Q1-Q2**: Program Formalization
- Advisory panel establishment
- University curriculum development
- International expert network expansion
- Process optimization

**Q3-Q4**: Impact Measurement
- Second annual media accuracy report
- Program impact assessment
- Sustainability planning
- Scale planning for Year 3

### Years 3+: Reference Point Establishment
- Unprompted citation achievement
- Annual accuracy awards
- Curriculum integration
- International recognition

---

## 9. Resource Requirements

### 9.1 Human Resources
**Core Team**:
- Program Director (part-time)
- Content Lead (part-time)
- Outreach Lead (part-time)
- Research Lead (part-time)
- Operations Support (part-time)

**Expert Network**:
- 30+ verified experts
- Response time commitments
- Diverse expertise coverage
- Geographic distribution

**Advisory Panel**:
- 5-7 members
- Independent chair
- Diverse composition
- Quarterly meetings

### 9.2 Technology Infrastructure
**Platform Requirements**:
- Resource hub website
- Journalist CRM system
- Expert directory database
- Fact-check workflow system
- Analytics and reporting

**Security Requirements**:
- Journalist data protection
- Secure communication channels
- Access control systems
- Backup and recovery

### 9.3 Financial Resources
**Year 1 Budget**:
- Platform development: $XX,XXX
- Content creation: $XX,XXX
- Outreach activities: $XX,XXX
- Research and audit: $XX,XXX
- Operations: $XX,XXX

**Funding Sources**:
- ABIB operational budget
- Grant