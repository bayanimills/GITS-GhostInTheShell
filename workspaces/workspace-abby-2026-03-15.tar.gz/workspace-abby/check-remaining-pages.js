const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: 'ntn_566773375807azgBK7abuXMzddlWvZKSzIEQstr'
});

async function checkRemainingPages() {
  console.log('Checking for remaining sub-pages...\n');
  
  // Pages we've already migrated
  const migratedPages = [
    '174d323b89ec8009b337c0d9f31bee47', // AUSTRAC Working Group
    '174d323b89ec80abaccedee15fff306c', // RBA & Treasury Working Group  
    '174d323b89ec80a7a661e72ce244d1fa', // ASIC Working Group
    '1ddd323b89ec80e78ba3e8a3e38d2d0a'  // Working Groups Dashboard
  ];
  
  // Search for all ABIB working group pages
  console.log('Searching for ABIB working group pages...');
  const searchResponse = await notion.search({
    query: 'Working Group',
    filter: {
      property: 'object',
      value: 'page'
    },
    page_size: 50
  });
  
  console.log(`Found ${searchResponse.results.length} pages with "Working Group"\n`);
  
  // Check each page
  const remainingPages = [];
  
  searchResponse.results.forEach((page, i) => {
    const title = page.properties?.title?.title?.[0]?.plain_text || 
                 page.properties?.Name?.title?.[0]?.plain_text ||
                 'Untitled';
    
    const isMigrated = migratedPages.includes(page.id);
    const status = isMigrated ? '✅ MIGRATED' : '⚠️ NOT MIGRATED';
    
    console.log(`${i + 1}. ${status} - ${title}`);
    console.log(`   ID: ${page.id}`);
    console.log(`   Last edited: ${page.last_edited_time}`);
    
    if (!isMigrated) {
      remainingPages.push({
        title,
        id: page.id,
        lastEdited: page.last_edited_time
      });
    }
    
    console.log();
  });
  
  // Also check for linked pages in migrated content
  console.log('='.repeat(60));
  console.log('\nChecking for linked pages in migrated content...\n');
  
  // Known linked pages from our extractions:
  const linkedPages = [
    { id: '1ddd323b89ec80f0a49deb05ea726a2c', name: 'ABIB x RBA' },
    { id: '215d323b89ec80e8aa9bffa6132c34e3', name: 'NSW: Friends of Bitcoin → RBA' },
    { id: '1ddd323b89ec80f08bc6f2bf54c9ef9a', name: 'ABIB Operations' },
    { id: '1b4d323b89ec8004afd2c0dfcea649aa', name: 'ABIB Budget' },
    { id: 'd7d60a5fed5b46649ba4961f3ba69c1e', name: 'ABIB Policy & Procedure Manual' },
    { id: '309d323b89ec80d7abb7dcf9ee7aefeb', name: 'Bitcoin Research Newsletter' },
    { id: 'e5a3c5003ee945fa8f9318fb440b7284', name: 'ABIB Membership Categories' }
  ];
  
  linkedPages.forEach((page, i) => {
    const isMigrated = migratedPages.includes(page.id);
    const status = isMigrated ? '✅ MIGRATED' : '📄 LINKED (check if needed)';
    
    console.log(`${i + 1}. ${status} - ${page.name}`);
    console.log(`   ID: ${page.id}`);
    
    if (!isMigrated) {
      remainingPages.push({
        title: page.name,
        id: page.id,
        lastEdited: 'Unknown',
        type: 'linked'
      });
    }
    
    console.log();
  });
  
  // Summary
  console.log('='.repeat(60));
  console.log('\n📋 MIGRATION STATUS SUMMARY\n');
  console.log(`Total pages found: ${searchResponse.results.length}`);
  console.log(`Already migrated: ${migratedPages.length}`);
  console.log(`Remaining pages to check: ${remainingPages.length}`);
  
  if (remainingPages.length > 0) {
    console.log('\n⚠️ PAGES REQUIRING ATTENTION:');
    remainingPages.forEach((page, i) => {
      console.log(`${i + 1}. ${page.title} (${page.id})`);
      if (page.type === 'linked') {
        console.log('   Type: Linked page in migrated content');
      }
    });
    
    console.log('\n🔍 RECOMMENDED ACTION:');
    console.log('1. Check if these pages contain critical operational content');
    console.log('2. If yes, extract and migrate to Nextcloud');
    console.log('3. If no, note for Notion deprecation');
  } else {
    console.log('\n✅ ALL PAGES MIGRATED OR ACCOUNTED FOR');
  }
  
  return { remainingPages, totalFound: searchResponse.results.length };
}

checkRemainingPages().catch(console.error);