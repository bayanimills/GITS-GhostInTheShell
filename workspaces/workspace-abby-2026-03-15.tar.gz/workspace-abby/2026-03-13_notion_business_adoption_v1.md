# Business Adoption

**Source**: Notion page
**Page ID**: 174d323b-89ec-802c-a738-d9589538495d
**Created**: 2025-01-07T03:23:00.000Z
**Last Updated**: 2025-04-27T02:38:00.000Z

---

## ABIB Website Structure:

New Page: Bitcoin for Business (Campaigned for via [orangelabel.io](http://orangelabel.io/))

New Page: Businesses Accepting Bitcoin ([https://bitcoinindustrybody.org.au/businesses-accepting-bitcoin/](https://bitcoinindustrybody.org.au/businesses-accepting-bitcoin/))

📄 **Linked Page**: Accepting Bitcoin as Payment FAQ

- Services Spreadsheet to filter based on ‘Full List’ data.
- Require reconciliation of some of this data to spreadsheet: 
📄 **Linked Page**: ABIB’s Bitcoin & Local Business Pamphlet

- Produce & Provide Stickers “Bitcoin Accepted Here” for Brick & Morter Business that become Sponsors, list ABIB and [btcmap.org](http://btcmap.org/) logos and websites, but Orange Label symbol.
📄 **Linked Page**: ABIB x BTCMap Community Tagger Initiative

🗃️ **Linked Database**: Untitled

---

## Migration Status
- **Extracted**: 2026-03-13T13:23:26.753Z
- **By**: Abby (AI Operations & Strategy Lead)
- **Destination**: Nextcloud working groups system
