# AUSTRAC Working Group

**Source**: Notion page (to be deprecated)
**Page ID**: 174d323b89ec8009b337c0d9f31bee47
**Created**: 2025-01-07T03:27:00.000Z
**Last Updated**: 2025-07-08T05:44:00.000Z

---

> **Note**: Information in this page falls under Non-Disclosures.

<details>
<summary>AUSTRAC’s Industry Working Group Personnel</summary>

  🗃️ **Linked Database**: AUSTRAC Personnel


</details>

<div style="display: flex; gap: 20px;">

<div style="flex: 1;">

🗃️ **Linked Database**: AUSTRAC

July 3, 2025 - Virtual Asset Working Group

🗃️ **Linked Database**: AUSTRAC Meetings


</div>

<div style="flex: 1;">

> **Note**: **GOALS**

# Key Dates:

2025, February 14th - Public Consultation on new AML/CTF Rules

2025, March 31st - Tranche 1 is LIVE

2026, March 31st - Implementation of Travel / Value Transfer Rule 

2026, December - IFT Reporting

# Workflow:

1. Prioritised List of Concerns as Pages - Documents, questions, etc
1. Comments to be left in relevant pages
1. Response Drafted
1. Response Refined
1. Response sent to Communications for Publication

</div>

</div>

---

## Migration Information

### Source Details
- **Notion Page**: AUSTRAC Working Group
- **Page ID**: `174d323b89ec8009b337c0d9f31bee47`
- **Created**: 2025-01-07T03:27:00.000Z
- **Last Updated**: 2025-07-08T05:44:00.000Z

### Migration Details
- **Extracted**: 2026-03-13T12:10:21.947Z
- **Extracted By**: Abby (AI Operations & Strategy Lead)
- **Destination**: Nextcloud `ABIB-Admin/operations/abby/01-policy/`
- **Status**: Migrated for long-term storage
- **Action Required**: Notion page to be deprecated after verification

### File Naming Convention
Following ABIB operational standards:
`YYYY-MM-DD_source_topic_vX.ext`

### Nextcloud Path
`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/austrac/`
