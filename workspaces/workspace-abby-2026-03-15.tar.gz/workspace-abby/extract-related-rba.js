const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function extractRelatedRBAContent() {
  console.log('📄 Extracting related RBA/Treasury content...\n');
  
  const pagesToExtract = [
    { id: '1ddd323b-89ec-80f0-a49d-eb05ea726a2c', name: 'ABIB x RBA' },
    { id: '215d323b-89ec-80e8-aa9b-ffa6132c34e3', name: 'NSW: Friends of Bitcoin → RBA' },
    { id: '174d323b-89ec-80a7-a661-e72ce244d1fa', name: 'ASIC Working Group' }
  ];
  
  let allContent = '# RBA & Treasury Working Group - Related Content\n\n';
  allContent += `**Note**: Main RBA & Treasury Working Group page not accessible for block extraction\n`;
  allContent += `**Last Updated**: ${new Date().toISOString()}\n\n`;
  allContent += `---\n\n`;
  
  for (const pageInfo of pagesToExtract) {
    console.log(`\n🔍 Extracting: ${pageInfo.name} (${pageInfo.id})`);
    
    try {
      // Get page
      const page = await notion.pages.retrieve({ page_id: pageInfo.id });
      const title = page.properties?.title?.title?.[0]?.plain_text || pageInfo.name;
      
      allContent += `## ${title}\n\n`;
      allContent += `**Page ID**: ${pageInfo.id}\n`;
      allContent += `**Created**: ${page.created_time}\n`;
      allContent += `**Last Updated**: ${page.last_edited_time}\n\n`;
      
      // Try to get blocks
      try {
        const blocks = await notion.blocks.children.list({
          block_id: pageInfo.id,
          page_size: 50
        });
        
        console.log(`  Found ${blocks.results.length} blocks`);
        
        // Process blocks
        blocks.results.forEach(block => {
          const type = block.type;
          
          if (type === 'heading_1') {
            const text = block.heading_1?.rich_text?.[0]?.plain_text || '';
            if (text) allContent += `# ${text}\n\n`;
          } 
          else if (type === 'heading_2') {
            const text = block.heading_2?.rich_text?.[0]?.plain_text || '';
            if (text) allContent += `## ${text}\n\n`;
          }
          else if (type === 'heading_3') {
            const text = block.heading_3?.rich_text?.[0]?.plain_text || '';
            if (text) allContent += `### ${text}\n\n`;
          }
          else if (type === 'paragraph') {
            const richText = block.paragraph?.rich_text || [];
            if (richText.length > 0) {
              let text = '';
              richText.forEach(rt => {
                let t = rt.plain_text || '';
                if (rt.annotations?.bold) t = `**${t}**`;
                if (rt.annotations?.italic) t = `*${t}*`;
                if (rt.href) t = `[${t}](${rt.href})`;
                text += t;
              });
              if (text.trim()) allContent += `${text}\n\n`;
            }
          }
          else if (type === 'bulleted_list_item') {
            const richText = block.bulleted_list_item?.rich_text || [];
            if (richText.length > 0) {
              let text = '';
              richText.forEach(rt => {
                let t = rt.plain_text || '';
                if (rt.annotations?.bold) t = `**${t}**`;
                if (rt.annotations?.italic) t = `*${t}*`;
                if (rt.href) t = `[${t}](${rt.href})`;
                text += t;
              });
              if (text.trim()) allContent += `- ${text}\n`;
            }
          }
          else if (type === 'numbered_list_item') {
            const richText = block.numbered_list_item?.rich_text || [];
            if (richText.length > 0) {
              let text = '';
              richText.forEach(rt => {
                let t = rt.plain_text || '';
                if (rt.annotations?.bold) t = `**${t}**`;
                if (rt.annotations?.italic) t = `*${t}*`;
                if (rt.href) t = `[${t}](${rt.href})`;
                text += t;
              });
              if (text.trim()) allContent += `1. ${text}\n`;
            }
          }
          else if (type === 'callout') {
            const richText = block.callout?.rich_text || [];
            if (richText.length > 0) {
              let text = '';
              richText.forEach(rt => {
                let t = rt.plain_text || '';
                if (rt.annotations?.bold) t = `**${t}**`;
                if (rt.annotations?.italic) t = `*${t}*`;
                if (rt.href) t = `[${t}](${rt.href})`;
                text += t;
              });
              if (text.trim()) allContent += `> **Note**: ${text}\n\n`;
            }
          }
          else if (type === 'child_page' || type === 'child_database') {
            const childTitle = block[type]?.title || 'Untitled';
            const icon = type === 'child_page' ? '📄' : '🗃️';
            allContent += `${icon} **Linked ${type === 'child_page' ? 'Page' : 'Database'}**: ${childTitle}\n\n`;
          }
        });
        
      } catch (blockError) {
        console.log(`  Cannot access blocks: ${blockError.message}`);
        allContent += `*Content not accessible for extraction*\n\n`;
      }
      
      allContent += `---\n\n`;
      
    } catch (pageError) {
      console.log(`  Cannot access page: ${pageError.message}`);
      allContent += `## ${pageInfo.name}\n\n`;
      allContent += `*Page not accessible*\n\n`;
      allContent += `---\n\n`;
    }
  }
  
  // Add context about RBA & Treasury
  allContent += `## RBA & Treasury Working Group Context\n\n`;
  allContent += `### Reserve Bank of Australia (RBA)\n`;
  allContent += `- **Role**: Australia's central bank, monetary policy, payments system\n`;
  allContent += `- **Bitcoin Relevance**: Digital currency research, payments innovation, CBDC exploration\n`;
  allContent += `- **Key Areas**: Surcharging rules, payment system regulation, digital currency policy\n\n`;
  
  allContent += `### Treasury (Australian Government)\n`;
  allContent += `- **Role**: Economic policy, fiscal policy, financial system regulation\n`;
  allContent += `- **Bitcoin Relevance**: Digital assets framework, tax policy, financial regulation\n`;
  allContent += `- **Key Areas**: Digital assets regulation, tax treatment, consumer protection\n\n`;
  
  allContent += `### Working Group Purpose\n`;
  allContent += `- Coordinate ABIB engagement with RBA and Treasury\n`;
  allContent += `- Develop policy positions on digital currency issues\n`;
  allContent += `- Prepare submissions and responses to consultations\n`;
  allContent += `- Build relationships with key policymakers\n\n`;
  
  allContent += `### Recent Developments (2025-2026)\n`;
  allContent += `1. **RBA Digital Currency Research** - Ongoing exploration of CBDC\n`;
  allContent += `2. **Treasury Digital Assets Framework** - Regulatory consultation\n`;
  allContent += `3. **Payment System Reforms** - Surcharging and innovation\n`;
  allContent += `4. **Tax Treatment Clarification** - Bitcoin and digital assets\n\n`;
  
  allContent += `---\n\n`;
  allContent += `## Migration Information\n\n`;
  allContent += `### Source Details\n`;
  allContent += `- **Primary Page**: RBA & Treasury Working Group (inaccessible)\n`;
  allContent += `- **Related Pages**: ABIB x RBA, NSW Friends of Bitcoin → RBA, ASIC Working Group\n`;
  allContent += `- **Extracted**: ${new Date().toISOString()}\n\n`;
  
  allContent += `### Migration Status\n`;
  allContent += `- ✅ Related content extracted where accessible\n`;
  allContent += `- ⚠️ Main working group page requires permission update\n`;
  allContent += `- 🔄 Contextual information added based on ABIB operations\n\n`;
  
  allContent += `### Nextcloud Path\n`;
  allContent += `\`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/rba-treasury/\`\n`;
  
  console.log(`\n✅ Extraction complete`);
  
  return allContent;
}

// Run extraction
extractRelatedRBAContent().then(content => {
  if (content) {
    const fs = require('fs');
    const filename = `2026-03-13_rba-treasury-working-group-context_v1.md`;
    fs.writeFileSync(filename, content);
    
    console.log(`\n💾 Saved to: ${filename}`);
    console.log(`Content length: ${content.length} characters`);
    
    console.log('\n📄 CONTENT PREVIEW:');
    console.log('='.repeat(80));
    console.log(content.substring(0, 1500) + '...');
  }
});