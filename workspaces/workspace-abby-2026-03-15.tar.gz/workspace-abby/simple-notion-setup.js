const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function simpleSetup() {
  console.log('Setting up simple ABIB operations in Notion...\n');
  
  try {
    // Find the ABIB Operations page
    const searchResponse = await notion.search({
      query: 'ABIB Operations',
      filter: {
        property: 'object',
        value: 'page'
      }
    });
    
    const abibOpsPage = searchResponse.results.find(p => 
      p.properties?.title?.title?.[0]?.plain_text === 'ABIB Operations'
    );
    
    if (!abibOpsPage) {
      console.log('ABIB Operations page not found');
      return;
    }
    
    console.log(`Found ABIB Operations page: ${abibOpsPage.id}`);
    
    // Create a simple Abby dashboard
    const abbyPage = await notion.pages.create({
      parent: { page_id: abibOpsPage.id },
      properties: {
        title: {
          title: [{ text: { content: 'Abby - AI Operations Dashboard' } }]
        }
      },
      children: [
        {
          object: 'block',
          type: 'heading_1',
          heading_1: {
            rich_text: [{ text: { content: 'ABIB AI Operations Dashboard' } }]
          }
        },
        {
          object: 'block',
          type: 'paragraph',
          paragraph: {
            rich_text: [
              { text: { content: 'Operational dashboard for Abby, AI Operations & Strategy Lead for ABIB.' } }
            ]
          }
        },
        {
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [{ text: { content: 'Integration Status' } }]
          }
        },
        {
          object: 'block',
          type: 'bulleted_list_item',
          bulleted_list_item: {
            rich_text: [{ text: { content: '✅ Nextcloud: Operational workspace established' } }]
          }
        },
        {
          object: 'block',
          type: 'bulleted_list_item',
          bulleted_list_item: {
            rich_text: [{ text: { content: '✅ ABIB API: Public endpoints accessible' } }]
          }
        },
        {
          object: 'block',
          type: 'bulleted_list_item',
          bulleted_list_item: {
            rich_text: [{ text: { content: '✅ Notion: Connected and integrated' } }]
          }
        },
        {
          object: 'block',
          type: 'bulleted_list_item',
          bulleted_list_item: {
            rich_text: [{ text: { content: '⚠️ ABIB API Auth: Needs valid token' } }]
          }
        },
        {
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [{ text: { content: 'Operational Areas' } }]
          }
        },
        {
          object: 'block',
          type: 'numbered_list_item',
          numbered_list_item: {
            rich_text: [{ text: { content: 'Policy Operations: Regulatory monitoring & submissions' } }]
          }
        },
        {
          object: 'block',
          type: 'numbered_list_item',
          numbered_list_item: {
            rich_text: [{ text: { content: 'Education Operations: Content for policy makers, media, public' } }]
          }
        },
        {
          object: 'block',
          type: 'numbered_list_item',
          numbered_list_item: {
            rich_text: [{ text: { content: 'Research Operations: Australian Bitcoin ecosystem analysis' } }]
          }
        },
        {
          object: 'block',
          type: 'numbered_list_item',
          numbered_list_item: {
            rich_text: [{ text: { content: 'General Operations: Monitoring, reporting, optimization' } }]
          }
        },
        {
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [{ text: { content: 'Quick Links' } }]
          }
        },
        {
          object: 'block',
          type: 'paragraph',
          paragraph: {
            rich_text: [
              { text: { content: '• ' } },
              { text: { content: 'ABIB Website', link: { url: 'https://bitcoinindustrybody.org.au' } } },
              { text: { content: '\n• ' } },
              { text: { content: 'Nextcloud', link: { url: 'https://team.bitcoinindustrybody.org.au' } } },
              { text: { content: '\n• ' } },
              { text: { content: 'API Docs', link: { url: 'https://bitcoinindustrybody.org.au/api/docs' } } }
            ]
          }
        },
        {
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [{ text: { content: 'Last Updated' } }]
          }
        },
        {
          object: 'block',
          type: 'paragraph',
          paragraph: {
            rich_text: [
              { text: { content: '2026-03-13 - Initial setup complete' } }
            ]
          }
        }
      ]
    });
    
    console.log(`✅ Created Abby dashboard: https://www.notion.so/${abbyPage.id.replace(/-/g, '')}`);
    
    // Create a simple policy tracking database
    const policyDb = await notion.databases.create({
      parent: { type: 'page_id', page_id: abbyPage.id },
      title: [{ type: 'text', text: { content: 'Policy Tracking' } }],
      properties: {
        'Title': { title: {} },
        'Agency': { 
          select: {
            options: [
              { name: 'ASIC', color: 'blue' },
              { name: 'AUSTRAC', color: 'green' },
              { name: 'Treasury', color: 'purple' },
              { name: 'RBA', color: 'red' }
            ]
          }
        },
        'Status': {
          select: {
            options: [
              { name: 'Monitoring', color: 'yellow' },
              { name: 'Active', color: 'blue' },
              { name: 'Submitted', color: 'green' },
              { name: 'Closed', color: 'gray' }
            ]
          }
        },
        'Deadline': { date: {} }
      }
    });
    
    console.log(`✅ Created Policy Tracking database: ${policyDb.id}`);
    
    // Add initial entries
    await notion.pages.create({
      parent: { database_id: policyDb.id },
      properties: {
        'Title': { title: [{ text: { content: 'RBA Surcharging Review' } }] },
        'Agency': { select: { name: 'RBA' } },
        'Status': { select: { name: 'Submitted' } },
        'Deadline': { date: { start: '2026-01-21' } }
      }
    });
    
    await notion.pages.create({
      parent: { database_id: policyDb.id },
      properties: {
        'Title': { title: [{ text: { content: 'Treasury Digital Assets Framework' } }] },
        'Agency': { select: { name: 'Treasury' } },
        'Status': { select: { name: 'Monitoring' } }
      }
    });
    
    console.log('✅ Added initial policy tracking entries');
    
    return {
      dashboard: abbyPage,
      policyDb: policyDb
    };
    
  } catch (error) {
    console.error('Error:', error.message);
    return null;
  }
}

simpleSetup().then(result => {
  if (result) {
    console.log('\n🎉 Notion setup completed successfully!');
  }
});