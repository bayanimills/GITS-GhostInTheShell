const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function resolvePermissions() {
  console.log('Resolving RBA/Treasury page permissions...\n');
  
  const pageId = '174d323b89ec80abaccedee15fff306c';
  
  try {
    // Try direct page access first
    const page = await notion.pages.retrieve({ page_id: pageId });
    console.log(`✅ Page exists: "${page.properties?.title?.title?.[0]?.plain_text || 'RBA & Treasury Working Group'}"`);
    console.log(`   Last edited: ${page.last_edited_time}`);
    
    // Try different access methods
    console.log('\nTrying alternative access methods:');
    
    // 1. Try with smaller page size
    console.log('1. Testing with minimal block request...');
    try {
      const blocks = await notion.blocks.children.list({
        block_id: pageId,
        page_size: 1
      });
      console.log(`   ✅ Success! Got ${blocks.results.length} block(s)`);
    } catch (e1) {
      console.log(`   ❌ Failed: ${e1.message}`);
    }
    
    // 2. Check if it's actually a database
    console.log('2. Checking if it\'s a database...');
    try {
      const db = await notion.databases.retrieve({ database_id: pageId });
      console.log(`   ✅ It's a database: "${db.title[0]?.plain_text || 'Untitled'}"`);
    } catch (e2) {
      console.log(`   ❌ Not a database: ${e2.message}`);
    }
    
    // 3. Search for it to see permissions
    console.log('3. Searching for page in workspace...');
    const search = await notion.search({
      query: 'RBA Treasury Working Group',
      filter: { property: 'object', value: 'page' },
      page_size: 5
    });
    
    const found = search.results.find(r => r.id === pageId);
    console.log(`   ${found ? '✅ Found in search' : '❌ Not found in search'}`);
    
    return { accessible: false, reason: 'Block-level permissions needed' };
    
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
    
    if (error.code === 'object_not_found') {
      console.log('\n🔧 Solution needed:');
      console.log('1. The page exists but integration lacks block-level access');
      console.log('2. Need to update Notion integration permissions');
      console.log('3. Or page might be in a different workspace/shared differently');
      console.log('\n📋 Action required:');
      console.log('- Update Notion integration to access this specific page');
      console.log('- Or manually share the page with the integration');
    }
    
    return { accessible: false, error: error.message };
  }
}

resolvePermissions();