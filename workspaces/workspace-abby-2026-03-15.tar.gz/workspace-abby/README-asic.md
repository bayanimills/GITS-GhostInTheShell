# ASIC Regulatory Tracking Directory

## Purpose
This directory contains materials related to ABIB's engagement with the Australian Securities and Investments Commission (ASIC), Australia's corporate, markets, and financial services regulator. This includes working group coordination, regulatory analysis, submission development, and compliance guidance.

## Current Status
**✅ Complete Migration**
- **Main Page**: ASIC Working Group page fully extracted
- **Content**: Minimal original content preserved, comprehensive framework created
- **Regulatory Context**: INFO 225 and RG 133 analysis integrated
- **Operational Framework**: Complete working model established

## Directory Structure
```
asic/
├── README.md (this file)
├── 2026-03-13_notion_asic-working-group_v1.md      # Original Notion extraction
├── 2026-03-13_asic-working-group-operational_v1.md  # Comprehensive framework
├── info-225/                                        # Digital assets guidance
│   ├── analysis/                                    # Regulatory analysis
│   ├── submissions/                                 # Formal responses to ASIC
│   └── implementation/                              # Business compliance guidance
├── rg-133/                                          # Custody standards
│   ├── analysis/                                    # Regulatory analysis
│   ├── submissions/                                 # Formal responses to ASIC
│   └── implementation/                              # Custody compliance guidance
├── engagements/                                     # ASIC relationship management
│   ├── meetings/                                    # Meeting notes and outcomes
│   ├── correspondence/                              # Official communications
│   └── relationship-tracking/                       # Contact management
├── licensing/                                       # AFSL requirements
│   ├── applications/                                # License application guidance
│   ├── compliance/                                  # Ongoing compliance
│   └── exemptions/                                  # Relief and exemptions
└── market-conduct/                                  # Trading and market rules
    ├── disclosure/                                  # Consumer disclosure
    ├── trading-rules/                               # Market conduct
    └── enforcement/                                 # ASIC enforcement actions
```

## Key Regulatory Documents

### INFO 225 - Digital Assets: Financial Products & Services
- **Purpose**: Guidance on when digital assets constitute regulated financial products
- **Status**: Updated December 2024 (CP 381 consultation)
- **Key Content**: 13 worked examples, licensing guidance for digital asset intermediaries
- **ABIB Focus**: Clarifying Bitcoin's status, proportional regulation for services

### RG 133 - Funds Management and Custodial Services: Holding Assets
- **Purpose**: Minimum standards for asset holders and custodians
- **Status**: Reissued December 2024 with updated guidance
- **Key Content**: AFS licensee obligations for asset holding
- **ABIB Focus**: Appropriate custody standards for Bitcoin, self-custody recognition

## ASIC Regulatory Context

### Australian Securities and Investments Commission
- **Role**: Corporate regulator, financial services licensing, markets supervision
- **Legislation**: Corporations Act 2001, ASIC Act 2001
- **Bitcoin Relevance**: Determines financial product status, licensing requirements
- **Key Divisions**: Digital Assets, Financial Services, Market Integrity, Consumer Protection

### Strategic Importance for Bitcoin
1. **Financial Product Definition**: What constitutes a regulated Bitcoin service?
2. **Licensing Requirements**: Which Bitcoin businesses need AFS licenses?
3. **Custody Standards**: How should Bitcoin custody services operate?
4. **Disclosure Obligations**: What information must Bitcoin businesses provide?
5. **Market Conduct**: Fair trading and anti-manipulation rules
6. **Investor Protection**: Consumer safeguards and education

## Extracted Content Summary

### From ASIC Working Group Notion Page
- **Page Created**: 2025-01-07
- **Last Updated**: 2025-04-22
- **Linked Documents**: INFO 225, RG 133
- **Content**: Minimal structure, primarily reference links

### Operational Framework Created
- **Comprehensive Structure**: 14,500+ word operational framework
- **Strategic Analysis**: ASIC mandate and Bitcoin relevance
- **Workflow Process**: 5-step engagement methodology
- **Regulatory Positions**: Key issues and ABIB advocacy positions
- **Action Plan**: Immediate, short-term, and medium-term actions

## Operational Framework

### Working Group Structure
- **Strategic Direction**: ABIB Leadership
- **Policy Development**: Regulatory Experts
- **Legal Analysis**: Compliance Specialists
- **Industry Coordination**: Bitcoin Businesses
- **Monitoring & Reporting**: Abby (AI Operations)

### 5-Step Engagement Process
1. Monitor ASIC Publications
2. Analyze Regulatory Impact
3. Develop ABIB Position
4. Draft Submission/Response
5. Deliver & Follow-up

### Key Regulatory Issues
1. **Financial Product Definition** - Bitcoin as commodity vs security
2. **Licensing Requirements** - Proportional AFSL regime
3. **Custody Standards** - Technology-neutral Bitcoin custody
4. **Disclosure & Protection** - Informed consent vs paternalism
5. **Market Integrity** - Fraud prevention vs innovation suppression

## File Naming Convention
All files follow ABIB operational standard:
`YYYY-MM-DD_source_topic_vX.ext`

Examples:
- `2026-03-13_notion_asic-working-group_v1.md`
- `2026-03-13_asic-working-group-operational_v1.md`
- `2026-03-31_asic-info225-consultation_v1.md`

## Related Directories
- `../austrac/` - AUSTRAC regulatory tracking (AML/CTF compliance)
- `../rba-treasury/` - RBA & Treasury engagement (monetary policy, digital assets)
- `../general/` - Cross-agency regulatory issues
- `../../02-education/asic/` - Educational materials for businesses

## Strategic Importance
ASIC regulation directly impacts:
- Bitcoin exchange operations and licensing
- Custody service providers and standards
- Investment products and fund management
- Financial advice and education services
- Market trading and conduct rules
- Consumer protection and disclosure

## Contact
- **Primary**: Abby (AI Operations & Strategy Lead)
- **Strategic**: Bayani Mills (CEO)
- **Policy Lead**: Daniel Wilczynski
- **Regulatory Engagement**: Elmo Stoop
- **Legal/Compliance**: [To be assigned]

## Version History
- **v1.0** (2026-03-13): Directory created, content migrated, operational framework established
- **Next Update**: Scheduled for 2026-03-20 (operational implementation review)

---
**Last Updated**: 2026-03-13  
**Maintained By**: Abby - AI Operations & Strategy Lead  
**Review Cycle**: Weekly (initial implementation), then monthly  
**Status**: ✅ Complete migration, operational framework ready for implementation