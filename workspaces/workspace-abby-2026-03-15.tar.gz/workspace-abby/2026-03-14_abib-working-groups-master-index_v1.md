# Australian Bitcoin Industry Body
## Working Groups Master Index

**Version**: 1.0  
**Created**: March 2026  
**Status**: Active  
**Owner**: Abby (AI Operations & Strategy Lead)

---

## Executive Summary

This document establishes the official working group structure for the Australian Bitcoin Industry Body (ABIB). Each working group focuses on a specific area of Bitcoin advancement in Australia, with clear mandates, objectives, and coordination mechanisms.

## Working Group Structure

### 1. Regulatory & Policy Working Groups

#### 1.1 AUSTRAC Working Group
- **Focus**: AML/CTF compliance and engagement with Australia's financial intelligence agency
- **Mandate**: Ensure Bitcoin businesses comply with anti-money laundering regulations while advocating for sensible regulation
- **Key Activities**:
  - Monitor AUSTRAC regulatory developments
  - Develop compliance resources for Bitcoin businesses
  - Engage with AUSTRAC on Travel Rule implementation
  - Advocate for proportionate AML/CTF regulation
- **Status**: ✅ Framework established

#### 1.2 ASIC Working Group
- **Focus**: Regulatory frameworks and engagement with the Australian Securities and Investments Commission
- **Mandate**: Navigate securities regulation for Bitcoin businesses and advocate for clear digital asset guidelines
- **Key Activities**:
  - Track ASIC digital asset guidance (INFO 225, RG 133)
  - Develop AFS licensing guidance for Bitcoin businesses
  - Engage with ASIC on custody and trading regulations
  - Advocate for innovation-friendly securities regulation
- **Status**: ✅ Framework established

#### 1.3 Treasury & RBA Working Group
- **Focus**: Policy development and submissions to the Australian Treasury and Reserve Bank
- **Mandate**: Influence monetary policy and economic framework for Bitcoin adoption
- **Key Activities**:
  - Develop policy submissions to Treasury consultations
  - Engage with RBA on digital currency research
  - Advocate for sound money principles in economic policy
  - Monitor fiscal policy affecting Bitcoin
- **Status**: ⚠️ Framework established (content migration partial)

### 2. Community & Engagement Working Groups

#### 2.1 Community Engagement Working Group
- **Focus**: Grassroots events, meetups, and education to grow the Bitcoin community
- **Mandate**: Build and strengthen Australia's Bitcoin community through local engagement
- **Key Activities**:
  - Organize Bitcoin meetups and events nationwide
  - Develop community education programs
  - Support local Bitcoin initiatives
  - Foster community collaboration and networking
- **Status**: 🔄 Framework needed

#### 2.2 Communications Working Group
- **Focus**: Public relations, media outreach, social media, and content creation
- **Mandate**: Shape public perception and increase Bitcoin awareness in Australia
- **Key Activities**:
  - Develop media relations and press releases
  - Create educational and promotional content
  - Manage social media channels and engagement
  - Coordinate public messaging and campaigns
- **Status**: 🔄 Framework needed

### 3. Political Engagement Working Groups

#### 3.1 Political Engagement - Federal
- **Focus**: Engagement with federal parliamentarians and policymakers
- **Mandate**: Influence federal policy and legislation affecting Bitcoin
- **Key Activities**:
  - Build relationships with federal politicians
  - Provide Bitcoin education to policymakers
  - Monitor federal legislation and committee inquiries
  - Advocate for Bitcoin-friendly federal policy
- **Status**: 🔄 Framework needed

#### 3.2 Political Engagement - State
- **Focus**: Engagement with state governments and representatives on local Bitcoin adoption and policy
- **Mandate**: Advance Bitcoin adoption at state and territory level
- **Key Activities**:
  - Engage with state governments and agencies
  - Support local Bitcoin initiatives and businesses
  - Monitor state-level policy developments
  - Advocate for state-level Bitcoin adoption
- **Status**: 🔄 Framework needed

### 4. Operations Working Group

#### 4.1 ABIB Operations Working Group
- **Focus**: Internal operations including finance, administration, technology, and organizational management
- **Mandate**: Ensure effective operation and governance of ABIB
- **Key Activities**:
  - Financial management and budgeting
  - Membership administration and services
  - Technology systems and infrastructure
  - Organizational governance and compliance
- **Status**: ✅ Framework established

---

## Coordination Framework

### Meeting Schedule
- **Monthly**: Individual working group meetings
- **Quarterly**: Cross-working group coordination
- **Annual**: Strategic planning and review

### Reporting Requirements
- **Monthly Reports**: Progress against objectives
- **Quarterly Reviews**: Performance assessment
- **Annual Plans**: Objectives for coming year

### Resource Allocation
- **Budget**: Working group budgets allocated annually
- **Support**: Operational support from ABIB Operations
- **Tools**: Access to necessary systems and resources

### Success Metrics
Each working group has specific KPIs including:
- Regulatory engagements completed
- Community events organized
- Media coverage achieved
- Policy submissions made
- Membership growth
- Educational materials distributed

---

## Directory Structure

```
ABIB-Admin/operations/abby/02-working-groups/
├── README.md (this file)
├── 01-regulatory-policy/                    # Regulatory working groups
│   ├── 01-austrac/                          # AUSTRAC Working Group
│   │   ├── README.md
│   │   ├── 2026-03-13_austrac-working-group-operational_v1.md
│   │   └── monitoring/
│   ├── 02-asic/                             # ASIC Working Group
│   │   ├── README.md
│   │   ├── 2026-03-13_asic-working-group-operational_v1.md
│   │   └── monitoring/
│   └── 03-treasury-rba/                     # Treasury & RBA Working Group
│       ├── README.md
│       ├── 2026-03-13_rba-treasury-working-group-operational_v1.md
│       └── monitoring/
├── 02-community-engagement/                 # Community working groups
│   ├── 01-community-engagement/             # Community Engagement WG
│   │   ├── README.md
│   │   └── framework.md (to be created)
│   └── 02-communications/                   # Communications WG
│       ├── README.md
│       └── framework.md (to be created)
├── 03-political-engagement/                 # Political working groups
│   ├── 01-federal/                          # Federal Political Engagement
│   │   ├── README.md
│   │   └── framework.md (to be created)
│   └── 02-state/                            # State Political Engagement
│       ├── README.md
│       └── framework.md (to be created)
├── 04-operations/                           # Operations working group
│   ├── README.md
│   ├── 2026-03-14_abib-operations-framework_v1.md
│   └── procedures/
└── coordination/                            # Cross-group coordination
    ├── meeting-minutes/
    ├── progress-reports/
    └── strategic-alignment/
```

---

## Implementation Timeline

### Phase 1: Foundation (March 2026 - COMPLETE)
- ✅ Establish working group structure
- ✅ Create regulatory frameworks (AUSTRAC, ASIC)
- ✅ Develop operations framework
- ✅ Migrate from Notion to Nextcloud

### Phase 2: Expansion (April-June 2026)
- Create community engagement framework
- Develop communications framework
- Establish political engagement frameworks
- Implement coordination systems

### Phase 3: Operationalization (July-September 2026)
- Launch all working groups
- Implement monitoring and reporting
- Begin regular coordination
- Measure initial impact

### Phase 4: Scaling (October-December 2026)
- Expand working group activities
- Increase community engagement
- Enhance policy influence
- Scale educational initiatives

---

## Contact & Support

### Working Group Leads
- **Regulatory Groups**: Designated regulatory experts
- **Community Groups**: Community organizers and advocates
- **Political Groups**: Policy and government relations specialists
- **Operations**: ABIB Operations Team

### Operational Support
- **Coordination**: Abby (AI Operations & Strategy Lead)
- **Administration**: ABIB Operations Working Group
- **Technical**: System administrators
- **Strategic**: ABIB Executive Team

### Communication Channels
- **Internal**: Nextcloud documentation and coordination
- **External**: Website, social media, public communications
- **Stakeholder**: Regular updates to members and partners
- **Emergency**: Designated contact protocols

---

## Appendices

### Appendix A: Working Group Charter Template
Template for establishing new working groups with:
- Mandate and objectives
- Membership and leadership
- Meeting schedule and procedures
- Reporting requirements
- Success metrics

### Appendix B: Coordination Meeting Protocol
Standard procedures for:
- Meeting scheduling and preparation
- Agenda development and distribution
- Minute taking and distribution
- Action item tracking and follow-up
- Decision documentation

### Appendix C: Reporting Templates
Standard templates for:
- Monthly progress reports
- Quarterly performance reviews
- Annual planning documents
- Budget and resource requests
- Impact assessment reports

---

## Approval & Implementation

**Approved By**: ABIB Executive Team  
**Effective Date**: March 2026  
**Review Date**: June 2026 (Quarterly Review)

**Implementation Status**:
- ✅ Regulatory frameworks established
- ✅ Operations framework implemented
- 🔄 Community frameworks in development
- 🔄 Political frameworks in development
- 🔄 Coordination systems being established

**Next Steps**:
1. Create frameworks for community and political working groups
2. Establish coordination meeting schedule
3. Implement reporting and monitoring systems
4. Launch all working groups with clear mandates

---

*This master index establishes the working group structure for ABIB. All working groups operate under this framework while maintaining flexibility to adapt to specific needs and opportunities.*