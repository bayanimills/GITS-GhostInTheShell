# ABIB x RBA

**Source**: Notion
**ID**: 1ddd323b89ec80f0a49deb05ea726a2c
**Created**: 2025-04-22T02:22:00.000Z
**Updated**: 2025-04-22T02:45:00.000Z

---

# What does the RBA Do?

# Key Dates:

2025 -

📄 **Linked Page**: RBA and Treasury Joint Paper on Central Bank Digital Currency and the Future of Digital Money in Australia

📄 **Linked Page**: Project Acacia

# Workflow:

📄 **Linked Page**: 2025-03 - Standing Committee on Economics - RBA Questions

---

*Extracted: 2026-03-13T13:31:57.051Z*
