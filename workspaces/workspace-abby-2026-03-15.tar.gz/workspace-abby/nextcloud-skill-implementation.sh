#!/bin/bash
# Nextcloud Skill Implementation for ABIB Operations
# Usage: ./nextcloud-skill-implementation.sh [command] [args]

set -e

# Configuration
NEXTCLOUD_URL="https://team.bitcoinindustrybody.org.au"
USERNAME="abby"
PASSWORD="agent12345abby"
WEBDAV_BASE="${NEXTCLOUD_URL}/remote.php/dav/files/${USERNAME}"
API_BASE="${NEXTCLOUD_URL}/ocs/v2.php"

# Rate limiting handling
RATE_LIMIT_WAIT=30
MAX_RETRIES=3

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Make curl request with rate limiting handling
make_request() {
    local method=$1
    local url=$2
    local data=$3
    local headers=$4
    local retry_count=0
    
    while [ $retry_count -lt $MAX_RETRIES ]; do
        local curl_cmd="curl -s -u \"${USERNAME}:${PASSWORD}\" -X ${method} \"${url}\""
        
        if [ -n "$data" ]; then
            curl_cmd="${curl_cmd} -d '${data}'"
        fi
        
        if [ -n "$headers" ]; then
            for header in $headers; do
                curl_cmd="${curl_cmd} -H '${header}'"
            done
        fi
        
        local response=$(eval $curl_cmd 2>/dev/null)
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" -u "${USERNAME}:${PASSWORD}" -X ${method} "${url}" 2>/dev/null)
        
        if [ "$http_code" -eq 429 ]; then
            retry_count=$((retry_count + 1))
            log_warning "Rate limited (429). Waiting ${RATE_LIMIT_WAIT} seconds before retry ${retry_count}/${MAX_RETRIES}..."
            sleep $RATE_LIMIT_WAIT
            RATE_LIMIT_WAIT=$((RATE_LIMIT_WAIT * 2)) # Exponential backoff
        elif [ "$http_code" -eq 401 ]; then
            log_error "Authentication failed (401). Check credentials."
            return 1
        elif [ "$http_code" -eq 404 ]; then
            log_error "Resource not found (404): ${url}"
            return 1
        elif [ "$http_code" -eq 200 ] || [ "$http_code" -eq 201 ] || [ "$http_code" -eq 204 ]; then
            echo "$response"
            return 0
        else
            log_error "HTTP ${http_code}: ${response}"
            return 1
        fi
    done
    
    log_error "Max retries exceeded due to rate limiting"
    return 1
}

# List files in directory
list_files() {
    local path=${1:-/}
    log_info "Listing files in: ${path}"
    
    # Remove leading slash if present and add trailing slash
    path="${path#/}"
    [[ "$path" != */ ]] && path="${path}/"
    
    local response=$(make_request "PROPFIND" "${WEBDAV_BASE}/${path}" "" "Depth: 1")
    
    if [ $? -eq 0 ]; then
        # Parse XML response
        echo "$response" | xmlstarlet sel -t -m "//d:response" -v "d:href" -n 2>/dev/null | \
            sed "s|${WEBDAV_BASE}/${path}||" | \
            grep -v "^$" | \
            while read -r item; do
                if [[ "$item" == */ ]]; then
                    echo "[DIR]  ${item%/}"
                else
                    echo "[FILE] ${item}"
                fi
            done
    fi
}

# Upload file
upload_file() {
    local local_path=$1
    local remote_path=$2
    
    if [ ! -f "$local_path" ]; then
        log_error "Local file not found: ${local_path}"
        return 1
    fi
    
    log_info "Uploading ${local_path} to ${remote_path}"
    
    # Remove leading slash from remote path
    remote_path="${remote_path#/}"
    
    curl -s -u "${USERNAME}:${PASSWORD}" \
        -X PUT "${WEBDAV_BASE}/${remote_path}" \
        --data-binary @"${local_path}" \
        -H "Content-Type: application/octet-stream"
    
    if [ $? -eq 0 ]; then
        log_success "Upload completed: ${remote_path}"
    else
        log_error "Upload failed"
        return 1
    fi
}

# Download file
download_file() {
    local remote_path=$1
    local local_path=${2:-$(basename "$remote_path")}
    
    log_info "Downloading ${remote_path} to ${local_path}"
    
    # Remove leading slash from remote path
    remote_path="${remote_path#/}"
    
    curl -s -u "${USERNAME}:${PASSWORD}" \
        -o "${local_path}" \
        "${WEBDAV_BASE}/${remote_path}"
    
    if [ $? -eq 0 ]; then
        log_success "Download completed: ${local_path}"
    else
        log_error "Download failed"
        return 1
    fi
}

# Create directory
create_directory() {
    local path=$1
    
    log_info "Creating directory: ${path}"
    
    # Remove leading slash and ensure no trailing slash for MKCOL
    path="${path#/}"
    path="${path%/}"
    
    make_request "MKCOL" "${WEBDAV_BASE}/${path}"
    
    if [ $? -eq 0 ]; then
        log_success "Directory created: ${path}"
    else
        log_error "Failed to create directory"
        return 1
    fi
}

# Get file info
get_file_info() {
    local path=$1
    
    log_info "Getting info for: ${path}"
    
    # Remove leading slash
    path="${path#/}"
    
    make_request "PROPFIND" "${WEBDAV_BASE}/${path}" "" "Depth: 0"
    
    if [ $? -eq 0 ]; then
        echo "$response"
    fi
}

# Check server status
check_status() {
    log_info "Checking Nextcloud server status..."
    
    local response=$(curl -s "${NEXTCLOUD_URL}/status.php")
    
    if echo "$response" | grep -q '"installed":true'; then
        log_success "Nextcloud is running"
        echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
    else
        log_error "Nextcloud status check failed"
        return 1
    fi
}

# Test connection
test_connection() {
    log_info "Testing Nextcloud connection..."
    
    # First check general status
    if ! check_status > /dev/null 2>&1; then
        log_error "Cannot reach Nextcloud server"
        return 1
    fi
    
    # Try to list root directory
    if list_files "/" > /dev/null 2>&1; then
        log_success "Connection test passed - able to authenticate and list files"
        return 0
    else
        log_error "Connection test failed - authentication or permissions issue"
        return 1
    fi
}

# Main command handler
main() {
    local command=$1
    shift
    
    case $command in
        "list")
            list_files "$@"
            ;;
        "upload")
            if [ $# -lt 2 ]; then
                log_error "Usage: $0 upload <local_file> <remote_path>"
                return 1
            fi
            upload_file "$1" "$2"
            ;;
        "download")
            if [ $# -lt 1 ]; then
                log_error "Usage: $0 download <remote_path> [local_path]"
                return 1
            fi
            download_file "$1" "$2"
            ;;
        "mkdir")
            if [ $# -lt 1 ]; then
                log_error "Usage: $0 mkdir <path>"
                return 1
            fi
            create_directory "$1"
            ;;
        "info")
            if [ $# -lt 1 ]; then
                log_error "Usage: $0 info <path>"
                return 1
            fi
            get_file_info "$1"
            ;;
        "status")
            check_status
            ;;
        "test")
            test_connection
            ;;
        "help"|"")
            echo "Nextcloud Skill for ABIB Operations"
            echo "====================================="
            echo "Commands:"
            echo "  list [path]          - List files in directory (default: /)"
            echo "  upload <local> <remote> - Upload file to Nextcloud"
            echo "  download <remote> [local] - Download file from Nextcloud"
            echo "  mkdir <path>         - Create directory"
            echo "  info <path>          - Get file/directory info"
            echo "  status               - Check server status"
            echo "  test                 - Test connection and authentication"
            echo "  help                 - Show this help"
            echo ""
            echo "Examples:"
            echo "  $0 list"
            echo "  $0 list Committee/"
            echo "  $0 upload policy.pdf Policy/Submissions/policy.pdf"
            echo "  $0 download Committee/meeting-notes.md"
            echo "  $0 mkdir Policy/Research"
            ;;
        *)
            log_error "Unknown command: ${command}"
            echo "Use '$0 help' for usage information"
            return 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"