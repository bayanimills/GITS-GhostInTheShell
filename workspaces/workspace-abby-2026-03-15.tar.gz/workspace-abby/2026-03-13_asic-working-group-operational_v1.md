# ASIC Working Group - Operational Framework

## Executive Summary
**Status**: Regulatory engagement group for Australian Securities and Investments Commission  
**Focus**: Securities regulation, financial services licensing, investor protection  
**Key Documents**: INFO 225 (Digital Assets), RG 133 (Funds Management & Custody)  
**Last Updated**: 2025-04-22 (Notion page), 2026-03-13 (operational framework)  
**Extraction Status**: ✅ Complete - minimal content extracted, comprehensive framework created  

---

## Working Group Overview

### Primary Purpose
Coordinate ABIB's engagement with the Australian Securities and Investments Commission (ASIC), Australia's corporate, markets, and financial services regulator.

### Strategic Importance
- **Securities Regulation**: ASIC determines what constitutes a financial product
- **Licensing Requirements**: AFSL (Australian Financial Services Licence) regime
- **Investor Protection**: Consumer safeguards and disclosure requirements
- **Market Integrity**: Fair and efficient financial markets
- **Bitcoin Impact**: ASIC's decisions directly affect Bitcoin businesses and services

---

## Extracted Content from Notion

### Original Page Content (Minimal)
- **Page Title**: ASIC Working Group
- **Created**: 2025-01-07
- **Last Updated**: 2025-04-22
- **Linked Documents**:
  1. **INFO 225** - Digital Assets: Financial Products & Services
  2. **RG 133** - Funds management and custodial services: Holding assets

### Key Regulatory Documents Identified

#### 1. INFO 225 - Digital Assets: Financial Products & Services
- **Purpose**: Guidance on when digital assets constitute regulated financial products
- **Status**: Updated December 2024 (CP 381 consultation)
- **Key Content**: 13 worked examples of digital assets as financial products
- **Relevance**: Determines which Bitcoin services require AFS licensing
- **Consultation**: CP 381 sought feedback on licensing digital asset intermediaries

#### 2. RG 133 - Funds Management and Custodial Services: Holding Assets
- **Purpose**: Minimum standards for asset holders and custodians
- **Status**: Reissued December 2024 with updated guidance
- **Key Content**: AFS licensee obligations for asset holding
- **Relevance**: Applies to Bitcoin custody services and fund management
- **Impact**: Sets custody standards for digital asset businesses

---

## ASIC Context & Strategic Focus Areas

### Australian Securities and Investments Commission Mandate
- **Primary Legislation**: Corporations Act 2001, ASIC Act 2001
- **Core Functions**:
  1. **Corporate Regulation**: Company registration and governance
  2. **Financial Services**: Licensing and supervision (AFSL)
  3. **Markets Supervision**: Fair and efficient markets
  4. **Consumer Protection**: Investor and financial consumer safeguards
  5. **Enforcement**: Investigation and prosecution of misconduct

### Bitcoin Relevance Areas
1. **Financial Product Definition**: When is Bitcoin/Bitcoin services a regulated product?
2. **Licensing Requirements**: Which Bitcoin businesses need AFS licenses?
3. **Custody Standards**: How should Bitcoin custody services operate?
4. **Disclosure Obligations**: What information must Bitcoin businesses provide?
5. **Market Conduct**: Fair trading and anti-manipulation rules
6. **Fund Management**: Bitcoin investment funds and products

### Key ASIC Initiatives (2024-2026)
1. **INFO 225 Update** (CP 381) - Digital assets guidance modernization
2. **RG 133 Reissue** - Custody standards for digital assets
3. **Digital Assets Licensing** - AFSL regime for crypto intermediaries
4. **Consumer Warnings** - Investor protection for crypto assets
5. **Enforcement Actions** - Market integrity and misconduct cases

---

## Working Group Structure & Operations

### Governance Model
```
ASIC Working Group
├── Strategic Direction (ABIB Leadership)
├── Policy Development (Regulatory Experts)
├── Legal Analysis (Compliance Specialists)
├── Industry Coordination (Bitcoin Businesses)
└── Monitoring & Reporting (Abby - AI Operations)
```

### Membership Composition
- **ABIB Leadership**: Strategic oversight and decision-making
- **Legal Experts**: Corporations Act and financial services law
- **Compliance Professionals**: AFSL requirements and implementation
- **Bitcoin Business Representatives**: Exchange, custody, fund managers
- **Technical Experts**: Blockchain and Bitcoin protocol understanding
- **Consumer Advocates**: User protection and education

### Meeting Structure
- **Quarterly**: Strategic review of ASIC developments
- **Monthly**: Working group coordination and planning
- **Ad-hoc**: Response to ASIC consultations and publications
- **Emergency**: Rapid response to significant regulatory changes

---

## Workflow Process for ASIC Engagement

### 5-Step Regulatory Response Process
```mermaid
graph TD
    A[Monitor ASIC Publications] --> B[Analyze Regulatory Impact]
    B --> C[Develop ABIB Position]
    C --> D[Draft Submission/Response]
    D --> E[Deliver & Follow-up]
```

### Detailed Engagement Process

#### 1. Monitoring & Identification
- **Daily**: ASIC website and publication monitoring
- **Weekly**: Regulatory update review and analysis
- **Monthly**: Consultation paper identification and prioritization
- **Quarterly**: Strategic trend analysis and planning

#### 2. Impact Analysis
- **Legal Analysis**: Corporations Act interpretation and implications
- **Business Impact**: Effect on Bitcoin industry segments
- **Consumer Impact**: User protection and access considerations
- **Strategic Alignment**: Consistency with ABIB policy positions

#### 3. Position Development
- **Working Group Input**: Collective expertise and perspectives
- **Industry Consultation**: Bitcoin business feedback and concerns
- **Legal Review**: Compliance with existing law and regulations
- **Strategic Review**: Alignment with Austrian economics principles

#### 4. Response Development
- **Evidence-Based**: Data, research, and practical examples
- **Solution-Oriented**: Constructive recommendations and alternatives
- **Clear Communication**: Accessible language for regulatory audience
- **Professional Format**: ASIC submission standards and requirements

#### 5. Delivery & Engagement
- **Formal Submission**: Through official ASIC channels
- **Relationship Building**: Meetings with ASIC officials
- **Public Advocacy**: Media and public communication
- **Follow-up Monitoring**: Tracking ASIC response and implementation

---

## Key Regulatory Issues & Positions

### 1. Financial Product Definition (INFO 225)
- **Issue**: When do Bitcoin and Bitcoin services become regulated financial products?
- **ABIB Position**: Bitcoin as commodity/money, not security; minimal services regulation
- **Key Argument**: Distinguish between Bitcoin protocol and ancillary services
- **Goal**: Clear, sensible boundaries that don't stifle innovation

### 2. Licensing Requirements (AFSL Regime)
- **Issue**: Which Bitcoin businesses require Australian Financial Services Licences?
- **ABIB Position**: Risk-based approach focusing on custody and investment advice
- **Key Argument**: Proportional regulation based on actual consumer risks
- **Goal**: Protect consumers without crushing Bitcoin industry

### 3. Custody Standards (RG 133)
- **Issue**: Appropriate custody standards for Bitcoin and digital assets
- **ABIB Position**: Technology-neutral standards recognizing Bitcoin's unique properties
- **Key Argument**: Self-custody as legitimate option, institutional custody standards
- **Goal**: Security without forcing centralized custody models

### 4. Disclosure & Consumer Protection
- **Issue**: Appropriate disclosure requirements for Bitcoin businesses
- **ABIB Position**: Clear, accurate information about Bitcoin risks and characteristics
- **Key Argument**: Education over paternalism, informed consent principles
- **Goal**: Empowered users making informed decisions

### 5. Market Integrity & Enforcement
- **Issue**: Preventing fraud and market manipulation in Bitcoin markets
- **ABIB Position**: Support legitimate enforcement against actual fraud
- **Key Argument**: Distinguish between fraud prevention and innovation suppression
- **Goal**: Clean markets that build trust and confidence

---

## Current & Upcoming Engagements

### Active Regulatory Processes
1. **INFO 225 Consultation Response** (CP 381) - Submitted/planned
2. **RG 133 Implementation** - Monitoring and guidance development
3. **Digital Assets Licensing Framework** - Ongoing engagement
4. **Consumer Protection Initiatives** - Input and collaboration

### Planned Submissions & Engagements
1. **Bitcoin as Non-Financial Product** - Clarification submission
2. **Custody Standards for Digital Assets** - Practical guidance
3. **Exchange Regulation Framework** - Proportional approach
4. **Investment Product Standards** - Bitcoin fund management

### Relationship Building Priorities
1. **ASIC Digital Assets Team** - Primary regulatory contacts
2. **Financial Services Licensing** - AFSL application guidance
3. **Market Integrity Division** - Trading and market conduct
4. **Consumer Protection Team** - Investor education and warnings

---

## Success Metrics & Monitoring

### Engagement Metrics
- Number of formal submissions to ASIC
- Meetings conducted with ASIC officials
- Consultation responses submitted
- Regulatory clarifications obtained

### Impact Metrics
- Policy positions reflected in ASIC guidance
- Regulatory burden reduction for Bitcoin businesses
- Consumer protection improvements
- Market clarity and certainty achieved

### Operational Metrics
- Response time to ASIC consultations
- Quality and completeness of submissions
- Stakeholder satisfaction with engagement
- Process efficiency and effectiveness

---

## Migration & Integration Status

### Current Status
- ✅ **Content Extracted**: Minimal Notion page content preserved
- ✅ **Operational Framework**: Comprehensive structure created
- ✅ **Regulatory Context**: INFO 225 and RG 133 analysis included
- ✅ **Integration Ready**: Connected to ABIB policy operations

### Nextcloud Integration
```
ABIB-Admin/operations/abby/01-policy/regulatory-tracking/asic/
├── 2026-03-13_notion_asic-working-group_v1.md      # Original extraction
├── 2026-03-13_asic-working-group-operational_v1.md  # This framework
├── README.md                                        # Directory documentation
├── info-225/                                        # Digital assets guidance
│   ├── analysis/                                    # Regulatory analysis
│   ├── submissions/                                 # Formal responses
│   └── implementation/                              # Business guidance
├── rg-133/                                          # Custody standards
│   ├── analysis/                                    # Regulatory analysis
│   ├── submissions/                                 # Formal responses
│   └── implementation/                              # Compliance guidance
└── engagements/                                     # ASIC relationship management
    ├── meetings/                                    # Meeting notes and outcomes
    ├── correspondence/                              # Official communications
    └── relationship-tracking/                       # Contact management
```

### Notion Deprecation Plan
1. ✅ **Content Migration**: All accessible content extracted
2. 🔄 **Verification**: Confirm no additional content in Notion
3. 📋 **Redirect Setup**: Migration notice on Notion page
4. 🗑️ **Archive & Delete**: Final export and page removal

---

## Immediate Action Items

### Week 1 (Next 7 days)
1. ✅ **Framework Establishment**: Create operational structure (this document)
2. 🔄 **Stakeholder Review**: Circulate to ABIB leadership and working group
3. 📅 **Monitoring Setup**: Implement ASIC publication tracking
4. 👥 **Membership Confirmation**: Confirm working group participants

### Month 1 (Next 30 days)
1. **Regulatory Analysis**: Deep dive into INFO 225 and RG 133
2. **Contact Database**: Develop ASIC relationship tracking system
3. **Template Library**: Create submission and response templates
4. **Workflow Implementation**: Operationalize 5-step engagement process

### Quarter 1 (Next 90 days)
1. **Strategic Plan**: Develop comprehensive ASIC engagement strategy
2. **Position Papers**: Create detailed policy positions on key issues
3. **Relationship Building**: Initiate formal ASIC engagement
4. **Integration Complete**: Full operational transition from Notion

---

## Related Resources & Connections

### ABIB Policy Framework Integration
- **Financial Self-Sovereignty**: ASIC regulation impact on individual control
- **Privacy & Freedom**: Surveillance and reporting requirements
- **Tax Reform**: Interaction with ATO reporting and compliance
- **Energy & Climate**: Bitcoin mining regulation and energy reporting

### Australian Regulatory Ecosystem
- **Treasury**: Digital assets policy framework (connected)
- **AUSTRAC**: AML/CTF compliance (already migrated)
- **RBA**: Payments system and digital currency (connected)
- **APRA**: Banking sector and financial stability

### Bitcoin Industry Context
- **OrangeLabel.io**: 250+ Bitcoin businesses affected by ASIC rules
- **Australian Exchanges**: AFSL requirements and compliance
- **Custody Providers**: RG 133 standards implementation
- **Investment Funds**: Managed investment scheme regulation
- **Advisors & Educators**: Financial advice licensing requirements

---

## Contact & Coordination

### ABIB Leadership
- **Bayani Mills** - CEO, Strategic direction
- **Daniel Wilczynski** - Policy development lead
- **Elmo Stoop** - Regulatory engagement
- **Ben Dickens** - Board oversight

### Operational Team
- **Abby** - AI Operations & Strategy Lead (framework development)
- **Donna** - Executive operations coordination
- **The Doc** - Document processing and management
- **Legal/Compliance Experts** - Regulatory analysis and submissions
- **Industry Representatives** - Bitcoin business perspective

### External Coordination
- ASIC Digital Assets and Innovation team
- ASIC Financial Services Licensing
- ASIC Market Integrity division
- ASIC Consumer Protection team
- Legal and compliance advisors
- Industry association partners

---

**Document Status**: Operational framework established  
**Last Updated**: 2026-03-13  
**Next Review**: 2026-04-13  
**Version**: v1.0  
**Prepared By**: Abby - AI Operations & Strategy Lead  
**Approval Required**: ABIB Leadership and working group review