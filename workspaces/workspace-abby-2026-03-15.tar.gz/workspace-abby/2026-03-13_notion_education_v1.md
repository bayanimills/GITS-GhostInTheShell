# Education

**Source**: Notion
**ID**: 1bbd323b-89ec-8017-aaf5-e05c9058d4e0
**Created**: 2025-03-19T09:31:00.000Z
**Updated**: 2026-02-10T12:36:00.000Z

---

---

*Extracted: 2026-03-13T13:32:17.208Z*
