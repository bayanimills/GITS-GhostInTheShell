# Nextcloud Skill for ABIB Operations

## Overview
Skill for managing files on the Australian Bitcoin Industry Body's Nextcloud instance via WebDAV.

## Configuration
- **URL:** `https://team.bitcoinindustrybody.org.au`
- **WebDAV Endpoint:** `https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/`
- **Username:** `abby`
- **Password:** `agent12345abby` (stored securely in 1Password)

## Functions

### 1. Upload File
```bash
# Upload a file to Nextcloud
curl -u "abby:agent12345abby" \
  -X PUT "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/path/to/destination/filename.ext" \
  --data-binary @localfile.ext
```

### 2. Download File
```bash
# Download a file from Nextcloud
curl -u "abby:agent12345abby" \
  -o localfile.ext \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/path/to/file.ext"
```

### 3. List Directory Contents
```bash
# List files in a directory
curl -u "abby:agent12345abby" \
  -X PROPFIND -H "Depth: 1" \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/path/to/folder/" \
  | xmllint --format - | grep -o 'href>[^<]*' | sed 's/href>//'
```

### 4. Create Directory
```bash
# Create a new directory
curl -u "abby:agent12345abby" \
  -X MKCOL \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/path/to/newfolder/"
```

### 5. Delete File/Directory
```bash
# Delete a file or empty directory
curl -u "abby:agent12345abby" \
  -X DELETE \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/path/to/file-or-folder/"
```

### 6. Move/Rename File
```bash
# Move or rename a file
curl -u "abby:agent12345abby" \
  -X MOVE -H "Destination: https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/new/path/filename.ext" \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/old/path/filename.ext"
```

## ABIB-Specific Directories Structure

Based on committee pack upload, expected structure:

```
abby/
├── Committee/                    # Committee documents
│   ├── Meetings/                # Meeting minutes and agendas
│   ├── Reports/                 # Committee reports
│   └── Submissions/             # Policy submissions
├── Policy/                      # Policy documents
│   ├── Regulatory/              # Regulatory submissions
│   ├── Research/                # Research papers
│   └── Position-Papers/         # ABIB position papers
├── Education/                   # Educational materials
│   ├── Guides/                  # How-to guides
│   ├── Presentations/           # Presentation decks
│   └── Resources/               # Educational resources
├── Operations/                  # Operational documents
│   ├── Workflows/               # Operational workflows
│   ├── Templates/               # Document templates
│   └── Procedures/              # Standard procedures
└── Media/                       # Media assets
    ├── Logos/                   # Brand assets
    ├── Images/                  # Images for content
    └── Videos/                  # Video content
```

## Usage Examples for ABIB Work

### Upload Policy Submission
```bash
curl -u "abby:agent12345abby" \
  -X PUT "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/Policy/Regulatory/ASIC-Consultation-2026.pdf" \
  --data-binary @/local/path/to/submission.pdf
```

### Download Committee Meeting Minutes
```bash
curl -u "abby:agent12345abby" \
  -o meeting-minutes-2026-03-13.md \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/Committee/Meetings/2026-03-13-minutes.md"
```

### List Educational Materials
```bash
curl -u "abby:agent12345abby" \
  -X PROPFIND -H "Depth: 1" \
  "https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/Education/Guides/" \
  | xmllint --format - | grep -o 'href>[^<]*' | sed 's/href>//' | grep -v '/$'
```

## Security Notes
1. **Credentials:** Store password in 1Password, not in plain text
2. **Rate Limiting:** Be mindful of Cloudflare rate limits (429 errors)
3. **Backup:** Important documents should have backup copies
4. **Access Control:** Use Nextcloud sharing features for collaboration

## Integration with Other Skills
- **1Password:** Retrieve credentials securely
- **GitHub:** Sync with ABIB GitHub repositories
- **Document Processing:** Convert/process documents before upload
- **Cron:** Schedule regular backups/syncs

## Error Handling
- **401 Unauthorized:** Check credentials
- **404 Not Found:** File/directory doesn't exist
- **409 Conflict:** Directory already exists
- **429 Too Many Requests:** Wait and retry
- **507 Insufficient Storage:** Contact administrator

## Best Practices for ABIB
1. Use consistent naming conventions
2. Organize by project/committee/date
3. Keep file sizes reasonable for WebDAV
4. Regular cleanup of temporary files
5. Document file structure changes in MEMORY.md

---

*Last Updated: 2026-03-13*
*For: Australian Bitcoin Industry Body Operations*