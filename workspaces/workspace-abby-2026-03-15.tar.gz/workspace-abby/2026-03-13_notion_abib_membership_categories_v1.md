# ABIB Membership Categories

**Source**: Notion
**ID**: e5a3c5003ee945fa8f9318fb440b7284
**Created**: 2025-01-08T10:46:00.000Z
**Updated**: 2025-08-20T04:24:00.000Z

---

# FINAL DRAFT

- **Memberships run from 1 July to 30 June.**
- **All memberships expire on 30 June, regardless of join date.**
- **Memberships taken after 1 January pay the full annual fee upfront.**
- **A 50% credit will be applied to their next year’s renewal invoice.**
- **Renewal invoices are sent 60 days before 30 June, payable by 30 June.**
# $615

- A bitcoin enterprise, AND/OR 
- An applicant approved by the Board.
- A Business or enterprise that accepts Bitcoin (not crypto) as payment, AND/OR 
- An applicant approved by the Board.
# $61.50

- A Business or enterprise that accepts Bitcoin (not crypto) as payment, AND/OR
- An applicant approved by the Board.
- An individual, business, or entity that is **Bitcoin-only**, AND/OR 
- their application has been approved.
# $0

- A non-financial member that is a nominated representative of an active bitcoin-only meetup group hosting regular events.
---

*Extracted: 2026-03-13T13:32:14.242Z*
