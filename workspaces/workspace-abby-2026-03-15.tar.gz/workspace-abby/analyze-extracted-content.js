const fs = require('fs');
const path = require('path');

// List of all extracted files
const extractedFiles = [
  // Already migrated with frameworks
  '2026-03-13_asic-working-group-operational_v1.md',
  '2026-03-13_austrac-working-group-operational_v1.md',
  '2026-03-13_rba-treasury-working-group-operational_v1.md',
  
  // New extractions (need frameworks)
  '2026-03-13_notion_working-groups-dashboard-complex_v1.md',
  '2026-03-13_notion_business_adoption_v1.md',
  '2026-03-13_notion_communications___outreach_v1.md',
  '2026-03-13_notion_mining___energy_v1.md',
  '2026-03-13_notion_community_voices_v1.md',
  '2026-03-13_notion_auspol_v1.md',
  '2026-03-13_notion_abib_x_rba_v1.md',
  '2026-03-13_notion_policy_working_group_v1.md',
  '2026-03-13_notion_financial_inclusion_working_group_v1.md',
  '2026-03-13_notion_abib_operations_v1.md',
  '2026-03-13_notion_abib_budget_v1.md',
  '2026-03-13_notion_abib_policy___procedure_manual_v1.md',
  '2026-03-13_notion_bitcoin_research_newsletter_v1.md',
  '2026-03-13_notion_abib_membership_categories_v1.md',
  '2026-03-13_notion_education_v1.md',
  '2026-03-13_notion_resources_v1.md',
  '2026-03-13_notion_resource_library_v1.md',
  '2026-03-13_notion_abib_policies_v1.md',
  '2026-03-13_notion_strategic_roadmap_2025_2030_v1.md',
  '2026-03-13_notion_our_next_steps_v1.md'
];

function analyzeFile(filename) {
  try {
    const content = fs.readFileSync(filename, 'utf8');
    const lines = content.split('\n');
    
    // Basic analysis
    const sizeKB = (content.length / 1024).toFixed(1);
    const lineCount = lines.length;
    const wordCount = content.split(/\s+/).length;
    
    // Look for key indicators
    let hasContent = false;
    let hasLinks = false;
    let hasLists = false;
    let hasHeadings = false;
    
    for (const line of lines) {
      if (line.trim().length > 10) hasContent = true;
      if (line.includes('http://') || line.includes('https://')) hasLinks = true;
      if (line.trim().startsWith('- ') || line.trim().match(/^\d+\./)) hasLists = true;
      if (line.trim().startsWith('#') || line.trim().startsWith('##')) hasHeadings = true;
    }
    
    // Determine content type
    let contentType = 'minimal';
    if (wordCount > 200) contentType = 'substantial';
    else if (wordCount > 50) contentType = 'moderate';
    
    // Determine operational importance
    let importance = 'low';
    const lowerFilename = filename.toLowerCase();
    
    if (lowerFilename.includes('operations') || 
        lowerFilename.includes('dashboard') ||
        lowerFilename.includes('roadmap') ||
        lowerFilename.includes('policy_manual')) {
      importance = 'high';
    } else if (lowerFilename.includes('working_group') ||
               lowerFilename.includes('budget') ||
               lowerFilename.includes('membership')) {
      importance = 'medium';
    }
    
    return {
      filename,
      sizeKB: `${sizeKB} KB`,
      lines: lineCount,
      words: wordCount,
      contentType,
      hasContent,
      hasLinks,
      hasLists,
      hasHeadings,
      importance,
      isEmpty: wordCount < 20
    };
  } catch (error) {
    return {
      filename,
      error: error.message,
      isEmpty: true,
      importance: 'unknown'
    };
  }
}

function createAnalysisReport() {
  console.log('🔍 ANALYZING EXTRACTED CONTENT\n');
  console.log('='.repeat(80));
  
  const analyses = [];
  let totalWords = 0;
  let highImportance = 0;
  let mediumImportance = 0;
  let lowImportance = 0;
  let emptyFiles = 0;
  
  // Analyze each file
  extractedFiles.forEach(filename => {
    if (fs.existsSync(filename)) {
      const analysis = analyzeFile(filename);
      analyses.push(analysis);
      
      totalWords += analysis.words || 0;
      
      if (analysis.importance === 'high') highImportance++;
      else if (analysis.importance === 'medium') mediumImportance++;
      else if (analysis.importance === 'low') lowImportance++;
      
      if (analysis.isEmpty) emptyFiles++;
    }
  });
  
  // Sort by importance and content
  analyses.sort((a, b) => {
    const importanceOrder = { high: 3, medium: 2, low: 1, unknown: 0 };
    return importanceOrder[b.importance] - importanceOrder[a.importance] || 
           (b.words || 0) - (a.words || 0);
  });
  
  // Display analysis
  console.log('\n📊 CONTENT ANALYSIS SUMMARY:\n');
  
  analyses.forEach((analysis, i) => {
    const icon = analysis.importance === 'high' ? '🚨' :
                 analysis.importance === 'medium' ? '⚠️' : '📄';
    const status = analysis.isEmpty ? '📭 EMPTY' : 
                   analysis.contentType === 'substantial' ? '📚 SUBSTANTIAL' :
                   analysis.contentType === 'moderate' ? '📝 MODERATE' : '📄 MINIMAL';
    
    console.log(`${i + 1}. ${icon} ${analysis.filename}`);
    console.log(`   ${status} | ${analysis.words} words | ${analysis.sizeKB}`);
    console.log(`   Importance: ${analysis.importance.toUpperCase()}`);
    
    if (analysis.error) {
      console.log(`   ❌ Error: ${analysis.error}`);
    }
    
    console.log();
  });
  
  // Statistics
  console.log('='.repeat(80));
  console.log('\n📈 STATISTICS:\n');
  console.log(`Total files analyzed: ${analyses.length}`);
  console.log(`Total words extracted: ${totalWords.toLocaleString()}`);
  console.log(`High importance files: ${highImportance}`);
  console.log(`Medium importance files: ${mediumImportance}`);
  console.log(`Low importance files: ${lowImportance}`);
  console.log(`Empty/minimal files: ${emptyFiles}`);
  
  // Recommendations
  console.log('\n' + '='.repeat(80));
  console.log('\n🎯 RECOMMENDATIONS FOR OPERATIONAL FRAMEWORKS:\n');
  
  const highPriority = analyses.filter(a => a.importance === 'high' && !a.isEmpty);
  const mediumPriority = analyses.filter(a => a.importance === 'medium' && !a.isEmpty);
  
  console.log('🚨 HIGH PRIORITY (Create operational frameworks first):');
  highPriority.forEach((analysis, i) => {
    const name = analysis.filename.replace('2026-03-13_notion_', '').replace('_v1.md', '');
    console.log(`${i + 1}. ${name} (${analysis.words} words)`);
  });
  
  console.log('\n⚠️ MEDIUM PRIORITY (Create frameworks next):');
  mediumPriority.forEach((analysis, i) => {
    const name = analysis.filename.replace('2026-03-13_notion_', '').replace('_v1.md', '');
    console.log(`${i + 1}. ${name} (${analysis.words} words)`);
  });
  
  console.log('\n📄 LOW PRIORITY (Reference/archive only):');
  const lowPriority = analyses.filter(a => a.importance === 'low' || a.isEmpty);
  lowPriority.forEach((analysis, i) => {
    const name = analysis.filename.replace('2026-03-13_notion_', '').replace('_v1.md', '');
    console.log(`${i + 1}. ${name} (${analysis.isEmpty ? 'empty' : analysis.words + ' words'})`);
  });
  
  // Next steps
  console.log('\n' + '='.repeat(80));
  console.log('\n📋 PHASE 2: OPERATIONAL FRAMEWORK CREATION PLAN\n');
  
  console.log('Step 1: Create frameworks for HIGH PRIORITY files');
  console.log('  - ABIB Operations (updated today)');
  console.log('  - Working Groups Dashboard');
  console.log('  - Strategic Roadmap 2025-2030');
  console.log('  - ABIB Policy & Procedure Manual');
  
  console.log('\nStep 2: Create frameworks for MEDIUM PRIORITY working groups');
  console.log('  - Business Adoption');
  console.log('  - Policy Working Group');
  console.log('  - Financial Inclusion Working Group');
  console.log('  - ABIB Budget');
  console.log('  - ABIB Membership Categories');
  
  console.log('\nStep 3: Create frameworks for other working groups');
  console.log('  - Communications & Outreach');
  console.log('  - Mining & Energy');
  console.log('  - Community Voices');
  console.log('  - AUSPOL');
  console.log('  - Education');
  
  console.log('\nStep 4: Handle LOW PRIORITY/empty files');
  console.log('  - Archive or create minimal frameworks');
  
  // Create report file
  let report = `# ABIB Extracted Content Analysis Report\n\n`;
  report += `**Generated**: ${new Date().toISOString()}\n`;
  report += `**Files Analyzed**: ${analyses.length}\n`;
  report += `**Total Words**: ${totalWords.toLocaleString()}\n\n`;
  report += `---\n\n`;
  
  report += `## Priority Classification\n\n`;
  report += `### 🚨 HIGH PRIORITY (${highPriority.length} files)\n\n`;
  highPriority.forEach(a => {
    report += `- **${a.filename}** (${a.words} words, ${a.sizeKB})\n`;
  });
  
  report += `\n### ⚠️ MEDIUM PRIORITY (${mediumPriority.length} files)\n\n`;
  mediumPriority.forEach(a => {
    report += `- **${a.filename}** (${a.words} words, ${a.sizeKB})\n`;
  });
  
  report += `\n### 📄 LOW PRIORITY (${lowPriority.length} files)\n\n`;
  lowPriority.forEach(a => {
    report += `- **${a.filename}** (${a.isEmpty ? 'empty/minimal' : a.words + ' words'})\n`;
  });
  
  report += `\n---\n\n`;
  report += `## Operational Framework Creation Plan\n\n`;
  
  report += `### Phase 2A: High Priority Frameworks (Week 1)\n`;
  report += `1. ABIB Operations Framework\n`;
  report += `2. Working Groups Dashboard Framework\n`;
  report += `3. Strategic Roadmap 2025-2030 Framework\n`;
  report += `4. Policy & Procedure Framework\n\n`;
  
  report += `### Phase 2B: Medium Priority Frameworks (Week 2)\n`;
  report += `1. Business Adoption Framework\n`;
  report += `2. Policy Working Group Framework\n`;
  report += `3. Financial Inclusion Framework\n`;
  report += `4. Budget Management Framework\n`;
  report += `5. Membership Framework\n\n`;
  
  report += `### Phase 2C: Other Working Groups (Week 3)\n`;
  report += `1. Communications & Outreach Framework\n`;
  report += `2. Mining & Energy Framework\n`;
  report += `3. Community Voices Framework\n`;
  report += `4. AUSPOL Framework\n`;
  report += `5. Education Framework\n\n`;
  
  report += `### Phase 2D: Low Priority/Archive (Week 4)\n`;
  report += `1. Archive empty/minimal files\n`;
  report += `2. Create reference documentation\n`;
  report += `3. Verify complete migration\n`;
  
  const reportFile = '2026-03-14_abib-content-analysis-and-plan_v1.md';
  fs.writeFileSync(reportFile, report);
  
  console.log(`\n💾 Analysis report saved: ${reportFile}`);
  
  return {
    analyses,
    highPriority: highPriority.length,
    mediumPriority: mediumPriority.length,
    lowPriority: lowPriority.length,
    emptyFiles,
    totalWords
  };
}

// Run analysis
createAnalysisReport();