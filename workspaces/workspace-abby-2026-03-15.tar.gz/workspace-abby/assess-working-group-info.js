const fs = require('fs');
const path = require('path');

// List of all 8 official working groups
const WORKING_GROUPS = [
  {
    name: 'AUSTRAC Working Group',
    category: 'Regulatory & Policy',
    description: 'AML/CTF compliance and engagement with Australia\'s financial intelligence agency',
    extractedFile: '2026-03-13_notion_austrac-working-group_v1.md',
    frameworkFile: '2026-03-13_austrac-working-group-operational_v1.md',
    status: 'migrated'
  },
  {
    name: 'ASIC Working Group',
    category: 'Regulatory & Policy',
    description: 'Regulatory frameworks and engagement with the Australian Securities and Investments Commission',
    extractedFile: '2026-03-13_notion_asic-working-group_v1.md',
    frameworkFile: '2026-03-13_asic-working-group-operational_v1.md',
    status: 'migrated'
  },
  {
    name: 'Treasury & RBA Working Group',
    category: 'Regulatory & Policy',
    description: 'Policy development and submissions to the Australian Treasury',
    extractedFile: '2026-03-13_rba-treasury-working-group-context_v1.md',
    frameworkFile: '2026-03-13_rba-treasury-working-group-operational_v1.md',
    status: 'partial'
  },
  {
    name: 'Community Engagement Working Group',
    category: 'Community & Engagement',
    description: 'Grassroots events, meetups, and education to grow the Bitcoin community',
    extractedFile: '2026-03-13_notion_community_voices_v1.md', // Note: This might be related
    frameworkFile: '2026-03-14_community-engagement-working-group-framework_v1.md',
    status: 'framework_created'
  },
  {
    name: 'Communications Working Group',
    category: 'Community & Engagement',
    description: 'Public relations, media outreach, social media, and content creation',
    extractedFile: '2026-03-13_notion_communications___outreach_v1.md',
    frameworkFile: '2026-03-14_communications-working-group-framework_v1.md',
    status: 'framework_created'
  },
  {
    name: 'Political Engagement - Federal Working Group',
    category: 'Political Engagement',
    description: 'Engagement with federal parliamentarians and policymakers',
    extractedFile: '2026-03-13_notion_auspol_v1.md', // Note: This might be related
    frameworkFile: null,
    status: 'needs_framework'
  },
  {
    name: 'Political Engagement - State Working Group',
    category: 'Political Engagement',
    description: 'Engagement with state governments and representatives on local Bitcoin adoption and policy',
    extractedFile: null,
    frameworkFile: null,
    status: 'needs_framework'
  },
  {
    name: 'ABIB Operations Working Group',
    category: 'Operations',
    description: 'Internal operations including finance, administration, technology, and organisational management',
    extractedFile: '2026-03-13_notion_abib_operations_v1.md',
    frameworkFile: '2026-03-14_abib-operations-framework_v1.md',
    status: 'framework_created'
  }
];

function analyzeFileContent(filename) {
  if (!filename || !fs.existsSync(filename)) {
    return { exists: false, content: null, analysis: null };
  }
  
  try {
    const content = fs.readFileSync(filename, 'utf8');
    const lines = content.split('\n');
    const wordCount = content.split(/\s+/).length;
    
    // Basic analysis
    let hasSubstantialContent = wordCount > 100;
    let hasLinks = content.includes('http://') || content.includes('https://');
    let hasLists = content.includes('- ') || content.match(/\d+\./);
    let hasHeadings = content.includes('# ') || content.includes('## ');
    
    // Look for specific content indicators
    let hasObjectives = false;
    let hasActions = false;
    let hasContacts = false;
    let hasDates = false;
    
    const lowerContent = content.toLowerCase();
    if (lowerContent.includes('objective') || lowerContent.includes('goal') || lowerContent.includes('purpose')) {
      hasObjectives = true;
    }
    if (lowerContent.includes('action') || lowerContent.includes('initiative') || lowerContent.includes('activity')) {
      hasActions = true;
    }
    if (lowerContent.includes('contact') || lowerContent.includes('email') || lowerContent.includes('@')) {
      hasContacts = true;
    }
    if (lowerContent.includes('202') || lowerContent.includes('date') || lowerContent.includes('deadline')) {
      hasDates = true;
    }
    
    return {
      exists: true,
      wordCount,
      lines: lines.length,
      analysis: {
        hasSubstantialContent,
        hasLinks,
        hasLists,
        hasHeadings,
        hasObjectives,
        hasActions,
        hasContacts,
        hasDates,
        contentType: wordCount > 500 ? 'substantial' : wordCount > 100 ? 'moderate' : 'minimal'
      },
      preview: content.substring(0, 500) + (content.length > 500 ? '...' : '')
    };
  } catch (error) {
    return { exists: false, error: error.message, content: null, analysis: null };
  }
}

function assessWorkingGroups() {
  console.log('🔍 ASSESSING WORKING GROUP INFORMATION\n');
  console.log('='.repeat(100));
  
  let totalExtractedWords = 0;
  let totalFrameworkWords = 0;
  let groupsWithContent = 0;
  let groupsWithFrameworks = 0;
  
  console.log('\n📋 WORKING GROUP ASSESSMENT:\n');
  
  WORKING_GROUPS.forEach((group, index) => {
    console.log(`${index + 1}. ${group.name}`);
    console.log(`   Category: ${group.category}`);
    console.log(`   Description: ${group.description}`);
    
    // Check extracted content
    if (group.extractedFile) {
      const extracted = analyzeFileContent(group.extractedFile);
      if (extracted.exists) {
        totalExtractedWords += extracted.wordCount;
        groupsWithContent++;
        
        console.log(`   📄 Extracted: ${group.extractedFile}`);
        console.log(`      Words: ${extracted.wordCount}, Type: ${extracted.analysis.contentType}`);
        
        if (extracted.analysis.hasObjectives) console.log(`      ✓ Has objectives/goals`);
        if (extracted.analysis.hasActions) console.log(`      ✓ Has actions/initiatives`);
        if (extracted.analysis.hasContacts) console.log(`      ✓ Has contact information`);
        if (extracted.analysis.hasDates) console.log(`      ✓ Has dates/deadlines`);
        
        // Show brief preview if content is minimal
        if (extracted.wordCount < 200 && extracted.preview) {
          console.log(`      Preview: ${extracted.preview.replace(/\n/g, ' ').substring(0, 150)}...`);
        }
      } else {
        console.log(`   📭 No extracted file found: ${group.extractedFile}`);
      }
    } else {
      console.log(`   📭 No extracted file specified`);
    }
    
    // Check framework
    if (group.frameworkFile) {
      const framework = analyzeFileContent(group.frameworkFile);
      if (framework.exists) {
        totalFrameworkWords += framework.wordCount;
        groupsWithFrameworks++;
        
        console.log(`   🏗️ Framework: ${group.frameworkFile}`);
        console.log(`      Words: ${framework.wordCount}, Comprehensive: ${framework.wordCount > 5000 ? 'YES' : 'NO'}`);
      } else {
        console.log(`   🚨 Framework file not found: ${group.frameworkFile}`);
      }
    } else {
      console.log(`   🔄 Framework needed`);
    }
    
    console.log(`   Status: ${group.status.toUpperCase().replace(/_/g, ' ')}`);
    console.log();
  });
  
  // Summary
  console.log('='.repeat(100));
  console.log('\n📊 ASSESSMENT SUMMARY:\n');
  
  console.log(`Total Working Groups: ${WORKING_GROUPS.length}`);
  console.log(`Groups with extracted content: ${groupsWithContent}/${WORKING_GROUPS.length}`);
  console.log(`Groups with frameworks: ${groupsWithFrameworks}/${WORKING_GROUPS.length}`);
  console.log(`Total extracted words: ${totalExtractedWords.toLocaleString()}`);
  console.log(`Total framework words: ${totalFrameworkWords.toLocaleString()}`);
  console.log(`Combined documentation: ${(totalExtractedWords + totalFrameworkWords).toLocaleString()} words`);
  
  // Status breakdown
  const statusCounts = {};
  WORKING_GROUPS.forEach(g => {
    statusCounts[g.status] = (statusCounts[g.status] || 0) + 1;
  });
  
  console.log('\n📈 STATUS BREAKDOWN:');
  Object.entries(statusCounts).forEach(([status, count]) => {
    const icon = status === 'migrated' ? '✅' :
                 status === 'framework_created' ? '🏗️' :
                 status === 'partial' ? '⚠️' : '🔴';
    console.log(`   ${icon} ${status.replace(/_/g, ' ').toUpperCase()}: ${count} groups`);
  });
  
  // Recommendations
  console.log('\n' + '='.repeat(100));
  console.log('\n🎯 RECOMMENDED NEXT STEPS:\n');
  
  // Groups needing attention
  const needsAttention = WORKING_GROUPS.filter(g => 
    g.status === 'needs_framework' || 
    g.status === 'partial' || 
    (!g.extractedFile && !g.frameworkFile)
  );
  
  if (needsAttention.length > 0) {
    console.log('🚨 GROUPS NEEDING ATTENTION:');
    needsAttention.forEach((group, i) => {
      console.log(`${i + 1}. ${group.name}`);
      console.log(`   Issue: ${group.status === 'needs_framework' ? 'Needs operational framework' : 
                               group.status === 'partial' ? 'Partial migration/incomplete' :
                               'No extracted content or framework'}`);
      
      // Specific actions based on what's missing
      if (!group.extractedFile && !group.frameworkFile) {
        console.log(`   Action: Need to extract any existing content AND create framework`);
      } else if (!group.frameworkFile) {
        console.log(`   Action: Create operational framework based on extracted content`);
      } else if (group.status === 'partial') {
        console.log(`   Action: Complete migration and enhance framework`);
      }
      console.log();
    });
  }
  
  // Check for related files that might contain additional information
  console.log('🔍 CHECKING FOR RELATED FILES:\n');
  
  const allFiles = fs.readdirSync('.').filter(f => f.endsWith('.md'));
  const workingGroupKeywords = [
    'policy', 'political', 'auspol', 'federal', 'state', 
    'engagement', 'government', 'parliament', 'minister'
  ];
  
  let relatedFiles = [];
  allFiles.forEach(file => {
    const lowerFile = file.toLowerCase();
    if (workingGroupKeywords.some(keyword => lowerFile.includes(keyword)) && 
        !WORKING_GROUPS.some(g => g.extractedFile === file || g.frameworkFile === file)) {
      relatedFiles.push(file);
    }
  });
  
  if (relatedFiles.length > 0) {
    console.log('Found potentially related files:');
    relatedFiles.forEach(file => {
      const stats = analyzeFileContent(file);
      console.log(`   📄 ${file} (${stats.wordCount || 0} words)`);
    });
  } else {
    console.log('No additional related files found.');
  }
  
  return {
    totalGroups: WORKING_GROUPS.length,
    groupsWithContent,
    groupsWithFrameworks,
    totalWords: totalExtractedWords + totalFrameworkWords,
    needsAttention: needsAttention.length
  };
}

// Run assessment
assessWorkingGroups();