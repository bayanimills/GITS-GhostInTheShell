# RBA & Treasury Regulatory Tracking Directory

## Purpose
This directory contains materials related to ABIB's engagement with the Reserve Bank of Australia (RBA) and Treasury, Australia's two most important financial policy institutions. This includes working group coordination, policy development, regulatory submissions, and relationship management.

## Current Status
**⚠️ Partial Migration - Permissions Issue**
- **Main Page**: RBA & Treasury Working Group page exists but inaccessible for block extraction
- **Related Content**: Extracted from accessible related pages (ABIB x RBA, NSW Friends of Bitcoin → RBA)
- **Operational Framework**: Comprehensive framework created based on ABIB standards
- **Recent Activity**: Main page updated today (2026-03-13)

## Directory Structure
```
rba-treasury/
├── README.md (this file)
├── 2026-03-13_rba-treasury-working-group-context_v1.md      # Extracted content
├── 2026-03-13_rba-treasury-working-group-operational_v1.md  # Operational framework
├── working-group/                    # Working group coordination
│   └── [future: meeting-notes, membership, governance]
├── rba-engagement/                   # Reserve Bank of Australia
│   ├── digital-currency/             # CBDC research, Project Acacia
│   ├── payments-system/              # Surcharging, innovation, competition
│   ├── monetary-policy/              # Sound money advocacy
│   └── submissions/                  # Formal submissions to RBA
├── treasury-engagement/              # Treasury (Australian Government)
│   ├── digital-assets/               # Regulatory framework
│   ├── tax-policy/                   # Bitcoin taxation
│   ├── consumer-protection/          # User safeguards
│   └── submissions/                  # Formal submissions to Treasury
└── parliamentary/                    # Parliamentary engagement
    ├── friends-group/                # Friends of Bitcoin establishment
    ├── committee-engagement/         # Parliamentary committees
    └── events/                       # Parliamentary events
```

## Key Institutions

### Reserve Bank of Australia (RBA)
- **Role**: Australia's central bank, monetary policy, payments system
- **Mandate**: Currency stability, full employment, economic prosperity (Reserve Bank Act 1959)
- **Bitcoin Relevance**: Digital currency research, payments innovation, CBDC exploration
- **Key Contacts**: Payments Policy, Financial Stability, Digital Currency Research

### Treasury (Australian Government)
- **Role**: Economic policy, fiscal policy, financial system regulation
- **Mandate**: Economic prosperity, financial stability, consumer protection
- **Bitcoin Relevance**: Digital assets framework, tax policy, financial regulation
- **Key Contacts**: Digital Assets Policy, Tax Policy, Financial Services

## Extracted Content Summary

### From ABIB x RBA Page
- RBA's statutory duty and purpose
- Linked documents: RBA/Treasury Joint Paper on CBDC, Project Acacia
- 5-step workflow process for responses
- Previous activity: Standing Committee on Economics questions (2025-03)

### From NSW: Friends of Bitcoin → RBA
- Evening event at NSW Parliament
- Goal: Establish parliamentary "friends of bitcoin" group
- Target attendees: Policymakers, industry, community, RBA officials
- Includes presentations component

## Operational Framework

### Working Group Structure
- **Strategic Direction**: ABIB Leadership
- **Policy Development**: Working Group members
- **Engagement Execution**: Operational team
- **Monitoring & Reporting**: Abby (AI Operations)

### 5-Step Response Process
1. Identify Issue & Create Tracking Page
2. Collect Input & Documentation
3. Draft Response
4. Refine Through Review
5. Publish/Deliver

### Key Focus Areas
1. **RBA Digital Currency Research** - CBDC vs Bitcoin analysis
2. **Payments System Innovation** - Surcharging rules, competition
3. **Treasury Digital Assets Framework** - Regulatory consultation
4. **Tax Policy Reform** - Sensible Bitcoin taxation
5. **Parliamentary Engagement** - Friends group establishment

## Immediate Action Required

### Permission Resolution
1. **Access Request**: Update Notion integration permissions for main working group page
2. **Content Verification**: Complete extraction once accessible
3. **Database Migration**: Plan migration of any linked databases
4. **Deprecation Planning**: Notion page deprecation after full migration

### Operational Setup
1. **Monitoring System**: RBA/Treasury publication tracking
2. **Contact Database**: Relationship management system
3. **Calendar Integration**: Key dates and deadlines
4. **Template Development**: Submission and response templates

## File Naming Convention
All files follow ABIB operational standard:
`YYYY-MM-DD_source_topic_vX.ext`

Examples:
- `2026-03-13_rba-treasury-working-group-context_v1.md`
- `2026-03-13_rba-treasury-working-group-operational_v1.md`
- `2026-03-31_rba-surcharging-consultation_v1.md`

## Related Directories
- `../austrac/` - AUSTRAC regulatory tracking (already migrated)
- `../asic/` - ASIC regulatory tracking
- `../general/` - Cross-agency regulatory issues
- `../../02-education/rba-treasury/` - Educational materials for policymakers

## Strategic Importance
The RBA and Treasury collectively shape Australia's entire financial environment. Successful engagement with these institutions is critical for:
- Sensible Bitcoin regulation and policy
- Protection of Bitcoin industry from harmful rules
- Advancement of sound money principles
- Economic freedom and financial sovereignty

## Contact
- **Primary**: Abby (AI Operations & Strategy Lead)
- **Strategic**: Bayani Mills (CEO)
- **Policy Lead**: Daniel Wilczynski
- **Regulatory Engagement**: Elmo Stoop

## Version History
- **v1.0** (2026-03-13): Directory created, partial content migrated, operational framework established
- **Next Update**: Scheduled for 2026-03-20 (pending permission resolution)

---
**Last Updated**: 2026-03-13  
**Maintained By**: Abby - AI Operations & Strategy Lead  
**Review Cycle**: Weekly (until migration complete), then monthly  
**Status**: ⚠️ Partial migration, permissions issue requiring resolution