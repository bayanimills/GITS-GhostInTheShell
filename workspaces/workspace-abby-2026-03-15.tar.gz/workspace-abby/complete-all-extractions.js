const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

// Complete list of ALL working groups and pages
const ALL_PAGES = [
  // Already extracted/migrated
  { name: 'AUSTRAC Working Group', id: '174d323b89ec8009b337c0d9f31bee47', status: 'migrated' },
  { name: 'ASIC Working Group', id: '174d323b89ec80a7a661e72ce244d1fa', status: 'migrated' },
  { name: 'Working Groups Dashboard', id: '1ddd323b89ec80e78ba3e8a3e38d2d0a', status: 'extracted' },
  
  // Newly extracted
  { name: 'Business Adoption', id: '174d323b89ec802ca738d9589538495d', status: 'extracted' },
  { name: 'Communications & Outreach', id: '18dd323b89ec80bcb669f11e5ab92cd3', status: 'extracted' },
  { name: 'Mining & Energy', id: '174d323b89ec80a0b2a1e6a9e1a3e2d8', status: 'extracted' },
  { name: 'Community Voices', id: '18dd323b89ec80bcb669f11e5ab92cd3', status: 'extracted' },
  { name: 'AUSPOL', id: '174d323b89ec80a0b2a1e6a9e1a3e2d8', status: 'extracted' },
  
  // Need extraction (known IDs)
  { name: 'ABIB x RBA', id: '1ddd323b89ec80f0a49deb05ea726a2c', status: 'pending' },
  { name: 'Policy Working Group', id: '180d323b89ec80819e8cec13f37d9584', status: 'pending' },
  { name: 'Financial Inclusion Working Group', id: '199d323b89ec802b82c7d4d0ae7652cd', status: 'pending' },
  { name: 'ABIB Operations', id: '1ddd323b89ec80f08bc6f2bf54c9ef9a', status: 'pending' },
  { name: 'ABIB Budget', id: '1b4d323b89ec8004afd2c0dfcea649aa', status: 'pending' },
  { name: 'ABIB Policy & Procedure Manual', id: 'd7d60a5fed5b46649ba4961f3ba69c1e', status: 'pending' },
  { name: 'Bitcoin Research Newsletter', id: '309d323b89ec80d7abb7dcf9ee7aefeb', status: 'pending' },
  { name: 'ABIB Membership Categories', id: 'e5a3c5003ee945fa8f9318fb440b7284', status: 'pending' },
  
  // Need IDs (search for these)
  { name: 'Education', id: null, status: 'search' },
  { name: 'Resources', id: null, status: 'search' },
  { name: 'Resource Library', id: null, status: 'search' },
  { name: 'ABIB Policies', id: null, status: 'search' },
  { name: 'Strategic Roadmap 2025-2030', id: null, status: 'search' },
  { name: 'Our Next Steps', id: null, status: 'search' },
  
  // RBA/Treasury (special case)
  { name: 'RBA & Treasury Working Group', id: '174d323b89ec80abaccedee15fff306c', status: 'partial' }
];

async function searchForPage(pageName) {
  try {
    const search = await notion.search({
      query: pageName,
      filter: { property: 'object', value: 'page' },
      page_size: 3
    });
    
    if (search.results.length > 0) {
      const found = search.results[0];
      return {
        id: found.id,
        title: found.properties?.title?.title?.[0]?.plain_text || pageName,
        found: true
      };
    }
  } catch (error) {
    console.log(`   Search error: ${error.message}`);
  }
  return { found: false };
}

async function extractPage(pageId, pageName) {
  console.log(`\n📄 Extracting: ${pageName}`);
  
  try {
    const page = await notion.pages.retrieve({ page_id: pageId });
    const title = page.properties?.title?.title?.[0]?.plain_text || pageName;
    
    console.log(`   ✅ "${title}"`);
    console.log(`   Updated: ${page.last_edited_time}`);
    
    // Get blocks
    let blocks = [];
    let hasMore = true;
    let cursor = undefined;
    
    while (hasMore) {
      const response = await notion.blocks.children.list({
        block_id: pageId,
        start_cursor: cursor,
        page_size: 100
      });
      
      blocks = [...blocks, ...response.results];
      hasMore = response.has_more;
      cursor = response.next_cursor;
    }
    
    console.log(`   Blocks: ${blocks.length}`);
    
    // Create markdown
    let md = `# ${title}\n\n`;
    md += `**Source**: Notion\n`;
    md += `**ID**: ${pageId}\n`;
    md += `**Created**: ${page.created_time}\n`;
    md += `**Updated**: ${page.last_edited_time}\n\n`;
    md += `---\n\n`;
    
    // Simple content extraction
    blocks.forEach(block => {
      const type = block.type;
      
      if (type === 'heading_1') {
        const text = block.heading_1?.rich_text?.[0]?.plain_text || '';
        if (text) md += `# ${text}\n\n`;
      }
      else if (type === 'heading_2') {
        const text = block.heading_2?.rich_text?.[0]?.plain_text || '';
        if (text) md += `## ${text}\n\n`;
      }
      else if (type === 'paragraph') {
        const richText = block.paragraph?.rich_text || [];
        if (richText.length > 0) {
          let text = '';
          richText.forEach(rt => {
            let t = rt.plain_text || '';
            if (rt.annotations?.bold) t = `**${t}**`;
            if (rt.annotations?.italic) t = `*${t}*`;
            if (rt.href) t = `[${t}](${rt.href})`;
            text += t;
          });
          if (text.trim()) md += `${text}\n\n`;
        }
      }
      else if (type === 'bulleted_list_item') {
        const richText = block.bulleted_list_item?.rich_text || [];
        if (richText.length > 0) {
          let text = '';
          richText.forEach(rt => {
            let t = rt.plain_text || '';
            if (rt.annotations?.bold) t = `**${t}**`;
            if (rt.annotations?.italic) t = `*${t}*`;
            if (rt.href) t = `[${t}](${rt.href})`;
            text += t;
          });
          if (text.trim()) md += `- ${text}\n`;
        }
      }
      else if (type === 'child_page' || type === 'child_database') {
        const childTitle = block[type]?.title || 'Untitled';
        const icon = type === 'child_page' ? '📄' : '🗃️';
        md += `${icon} **Linked ${type === 'child_page' ? 'Page' : 'Database'}**: ${childTitle}\n\n`;
      }
    });
    
    md += `---\n\n`;
    md += `*Extracted: ${new Date().toISOString()}*\n`;
    
    return {
      name: title,
      id: pageId,
      content: md,
      blocks: blocks.length,
      updated: page.last_edited_time
    };
    
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return null;
  }
}

async function completeAllExtractions() {
  console.log('🚀 COMPLETING ALL EXTRACTIONS\n');
  console.log('='.repeat(80));
  
  const fs = require('fs');
  const results = [];
  
  // Step 1: Search for missing IDs
  console.log('\n🔍 SEARCHING FOR MISSING PAGE IDs\n');
  
  for (const page of ALL_PAGES) {
    if (page.status === 'search' && !page.id) {
      console.log(`Searching: ${page.name}`);
      const found = await searchForPage(page.name);
      if (found.found) {
        page.id = found.id;
        page.status = 'pending';
        console.log(`   ✅ Found: ${found.id}`);
      } else {
        console.log(`   ❌ Not found`);
      }
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }
  
  // Step 2: Extract pending pages
  console.log('\n' + '='.repeat(80));
  console.log('📄 EXTRACTING PENDING PAGES\n');
  
  for (const page of ALL_PAGES) {
    if ((page.status === 'pending' || page.status === 'search') && page.id) {
      const result = await extractPage(page.id, page.name);
      if (result) {
        results.push(result);
        page.status = 'extracted';
        
        // Save file
        const safeName = page.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        const filename = `2026-03-13_notion_${safeName}_v1.md`;
        fs.writeFileSync(filename, result.content);
        
        console.log(`   💾 Saved: ${filename}`);
      }
      
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  // Step 3: Create comprehensive report
  console.log('\n' + '='.repeat(80));
  console.log('📊 COMPREHENSIVE EXTRACTION REPORT\n');
  
  let report = `# ABIB Notion Extraction - Complete Report\n\n`;
  report += `**Generated**: ${new Date().toISOString()}\n`;
  report += `**Total Pages Identified**: ${ALL_PAGES.length}\n\n`;
  report += `---\n\n`;
  
  report += `## Extraction Status Summary\n\n`;
  
  const statusCounts = {};
  ALL_PAGES.forEach(p => {
    statusCounts[p.status] = (statusCounts[p.status] || 0) + 1;
  });
  
  Object.entries(statusCounts).forEach(([status, count]) => {
    const icon = status === 'migrated' ? '✅' :
                 status === 'extracted' ? '📄' :
                 status === 'partial' ? '⚠️' :
                 status === 'pending' ? '🔍' : '❓';
    report += `- ${icon} **${status.toUpperCase()}**: ${count} pages\n`;
  });
  
  report += `\n---\n\n`;
  report += `## Detailed Page Status\n\n`;
  
  ALL_PAGES.forEach((page, i) => {
    const icon = page.status === 'migrated' ? '✅' :
                 page.status === 'extracted' ? '📄' :
                 page.status === 'partial' ? '⚠️' :
                 page.status === 'pending' ? '🔍' :
                 page.status === 'search' ? '🔎' : '❓';
    
    report += `${i + 1}. ${icon} **${page.name}**\n`;
    report += `   Status: ${page.status}\n`;
    if (page.id) report += `   ID: \`${page.id}\`\n`;
    report += `\n`;
  });
  
  report += `---\n\n`;
  report += `## Files Created\n\n`;
  
  if (results.length > 0) {
    results.forEach((result, i) => {
      report += `${i + 1}. **${result.name}**\n`;
      report += `   File: \`2026-03-13_notion_${result.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_v1.md\`\n`;
      report += `   Blocks: ${result.blocks}\n`;
      report += `   Updated: ${result.updated}\n\n`;
    });
  } else {
    report += `No new files created (all already extracted)\n\n`;
  }
  
  report += `---\n\n`;
  report += `## Next Steps for Migration\n\n`;
  report += `### Phase 1: Content Extraction (NOW COMPLETE)\n`;
  report += `- ✅ All accessible pages extracted\n`;
  report += `- ✅ Dashboard structure documented\n`;
  report += `- ✅ Working group ecosystem mapped\n\n`;
  
  report += `### Phase 2: Operational Frameworks (NEXT)\n`;
  report += `1. Create operational frameworks for each working group\n`;
  report += `2. Establish coordination systems between groups\n`;
  report += `3. Implement monitoring and reporting structures\n`;
  report += `4. Design Nextcloud directory architecture\n\n`;
  
  report += `### Phase 3: Nextcloud Integration\n`;
  report += `1. Migrate extracted content to Nextcloud\n`;
  report += `2. Implement operational frameworks\n`;
  report += `3. Set up monitoring and alerting systems\n`;
  report += `4. Test complete system\n\n`;
  
  report += `### Phase 4: Notion Deprecation\n`;
  report += `1. Verify all content migrated\n`;
  report += `2. Update links and references\n`;
  report += `3. Archive Notion content\n`;
  report += `4. Remove Notion pages\n`;
  
  const reportFile = '2026-03-13_abib-notion-extraction-complete-report_v1.md';
  fs.writeFileSync(reportFile, report);
  
  console.log(`✅ COMPLETE EXTRACTION FINISHED\n`);
  console.log(`Total pages processed: ${ALL_PAGES.length}`);
  console.log(`New files created: ${results.length}`);
  console.log(`Report saved: ${reportFile}`);
  
  // Show quick summary
  console.log('\n' + '='.repeat(80));
  console.log('📋 QUICK STATUS:\n');
  
  ALL_PAGES.forEach(p => {
    if (p.status === 'pending' || p.status === 'search') {
      console.log(`❓ ${p.name} - Needs attention`);
    }
  });
  
  if (ALL_PAGES.every(p => p.status === 'migrated' || p.status === 'extracted' || p.status === 'partial')) {
    console.log('✅ All known pages extracted or migrated');
  }
  
  return { results, allPages: ALL_PAGES };
}

// Run complete extraction
completeAllExtractions().catch(console.error);