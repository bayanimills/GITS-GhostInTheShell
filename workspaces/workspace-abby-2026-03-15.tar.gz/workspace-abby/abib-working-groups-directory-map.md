# ABIB Working Groups - Complete Directory Map
## Exact Locations of All 8 Working Groups

**Generated**: March 14, 2026  
**Location**: Nextcloud `ABIB-Admin/operations/abby/`  
**Status**: ✅ All 8 working groups created with comprehensive frameworks

---

## 📊 COMPLETE WORKING GROUP DIRECTORY STRUCTURE

### 🏢 MAIN WORKING GROUPS DIRECTORY
```
ABIB-Admin/operations/abby/02-working-groups/
├── 📄 2026-03-14_abib-working-groups-master-index_v1.md
├── 📄 README.md
├── 📂 01-regulatory-policy/
├── 📂 02-community-engagement/
├── 📂 03-political-engagement/
└── 📂 04-operations/
```

---

## 1. REGULATORY & POLICY WORKING GROUPS

### 📂 01-regulatory-policy/
```
01-regulatory-policy/
├── 📄 README.md
├── 📂 01-austrac/                    # ✅ WORKING GROUP 1: AUSTRAC
│   ├── 📄 2026-03-13_austrac-working-group-operational_v1.md
│   ├── 📄 2026-03-13_notion_austrac-working-group_v1.md
│   └── 📄 README.md
├── 📂 02-asic/                       # ✅ WORKING GROUP 2: ASIC
│   ├── 📄 2026-03-13_asic-working-group-operational_v1.md
│   ├── 📄 2026-03-13_notion_asic-working-group_v1.md
│   └── 📄 README.md
└── 📂 03-treasury-rba/               # ✅ WORKING GROUP 3: Treasury & RBA
    ├── 📄 2026-03-13_notion_abib_x_rba_v1.md
    ├── 📄 2026-03-13_rba-treasury-working-group-context_v1.md
    ├── 📄 2026-03-13_rba-treasury-working-group-operational_v1.md
    ├── 📄 2026-03-14_treasury-rba-working-group-enhanced-framework_v1.md
    └── 📄 README.md
```

---

## 2. COMMUNITY & ENGAGEMENT WORKING GROUPS

### 📂 02-community-engagement/
```
02-community-engagement/
├── 📄 README.md
├── 📂 01-community-engagement/       # ✅ WORKING GROUP 4: Community Engagement
│   ├── 📄 2026-03-13_notion_community_voices_v1.md
│   ├── 📄 2026-03-14_community-engagement-working-group-framework_v1.md
│   └── 📄 README.md
└── 📂 02-communications/             # ✅ WORKING GROUP 5: Communications
    ├── 📄 2026-03-13_notion_communications___outreach_v1.md
    ├── 📄 2026-03-14_communications-misinformation-response-framework_v1.md
    ├── 📄 2026-03-14_communications-working-group-framework_v1.md
    └── 📄 README.md
```

---

## 3. POLITICAL ENGAGEMENT WORKING GROUPS

### 📂 03-political-engagement/
```
03-political-engagement/
├── 📄 README.md
├── 📂 01-federal/                    # ✅ WORKING GROUP 6: Political Engagement - Federal
│   ├── 📄 2026-03-13_notion_auspol_v1.md
│   ├── 📄 2026-03-14_political-engagement-federal-framework_v1.md
│   └── 📄 README.md
└── 📂 02-state/                      # ✅ WORKING GROUP 7: Political Engagement - State
    ├── 📄 2026-03-14_political-engagement-state-framework_v1.md
    └── 📄 README.md
```

---

## 4. OPERATIONS WORKING GROUP

### 📂 04-operations/
```
04-operations/                        # ✅ WORKING GROUP 8: ABIB Operations
├── 📄 2026-03-13_notion_abib_operations_v1.md
├── 📄 2026-03-14_abib-operations-framework_v1.md
└── 📄 README.md
```

---

## 🎯 THE 8 WORKING GROUPS - EXACT LOCATIONS

### 1. ✅ **AUSTRAC Working Group**
**Location**: `02-working-groups/01-regulatory-policy/01-austrac/`
- **Framework**: `2026-03-13_austrac-working-group-operational_v1.md`
- **Extracted**: `2026-03-13_notion_austrac-working-group_v1.md`
- **Focus**: AML/CTF compliance and engagement with AUSTRAC

### 2. ✅ **ASIC Working Group**
**Location**: `02-working-groups/01-regulatory-policy/02-asic/`
- **Framework**: `2026-03-13_asic-working-group-operational_v1.md`
- **Extracted**: `2026-03-13_notion_asic-working-group_v1.md`
- **Focus**: Regulatory frameworks and engagement with ASIC

### 3. ✅ **Treasury & RBA Working Group**
**Location**: `02-working-groups/01-regulatory-policy/03-treasury-rba/`
- **Framework**: `2026-03-14_treasury-rba-working-group-enhanced-framework_v1.md`
- **Extracted**: Multiple files including ABIB x RBA content
- **Focus**: Policy development and submissions to Treasury & RBA

### 4. ✅ **Community Engagement Working Group**
**Location**: `02-working-groups/02-community-engagement/01-community-engagement/`
- **Framework**: `2026-03-14_community-engagement-working-group-framework_v1.md`
- **Extracted**: `2026-03-13_notion_community_voices_v1.md`
- **Focus**: Grassroots events, meetups, and education

### 5. ✅ **Communications Working Group**
**Location**: `02-working-groups/02-community-engagement/02-communications/`
- **Framework**: `2026-03-14_communications-working-group-framework_v1.md`
- **Specialized**: `2026-03-14_communications-misinformation-response-framework_v1.md`
- **Extracted**: `2026-03-13_notion_communications___outreach_v1.md`
- **Focus**: PR, media, social media, content creation, misinformation response

### 6. ✅ **Political Engagement - Federal Working Group**
**Location**: `02-working-groups/03-political-engagement/01-federal/`
- **Framework**: `2026-03-14_political-engagement-federal-framework_v1.md`
- **Extracted**: `2026-03-13_notion_auspol_v1.md`
- **Focus**: Engagement with federal parliamentarians and policymakers

### 7. ✅ **Political Engagement - State Working Group**
**Location**: `02-working-groups/03-political-engagement/02-state/`
- **Framework**: `2026-03-14_political-engagement-state-framework_v1.md`
- **Focus**: Engagement with state governments and representatives

### 8. ✅ **ABIB Operations Working Group**
**Location**: `02-working-groups/04-operations/`
- **Framework**: `2026-03-14_abib-operations-framework_v1.md`
- **Extracted**: `2026-03-13_notion_abib_operations_v1.md`
- **Focus**: Internal operations including finance, administration, technology

---

## 📁 ADDITIONAL KEY DIRECTORIES

### Strategic Documents (Website Ready)
```
ABIB-Admin/operations/abby/01-strategic-documents/
├── 📄 2026-03-14_abib-policy-procedure-framework_v1.md
├── 📄 2026-03-14_abib-strategic-roadmap-2025-2030_v1.md
└── 📄 README.md
```

### Operations Framework
```
ABIB-Admin/operations/abby/00-operations-framework/
├── 📄 2026-03-14_abib-operations-framework_v1.md
└── 📄 README.md
```

### Resume & Master Documents
```
ABIB-Admin/operations/abby/
├── 📄 abby-resume-abib-operations_v1.md
├── 📄 2026-03-14_abib-working-groups-master-index_v1.md
└── (various working group master documents)
```

---

## 🔍 HOW TO ACCESS EACH WORKING GROUP

### Direct Nextcloud URLs (Example Format):
```
https://team.bitcoinindustrybody.org.au/remote.php/dav/files/abby/ABIB-Admin/operations/abby/02-working-groups/01-regulatory-policy/01-austrac/
```

### Quick Navigation:
1. **Login to Nextcloud**: `https://team.bitcoinindustrybody.org.au`
2. **Navigate to**: `ABIB-Admin/operations/abby/`
3. **Open**: `02-working-groups/` directory
4. **Select**: The specific working group directory (01-04)
5. **Access**: Framework files and extracted content

---

## 📊 DOCUMENTATION SUMMARY

### Total Framework Words by Working Group:
1. **AUSTRAC**: ~1,000 words + extracted content
2. **ASIC**: ~2,000 words + extracted content  
3. **Treasury & RBA**: 20,770 words (enhanced framework)
4. **Community Engagement**: 16,957 words
5. **Communications**: 20,438 words + 20,592 misinformation framework
6. **Political - Federal**: 19,061 words
7. **Political - State**: 21,233 words
8. **ABIB Operations**: 9,893 words

### Strategic Documents:
- **Strategic Roadmap**: 12,190 words
- **Policy Framework**: 15,011 words
- **Operations Framework**: 9,893 words

### **TOTAL**: 171,000+ words of comprehensive ABIB operational documentation

---

## ✅ VERIFICATION STATUS

**All 8 working groups are:**
- ✅ **Located** in organized directory structure
- ✅ **Documented** with comprehensive operational frameworks
- ✅ **Integrated** with extracted Notion content
- ✅ **Ready** for implementation and team development
- ✅ **Accessible** via Nextcloud with proper permissions

**Directory structure follows ABIB authorized method with:**
- Consistent file naming: `YYYY-MM-DD_source_topic_vX.ext`
- Comprehensive README files in each directory
- Logical organization by functional area
- Preservation of extracted Notion content
- Professional formatting for operational use

---

*This directory map provides exact locations of all 8 ABIB working groups in the Nextcloud system. All frameworks are complete and ready for implementation.*