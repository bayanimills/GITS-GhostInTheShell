const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function checkDatabase() {
  try {
    // Check the database that was created
    const dbId = '542499ed-648b-44f3-8120-fc232cf0bc78';
    const database = await notion.databases.retrieve({ database_id: dbId });
    
    console.log('Database Info:');
    console.log(`Title: ${database.title[0]?.plain_text || 'Untitled'}`);
    console.log(`ID: ${database.id}`);
    console.log('\nProperties:');
    
    Object.entries(database.properties).forEach(([key, prop]) => {
      console.log(`  ${key}: ${prop.type}`);
      if (prop.type === 'select' && prop.select.options) {
        console.log(`    Options: ${prop.select.options.map(o => o.name).join(', ')}`);
      }
    });
    
    // Try to add a page with correct properties
    const page = await notion.pages.create({
      parent: { database_id: dbId },
      properties: {
        'Name': { title: [{ text: { content: 'Test Policy Item' } }] }
      }
    });
    
    console.log('\n✅ Successfully added test page');
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

checkDatabase();