# RBA & Treasury Working Group - Related Content

**Note**: Main RBA & Treasury Working Group page not accessible for block extraction
**Last Updated**: 2026-03-13T12:27:49.711Z

---

## ABIB x RBA

**Page ID**: 1ddd323b-89ec-80f0-a49d-eb05ea726a2c
**Created**: 2025-04-22T02:22:00.000Z
**Last Updated**: 2025-04-22T02:45:00.000Z

> **Note**: “The Reserve Bank of Australia (RBA) is Australia's central bank and derives its functions and powers from the Reserve Bank Act 1959 . Its duty is **to contribute to the stability of the currency, full employment, and the economic prosperity and welfare of the Australian people**.”

# What does the RBA Do?

# Key Dates:

2025 -

> **Note**: **GOALS**

📄 **Linked Page**: RBA and Treasury Joint Paper on Central Bank Digital Currency and the Future of Digital Money in Australia

📄 **Linked Page**: Project Acacia

# Workflow:

1. Prioritised List of Concerns as Pages - Documents, questions, etc
1. Comments to be left in relevant pages
1. Response Drafted
1. Response Refined
1. Response sent to Communications for Publication
### Previous Activities:

📄 **Linked Page**: 2025-03 - Standing Committee on Economics - RBA Questions

---

## NSW: Friends of Bitcoin → RBA

**Page ID**: 215d323b-89ec-80e8-aa9b-ffa6132c34e3
**Created**: 2025-06-17T09:19:00.000Z
**Last Updated**: 2025-06-17T09:34:00.000Z

Evening Event NSW Parliament

Seek to establish friends of bitcoin

Create event with policymakers and industry / IREN, Exchanges, Meetup organisers/Community / Hardware - FrostSnap

Invite RBA/

Invite Federal Senators / Departments


Presentations:

---

## ASIC Working Group

**Page ID**: 174d323b-89ec-80a7-a661-e72ce244d1fa
**Created**: 2025-01-07T03:27:00.000Z
**Last Updated**: 2025-04-22T04:16:00.000Z

📄 **Linked Page**: INFO 225 - Digital Assets: Financial Products & Services

📄 **Linked Page**: RG 133 - Funds management and custodial services: Holding assets

---

## RBA & Treasury Working Group Context

### Reserve Bank of Australia (RBA)
- **Role**: Australia's central bank, monetary policy, payments system
- **Bitcoin Relevance**: Digital currency research, payments innovation, CBDC exploration
- **Key Areas**: Surcharging rules, payment system regulation, digital currency policy

### Treasury (Australian Government)
- **Role**: Economic policy, fiscal policy, financial system regulation
- **Bitcoin Relevance**: Digital assets framework, tax policy, financial regulation
- **Key Areas**: Digital assets regulation, tax treatment, consumer protection

### Working Group Purpose
- Coordinate ABIB engagement with RBA and Treasury
- Develop policy positions on digital currency issues
- Prepare submissions and responses to consultations
- Build relationships with key policymakers

### Recent Developments (2025-2026)
1. **RBA Digital Currency Research** - Ongoing exploration of CBDC
2. **Treasury Digital Assets Framework** - Regulatory consultation
3. **Payment System Reforms** - Surcharging and innovation
4. **Tax Treatment Clarification** - Bitcoin and digital assets

---

## Migration Information

### Source Details
- **Primary Page**: RBA & Treasury Working Group (inaccessible)
- **Related Pages**: ABIB x RBA, NSW Friends of Bitcoin → RBA, ASIC Working Group
- **Extracted**: 2026-03-13T12:27:53.147Z

### Migration Status
- ✅ Related content extracted where accessible
- ⚠️ Main working group page requires permission update
- 🔄 Contextual information added based on ABIB operations

### Nextcloud Path
`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/rba-treasury/`
