# AUSTRAC Regulatory Tracking Directory

## Purpose
This directory contains all materials related to ABIB's engagement with the Australian Transaction Reports and Analysis Centre (AUSTRAC), including working group participation, regulatory compliance tracking, and advocacy materials.

## Directory Structure
```
austrac/
├── README.md (this file)
├── working-group/                    # AUSTRAC Industry Working Group
│   ├── 2026-03-13_notion_austrac-working-group_v1.md (raw extraction)
│   ├── 2026-03-13_austrac-working-group-operational_v1.md
│   └── [future: meeting-notes, correspondence, etc.]
├── regulations/                      # AML/CTF regulations tracking
│   └── [future: rule-changes, guidance, compliance]
├── submissions/                      # Formal submissions to AUSTRAC
│   └── [future: consultation-responses, position-papers]
└── compliance/                       # Industry compliance support
    └── [future: guides, templates, best-practices]
```

## Current Status

### ✅ Completed
1. **Notion Migration** - AUSTRAC Working Group page extracted and migrated
2. **Operational Foundation** - Directory structure established
3. **Content Preservation** - Original Notion content preserved in markdown

### ⚠️ Pending Migration
1. **AUSTRAC Personnel Database** - Working group contacts
2. **AUSTRAC Meetings Database** - Meeting schedules and notes
3. **AUSTRAC Engagement Database** - Correspondence and action items

### 📅 Upcoming Deadlines
- **2026-03-31** - Travel / Value Transfer Rule implementation
- **2026-12** - International Funds Transfer (IFT) Reporting

## File Naming Convention
All files follow ABIB operational standard:
`YYYY-MM-DD_source_topic_vX.ext`

Examples:
- `2026-03-13_notion_austrac-working-group_v1.md`
- `2026-03-13_austrac-working-group-operational_v1.md`
- `2026-03-31_au-travel-rule-implementation_v1.md`

## Confidentiality Notice
⚠️ **IMPORTANT**: Information in this directory may fall under Non-Disclosure Agreements (NDAs) with AUSTRAC and industry partners. Handle with appropriate confidentiality.

## Operational Workflow

### Monitoring
1. Daily check of AUSTRAC website for updates
2. Weekly review of regulatory developments
3. Monthly working group coordination

### Response Process
1. Identify regulatory concern or consultation
2. Create dedicated tracking page
3. Collect working group input
4. Draft response
5. Review and refine
6. Submit through appropriate channels

### Relationship Management
1. Maintain contact database of AUSTRAC personnel
2. Track meeting schedules and outcomes
3. Document correspondence and commitments
4. Regular relationship assessment

## Related Directories
- `../asic/` - ASIC regulatory tracking
- `../treasury/` - Treasury policy engagement
- `../rba/` - Reserve Bank of Australia engagement
- `../general/` - Cross-agency regulatory issues

## Contact
- **Primary**: Abby (AI Operations & Strategy Lead)
- **Backup**: Bayani Mills (CEO)
- **Legal/Compliance**: [To be assigned]

## Version History
- **v1.0** (2026-03-13): Directory created, Notion content migrated
- **Next Update**: Scheduled for 2026-04-13

---
**Last Updated**: 2026-03-13  
**Maintained By**: Abby - AI Operations & Strategy Lead  
**Review Cycle**: Monthly