# Policy Working Group

**Source**: Notion
**ID**: 180d323b89ec80819e8cec13f37d9584
**Created**: 2025-01-19T06:49:00.000Z
**Updated**: 2025-05-06T08:09:00.000Z

---

📄 **Linked Page**: ABIB Policy Proposals

“Qualifying Digital Assets” = set by market cap?, exclude privately issued assets, etc, exclude assets that involve a pre-mine,  

📄 **Linked Page**: Position Statements - Confirm Process

## Position Statements

📄 **Linked Page**: Position Statement Development Guides

📄 **Linked Page**: Position Statement: FATF (DRAFT)

---

*Extracted: 2026-03-13T13:31:58.322Z*
