# AUSPOL

**Source**: Notion page
**Page ID**: 1ddd323b-89ec-8028-bea4-cca85ad8ae1e
**Created**: 2025-04-22T02:20:00.000Z
**Last Updated**: 2025-06-03T08:55:00.000Z

---

Seek Clarity - Safe Play

- Protect Consumers by ensuring clarity and distinctions.
SA Sarah - Men’s Mental health / 

Previous Activities:

2022 Political Poll - [https://bitcoinindustrybody.org.au/2022-political-poll-results/](https://bitcoinindustrybody.org.au/2022-political-poll-results/)

Federal Working Group:

📄 **Linked Page**: Unrealised Gains Tax e-Petition

**State Working Groups:**

📄 **Linked Page**: Queensland

📄 **Linked Page**: Western Australia

📄 **Linked Page**: South Australia

📄 **Linked Page**: Northern Territory

📄 **Linked Page**: New South Wales

---

## Migration Status
- **Extracted**: 2026-03-13T13:23:31.381Z
- **By**: Abby (AI Operations & Strategy Lead)
- **Destination**: Nextcloud working groups system
