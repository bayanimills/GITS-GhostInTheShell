const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function extractWorkingGroupsDashboard() {
  console.log('Extracting Working Groups Dashboard...\n');
  
  const pageId = '1ddd323b89ec80e78ba3e8a3e38d2d0a';
  
  try {
    // Get page
    const page = await notion.pages.retrieve({ page_id: pageId });
    const title = page.properties?.title?.title?.[0]?.plain_text || 'Working Groups Dashboard';
    
    console.log(`Title: ${title}`);
    console.log(`Created: ${page.created_time}`);
    console.log(`Last edited: ${page.last_edited_time}`);
    
    // Get blocks
    const blocks = await notion.blocks.children.list({
      block_id: pageId,
      page_size: 100
    });
    
    console.log(`\nFound ${blocks.results.length} blocks`);
    
    // Process content
    let markdown = `# ${title}\n\n`;
    markdown += `**Source**: Notion Working Groups Dashboard\n`;
    markdown += `**Page ID**: ${pageId}\n`;
    markdown += `**Created**: ${page.created_time}\n`;
    markdown += `**Last Updated**: ${page.last_edited_time}\n\n`;
    markdown += `---\n\n`;
    
    blocks.results.forEach(block => {
      const type = block.type;
      
      if (type === 'heading_1') {
        const text = block.heading_1?.rich_text?.[0]?.plain_text || '';
        if (text) markdown += `# ${text}\n\n`;
      } 
      else if (type === 'heading_2') {
        const text = block.heading_2?.rich_text?.[0]?.plain_text || '';
        if (text) markdown += `## ${text}\n\n`;
      }
      else if (type === 'paragraph') {
        const richText = block.paragraph?.rich_text || [];
        if (richText.length > 0) {
          let text = '';
          richText.forEach(rt => {
            let t = rt.plain_text || '';
            if (rt.annotations?.bold) t = `**${t}**`;
            if (rt.annotations?.italic) t = `*${t}*`;
            if (rt.href) t = `[${t}](${rt.href})`;
            text += t;
          });
          if (text.trim()) markdown += `${text}\n\n`;
        }
      }
      else if (type === 'bulleted_list_item') {
        const richText = block.bulleted_list_item?.rich_text || [];
        if (richText.length > 0) {
          let text = '';
          richText.forEach(rt => {
            let t = rt.plain_text || '';
            if (rt.annotations?.bold) t = `**${t}**`;
            if (rt.annotations?.italic) t = `*${t}*`;
            if (rt.href) t = `[${t}](${rt.href})`;
            text += t;
          });
          if (text.trim()) markdown += `- ${text}\n`;
        }
      }
      else if (type === 'child_page') {
        const childTitle = block.child_page?.title || 'Untitled';
        markdown += `📄 **Linked Page**: ${childTitle}\n\n`;
      }
      else if (type === 'child_database') {
        const dbTitle = block.child_database?.title || 'Untitled Database';
        markdown += `🗃️ **Linked Database**: ${dbTitle}\n\n`;
      }
    });
    
    // Add migration context
    markdown += `---\n\n`;
    markdown += `## Migration Context\n\n`;
    markdown += `This dashboard has been superseded by the Nextcloud regulatory tracking system:\n\n`;
    markdown += `### Migrated Working Groups\n`;
    markdown += `1. **AUSTRAC Working Group** - Complete migration to Nextcloud\n`;
    markdown += `2. **RBA & Treasury Working Group** - Framework created, partial migration\n`;
    markdown += `3. **ASIC Working Group** - Complete migration to Nextcloud\n\n`;
    
    markdown += `### Nextcloud Location\n`;
    markdown += `\`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/\`\n\n`;
    
    markdown += `### Status\n`;
    markdown += `- ✅ Operational frameworks established\n`;
    markdown += `- ✅ Directory structure created\n`;
    markdown += `- ✅ Documentation complete\n`;
    markdown += `- 🔄 Notion deprecation in progress\n`;
    
    console.log(`✅ Extraction complete`);
    
    return {
      title,
      content: markdown,
      blockCount: blocks.results.length
    };
    
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return null;
  }
}

// Run extraction
extractWorkingGroupsDashboard().then(result => {
  if (result) {
    const fs = require('fs');
    const filename = `2026-03-13_notion_working-groups-dashboard_v1.md`;
    fs.writeFileSync(filename, result.content);
    
    console.log(`\n💾 Saved to: ${filename}`);
    console.log(`Blocks: ${result.blockCount}`);
    
    console.log('\n📄 Preview:');
    console.log('='.repeat(50));
    console.log(result.content.substring(0, 800) + '...');
  }
});