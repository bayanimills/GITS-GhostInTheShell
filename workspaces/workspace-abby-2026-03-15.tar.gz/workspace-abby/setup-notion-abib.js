const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function setupABIBOperations() {
  console.log('Setting up ABIB Operations in Notion...\n');
  
  try {
    // First, let's find the main ABIB Operations page
    const searchResponse = await notion.search({
      query: 'ABIB Operations',
      filter: {
        property: 'object',
        value: 'page'
      }
    });
    
    let abibOperationsPage = searchResponse.results.find(page => 
      page.properties?.title?.title?.[0]?.plain_text === 'ABIB Operations' ||
      (page.properties?.Name?.title?.[0]?.plain_text === 'ABIB Operations')
    );
    
    if (!abibOperationsPage) {
      console.log('ABIB Operations page not found, searching for any ABIB page...');
      // Use the first ABIB page found
      abibOperationsPage = searchResponse.results[0];
    }
    
    if (abibOperationsPage) {
      console.log(`Found ABIB Operations page: "${abibOperationsPage.properties?.title?.title?.[0]?.plain_text || 'Untitled'}"`);
      console.log(`Page ID: ${abibOperationsPage.id}`);
      
      // Create Abby's operational dashboard under this page
      console.log('\n--- Creating Abby\'s Operational Dashboard ---\n');
      
      const abbyDashboard = await notion.pages.create({
        parent: {
          type: 'page_id',
          page_id: abibOperationsPage.id
        },
        properties: {
          title: {
            title: [
              {
                type: 'text',
                text: {
                  content: 'Abby - AI Operations & Strategy Lead'
                }
              }
            ]
          }
        },
        children: [
          {
            object: 'block',
            type: 'heading_1',
            heading_1: {
              rich_text: [{ type: 'text', text: { content: 'ABIB AI Operations Dashboard' } }],
              color: 'blue'
            }
          },
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Operational dashboard for Abby, AI Operations & Strategy Lead for the Australian Bitcoin Industry Body. Focused on advancing Bitcoin adoption, education, and policy in Australia.'
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'callout',
            callout: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: '🇦🇺⚡ Mission: Advance Bitcoin in Australia through evidence-based policy advocacy, targeted education, comprehensive research, and operational excellence.'
                  }
                }
              ],
              icon: {
                emoji: '⚡'
              },
              color: 'yellow_background'
            }
          },
          {
            object: 'block',
            type: 'heading_2',
            heading_2: {
              rich_text: [{ type: 'text', text: { content: 'Operational Structure' } }]
            }
          },
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Linked with Nextcloud workspace at: '
                  }
                },
                {
                  type: 'text',
                  text: {
                    content: 'ABIB-Admin/operations/abby/',
                    annotations: {
                      code: true
                    }
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'heading_3',
            heading_3: {
              rich_text: [{ type: 'text', text: { content: '1. Policy Operations' } }],
              color: 'green'
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Regulatory monitoring (ASIC, AUSTRAC, Treasury, RBA, APRA)' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Policy submission development and tracking' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Consultation response management' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'heading_3',
            heading_3: {
              rich_text: [{ type: 'text', text: { content: '2. Education Operations' } }],
              color: 'blue'
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Target audiences: Policy Makers, Media, General Public' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Content development and distribution' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Media engagement and relationship building' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'heading_3',
            heading_3: {
              rich_text: [{ type: 'text', text: { content: '3. Research Operations' } }],
              color: 'purple'
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Australian Bitcoin ecosystem mapping' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Adoption metrics and trend analysis' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Economic impact assessment' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'heading_3',
            heading_3: {
              rich_text: [{ type: 'text', text: { content: '4. General Operations' } }],
              color: 'orange'
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Monitoring and reporting systems' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Workflow optimization and automation' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: { content: 'Integration management (Nextcloud, API, etc.)' }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'heading_2',
            heading_2: {
              rich_text: [{ type: 'text', text: { content: 'Integration Status' } }]
            }
          },
          {
            object: 'block',
            type: 'to_do',
            to_do: {
              rich_text: [{ type: 'text', text: { content: 'Nextcloud Workspace' } }],
              checked: true,
              color: 'green'
            }
          },
          {
            object: 'block',
            type: 'to_do',
            to_do: {
              rich_text: [{ type: 'text', text: { content: 'ABIB API (Public Endpoints)' } }],
              checked: true,
              color: 'green'
            }
          },
          {
            object: 'block',
            type: 'to_do',
            to_do: {
              rich_text: [{ type: 'text', text: { content: 'Notion Integration' } }],
              checked: true,
              color: 'green'
            }
          },
          {
            object: 'block',
            type: 'to_do',
            to_do: {
              rich_text: [{ type: 'text', text: { content: 'ABIB API (Authenticated)' } }],
              checked: false,
              color: 'yellow'
            }
          },
          {
            object: 'block',
            type: 'heading_2',
            heading_2: {
              rich_text: [{ type: 'text', text: { content: 'Quick Links' } }]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'ABIB Website: ',
                    link: { url: 'https://www.bitcoinindustrybody.org.au' }
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'ABIB API Documentation: ',
                    link: { url: 'https://bitcoinindustrybody.org.au/api/docs' }
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Nextcloud Access: ',
                    link: { url: 'https://team.bitcoinindustrybody.org.au' }
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'heading_2',
            heading_2: {
              rich_text: [{ type: 'text', text: { content: 'Last Updated' } }]
            }
          },
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: new Date().toISOString().split('T')[0]
                  },
                  annotations: {
                    bold: true
                  }
                },
                {
                  type: 'text',
                  text: {
                    content: ' - Initial setup complete. Operational foundation established.'
                  }
                }
              ]
            }
          }
        ]
      });
      
      console.log('✅ Successfully created Abby\'s Operational Dashboard!');
      console.log(`Dashboard URL: https://www.notion.so/${abbyDashboard.id.replace(/-/g, '')}`);
      
      // Now create databases for tracking
      console.log('\n--- Creating Operational Databases ---\n');
      
      // 1. Policy Tracking Database
      const policyDb = await notion.databases.create({
        parent: {
          type: 'page_id',
          page_id: abbyDashboard.id
        },
        title: [
          {
            type: 'text',
            text: {
              content: 'Policy Tracking'
            }
          }
        ],
        properties: {
          'Policy Area': {
            title: {}
          },
          'Agency': {
            select: {
              options: [
                { name: 'ASIC', color: 'blue' },
                { name: 'AUSTRAC', color: 'green' },
                { name: 'Treasury', color: 'purple' },
                { name: 'RBA', color: 'red' },
                { name: 'APRA', color: 'orange' },
                { name: 'Other', color: 'gray' }
              ]
            }
          },
          'Status': {
            select: {
              options: [
                { name: 'Monitoring', color: 'yellow' },
                { name: 'Consultation Open', color: 'blue' },
                { name: 'Submission in Progress', color: 'orange' },
                { name: 'Submitted', color: 'green' },
                { name: 'Closed', color: 'gray' }
              ]
            }
          },
          'Deadline': {
            date: {}
          },
          'Priority': {
            select: {
              options: [
                { name: 'High', color: 'red' },
                { name: 'Medium', color: 'yellow' },
                { name: 'Low', color: 'green' }
              ]
            }
          },
          'ABIB Contact': {
            rich_text: {}
          },
          'Next Action': {
            rich_text: {}
          }
        }
      });
      
      console.log('✅ Created Policy Tracking Database');
      
      // 2. Media Engagement Database
      const mediaDb = await notion.databases.create({
        parent: {
          type: 'page_id',
          page_id: abbyDashboard.id
        },
        title: [
          {
            type: 'text',
            text: {
              content: 'Media Engagement'
            }
          }
        ],
        properties: {
          'Outlet': {
            title: {}
          },
          'Contact': {
            rich_text: {}
          },
          'Type': {
            select: {
              options: [
                { name: 'Financial', color: 'green' },
                { name: 'Technology', color: 'blue' },
                { name: 'General News', color: 'red' },
                { name: 'Industry', color: 'purple' }
              ]
            }
          },
          'Relationship Status': {
            select: {
              options: [
                { name: 'Initial Contact', color: 'yellow' },
                { name: 'Building', color: 'blue' },
                { name: 'Established', color: 'green' },
                { name: 'Partnership', color: 'purple' }
              ]
            }
          },
          'Last Contact': {
            date: {}
          },
          'Next Action': {
            rich_text: {}
          },
          'Notes': {
            rich_text: {}
          }
        }
      });
      
      console.log('✅ Created Media Engagement Database');
      
      // 3. Educational Content Database
      const educationDb = await notion.databases.create({
        parent: {
          type: 'page_id',
          page_id: abbyDashboard.id
        },
        title: [
          {
            type: 'text',
            text: {
              content: 'Educational Content'
            }
          }
        ],
        properties: {
          'Title': {
            title: {}
          },
          'Audience': {
            multi_select: {
              options: [
                { name: 'Policy Makers', color: 'blue' },
                { name: 'Media', color: 'green' },
                { name: 'General Public', color: 'red' }
              ]
            }
          },
          'Format': {
            select: {
              options: [
                { name: 'Guide', color: 'blue' },
                { name: 'Report', color: 'green' },
                { name: 'Infographic', color: 'yellow' },
                { name: 'Video', color: 'red' },
                { name: 'Presentation', color: 'purple' }
              ]
            }
          },
          'Status': {
            select: {
              options: [
                { name: 'Planned', color: 'gray' },
                { name: 'In Progress', color: 'yellow' },
                { name: 'Review', color: 'orange' },
                { name: 'Published', color: 'green' },
                { name: 'Archived', color: 'brown' }
              ]
            }
          },
          'Due Date': {
            date: {}
          },
          'Nextcloud Path': {
            rich_text: {}
          },
          'Notes': {
            rich_text: {}
          }
        }
      });
      
      console.log('✅ Created Educational Content Database');
      
      // Add database links to the dashboard
      await notion.blocks.children.append({
        block_id: abbyDashboard.id,
        children: [
          {
            object: 'block',
            type: 'heading_2',
            heading_2: {
              rich_text: [{ type: 'text', text: { content: 'Operational Databases' } }]
            }
          },
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Three databases have been created for operational tracking:'
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Policy Tracking - Monitor regulatory developments and submissions'
                  },
                  annotations: {
                    bold: true
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Media Engagement - Track media relationships and coverage'
                  },
                  annotations: {
                    bold: true
                  }
                }
              ]
            }
          },
          {
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: 'Educational Content - Manage content development and distribution'
                  },
                  annotations: {
                    bold: true
                  }
                }
              ]
            }
          }
        ]
      });
      

      console.log('\n🎉 ABIB Notion Operations Setup Complete!');
      console.log('==========================================');
      console.log(`1. Dashboard: https://www.notion.so/${abbyDashboard.id.replace(/-/g, '')}`);
      console.log(`2. Policy Database: ${policyDb.id}`);
      console.log(`3. Media Database: ${mediaDb.id}`);
      console.log(`4. Education Database: ${educationDb.id}`);
      console.log('\nReady for operational use!');
      
      return {
        dashboard: abbyDashboard,
        databases: {
          policy: policyDb,
          media: mediaDb,
          education: educationDb
        }
      };
      
    } else {
      console.log('Could not find suitable ABIB page to use as parent.');
      return null;
    }
    
  } catch (error) {
    console.error('Error setting up ABIB operations in Notion:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
    return null;
  }
}

// Run the setup
setupABIBOperations().then(result => {
  if (result) {
    console.log('\n✅ Setup completed successfully!');
  } else {
    console.log('\n❌ Setup failed or incomplete.');
  }
});
