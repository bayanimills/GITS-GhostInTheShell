# Financial Inclusion Working Group

**Source**: Notion
**ID**: 199d323b89ec802b82c7d4d0ae7652cd
**Created**: 2025-02-13T20:44:00.000Z
**Updated**: 2025-04-22T08:46:00.000Z

---

---

*Extracted: 2026-03-13T13:31:59.482Z*
