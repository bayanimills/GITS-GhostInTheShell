const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function exploreABIBNotion() {
  console.log('🔍 Exploring ABIB Notion Workspace\n');
  console.log('='.repeat(80));
  
  try {
    // Get workspace users
    console.log('\n👥 WORKSPACE USERS:');
    const users = await notion.users.list({});
    console.log(`Total users: ${users.results.length}`);
    users.results.forEach((user, i) => {
      const type = user.type === 'bot' ? '🤖' : '👤';
      console.log(`${type} ${user.name || 'Unknown'} (${user.type})`);
    });
    
    // Search for all ABIB pages
    console.log('\n📄 SEARCHING FOR ABIB CONTENT:');
    const searchResponse = await notion.search({
      query: 'ABIB Bitcoin',
      filter: {
        property: 'object',
        value: 'page'
      },
      sort: {
        direction: 'descending',
        timestamp: 'last_edited_time'
      },
      page_size: 50
    });
    
    console.log(`Found ${searchResponse.results.length} pages total`);
    
    // Group pages by likely categories
    const categories = {
      operations: [],
      policy: [],
      research: [],
      membership: [],
      events: [],
      other: []
    };
    
    searchResponse.results.forEach(page => {
      const title = page.properties?.title?.title?.[0]?.plain_text || 
                   page.properties?.Name?.title?.[0]?.plain_text ||
                   'Untitled';
      
      const lowerTitle = title.toLowerCase();
      
      if (lowerTitle.includes('operation') || lowerTitle.includes('budget') || lowerTitle.includes('manual')) {
        categories.operations.push({ title, id: page.id, lastEdited: page.last_edited_time });
      } else if (lowerTitle.includes('policy') || lowerTitle.includes('rba') || lowerTitle.includes('submission')) {
        categories.policy.push({ title, id: page.id, lastEdited: page.last_edited_time });
      } else if (lowerTitle.includes('research') || lowerTitle.includes('newsletter')) {
        categories.research.push({ title, id: page.id, lastEdited: page.last_edited_time });
      } else if (lowerTitle.includes('member') || lowerTitle.includes('category')) {
        categories.membership.push({ title, id: page.id, lastEdited: page.last_edited_time });
      } else if (lowerTitle.includes('event') || lowerTitle.includes('day') || lowerTitle.includes('award')) {
        categories.events.push({ title, id: page.id, lastEdited: page.last_edited_time });
      } else {
        categories.other.push({ title, id: page.id, lastEdited: page.last_edited_time });
      }
    });
    
    // Display by category
    console.log('\n📁 CATEGORIZED CONTENT:');
    
    console.log('\n🏢 OPERATIONS:');
    categories.operations.forEach(item => {
      console.log(`  • ${item.title} (${new Date(item.lastEdited).toLocaleDateString()})`);
      console.log(`    https://www.notion.so/${item.id.replace(/-/g, '')}`);
    });
    
    console.log('\n⚖️ POLICY:');
    categories.policy.forEach(item => {
      console.log(`  • ${item.title} (${new Date(item.lastEdited).toLocaleDateString()})`);
      console.log(`    https://www.notion.so/${item.id.replace(/-/g, '')}`);
    });
    
    console.log('\n🔬 RESEARCH:');
    categories.research.forEach(item => {
      console.log(`  • ${item.title} (${new Date(item.lastEdited).toLocaleDateString()})`);
      console.log(`    https://www.notion.so/${item.id.replace(/-/g, '')}`);
    });
    
    console.log('\n👥 MEMBERSHIP:');
    categories.membership.forEach(item => {
      console.log(`  • ${item.title} (${new Date(item.lastEdited).toLocaleDateString()})`);
      console.log(`    https://www.notion.so/${item.id.replace(/-/g, '')}`);
    });
    
    console.log('\n🎉 EVENTS & AWARDS:');
    categories.events.forEach(item => {
      console.log(`  • ${item.title} (${new Date(item.lastEdited).toLocaleDateString()})`);
      console.log(`    https://www.notion.so/${item.id.replace(/-/g, '')}`);
    });
    
    console.log('\n📝 OTHER PAGES:');
    categories.other.slice(0, 10).forEach(item => {
      console.log(`  • ${item.title} (${new Date(item.lastEdited).toLocaleDateString()})`);
      console.log(`    https://www.notion.so/${item.id.replace(/-/g, '')}`);
    });
    
    if (categories.other.length > 10) {
      console.log(`  ... and ${categories.other.length - 10} more pages`);
    }
    
    // Let's examine the ABIB Operations page in detail
    console.log('\n🔎 EXAMINING ABIB OPERATIONS PAGE:');
    const abibOpsPage = categories.operations.find(p => p.title.includes('ABIB Operations'));
    
    if (abibOpsPage) {
      console.log(`\nFetching details for: ${abibOpsPage.title}`);
      
      // Get page content
      const blocks = await notion.blocks.children.list({
        block_id: abibOpsPage.id,
        page_size: 100
      });
      
      console.log(`\nPage has ${blocks.results.length} blocks`);
      
      // Extract text content
      let pageContent = '';
      blocks.results.forEach(block => {
        if (block.type === 'heading_1' || block.type === 'heading_2' || block.type === 'heading_3') {
          const text = block[block.type]?.rich_text?.[0]?.plain_text || '';
          if (text) {
            const prefix = block.type === 'heading_1' ? '# ' : block.type === 'heading_2' ? '## ' : '### ';
            pageContent += `\n${prefix}${text}\n`;
          }
        } else if (block.type === 'paragraph') {
          const text = block.paragraph?.rich_text?.[0]?.plain_text || '';
          if (text) pageContent += `${text}\n`;
        } else if (block.type === 'bulleted_list_item') {
          const text = block.bulleted_list_item?.rich_text?.[0]?.plain_text || '';
          if (text) pageContent += `• ${text}\n`;
        } else if (block.type === 'numbered_list_item') {
          const text = block.numbered_list_item?.rich_text?.[0]?.plain_text || '';
          if (text) pageContent += `1. ${text}\n`;
        }
      });
      
      console.log('\n📋 PAGE CONTENT SUMMARY:');
      console.log(pageContent.substring(0, 1000) + (pageContent.length > 1000 ? '...' : ''));
      
      // Check for child pages/databases
      console.log('\n🔗 CHILD PAGES/DATABASES:');
      const childBlocks = blocks.results.filter(block => 
        block.type === 'child_page' || block.type === 'child_database'
      );
      
      if (childBlocks.length > 0) {
        childBlocks.forEach((block, i) => {
          const type = block.type === 'child_page' ? '📄 Page' : '🗃️ Database';
          const title = block[block.type]?.title || 'Untitled';
          console.log(`${i + 1}. ${type}: ${title}`);
        });
      } else {
        console.log('No child pages or databases found');
      }
    }
    
    // Check for databases
    console.log('\n🗃️ SEARCHING FOR DATABASES:');
    const dbSearch = await notion.search({
      filter: {
        property: 'object',
        value: 'database'
      },
      page_size: 20
    });
    
    console.log(`Found ${dbSearch.results.length} databases`);
    
    if (dbSearch.results.length > 0) {
      console.log('\nTop databases:');
      dbSearch.results.slice(0, 10).forEach((db, i) => {
        const title = db.title?.[0]?.plain_text || 'Untitled Database';
        console.log(`${i + 1}. ${title} (${db.id})`);
        
        // Try to get some info about the database
        if (i < 3) { // Limit to first 3 to avoid rate limiting
          setTimeout(async () => {
            try {
              const dbInfo = await notion.databases.retrieve({ database_id: db.id });
              console.log(`   Properties: ${Object.keys(dbInfo.properties).join(', ')}`);
            } catch (err) {
              // Skip if we can't access
            }
          }, i * 1000);
        }
      });
    }
    
    // Check my Abby dashboard
    console.log('\n👩‍💼 CHECKING ABBY DASHBOARD:');
    const abbyPage = searchResponse.results.find(p => 
      p.properties?.title?.title?.[0]?.plain_text?.includes('Abby') ||
      p.properties?.Name?.title?.[0]?.plain_text?.includes('Abby')
    );
    
    if (abbyPage) {
      const title = abbyPage.properties?.title?.title?.[0]?.plain_text || 
                   abbyPage.properties?.Name?.title?.[0]?.plain_text ||
                   'Untitled';
      console.log(`Found Abby page: ${title}`);
      console.log(`URL: https://www.notion.so/${abbyPage.id.replace(/-/g, '')}`);
      console.log(`Last edited: ${new Date(abbyPage.last_edited_time).toLocaleDateString()}`);
    } else {
      console.log('Abby dashboard not found in search results');
    }
    
    return {
      users: users.results,
      pages: searchResponse.results,
      categories,
      databases: dbSearch.results
    };
    
  } catch (error) {
    console.error('Error exploring Notion:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
    return null;
  }
}

// Run exploration
exploreABIBNotion().then(result => {
  if (result) {
    console.log('\n' + '='.repeat(80));
    console.log('✅ ABIB Notion exploration complete!');
    console.log(`📊 Summary: ${result.users.length} users, ${result.pages.length} pages, ${result.databases.length} databases`);
  } else {
    console.log('\n❌ Exploration failed.');
  }
});