const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

// List of ALL working groups found in the dashboard
const ALL_WORKING_GROUPS = [
  // Already migrated (regulatory)
  { name: 'AUSTRAC Working Group', id: '174d323b89ec8009b337c0d9f31bee47', status: 'migrated' },
  { name: 'RBA & Treasury Working Group', id: '174d323b89ec80abaccedee15fff306c', status: 'partial' },
  { name: 'ASIC Working Group', id: '174d323b89ec80a7a661e72ce244d1fa', status: 'migrated' },
  
  // NEW - Found in dashboard (need extraction)
  { name: 'Business Adoption', id: null, status: 'pending' },
  { name: 'Communications & Outreach', id: null, status: 'pending' },
  { name: 'Mining & Energy', id: null, status: 'pending' },
  { name: 'Community Voices', id: null, status: 'pending' },
  { name: 'AUSPOL', id: null, status: 'pending' },
  { name: 'ABIB x RBA', id: '1ddd323b89ec80f0a49deb05ea726a2c', status: 'extracted' },
  { name: 'Policy Working Group', id: '180d323b89ec80819e8cec13f37d9584', status: 'pending' },
  { name: 'Financial Inclusion Working Group', id: '199d323b89ec802b82c7d4d0ae7652cd', status: 'pending' },
  { name: 'Education', id: null, status: 'pending' },
  
  // Other linked pages
  { name: 'Resources', id: null, status: 'pending' },
  { name: 'Resource Library', id: null, status: 'pending' },
  { name: 'ABIB Policies', id: null, status: 'pending' },
  { name: 'Strategic Roadmap 2025-2030', id: null, status: 'pending' },
  { name: 'Our Next Steps', id: null, status: 'pending' },
  
  // Already seen in earlier search
  { name: 'ABIB Operations', id: '1ddd323b89ec80f08bc6f2bf54c9ef9a', status: 'pending' },
  { name: 'ABIB Budget', id: '1b4d323b89ec8004afd2c0dfcea649aa', status: 'pending' },
  { name: 'ABIB Policy & Procedure Manual', id: 'd7d60a5fed5b46649ba4961f3ba69c1e', status: 'pending' },
  { name: 'Bitcoin Research Newsletter', id: '309d323b89ec80d7abb7dcf9ee7aefeb', status: 'pending' },
  { name: 'ABIB Membership Categories', id: 'e5a3c5003ee945fa8f9318fb440b7284', status: 'pending' }
];

async function extractPageContent(pageId, pageName) {
  console.log(`\n📄 Extracting: ${pageName} (${pageId || 'ID unknown'})`);
  
  if (!pageId) {
    console.log('   ❌ No page ID - cannot extract');
    return null;
  }
  
  try {
    // Get page
    const page = await notion.pages.retrieve({ page_id: pageId });
    const title = page.properties?.title?.title?.[0]?.plain_text || pageName;
    
    console.log(`   ✅ Page exists: "${title}"`);
    console.log(`   Created: ${page.created_time}`);
    console.log(`   Last edited: ${page.last_edited_time}`);
    
    // Get blocks
    let allBlocks = [];
    let hasMore = true;
    let startCursor = undefined;
    
    while (hasMore) {
      const response = await notion.blocks.children.list({
        block_id: pageId,
        start_cursor: startCursor,
        page_size: 100
      });
      
      allBlocks = [...allBlocks, ...response.results];
      hasMore = response.has_more;
      startCursor = response.next_cursor;
    }
    
    console.log(`   Blocks: ${allBlocks.length}`);
    
    // Simple extraction
    let content = `# ${title}\n\n`;
    content += `**Source**: Notion page\n`;
    content += `**Page ID**: ${pageId}\n`;
    content += `**Created**: ${page.created_time}\n`;
    content += `**Last Updated**: ${page.last_edited_time}\n\n`;
    content += `---\n\n`;
    
    // Extract basic content
    allBlocks.forEach(block => {
      const type = block.type;
      
      if (type === 'heading_1') {
        const text = block.heading_1?.rich_text?.[0]?.plain_text || '';
        if (text) content += `# ${text}\n\n`;
      }
      else if (type === 'heading_2') {
        const text = block.heading_2?.rich_text?.[0]?.plain_text || '';
        if (text) content += `## ${text}\n\n`;
      }
      else if (type === 'paragraph') {
        const richText = block.paragraph?.rich_text || [];
        if (richText.length > 0) {
          let text = '';
          richText.forEach(rt => {
            let t = rt.plain_text || '';
            if (rt.annotations?.bold) t = `**${t}**`;
            if (rt.annotations?.italic) t = `*${t}*`;
            if (rt.href) t = `[${t}](${rt.href})`;
            text += t;
          });
          if (text.trim()) content += `${text}\n\n`;
        }
      }
      else if (type === 'bulleted_list_item') {
        const richText = block.bulleted_list_item?.rich_text || [];
        if (richText.length > 0) {
          let text = '';
          richText.forEach(rt => {
            let t = rt.plain_text || '';
            if (rt.annotations?.bold) t = `**${t}**`;
            if (rt.annotations?.italic) t = `*${t}*`;
            if (rt.href) t = `[${t}](${rt.href})`;
            text += t;
          });
          if (text.trim()) content += `- ${text}\n`;
        }
      }
      else if (type === 'child_page' || type === 'child_database') {
        const childTitle = block[type]?.title || 'Untitled';
        const icon = type === 'child_page' ? '📄' : '🗃️';
        content += `${icon} **Linked ${type === 'child_page' ? 'Page' : 'Database'}**: ${childTitle}\n\n`;
      }
    });
    
    content += `---\n\n`;
    content += `## Migration Status\n`;
    content += `- **Extracted**: ${new Date().toISOString()}\n`;
    content += `- **By**: Abby (AI Operations & Strategy Lead)\n`;
    content += `- **Destination**: Nextcloud working groups system\n`;
    
    return {
      name: title,
      id: pageId,
      content: content,
      blockCount: allBlocks.length,
      lastEdited: page.last_edited_time
    };
    
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    if (error.code === 'object_not_found') {
      console.log(`   Page not found or inaccessible`);
    }
    return null;
  }
}

async function extractAllWorkingGroups() {
  console.log('🚀 EXTRACTING ALL ABIB WORKING GROUPS\n');
  console.log('='.repeat(80));
  
  const results = [];
  const fs = require('fs');
  
  // First, let's search for pages to get missing IDs
  console.log('\n🔍 Searching for missing page IDs...');
  
  for (const group of ALL_WORKING_GROUPS) {
    if (!group.id && group.status === 'pending') {
      try {
        const search = await notion.search({
          query: group.name,
          filter: { property: 'object', value: 'page' },
          page_size: 5
        });
        
        if (search.results.length > 0) {
          const foundPage = search.results[0];
          group.id = foundPage.id;
          console.log(`   Found "${group.name}": ${foundPage.id}`);
        }
      } catch (error) {
        console.log(`   Search error for "${group.name}": ${error.message}`);
      }
    }
  }
  
  console.log('\n' + '='.repeat(80));
  console.log('📋 EXTRACTION PLAN\n');
  
  // Show what we're extracting
  ALL_WORKING_GROUPS.forEach((group, i) => {
    const statusIcon = group.status === 'migrated' ? '✅' : 
                      group.status === 'extracted' ? '📄' :
                      group.status === 'partial' ? '⚠️' : '🔍';
    console.log(`${i + 1}. ${statusIcon} ${group.name}`);
    if (group.id) console.log(`   ID: ${group.id}`);
  });
  
  console.log('\n' + '='.repeat(80));
  console.log('🚀 STARTING EXTRACTION\n');
  
  // Extract pending groups
  for (const group of ALL_WORKING_GROUPS) {
    if (group.status === 'pending' && group.id) {
      const result = await extractPageContent(group.id, group.name);
      if (result) {
        results.push(result);
        
        // Save to file
        const safeName = group.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        const filename = `2026-03-13_notion_${safeName}_v1.md`;
        fs.writeFileSync(filename, result.content);
        
        console.log(`   💾 Saved: ${filename} (${result.blockCount} blocks)`);
      }
      
      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  // Summary
  console.log('\n' + '='.repeat(80));
  console.log('📊 EXTRACTION SUMMARY\n');
  
  console.log(`Total working groups identified: ${ALL_WORKING_GROUPS.length}`);
  console.log(`Already migrated: ${ALL_WORKING_GROUPS.filter(g => g.status === 'migrated').length}`);
  console.log(`Partially migrated: ${ALL_WORKING_GROUPS.filter(g => g.status === 'partial').length}`);
  console.log(`Newly extracted: ${results.length}`);
  console.log(`Still pending (no ID): ${ALL_WORKING_GROUPS.filter(g => g.status === 'pending' && !g.id).length}`);
  
  if (results.length > 0) {
    console.log('\n📁 FILES CREATED:');
    results.forEach((result, i) => {
      console.log(`${i + 1}. ${result.name} (${result.blockCount} blocks)`);
    });
  }
  
  // Create master index
  console.log('\n' + '='.repeat(80));
  console.log('📋 CREATING MASTER INDEX\n');
  
  let masterIndex = `# ABIB Working Groups - Master Index\n\n`;
  masterIndex += `**Generated**: ${new Date().toISOString()}\n`;
  masterIndex += `**Total Groups**: ${ALL_WORKING_GROUPS.length}\n`;
  masterIndex += `**Status**: Comprehensive extraction in progress\n\n`;
  masterIndex += `---\n\n`;
  
  masterIndex += `## Working Groups Status\n\n`;
  
  ALL_WORKING_GROUPS.forEach((group, i) => {
    const status = group.status === 'migrated' ? '✅ Migrated' :
                   group.status === 'extracted' ? '📄 Extracted' :
                   group.status === 'partial' ? '⚠️ Partial' : '🔍 Pending';
    
    masterIndex += `${i + 1}. **${group.name}** - ${status}\n`;
    if (group.id) masterIndex += `   ID: \`${group.id}\`\n`;
    masterIndex += `\n`;
  });
  
  masterIndex += `---\n\n`;
  masterIndex += `## Next Steps\n\n`;
  masterIndex += `1. **Review extracted content** for operational importance\n`;
  masterIndex += `2. **Migrate critical pages** to Nextcloud operational system\n`;
  masterIndex += `3. **Create operational frameworks** for each working group\n`;
  masterIndex += `4. **Deprecate Notion pages** after migration verification\n`;
  masterIndex += `5. **Implement coordination system** in Nextcloud\n`;
  
  fs.writeFileSync('2026-03-13_abib-working-groups-master-index_v1.md', masterIndex);
  console.log(`💾 Master index saved: 2026-03-13_abib-working-groups-master-index_v1.md`);
  
  return { results, totalGroups: ALL_WORKING_GROUPS.length };
}

// Run extraction
extractAllWorkingGroups().catch(console.error);