const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function testNotion() {
  try {
    console.log('Testing Notion API connection...');
    
    // Try to search for pages and databases
    const response = await notion.search({
      filter: {
        property: 'object',
        value: 'page'
      }
    });
    
    console.log('Successfully connected to Notion!');
    console.log(`Found ${response.results.length} databases`);
    
    if (response.results.length > 0) {
      console.log('\nAvailable databases:');
      response.results.forEach((db, i) => {
        console.log(`${i + 1}. ${db.title ? db.title[0]?.plain_text || 'Untitled' : 'Untitled'} (${db.id})`);
      });
    }
    
    // Try to get user info
    const userResponse = await notion.users.list({});
    console.log(`\nConnected as user with ${userResponse.results.length} users in workspace`);
    
    return response;
    
  } catch (error) {
    console.error('Error connecting to Notion:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
    return null;
  }
}

testNotion();