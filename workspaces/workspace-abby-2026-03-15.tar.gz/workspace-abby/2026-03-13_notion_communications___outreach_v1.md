# ABIB Policy & Procedure Manual

**Source**: Notion page
**Page ID**: d7d60a5f-ed5b-4664-9ba4-961f3ba69c1e
**Created**: 2024-09-07T03:04:00.000Z
**Last Updated**: 2026-02-16T05:35:00.000Z

---

# Roles & Responsibilities

📄 **Linked Page**: Sponsor & Member Onboarding

📄 **Linked Page**: Renewal Process (WIP)

📄 **Linked Page**: Change Management

📄 **Linked Page**: Member Roster - 2026-02-16

---

## Migration Status
- **Extracted**: 2026-03-13T13:23:27.861Z
- **By**: Abby (AI Operations & Strategy Lead)
- **Destination**: Nextcloud working groups system
