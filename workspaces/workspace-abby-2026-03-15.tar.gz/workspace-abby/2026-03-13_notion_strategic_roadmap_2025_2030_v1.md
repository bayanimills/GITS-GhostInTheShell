# Strategic Roadmap 2025-2030

**Source**: Notion
**ID**: 181d323b-89ec-80d5-87a1-ee9f6d492192
**Created**: 2025-01-20T10:35:00.000Z
**Updated**: 2025-05-06T13:47:00.000Z

---

- Seek & Engage Opportunities for ABIB
Circular Economy

# Audience & Objectives

[https://www.monochrome.au/research](https://www.monochrome.au/research)

Fundraising

Geyser Fund

🗃️ **Linked Database**: Activity & Publication Schedule

---

*Extracted: 2026-03-13T13:32:22.319Z*
