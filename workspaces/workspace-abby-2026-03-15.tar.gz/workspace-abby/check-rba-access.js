const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function checkRBAAccess() {
  console.log('🔍 Checking RBA Treasury Working Group access...\n');
  
  try {
    const pageId = '174d323b89ec80abaccedee15fff306c';
    
    // Try to get the page first
    console.log(`Attempting to retrieve page: ${pageId}`);
    const page = await notion.pages.retrieve({ page_id: pageId });
    
    console.log('✅ Page retrieved successfully!');
    console.log(`Title: ${page.properties?.title?.title?.[0]?.plain_text || 'No title'}`);
    console.log(`Created: ${page.created_time}`);
    console.log(`Last edited: ${page.last_edited_time}`);
    
    // Try to search for it
    console.log('\n🔍 Searching for RBA/Treasury content...');
    const searchResponse = await notion.search({
      query: 'RBA Treasury Working Group',
      filter: {
        property: 'object',
        value: 'page'
      },
      page_size: 10
    });
    
    console.log(`Found ${searchResponse.results.length} pages in search`);
    
    searchResponse.results.forEach((result, i) => {
      const title = result.properties?.title?.title?.[0]?.plain_text || 
                   result.properties?.Name?.title?.[0]?.plain_text ||
                   'Untitled';
      console.log(`${i + 1}. ${title} (${result.id})`);
    });
    
    // Check if there are any child pages/databases we can access
    console.log('\n📋 Checking for accessible child content...');
    
    // Try to get blocks with a smaller page size
    try {
      const blocks = await notion.blocks.children.list({
        block_id: pageId,
        page_size: 5
      });
      
      console.log(`Got ${blocks.results.length} blocks`);
      blocks.results.forEach((block, i) => {
        console.log(`${i + 1}. Type: ${block.type}`);
        if (block.type === 'paragraph') {
          const text = block.paragraph?.rich_text?.[0]?.plain_text || '';
          if (text) console.log(`   Text: ${text.substring(0, 100)}...`);
        }
      });
    } catch (blockError) {
      console.log(`Block access error: ${blockError.message}`);
    }
    
    return page;
    
  } catch (error) {
    console.error('Access check error:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
    return null;
  }
}

checkRBAAccess().then(result => {
  if (result) {
    console.log('\n✅ Access check complete');
  } else {
    console.log('\n❌ Cannot access page content');
  }
});