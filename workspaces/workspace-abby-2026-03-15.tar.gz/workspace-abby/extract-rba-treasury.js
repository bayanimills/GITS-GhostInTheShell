const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

// Recursive function to extract toggle content
async function extractToggleContent(toggleBlock) {
  let content = '';
  const toggleText = toggleBlock.toggle?.rich_text?.[0]?.plain_text || '';
  
  if (toggleText) {
    content += `<details>\n<summary>${toggleText}</summary>\n\n`;
  } else {
    content += `<details>\n<summary>Toggle</summary>\n\n`;
  }
  
  // Get children of toggle
  let hasMore = true;
  let startCursor = undefined;
  let childBlocks = [];
  
  while (hasMore) {
    const response = await notion.blocks.children.list({
      block_id: toggleBlock.id,
      start_cursor: startCursor,
      page_size: 100
    });
    
    childBlocks = [...childBlocks, ...response.results];
    hasMore = response.has_more;
    startCursor = response.next_cursor;
  }
  
  // Process child blocks
  for (const child of childBlocks) {
    content += await processBlock(child, 1); // Indent level 1 for toggle content
  }
  
  content += `\n</details>\n\n`;
  return content;
}

// Process individual block
async function processBlock(block, indentLevel = 0) {
  const type = block.type;
  let content = '';
  const indent = '  '.repeat(indentLevel);
  
  if (type === 'heading_1') {
    const text = block.heading_1?.rich_text?.[0]?.plain_text || '';
    if (text) content += `${indent}# ${text}\n\n`;
  } 
  else if (type === 'heading_2') {
    const text = block.heading_2?.rich_text?.[0]?.plain_text || '';
    if (text) content += `${indent}## ${text}\n\n`;
  }
  else if (type === 'heading_3') {
    const text = block.heading_3?.rich_text?.[0]?.plain_text || '';
    if (text) content += `${indent}### ${text}\n\n`;
  }
  else if (type === 'paragraph') {
    const richText = block.paragraph?.rich_text || [];
    if (richText.length > 0) {
      let paragraphText = '';
      richText.forEach(rt => {
        let text = rt.plain_text || '';
        if (rt.annotations?.bold) text = `**${text}**`;
        if (rt.annotations?.italic) text = `*${text}*`;
        if (rt.annotations?.code) text = `\`${text}\``;
        if (rt.href) text = `[${text}](${rt.href})`;
        paragraphText += text;
      });
      if (paragraphText.trim()) {
        content += `${indent}${paragraphText}\n\n`;
      }
    }
  }
  else if (type === 'toggle') {
    content += await extractToggleContent(block);
  }
  else if (type === 'bulleted_list_item') {
    const richText = block.bulleted_list_item?.rich_text || [];
    if (richText.length > 0) {
      let itemText = '';
      richText.forEach(rt => {
        let text = rt.plain_text || '';
        if (rt.annotations?.bold) text = `**${text}**`;
        if (rt.annotations?.italic) text = `*${text}*`;
        if (rt.href) text = `[${text}](${rt.href})`;
        itemText += text;
      });
      if (itemText.trim()) {
        content += `${indent}- ${itemText}\n`;
      }
    }
  }
  else if (type === 'numbered_list_item') {
    const richText = block.numbered_list_item?.rich_text || [];
    if (richText.length > 0) {
      let itemText = '';
      richText.forEach(rt => {
        let text = rt.plain_text || '';
        if (rt.annotations?.bold) text = `**${text}**`;
        if (rt.annotations?.italic) text = `*${text}*`;
        if (rt.href) text = `[${text}](${rt.href})`;
        itemText += text;
      });
      if (itemText.trim()) {
        content += `${indent}1. ${itemText}\n`;
      }
    }
  }
  else if (type === 'callout') {
    const richText = block.callout?.rich_text || [];
    if (richText.length > 0) {
      let calloutText = '';
      richText.forEach(rt => {
        let text = rt.plain_text || '';
        if (rt.annotations?.bold) text = `**${text}**`;
        if (rt.annotations?.italic) text = `*${text}*`;
        if (rt.href) text = `[${text}](${rt.href})`;
        calloutText += text;
      });
      if (calloutText.trim()) {
        content += `${indent}> **Note**: ${calloutText}\n\n`;
      }
    }
  }
  else if (type === 'divider') {
    content += `${indent}---\n\n`;
  }
  else if (type === 'child_page' || type === 'child_database') {
    const childTitle = block[type]?.title || 'Untitled';
    const icon = type === 'child_page' ? '📄' : '🗃️';
    content += `${indent}${icon} **Linked ${type === 'child_page' ? 'Page' : 'Database'}**: ${childTitle}\n\n`;
  }
  else if (type === 'quote') {
    const richText = block.quote?.rich_text || [];
    if (richText.length > 0) {
      let quoteText = '';
      richText.forEach(rt => {
        let text = rt.plain_text || '';
        if (rt.annotations?.bold) text = `**${text}**`;
        if (rt.annotations?.italic) text = `*${text}*`;
        if (rt.href) text = `[${text}](${rt.href})`;
        quoteText += text;
      });
      if (quoteText.trim()) {
        content += `${indent}> ${quoteText}\n\n`;
      }
    }
  }
  else if (type === 'code') {
    const codeText = block.code?.rich_text?.[0]?.plain_text || '';
    const language = block.code?.language || '';
    if (codeText.trim()) {
      content += `${indent}\`\`\`${language}\n${codeText}\n\`\`\`\n\n`;
    }
  }
  
  return content;
}

async function extractRBATreasuryWorkingGroup() {
  console.log('📄 Extracting RBA Treasury Working Group from Notion...\n');
  
  try {
    // The page ID from the URL: 174d323b89ec80abaccedee15fff306c
    const pageId = '174d323b89ec80abaccedee15fff306c';
    
    console.log(`Fetching page: ${pageId}`);
    
    // Get the page
    const page = await notion.pages.retrieve({ page_id: pageId });
    const title = page.properties?.title?.title?.[0]?.plain_text || 
                 page.properties?.Name?.title?.[0]?.plain_text ||
                 'RBA Treasury Working Group';
    
    console.log(`Title: ${title}`);
    console.log(`Created: ${page.created_time}`);
    console.log(`Last edited: ${page.last_edited_time}`);
    
    // Get all page content
    let allBlocks = [];
    let hasMore = true;
    let startCursor = undefined;
    
    while (hasMore) {
      const response = await notion.blocks.children.list({
        block_id: pageId,
        start_cursor: startCursor,
        page_size: 100
      });
      
      allBlocks = [...allBlocks, ...response.results];
      hasMore = response.has_more;
      startCursor = response.next_cursor;
    }
    
    console.log(`\nFound ${allBlocks.length} top-level blocks`);
    
    // Process all blocks
    let markdownContent = `# ${title}\n\n`;
    markdownContent += `**Source**: Notion page (to be deprecated)\n`;
    markdownContent += `**Page ID**: ${pageId}\n`;
    markdownContent += `**Created**: ${page.created_time}\n`;
    markdownContent += `**Last Updated**: ${page.last_edited_time}\n\n`;
    markdownContent += `---\n\n`;
    
    // Process each block
    for (const block of allBlocks) {
      markdownContent += await processBlock(block);
    }
    
    // Add migration notes
    markdownContent += `---\n\n`;
    markdownContent += `## Migration Information\n\n`;
    markdownContent += `### Source Details\n`;
    markdownContent += `- **Notion Page**: ${title}\n`;
    markdownContent += `- **Page ID**: \`${pageId}\`\n`;
    markdownContent += `- **Created**: ${page.created_time}\n`;
    markdownContent += `- **Last Updated**: ${page.last_edited_time}\n\n`;
    
    markdownContent += `### Migration Details\n`;
    markdownContent += `- **Extracted**: ${new Date().toISOString()}\n`;
    markdownContent += `- **Extracted By**: Abby (AI Operations & Strategy Lead)\n`;
    markdownContent += `- **Destination**: Nextcloud \`ABIB-Admin/operations/abby/01-policy/\`\n`;
    markdownContent += `- **Status**: Migrated for long-term storage\n`;
    markdownContent += `- **Action Required**: Notion page to be deprecated after verification\n\n`;
    
    markdownContent += `### File Naming Convention\n`;
    markdownContent += `Following ABIB operational standards:\n`;
    markdownContent += `\`YYYY-MM-DD_source_topic_vX.ext\`\n\n`;
    
    markdownContent += `### Nextcloud Path\n`;
    markdownContent += `\`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/rba-treasury/\`\n`;
    
    console.log(`✅ Extraction complete`);
    console.log(`Markdown length: ${markdownContent.length} characters`);
    
    return {
      title,
      pageId,
      created: page.created_time,
      lastEdited: page.last_edited_time,
      markdown: markdownContent,
      blockCount: allBlocks.length
    };
    
  } catch (error) {
    console.error('Error extracting RBA Treasury Working Group:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
    return null;
  }
}

// Run extraction
extractRBATreasuryWorkingGroup().then(result => {
  if (result) {
    console.log('\n' + '='.repeat(80));
    console.log('📋 EXTRACTION SUMMARY:');
    console.log(`Title: ${result.title}`);
    console.log(`Blocks Processed: ${result.blockCount}`);
    console.log(`Created: ${result.created}`);
    console.log(`Last Edited: ${result.lastEdited}`);
    
    // Save to file
    const fs = require('fs');
    const filename = `2026-03-13_notion_rba-treasury-working-group_v1.md`;
    fs.writeFileSync(filename, result.markdown);
    console.log(`\n💾 Saved to: ${filename}`);
    
    // Show preview
    console.log('\n📄 CONTENT PREVIEW:');
    console.log('='.repeat(80));
    console.log(result.markdown.substring(0, 1500) + (result.markdown.length > 1500 ? '...' : ''));
    
  } else {
    console.log('\n❌ Extraction failed.');
  }
});