# ABIB Working Groups Directory

## Purpose
Central repository for all ABIB working groups, organized by focus area. Each working group has a specific mandate to advance Bitcoin adoption in Australia through targeted initiatives in regulation, community engagement, political advocacy, and operations.

## Official Working Group Structure

### 1. Regulatory & Policy Working Groups
- **01-austrac/**: AML/CTF compliance and engagement with AUSTRAC
- **02-asic/**: Regulatory frameworks and engagement with ASIC
- **03-treasury-rba/**: Policy development and submissions to Treasury & RBA

### 2. Community & Engagement Working Groups
- **01-community-engagement/**: Grassroots events, meetups, and education
- **02-communications/**: PR, media, social media, and content creation

### 3. Political Engagement Working Groups
- **01-federal/**: Engagement with federal parliamentarians and policymakers
- **02-state/**: Engagement with state governments on local adoption

### 4. Operations Working Group
- **04-operations/**: Finance, administration, technology, organizational management

## Directory Structure
```
02-working-groups/
├── README.md (this file)
├── 2026-03-14_abib-working-groups-master-index_v1.md      # Master index
├── 01-regulatory-policy/                                  # Regulatory groups
│   ├── 01-austrac/                                        # AUSTRAC Working Group
│   │   ├── README.md
│   │   ├── 2026-03-13_austrac-working-group-operational_v1.md
│   │   └── monitoring/
│   ├── 02-asic/                                           # ASIC Working Group
│   │   ├── README.md
│   │   ├── 2026-03-13_asic-working-group-operational_v1.md
│   │   └── monitoring/
│   └── 03-treasury-rba/                                   # Treasury & RBA WG
│       ├── README.md
│       ├── 2026-03-13_rba-treasury-working-group-operational_v1.md
│       └── monitoring/
├── 02-community-engagement/                               # Community groups
│   ├── 01-community-engagement/                           # Community Engagement
│   │   ├── README.md
│   │   └── framework.md (to be created)
│   └── 02-communications/                                 # Communications
│       ├── README.md
│       └── framework.md (to be created)
├── 03-political-engagement/                               # Political groups
│   ├── 01-federal/                                        # Federal Engagement
│   │   ├── README.md
│   │   └── framework.md (to be created)
│   └── 02-state/                                          # State Engagement
│       ├── README.md
│       └── framework.md (to be created)
├── 04-operations/                                         # Operations group
│   ├── README.md
│   ├── 2026-03-14_abib-operations-framework_v1.md
│   └── procedures/
└── coordination/                                          # Cross-group coordination
    ├── meeting-minutes/
    ├── progress-reports/
    └── strategic-alignment/
```

## Current Status

### ✅ Complete (Frameworks Established)
1. **AUSTRAC Working Group** - Operational framework ready
2. **ASIC Working Group** - Operational framework ready  
3. **Treasury & RBA Working Group** - Framework established
4. **ABIB Operations Working Group** - Comprehensive framework ready

### 🔄 In Development (Frameworks Needed)
1. **Community Engagement Working Group** - Framework to be created
2. **Communications Working Group** - Framework to be created
3. **Political Engagement - Federal** - Framework to be created
4. **Political Engagement - State** - Framework to be created

## Coordination Framework

### Meeting Schedule
- **Monthly**: Individual working group meetings
- **Quarterly**: Cross-working group coordination
- **Annual**: Strategic planning and review

### Reporting Requirements
- **Monthly**: Progress against objectives
- **Quarterly**: Performance assessment
- **Annual**: Objectives for coming year

### Success Metrics
Each working group tracks specific KPIs including:
- Regulatory engagements completed
- Community events organized
- Media coverage achieved
- Policy submissions made
- Membership growth
- Educational materials distributed

## File Naming Convention
All files follow ABIB operational standard:
`YYYY-MM-DD_source_topic_vX.ext`

Examples:
- `2026-03-13_austrac-working-group-operational_v1.md`
- `2026-06-30_community-engagement-report_q2-2026_v1.md`
- `2026-09-30_political-engagement-framework_v1.md`

## Implementation Timeline

### Phase 1: Foundation (March 2026 - COMPLETE)
- ✅ Establish working group structure
- ✅ Create regulatory frameworks
- ✅ Develop operations framework
- ✅ Migrate from Notion to Nextcloud

### Phase 2: Expansion (April-June 2026)
- Create community engagement framework
- Develop communications framework
- Establish political engagement frameworks
- Implement coordination systems

### Phase 3: Operationalization (July-September 2026)
- Launch all working groups
- Implement monitoring and reporting
- Begin regular coordination
- Measure initial impact

### Phase 4: Scaling (October-December 2026)
- Expand working group activities
- Increase community engagement
- Enhance policy influence
- Scale educational initiatives

## Contact & Support

### Working Group Leadership
- **Regulatory Groups**: Designated regulatory experts
- **Community Groups**: Community organizers and advocates
- **Political Groups**: Policy and government relations specialists
- **Operations**: ABIB Operations Team

### Operational Support
- **Coordination**: Abby (AI Operations & Strategy Lead)
- **Administration**: ABIB Operations Working Group
- **Technical**: System administrators
- **Strategic**: ABIB Executive Team

## Integration with Other Directories

### Connected Directories
- `../00-operations-framework/` - Overall operational foundation
- `../01-strategic-documents/` - Strategic direction and governance
- `../03-research/` - Research and analysis supporting working groups
- `../04-education/` - Educational materials and resources
- `../05-archive/` - Completed work and historical records

### Data Flow
```
Strategic Documents → Working Groups → Execution → Monitoring → Reporting
        ↓                   ↓              ↓           ↓           ↓
   Direction → Initiatives → Activities → Metrics → Assessment → Improvement
```

## Version History
- **v1.0** (2026-03-14): Working group structure established, regulatory and operations frameworks created
- **Next Update**: Scheduled for 2026-04-14 (community and political frameworks)

---
**Last Updated**: 2026-03-14  
**Maintained By**: Abby - AI Operations & Strategy Lead  
**Review Cycle**: Monthly coordination, quarterly strategic alignment  
**Status**: ✅ Structure established, frameworks in progress