# RBA & Treasury Working Group - Operational Framework

## Executive Summary
**Status**: Active regulatory engagement group (permissions issue for full extraction)  
**Focus**: Reserve Bank of Australia (RBA) and Treasury policy engagement  
**Last Updated**: 2026-03-13 (page recently edited)  
**Extraction Status**: ⚠️ Partial - main page inaccessible, related content extracted  

---

## Working Group Overview

### Primary Purpose
Coordinate ABIB's strategic engagement with Australia's two most important financial policy institutions:
1. **Reserve Bank of Australia (RBA)** - Monetary policy, payments system, digital currency
2. **Treasury** - Economic policy, digital assets framework, financial regulation

### Strategic Importance
- **RBA**: Controls monetary policy, payments system, influences banking sector
- **Treasury**: Sets economic policy, tax framework, digital assets regulation
- **Combined Impact**: These institutions shape the entire financial environment for Bitcoin in Australia

---

## Extracted Content from Related Pages

### 1. ABIB x RBA Page (Last Updated: 2025-04-22)
**Key Content:**
- RBA's statutory duty: "to contribute to the stability of the currency, full employment, and the economic prosperity and welfare of the Australian people"
- **Linked Documents**:
  - RBA and Treasury Joint Paper on Central Bank Digital Currency and the Future of Digital Money in Australia
  - Project Acacia (likely RBA digital currency project)
- **Workflow Process** (5-step):
  1. Prioritised List of Concerns as Pages
  2. Comments in relevant pages
  3. Response Drafted
  4. Response Refined
  5. Response sent to Communications for Publication
- **Previous Activity**: 2025-03 - Standing Committee on Economics - RBA Questions

### 2. NSW: Friends of Bitcoin → RBA (Last Updated: 2025-06-17)
**Key Content:**
- Evening event at NSW Parliament
- Goal: Establish "friends of bitcoin" parliamentary group
- Target attendees: Policymakers, industry (IREN, exchanges, meetup organizers), community, hardware (FrostSnap)
- Invitations: RBA officials, Federal Senators, Government departments
- Includes presentations component

### 3. ASIC Working Group (Related Context)
- Shows ABIB's multi-agency regulatory engagement approach
- Provides template for RBA/Treasury working group structure

---

## RBA Context & Strategic Focus Areas

### Reserve Bank of Australia Mandate
- **Primary Legislation**: Reserve Bank Act 1959
- **Core Duties**: Currency stability, full employment, economic prosperity
- **Bitcoin Relevance Areas**:
  1. **Digital Currency Research**: CBDC exploration vs Bitcoin
  2. **Payments System**: Innovation, surcharging rules, competition
  3. **Financial Stability**: Bitcoin's role in financial system
  4. **Monetary Policy**: Sound money principles vs fiat debasement

### Key RBA Initiatives (2025-2026)
1. **Project Acacia** - Digital currency/innovation project
2. **CBDC Research** - Joint paper with Treasury
3. **Payments System Review** - Modernization and innovation
4. **Surcharging Rules** - Payment cost transparency

---

## Treasury Context & Strategic Focus Areas

### Treasury Mandate
- **Role**: Economic policy, fiscal policy, financial regulation
- **Bitcoin Relevance Areas**:
  1. **Digital Assets Framework** - Comprehensive regulatory approach
  2. **Tax Policy** - Capital gains, GST, business treatment
  3. **Consumer Protection** - Safeguards for Bitcoin users
  4. **Financial Innovation** - Balancing innovation and stability

### Key Treasury Initiatives (2025-2026)
1. **Digital Assets Consultation** - Regulatory framework development
2. **Tax Treatment Review** - Clarification for digital assets
3. **Financial Services Reform** - Modernizing for digital age
4. **Consumer Protection Framework** - Digital asset safeguards

---

## Working Group Structure & Operations

### Governance Model
```
RBA & Treasury Working Group
├── Strategic Direction (ABIB Leadership)
├── Policy Development (Working Group)
├── Engagement Execution (Team)
└── Monitoring & Reporting (Abby - AI Operations)
```

### Membership Composition
- **ABIB Leadership**: Strategic oversight
- **Policy Experts**: Regulatory and economic analysis
- **Industry Representatives**: Bitcoin business perspective
- **Legal/Compliance**: Regulatory compliance expertise
- **Community Representatives**: User perspective

### Meeting Structure
- **Quarterly**: Strategic planning sessions
- **Monthly**: Working group meetings
- **Ad-hoc**: Response to regulatory developments
- **Event-based**: Parliamentary engagements, consultations

---

## Workflow Process (Based on Extracted Template)

### 5-Step Response Development
```mermaid
graph LR
    A[Identify Issue] --> B[Create Tracking Page]
    B --> C[Collect Input]
    C --> D[Draft Response]
    D --> E[Refine Response]
    E --> F[Publish/Deliver]
```

### Detailed Process
1. **Issue Identification**
   - Monitor RBA/Treasury publications
   - Track parliamentary inquiries
   - Identify consultation opportunities
   - Prioritize based on impact and urgency

2. **Documentation & Input**
   - Create dedicated tracking page
   - Collect relevant documents, research, questions
   - Gather working group input and comments
   - Conduct economic and legal analysis

3. **Response Development**
   - Draft initial response based on Austrian economics
   - Incorporate Bitcoin industry perspective
   - Align with ABIB policy positions
   - Ensure factual accuracy and evidence base

4. **Refinement Process**
   - Working group review and feedback
   - Legal and compliance review
   - Strategic alignment check
   - Stakeholder consultation

5. **Publication & Delivery**
   - Communications team review
   - Format for appropriate channel (submission, meeting, media)
   - Delivery through official channels
   - Follow-up and relationship maintenance

---

## Key Projects & Initiatives

### Active Projects (Based on Extracted Content)
1. **Parliamentary Friends Group** - Establishing "friends of bitcoin" in NSW Parliament
2. **RBA Engagement Events** - Evening events with policymakers and industry
3. **Committee Submissions** - Standing Committee on Economics questions
4. **Joint Paper Analysis** - RBA/Treasury digital currency paper response

### Planned Initiatives
1. **RBA Surcharging Review** - Payment cost transparency advocacy
2. **Treasury Digital Assets Framework** - Consultation response
3. **CBDC vs Bitcoin Education** - Comparative analysis and advocacy
4. **Tax Policy Reform** - Sensible Bitcoin tax treatment

---

## Relationship Management Strategy

### RBA Engagement Approach
- **Technical Level**: Payments system, digital currency research
- **Policy Level**: Monetary policy, financial stability
- **Operational Level**: Banking sector relationships, implementation
- **Public Level**: Education, transparency, public communications

### Treasury Engagement Approach
- **Policy Development**: Digital assets framework, tax policy
- **Regulatory Design**: Consumer protection, business regulation
- **Economic Analysis**: Impact assessment, cost-benefit analysis
- **Stakeholder Coordination**: Industry consultation, public input

### Key Contacts to Develop
1. **RBA Payments Policy** - Digital currency and innovation
2. **RBA Financial Stability** - Systemic risk assessment
3. **Treasury Digital Assets** - Regulatory framework
4. **Treasury Tax Policy** - Digital asset taxation
5. **Parliamentary Committees** - Oversight and inquiry

---

## Success Metrics & Monitoring

### Engagement Metrics
- Number of formal submissions delivered
- Meetings conducted with RBA/Treasury officials
- Parliamentary engagements secured
- Consultation responses submitted

### Impact Metrics
- Policy changes influenced
- Regulatory clarity achieved
- Industry concerns addressed
- Relationship depth developed

### Operational Metrics
- Response time to consultations
- Quality of submissions (completeness, evidence)
- Stakeholder satisfaction
- Process efficiency improvements

---

## Migration & Integration Status

### Current Status
- ✅ **Related Content Extracted**: ABIB x RBA, NSW Friends, ASIC Working Group
- ⚠️ **Main Page Inaccessible**: RBA & Treasury Working Group page requires permission update
- 🔄 **Context Added**: Operational framework based on ABIB standards
- 📅 **Recent Activity**: Page updated today (2026-03-13)

### Nextcloud Integration
```
ABIB-Admin/operations/abby/01-policy/regulatory-tracking/rba-treasury/
├── 2026-03-13_rba-treasury-working-group-context_v1.md
├── 2026-03-13_rba-treasury-working-group-operational_v1.md (this file)
├── README.md
└── [Future: submissions, meeting-notes, correspondence]
```

### Permission Resolution Required
1. **Access Request**: Update Notion integration permissions for RBA & Treasury Working Group page
2. **Content Verification**: Complete extraction once accessible
3. **Database Migration**: Plan migration of any linked databases
4. **Deprecation Planning**: Notion page deprecation after full migration

---

## Immediate Action Items

### Week 1 (Next 7 days)
1. ⚠️ **Resolve Access**: Request permissions for main working group page
2. ✅ **Document Foundation**: Create operational framework (this document)
3. 🔄 **Stakeholder Review**: Circulate to ABIB leadership for input
4. 📅 **Calendar Setup**: Add key RBA/Treasury dates to ABIB calendar

### Month 1 (Next 30 days)
1. **Monitoring System**: Set up RBA/Treasury publication monitoring
2. **Contact Database**: Develop relationship tracking system
3. **Template Library**: Create submission and response templates
4. **Workflow Automation**: Implement tracking and notification systems

### Quarter 1 (Next 90 days)
1. **Strategic Plan**: Develop comprehensive RBA/Treasury engagement strategy
2. **Capacity Building**: Train team on regulatory engagement processes
3. **Metrics System**: Implement success measurement framework
4. **Integration Complete**: Full migration from Notion to Nextcloud

---

## Related Resources & Connections

### ABIB Policy Framework Integration
- **Energy & Climate**: RBA's economic stability mandate
- **Tax Reform**: Treasury tax policy engagement
- **Privacy & Freedom**: Financial surveillance concerns
- **Financial Self-Sovereignty**: Alternative to state-controlled money

### Australian Regulatory Ecosystem
- **ASIC**: Securities and investments regulation
- **AUSTRAC**: AML/CTF compliance (already migrated)
- **APRA**: Banking and financial stability
- **ACCC**: Competition and consumer protection

### Bitcoin Industry Context
- **OrangeLabel.io**: 250+ Bitcoin businesses affected by policy
- **Australian Exchanges**: Regulatory compliance requirements
- **Mining Operations**: Energy policy and economic contribution
- **Community Groups**: Education and adoption efforts

---

## Contact & Coordination

### ABIB Leadership
- **Bayani Mills** - CEO, Strategic direction
- **Daniel Wilczynski** - Policy development lead
- **Elmo Stoop** - Regulatory engagement
- **Ben Dickens** - Board oversight

### Operational Team
- **Abby** - AI Operations & Strategy Lead (framework development)
- **Donna** - Executive operations coordination
- **The Doc** - Document processing and management
- **Working Group Members** - Subject matter experts

### External Coordination
- RBA officials and researchers
- Treasury policy developers
- Parliamentary committee members
- Industry association partners
- Legal and compliance advisors

---

**Document Status**: Operational framework established  
**Last Updated**: 2026-03-13  
**Next Review**: 2026-04-13  
**Version**: v1.0  
**Prepared By**: Abby - AI Operations & Strategy Lead  
**Approval Required**: ABIB Leadership review and input