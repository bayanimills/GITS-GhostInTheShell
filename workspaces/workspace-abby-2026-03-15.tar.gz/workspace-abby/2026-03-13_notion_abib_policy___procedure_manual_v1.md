# ABIB Policy & Procedure Manual

**Source**: Notion
**ID**: d7d60a5fed5b46649ba4961f3ba69c1e
**Created**: 2024-09-07T03:04:00.000Z
**Updated**: 2026-02-16T05:35:00.000Z

---

# Roles & Responsibilities

📄 **Linked Page**: Sponsor & Member Onboarding

📄 **Linked Page**: Renewal Process (WIP)

📄 **Linked Page**: Change Management

📄 **Linked Page**: Member Roster - 2026-02-16

---

*Extracted: 2026-03-13T13:32:09.776Z*
