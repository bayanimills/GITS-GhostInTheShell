# ABIB Budget

**Source**: Notion
**ID**: 1b4d323b89ec8004afd2c0dfcea649aa
**Created**: 2025-03-12T03:09:00.000Z
**Updated**: 2026-02-16T06:48:00.000Z

---

@Wade - How can this be implemented into Xero?

🗃️ **Linked Database**: Annual Budget

---

*Extracted: 2026-03-13T13:32:03.967Z*
