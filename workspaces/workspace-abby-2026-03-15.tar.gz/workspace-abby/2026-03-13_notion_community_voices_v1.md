# Communications & Outreach

**Source**: Notion page
**Page ID**: 18dd323b-89ec-80bc-b669-f11e5ab92cd3
**Created**: 2025-02-01T01:31:00.000Z
**Last Updated**: 2025-05-21T13:25:00.000Z

---

🗃️ **Linked Database**: Untitled

📄 **Linked Page**: Social Media Calendar

📄 **Linked Page**: Orange Pages

📄 **Linked Page**: Manifesto from BPUK

**Campaigns Messaging**

- ABIB:
- Policymakers
- Regulators
- Business Adoption:
- Mining & Energy
- Banks:
---

## Migration Status
- **Extracted**: 2026-03-13T13:23:30.079Z
- **By**: Abby (AI Operations & Strategy Lead)
- **Destination**: Nextcloud working groups system
