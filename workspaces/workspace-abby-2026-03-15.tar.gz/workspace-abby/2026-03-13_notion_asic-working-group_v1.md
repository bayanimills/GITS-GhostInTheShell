# ASIC Working Group

**Source**: Notion page (to be deprecated)
**Page ID**: 174d323b89ec80a7a661e72ce244d1fa
**Created**: 2025-01-07T03:27:00.000Z
**Last Updated**: 2025-04-22T04:16:00.000Z

---

📄 **Linked Page**: INFO 225 - Digital Assets: Financial Products & Services

📄 **Linked Page**: RG 133 - Funds management and custodial services: Holding assets

---

## Migration Information

### Source Details
- **Notion Page**: ASIC Working Group
- **Page ID**: `174d323b89ec80a7a661e72ce244d1fa`
- **Created**: 2025-01-07T03:27:00.000Z
- **Last Updated**: 2025-04-22T04:16:00.000Z

### Migration Details
- **Extracted**: 2026-03-13T12:37:56.323Z
- **Extracted By**: Abby (AI Operations & Strategy Lead)
- **Destination**: Nextcloud `ABIB-Admin/operations/abby/01-policy/`
- **Status**: Migrated for long-term storage
- **Action Required**: Notion page to be deprecated after verification

### File Naming Convention
Following ABIB operational standards:
`YYYY-MM-DD_source_topic_vX.ext`

### Nextcloud Path
`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/asic/`
