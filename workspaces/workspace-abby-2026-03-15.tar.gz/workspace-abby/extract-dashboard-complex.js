const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

// Function to extract column list content
async function extractColumnList(columnListBlock) {
  let content = '';
  
  // Get columns
  let columnBlocks = [];
  let hasMore = true;
  let startCursor = undefined;
  
  while (hasMore) {
    const response = await notion.blocks.children.list({
      block_id: columnListBlock.id,
      start_cursor: startCursor,
      page_size: 100
    });
    
    columnBlocks = [...columnBlocks, ...response.results];
    hasMore = response.has_more;
    startCursor = response.next_cursor;
  }
  
  content += `\n<div class="columns">\n\n`;
  
  for (const columnBlock of columnBlocks) {
    if (columnBlock.type === 'column') {
      content += `<div class="column">\n\n`;
      
      // Get column children
      let columnChildren = [];
      let colHasMore = true;
      let colCursor = undefined;
      
      while (colHasMore) {
        const colResponse = await notion.blocks.children.list({
          block_id: columnBlock.id,
          start_cursor: colCursor,
          page_size: 100
        });
        
        columnChildren = [...columnChildren, ...colResponse.results];
        colHasMore = colResponse.has_more;
        colCursor = colResponse.next_cursor;
      }
      
      // Process column children
      for (const child of columnChildren) {
        content += await extractBlockContent(child, 1);
      }
      
      content += `\n</div>\n\n`;
    }
  }
  
  content += `</div>\n\n`;
  return content;
}

// Function to extract block content
async function extractBlockContent(block, indent = 0) {
  const type = block.type;
  let content = '';
  const indentStr = '  '.repeat(indent);
  
  if (type === 'column_list') {
    content += await extractColumnList(block);
  }
  else if (type === 'callout') {
    const richText = block.callout?.rich_text || [];
    if (richText.length > 0) {
      const text = richText.map(rt => rt.plain_text).join('');
      content += `${indentStr}> **Callout**: ${text}\n\n`;
    }
  }
  else if (type === 'bulleted_list_item') {
    const richText = block.bulleted_list_item?.rich_text || [];
    if (richText.length > 0) {
      const text = richText.map(rt => {
        let t = rt.plain_text || '';
        if (rt.annotations?.bold) t = `**${t}**`;
        if (rt.annotations?.italic) t = `*${t}*`;
        if (rt.href) t = `[${t}](${rt.href})`;
        return t;
      }).join('');
      content += `${indentStr}- ${text}\n`;
    }
  }
  else if (type === 'paragraph') {
    const richText = block.paragraph?.rich_text || [];
    if (richText.length > 0) {
      const text = richText.map(rt => {
        let t = rt.plain_text || '';
        if (rt.annotations?.bold) t = `**${t}**`;
        if (rt.annotations?.italic) t = `*${t}*`;
        if (rt.href) t = `[${t}](${rt.href})`;
        return t;
      }).join('');
      if (text.trim()) {
        content += `${indentStr}${text}\n\n`;
      }
    }
  }
  else if (type === 'divider') {
    content += `${indentStr}---\n\n`;
  }
  else if (type === 'child_page') {
    const pageTitle = block.child_page?.title || 'Untitled Page';
    content += `${indentStr}📄 **Linked Page**: ${pageTitle}\n\n`;
  }
  else if (type === 'child_database') {
    const dbTitle = block.child_database?.title || 'Untitled Database';
    content += `${indentStr}🗃️ **Linked Database**: ${dbTitle}\n\n`;
  }
  
  return content;
}

async function extractDashboardComplex() {
  console.log('Extracting complex dashboard structure...\n');
  
  const dashboardId = '1ddd323b89ec80e78ba3e8a3e38d2d0a';
  
  try {
    // Get page
    const page = await notion.pages.retrieve({ page_id: dashboardId });
    const title = page.properties?.title?.title?.[0]?.plain_text || 'Working Groups Dashboard';
    
    console.log(`Dashboard: ${title}`);
    console.log(`Updated today at: ${page.last_edited_time}`);
    console.log();
    
    // Get all blocks
    let allBlocks = [];
    let hasMore = true;
    let startCursor = undefined;
    
    while (hasMore) {
      const response = await notion.blocks.children.list({
        block_id: dashboardId,
        start_cursor: startCursor,
        page_size: 100
      });
      
      allBlocks = [...allBlocks, ...response.results];
      hasMore = response.has_more;
      startCursor = response.next_cursor;
    }
    
    console.log(`Processing ${allBlocks.length} blocks with complex structure...\n`);
    
    // Extract content
    let markdown = `# ${title}\n\n`;
    markdown += `**Source**: Notion Working Groups Dashboard\n`;
    markdown += `**Page ID**: ${dashboardId}\n`;
    markdown += `**Created**: ${page.created_time}\n`;
    markdown += `**Last Updated**: ${page.last_edited_time}\n`;
    markdown += `**Status**: Actively used (updated today)\n\n`;
    markdown += `---\n\n`;
    
    // Process each block
    for (const block of allBlocks) {
      markdown += await extractBlockContent(block);
    }
    
    // Add critical note
    markdown += `---\n\n`;
    markdown += `## 🚨 CRITICAL FINDING\n\n`;
    markdown += `This dashboard was **updated today (${page.last_edited_time})**, indicating it is actively used.\n\n`;
    markdown += `### Structure Analysis:\n`;
    markdown += `1. **Column Lists**: Likely organizing working groups into categories\n`;
    markdown += `2. **Callout Blocks**: Important instructions or notes\n`;
    markdown += `3. **Complex Layout**: Not simple text - needs proper extraction\n\n`;
    markdown += `### Migration Impact:\n`;
    markdown += `- We may have missed working groups listed in column layouts\n`;
    markdown += `- The dashboard coordinates ALL working groups, not just regulatory\n`;
    markdown += `- Need to extract complete structure before deprecation\n`;
    
    console.log('✅ Complex extraction complete');
    
    // Save to file
    const fs = require('fs');
    const filename = `2026-03-13_notion_working-groups-dashboard-complex_v1.md`;
    fs.writeFileSync(filename, markdown);
    
    console.log(`\n💾 Saved to: ${filename}`);
    
    // Show preview
    console.log('\n📄 PREVIEW (first 1500 chars):');
    console.log('='.repeat(60));
    console.log(markdown.substring(0, 1500) + '...');
    
    return {
      title,
      content: markdown,
      blockCount: allBlocks.length,
      lastUpdated: page.last_edited_time
    };
    
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return null;
  }
}

extractDashboardComplex();