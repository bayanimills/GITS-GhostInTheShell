const { Client } = require('@notionhq/client');

const notion = new Client({
  auth: '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'
});

async function extractAUSTRACWorkingGroup() {
  console.log('📄 Extracting AUSTRAC Working Group from Notion...\n');
  
  try {
    // The page ID from the URL: 174d323b89ec8009b337c0d9f31bee47
    const pageId = '174d323b89ec8009b337c0d9f31bee47';
    
    console.log(`Fetching page: ${pageId}`);
    
    // Get the page
    const page = await notion.pages.retrieve({ page_id: pageId });
    const title = page.properties?.title?.title?.[0]?.plain_text || 
                 page.properties?.Name?.title?.[0]?.plain_text ||
                 'AUSTRAC Working Group';
    
    console.log(`Title: ${title}`);
    console.log(`Created: ${page.created_time}`);
    console.log(`Last edited: ${page.last_edited_time}`);
    
    // Get all page content
    let allBlocks = [];
    let hasMore = true;
    let startCursor = undefined;
    
    while (hasMore) {
      const response = await notion.blocks.children.list({
        block_id: pageId,
        start_cursor: startCursor,
        page_size: 100
      });
      
      allBlocks = [...allBlocks, ...response.results];
      hasMore = response.has_more;
      startCursor = response.next_cursor;
    }
    
    console.log(`\nFound ${allBlocks.length} blocks total`);
    
    // Process blocks into markdown
    let markdownContent = `# ${title}\n\n`;
    markdownContent += `**Source**: Notion page (to be deprecated)\n`;
    markdownContent += `**Page ID**: ${pageId}\n`;
    markdownContent += `**Created**: ${page.created_time}\n`;
    markdownContent += `**Last Updated**: ${page.last_edited_time}\n\n`;
    markdownContent += `---\n\n`;
    
    // Track list context for proper formatting
    let inBulletedList = false;
    let inNumberedList = false;
    let numberedListCounter = 1;
    
    allBlocks.forEach((block, index) => {
      const type = block.type;
      
      // Close previous lists if needed
      if (inBulletedList && type !== 'bulleted_list_item') {
        markdownContent += '\n';
        inBulletedList = false;
      }
      if (inNumberedList && type !== 'numbered_list_item') {
        markdownContent += '\n';
        inNumberedList = false;
        numberedListCounter = 1;
      }
      
      // Handle different block types
      if (type === 'heading_1') {
        const text = block.heading_1?.rich_text?.[0]?.plain_text || '';
        if (text) markdownContent += `\n# ${text}\n\n`;
      } 
      else if (type === 'heading_2') {
        const text = block.heading_2?.rich_text?.[0]?.plain_text || '';
        if (text) markdownContent += `\n## ${text}\n\n`;
      }
      else if (type === 'heading_3') {
        const text = block.heading_3?.rich_text?.[0]?.plain_text || '';
        if (text) markdownContent += `\n### ${text}\n\n`;
      }
      else if (type === 'paragraph') {
        const richText = block.paragraph?.rich_text || [];
        if (richText.length > 0) {
          let paragraphText = '';
          richText.forEach(rt => {
            let text = rt.plain_text || '';
            if (rt.annotations?.bold) text = `**${text}**`;
            if (rt.annotations?.italic) text = `*${text}*`;
            if (rt.annotations?.code) text = `\`${text}\``;
            if (rt.annotations?.strikethrough) text = `~~${text}~~`;
            if (rt.annotations?.underline) text = `<u>${text}</u>`;
            if (rt.href) text = `[${text}](${rt.href})`;
            paragraphText += text;
          });
          if (paragraphText.trim()) {
            markdownContent += `${paragraphText}\n\n`;
          }
        }
      }
      else if (type === 'bulleted_list_item') {
        const richText = block.bulleted_list_item?.rich_text || [];
        if (richText.length > 0) {
          let itemText = '';
          richText.forEach(rt => {
            let text = rt.plain_text || '';
            if (rt.annotations?.bold) text = `**${text}**`;
            if (rt.annotations?.italic) text = `*${text}*`;
            if (rt.href) text = `[${text}](${rt.href})`;
            itemText += text;
          });
          if (itemText.trim()) {
            if (!inBulletedList) {
              markdownContent += '\n';
              inBulletedList = true;
            }
            markdownContent += `- ${itemText}\n`;
          }
        }
      }
      else if (type === 'numbered_list_item') {
        const richText = block.numbered_list_item?.rich_text || [];
        if (richText.length > 0) {
          let itemText = '';
          richText.forEach(rt => {
            let text = rt.plain_text || '';
            if (rt.annotations?.bold) text = `**${text}**`;
            if (rt.annotations?.italic) text = `*${text}*`;
            if (rt.href) text = `[${text}](${rt.href})`;
            itemText += text;
          });
          if (itemText.trim()) {
            if (!inNumberedList) {
              markdownContent += '\n';
              inNumberedList = true;
            }
            markdownContent += `${numberedListCounter}. ${itemText}\n`;
            numberedListCounter++;
          }
        }
      }
      else if (type === 'to_do') {
        const richText = block.to_do?.rich_text || [];
        const checked = block.to_do?.checked ? '✅' : '☐';
        if (richText.length > 0) {
          let itemText = '';
          richText.forEach(rt => {
            let text = rt.plain_text || '';
            if (rt.annotations?.bold) text = `**${text}**`;
            if (rt.annotations?.italic) text = `*${text}*`;
            if (rt.href) text = `[${text}](${rt.href})`;
            itemText += text;
          });
          if (itemText.trim()) {
            markdownContent += `${checked} ${itemText}\n`;
          }
        }
      }
      else if (type === 'callout') {
        const richText = block.callout?.rich_text || [];
        if (richText.length > 0) {
          let calloutText = '';
          richText.forEach(rt => {
            let text = rt.plain_text || '';
            if (rt.annotations?.bold) text = `**${text}**`;
            if (rt.annotations?.italic) text = `*${text}*`;
            if (rt.href) text = `[${text}](${rt.href})`;
            calloutText += text;
          });
          if (calloutText.trim()) {
            markdownContent += `> **Note**: ${calloutText}\n\n`;
          }
        }
      }
      else if (type === 'quote') {
        const richText = block.quote?.rich_text || [];
        if (richText.length > 0) {
          let quoteText = '';
          richText.forEach(rt => {
            let text = rt.plain_text || '';
            if (rt.annotations?.bold) text = `**${text}**`;
            if (rt.annotations?.italic) text = `*${text}*`;
            if (rt.href) text = `[${text}](${rt.href})`;
            quoteText += text;
          });
          if (quoteText.trim()) {
            markdownContent += `> ${quoteText}\n\n`;
          }
        }
      }
      else if (type === 'code') {
        const codeText = block.code?.rich_text?.[0]?.plain_text || '';
        const language = block.code?.language || '';
        if (codeText.trim()) {
          markdownContent += `\`\`\`${language}\n${codeText}\n\`\`\`\n\n`;
        }
      }
      else if (type === 'divider') {
        markdownContent += `---\n\n`;
      }
      else if (type === 'child_page' || type === 'child_database') {
        const childTitle = block[type]?.title || 'Untitled';
        const icon = type === 'child_page' ? '📄' : '🗃️';
        markdownContent += `${icon} **Linked ${type === 'child_page' ? 'Page' : 'Database'}**: ${childTitle}\n\n`;
      }
      else if (type === 'embed' || type === 'bookmark' || type === 'link_preview') {
        const url = block[type]?.url || '';
        if (url) {
          markdownContent += `🔗 **Link**: [${url}](${url})\n\n`;
        }
      }
      else if (type === 'image') {
        const imageUrl = block.image?.file?.url || block.image?.external?.url || '';
        const caption = block.image?.caption?.[0]?.plain_text || '';
        if (imageUrl) {
          markdownContent += `![${caption || 'Image'}](${imageUrl})\n`;
          if (caption) markdownContent += `*${caption}*\n\n`;
        }
      }
      else if (type === 'table') {
        markdownContent += `\n**Table content (needs manual extraction)**\n\n`;
      }
      else {
        // For any other block types, just note they exist
        console.log(`  Skipping block type: ${type}`);
      }
    });
    
    // Close any open lists
    if (inBulletedList || inNumberedList) {
      markdownContent += '\n';
    }
    
    // Add metadata footer
    markdownContent += `---\n\n`;
    markdownContent += `## Migration Notes\n`;
    markdownContent += `- **Source**: Notion page \`${pageId}\`\n`;
    markdownContent += `- **Extracted**: ${new Date().toISOString()}\n`;
    markdownContent += `- **Status**: Migrated to Nextcloud for long-term storage\n`;
    markdownContent += `- **Action**: Notion page to be deprecated after verification\n`;
    
    console.log(`\n✅ Successfully extracted content`);
    console.log(`Markdown length: ${markdownContent.length} characters`);
    
    return {
      title,
      pageId,
      created: page.created_time,
      lastEdited: page.last_edited_time,
      markdown: markdownContent,
      blockCount: allBlocks.length
    };
    
  } catch (error) {
    console.error('Error extracting AUSTRAC Working Group:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
    return null;
  }
}

// Run extraction
extractAUSTRACWorkingGroup().then(result => {
  if (result) {
    console.log('\n' + '='.repeat(80));
    console.log('📋 EXTRACTION SUMMARY:');
    console.log(`Title: ${result.title}`);
    console.log(`Blocks: ${result.blockCount}`);
    console.log(`Created: ${result.created}`);
    console.log(`Last Edited: ${result.lastEdited}`);
    
    // Save to file
    const fs = require('fs');
    const filename = `austrac-working-group-${new Date().toISOString().split('T')[0]}.md`;
    fs.writeFileSync(filename, result.markdown);
    console.log(`\n💾 Saved to: ${filename}`);
    
    // Show preview
    console.log('\n📄 CONTENT PREVIEW (first 1000 chars):');
    console.log('='.repeat(80));
    console.log(result.markdown.substring(0, 1000) + '...');
    
  } else {
    console.log('\n❌ Extraction failed.');
  }
});