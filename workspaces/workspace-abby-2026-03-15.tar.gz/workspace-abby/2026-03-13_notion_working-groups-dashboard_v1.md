# Working Groups Dashboard

**Source**: Notion Working Groups Dashboard
**Page ID**: 1ddd323b89ec80e78ba3e8a3e38d2d0a
**Created**: 2025-04-22T02:03:00.000Z
**Last Updated**: 2025-07-01T08:57:00.000Z

---

- Grants
📄 **Linked Page**: Synced Blocks

---

## Migration Context

This dashboard has been superseded by the Nextcloud regulatory tracking system:

### Migrated Working Groups
1. **AUSTRAC Working Group** - Complete migration to Nextcloud
2. **RBA & Treasury Working Group** - Framework created, partial migration
3. **ASIC Working Group** - Complete migration to Nextcloud

### Nextcloud Location
`ABIB-Admin/operations/abby/01-policy/regulatory-tracking/`

### Status
- ✅ Operational frameworks established
- ✅ Directory structure created
- ✅ Documentation complete
- 🔄 Notion deprecation in progress
