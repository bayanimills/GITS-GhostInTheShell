#!/bin/bash
set -e
echo "=== Starting minimal test at $(date) ==="

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
    echo "✓ Loaded secrets.env"
    echo "SIMMER_API_KEY length: ${#SIMMER_API_KEY}"
else
    echo "✗ secrets.env not found"
    exit 1
fi

echo "=== Testing Python environment ==="
python3 -c "import sys; print(f'Python {sys.version}')"

echo "=== Testing simmer_sdk import ==="
python3 -c "import simmer_sdk; print('✓ simmer_sdk imported successfully')"

echo "=== Testing SimmerClient initialization ==="
python3 -c "
import simmer_sdk
import os
client = simmer_sdk.SimmerClient(api_key=os.environ['SIMMER_API_KEY'], venue='polymarket')
print('✓ SimmerClient initialized successfully')
"

echo "=== Testing mert_sniper.py with timeout ==="
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

# Run with timeout and capture first few lines
timeout 30 python3 mert_sniper.py --dry-run --expiry 1 2>&1 | head -50

echo "=== Test completed at $(date) ==="