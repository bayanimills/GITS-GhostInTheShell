# CANONICALS.md

## Purpose
Authoritative registry of valid references for core files:
`SOUL.md`, `IDENTITY.md`, `USER.md`, `MEMORY.md`, `HEARTBEAT.md`, `AGENTS.md`, `TOOLS.md`.

## Canonical External URLs
- (add production URLs here, one per line)

## Required Local Paths
- MEMORY.md
- HEARTBEAT.md
- AGENTS.md
- SOUL.md
- IDENTITY.md
- USER.md
- TOOLS.md

## Allowed Local Prefixes
- memory/
- scripts/
- logs/
- config/
- reports/

## Forbidden/Deprecated Patterns
- myweeklyjourney/index.html
- mode-prompt.md
- avatars/openclaw.png

## Notes
Keep this file current when architecture changes.

## Ignored Reference Patterns
- memory/YYYY-MM-DD.md
- BOOTSTRAP.md
- SKILL.md
- memory/heartbeat-state.json
- highlight.js/
