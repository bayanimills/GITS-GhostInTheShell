#!/usr/bin/env python3
import requests
import json
import sys
import os
from typing import Dict, List, Any

API_KEY = 'sk_live_a20bb67064b7db925e7f8c854de2e91e4ffc3ef495acd91f5f170d9eb6224671'
BASE_URL = 'https://api.simmer.markets/api/sdk'
HEADERS = {
    'Authorization': f'Bearer {API_KEY}',
    'Content-Type': 'application/json',
    'User-Agent': 'DannyTrader/1.0'
}

def query_portfolio(venue: str = 'polymarket') -> Dict:
    """Query portfolio for a venue."""
    url = f"{BASE_URL}/portfolio"
    params = {'venue': venue}
    try:
        resp = requests.get(url, headers=HEADERS, params=params, timeout=30, verify=False)
        if resp.status_code == 200:
            return resp.json()
        else:
            print(f"Error {resp.status_code} for venue {venue}: {resp.text[:200]}")
            return {}
    except Exception as e:
        print(f"Exception querying portfolio for {venue}: {e}")
        return {}

def query_positions(venue: str = 'polymarket') -> List:
    """Query positions for a venue."""
    url = f"{BASE_URL}/positions"
    params = {'venue': venue}
    try:
        resp = requests.get(url, headers=HEADERS, params=params, timeout=30, verify=False)
        if resp.status_code == 200:
            return resp.json()
        else:
            print(f"Error {resp.status_code} for venue {venue}: {resp.text[:200]}")
            return []
    except Exception as e:
        print(f"Exception querying positions for {venue}: {e}")
        return []

def main():
    print("Investigating Simmer positions discrepancy")
    print("=" * 60)
    
    venues = ['polymarket', 'simmer']
    
    for venue in venues:
        print(f"\nVenue: {venue}")
        print("-" * 40)
        portfolio = query_portfolio(venue)
        if portfolio:
            print(f"Portfolio keys: {list(portfolio.keys())}")
            for key in ['balance_usdc', 'balance_sim', 'total_exposure', 'positions_count', 'unrealized_pnl', 'realized_pnl']:
                if key in portfolio:
                    print(f"  {key}: {portfolio[key]}")
        positions = query_positions(venue)
        print(f"Positions count from API: {len(positions)}")
        if positions:
            # Show first few positions
            for i, pos in enumerate(positions[:3]):
                print(f"  Position {i}:")
                for k, v in pos.items():
                    print(f"    {k}: {v}")
        else:
            print("  No positions returned (empty list)")
        
        # Check if positions array empty but count > 0
        if portfolio and portfolio.get('positions_count', 0) > 0 and len(positions) == 0:
            print(f"  ⚠️  DISCREPANCY: portfolio positions_count={portfolio['positions_count']} but positions array empty!")
            # Try to fetch positions with filter for 'open' status
            print("  Attempting to fetch positions with status=open...")
            url = f"{BASE_URL}/positions"
            params = {'venue': venue, 'status': 'open'}
            try:
                resp = requests.get(url, headers=HEADERS, params=params, timeout=30, verify=False)
                if resp.status_code == 200:
                    open_positions = resp.json()
                    print(f"  Open positions count: {len(open_positions)}")
                    for pos in open_positions:
                        print(f"    - {pos.get('market_id')} side {pos.get('side')} shares {pos.get('shares')}")
                else:
                    print(f"  Failed to filter: {resp.status_code}")
            except Exception as e:
                print(f"  Error: {e}")
    
    # Also query trades from journal to see unresolved trades
    print("\n" + "=" * 60)
    print("Checking trade journal for unresolved trades...")
    trades_path = '/home/agent/.openclaw/workspace/skills/prediction-trade-journal/data/trades.json'
    if os.path.exists(trades_path):
        with open(trades_path, 'r') as f:
            data = json.load(f)
        trades = data.get('trades', [])
        unresolved = [t for t in trades if not t.get('outcome', {}).get('resolved', False)]
        print(f"Total trades: {len(trades)}")
        print(f"Unresolved trades: {len(unresolved)}")
        for t in unresolved[:5]:
            print(f"  Trade {t['id']}: market {t['market_id']} side {t['side']}")
    else:
        print("Trade journal not found.")
    
    print("\n" + "=" * 60)
    print("Investigation complete.")

if __name__ == '__main__':
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    main()