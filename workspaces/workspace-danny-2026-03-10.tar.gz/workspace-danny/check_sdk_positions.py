#!/usr/bin/env python3
import os
import json

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

from simmer_sdk import SimmerClient
client = SimmerClient(api_key=api_key)

print("=== SDK Positions Check ===")
try:
    positions = client.get_positions()
    print(f"Positions count: {len(positions)}")
    for i, pos in enumerate(positions):
        print(f"\nPosition {i+1}:")
        print(f"  Market ID: {pos.market_id}")
        print(f"  Side: {pos.side}")
        print(f"  Shares: {pos.shares}")
        print(f"  Average price: {pos.average_price}")
        print(f"  Redeemable: {pos.redeemable}")
        print(f"  Expired: {pos.expired}")
        print(f"  Profit: {pos.profit}")
        print(f"  Return: {pos.return_pct}")
except Exception as e:
    print(f"Error fetching positions: {e}")

print("\n=== Portfolio ===")
portfolio = client.get_portfolio()
print(json.dumps(portfolio, indent=2))

print("\n=== Briefing ===")
briefing = client._request("GET", "/api/sdk/briefing")
print(json.dumps(briefing, indent=2))