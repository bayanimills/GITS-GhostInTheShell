#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"

# Timestamp only
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Run directly with timeout - NO output processing
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper
timeout 45 python3 mert_sniper.py --live --smart-sizing --expiry 60 --set min_split=0.65 >> "$LOG_FILE" 2>&1

# Exit with whatever code the Python script returned
exit $?