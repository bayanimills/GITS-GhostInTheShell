#!/usr/bin/env python3
import os
import sys
from datetime import datetime

# Add the workspace to path
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper')

try:
    from simmer_sdk import SimmerClient
except ImportError as e:
    print(f"ERROR: Could not import Simmer SDK: {e}")
    sys.exit(1)

# Load API key from environment
api_key = os.environ.get('SIMMER_API_KEY')
if not api_key:
    print("ERROR: SIMMER_API_KEY environment variable not set")
    sys.exit(1)

# Create client
try:
    client = SimmerClient(api_key=api_key, venue='polymarket')
except Exception as e:
    print(f"ERROR: Could not create Simmer client: {e}")
    sys.exit(1)

print("🔍 Fetching portfolio position details...")
print("=" * 60)

try:
    # Get portfolio using the same method as mert_sniper.py
    portfolio = client.get_portfolio()
    print(f"Portfolio Balance (USDC): ${portfolio.get('balance_usdc', 0):.2f}")
    print(f"Total Exposure: ${portfolio.get('total_exposure', 0):.2f}")
    positions_count = portfolio.get('positions_count', 0)
    print(f"Number of Positions: {positions_count}")
    
    # Also try to get positions directly
    try:
        positions = client.get_positions()
        positions_count = len(positions) if positions else 0
        print(f"Direct Positions Count: {positions_count}")
        
        # If we have positions but they're objects, convert to dicts
        if positions_count > 0:
            # Check if first item is an object with attributes
            first_pos = positions[0]
            if hasattr(first_pos, '__dict__'):
                positions = [p.__dict__ for p in positions]
            elif not isinstance(first_pos, dict):
                # Try to convert using asdict if available
                try:
                    from dataclasses import asdict
                    positions = [asdict(p) for p in positions]
                except:
                    # Last resort: try to access attributes directly
                    positions = [{k: getattr(p, k) for k in dir(p) if not k.startswith('_')} for p in positions]
    except Exception as e:
        print(f"Could not get positions directly: {e}")
        positions = []
    
    balance = portfolio.get('balance_usdc', 1)  # Avoid division by zero
    exposure = portfolio.get('total_exposure', 0)
    if balance > 0:
        print(f"Exposure %: {(exposure / balance * 100):.1f}%")
    else:
        print(f"Exposure %: N/A (zero balance)")
    print()
    
    if positions_count == 0 and (not positions or len(positions) == 0):
        print("No positions found in portfolio")
        sys.exit(0)
    
    print("📊 POSITION DETAILS:")
    print("=" * 60)
    
    total_position_value = 0
    position_details = []
    
    for i, position in enumerate(positions, 1):
        # Get market details for this position
        try:
            # Handle both dict and object access
            if isinstance(position, dict):
                market_id = position.get('market_id')
                side = position.get('side')
                shares = position.get('shares', 0)
                avg_price = position.get('avg_price', 0)
                current_price = position.get('current_price', 0)
                value = position.get('value', 0)
                pnl = position.get('pnl', 0)
                pnl_percent = position.get('pnl_percent', 0)
            else:
                # Try to access as object attributes
                market_id = getattr(position, 'market_id', None)
                side = getattr(position, 'side', None)
                shares = getattr(position, 'shares', 0)
                avg_price = getattr(position, 'avg_price', 0)
                current_price = getattr(position, 'current_price', 0)
                value = getattr(position, 'value', 0)
                pnl = getattr(position, 'pnl', 0)
                pnl_percent = getattr(position, 'pnl_percent', 0)
            
            if not market_id:
                print(f"  Position {i}: No market_id found")
                continue
                
            market = client.get_market_context(market_id)
            market_name = market.get('question', 'Unknown Market')
            resolution_time_str = market.get('resolution_time')
            
            # Parse resolution time
            resolution_time = None
            time_to_expiry = "UNKNOWN"
            if resolution_time_str:
                try:
                    resolution_time = datetime.fromisoformat(resolution_time_str.replace('Z', '+00:00'))
                    # Calculate time to expiration
                    now = datetime.utcnow()
                    if resolution_time > now:
                        time_to_expiry = resolution_time - now
                    else:
                        time_to_expiry = "EXPIRED"
                except Exception as time_err:
                    time_to_expiry = f"Error: {time_err}"
            
            position_info = {
                'index': i,
                'market_id': market_id,
                'market_name': market_name,
                'side': 'YES' if side == 'yes' else 'NO',
                'shares': shares,
                'avg_price': avg_price,
                'current_price': current_price,
                'value': value,
                'pnl': pnl,
                'pnl_percent': pnl_percent,
                'resolution_time': resolution_time,
                'time_to_expiry': time_to_expiry
            }
            position_details.append(position_info)
            total_position_value += value
            
        except Exception as e:
            print(f"  Position {i}: Error fetching market details: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    # Sort by position value (largest first)
    position_details.sort(key=lambda x: x['value'], reverse=True)
    
    for pos in position_details:
        print(f"\n  Position #{pos['index']}:")
        print(f"    Market: {pos['market_name']}")
        print(f"    Side: {pos['side']}")
        print(f"    Shares: {pos['shares']:.2f}")
        print(f"    Avg Price: ${pos['avg_price']:.4f}")
        print(f"    Current Price: ${pos['current_price']:.4f}")
        print(f"    Position Value: ${pos['value']:.2f}")
        print(f"    P&L: ${pos['pnl']:.2f} ({pos['pnl_percent']:.1f}%)")
        
        if isinstance(pos['time_to_expiry'], str):
            print(f"    Expiry: {pos['time_to_expiry']}")
        else:
            hours = pos['time_to_expiry'].total_seconds() / 3600
            if hours < 1:
                minutes = hours * 60
                print(f"    Expires in: {minutes:.0f} minutes")
            else:
                print(f"    Expires in: {hours:.1f} hours")
    
    print("\n" + "=" * 60)
    print(f"📈 SUMMARY:")
    print(f"  Total Positions: {len(position_details)}")
    print(f"  Total Position Value: ${total_position_value:.2f}")
    print(f"  Portfolio Balance: ${balance:.2f}")
    if balance > 0:
        print(f"  Leverage Ratio: {(total_position_value / balance * 100):.1f}%")
    else:
        print(f"  Leverage Ratio: N/A (zero balance)")
    
    # Risk assessment
    leverage_ratio = total_position_value / balance if balance > 0 else 0
    if leverage_ratio > 1.3:
        print(f"  ⚠️  RISK LEVEL: EXTREME (>{leverage_ratio:.1f}x leverage)")
    elif leverage_ratio > 1.0:
        print(f"  ⚠️  RISK LEVEL: HIGH ({leverage_ratio:.1f}x leverage)")
    elif leverage_ratio > 0.5:
        print(f"  ⚠️  RISK LEVEL: MODERATE ({leverage_ratio:.1f}x leverage)")
    else:
        print(f"  ✅ RISK LEVEL: LOW ({leverage_ratio:.1f}x leverage)")
    
except Exception as e:
    print(f"ERROR: Could not fetch portfolio details: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)