#!/usr/bin/env python3
"""
Analyze positions expiring in April to determine if they are mispriced/mismatch markets
with guaranteed returns regardless of time locked up.
"""
import os
import sys
import json
import requests
from datetime import datetime, timezone

SIMMER_API_KEY = os.environ.get("SIMMER_API_KEY")
if not SIMMER_API_KEY:
    secrets_path = os.path.expanduser("/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env")
    if os.path.exists(secrets_path):
        with open(secrets_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    key, val = line.split('=', 1)
                    os.environ[key] = val
        SIMMER_API_KEY = os.environ.get("SIMMER_API_KEY")

if not SIMMER_API_KEY:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

HEADERS = {"Authorization": f"Bearer {SIMMER_API_KEY}"}
BASE_URL = "https://api.simmer.markets/api/sdk"

def fetch_positions(venue=None):
    """Fetch positions from Simmer API."""
    url = f"{BASE_URL}/positions"
    params = {}
    if venue:
        params["venue"] = venue
    try:
        resp = requests.get(url, headers=HEADERS, params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"  Positions fetch failed: {type(e).__name__}: {e}")
        return None

def fetch_market_details(market_id):
    """Fetch market details including resolution date."""
    url = f"{BASE_URL}/markets/{market_id}"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"    Market {market_id} fetch failed: {e}")
        return None

def analyze_positions():
    """Main analysis."""
    print("🔍 Analyzing positions expiring in April")
    print("=" * 60)
    
    # 1. Get positions for all venues
    data = fetch_positions()
    if not data:
        print("  ❌ Could not fetch positions")
        return
    
    positions = data.get("positions", [])
    print(f"  Total positions: {len(positions)}")
    if not positions:
        print("  No open positions found.")
        return
    
    # 2. Filter positions expiring in April 2026
    april_positions = []
    for pos in positions:
        market_id = pos.get("market_id")
        if not market_id:
            continue
        # Fetch market details to get resolution date
        market = fetch_market_details(market_id)
        if not market:
            continue
        resolves_at = market.get("resolves_at")
        if not resolves_at:
            continue
        # Parse ISO date
        try:
            resolve_dt = datetime.fromisoformat(resolves_at.replace('Z', '+00:00'))
            if resolve_dt.month == 4 and resolve_dt.year == 2026:
                april_positions.append((pos, market, resolve_dt))
        except Exception as e:
            print(f"    Date parse error: {e}")
            continue
    
    print(f"  Positions expiring in April 2026: {len(april_positions)}")
    if not april_positions:
        print("  No April positions found.")
        return
    
    # 3. Analyze each position for mispricing/arbitrage potential
    print("\n📊 April Position Analysis")
    for pos, market, resolve_dt in april_positions:
        print(f"\n  Market: {market.get('question', 'Unknown')}")
        print(f"    ID: {market.get('id')}")
        print(f"    Resolves: {resolve_dt.strftime('%Y‑%m‑d %H:%M')} UTC")
        print(f"    Side: {pos.get('side')}")
        print(f"    Shares: {pos.get('shares', 0):.2f}")
        print(f"    Cost: ${pos.get('cost', 0):.2f}")
        print(f"    Current value: ${pos.get('value', 0):.2f}")
        
        # Check if this is part of a paired position (yes+no)
        # We'd need to see if there's another position on opposite side
        # For now, just note if there's a mismatch between Simmer AI and Polymarket price
        # We'll need to fetch simmer probability and polymarket price
        # Simmer probability is in market.get('simmer_probability')
        simmer_prob = market.get('simmer_probability')
        polymarket_price = market.get('polymarket_price')
        if simmer_prob is not None and polymarket_price is not None:
            diff = simmer_prob - polymarket_price
            print(f"    Simmer AI: {simmer_prob:.1%}")
            print(f"    Polymarket price: {polymarket_price:.1%}")
            print(f"    Divergence: {diff:+.1%}")
            if abs(diff) > 0.1:
                print("    ⚠️  Significant divergence — potential mispricing")
            else:
                print("    ✓ No significant divergence")
        
        # Check if yes+no positions exist in portfolio for same market
        # We'll need to scan all positions for same market_id
        same_market_positions = [p for p in positions if p.get('market_id') == market.get('id')]
        if len(same_market_positions) > 1:
            sides = [p.get('side') for p in same_market_positions]
            print(f"    Multiple positions: {sides}")
            # Compute combined cost and guaranteed payout
            total_cost = sum(p.get('cost', 0) for p in same_market_positions)
            # If we have both yes and no, check if total cost < 1.0 per share
            if 'yes' in sides and 'no' in sides:
                print(f"    ⚖️  Both yes and no positions held")
                print(f"    Total cost: ${total_cost:.2f}")
                # Assuming shares are equal? Need more analysis
                # For simple case: if cost yes + cost no < payout (1 per share), arbitrage
                # But Polymarket LMSR ensures yes+no price = 1, so arbitrage only if we bought at mispriced times
                # This is complex; we'll just flag
                print("    🔍 Possible arbitrage — need deeper analysis")
    
    # 4. Summary
    print("\n📈 Summary")
    print("  April positions represent longer‑term bets (30‑60 days).")
    print("  Returns are NOT guaranteed unless:")
    print("    • You hold both yes+no positions with combined cost < $1 per share")
    print("    • There's a significant divergence between Simmer AI and market price")
    print("    • The market is mis‑priced relative to external data")
    print("  Otherwise, returns depend on actual outcome at resolution.")

if __name__ == "__main__":
    analyze_positions()