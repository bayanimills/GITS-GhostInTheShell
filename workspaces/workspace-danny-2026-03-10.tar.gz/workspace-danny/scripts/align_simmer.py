#!/usr/bin/env python3
"""
Simmer Alignment Checker

Ensures our trading scripts align with simmer.markets/skill.md recommendations.
Checklist:
- Use briefing endpoint for comprehensive status
- Check risk alerts before any trading
- Review positions needing attention
- Use proper formatting ($SIM vs USDC)
- Include reasoning, source, skill_slug (if supported)
- Use context before trading
"""

import os
import sys
import json
import requests
from datetime import datetime, timezone

SIMMER_API_KEY = os.environ.get("SIMMER_API_KEY")
if not SIMMER_API_KEY:
    # Try to load from secrets.env
    secrets_path = os.path.expanduser("/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env")
    if os.path.exists(secrets_path):
        with open(secrets_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    key, val = line.split('=', 1)
                    os.environ[key] = val
        SIMMER_API_KEY = os.environ.get("SIMMER_API_KEY")

if not SIMMER_API_KEY:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

HEADERS = {"Authorization": f"Bearer {SIMMER_API_KEY}"}
BASE_URL = "https://api.simmer.markets/api/sdk"

def fetch_briefing():
    """Fetch briefing endpoint and return parsed JSON."""
    try:
        resp = requests.get(f"{BASE_URL}/briefing", headers=HEADERS, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"  Briefing fetch failed: {type(e).__name__}: {e}")
        return None

def check_alignment():
    """Run alignment checks and report discrepancies."""
    print("🔮 Simmer Alignment Check")
    print("=" * 50)
    
    briefing = fetch_briefing()
    if not briefing:
        print("  ❌ Could not fetch briefing — API issue")
        return False
    
    # 1. Risk alerts
    risk_alerts = briefing.get("risk_alerts", [])
    if risk_alerts:
        print("  ⚠️  Risk alerts present (should address before trading):")
        for alert in risk_alerts:
            print(f"    - {alert}")
    else:
        print("  ✅ No risk alerts")
    
    # 2. Venue breakdown
    venues = briefing.get("venues", {})
    if not venues:
        print("  ❌ No venue data in briefing")
    else:
        for venue_name, venue_data in venues.items():
            if venue_data is None:
                continue
            currency = venue_data.get("currency", "?")
            balance = venue_data.get("balance", 0)
            positions = venue_data.get("positions_count", 0)
            print(f"  📊 {venue_name}: {balance:.2f} {currency}, {positions} positions")
    
    # 3. Positions needing attention
    positions_needing = []
    for venue_name, venue_data in venues.items():
        if venue_data and "positions_needing_attention" in venue_data:
            positions_needing.extend(venue_data["positions_needing_attention"])
    
    if positions_needing:
        print(f"  ⚠️  {len(positions_needing)} positions need attention")
    else:
        print("  ✅ No positions needing immediate attention")
    
    # 4. Opportunities
    opportunities = briefing.get("opportunities", {})
    new_markets = opportunities.get("new_markets", [])
    high_div = opportunities.get("high_divergence", [])
    print(f"  📈 {len(new_markets)} new markets, {len(high_div)} high‑divergence")
    
    # 5. Performance rank
    performance = briefing.get("performance", {})
    rank = performance.get("rank")
    total = performance.get("total_agents")
    if rank and total:
        print(f"  🏆 Rank {rank}/{total}")
    
    # 6. Check if we're using briefing in our scripts (can't auto‑detect)
    print("\n📋 Alignment recommendations:")
    print("  - Use briefing endpoint for scanning (already done in this check)")
    print("  - Include risk_alerts check before any trading")
    print("  - Format outputs with $SIM vs USDC labels")
    print("  - Add venue‑specific breakdown in reports")
    print("  - Use context endpoint before executing trades")
    print("  - Include reasoning and source in all trades")
    
    # Return True if no critical issues
    critical = len(risk_alerts) > 0
    return not critical

if __name__ == "__main__":
    success = check_alignment()
    sys.exit(0 if success else 1)