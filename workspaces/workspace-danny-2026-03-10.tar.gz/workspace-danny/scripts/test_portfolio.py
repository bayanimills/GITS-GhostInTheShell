#!/usr/bin/env python3
import os
import sys
from simmer_sdk import SimmerClient

api_key = os.environ.get('SIMMER_API_KEY')
if not api_key:
    print("ERROR: SIMMER_API_KEY not set")
    sys.exit(1)

client = SimmerClient(api_key=api_key, venue='polymarket')

print("Testing portfolio data...")
print("=" * 60)

# Method 1: get_portfolio()
print("1. client.get_portfolio():")
portfolio = client.get_portfolio()
print(f"   Type: {type(portfolio)}")
print(f"   Keys: {list(portfolio.keys()) if isinstance(portfolio, dict) else 'N/A'}")
print(f"   balance_usdc: {portfolio.get('balance_usdc', 'NOT FOUND')}")
print(f"   total_exposure: {portfolio.get('total_exposure', 'NOT FOUND')}")
print(f"   positions_count: {portfolio.get('positions_count', 'NOT FOUND')}")
print()

# Method 2: get_positions()
print("2. client.get_positions():")
try:
    positions = client.get_positions()
    print(f"   Type: {type(positions)}")
    if isinstance(positions, list):
        print(f"   Count: {len(positions)}")
        if positions:
            print(f"   First position keys: {list(positions[0].keys()) if isinstance(positions[0], dict) else 'N/A'}")
    else:
        print(f"   Value: {positions}")
except Exception as e:
    print(f"   Error: {e}")
print()

# Method 3: Try different venue
print("3. Testing with venue='prod' (if different):")
try:
    client2 = SimmerClient(api_key=api_key, venue='prod')
    portfolio2 = client2.get_portfolio()
    print(f"   balance_usdc: {portfolio2.get('balance_usdc', 'NOT FOUND')}")
    print(f"   total_exposure: {portfolio2.get('total_exposure', 'NOT FOUND')}")
    print(f"   positions_count: {portfolio2.get('positions_count', 'NOT FOUND')}")
except Exception as e:
    print(f"   Error with venue='prod': {e}")