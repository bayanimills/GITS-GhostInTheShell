#!/bin/bash
set -e
echo "=== Test started at $(date) ==="

cd /home/agent/.openclaw/workspace-danny

# Load secrets simply
if [ -f .openclaw/secrets.env ]; then
    echo "Loading secrets..."
    export $(grep -v '^#' .openclaw/secrets.env | xargs)
    echo "API key length: ${#SIMMER_API_KEY}"
fi

cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

echo "Running Python script with 10s timeout..."
timeout 10 python3 -c "
import os
print('Python test starting...')
print(f'API Key present: {\"YES\" if os.environ.get(\"SIMMER_API_KEY\") else \"NO\"}')

try:
    from simmer_sdk import SimmerClient
    print('Simmer SDK imported')
    
    client = SimmerClient(api_key=os.environ['SIMMER_API_KEY'], venue='polymarket')
    print('Client created')
    
    markets = client.get_markets(limit=2)
    print(f'Got {len(markets)} markets')
    
except Exception as e:
    print(f'Error: {type(e).__name__}: {e}')
"

echo "=== Test completed at $(date) ==="