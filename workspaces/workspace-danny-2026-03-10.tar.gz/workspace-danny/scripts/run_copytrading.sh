#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/copytrading_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Check for wallets
if [[ -z "$SIMMER_COPYTRADING_WALLETS" ]]; then
    echo "⏸️  No whale wallets configured (set SIMMER_COPYTRADING_WALLETS in secrets.env)" >> "$LOG_FILE"
    exit 0
fi

# Determine mode: live if wallet private key is set
MODE_FLAGS=""
if [[ -n "$WALLET_PRIVATE_KEY" ]]; then
    echo "✅ Wallet key detected — executing LIVE trades" >> "$LOG_FILE"
    MODE_FLAGS="--live"
else
    echo "⚠️  No wallet key — dry‑run only" >> "$LOG_FILE"
fi

# Build command
CMD="python3 copytrading_trader.py --wallets \"$SIMMER_COPYTRADING_WALLETS\""

# Add max USD if set
if [[ -n "$SIMMER_COPYTRADING_MAX_USD" ]]; then
    CMD="$CMD --max-usd $SIMMER_COPYTRADING_MAX_USD"
fi

# Add max trades if set (note: skill uses --top-n for position limit, not max trades)
# Top N auto-calculates based on balance if not specified

# Add mode flags
if [[ -n "$MODE_FLAGS" ]]; then
    CMD="$CMD $MODE_FLAGS"
fi

# Run the Copytrading trader
cd /home/agent/.openclaw/workspace/skills/polymarket-copytrading
echo "Running: $CMD" >> "$LOG_FILE"
eval $CMD 2>&1 | tee -a "$LOG_FILE"