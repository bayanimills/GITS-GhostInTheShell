#!/bin/bash
mkdir -p /home/agent/.openclaw/workspace-danny/logs
echo "FastLoop run at $(date)" >> /home/agent/.openclaw/workspace-danny/logs/fastloop.log
exit 0
