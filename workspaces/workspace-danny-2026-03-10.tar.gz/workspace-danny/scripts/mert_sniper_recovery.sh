#!/bin/bash
set -e

echo "=== MERT SNIPER RECOVERY MODE ==="
echo "Start time: $(date)"
echo "=================================="

cd /home/agent/.openclaw/workspace-danny

# 1. Load environment with validation
if [ ! -f .openclaw/secrets.env ]; then
    echo "❌ ERROR: secrets.env not found"
    exit 1
fi

set -a
source .openclaw/secrets.env
set +a

if [ -z "$SIMMER_API_KEY" ]; then
    echo "❌ ERROR: SIMMER_API_KEY not set"
    exit 1
fi

echo "✓ Environment loaded (API key: ${#SIMMER_API_KEY} chars)"

# 2. Create log directory
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
RECOVERY_LOG="$LOG_DIR/mert_sniper_recovery_$(date +%Y%m%d_%H%M%S).log"

# 3. Health check - test basic connectivity
echo "=== HEALTH CHECK ==="
HEALTH_CHECK=$(curl -s -o /dev/null -w "%{http_code}" https://api.simmer.markets/health 2>/dev/null || echo "CURL_FAILED")
if [ "$HEALTH_CHECK" = "200" ]; then
    echo "✓ Simmer API health check: 200 OK"
else
    echo "❌ Simmer API health check failed: $HEALTH_CHECK"
    echo "   API may be down or unreachable"
    exit 1
fi

# 4. Test Python environment
echo "=== PYTHON ENVIRONMENT CHECK ==="
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

PYTHON_TEST=$(timeout 10 python3 -c "
import os
import simmer_sdk
print('Python imports: OK')
client = simmer_sdk.SimmerClient(api_key=os.environ['SIMMER_API_KEY'], venue='polymarket')
print('SimmerClient: OK')
" 2>&1)

if echo "$PYTHON_TEST" | grep -q "OK"; then
    echo "✓ Python environment: OK"
else
    echo "❌ Python environment check failed:"
    echo "$PYTHON_TEST"
    exit 1
fi

# 5. Run with STRICT timeout and monitoring
echo "=== EXECUTING MERT SNIPER ==="
echo "Command: timeout 120 python3 mert_sniper.py --dry-run --expiry 5 --set min_split=0.65"
echo "Timeout: 2 minutes"
echo "Mode: DRY RUN (no real trades)"
echo "Expiry: 5 minutes (reduced for testing)"
echo "=================================="

START_TIME=$(date +%s)
EXECUTION_OUTPUT=$(timeout 120 python3 mert_sniper.py --dry-run --expiry 5 --set min_split=0.65 2>&1)
EXIT_CODE=$?
END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

# 6. Log everything
{
    echo "=== EXECUTION LOG $(date) ==="
    echo "Duration: ${DURATION}s"
    echo "Exit code: $EXIT_CODE"
    echo "Output:"
    echo "$EXECUTION_OUTPUT"
    echo "=== END LOG ==="
} >> "$RECOVERY_LOG"

# 7. Analyze results
echo "=== EXECUTION RESULTS ==="
echo "Duration: ${DURATION} seconds"
echo "Exit code: $EXIT_CODE"

if [ $EXIT_CODE -eq 124 ]; then
    echo "❌ EXECUTION TIMED OUT after 120 seconds"
    echo "   The script is hanging - requires debugging"
    echo "   Log saved to: $RECOVERY_LOG"
    exit 1
elif [ $EXIT_CODE -eq 0 ]; then
    echo "✓ Execution completed successfully"
    
    # Extract summary
    TRADES=$(echo "$EXECUTION_OUTPUT" | grep "Trades executed:" | awk '{print $3}')
    NEAR=$(echo "$EXECUTION_OUTPUT" | grep "Near expiry:" | awk '{print $3}')
    
    if [ -z "$TRADES" ]; then
        TRADES=0
    fi
    
    echo "Summary: ${NEAR:-0} markets near expiry, ${TRADES} trades"
    echo "✓ System appears functional in dry-run mode"
    
    # Suggest next steps
    echo ""
    echo "=== NEXT STEPS ==="
    echo "1. Test with --live flag (real trading):"
    echo "   timeout 180 python3 mert_sniper.py --live --expiry 60 --set min_split=0.65"
    echo ""
    echo "2. If that works, re-enable cron with timeout wrapper:"
    echo "   timeout 300 ./scripts/run_mert_sniper.sh"
    echo ""
    echo "3. Log file: $RECOVERY_LOG"
    
else
    echo "❌ Execution failed with exit code: $EXIT_CODE"
    echo "Error output (last 10 lines):"
    echo "$EXECUTION_OUTPUT" | tail -20
    echo ""
    echo "Full log saved to: $RECOVERY_LOG"
    exit 1
fi

echo "=================================="
echo "Recovery completed at: $(date)"