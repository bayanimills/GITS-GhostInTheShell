#!/bin/bash
# Micro‑Arbitrage Scanner wrapper
# Runs the scanner and sends notification if opportunities found.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_DIR="$(dirname "$SCRIPT_DIR")"
cd "$WORKSPACE_DIR"

# Load environment
if [ -f .openclaw/secrets.env ]; then
    source .openclaw/secrets.env
fi

# Default threshold (minimum gap percentage)
MIN_GAP=${MICRO_ARBITRAGE_MIN_GAP:-3.0}

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting Micro‑Arbitrage Scanner (gap ≥${MIN_GAP}%)"

# Run scanner
python3 scripts/micro_arbitrage.py --min-gap "$MIN_GAP" --save

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Opportunities found (see logs/micro_arbitrage.json)"
    # The scanner itself does not send notifications; cron wrapper will handle that.
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] No arbitrage opportunities found."
fi

exit $EXIT_CODE