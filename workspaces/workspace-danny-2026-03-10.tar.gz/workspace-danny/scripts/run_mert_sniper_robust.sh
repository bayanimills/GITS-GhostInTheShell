#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Run Mert Sniper with multiple safeguards
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

# Use timeout with multiple stages to catch hangs early
# Stage 1: Quick timeout for initial hangs (15 seconds)
echo "Stage 1: Quick check (15s timeout)..." >> "$LOG_FILE"
STAGE1_OUTPUT=$(timeout 15 python3 -c "
import os
print('Quick test starting...')
print(f'API Key: {len(os.environ.get(\"SIMMER_API_KEY\", \"\"))} chars')

try:
    from simmer_sdk import SimmerClient
    print('SDK imported')
    
    client = SimmerClient(api_key=os.environ['SIMMER_API_KEY'], venue='polymarket')
    print('Client created')
    
    # Quick test - get just 1 market
    markets = client.get_markets(limit=1)
    print(f'Quick test OK: {len(markets)} markets')
    
except Exception as e:
    print(f'Quick test FAILED: {type(e).__name__}: {str(e)[:100]}')
" 2>&1)

STAGE1_STATUS=$?
echo "$STAGE1_OUTPUT" >> "$LOG_FILE"

if [ $STAGE1_STATUS -eq 124 ]; then
    echo "ERROR: Stage 1 timed out after 15 seconds - API/SDK issue" >> "$LOG_FILE"
    echo "Mert Sniper: FAILED - Initial API check timed out"
    exit 1
fi

if echo "$STAGE1_OUTPUT" | grep -q "FAILED"; then
    echo "ERROR: Stage 1 failed - see log for details" >> "$LOG_FILE"
    echo "Mert Sniper: FAILED - Initial API check failed"
    exit 1
fi

echo "Stage 1 passed, running main script..." >> "$LOG_FILE"

# Stage 2: Main script with timeout (90 seconds)
TIMEOUT=90
OUTPUT=$(timeout $TIMEOUT python3 mert_sniper.py --live --smart-sizing --expiry 60 --set min_split=0.65 2>&1)
TIMEOUT_STATUS=$?

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Check if timeout occurred
if [ $TIMEOUT_STATUS -eq 124 ]; then
    echo "ERROR: Main script timed out after ${TIMEOUT} seconds" >> "$LOG_FILE"
    echo "Mert Sniper: TIMEOUT - script took too long (${TIMEOUT}s)"
    exit 1
fi

# Extract trade count
TRADES=$(echo "$OUTPUT" | grep "Trades executed:" | awk '{print $3}')
NEAR=$(echo "$OUTPUT" | grep "Near expiry:" | awk '{print $3}')

if [ -z "$TRADES" ]; then
    TRADES=0
fi

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

if [ "$TRADES" -gt 0 ]; then
    # Trades executed — output full summary
    echo "$OUTPUT" | grep -A10 "Summary:"
elif [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours, no trade — stay silent (no output)
    exit 0
else
    # Daytime, no trade — output concise status
    echo "Mert Sniper: ${NEAR:-0} markets near expiry, ${TRADES} trades (60min, 65% split)."
fi