#!/usr/bin/env python3
"""
Check Polymarket API for market outcomes to supplement Simmer data.
Uses Gamma API (public) and CLOB API (authenticated) for resolution data.
"""

import os
import json
import requests
import warnings
requests.packages.urllib3.disable_warnings()
from pathlib import Path
from datetime import datetime

POLYMARKET_GAMMA_API = "https://gamma-api.polymarket.com"
POLYMARKET_CLOB_API = "https://clob.polymarket.com"

def check_gamma_market(market_id: str):
    """Check Gamma API for market resolution."""
    try:
        url = f"{POLYMARKET_GAMMA_API}/markets/{market_id}"
        response = requests.get(url, timeout=15, verify=False)
        if response.status_code == 200:
            data = response.json()
            return {
                "found": True,
                "resolved": data.get("resolved", False),
                "outcome": data.get("outcome"),
                "question": data.get("question", "Unknown")[:60],
                "end_date": data.get("endDate"),
                "status": data.get("active", "unknown")
            }
        return {"found": False, "error": f"HTTP {response.status_code}"}
    except Exception as e:
        return {"found": False, "error": str(e)}

def check_clob_market(condition_id: str):
    """Check CLOB API for market."""
    try:
        url = f"{POLYMARKET_CLOB_API}/markets/{condition_id}"
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            return response.json()
        return None
    except Exception:
        return None

def load_simmer_trades():
    """Load trades from Simmer data file."""
    trades_file = Path("/home/agent/.openclaw/workspace/skills/polymarket-copytrading/data/trades.json")
    if trades_file.exists():
        with open(trades_file) as f:
            return json.load(f)
    return {"trades": []}

def main():
    # Load trades
    trades_file = Path("/home/agent/.openclaw/workspace/skills/prediction-trade-journal/data/trades.json")
    if not trades_file.exists():
        print("No trades file found")
        return
    
    with open(trades_file) as f:
        data = json.load(f)
    
    trades = data.get("trades", [])
    pending = [t for t in trades if not t.get("outcome", {}).get("resolved")]
    
    print(f"Checking {len(pending)} pending trades against Polymarket...")
    print("=" * 70)
    
    found_count = 0
    resolved_count = 0
    
    for trade in pending[:10]:  # Check first 10
        market_id = trade.get("market_id")
        question = trade.get("market_question", "Unknown")[:50]
        
        print(f"\nChecking: {question}")
        print(f"  Market ID: {market_id}")
        
        result = check_gamma_market(market_id)
        
        if result.get("found"):
            found_count += 1
            print(f"  ✅ Found on Gamma")
            print(f"     Status: {'RESOLVED' if result['resolved'] else 'OPEN'}")
            if result.get("outcome"):
                print(f"     Outcome: {result['outcome']}")
                resolved_count += 1
            print(f"     End Date: {result.get('end_date')}")
        else:
            print(f"  ❌ Not found: {result.get('error', 'Unknown error')}")
    
    print(f"\n{'=' * 70}")
    print(f"Summary: Found {found_count}/{min(10, len(pending))} markets")
    print(f"Resolved outcomes: {resolved_count}")

if __name__ == "__main__":
    main()
