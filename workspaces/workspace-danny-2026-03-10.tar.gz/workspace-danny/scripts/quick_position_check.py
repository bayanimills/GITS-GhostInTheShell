#!/usr/bin/env python3
import os
import sys
from simmer_sdk import SimmerClient

api_key = os.environ.get('SIMMER_API_KEY')
if not api_key:
    print("ERROR: SIMMER_API_KEY not set")
    sys.exit(1)

client = SimmerClient(api_key=api_key, venue='polymarket')

print("Quick Position Check")
print("=" * 60)

# Get portfolio
portfolio = client.get_portfolio()
balance = portfolio.get('balance_usdc', 0)
exposure = portfolio.get('total_exposure', 0)
positions_count = portfolio.get('positions_count', 0)

print(f"Balance: ${balance:.2f}")
print(f"Exposure: ${exposure:.2f}")
print(f"Positions: {positions_count}")
if balance > 0:
    print(f"Exposure %: {(exposure / balance * 100):.1f}%")
print()

# Get positions (just count and basic info)
try:
    positions = client.get_positions()
    if positions and len(positions) > 0:
        print(f"Found {len(positions)} positions:")
        print("-" * 40)
        
        # Just show first 3 positions to avoid API limits
        for i, pos in enumerate(positions[:3], 1):
            if isinstance(pos, dict):
                market_id = pos.get('market_id', 'Unknown')
                side = pos.get('side', 'unknown')
                value = pos.get('value', 0)
                pnl = pos.get('pnl', 0)
            else:
                market_id = getattr(pos, 'market_id', 'Unknown')
                side = getattr(pos, 'side', 'unknown')
                value = getattr(pos, 'value', 0)
                pnl = getattr(pos, 'pnl', 0)
            
            print(f"Position {i}:")
            print(f"  Market ID: {market_id[:20]}...")
            print(f"  Side: {side}")
            print(f"  Value: ${value:.2f}")
            print(f"  P&L: ${pnl:.2f}")
            print()
        
        if len(positions) > 3:
            print(f"... and {len(positions) - 3} more positions")
    else:
        print("No positions found")
        
except Exception as e:
    print(f"Error getting positions: {e}")