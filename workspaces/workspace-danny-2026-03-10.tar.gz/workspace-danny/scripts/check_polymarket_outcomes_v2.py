#!/usr/bin/env python3
"""
Check Polymarket API for market outcomes using multiple methods.
Tries condition_id, slug lookup, and question search.
"""

import os
import json
import requests
from pathlib import Path
from datetime import datetime
import re

POLYMARKET_GAMMA_API = "https://gamma-api.polymarket.com"

def slugify(text):
    """Convert question to slug format."""
    # Remove non-alphanumeric, convert to lowercase, replace spaces with dashes
    slug = re.sub(r'[^\w\s-]', '', text.lower())
    slug = re.sub(r'[-\s]+', '-', slug)
    return slug[:80]  # Limit length

def search_gamma_by_question(question: str):
    """Search Gamma API by market question."""
    try:
        # Extract key terms
        terms = re.sub(r'[^\w\s]', '', question.lower()).split()
        keywords = ' '.join(terms[:5])  # First 5 words
        
        url = f"{POLYMARKET_GAMMA_API}/markets"
        params = {
            "closed": "false",
            "archived": "false", 
            "order": "desc",
            "limit": 50
        }
        
        response = requests.get(url, params=params, timeout=15)
        if response.status_code == 200:
            data = response.json()
            markets = data.get("markets", [])
            
            # Find matching market
            for m in markets:
                if keywords in m.get("question", "").lower():
                    return {
                        "found": True,
                        "market": m,
                        "resolved": m.get("isResolved", False),
                        "outcome": m.get("outcome")
                    }
        return None
    except Exception as e:
        return {"found": False, "error": str(e)}

def check_market_by_id(market_id: str):
    """Try multiple ID formats."""
    results = {}
    
    # Try as condition_id directly
    try:
        url = f"{POLYMARKET_GAMMA_API}/markets/{market_id}"
        response = requests.get(url, timeout=10)
        results["direct_lookup"] = response.status_code
        if response.status_code == 200:
            return {"found": True, "method": "direct", "data": response.json()}
    except:
        pass
    
    return results

def main():
    # Load trades
    trades_file = Path("/home/agent/.openclaw/workspace/skills/prediction-trade-journal/data/trades.json")
    if not trades_file.exists():
        print("No trades file found")
        return
    
    with open(trades_file) as f:
        data = json.load(f)
    
    trades = data.get("trades", [])
    pending = [t for t in trades if not t.get("outcome", {}).get("resolved")]
    
    print(f"Checking {len(pending)} pending trades...")
    print("=" * 70)
    
    found_count = 0
    
    for trade in pending[:5]:  # Check first 5
        market_id = trade.get("market_id")
        question = trade.get("market_question", "Unknown")
        
        print(f"\n{'='*70}")
        print(f"Trade: {question[:60]}")
        print(f"Simmer Market ID: {market_id}")
        print(f"Venue: {trade.get('venue')}")
        print(f"Source: {trade.get('source')}")
        
        # Try direct lookup
        result = check_market_by_id(market_id)
        if isinstance(result, dict) and result.get("found"):
            print(f"✅ Found via direct lookup!")
            print(f"   Resolved: {result['data'].get('isResolved')}")
            print(f"   Outcome: {result['data'].get('outcome')}")
            found_count += 1
        else:
            print(f"Direct lookup failed: {result}")
            
            # Try search by question
            print(f"\nTrying question search...")
            search = search_gamma_by_question(question)
            if search and search.get("found"):
                print(f"✅ Found via question search!")
                m = search.get("market", {})
                print(f"   Question: {m.get('question')[:60]}")
                print(f"   Condition ID: {m.get('conditionId')}")
                print(f"   Resolved: {m.get('isResolved')}")
                print(f"   Outcome: {m.get('outcome')}")
                found_count += 1
            else:
                print(f"❌ Not found via search either")
                if search:
                    print(f"   Search result: {search}")
    
    print(f"\n{'='*70}")
    print(f"Found {found_count}/{min(5, len(pending))} markets on Polymarket")

if __name__ == "__main__":
    main()
