#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/tradejournal_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Run the Trade Journal sync
cd /home/agent/.openclaw/workspace/skills/prediction-trade-journal
python3 tradejournal.py --sync 2>&1 | tee -a "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Sync outcomes for resolved markets
echo "=== Syncing resolved market outcomes ===" >> "$LOG_FILE"
python3 tradejournal.py --sync-outcomes 2>&1 | tee -a "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Generate daily report (optional)
python3 tradejournal.py --report daily 2>&1 | tee -a "$LOG_FILE"