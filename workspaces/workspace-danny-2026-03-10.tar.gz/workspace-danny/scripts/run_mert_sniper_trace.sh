#!/bin/bash
set -e
set -x  # Enable tracing

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    echo "DEBUG: Loading secrets"
    set -a
    source .openclaw/secrets.env
    set +a
    echo "DEBUG: SIMMER_API_KEY length: ${#SIMMER_API_KEY}"
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"
TRACE_FILE="$LOG_DIR/mert_sniper_trace.log"

echo "=== TRACE START $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$TRACE_FILE"
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper
echo "DEBUG: In directory: $(pwd)" >> "$TRACE_FILE"

# Create a traced version of the Python script
cat > /tmp/mert_sniper_traced.py << 'EOF'
import os
import sys
import time

def trace(msg):
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] TRACE: {msg}", file=sys.stderr)
    sys.stderr.flush()

trace("Script starting")
trace(f"Python path: {sys.executable}")
trace(f"API Key present: {'YES' if os.environ.get('SIMMER_API_KEY') else 'NO'}")

# Import the original script
import importlib.util
spec = importlib.util.spec_from_file_location("mert_sniper", "mert_sniper.py")
module = importlib.util.module_from_spec(spec)

# Monkey-patch key functions to add tracing
original_get_client = None
original_fetch_markets = None
original_fetch_portfolio = None
original_execute_trade = None

def traced_get_client():
    trace("get_client() called")
    if original_get_client:
        result = original_get_client()
        trace(f"get_client() returned: {type(result).__name__}")
        return result
    return None

def traced_fetch_markets(market_filter=""):
    trace(f"fetch_markets() called with filter: '{market_filter}'")
    if original_fetch_markets:
        start = time.time()
        result = original_fetch_markets(market_filter)
        elapsed = time.time() - start
        trace(f"fetch_markets() returned {len(result) if result else 0} markets in {elapsed:.2f}s")
        return result
    return []

def traced_fetch_portfolio():
    trace("fetch_portfolio() called")
    if original_fetch_portfolio:
        start = time.time()
        result = original_fetch_portfolio()
        elapsed = time.time() - start
        if result:
            trace(f"fetch_portfolio() returned balance: ${result.get('balance', 0):.2f}")
        else:
            trace("fetch_portfolio() returned None")
        return result
    return None

def traced_execute_trade(market_id, side, amount_usd, is_dry_run=False):
    trace(f"execute_trade() called: {market_id}, {side}, ${amount_usd}, dry_run={is_dry_run}")
    if original_execute_trade:
        start = time.time()
        try:
            result = original_execute_trade(market_id, side, amount_usd, is_dry_run)
            elapsed = time.time() - start
            trace(f"execute_trade() completed in {elapsed:.2f}s: {result}")
            return result
        except Exception as e:
            elapsed = time.time() - start
            trace(f"execute_trade() failed after {elapsed:.2f}s: {type(e).__name__}: {str(e)[:100]}")
            raise
    return False

# Load the module
sys.modules["mert_sniper"] = module
spec.loader.exec_module(module)

# Apply tracing
if hasattr(module, 'get_client'):
    original_get_client = module.get_client
    module.get_client = traced_get_client

if hasattr(module, 'fetch_markets'):
    original_fetch_markets = module.fetch_markets
    module.fetch_markets = traced_fetch_markets

if hasattr(module, 'fetch_portfolio'):
    original_fetch_portfolio = module.fetch_portfolio
    module.fetch_portfolio = traced_fetch_portfolio

if hasattr(module, 'execute_trade'):
    original_execute_trade = module.execute_trade
    module.execute_trade = traced_execute_trade

# Run main with tracing
trace("Calling main()")
start = time.time()
try:
    # Parse command line args
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--smart-sizing', action='store_true')
    parser.add_argument('--expiry', type=int, default=60)
    parser.add_argument('--set', action='append')
    args, unknown = parser.parse_known_args()
    
    trace(f"Args: live={args.live}, dry-run={args.dry_run}, expiry={args.expiry}")
    
    # Call the original main function
    if hasattr(module, 'main'):
        module.main()
    else:
        trace("ERROR: No main() function found")
except Exception as e:
    trace(f"ERROR in main(): {type(e).__name__}: {str(e)[:200]}")
    raise
finally:
    elapsed = time.time() - start
    trace(f"Script completed in {elapsed:.2f}s")

trace("Script finished")
EOF

echo "DEBUG: Running traced script with 60s timeout" >> "$TRACE_FILE"
# Run with timeout, capturing both stdout and stderr
TIMEOUT=60
OUTPUT=$(timeout $TIMEOUT python3 /tmp/mert_sniper_traced.py --live --smart-sizing --expiry 60 --set min_split=0.65 2>&1)
TIMEOUT_STATUS=$?

echo "DEBUG: Script exit status: $TIMEOUT_STATUS" >> "$TRACE_FILE"
echo "$OUTPUT" >> "$TRACE_FILE"

# Check if timeout occurred
if [ $TIMEOUT_STATUS -eq 124 ]; then
    echo "ERROR: Script timed out after ${TIMEOUT} seconds" >> "$LOG_FILE"
    echo "ERROR: Script timed out after ${TIMEOUT} seconds" >> "$TRACE_FILE"
    echo "Mert Sniper: TIMEOUT - script took too long (${TIMEOUT}s)"
    exit 1
fi

# Extract the actual output (excluding trace messages)
ACTUAL_OUTPUT=$(echo "$OUTPUT" | grep -v "^\[.*\] TRACE:")
echo "$ACTUAL_OUTPUT" >> "$LOG_FILE"

# Extract trade count from actual output
TRADES=$(echo "$ACTUAL_OUTPUT" | grep "Trades executed:" | awk '{print $3}')
NEAR=$(echo "$ACTUAL_OUTPUT" | grep "Near expiry:" | awk '{print $3}')

if [ -z "$TRADES" ]; then
    TRADES=0
fi

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

if [ "$TRADES" -gt 0 ]; then
    # Trades executed — output full summary
    echo "$ACTUAL_OUTPUT" | grep -A10 "Summary:"
elif [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours, no trade — stay silent (no output)
    exit 0
else
    # Daytime, no trade — output concise status
    echo "Mert Sniper: ${NEAR:-0} markets near expiry, ${TRADES} trades (60min, 65% split)."
fi

echo "=== TRACE END $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$TRACE_FILE"