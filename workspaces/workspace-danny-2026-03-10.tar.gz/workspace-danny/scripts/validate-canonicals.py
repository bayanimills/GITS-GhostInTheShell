#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
CORE = ["SOUL.md","IDENTITY.md","USER.md","MEMORY.md","HEARTBEAT.md","AGENTS.md","TOOLS.md"]
CANON = ROOT / "CANONICALS.md"
KNOWN_EXT = (".md", ".json", ".py", ".sh", ".log", ".yaml", ".yml", ".txt", ".png", ".html")

if not CANON.exists():
    print("ERROR: CANONICALS.md missing")
    sys.exit(2)

text = CANON.read_text(errors="ignore")
forbidden, ignored = [], []
section = None
for ln in text.splitlines():
    s = ln.strip()
    if s.startswith("## "):
        section = s
    elif s.startswith("-") and section:
        val = s[1:].strip()
        if "Forbidden/Deprecated Patterns" in section:
            forbidden.append(val)
        elif "Ignored Reference Patterns" in section:
            ignored.append(val)

md_link = re.compile(r'\[[^\]]*\]\(([^)]+)\)')
code_tick = re.compile(r'`([^`]+)`')
plain_path = re.compile(r'(?<!\S)([A-Za-z0-9_./-]+\.(?:md|json|py|sh|log|yaml|yml|txt|png|html))(?!\S)')

errors = []

def likely_path(ref: str) -> bool:
    ref = ref.strip()
    if not ref or ref.startswith(("http://","https://","mailto:","#")):
        return False
    if " " in ref or "@" in ref:
        return False
    if ref.endswith(KNOWN_EXT):
        return True
    if "/" in ref and not ref.startswith("<"):
        return True
    return False

def is_ignored(ref: str) -> bool:
    return any(p and p in ref for p in ignored)

for f in CORE:
    p = ROOT / f
    if not p.exists():
        errors.append(f"missing core file: {f}")
        continue
    t = p.read_text(errors="ignore")
    cands = []
    cands += md_link.findall(t)
    cands += [c for c in code_tick.findall(t) if likely_path(c)]
    cands += plain_path.findall(t)

    seen = set()
    for c in cands:
        c = c.strip().strip('"\'')
        if not c or c in seen:
            continue
        seen.add(c)
        if is_ignored(c):
            continue
        if any(bad and bad in c for bad in forbidden):
            errors.append(f"{f}: forbidden reference '{c}'")
        if not likely_path(c):
            continue
        target = Path(c) if Path(c).is_absolute() else ROOT / c
        if not target.exists():
            errors.append(f"{f}: missing local reference '{c}'")

if errors:
    print("CANONICAL VALIDATION FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("CANONICAL VALIDATION OK")
