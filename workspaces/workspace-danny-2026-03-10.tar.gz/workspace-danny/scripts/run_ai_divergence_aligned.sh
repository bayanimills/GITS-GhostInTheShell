#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Briefing check (align with simmer skill)
echo "🔮 Simmer alignment check..." >&2
BRIEFING_OUTPUT=$(python3 << 'EOF'
import requests, os, json, sys
api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY missing", file=sys.stderr)
    sys.exit(1)
headers = {"Authorization": f"Bearer {api_key}"}
try:
    r = requests.get("https://api.simmer.markets/api/sdk/briefing", headers=headers, timeout=15)
    r.raise_for_status()
    data = r.json()
except Exception as e:
    print(f"BRIEFING_ERROR:{e}", file=sys.stderr)
    sys.exit(1)

# Risk alerts
risk_alerts = data.get("risk_alerts", [])
if risk_alerts:
    print("RISK_ALERTS:" + json.dumps(risk_alerts))
    sys.exit(0)

# Venue breakdown
venues = data.get("venues", {})
for venue, vdata in venues.items():
    if vdata:
        currency = vdata.get("currency", "?")
        balance = vdata.get("balance", 0)
        positions = vdata.get("positions_count", 0)
        print(f"VENUE:{venue}:{currency}:{balance:.2f}:{positions}")
EOF
)

if [ $? -ne 0 ]; then
    echo "⚠️  Briefing check failed, continuing anyway..." >&2
fi

if echo "$BRIEFING_OUTPUT" | grep -q "RISK_ALERTS:"; then
    alerts=$(echo "$BRIEFING_OUTPUT" | grep "RISK_ALERTS:" | sed 's/RISK_ALERTS://')
    echo "⛔ Risk alerts detected, skipping trading:" >&2
    echo "$alerts" | jq -r '.[]' | while read -r alert; do echo "   - $alert" >&2; done
    exit 0
fi

# Extract polymarket balance for reporting
POLYMARKET_BALANCE=$(echo "$BRIEFING_OUTPUT" | grep "^VENUE:polymarket:" | cut -d: -f4 2>/dev/null || echo "")
SIM_BALANCE=$(echo "$BRIEFING_OUTPUT" | grep "^VENUE:simmer:" | cut -d: -f4 2>/dev/null || echo "")

# Log venue summary
echo "$BRIEFING_OUTPUT" | grep "^VENUE:" | while IFS=: read -r venue currency balance positions; do
    echo "  $venue: $balance $currency, $positions positions" >&2
done

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/ai_divergence_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

# Run AI divergence scan with --min 8 threshold
cd /home/agent/.openclaw/workspace/skills/polymarket-ai-divergence
OUTPUT=$(python3 ai_divergence.py --min 8 2>&1)

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Check for opportunities
if echo "$OUTPUT" | grep -q "Showing.*of.*markets with divergence"; then
    # Extract count
    COUNT=$(echo "$OUTPUT" | grep "Showing.*of.*markets with divergence" | sed -E 's/.*Showing ([0-9]+) of ([0-9]+) markets.*/\1/')
    if [ "$COUNT" -gt 0 ]; then
        # Opportunities found
        if [[ "$QUIET" -eq 1 ]]; then
            # Quiet hours — stay silent (no output)
            exit 0
        else
            # Daytime — output full results with venue context
            echo "$OUTPUT"
            if [ -n "$POLYMARKET_BALANCE" ]; then
                echo "  Balance: $POLYMARKET_BALANCE USDC"
            fi
        fi
        exit 0
    fi
fi

# No opportunities
if [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours — stay silent
    exit 0
else
    STATUS="No AI divergence opportunities >8% found"
    if [ -n "$POLYMARKET_BALANCE" ]; then
        STATUS="$STATUS, balance $POLYMARKET_BALANCE USDC"
    fi
    echo "$STATUS."
fi