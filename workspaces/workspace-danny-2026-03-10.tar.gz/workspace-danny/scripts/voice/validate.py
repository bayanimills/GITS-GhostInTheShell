#!/usr/bin/env python3
"""
Voice validation script for DNA.MD compliance.
Checks for banned phrases, paragraph length, contractions, etc.
"""

import re
import sys

# Banned phrases (from DNA.MD)
BANNED_PHRASES = [
    # Dead AI Language
    r"In today's",
    r"It's important to note that",
    r"It's worth noting",
    r"delve",
    r"dive into",
    r"unpack",
    r"harness",
    r"leverage",
    r"utilize",
    r"landscape",
    r"realm",
    r"robust",
    r"game-changer",
    r"cutting-edge",
    r"straightforward",
    r"I'd be happy to help",
    r"In order to",
    # Dead Transitions
    r"furthermore",
    r"additionally",
    r"moreover",
    r"Moving forward",
    r"At the end of the day",
    r"To put this in perspective",
    r"What makes this particularly interesting is",
    r"The implications here are",
    r"In other words",
    r"It goes without saying",
    # Engagement Bait
    r"Let that sink in",
    r"Read that again",
    r"Full stop",
    r"This changes everything",
    r"Are you paying attention?",
    r"You're not ready for this",
    # AI Cringe
    r"supercharge",
    r"unlock",
    r"future-proof",
    r"10x your productivity",
    r"The AI revolution",
    r"In the age of AI",
    # Generic Insider Claims
    r"Here's the part nobody's talking about",
    r"What nobody tells you",
    # The Big One (FATAL)
    r"This isn't [^.]*\. This is [^.]*\.",
    r"Not [^.]*\. [^.]*\.",
    r"Forget [^.]*\. This is [^.]*\.",
    r"Less [^.]*, more [^.]*\.",
]

def check_banned_phrases(text):
    """Return list of banned phrases found."""
    found = []
    text_lower = text.lower()
    for pattern in BANNED_PHRASES:
        # Simple substring match for most patterns
        if re.search(pattern, text_lower, re.IGNORECASE):
            found.append(pattern)
    return found

def check_paragraph_length(text):
    """Return paragraphs longer than 3 sentences."""
    paragraphs = text.split('\n\n')
    long_paras = []
    for i, para in enumerate(paragraphs):
        if para.strip():
            # Count sentences roughly
            sentences = re.split(r'[.!?]+', para)
            if len([s for s in sentences if s.strip()]) > 3:
                long_paras.append((i+1, para[:100] + "..."))
    return long_paras

def check_contractions(text):
    """Check for missing contractions where natural."""
    # This is a simplistic check: look for "do not", "cannot", etc.
    missing = []
    pairs = [
        ("do not", "don't"),
        ("does not", "doesn't"),
        ("cannot", "can't"),
        ("could not", "couldn't"),
        ("will not", "won't"),
        ("is not", "isn't"),
        ("are not", "aren't"),
        ("have not", "haven't"),
        ("has not", "hasn't"),
        ("had not", "hadn't"),
    ]
    for formal, contraction in pairs:
        if re.search(r'\b' + formal + r'\b', text, re.IGNORECASE):
            missing.append(f"{formal} → {contraction}")
    return missing

def validate(text):
    """Run all checks and return summary."""
    banned = check_banned_phrases(text)
    long_paras = check_paragraph_length(text)
    missing_contractions = check_contractions(text)
    
    score = 100
    if banned:
        score -= len(banned) * 5
    if long_paras:
        score -= len(long_paras) * 3
    if missing_contractions:
        score -= len(missing_contractions) * 2
    score = max(0, score)
    
    return {
        "score": score,
        "banned_phrases": banned,
        "long_paragraphs": long_paras,
        "missing_contractions": missing_contractions,
        "passed": len(banned) == 0 and len(long_paras) == 0
    }

def main():
    if len(sys.argv) < 2:
        print("Usage: python validate.py <text_file>")
        sys.exit(1)
    
    with open(sys.argv[1], 'r') as f:
        text = f.read()
    
    result = validate(text)
    
    print(f"Compliance Score: {result['score']:.1f}%")
    print(f"Passed: {'✅' if result['passed'] else '❌'}")
    
    if result['banned_phrases']:
        print("\n❌ Banned phrases found:")
        for phrase in result['banned_phrases']:
            print(f"  - {phrase}")
    
    if result['long_paragraphs']:
        print("\n⚠️  Long paragraphs (>3 sentences):")
        for para_num, preview in result['long_paragraphs']:
            print(f"  Paragraph {para_num}: {preview}")
    
    if result['missing_contractions']:
        print("\n💡 Consider contractions:")
        for suggestion in result['missing_contractions']:
            print(f"  {suggestion}")
    
    if result['passed'] and not result['missing_contractions']:
        print("\n✅ Perfect compliance!")
    
    return 0 if result['passed'] else 1

if __name__ == "__main__":
    sys.exit(main())