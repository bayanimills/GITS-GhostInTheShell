#!/usr/bin/env python3
"""Manual outcome update helper for resolved markets."""

trades_input = """# Paste your resolved markets here
# Format: trade_id,winning_side,notes
bc2d6273-2633-49a4-92c9-7d5ef6cb7029,no,ETH closed down at 11:45
486c04b3-fcc0-41c3-b7a6-934ebc15b429,no,SOL closed down at 11:45
a123d944-d157-4feb-b395-c8d678203701,no,SOL closed down at 11AM
"""

print("""
📋 MANUAL REDEMPTION TRACKER
============================

Your 28 trades need manual outcome entry.

QUICK REFERENCE:
- Crypto 15-min binaries: Check if price was UP or DOWN at snapshot time
- Sports markets: Check final game results
- Weather markets: Check actual weather data

COMMANDS TO UPDATE:

cd /home/agent/.openclaw/workspace/skills/prediction-trade-journal

# List pending:
python3 tradejournal.py --pending

# Update single trade:
python3 tradejournal.py --manual-outcome <MARKET_ID> <yes|no> "note"

# Example:
python3 tradejournal.py --manual-outcome bc2d6273 yes "ETH closed up"

Once you know the outcomes, I'll batch-update them all.
""")

print(f"Total positions: 28")
print(f"Total cost basis: ~$126")
print(f"Potential redemption: $X (unknown until outcomes entered)")
