#!/bin/bash
mkdir -p /home/agent/.openclaw/workspace-danny/logs
echo "Weather run at $(date)" >> /home/agent/.openclaw/workspace-danny/logs/weather.log
exit 0
