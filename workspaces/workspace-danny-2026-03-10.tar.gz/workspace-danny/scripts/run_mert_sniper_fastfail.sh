#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"

# Timestamp only
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Create a modified version of the script with trade timeouts
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

# Create a wrapper that adds timeouts to trade execution
cat > /tmp/mert_sniper_fastfail.py << 'EOF'
import os
import sys
import signal

class TimeoutException(Exception):
    pass

def timeout_handler(signum, frame):
    raise TimeoutException("Operation timed out")

# Add timeout to trade execution
original_execute_trade = None

def execute_trade_with_timeout(market_id, side, amount_usd, is_dry_run=False):
    """Wrapper around execute_trade with timeout"""
    # Set timeout for trade execution (5 seconds)
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(5)
    
    try:
        result = original_execute_trade(market_id, side, amount_usd, is_dry_run)
        signal.alarm(0)  # Cancel alarm
        return result
    except TimeoutException:
        print(f"     Trade TIMEOUT: Execution took too long (5s)")
        return False
    except Exception as e:
        signal.alarm(0)  # Cancel alarm
        raise
    finally:
        signal.alarm(0)  # Ensure alarm is cleared

# Import and patch the module
import importlib.util
spec = importlib.util.spec_from_file_location("mert_sniper", "mert_sniper.py")
module = importlib.util.module_from_spec(spec)
sys.modules["mert_sniper"] = module
spec.loader.exec_module(module)

# Patch execute_trade if it exists
if hasattr(module, 'execute_trade'):
    original_execute_trade = module.execute_trade
    module.execute_trade = execute_trade_with_timeout
    print("DEBUG: Patched execute_trade with 5s timeout", file=sys.stderr)

# Also patch any other potentially slow operations
# Run the script by invoking its main execution
if __name__ == "__main__":
    # The script runs when imported, so we need to run it
    # by checking if there's a main guard or similar
    pass

# Since the script runs on import, we need a different approach
# Let's just run it directly with subprocess but with timeout
import subprocess
import shlex

# Build command
cmd = [
    sys.executable, "mert_sniper.py",
    "--live", "--smart-sizing",
    "--expiry", "60",
    "--set", "min_split=0.65"
]

print(f"DEBUG: Running command: {' '.join(cmd)}", file=sys.stderr)

# Run with overall timeout (40 seconds)
try:
    result = subprocess.run(
        cmd,
        timeout=40,
        capture_output=True,
        text=True
    )
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    sys.exit(result.returncode)
except subprocess.TimeoutExpired:
    print("ERROR: Script timed out after 40 seconds", file=sys.stderr)
    sys.exit(124)
EOF

# Run the modified script
timeout 50 python3 /tmp/mert_sniper_fastfail.py >> "$LOG_FILE" 2>&1
exit $?