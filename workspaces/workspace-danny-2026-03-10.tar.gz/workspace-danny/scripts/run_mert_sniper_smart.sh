#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"
STATE_FILE="$LOG_DIR/mert_sniper_state.json"

# Check recent failures - if too many, skip this run
MAX_CONSECUTIVE_FAILURES=3
COOLDOWN_MINUTES=30

# Read state or initialize
if [ -f "$STATE_FILE" ]; then
    LAST_RUN=$(grep -o '"last_run":[^,}]*' "$STATE_FILE" | cut -d: -f2 | tr -d '" ')
    CONSECUTIVE_FAILURES=$(grep -o '"consecutive_failures":[^,}]*' "$STATE_FILE" | cut -d: -f2 | tr -d ' ,')
else
    LAST_RUN=0
    CONSECUTIVE_FAILURES=0
fi

CURRENT_TIME=$(date +%s)
LAST_RUN_TIME=${LAST_RUN:-0}

# Calculate time since last run
TIME_SINCE_LAST_RUN=$((CURRENT_TIME - LAST_RUN_TIME))
TIME_SINCE_LAST_RUN_MINUTES=$((TIME_SINCE_LAST_RUN / 60))

echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"
echo "DEBUG: State - Last run: $LAST_RUN_TIME, Failures: $CONSECUTIVE_FAILURES, Minutes since: $TIME_SINCE_LAST_RUN_MINUTES" >> "$LOG_FILE"

# Check if we should run
if [ "$CONSECUTIVE_FAILURES" -ge "$MAX_CONSECUTIVE_FAILURES" ]; then
    if [ "$TIME_SINCE_LAST_RUN_MINUTES" -lt "$COOLDOWN_MINUTES" ]; then
        echo "SKIPPING: $CONSECUTIVE_FAILURES consecutive failures, cooling down for $((COOLDOWN_MINUTES - TIME_SINCE_LAST_RUN_MINUTES)) more minutes" >> "$LOG_FILE"
        echo "Mert Sniper: SKIPPED - Cooling down after $CONSECUTIVE_FAILURES failures"
        
        # Update state
        echo "{\"last_run\": $CURRENT_TIME, \"consecutive_failures\": $CONSECUTIVE_FAILURES, \"last_action\": \"skipped_cooldown\"}" > "$STATE_FILE"
        exit 0
    else
        echo "DEBUG: Cooldown period ended, attempting run" >> "$LOG_FILE"
    fi
fi

# Quick API health check before full run
echo "DEBUG: Performing API health check" >> "$LOG_FILE"
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

HEALTH_CHECK_OUTPUT=$(timeout 10 python3 -c "
import os
import sys
print('Health check starting...')
try:
    from simmer_sdk import SimmerClient
    client = SimmerClient(api_key=os.environ['SIMMER_API_KEY'], venue='polymarket')
    markets = client.get_markets(limit=1)
    print(f'Health check OK: API responding')
    sys.exit(0)
except Exception as e:
    print(f'Health check FAILED: {type(e).__name__}: {str(e)[:100]}')
    sys.exit(1)
" 2>&1)

HEALTH_CHECK_STATUS=$?
echo "$HEALTH_CHECK_OUTPUT" >> "$LOG_FILE"

if [ $HEALTH_CHECK_STATUS -ne 0 ]; then
    echo "DEBUG: API health check failed, skipping full run" >> "$LOG_FILE"
    NEW_FAILURES=$((CONSECUTIVE_FAILURES + 1))
    echo "{\"last_run\": $CURRENT_TIME, \"consecutive_failures\": $NEW_FAILURES, \"last_action\": \"health_check_failed\"}" > "$STATE_FILE"
    echo "Mert Sniper: SKIPPED - API health check failed"
    exit 0
fi

echo "DEBUG: API health check passed, running main script" >> "$LOG_FILE"

# Run main script with timeout
MAIN_TIMEOUT=30
MAIN_OUTPUT=$(timeout $MAIN_TIMEOUT python3 mert_sniper.py --live --smart-sizing --expiry 60 --set min_split=0.65 2>&1)
MAIN_STATUS=$?

echo "$MAIN_OUTPUT" >> "$LOG_FILE"

# Update state based on result
if [ $MAIN_STATUS -eq 124 ]; then
    # Timeout
    NEW_FAILURES=$((CONSECUTIVE_FAILURES + 1))
    echo "{\"last_run\": $CURRENT_TIME, \"consecutive_failures\": $NEW_FAILURES, \"last_action\": \"timeout\"}" > "$STATE_FILE"
    echo "Mert Sniper: TIMEOUT - script took too long (${MAIN_TIMEOUT}s)"
    exit 1
elif [ $MAIN_STATUS -ne 0 ]; then
    # Other error
    NEW_FAILURES=$((CONSECUTIVE_FAILURES + 1))
    echo "{\"last_run\": $CURRENT_TIME, \"consecutive_failures\": $NEW_FAILURES, \"last_action\": \"error_$MAIN_STATUS\"}" > "$STATE_FILE"
    echo "Mert Sniper: ERROR - script failed with code $MAIN_STATUS"
    exit 1
else
    # Success - reset failure count
    echo "{\"last_run\": $CURRENT_TIME, \"consecutive_failures\": 0, \"last_action\": \"success\"}" > "$STATE_FILE"
    
    # Extract trade count for output
    TRADES=$(echo "$MAIN_OUTPUT" | grep "Trades executed:" | awk '{print $3}')
    NEAR=$(echo "$MAIN_OUTPUT" | grep "Near expiry:" | awk '{print $3}')
    
    if [ -z "$TRADES" ]; then
        TRADES=0
    fi
    
    # Current hour in AEST
    HOUR=$(TZ=Australia/Sydney date +%H)
    
    # Quiet hours: 23:00-07:00 (inclusive)
    QUIET=0
    if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
        QUIET=1
    fi
    
    if [ "$TRADES" -gt 0 ]; then
        # Trades executed — output full summary
        echo "$MAIN_OUTPUT" | grep -A10 "Summary:"
    elif [[ "$QUIET" -eq 1 ]]; then
        # Quiet hours, no trade — stay silent (no output)
        exit 0
    else
        # Daytime, no trade — output concise status
        echo "Mert Sniper: ${NEAR:-0} markets near expiry, ${TRADES} trades (60min, 65% split)."
    fi
fi