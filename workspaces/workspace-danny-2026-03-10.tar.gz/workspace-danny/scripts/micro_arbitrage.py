#!/usr/bin/env python3
"""
Micro‑Arbitrage Scanner for Polymarket.
Finds price gaps between correlated markets (same underlying question, different time buckets).
"""

import os
import sys
import json
import re
from collections import defaultdict
from datetime import datetime
from typing import List, Dict, Tuple, Optional

# Add simmer_sdk path if needed
sys.path.append('/home/agent/.openclaw/workspace/skills/polymarket-ai-divergence')

from simmer_sdk import SimmerClient

class MicroArbitrageScanner:
    def __init__(self, api_key: str, min_gap_pct: float = 3.0, dry_run: bool = True):
        self.client = SimmerClient(api_key=api_key)
        self.min_gap_pct = min_gap_pct  # minimum price gap percentage to flag
        self.dry_run = dry_run
        self.fee_rate = 0.02  # 2% fee on winnings
        
    def parse_question(self, question: str) -> Dict[str, Optional[str]]:
        """
        Parse market question into components.
        Example: "XRP Up or Down - February 27, 11:15PM-11:30PM ET" ->
            {'asset': 'XRP Up or Down', 'date': 'February 27', 'time_bucket': '11:15PM-11:30PM ET'}
        """
        result = {'asset': None, 'date': None, 'time_bucket': None}
        
        if ' - ' not in question:
            result['asset'] = question.strip()
            return result
        
        # Split into asset and rest
        asset_part, rest = question.split(' - ', 1)
        result['asset'] = asset_part.strip()
        
        # Try to extract date and time bucket
        # Pattern: "February 27, 11:15PM-11:30PM ET"
        if ', ' in rest:
            date_part, time_part = rest.split(', ', 1)
            result['date'] = date_part.strip()
            result['time_bucket'] = time_part.strip()
        else:
            # No comma, maybe just date or just time
            result['date'] = rest.strip()
        
        return result
    
    def extract_underlying_asset(self, question: str) -> str:
        """Extract underlying asset (backward compatibility)."""
        parsed = self.parse_question(question)
        return parsed['asset'] or question.strip()
    
    def extract_time_bucket(self, question: str) -> Optional[str]:
        """Extract time bucket (backward compatibility)."""
        parsed = self.parse_question(question)
        return parsed['time_bucket']
    
    def fetch_active_markets(self, limit: int = 200) -> List[Dict]:
        """Fetch active markets from Simmer."""
        markets = self.client.get_markets(limit=limit, status='active')
        # Convert to dicts for easier processing
        market_dicts = []
        for m in markets:
            market_dicts.append({
                'id': m.id,
                'question': m.question,
                'slug': m.id,  # Use id as slug since Market doesn't have slug attribute
                'yes_price': m.current_probability,
                'no_price': 1 - m.current_probability,
                'expires_at': getattr(m, 'resolves_at', None),  # Use resolves_at instead of expires_at
                'volume': 0,  # Market doesn't have volume attribute
                'liquidity': 0  # Market doesn't have liquidity attribute
            })
        return market_dicts
    
    def group_by_underlying(self, markets: List[Dict]) -> Dict[str, List[Dict]]:
        """Group markets by underlying asset and date."""
        groups = defaultdict(list)
        for m in markets:
            parsed = self.parse_question(m['question'])
            # Use asset + date as key (if date exists)
            if parsed['date']:
                key = f"{parsed['asset']} | {parsed['date']}"
            else:
                key = parsed['asset']
            groups[key].append(m)
        # Filter groups with at least 2 markets
        return {k: v for k, v in groups.items() if len(v) >= 2}
    
    def find_arbitrage_opportunities(self, groups: Dict[str, List[Dict]]) -> List[Dict]:
        """Find arbitrage opportunities within each group."""
        opportunities = []
        
        for asset, markets in groups.items():
            # Sort by YES price (ascending)
            sorted_markets = sorted(markets, key=lambda x: x['yes_price'])
            
            # Compare each pair
            for i in range(len(sorted_markets)):
                for j in range(i + 1, len(sorted_markets)):
                    market_low = sorted_markets[i]
                    market_high = sorted_markets[j]
                    
                    price_low = market_low['yes_price']
                    price_high = market_high['yes_price']
                    
                    # Filter extreme prices (illiquid, unrealistic gaps)
                    if price_low <= 0:
                        import sys; sys.stderr.write(f"FILTER price_low <= 0: {price_low}\n")
                        continue
                    if price_low < 0.1 or price_high > 0.9:
                        import sys; sys.stderr.write(f"FILTER extreme: {price_low} -> {price_high}\n")
                        continue
                    
                    # Calculate gap percentage
                    gap = price_high - price_low
                    gap_pct = (gap / price_low) * 100 if price_low > 0 else 0
                    if gap_pct > 1000:
                        continue
                    if gap_pct > 50:
                        continue
                    
                    # Check if gap exceeds minimum
                    if gap_pct >= self.min_gap_pct:
                        # Calculate edge after fees
                        # Assuming we buy YES on low-price market and sell YES on high-price market
                        # (or buy NO on high-price market and sell NO on low-price market)
                        # For simplicity, we consider the YES side arbitrage
                        total_fees = 2 * self.fee_rate  # 2% each side
                        # Conservative estimate: edge = gap - total_fees (in price terms)
                        edge_price = gap - (price_low * total_fees)
                        edge_pct = (edge_price / price_low) * 100 if price_low > 0 else 0
                        
                        if edge_pct > 0:
                            opp = {
                                'asset': asset,
                                'market_low_id': market_low['id'],
                                'market_low_question': market_low['question'],
                                'market_low_price': price_low,
                                'market_high_id': market_high['id'],
                                'market_high_question': market_high['question'],
                                'market_high_price': price_high,
                                'gap_pct': round(gap_pct, 2),
                                'edge_pct': round(edge_pct, 2),
                                'timestamp': datetime.now().isoformat(),
                                'side': 'YES',  # YES-side arbitrage
                                'action': f'Buy YES @ {price_low:.3f}, Sell YES @ {price_high:.3f}'
                            }
                            opportunities.append(opp)
        
        return opportunities
    
    def scan(self) -> List[Dict]:
        """Run full scan."""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Fetching active markets...")
        markets = self.fetch_active_markets(limit=200)
        print(f"  Found {len(markets)} active markets.")
        
        groups = self.group_by_underlying(markets)
        print(f"  Grouped into {len(groups)} asset/date groups with ≥2 markets.")
        
        opportunities = self.find_arbitrage_opportunities(groups)
        print(f"  Found {len(opportunities)} arbitrage opportunities (gap ≥{self.min_gap_pct}%).")
        
        if opportunities:
            max_gap = max(opp['gap_pct'] for opp in opportunities)
            best_edge = max(opp['edge_pct'] for opp in opportunities)
            print(f"MICRO_ARBITRAGE_FOUND: {len(opportunities)} opportunities, max gap {max_gap:.1f}%, best edge {best_edge:.1f}%")
        
        return opportunities
    
    def print_opportunities(self, opportunities: List[Dict]):
        """Print opportunities in readable format."""
        if not opportunities:
            print("\nNo arbitrage opportunities found.")
            return
        
        print(f"\n🎯 MICRO‑ARBITRAGE OPPORTUNITIES (gap ≥{self.min_gap_pct}%)")
        print("=" * 80)
        
        for idx, opp in enumerate(opportunities, 1):
            # Parse questions for time buckets
            low_parsed = self.parse_question(opp['market_low_question'])
            high_parsed = self.parse_question(opp['market_high_question'])
            
            print(f"{idx}. {opp['asset']}")
            print(f"   Buy YES: {low_parsed['asset']} {low_parsed.get('time_bucket', '')}")
            print(f"     Price: {opp['market_low_price']:.3f} (market ID: {opp['market_low_id']})")
            print(f"   Sell YES: {high_parsed['asset']} {high_parsed.get('time_bucket', '')}")
            print(f"     Price: {opp['market_high_price']:.3f} (market ID: {opp['market_high_id']})")
            print(f"   Gap: {opp['gap_pct']}%, Edge after fees: {opp['edge_pct']}%")
            print(f"   Action: {opp['action']}")
            print()
    
    def save_opportunities(self, opportunities: List[Dict], filepath: str = "logs/micro_arbitrage.json"):
        """Save opportunities to JSON file."""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Load existing opportunities if any
        existing = []
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r') as f:
                    existing = json.load(f)
            except:
                pass
        
        # Append new opportunities
        all_opps = existing + opportunities
        
        # Keep only last 100 opportunities
        if len(all_opps) > 100:
            all_opps = all_opps[-100:]
        
        with open(filepath, 'w') as f:
            json.dump(all_opps, f, indent=2)
        
        print(f"Saved {len(opportunities)} opportunities to {filepath}")

def main():
    """Main function."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Micro‑Arbitrage Scanner for Polymarket')
    parser.add_argument('--min-gap', type=float, default=3.0,
                       help='Minimum price gap percentage to flag (default: 3.0%%)')
    parser.add_argument('--live', action='store_true',
                       help='Execute trades (NOT IMPLEMENTED YET)')
    parser.add_argument('--dry-run', action='store_true', default=True,
                       help='Dry run (default)')
    parser.add_argument('--save', action='store_true', default=True,
                       help='Save opportunities to JSON file')
    args = parser.parse_args()
    
    # Load API key
    secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
    api_key = None
    if os.path.exists(secrets_path):
        with open(secrets_path, 'r') as f:
            for line in f:
                if line.startswith('SIMMER_API_KEY='):
                    api_key = line.strip().split('=', 1)[1]
                    break
    
    if not api_key:
        print("Error: SIMMER_API_KEY not found in secrets.env")
        sys.exit(1)
    
    # Create scanner
    scanner = MicroArbitrageScanner(
        api_key=api_key,
        min_gap_pct=args.min_gap,
        dry_run=not args.live
    )
    
    # Run scan
    opportunities = scanner.scan()
    
    # Print results
    scanner.print_opportunities(opportunities)
    
    # Save if requested
    if args.save and opportunities:
        scanner.save_opportunities(opportunities)
    
    # Exit with code 0 if opportunities found (for cron notification)
    if opportunities:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()