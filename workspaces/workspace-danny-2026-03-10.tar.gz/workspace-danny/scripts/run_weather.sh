#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/weather_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Determine mode: live if LIVE_TRADING is set
MODE_FLAGS="--quiet"
if [[ -n "$LIVE_TRADING" && "$LIVE_TRADING" == "true" ]]; then
    echo "✅ LIVE TRADING ENABLED — executing real trades" >> "$LOG_FILE"
    MODE_FLAGS="--live --smart-sizing --quiet"
else
    echo "⚠️  Live trading disabled — dry‑run only" >> "$LOG_FILE"
fi

# Run the Weather trader and capture output
cd /home/agent/.openclaw/workspace/skills/polymarket-weather-trader
OUTPUT=$(python3 weather_trader.py $MODE_FLAGS 2>&1)

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Check for trade execution (case-insensitive)
TRADE_FOUND=0
if echo "$OUTPUT" | grep -qi "buy bucket\|buy yes\|buy no\|sell\|executed trade\|trade executed\|position opened"; then
    TRADE_FOUND=1
fi

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

# Decide output
if [[ "$TRADE_FOUND" -eq 1 ]]; then
    # Trade executed — output details
    echo "$OUTPUT"
elif [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours, no trade — stay silent (no output)
    exit 0
else
    # Daytime, no trade — output brief status (optional)
    # Extract bucket count line if present
    BUCKETS=$(echo "$OUTPUT" | grep -o "Found [0-9]* buckets" | head -1)
    if [[ -n "$BUCKETS" ]]; then
        echo "Weather: $BUCKETS — no trade."
    else
        echo "Weather: no trade opportunity."
    fi
fi