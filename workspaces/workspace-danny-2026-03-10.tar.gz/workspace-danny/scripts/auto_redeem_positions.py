#!/usr/bin/env python3
"""
Auto-redeem winning Polymarket positions via Simmer SDK.
Calls auto_redeem() which scans positions and redeems any with redeemable: true
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime

# Add simmer-sdk to path if installed locally
try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("❌ simmer-sdk not installed. Installing...")
    os.system("pip install simmer-sdk -q")
    from simmer_sdk import SimmerClient

# Try env first, fallback to secrets file
API_KEY = os.environ.get("SIMMER_API_KEY", "")
if not API_KEY:
    secrets_path = Path("/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env")
    if secrets_path.exists():
        with open(secrets_path) as f:
            for line in f:
                if line.strip().startswith("SIMMER_API_KEY="):
                    API_KEY = line.strip().split("=", 1)[1].split()[0]  # Handle comments
                    break
    
if not API_KEY:
    print("❌ SIMMER_API_KEY not set")
    print("Source: /home/agent/.openclaw/workspace-danny/.openclaw/secrets.env")
    sys.exit(1)

print("=" * 60)
print("🔄 SIMMER AUTO-REDEEM")
print("=" * 60)
print(f"Timeout: 120 seconds per position")
print()

# Initialize client with Polymarket venue
client = SimmerClient(
    api_key=API_KEY,
    venue="polymarket"
)

# Get portfolio first to see positions
print("📊 Checking portfolio...")
try:
    portfolio = client.get_portfolio()
    print(f"   Balance: ${portfolio.get('balance', 0):.2f}")
    print(f"   Exposure: ${portfolio.get('exposure', 0):.2f}")
    print()
except Exception as e:
    print(f"   ⚠️ Could not fetch portfolio: {e}")

# Get positions
print("📋 Checking positions for redemption...")
try:
    positions = client.get_positions()
    redeemable = [p for p in positions if p.get('redeemable', False)]
    print(f"   Total positions: {len(positions)}")
    print(f"   Redeemable: {len(redeemable)}")
    print()
    
    if redeemable:
        print("Positions ready to redeem:")
        for p in redeemable[:5]:
            q = p.get('question', 'Unknown')[:50]
            side = p.get('side', '?').upper()
            value = p.get('current_value', 0)
            print(f"   • {q} | {side} | ${value:.2f}")
        if len(redeemable) > 5:
            print(f"   ... and {len(redeemable) - 5} more")
        print()
except Exception as e:
    print(f"   ⚠️ Could not fetch positions: {e}")
    redeemable = []

# Run redemption
print("🎯 Executing redemption...")
print("   (Redeeming each redeemable position)")
print("-" * 60)

try:
    # Import socket to extend timeout if needed
    import socket
    original_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(120)  # 120 seconds per redemption
    
    results = []
    for p in redeemable:
        market_id = p.get('market_id')
        side = p.get('side')  # 'yes' or 'no'
        question = p.get('question', 'Unknown')[:50]
        value = p.get('current_value', 0)
        
        print(f"\nRedeeming: {question}")
        print(f"  Market ID: {market_id}")
        print(f"  Side: {side.upper()}")
        print(f"  Value: ${value:.2f}")
        
        try:
            result = client.redeem(market_id, side)
            result['market_id'] = market_id
            result['side'] = side
            results.append(result)
            if result.get('success'):
                print(f"  ✅ Success: tx {result.get('tx_hash', 'N/A')[:20]}...")
            else:
                print(f"  ❌ Failed: {result.get('error', 'Unknown error')}")
        except Exception as e:
            print(f"  ❌ Exception: {e}")
            results.append({
                'market_id': market_id,
                'side': side,
                'success': False,
                'error': str(e)
            })
    
    socket.setdefaulttimeout(original_timeout)
    
    print()
    print("=" * 60)
    print("📈 REDEMPTION RESULTS")
    print("=" * 60)
    
    successful = sum(1 for r in results if r.get('success'))
    failed = len(results) - successful
    total_redeemed = sum(r.get('amount', 0) for r in results if r.get('success'))
    
    for r in results:
        if r.get('success'):
            print(f"✅ {r.get('market_id', 'N/A')[:8]}...")
            print(f"   Side: {r.get('side', '?').upper()}")
            print(f"   Amount: ${r.get('amount', 0):.2f}")
            print(f"   Tx: {r.get('tx_hash', 'N/A')[:20]}...")
            print()
        else:
            print(f"❌ Failed: {r.get('market_id', 'N/A')}")
            print(f"   Error: {r.get('error', 'Unknown error')}")
            print()
    
    print("=" * 60)
    print(f"SUMMARY: {successful} redeemed, {failed} failed")
    print(f"TOTAL CLAIMED: ${total_redeemed:.2f}")
    print("=" * 60)
    
    # Save results
    result_file = "/home/agent/.openclaw/workspace-danny/logs/redeem_results.json"
    with open(result_file, "w") as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "successful": successful,
            "failed": failed,
            "total_redeemed": total_redeemed,
            "results": results
        }, f, indent=2, default=str)
    print(f"\n💾 Results saved to: {result_file}")
    
except Exception as e:
    print(f"\n❌ Redemption failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
