#!/usr/bin/env python3
"""
Redeem winning Polymarket positions using Simmer SDK.
Uses get_market_context to check each market from trades.json.
"""
import os
import sys
import json
import time
from pathlib import Path
from datetime import datetime

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("❌ simmer-sdk not installed. Installing...")
    os.system("pip install simmer-sdk -q")
    from simmer_sdk import SimmerClient

# Configuration
API_KEY = os.environ.get('SIMMER_API_KEY')
if not API_KEY:
    # Try to read from secrets.env
    secrets_path = Path.home() / '.openclaw' / 'workspace-danny' / '.openclaw' / 'secrets.env'
    if secrets_path.exists():
        with open(secrets_path) as f:
            for line in f:
                if line.startswith('SIMMER_API_KEY='):
                    API_KEY = line.strip().split('=', 1)[1]
                    break
    if not API_KEY:
        print("❌ SIMMER_API_KEY not set")
        sys.exit(1)

TRADES_PATH = Path('/home/agent/.openclaw/workspace/skills/prediction-trade-journal/data/trades.json')
OUTPUT_PATH = Path('/home/agent/.openclaw/workspace-danny/logs/redeem_positions.json')
LOG_PATH = Path('/home/agent/.openclaw/workspace-danny/logs/redeem_positions.log')

# Ensure logs directory exists
LOG_PATH.parent.mkdir(exist_ok=True)

def log(msg):
    timestamp = datetime.now().isoformat()
    full_msg = f"[{timestamp}] {msg}"
    print(full_msg)
    with open(LOG_PATH, 'a') as f:
        f.write(full_msg + '\n')

def main():
    log("=" * 60)
    log("🔍 REDEMPTION SCAN STARTED")
    log("=" * 60)
    
    # Load trades
    if not TRADES_PATH.exists():
        log(f"❌ Trades file not found: {TRADES_PATH}")
        sys.exit(1)
    
    with open(TRADES_PATH) as f:
        trades_data = json.load(f)
    
    trades = trades_data.get('trades', [])
    log(f"Loaded {len(trades)} trades from journal")
    
    # Group by market_id (multiple trades on same market)
    markets = {}
    for trade in trades:
        market_id = trade.get('market_id')
        if not market_id:
            continue
        if market_id not in markets:
            markets[market_id] = {
                'question': trade.get('market_question', 'Unknown'),
                'trades': [],
                'total_cost': 0,
                'sides': set()
            }
        markets[market_id]['trades'].append(trade)
        markets[market_id]['total_cost'] += trade.get('cost', 0)
        markets[market_id]['sides'].add(trade.get('side'))
    
    log(f"Unique markets: {len(markets)}")
    
    # Initialize client
    client = SimmerClient(api_key=API_KEY, venue='simmer')
    
    redeemable = []
    resolved_losing = []
    unresolved = []
    errors = []
    
    # Check each market
    for i, (market_id, info) in enumerate(markets.items(), 1):
        question = info['question'][:60]
        log(f"\n[{i}/{len(markets)}] Checking: {question}")
        log(f"  Market ID: {market_id}")
        log(f"  Trades: {len(info['trades'])}, Cost: ${info['total_cost']:.2f}")
        log(f"  Sides: {', '.join(info['sides'])}")
        
        try:
            # Timeout protection
            import signal
            
            class TimeoutException(Exception):
                pass
            
            def timeout_handler(signum, frame):
                raise TimeoutException("Market context request timed out")
            
            signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(30)  # 30 second timeout
            
            context = client.get_market_context(market_id)
            signal.alarm(0)  # Disable alarm
            
            market = context.get('market', {})
            position = context.get('position', {})
            
            status = market.get('status', 'unknown')
            prob = market.get('current_probability')
            has_position = position.get('has_position', False)
            
            log(f"  Status: {status}")
            log(f"  Probability YES: {prob}")
            log(f"  Has position: {has_position}")
            
            if has_position:
                pos_side = position.get('side')
                pos_value = position.get('current_value', 0)
                pos_pnl = position.get('unrealized_pnl', 0)
                log(f"  Position side: {pos_side}")
                log(f"  Current value: ${pos_value:.2f}")
                log(f"  P&L: ${pos_pnl:.2f}")
            
            # Determine if redeemable
            if status == 'resolved' and has_position:
                # Determine winning side
                if prob == 1.0:
                    winning_side = 'yes'
                elif prob == 0.0:
                    winning_side = 'no'
                else:
                    winning_side = None
                
                # Check if any of our trades match winning side
                our_sides = info['sides']
                if winning_side in our_sides:
                    redeemable.append({
                        'market_id': market_id,
                        'question': question,
                        'winning_side': winning_side,
                        'position_value': position.get('current_value', 0),
                        'position_pnl': position.get('unrealized_pnl', 0),
                        'context': context
                    })
                    log(f"  🎯 WINNING POSITION - Redeemable!")
                else:
                    resolved_losing.append(market_id)
                    log(f"  ❌ Losing position (winning side: {winning_side})")
            else:
                unresolved.append(market_id)
                log(f"  ⏳ Not resolved or no position")
                
        except TimeoutException:
            log(f"  ⚠️ Timeout fetching market context")
            errors.append(market_id)
        except Exception as e:
            log(f"  ❌ Error: {e}")
            errors.append(market_id)
        
        # Small delay between requests
        time.sleep(1)
    
    log("\n" + "=" * 60)
    log("📊 SCAN RESULTS")
    log("=" * 60)
    log(f"Total markets checked: {len(markets)}")
    log(f"Redeemable positions: {len(redeemable)}")
    log(f"Resolved losing positions: {len(resolved_losing)}")
    log(f"Unresolved markets: {len(unresolved)}")
    log(f"Errors: {len(errors)}")
    
    # Redeem winning positions
    if redeemable:
        log("\n" + "=" * 60)
        log("💰 REDEEMING WINNING POSITIONS")
        log("=" * 60)
        
        redemption_results = []
        total_redeemed = 0.0
        
        for item in redeemable:
            market_id = item['market_id']
            question = item['question']
            winning_side = item['winning_side']
            
            log(f"\nRedeeming: {question}")
            log(f"  Market ID: {market_id}")
            log(f"  Side: {winning_side}")
            
            try:
                result = client.redeem(market_id, winning_side)
                result['market_id'] = market_id
                result['question'] = question
                redemption_results.append(result)
                
                if result.get('success'):
                    amount = result.get('amount', 0)
                    total_redeemed += amount
                    tx_hash = result.get('tx_hash', 'N/A')[:20]
                    log(f"  ✅ Success!")
                    log(f"  Amount: ${amount:.2f}")
                    log(f"  Tx: {tx_hash}...")
                else:
                    log(f"  ❌ Failed: {result.get('error', 'Unknown error')}")
                    
            except Exception as e:
                log(f"  ❌ Exception: {e}")
                redemption_results.append({
                    'market_id': market_id,
                    'success': False,
                    'error': str(e)
                })
            
            time.sleep(2)  # Delay between redemptions
        
        log("\n" + "=" * 60)
        log("📈 REDEMPTION SUMMARY")
        log("=" * 60)
        log(f"Total redeemed: ${total_redeemed:.2f}")
        log(f"Successful: {sum(1 for r in redemption_results if r.get('success'))}")
        log(f"Failed: {sum(1 for r in redemption_results if not r.get('success'))}")
        
        # Save detailed results
        output_data = {
            'timestamp': datetime.now().isoformat(),
            'total_redeemed': total_redeemed,
            'redeemable_count': len(redeemable),
            'redemption_results': redemption_results,
            'redeemable_items': redeemable,
            'resolved_losing': resolved_losing,
            'unresolved': unresolved,
            'errors': errors
        }
        
        with open(OUTPUT_PATH, 'w') as f:
            json.dump(output_data, f, indent=2, default=str)
        
        log(f"\n💾 Results saved to: {OUTPUT_PATH}")
    else:
        log("\nNo redeemable positions found.")
        # Still save scan results
        output_data = {
            'timestamp': datetime.now().isoformat(),
            'redeemable_count': 0,
            'redeemable_items': [],
            'resolved_losing': resolved_losing,
            'unresolved': unresolved,
            'errors': errors
        }
        with open(OUTPUT_PATH, 'w') as f:
            json.dump(output_data, f, indent=2, default=str)
    
    log("\n" + "=" * 60)
    log("✅ REDEMPTION SCAN COMPLETE")
    log("=" * 60)

if __name__ == '__main__':
    main()