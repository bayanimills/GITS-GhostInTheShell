#!/usr/bin/env python3
"""
Check and redeem winning Polymarket positions using direct Simmer API.
Bypasses SDK to avoid hanging issues, uses strict timeouts.
"""
import os
import sys
import json
import time
import signal
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import requests
from requests.exceptions import Timeout, RequestException

# Configuration
API_KEY = 'sk_live_a20bb67064b7db925e7f8c854de2e91e4ffc3ef495acd91f5f170d9eb6224671'
BASE_URL = 'https://api.simmer.markets/api/sdk'

TRADES_PATH = Path('/home/agent/.openclaw/workspace/skills/prediction-trade-journal/data/trades.json')
OUTPUT_DIR = Path('/home/agent/.openclaw/workspace-danny/logs')
LOG_PATH = OUTPUT_DIR / 'check_and_redeem.log'
RESULTS_PATH = OUTPUT_DIR / 'check_and_redeem_results.json'

# Timeouts (seconds)
MARKET_TIMEOUT = 15
REDEEM_TIMEOUT = 30
REQUEST_DELAY = 1.5  # between API calls

# Headers
HEADERS = {
    'Authorization': f'Bearer {API_KEY}',
    'Content-Type': 'application/json',
    'User-Agent': 'DannyTrader/1.0'
}

def log(msg: str, level: str = 'INFO'):
    """Log message to file and stdout."""
    timestamp = datetime.now().isoformat()[:19]
    full_msg = f"[{timestamp} {level}] {msg}"
    print(full_msg)
    with open(LOG_PATH, 'a', encoding='utf-8') as f:
        f.write(full_msg + '\n')

def load_trades() -> List[Dict]:
    """Load trades from journal."""
    if not TRADES_PATH.exists():
        log(f"Trades file not found: {TRADES_PATH}", 'ERROR')
        return []
    try:
        with open(TRADES_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        trades = data.get('trades', [])
        log(f"Loaded {len(trades)} trades from journal")
        return trades
    except Exception as e:
        log(f"Failed to load trades: {e}", 'ERROR')
        return []

def group_trades_by_market(trades: List[Dict]) -> Dict[str, Dict]:
    """Group trades by market_id, collect sides and total cost."""
    markets = {}
    for trade in trades:
        market_id = trade.get('market_id')
        if not market_id:
            continue
        if market_id not in markets:
            markets[market_id] = {
                'question': trade.get('market_question', 'Unknown'),
                'trades': [],
                'sides': set(),
                'total_cost': 0.0,
                'trade_ids': []
            }
        markets[market_id]['trades'].append(trade)
        markets[market_id]['sides'].add(trade.get('side'))
        markets[market_id]['total_cost'] += trade.get('cost', 0.0)
        markets[market_id]['trade_ids'].append(trade.get('id'))
    return markets

def check_market(market_id: str) -> Optional[Dict]:
    """Check market status via direct API with timeout."""
    url = f"{BASE_URL}/markets/{market_id}"
    try:
        # Use signal for timeout
        def timeout_handler(signum, frame):
            raise TimeoutError(f"Market check timeout after {MARKET_TIMEOUT}s")
        
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(MARKET_TIMEOUT)
        
        response = requests.get(url, headers=HEADERS, timeout=MARKET_TIMEOUT, verify=False)
        signal.alarm(0)  # Disable alarm
        
        if response.status_code == 200:
            data = response.json()
            return data.get('market', {})
        elif response.status_code == 404:
            log(f"Market {market_id} not found in Simmer (404)", 'WARN')
            return None
        else:
            log(f"Market check failed: HTTP {response.status_code} - {response.text[:100]}", 'WARN')
            return None
    except TimeoutError as e:
        log(f"Market check timeout: {market_id} - {e}", 'WARN')
        return None
    except Exception as e:
        log(f"Market check error: {market_id} - {e}", 'WARN')
        return None

def redeem_position(market_id: str, side: str) -> Dict:
    """Attempt to redeem a winning position."""
    url = f"{BASE_URL}/redeem"
    payload = {
        "market_id": market_id,
        "side": side
    }
    try:
        # Timeout for redemption (longer)
        def timeout_handler(signum, frame):
            raise TimeoutError(f"Redemption timeout after {REDEEM_TIMEOUT}s")
        
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(REDEEM_TIMEOUT)
        
        response = requests.post(url, headers=HEADERS, json=payload, timeout=REDEEM_TIMEOUT, verify=False)
        signal.alarm(0)
        
        if response.status_code == 200:
            return response.json()
        else:
            return {
                'success': False,
                'error': f"HTTP {response.status_code}: {response.text[:200]}"
            }
    except TimeoutError as e:
        return {'success': False, 'error': f"Timeout: {e}"}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def update_trade_outcome(trade_id: str, outcome_data: Dict) -> bool:
    """Update a single trade in the journal with outcome data."""
    try:
        with open(TRADES_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        trades = data.get('trades', [])
        updated = False
        for trade in trades:
            if trade.get('id') == trade_id:
                if 'outcome' not in trade:
                    trade['outcome'] = {}
                trade['outcome'].update(outcome_data)
                updated = True
                break
        
        if updated:
            with open(TRADES_PATH, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
            log(f"Updated trade {trade_id} with outcome", 'INFO')
            return True
    except Exception as e:
        log(f"Failed to update trade {trade_id}: {e}", 'ERROR')
    return False

def main():
    """Main execution."""
    # Ensure output dir exists
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    log("=" * 70)
    log("🚀 CHECK AND REDEEM STARTED")
    log("=" * 70)
    
    # Load and group trades
    trades = load_trades()
    if not trades:
        log("No trades to process, exiting.", 'INFO')
        sys.exit(0)
    
    markets = group_trades_by_market(trades)
    log(f"Processing {len(markets)} unique markets")
    
    # Results tracking
    results = {
        'timestamp': datetime.now().isoformat(),
        'markets_checked': 0,
        'markets_resolved': 0,
        'markets_winning': 0,
        'redeem_attempts': 0,
        'redeem_success': 0,
        'redeem_failed': 0,
        'total_redeemed': 0.0,
        'details': []
    }
    
    # Process each market
    for i, (market_id, info) in enumerate(markets.items(), 1):
        question = info['question'][:60]
        sides = list(info['sides'])
        total_cost = info['total_cost']
        
        log(f"\n[{i}/{len(markets)}] {question}")
        log(f"  Market ID: {market_id}")
        log(f"  Sides: {sides}, Cost: ${total_cost:.2f}")
        
        # Check market status
        log(f"  Checking market status...")
        market_data = check_market(market_id)
        time.sleep(REQUEST_DELAY)  # Be polite
        
        if not market_data:
            results['details'].append({
                'market_id': market_id,
                'status': 'check_failed',
                'error': 'Market check failed'
            })
            continue
        
        results['markets_checked'] += 1
        status = market_data.get('status')
        outcome = market_data.get('outcome')  # True = yes, False = no
        prob = market_data.get('current_probability')
        
        log(f"  Status: {status}, Outcome: {outcome}, Probability: {prob}")
        
        # Determine winning side
        winning_side = None
        if status == 'resolved':
            results['markets_resolved'] += 1
            if outcome is True:
                winning_side = 'yes'
            elif outcome is False:
                winning_side = 'no'
        
        # Check if we have winning position
        if winning_side and winning_side in sides:
            results['markets_winning'] += 1
            log(f"  🎯 WINNING SIDE: {winning_side}")
            
            # Attempt redemption for this side
            log(f"  Attempting redemption for side '{winning_side}'...")
            redeem_result = redeem_position(market_id, winning_side)
            time.sleep(REQUEST_DELAY)
            
            results['redeem_attempts'] += 1
            redeem_success = redeem_result.get('success', False)
            
            if redeem_success:
                results['redeem_success'] += 1
                amount = redeem_result.get('amount', 0.0)
                results['total_redeemed'] += amount
                tx_hash = redeem_result.get('tx_hash', '')
                log(f"  ✅ REDEEM SUCCESS!")
                log(f"    Amount: ${amount:.2f}")
                log(f"    Tx: {tx_hash[:20]}...")
                
                # Update trade journal for winning trades
                for trade in info['trades']:
                    if trade.get('side') == winning_side:
                        outcome_data = {
                            'resolved': True,
                            'winning_side': winning_side,
                            'pnl_usd': amount - trade.get('cost', 0.0),
                            'was_correct': True,
                            'redeemed_at': datetime.now().isoformat(),
                            'redeem_tx_hash': tx_hash
                        }
                        update_trade_outcome(trade.get('id'), outcome_data)
            else:
                results['redeem_failed'] += 1
                error = redeem_result.get('error', 'Unknown error')
                log(f"  ❌ REDEEM FAILED: {error}")
            
            # Record details
            results['details'].append({
                'market_id': market_id,
                'status': 'resolved_winning',
                'winning_side': winning_side,
                'redeem_success': redeem_success,
                'redeem_amount': redeem_result.get('amount') if redeem_success else None,
                'redeem_error': redeem_result.get('error') if not redeem_success else None
            })
            
        elif winning_side:
            # Resolved but we're on losing side
            log(f"  ❌ Losing position (winning side: {winning_side})")
            results['details'].append({
                'market_id': market_id,
                'status': 'resolved_losing',
                'winning_side': winning_side,
                'our_sides': sides
            })
            
            # Update trade journal for losing trades
            for trade in info['trades']:
                outcome_data = {
                    'resolved': True,
                    'winning_side': winning_side,
                    'pnl_usd': -trade.get('cost', 0.0),  # Lost entire cost
                    'was_correct': False,
                    'redeemed_at': None
                }
                update_trade_outcome(trade.get('id'), outcome_data)
                
        else:
            # Not resolved or unknown outcome
            log(f"  ⏳ Not resolved or unknown outcome")
            results['details'].append({
                'market_id': market_id,
                'status': status,
                'outcome': outcome
            })
    
    # Save results
    with open(RESULTS_PATH, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, default=str)
    
    log("\n" + "=" * 70)
    log("📊 FINAL RESULTS")
    log("=" * 70)
    log(f"Markets checked: {results['markets_checked']}")
    log(f"Markets resolved: {results['markets_resolved']}")
    log(f"Markets winning: {results['markets_winning']}")
    log(f"Redemption attempts: {results['redeem_attempts']}")
    log(f"Redemption successes: {results['redeem_success']}")
    log(f"Redemption failures: {results['redeem_failed']}")
    log(f"Total redeemed: ${results['total_redeemed']:.2f}")
    log(f"Results saved to: {RESULTS_PATH}")
    log("=" * 70)
    
    # Exit code based on success
    if results['redeem_success'] > 0:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    # Disable SSL warnings for now
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    try:
        main()
    except KeyboardInterrupt:
        log("Interrupted by user", 'WARN')
        sys.exit(130)
    except Exception as e:
        log(f"Unexpected error: {e}", 'ERROR')
        import traceback
        traceback.print_exc()
        sys.exit(1)