#!/bin/bash
set -e
cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
fi

cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

echo "=== Testing --smart-sizing only (with 1min expiry) ==="
timeout 30 python3 mert_sniper.py --dry-run --smart-sizing --expiry 1 2>&1 | head -100

echo -e "\n=== Testing --expiry 60 only (no smart-sizing) ==="
timeout 30 python3 mert_sniper.py --dry-run --expiry 60 2>&1 | head -100