#!/usr/bin/env python3
import sys
import os

# Load API key
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

if not api_key:
    print("❌ SIMMER_API_KEY not found")
    sys.exit(1)

os.environ["SIMMER_API_KEY"] = api_key

# Add skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

# Import the function from the script
sys.path.insert(0, "/home/agent/.openclaw/workspace-danny/scripts")
try:
    from mert_sniper_counter import fetch_markets, get_client
except ImportError as e:
    print(f"Import error: {e}")
    sys.exit(1)

print("Testing fetch_markets with no filter...")
markets = fetch_markets()
print(f"  Total markets: {len(markets)}")
if markets:
    m = markets[0]
    print(f"  Sample market keys: {list(m.keys())}")
    print(f"  ID: {m.get('id')}")
    print(f"  Question: {m.get('question')[:60]}...")
    print(f"  Probability: {m.get('current_probability')}")

print("\nTesting fetch_markets with filter 'bitcoin'...")
markets2 = fetch_markets("bitcoin")
print(f"  Filtered markets: {len(markets2)}")
if markets2:
    m = markets2[0]
    print(f"  ID: {m.get('id')}")
    print(f"  Question: {m.get('question')[:60]}...")

print("\nTesting SDK client methods directly...")
client = get_client()
print("  get_markets:", len(client.get_markets(status='active', limit=5)))
print("  find_markets('bitcoin'):", len(client.find_markets(query='bitcoin')))

print("\n✅ Test completed.")