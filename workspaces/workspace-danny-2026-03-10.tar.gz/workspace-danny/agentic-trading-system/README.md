# Agentic Prediction Market Trading System

**Version:** 1.0.0  
**Architecture:** 5-Layer Agentic Stack  
**Primary Exchange:** Polymarket CLOB  
**Status:** Implementation Phase

## Architecture Overview

```
Layer 0: Data Ingestion (Streaming + Storage)
Layer 1: Research Agents (Orchestrator + Specialists)
Layer 2: Signal Generation (Alpha + Validation)
Layer 3: Portfolio & Risk Management
Layer 4: Execution Engine (CLOB + Fill Management)
Layer 5: Monitoring & Learning (Closed Feedback Loop)
```

## Quick Start

```bash
# Start the system
cd /home/agent/.openclaw/workspace-danny/agentic-trading-system
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Start data ingestion
python3 layer0/ingestion_daemon.py &

# Start research agents
python3 layer1/orchestrator.py &

# Start signal generation
python3 layer2/signal_engine.py &

# Start portfolio manager
python3 layer3/portfolio_manager.py &

# Start execution engine
python3 layer4/execution_agent.py &

# Start monitoring
python3 layer5/monitor_daemon.py
```

## System Components

See individual layer READMEs for detailed documentation.
