#!/bin/bash
set -e
echo "=== Testing cron job parameters at $(date) ==="

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
    echo "✓ Loaded secrets.env"
fi

echo "=== Testing with cron job parameters (DRY RUN) ==="
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

# Exact same command as cron but with --dry-run instead of --live
echo "Command: python3 mert_sniper.py --dry-run --smart-sizing --expiry 60 --set min_split=0.65"
echo "---"

timeout 45 python3 mert_sniper.py --dry-run --smart-sizing --expiry 60 --set min_split=0.65 2>&1

echo "=== Test completed at $(date) ==="