#!/usr/bin/env python3
import os
import sys
import requests
from datetime import datetime

# Load environment variables from secrets file
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found in environment")
    sys.exit(1)

print(f"Testing Simmer API connectivity at {datetime.now().isoformat()}")
print(f"API Key length: {len(api_key)} characters")
print(f"API Key prefix: {api_key[:10]}...")

# Test basic API endpoint
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

try:
    print("\n1. Testing API connection...")
    response = requests.get(
        "https://api.simmer.markets/api/sdk/markets",
        headers=headers,
        params={"limit": 1},
        timeout=10
    )
    print(f"   Status Code: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"   Success! Found {len(data.get('markets', []))} markets")
        if data.get('markets'):
            market = data['markets'][0]
            print(f"   Sample market: {market.get('title', 'Unknown')}")
    else:
        print(f"   Error: {response.text[:200]}")
        
except requests.exceptions.Timeout:
    print("   ERROR: Request timed out after 10 seconds")
except requests.exceptions.ConnectionError as e:
    print(f"   ERROR: Connection failed: {e}")
except Exception as e:
    print(f"   ERROR: {type(e).__name__}: {e}")

# Test with the Simmer SDK if available
try:
    print("\n2. Testing Simmer SDK...")
    from simmer import SimmerClient
    print("   SDK imported successfully")
    
    client = SimmerClient(api_key=api_key, venue="polymarket")
    print("   Client created successfully")
    
    # Try a simple call with timeout
    import signal
    def timeout_handler(signum, frame):
        raise TimeoutError("SDK call timed out")
    
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(15)  # 15 second timeout
    
    try:
        markets = client.get_markets(limit=1)
        signal.alarm(0)  # Cancel alarm
        print(f"   SDK call successful: {len(markets)} markets")
    except TimeoutError:
        print("   ERROR: SDK call timed out after 15 seconds")
    except Exception as e:
        print(f"   ERROR in SDK call: {type(e).__name__}: {e}")
        
except ImportError:
    print("   Simmer SDK not available")
except Exception as e:
    print(f"   ERROR initializing SDK: {type(e).__name__}: {e}")

print(f"\nTest completed at {datetime.now().isoformat()}")