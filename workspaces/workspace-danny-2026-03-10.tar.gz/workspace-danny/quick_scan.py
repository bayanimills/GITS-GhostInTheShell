#!/usr/bin/env python3
import os
import sys
from datetime import datetime, timezone, timedelta

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

from simmer_sdk import SimmerClient
client = SimmerClient(api_key=api_key)

print("Fetching active markets...")
markets = client.get_markets(limit=50, status='active')
print(f"Total active markets: {len(markets)}")

now = datetime.now(timezone.utc)
threshold = now + timedelta(minutes=120)
print(f"Now UTC: {now}")
print(f"Expiry threshold (UTC): {threshold}")

for m in markets:
    expiry = m.expires_at
    if not expiry:
        continue
    if expiry < threshold:
        prob = m.current_probability
        if prob <= 0.45:
            side = "YES" if prob <= 0.45 else "NO"
            print(f"  {m.id}: {m.question[:60]}...")
            print(f"    Expires: {expiry} ({(expiry - now).total_seconds() / 60:.1f} min)")
            print(f"    Probability: {prob:.1%} (side {side})")