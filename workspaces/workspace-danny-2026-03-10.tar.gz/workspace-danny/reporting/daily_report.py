#!/usr/bin/env python3
"""
Daily report generator for trading bots.
"""
import os
import sys
import json
from datetime import datetime, timedelta
from pathlib import Path

WORKSPACE = Path("/home/agent/.openclaw/workspace-danny")
REPORT_DIR = WORKSPACE / "reporting"
STATE_FILE = REPORT_DIR / "report_state.json"

# Add current directory to path for imports
sys.path.insert(0, str(REPORT_DIR))
from parser import generate_report

try:
    from simmer_sdk import SimmerClient
except ImportError:
    SimmerClient = None

def load_simmer_api_key() -> str:
    """Load SIMMER_API_KEY from secrets.env or environment."""
    # Try environment first
    key = os.environ.get("SIMMER_API_KEY")
    if key:
        return key
    # Try secrets.env
    secrets_path = WORKSPACE / ".openclaw" / "secrets.env"
    if secrets_path.exists():
        with open(secrets_path, 'r') as f:
            for line in f:
                if line.startswith("SIMMER_API_KEY="):
                    return line.strip().split('=', 1)[1]
    return None

def get_portfolio_summary() -> dict:
    """Fetch current portfolio balance and exposure."""
    if SimmerClient is None:
        return {"error": "simmer_sdk not available"}
    
    api_key = load_simmer_api_key()
    if not api_key:
        return {"error": "SIMMER_API_KEY not found"}
    
    try:
        client = SimmerClient(api_key=api_key, venue="polymarket")
        portfolio = client.get_portfolio()
        # Extract relevant fields
        return {
            "balance_usdc": portfolio.get("balance_usdc", 0),
            "balance_sim": portfolio.get("balance_sim", 0),
            "positions_count": portfolio.get("positions_count", 0),
            "exposure_usdc": portfolio.get("exposure_usdc", 0),
            "exposure_sim": portfolio.get("exposure_sim", 0),
            "total_value_usdc": portfolio.get("total_value_usdc", 0),
            "pnl_usdc": portfolio.get("pnl_usdc", 0),
            "pnl_sim": portfolio.get("pnl_sim", 0),
        }
    except Exception as e:
        return {"error": str(e)}

def load_report_state() -> dict:
    """Load last report timestamp and optionally cached data."""
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {
        "last_report_at": None,
        "last_portfolio": None,
    }

def save_report_state(state: dict):
    """Save report state."""
    STATE_FILE.parent.mkdir(exist_ok=True)
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def format_human_report(report: dict, portfolio: dict, period_hours: int = 24) -> str:
    """Generate a human-readable summary."""
    lines = []
    lines.append(f"📊 Trading Bot Report — Last {period_hours}h")
    lines.append(f"Generated: {report['generated_at']}")
    lines.append("")
    
    # Portfolio snapshot
    if "error" in portfolio:
        lines.append(f"⚠️ Portfolio fetch error: {portfolio['error']}")
    else:
        lines.append("💰 Portfolio Snapshot")
        lines.append(f"  Balance: ${portfolio.get('balance_usdc', 0):.2f} USDC")
        lines.append(f"  Exposure: ${portfolio.get('exposure_usdc', 0):.2f} USDC")
        lines.append(f"  Positions: {portfolio.get('positions_count', 0)}")
        lines.append(f"  Total Value: ${portfolio.get('total_value_usdc', 0):.2f} USDC")
        lines.append(f"  P&L: ${portfolio.get('pnl_usdc', 0):.2f} USDC")
        lines.append("")
    
    # Bot activity summary
    agg = report['aggregated']
    lines.append("🤖 Bot Activity")
    lines.append(f"  Total runs: {agg['total_runs']}")
    lines.append(f"  Total trades: {agg['total_trades']}")
    lines.append(f"  Markets scanned: {agg['total_markets_scanned']}")
    lines.append("")
    
    # Per‑bot breakdown
    lines.append("📈 Per‑Bot Breakdown")
    for bot_name, bot_data in agg['bots'].items():
        runs = bot_data['runs']
        trades = bot_data['trades']
        if bot_name.startswith('mert_sniper'):
            lines.append(f"  {bot_name}: {runs} runs, {trades} trades")
            if 'near_expiry' in bot_data:
                lines.append(f"    Near expiry: {bot_data['near_expiry']}")
            if 'strong_split' in bot_data:
                lines.append(f"    Strong splits: {bot_data['strong_split']}")
        elif bot_name == 'ai_divergence':
            lines.append(f"  {bot_name}: {runs} runs")
            lines.append(f"    Markets with divergence: {bot_data.get('markets_with_divergence', 0)}")
        elif bot_name in ('fastloop', 'weather'):
            lines.append(f"  {bot_name}: {runs} runs, {trades} trades")
    lines.append("")
    
    # Recent trades (if any)
    recent_trades = []
    for entry in report['entries']:
        metrics = entry['metrics']
        if 'trades' in metrics and metrics['trades']:
            for trade in metrics['trades']:
                recent_trades.append({
                    'timestamp': entry['timestamp'],
                    'bot': entry['bot'],
                    'side': trade.get('side'),
                    'shares': trade.get('shares'),
                    'price': trade.get('price'),
                })
    
    if recent_trades:
        lines.append("🎯 Recent Trades")
        for trade in recent_trades[-5:]:  # last 5 trades
            lines.append(f"  {trade['timestamp'][11:19]} {trade['bot']}: {trade['shares']:.1f} {trade['side']} @ ${trade['price']:.2f}")
        lines.append("")
    
    # Notable events
    if agg['total_trades'] == 0:
        lines.append("💤 No trades executed in this period.")
    
    lines.append("---")
    lines.append("Report generated by Danny's systematic reporting framework.")
    return "\n".join(lines)

def generate_daily_report(period_hours: int = 24, output_format: str = "text") -> dict:
    """Generate a complete report."""
    # Generate log‑based report
    report = generate_report(period_hours)
    
    # Fetch current portfolio
    portfolio = get_portfolio_summary()
    
    # Update state
    state = load_report_state()
    state["last_report_at"] = datetime.now().isoformat()
    state["last_portfolio"] = portfolio
    save_report_state(state)
    
    # Format output
    if output_format == "json":
        return {
            "report": report,
            "portfolio": portfolio,
            "state": state
        }
    else:
        text_report = format_human_report(report, portfolio, period_hours)
        return {"text": text_report}

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Generate trading bot report")
    parser.add_argument("--period", type=int, default=24, help="Period in hours (default: 24)")
    parser.add_argument("--format", choices=["text", "json"], default="text", help="Output format")
    parser.add_argument("--output", type=str, help="Output file (default: stdout)")
    args = parser.parse_args()
    
    result = generate_daily_report(period_hours=args.period, output_format=args.format)
    
    if args.format == "json":
        output = json.dumps(result, indent=2)
    else:
        output = result["text"]
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"Report written to {args.output}")
    else:
        print(output)

if __name__ == "__main__":
    main()