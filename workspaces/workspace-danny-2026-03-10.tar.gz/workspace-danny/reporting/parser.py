#!/usr/bin/env python3
"""
Parse bot logs and extract structured metrics for reporting.
"""
import os
import re
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

WORKSPACE = Path("/home/agent/.openclaw/workspace-danny")
LOG_DIR = WORKSPACE / "logs"

# Bot log file mappings
BOT_LOGS = {
    "mert_sniper": "mert_sniper_real.log",
    "mert_sniper_counter": "mert_sniper_counter.log",
    "ai_divergence": "ai_divergence_real.log",
    "fastloop": "fastloop_real.log",
    "weather": "weather_real.log",
}

def parse_timestamp(line: str) -> Optional[datetime]:
    """Parse timestamp from log separator line like '=== 2026‑m‑d HH:MM:SS ===' or '=== 2026-02-21 00:35:39 ==='"""
    # Match two formats: 2026‑m‑d or 2026-02-21 (note: dash could be hyphen or en dash)
    match = re.search(r'=== (\d{4})[‑\-](\d{1,2}|m)[‑\-](\d{1,2}|d) (\d{2}:\d{2}:\d{2}) ===', line)
    if not match:
        return None
    year = match.group(1)
    month_part = match.group(2)
    day_part = match.group(3)
    time_str = match.group(4)
    
    today = datetime.now()
    # Replace placeholder month/day with current month/day if needed
    month = month_part if month_part != 'm' else today.month
    day = day_part if day_part != 'd' else today.day
    
    try:
        month = int(month)
        day = int(day)
        return datetime(year=int(year), month=month, day=day, hour=int(time_str[0:2]), minute=int(time_str[3:5]), second=int(time_str[6:8]))
    except (ValueError, TypeError):
        # Fallback: use today's date with parsed time
        try:
            return datetime.strptime(f"{today.year}-{today.month}-{today.day} {time_str}", "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return None

def parse_mert_sniper_summary(lines: List[str]) -> Dict[str, Any]:
    """Extract summary metrics from Mert Sniper log segment."""
    metrics = {
        "markets_scanned": 0,
        "near_expiry": 0,
        "strong_split": 0,
        "trades_executed": 0,
        "trades": []
    }
    for line in lines:
        line = line.strip()
        if line.startswith("Markets scanned:"):
            try:
                metrics["markets_scanned"] = int(line.split(":")[1].strip())
            except:
                pass
        elif line.startswith("Near expiry:"):
            try:
                metrics["near_expiry"] = int(line.split(":")[1].strip())
            except:
                pass
        elif line.startswith("Strong split:"):
            try:
                metrics["strong_split"] = int(line.split(":")[1].strip())
            except:
                pass
        elif line.startswith("Trades executed:"):
            try:
                metrics["trades_executed"] = int(line.split(":")[1].strip())
            except:
                pass
        # Parse trade lines like "Bought 14.5 NO shares @ $0.76"
        trade_match = re.match(r'^\s*Bought ([\d.]+) (YES|NO) shares @ \$([\d.]+)', line)
        if trade_match:
            shares = float(trade_match.group(1))
            side = trade_match.group(2)
            price = float(trade_match.group(3))
            metrics["trades"].append({
                "shares": shares,
                "side": side,
                "price": price
            })
    return metrics

def parse_ai_divergence_summary(lines: List[str]) -> Dict[str, Any]:
    """Extract summary from AI Divergence log segment."""
    metrics = {
        "markets_with_divergence": 0,
        "total_markets": 0,
        "bullish": 0,
        "bearish": 0,
        "avg_divergence": 0.0,
        "opportunities": []
    }
    for line in lines:
        line = line.strip()
        # Example: Showing 1 of 1 markets with divergence
        match = re.search(r'Showing (\d+) of (\d+) markets with divergence', line)
        if match:
            metrics["markets_with_divergence"] = int(match.group(1))
            metrics["total_markets"] = int(match.group(2))
        # Summary line: Summary: 1 bullish, 0 bearish, avg divergence 8.0%
        match = re.search(r'Summary: (\d+) bullish, (\d+) bearish, avg divergence ([\d.]+)%', line)
        if match:
            metrics["bullish"] = int(match.group(1))
            metrics["bearish"] = int(match.group(2))
            metrics["avg_divergence"] = float(match.group(3))
        # Table rows: we could parse but skip for now
    return metrics

def parse_fastloop_summary(lines: List[str]) -> Dict[str, Any]:
    """FastLoop logs are more complex; for now just detect trades."""
    metrics = {
        "trades_executed": 0,
        "trades": []
    }
    # Simple detection: lines containing "BUY" or "SELL" with price
    for line in lines:
        if "BUY" in line or "SELL" in line:
            metrics["trades_executed"] += 1
            # Could parse details later
    return metrics

def parse_weather_summary(lines: List[str]) -> Dict[str, Any]:
    """Weather trader logs."""
    metrics = {
        "trades_executed": 0,
        "trades": []
    }
    # Simple detection
    for line in lines:
        if "BUY" in line or "SELL" in line or "filled" in line.lower():
            metrics["trades_executed"] += 1
    return metrics

def parse_log_file(bot_name: str, log_path: Path, since: datetime = None) -> List[Dict[str, Any]]:
    """Parse a log file and return list of run entries with timestamps."""
    if not log_path.exists():
        print(f"Log file not found: {log_path}")
        return []
    
    entries = []
    with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()
    
    current_segment = []
    segment_start = None
    in_segment = False
    
    for line in lines:
        # Check for timestamp separator
        ts = parse_timestamp(line)
        if ts is not None:
            # Save previous segment
            if in_segment and segment_start and (since is None or segment_start >= since):
                # Parse segment based on bot
                if bot_name.startswith("mert_sniper"):
                    metrics = parse_mert_sniper_summary(current_segment)
                elif bot_name == "ai_divergence":
                    metrics = parse_ai_divergence_summary(current_segment)
                elif bot_name == "fastloop":
                    metrics = parse_fastloop_summary(current_segment)
                elif bot_name == "weather":
                    metrics = parse_weather_summary(current_segment)
                else:
                    metrics = {}
                entries.append({
                    "timestamp": segment_start.isoformat(),
                    "bot": bot_name,
                    "metrics": metrics
                })
            # Start new segment
            current_segment = []
            segment_start = ts
            in_segment = True
        elif in_segment:
            current_segment.append(line)
    
    # Handle last segment
    if in_segment and segment_start and (since is None or segment_start >= since):
        if bot_name.startswith("mert_sniper"):
            metrics = parse_mert_sniper_summary(current_segment)
        elif bot_name == "ai_divergence":
            metrics = parse_ai_divergence_summary(current_segment)
        elif bot_name == "fastloop":
            metrics = parse_fastloop_summary(current_segment)
        elif bot_name == "weather":
            metrics = parse_weather_summary(current_segment)
        else:
            metrics = {}
        entries.append({
            "timestamp": segment_start.isoformat(),
            "bot": bot_name,
            "metrics": metrics
        })
    
    return entries

def aggregate_metrics(entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Aggregate metrics across multiple runs."""
    totals = {
        "total_runs": 0,
        "total_trades": 0,
        "total_markets_scanned": 0,
        "bots": {}
    }
    for entry in entries:
        bot = entry["bot"]
        if bot not in totals["bots"]:
            totals["bots"][bot] = {
                "runs": 0,
                "trades": 0,
                "markets_scanned": 0,
                "near_expiry": 0,
                "strong_split": 0,
                "markets_with_divergence": 0
            }
        bot_totals = totals["bots"][bot]
        bot_totals["runs"] += 1
        totals["total_runs"] += 1
        
        metrics = entry["metrics"]
        # Mert Sniper metrics
        if "markets_scanned" in metrics:
            bot_totals["markets_scanned"] += metrics.get("markets_scanned", 0)
            totals["total_markets_scanned"] += metrics.get("markets_scanned", 0)
        if "near_expiry" in metrics:
            bot_totals["near_expiry"] += metrics.get("near_expiry", 0)
        if "strong_split" in metrics:
            bot_totals["strong_split"] += metrics.get("strong_split", 0)
        if "trades_executed" in metrics:
            trades = metrics.get("trades_executed", 0)
            bot_totals["trades"] += trades
            totals["total_trades"] += trades
        # AI Divergence metrics
        if "markets_with_divergence" in metrics:
            bot_totals["markets_with_divergence"] += metrics.get("markets_with_divergence", 0)
    
    return totals

def generate_report(since_hours: int = 24) -> Dict[str, Any]:
    """Generate a report for the last N hours."""
    since = datetime.now() - timedelta(hours=since_hours)
    all_entries = []
    
    for bot_name, log_file in BOT_LOGS.items():
        log_path = LOG_DIR / log_file
        entries = parse_log_file(bot_name, log_path, since)
        all_entries.extend(entries)
    
    # Sort by timestamp
    all_entries.sort(key=lambda x: x["timestamp"])
    
    aggregated = aggregate_metrics(all_entries)
    
    report = {
        "generated_at": datetime.now().isoformat(),
        "period_hours": since_hours,
        "since": since.isoformat(),
        "entries": all_entries,
        "aggregated": aggregated
    }
    return report

if __name__ == "__main__":
    # Test: generate report for last 24h
    report = generate_report(24)
    print(json.dumps(report, indent=2))