# Systematic Reporting Framework

A lightweight framework for parsing bot logs, aggregating metrics, and generating regular reports.

## Components

### 1. Parser (`parser.py`)

Parses bot log files and extracts structured metrics.

**Supported bots:**
- `mert_sniper`, `mert_sniper_counter`
- `ai_divergence`
- `fastloop`
- `weather`

**Key metrics extracted:**
- Markets scanned, near expiry, strong splits
- Trades executed, trade details (side, shares, price)
- Markets with divergence, bullish/bearish counts
- Total runs per bot

**Usage:**
```python
from parser import generate_report
report = generate_report(period_hours=24)
```

### 2. Daily Report (`daily_report.py`)

Generates human‑readable or JSON reports combining log metrics and live portfolio data.

**Features:**
- Portfolio snapshot (balance, exposure, P&L)
- Bot activity summary (runs, trades, markets scanned)
- Per‑bot breakdown
- Recent trades (last 5)
- State persistence (last report timestamp)

**Command‑line interface:**
```bash
python3 daily_report.py --period 24 --format text
python3 daily_report.py --period 1 --format json --output report.json
```

**Portfolio data:** Automatically reads `SIMMER_API_KEY` from environment or `/.openclaw/secrets.env`.

### 3. Cron Integration

Two Gateway cron jobs are configured:

1. **Bot execution** – `run_mert_sniper_counter.sh` every 10 minutes (system cron)
2. **Scheduled reports** – 8 am & 8 pm Sydney time (Gateway cron)

To add a new scheduled report:
```bash
openclaw cron add --job-file report_job.json
```

Example job JSON (already added):
```json
{
  "name": "Danny Trading Report (8am/8pm)",
  "schedule": {
    "kind": "cron",
    "expr": "0 8,20 * * *",
    "tz": "Australia/Sydney"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "Run the daily trading report for the last 24 hours and output a concise summary."
  },
  "sessionTarget": "isolated",
  "delivery": {
    "mode": "announce"
  }
}
```

## Adding a New Bot

1. Ensure the bot writes logs to `logs/<bot_name>_real.log` with timestamp separators (`=== YYYY‑m‑d HH:MM:SS ===`).
2. Add the bot to `BOT_LOGS` in `parser.py`.
3. Implement a `parse_<bot>_summary()` function if the log format differs.
4. Update `aggregate_metrics()` to include any new metrics.

## Future Extensions

- **Trade alerts**: Real‑time detection of new trades and Telegram notifications.
- **Performance analytics**: Win/loss ratios, Sharpe ratio, maximum drawdown.
- **Comparative A/B testing**: Compare counter‑bot vs original Mert Sniper over rolling windows.
- **Dashboard**: Simple web UI showing live metrics (optional).

## Notes

- Log timestamps use placeholder month/day (`m`, `d`) for privacy; the parser substitutes current month/day.
- Portfolio exposure may show `0` when positions are expired (API discrepancy).
- The framework respects quiet‑hour suppression in wrapper scripts.

---

*Maintained by Danny – Market‑Trader Agent*