#!/usr/bin/env python3
import os
import sys
import json
import requests
from pathlib import Path

# Load secrets
secrets = Path('.openclaw/secrets.env')
if secrets.exists():
    with open(secrets) as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                k, v = line.strip().split('=', 1)
                os.environ[k] = v

api_key = os.environ.get('SIMMER_API_KEY')
if not api_key:
    print('SIMMER_API_KEY missing')
    sys.exit(1)

headers = {'Authorization': f'Bearer {api_key}'}

print('📊 Market Review')
print('='*60)

# 1. Current portfolio
print('\n1. Current Portfolio')
try:
    r = requests.get('https://api.simmer.markets/api/sdk/portfolio', headers=headers, timeout=15)
    r.raise_for_status()
    portfolio = r.json()
    print(f'   Balance: ${portfolio.get("balance_usdc", 0):.2f}')
    print(f'   Exposure: ${portfolio.get("total_exposure", 0):.2f}')
    print(f'   Positions count: {portfolio.get("positions_count", 0)}')
    print(f'   P&L total: ${portfolio.get("pnl_total", 0):.2f}')
except Exception as e:
    print(f'   Error: {e}')

# 2. Positions
print('\n2. Current Positions')
try:
    r = requests.get('https://api.simmer.markets/api/sdk/positions', headers=headers, timeout=15)
    r.raise_for_status()
    positions = r.json().get('positions', [])
    if positions:
        for p in positions:
            q = p.get('market_question', p.get('market_id', 'Unknown'))
            side = p.get('side', '?')
            shares = p.get('shares', 0)
            cost = p.get('cost_usdc', 0)
            value = p.get('value_usdc', 0)
            print(f'   - {q[:80]}...')
            print(f'     Side: {side}, Shares: {shares:.1f}, Cost: ${cost:.2f}, Value: ${value:.2f}')
    else:
        print('   No positions returned (may be expired)')
except Exception as e:
    print(f'   Error: {e}')

# 3. Markets with strong splits (≥60%/≤40%) expiring within 24h
print('\n3. Strong Split Opportunities (≥60%/≤40%, ≤24h expiry)')
try:
    params = {'status': 'active', 'limit': 200}
    r = requests.get('https://api.simmer.markets/api/sdk/markets', headers=headers, params=params, timeout=30)
    r.raise_for_status()
    markets = r.json().get('markets', [])
    
    strong = []
    for m in markets:
        price = m.get('current_probability', 0.5)
        mins = m.get('_minutes_remaining', 99999)
        if mins <= 1440:  # 24h
            if price >= 0.6 or price <= 0.4:
                strong.append((mins, price, m))
    
    strong.sort(key=lambda x: x[0])  # sort by expiry
    print(f'   Found {len(strong)} markets with strong splits expiring ≤24h')
    for mins, price, m in strong[:10]:  # top 10
        q = m.get('question', 'Unknown')
        print(f'   - {q[:70]}...')
        print(f'     Split: YES {price:.0%} / NO {1-price:.0%}, Expires: {mins//60}h {mins%60}m')
except Exception as e:
    print(f'   Error: {e}')

# 4. AI Divergence (from log)
print('\n4. AI Divergence Status')
log_path = Path('logs/ai_divergence_real.log')
if log_path.exists():
    with open(log_path) as f:
        lines = f.readlines()
        # Get last 5 runs
        last_runs = []
        for line in reversed(lines):
            if line.startswith('==='):
                last_runs.append(line.strip())
                if len(last_runs) >= 2:
                    break
        if last_runs:
            print(f'   Last run: {last_runs[-1]}')
            # Look for divergence lines in last run
            start_idx = None
            for i, line in enumerate(lines):
                if line.startswith('===') and line.strip() == last_runs[-1]:
                    start_idx = i
                    break
            if start_idx is not None:
                for line in lines[start_idx:]:
                    if 'divergence' in line.lower() and '>' in line:
                        print(f'   {line.strip()}')
else:
    print('   No AI Divergence log found')

print('\n' + '='*60)
print('Review complete.')