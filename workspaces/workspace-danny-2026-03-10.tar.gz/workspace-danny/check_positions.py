#!/usr/bin/env python3
import os
import json
from simmer_sdk import SimmerClient

api_key = os.environ.get('SIMMER_API_KEY')
if not api_key:
    api_key = 'sk_live_a20bb67064b7db925e7f8c854de2e91e4ffc3ef495acd91f5f170d9eb6224671'

client = SimmerClient(api_key=api_key, venue='polymarket')

print("Full portfolio response:")
portfolio = client.get_portfolio()
print(json.dumps(portfolio, indent=2))

print("\n\nChecking briefing API:")
try:
    briefing = client.get_briefing()
    print(json.dumps(briefing, indent=2))
except Exception as e:
    print(f"Error: {e}")

print("\n\nChecking if positions are resolved...")
# Maybe positions are resolved but still in count?
# Let's check recent trades via get_trades
try:
    trades = client.get_trades(limit=20)
    print(f"Recent trades: {len(trades)}")
    for i, trade in enumerate(trades[:10]):
        print(f"  {i+1}: {trade.get('market_question', 'Unknown')} - {trade.get('side')} @ {trade.get('price')}")
except Exception as e:
    print(f"Error getting trades: {e}")