#!/usr/bin/env python3
import os
import json
import requests

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

headers = {"Authorization": f"Bearer {api_key}"}
r = requests.get("https://api.simmer.markets/api/sdk/briefing", headers=headers, timeout=15)
r.raise_for_status()
data = r.json()

print("Briefing keys:", data.keys())
risk_alerts = data.get("risk_alerts", [])
if risk_alerts:
    print("RISK ALERTS:", json.dumps(risk_alerts, indent=2))
else:
    print("No risk alerts")

venues = data.get("venues", {})
for venue, vdata in venues.items():
    if vdata:
        print(f"{venue}: {vdata}")