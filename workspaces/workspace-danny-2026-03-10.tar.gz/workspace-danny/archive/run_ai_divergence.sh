#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/ai_divergence_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

# Run AI divergence scan with --min 10 threshold
cd /home/agent/.openclaw/workspace/skills/polymarket-ai-divergence
OUTPUT=$(python3 ai_divergence.py --min 10 2>&1)

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Check for opportunities
if echo "$OUTPUT" | grep -q "Showing.*of.*markets with divergence"; then
    # Extract count
    COUNT=$(echo "$OUTPUT" | grep "Showing.*of.*markets with divergence" | sed -E 's/.*Showing ([0-9]+) of ([0-9]+) markets.*/\1/')
    if [ "$COUNT" -gt 0 ]; then
        # Opportunities found
        if [[ "$QUIET" -eq 1 ]]; then
            # Quiet hours — stay silent (no output)
            exit 0
        else
            # Daytime — output full results
            echo "$OUTPUT"
        fi
        exit 0
    fi
fi

# No opportunities
if [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours — stay silent
    exit 0
else
    echo "No AI divergence opportunities >10% found."
fi