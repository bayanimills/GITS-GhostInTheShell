#!/usr/bin/env python3
import os
import sys
from simmer_sdk import SimmerClient

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
    if os.path.exists(secrets_path):
        with open(secrets_path, 'r') as f:
            for line in f:
                if line.startswith('SIMMER_API_KEY='):
                    api_key = line.strip().split('=', 1)[1]
                    break
    else:
        print("SIMMER_API_KEY not found")
        sys.exit(1)

client = SimmerClient(api_key=api_key)
markets = client.get_markets(limit=200, status='active')

fast_markets = []
for m in markets:
    q = m.question.lower()
    if 'fast' in q:
        fast_markets.append(m)

print(f"Total active markets: {len(markets)}")
print(f"Fast markets found: {len(fast_markets)}")
print()

if fast_markets:
    print("Fast markets:")
    for m in fast_markets[:20]:  # limit output
        print(f"  {m.id}: {m.question}")
        print(f"    YES: {m.current_probability:.3f}, NO: {1-m.current_probability:.3f}")
        print(f"    Slug: {m.slug}")
        print()
else:
    print("No fast markets detected.")
    
# Also check for "up or down" markets (regular)
updown = [m for m in markets if 'up or down' in m.question.lower()]
print(f"Up/Down markets (regular): {len(updown)}")
if updown:
    print("Sample:")
    for m in updown[:5]:
        print(f"  {m.question[:80]}...")
        print(f"    YES: {m.current_probability:.3f}")