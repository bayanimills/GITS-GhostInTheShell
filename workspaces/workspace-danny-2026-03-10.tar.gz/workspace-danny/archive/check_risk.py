#!/usr/bin/env python3
import os
import sys

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)
briefing = client._request("GET", "/api/sdk/briefing")
risk_alerts = briefing.get('risk_alerts', [])
print(f"Risk alerts: {len(risk_alerts)}")
for alert in risk_alerts:
    print(f"- {alert}")

# Check venue-specific alerts
venues = briefing.get('venues', {})
for venue, data in venues.items():
    if data and isinstance(data, dict):
        if data.get('risk_alerts'):
            print(f"\nVenue {venue} risk alerts:")
            for alert in data['risk_alerts']:
                print(f"  - {alert}")