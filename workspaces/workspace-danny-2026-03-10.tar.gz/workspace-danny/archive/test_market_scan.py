#!/usr/bin/env python3
import os
import sys
from datetime import datetime, timezone, timedelta

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

print("🔍 Market Scanning Examples")
print("=" * 60)

# Example 1: Get all active markets (limit 20)
print("\n1. client.get_markets(limit=20, status='active'):")
markets = client.get_markets(limit=20, status='active')
print(f"   Retrieved {len(markets)} markets")
for m in markets[:3]:
    print(f"   - {m.question[:60]}...")
    print(f"     Price: {m.current_probability:.2%}, Resolves: {m.resolves_at}")

# Example 2: Filter by tag using find_markets
print("\n2. client.find_markets(query='weather'):")
try:
    weather_markets = client.find_markets(query='weather')
    print(f"   Retrieved {len(weather_markets)} weather markets")
except Exception as e:
    print(f"   Error: {e}")

# Example 3: Manual filtering for near-expiry (like counter-bot)
print("\n3. Manual filter for near-expiry (<2 hours):")
now = datetime.now(timezone.utc)
near_expiry = []
for m in markets:
    if not hasattr(m, 'resolves_at') or not m.resolves_at:
        continue
    try:
        resolves = m.resolves_at
        if isinstance(resolves, str):
            # parse ISO string
            resolves = resolves.replace('Z', '+00:00')
            resolves_dt = datetime.fromisoformat(resolves)
            if resolves_dt.tzinfo is None:
                resolves_dt = resolves_dt.replace(tzinfo=timezone.utc)
        else:
            resolves_dt = resolves
        hours_to_res = (resolves_dt - now).total_seconds() / 3600
        if 0 < hours_to_res < 2:
            near_expiry.append((hours_to_res, m))
    except:
        continue

print(f"   Found {len(near_expiry)} markets expiring within 2 hours")
for hours, m in near_expiry[:3]:
    print(f"   - {m.question[:50]}...")
    print(f"     Price: {m.current_probability:.2%}, Hours: {hours:.1f}")

# Example 4: Get market context
print("\n4. client.get_market_context(market_id):")
if markets:
    market_id = markets[0].id
    try:
        context = client.get_market_context(market_id)
        print(f"   Context retrieved for market: {markets[0].question[:50]}...")
        print(f"   Position: {context.position}")
        print(f"   Warnings: {context.warnings}")
        print(f"   Hours to resolution: {context.hours_to_resolution}")
    except Exception as e:
        print(f"   Error: {e}")

print("\n" + "=" * 60)
print("✅ Market scanning works with SDK (v0.8.26).")
print("Note: Use object attributes (m.id, m.question) not dict keys.")