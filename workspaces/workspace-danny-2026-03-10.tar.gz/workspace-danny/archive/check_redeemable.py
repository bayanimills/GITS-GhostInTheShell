#!/usr/bin/env python3
import os
import sys

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

print("🔍 Checking for redeemable positions")
print("=" * 60)

# Get resolved markets (limit 10)
try:
    markets = client.get_markets(status='resolved', limit=10)
    print(f"Found {len(markets)} resolved markets")
    for m in markets:
        print(f"\nMarket: {m.question[:80]}...")
        print(f"  ID: {m.id}")
        print(f"  Outcome: {m.outcome}")
        print(f"  Resolved at: {m.resolves_at}")
        # Try to get context to see if redeemable
        try:
            ctx = client.get_market_context(m.id)
            if isinstance(ctx, dict):
                redeemable = ctx.get('redeemable', False)
                position = ctx.get('position', {})
                print(f"  Redeemable: {redeemable}")
                if position:
                    print(f"  Position: YES shares {position.get('shares_yes', 0)}, NO shares {position.get('shares_no', 0)}")
                else:
                    print(f"  Position: none")
            else:
                print(f"  Context type: {type(ctx)}")
        except Exception as e:
            print(f"  Context error: {e}")
except Exception as e:
    print(f"Error fetching resolved markets: {e}")

print("\n" + "=" * 60)