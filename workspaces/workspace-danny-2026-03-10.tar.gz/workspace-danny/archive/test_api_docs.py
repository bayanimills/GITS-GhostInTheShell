#!/usr/bin/env python3
"""
Test Simmer API endpoints as per documentation.
"""
import os
import sys
import json
from datetime import datetime, timezone

# Add skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

try:
    import simmer_sdk
except ImportError as e:
    print(f"❌ Failed to import simmer_sdk: {e}")
    sys.exit(1)

# Load API key from secrets.env
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if not os.path.exists(secrets_path):
    print(f"❌ secrets.env not found at {secrets_path}")
    sys.exit(1)

with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break
    else:
        print("❌ SIMMER_API_KEY not found in secrets.env")
        sys.exit(1)

print(f"✅ API key loaded (prefix: {api_key[:12]}...)")
print(f"📅 Current time: {datetime.now(timezone.utc).isoformat()}")
print("=" * 60)

# Initialize client
try:
    client = simmer_sdk.SimmerClient(api_key=api_key)
    print("✅ SimmerClient initialized")
except Exception as e:
    print(f"❌ SimmerClient initialization failed: {type(e).__name__}: {e}")
    sys.exit(1)

# Test 1: Briefing endpoint (heartbeat)
print("\n1. Testing GET /briefing endpoint...")
try:
    briefing = client.get_briefing()
    print(f"   ✅ Briefing retrieved at {briefing.get('checked_at', 'N/A')}")
    portfolio = briefing.get('portfolio', {})
    print(f"   - Sim balance: {portfolio.get('sim_balance', 'N/A')} $SIM")
    print(f"   - USDC balance: {portfolio.get('balance_usdc', 'N/A')} USDC")
    print(f"   - Positions count: {portfolio.get('positions_count', 'N/A')}")
    print(f"   - Risk alerts: {len(briefing.get('risk_alerts', []))}")
    print(f"   - Opportunities (high divergence): {len(briefing.get('opportunities', {}).get('high_divergence', []))}")
except Exception as e:
    print(f"   ❌ Briefing failed: {type(e).__name__}: {e}")

# Test 2: Markets endpoint (scanning)
print("\n2. Testing GET /markets endpoint...")
try:
    markets = client.get_markets(limit=3, max_hours_to_resolution=2, status='active')
    print(f"   ✅ Retrieved {len(markets)} near-expiry markets")
    for i, m in enumerate(markets[:2]):
        print(f"   {i+1}. {m.get('question', 'N/A')[:60]}...")
        print(f"      Price: {m.get('current_probability', 'N/A'):.2%}, Resolves: {m.get('resolves_at', 'N/A')}")
except Exception as e:
    print(f"   ❌ Markets failed: {type(e).__name__}: {e}")

# Test 3: Portfolio endpoint
print("\n3. Testing GET /portfolio endpoint...")
try:
    portfolio = client.get_portfolio()
    print(f"   ✅ Portfolio retrieved")
    print(f"   - Balance USDC: {portfolio.get('balance_usdc', 'N/A')}")
    print(f"   - Total exposure: {portfolio.get('total_exposure', 'N/A')}")
    print(f"   - Positions count: {portfolio.get('positions_count', 'N/A')}")
    print(f"   - PnL total: {portfolio.get('pnl_total', 'N/A')}")
except Exception as e:
    print(f"   ❌ Portfolio failed: {type(e).__name__}: {e}")

# Test 4: Positions endpoint (note known inconsistency)
print("\n4. Testing GET /positions endpoint...")
try:
    positions = client.get_positions()
    print(f"   ✅ Positions retrieved: {len(positions)} positions")
    if positions:
        for i, pos in enumerate(positions[:2]):
            print(f"   {i+1}. {pos.get('market_question', 'N/A')[:50]}...")
            print(f"      Shares YES: {pos.get('shares_yes', 'N/A')}, NO: {pos.get('shares_no', 'N/A')}")
            print(f"      Current price: {pos.get('current_price', 'N/A'):.2%}, PnL: {pos.get('pnl', 'N/A')}")
    else:
        print("   ⚠️  Empty positions array (known API inconsistency)")
except Exception as e:
    print(f"   ❌ Positions failed: {type(e).__name__}: {e}")

# Test 5: Context endpoint (single market)
print("\n5. Testing GET /context/{market_id} endpoint...")
if markets and len(markets) > 0:
    market_id = markets[0].get('id')
    try:
        context = client.get_market_context(market_id)
        print(f"   ✅ Context retrieved for market")
        print(f"   - Position: {context.get('position', 'N/A')}")
        print(f"   - Warnings: {context.get('warnings', 'N/A')}")
        print(f"   - Slippage estimate: {context.get('slippage_estimate', 'N/A')}")
        print(f"   - Hours to resolution: {context.get('hours_to_resolution', 'N/A')}")
    except Exception as e:
        print(f"   ❌ Context failed: {type(e).__name__}: {e}")
else:
    print("   ⚠️  Skipped (no markets)")

print("\n" + "=" * 60)
print("✅ API endpoint tests completed as per documentation.")
print("Note: Rate limits apply (Free: 6/min briefing, 30/min markets, 60/min trade)")