#!/usr/bin/env python3
import os
import sys
import time
from datetime import datetime

print(f"Testing Simmer SDK at {datetime.now().isoformat()}")

# Load API key
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

print(f"1. Importing simmer_sdk...")
try:
    from simmer_sdk import SimmerClient
    print("   Import successful")
except ImportError as e:
    print(f"   Import failed: {e}")
    sys.exit(1)

print(f"2. Creating SimmerClient...")
start_time = time.time()
try:
    client = SimmerClient(api_key=api_key, venue="polymarket")
    elapsed = time.time() - start_time
    print(f"   Client created in {elapsed:.2f} seconds")
except Exception as e:
    elapsed = time.time() - start_time
    print(f"   Client creation failed after {elapsed:.2f} seconds: {type(e).__name__}: {e}")
    sys.exit(1)

print(f"3. Testing get_markets() with timeout...")
start_time = time.time()
try:
    # Set a timeout
    import signal
    def timeout_handler(signum, frame):
        raise TimeoutError("get_markets() timed out")
    
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(30)  # 30 second timeout
    
    markets = client.get_markets(limit=2)
    signal.alarm(0)  # Cancel alarm
    elapsed = time.time() - start_time
    print(f"   get_markets() succeeded in {elapsed:.2f} seconds")
    print(f"   Retrieved {len(markets)} markets")
    if markets:
        print(f"   First market: {markets[0].get('title', 'Unknown')}")
except TimeoutError:
    elapsed = time.time() - start_time
    print(f"   get_markets() timed out after {elapsed:.2f} seconds")
except Exception as e:
    elapsed = time.time() - start_time
    print(f"   get_markets() failed after {elapsed:.2f} seconds: {type(e).__name__}: {e}")

print(f"\nTest completed at {datetime.now().isoformat()}")