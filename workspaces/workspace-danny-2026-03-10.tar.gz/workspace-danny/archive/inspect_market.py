#!/usr/bin/env python3
import os
import sys

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

markets = client.get_markets(limit=2)
if not markets:
    print("No markets")
    sys.exit(0)

m = markets[0]
print(f"Market object type: {type(m)}")
print(f"Attributes:")
for attr in dir(m):
    if not attr.startswith("_"):
        try:
            val = getattr(m, attr)
            print(f"  {attr}: {type(val).__name__} = {repr(val)[:80]}")
        except:
            print(f"  {attr}: <error>")

print("\nChecking for volume:")
if hasattr(m, 'volume'):
    print(f"  volume: {m.volume}")
if hasattr(m, 'volume_usdc'):
    print(f"  volume_usdc: {m.volume_usdc}")
if hasattr(m, 'liquidity'):
    print(f"  liquidity: {m.liquidity}")