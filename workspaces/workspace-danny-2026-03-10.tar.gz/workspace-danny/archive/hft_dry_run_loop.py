#!/usr/bin/env python3
"""
HFT Dry Run Loop - Runs FastLoop trader with HFT settings every 10 seconds for 1 hour.
Generates 15‑minute reports.
"""

import os
import sys
import time
import json
import subprocess
from datetime import datetime, timedelta
import random

# HFT Configuration
os.environ['ENTRY_THRESHOLD'] = '0.03'      # $0.03 divergence from 50¢
os.environ['MIN_MOMENTUM_PCT'] = '0.3'      # 0.3% minimum BTC momentum
os.environ['LOOKBACK_MINUTES'] = '3'        # 3‑minute lookback

# Paths
WORKSPACE = "/home/agent/.openclaw/workspace-danny"
ALIGNED_SCRIPT = os.path.join(WORKSPACE, "scripts", "run_fastloop_aligned.sh")
LOG_DIR = os.path.join(WORKSPACE, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# Session log
SESSION_LOG = os.path.join(LOG_DIR, "hft_dry_run.log")
REPORT_LOG = os.path.join(LOG_DIR, "hft_reports.json")

def log(msg):
    """Log to file and stdout."""
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    with open(SESSION_LOG, 'a', encoding='utf-8') as f:
        f.write(line + '\n')

def run_fastloop_scan():
    """Execute one FastLoop scan and return parsed results."""
    cmd = ["bash", ALIGNED_SCRIPT]
    env = os.environ.copy()
    env['LIVE_TRADING'] = 'false'  # Force dry‑run
    
    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            env=env,
            cwd=WORKSPACE,
            capture_output=True,
            text=True,
            timeout=30
        )
        elapsed = time.time() - start
        
        # Parse output
        stdout = proc.stdout.strip()
        stderr = proc.stderr.strip()
        returncode = proc.returncode
        
        # Extract key information
        scan_result = {
            'timestamp': datetime.now().isoformat(),
            'returncode': returncode,
            'stdout': stdout,
            'stderr': stderr,
            'duration': elapsed,
            'trade_found': False,
            'momentum': None,
            'markets_scanned': 0,
            'error': None
        }
        
        # Look for trade indicators
        if 'buy yes' in stdout.lower() or 'buy no' in stdout.lower() or 'trade executed' in stdout.lower():
            scan_result['trade_found'] = True
        
        # Extract momentum if present
        for line in stdout.split('\n'):
            if 'Momentum:' in line and '%' in line:
                # Example: "Momentum: -0.039%"
                try:
                    pct = line.split(':')[1].strip().replace('%', '')
                    scan_result['momentum'] = float(pct)
                except:
                    pass
            if 'Found' in line and 'active fast markets' in line:
                # Example: "Found 3 active fast markets"
                try:
                    num = int(line.split()[1])
                    scan_result['markets_scanned'] = num
                except:
                    pass
        
        if returncode != 0:
            scan_result['error'] = f'Script exited with {returncode}: {stderr[:200]}'
        
        return scan_result
        
    except subprocess.TimeoutExpired:
        return {
            'timestamp': datetime.now().isoformat(),
            'error': 'Timeout (30s)',
            'duration': 30,
            'trade_found': False
        }
    except Exception as e:
        return {
            'timestamp': datetime.now().isoformat(),
            'error': str(e),
            'duration': 0,
            'trade_found': False
        }

def generate_report(scan_history, start_time, current_time, report_number):
    """Generate a 15‑minute report."""
    # Filter scans in this reporting period (last 15 minutes)
    period_start = current_time - 15 * 60
    period_scans = [s for s in scan_history if datetime.fromisoformat(s['timestamp']).timestamp() >= period_start]
    
    total_scans = len(scan_history)
    period_scans_count = len(period_scans)
    
    # Count trades found (would have executed in live mode)
    total_trades = sum(1 for s in scan_history if s.get('trade_found'))
    period_trades = sum(1 for s in period_scans if s.get('trade_found'))
    
    # Average momentum
    momentums = [s['momentum'] for s in scan_history if s['momentum'] is not None]
    avg_momentum = sum(momentums) / len(momentums) if momentums else 0
    
    # Markets scanned (average)
    markets = [s['markets_scanned'] for s in scan_history if s['markets_scanned'] > 0]
    avg_markets = sum(markets) / len(markets) if markets else 0
    
    # Errors
    errors = sum(1 for s in scan_history if s.get('error'))
    
    # Build report
    report = {
        'report_number': report_number,
        'period': f"{(report_number-1)*15}-{report_number*15} minutes",
        'start_time': datetime.fromtimestamp(start_time).isoformat(),
        'end_time': datetime.fromtimestamp(current_time).isoformat(),
        'total_scans': total_scans,
        'period_scans': period_scans_count,
        'total_trades_found': total_trades,
        'period_trades_found': period_trades,
        'avg_momentum_pct': round(avg_momentum, 3),
        'avg_markets_per_scan': round(avg_markets, 1),
        'errors': errors,
        'scan_frequency_actual': round(period_scans_count / 15, 1) if period_scans_count > 0 else 0,
        'config': {
            'entry_threshold': os.environ.get('ENTRY_THRESHOLD'),
            'min_momentum_pct': os.environ.get('MIN_MOMENTUM_PCT'),
            'lookback_minutes': os.environ.get('LOOKBACK_MINUTES')
        }
    }
    
    # Save report to JSON
    reports = []
    if os.path.exists(REPORT_LOG):
        try:
            with open(REPORT_LOG, 'r') as f:
                reports = json.load(f)
        except:
            pass
    reports.append(report)
    with open(REPORT_LOG, 'w') as f:
        json.dump(reports, f, indent=2)
    
    # Format human‑readable summary
    lines = []
    lines.append(f"📊 HFT DRY‑RUN REPORT #{report_number} (Minutes {(report_number-1)*15}-{report_number*15})")
    lines.append("=" * 60)
    lines.append(f"Scans performed: {period_scans_count} ({report['scan_frequency_actual']}/min)")
    lines.append(f"Markets per scan (avg): {report['avg_markets_per_scan']}")
    lines.append(f"Avg BTC momentum: {report['avg_momentum_pct']}%")
    lines.append(f"Trade opportunities found: {period_trades}")
    if period_trades > 0:
        lines.append(f"  → Would have executed {period_trades} trades in live mode")
    lines.append(f"Errors: {errors}")
    lines.append("")
    lines.append("⚙️  HFT Configuration:")
    lines.append(f"  • Entry threshold: ${report['config']['entry_threshold']} divergence")
    lines.append(f"  • Min momentum: {report['config']['min_momentum_pct']}%")
    lines.append(f"  • Lookback: {report['config']['lookback_minutes']} minutes")
    lines.append("")
    
    # Recommendation based on data
    if period_scans_count == 0:
        lines.append("⚠️  No scans completed — check API connectivity.")
    elif avg_markets == 0:
        lines.append("⚠️  No fast markets found — strategy not viable at this time.")
    elif period_trades == 0:
        lines.append("⚠️  No trade opportunities — consider lowering momentum threshold or entry threshold.")
    else:
        lines.append("✅ Strategy is generating opportunities. Ready for live test with $1 positions.")
    
    lines.append("=" * 60)
    return '\n'.join(lines)

def main():
    """Main loop."""
    log("🚀 Starting HFT Dry‑Run Loop (1 hour, 10‑second scans)")
    log(f"Configuration: ENTRY_THRESHOLD={os.environ['ENTRY_THRESHOLD']}, MIN_MOMENTUM_PCT={os.environ['MIN_MOMENTUM_PCT']}%, LOOKBACK_MINUTES={os.environ['LOOKBACK_MINUTES']}min")
    
    total_duration = 60 * 60  # 1 hour
    scan_interval = 10        # 10 seconds
    report_interval = 15 * 60 # 15 minutes
    
    start_time = time.time()
    last_report_time = start_time
    scan_history = []
    report_number = 1
    
    log(f"Started at {datetime.fromtimestamp(start_time).strftime('%H:%M:%S')}")
    log(f"Will generate reports at 0, 15, 30, 45, and 60 minutes.")
    
    try:
        while time.time() - start_time < total_duration:
            loop_start = time.time()
            
            # Run one scan
            log(f"Scan #{len(scan_history)+1}...")
            result = run_fastloop_scan()
            scan_history.append(result)
            
            # Log result summary
            if result.get('error'):
                log(f"  Error: {result['error']}")
            else:
                markets = result.get('markets_scanned', 0)
                momentum = result.get('momentum', 'N/A')
                trade = "TRADE" if result.get('trade_found') else "no trade"
                log(f"  Markets: {markets}, Momentum: {momentum}%, {trade}")
            
            # Check for 15‑minute report
            current_time = time.time()
            if current_time - last_report_time >= report_interval:
                report_text = generate_report(scan_history, start_time, current_time, report_number)
                print("\n" + report_text + "\n")
                last_report_time = current_time
                report_number += 1
            
            # Sleep until next scan (adjust for scan duration)
            elapsed = time.time() - loop_start
            sleep_time = max(0.5, scan_interval - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
                
    except KeyboardInterrupt:
        log("Interrupted by user.")
    except Exception as e:
        log(f"Unexpected error: {e}")
    
    # Final report
    final_report = generate_report(scan_history, start_time, time.time(), report_number)
    print("\n" + final_report + "\n")
    
    # Summary
    total_scans = len(scan_history)
    total_trades = sum(1 for s in scan_history if s.get('trade_found'))
    avg_markets = sum(s.get('markets_scanned', 0) for s in scan_history) / max(total_scans, 1)
    
    log("=" * 60)
    log("🎯 HFT DRY‑RUN COMPLETE")
    log(f"Total scans: {total_scans}")
    log(f"Total trade opportunities: {total_trades}")
    log(f"Average fast markets per scan: {avg_markets:.1f}")
    log(f"Final report saved to {REPORT_LOG}")
    log("=" * 60)
    
    # Final recommendation
    if avg_markets == 0:
        log("❌ No fast markets detected — HFT strategy not viable.")
        log("   Consider switching to regular markets or different assets.")
    elif total_trades == 0:
        log("⚠️  No trade opportunities found — adjust thresholds.")
        log("   Suggest: lower momentum to 0.2% or entry threshold to $0.02.")
    else:
        log("✅ Strategy viable — ready for live test with small positions.")
        log(f"   Trade frequency: {total_trades} per hour ({total_trades/60:.2f}/min).")

if __name__ == "__main__":
    main()