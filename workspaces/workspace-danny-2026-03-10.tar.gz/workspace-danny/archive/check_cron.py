import json
import subprocess
import sys

result = subprocess.run(['openclaw', 'cron', 'list', '--include-disabled'], 
                       capture_output=True, text=True)
if result.returncode != 0:
    print("Failed to list cron jobs")
    sys.exit(1)

jobs = json.loads(result.stdout)
for job in jobs:
    if 'AI Divergence' in job.get('name', ''):
        print(f"Job ID: {job['id']}")
        print(f"Name: {job['name']}")
        print(f"Schedule: {job['schedule']}")
        print(f"Payload: {json.dumps(job['payload'], indent=2)}")
        print(f"Enabled: {job.get('enabled', True)}")
        print()