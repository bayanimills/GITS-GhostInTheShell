#!/usr/bin/env python3
import os
import sys
import json

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

print("📊 Simmer Briefing Endpoint (via _request)")
print("=" * 60)
try:
    briefing = client._request("GET", "/api/sdk/briefing")
    print(f"✅ Briefing retrieved at {briefing.get('checked_at', 'N/A')}")
    
    # Portfolio
    portfolio = briefing.get('portfolio', {})
    print(f"\n💼 Portfolio:")
    print(f"   Sim balance: {portfolio.get('sim_balance', 'N/A')} $SIM")
    print(f"   USDC balance: {portfolio.get('balance_usdc', 'N/A')} USDC")
    print(f"   Positions count: {portfolio.get('positions_count', 'N/A')}")
    print(f"   Total exposure: {portfolio.get('total_exposure', 'N/A')}")
    print(f"   PnL total: {portfolio.get('pnl_total', 'N/A')}")
    
    # Risk alerts
    risk_alerts = briefing.get('risk_alerts', [])
    print(f"\n⚠️  Risk Alerts ({len(risk_alerts)}):")
    for alert in risk_alerts[:3]:
        print(f"   - {alert}")
    
    # Opportunities
    opportunities = briefing.get('opportunities', {})
    high_div = opportunities.get('high_divergence', [])
    print(f"\n🎯 High Divergence Opportunities ({len(high_div)}):")
    for opp in high_div[:2]:
        print(f"   - {opp.get('market_question', 'N/A')[:60]}...")
        print(f"     Simmer: {opp.get('simmer_price', 'N/A'):.2%}, External: {opp.get('external_price', 'N/A'):.2%}")
    
    # Performance
    perf = briefing.get('performance', {})
    print(f"\n🏆 Performance:")
    print(f"   Rank: {perf.get('rank', 'N/A')}/{perf.get('total_agents', 'N/A')}")
    print(f"   Win rate: {perf.get('win_rate', 'N/A'):.1%}")
    
    # Positions (active)
    positions = briefing.get('positions', {}).get('active', [])
    print(f"\n📈 Active Positions ({len(positions)}):")
    for pos in positions[:3]:
        print(f"   - {pos.get('market_question', 'N/A')[:50]}...")
        print(f"     PnL: {pos.get('pnl', 'N/A')}, Price: {pos.get('current_price', 'N/A'):.2%}")
    
    # Venues
    venues = briefing.get('venues', {})
    print(f"\n🌐 Venues:")
    for venue, data in venues.items():
        print(f"   {venue}: {data.get('balance', 'N/A')} {data.get('currency', 'N/A')}")
        
except Exception as e:
    print(f"❌ Error: {type(e).__name__}: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 60)
print("✅ Briefing endpoint works as per API documentation.")
print("Note: This is the recommended heartbeat endpoint.")