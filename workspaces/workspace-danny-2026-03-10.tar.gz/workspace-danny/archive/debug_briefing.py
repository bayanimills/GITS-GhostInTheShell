#!/usr/bin/env python3
import os
import sys
import json

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

briefing = client._request("GET", "/api/sdk/briefing")
print("Briefing keys:", list(briefing.keys()))
print("\nFull briefing JSON (pretty):")
print(json.dumps(briefing, indent=2, default=str))