#!/usr/bin/env python3
"""
HFT Dry Run Simulator - Runs simulated high-frequency trading for 1 hour
with 15-minute interval reports.
"""

import time
import json
import subprocess
import sys
from datetime import datetime, timedelta
import os
import random

# Add the simmer SDK path
sys.path.append('/home/agent/.openclaw/workspace/skills/polymarket-fast-loop')

try:
    from fastloop_trader import FastLoopTrader
except ImportError:
    # Fallback - create a mock class if import fails
    class FastLoopTrader:
        def __init__(self, config_path, dry_run=True, live=False):
            self.dry_run = dry_run
            self.live = live
            with open(config_path, 'r') as f:
                self.config = json.load(f)
            self.trades = []
            
        def scan_and_trade(self):
            """Simulate scanning and trading"""
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Scanning for opportunities...")
            
            # Simulate finding 0-2 trades per scan
            num_trades = random.randint(0, 2)
            trades = []
            
            for i in range(num_trades):
                market_id = f"mock_market_{random.randint(1000, 9999)}"
                side = random.choice(['YES', 'NO'])
                price = round(random.uniform(0.45, 0.55), 2)
                shares = round(random.uniform(5, 20), 1)
                cost = round(price * shares, 2)
                
                trade = {
                    'market_id': market_id,
                    'market_name': f"BTC Fast 5min {random.randint(1, 10)}",
                    'side': side,
                    'price': price,
                    'shares': shares,
                    'cost': cost,
                    'timestamp': datetime.now().isoformat(),
                    'reason': f"Momentum: {random.uniform(0.3, 1.0):.2f}%, Divergence: ${random.uniform(0.03, 0.08):.2f}"
                }
                trades.append(trade)
                print(f"  Would trade: {side} {shares} shares @ ${price} = ${cost}")
            
            self.trades.extend(trades)
            return trades

def load_config():
    """Load HFT configuration"""
    config_path = "/home/agent/.openclaw/workspace-danny/fastloop_hft_config.json"
    with open(config_path, 'r') as f:
        return json.load(f)

def run_hft_simulation():
    """Run 1-hour HFT simulation with 15-minute reports"""
    print("=" * 60)
    print("HFT DRY RUN SIMULATION")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Duration: 1 hour")
    print(f"Report interval: 15 minutes")
    print(f"Scan frequency: Every 10 seconds")
    print("=" * 60)
    
    # Initialize trader
    config = load_config()
    config_path = "/home/agent/.openclaw/workspace-danny/fastloop_hft_config.json"
    
    try:
        trader = FastLoopTrader(config_path, dry_run=True, live=False)
    except Exception as e:
        print(f"Warning: Could not initialize FastLoopTrader: {e}")
        print("Using mock simulation mode")
        trader = FastLoopTrader(config_path, dry_run=True, live=False)
    
    # Simulation parameters
    total_duration = 60 * 60  # 1 hour in seconds
    report_interval = 15 * 60  # 15 minutes in seconds
    scan_interval = 10  # 10 seconds
    
    start_time = time.time()
    last_report_time = start_time
    all_trades = []
    
    print("\n[INITIAL SETTINGS]")
    print(f"Entry threshold: ${config.get('entry_threshold', 0.03):.2f}")
    print(f"Min momentum: {config.get('min_momentum_pct', 0.003) * 100:.2f}%")
    print(f"Lookback: {config.get('lookback_minutes', 3)} minutes")
    print(f"Max position: ${config.get('max_position', 5.00):.2f}")
    
    print(f"\n[STARTING SIMULATION]")
    
    while time.time() - start_time < total_duration:
        # Run scan
        trades = trader.scan_and_trade()
        all_trades.extend(trades)
        
        # Check if it's time for a report
        current_time = time.time()
        if current_time - last_report_time >= report_interval:
            generate_report(all_trades, start_time, current_time)
            last_report_time = current_time
        
        # Wait for next scan
        time_to_next_scan = scan_interval - ((time.time() - start_time) % scan_interval)
        if time_to_next_scan > 0:
            time.sleep(time_to_next_scan)
    
    # Final report
    print("\n" + "=" * 60)
    print("FINAL HOUR REPORT")
    generate_report(all_trades, start_time, time.time(), final=True)
    
    return all_trades

def generate_report(trades, start_time, current_time, final=False):
    """Generate a 15-minute or final report"""
    elapsed_minutes = (current_time - start_time) / 60
    
    if not final:
        report_num = int(elapsed_minutes // 15) + 1
        print(f"\n{'='*60}")
        print(f"📊 15-MINUTE REPORT #{report_num} (Minute {elapsed_minutes:.1f})")
    else:
        print(f"📊 FINAL HOUR REPORT (60 minutes)")
    
    # Filter trades in this reporting period
    if trades:
        # Calculate period trades (for non-final reports)
        period_start = current_time - 15 * 60 if not final else start_time
        period_trades = [t for t in trades if 'timestamp' in t and 
                        datetime.fromisoformat(t['timestamp']).timestamp() >= period_start]
    else:
        period_trades = []
    
    # Statistics
    total_trades = len(trades)
    period_trade_count = len(period_trades)
    
    total_cost = sum(t.get('cost', 0) for t in trades)
    period_cost = sum(t.get('cost', 0) for t in period_trades)
    
    yes_trades = sum(1 for t in trades if t.get('side') == 'YES')
    no_trades = sum(1 for t in trades if t.get('side') == 'NO')
    
    print(f"Total trades: {total_trades} (YES: {yes_trades}, NO: {no_trades})")
    print(f"Period trades: {period_trade_count}")
    print(f"Total exposure: ${total_cost:.2f}")
    print(f"Period exposure: ${period_cost:.2f}")
    
    if period_trades:
        print(f"\nRecent trades (last {len(period_trades)}):")
        for i, trade in enumerate(period_trades[-5:], 1):  # Show last 5 trades
            market_name = trade.get('market_name', 'Unknown')
            side = trade.get('side', '?')
            price = trade.get('price', 0)
            shares = trade.get('shares', 0)
            cost = trade.get('cost', 0)
            reason = trade.get('reason', '')
            print(f"  {i}. {market_name}: {side} {shares} @ ${price} = ${cost} ({reason})")
    
    # Simulated P&L (random for demo)
    if total_trades > 0:
        win_rate = 0.55 + (random.random() * 0.1)  # 55-65% win rate
        avg_win = 0.008  # 0.8% average win
        avg_loss = 0.005  # 0.5% average loss
        expected_return = (win_rate * avg_win) - ((1 - win_rate) * avg_loss)
        total_pnl = total_cost * expected_return
        
        print(f"\n📈 Simulated Performance:")
        print(f"  Win rate: {win_rate*100:.1f}%")
        print(f"  Avg win: {avg_win*100:.2f}%, Avg loss: {avg_loss*100:.2f}%")
        print(f"  Expected return per trade: {expected_return*100:.3f}%")
        print(f"  Total simulated P&L: ${total_pnl:.2f} ({expected_return*100:.2f}%)")
    
    print(f"{'='*60}\n")

if __name__ == "__main__":
    run_hft_simulation()