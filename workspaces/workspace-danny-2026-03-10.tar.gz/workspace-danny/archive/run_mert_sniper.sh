#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Briefing check (align with simmer skill)
echo "Checking briefing for risk alerts..." >> /dev/stderr
BRIEFING=$(python3 << 'EOF'
import requests, os, json
api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY missing")
    exit(1)
headers = {"Authorization": f"Bearer {api_key}"}
try:
    r = requests.get("https://api.simmer.markets/api/sdk/briefing", headers=headers, timeout=10)
    if r.status_code == 200:
        data = r.json()
        risk_alerts = data.get("risk_alerts", [])
        venues = data.get("venues", {})
        if risk_alerts:
            print("RISK_ALERTS:" + json.dumps(risk_alerts))
        for venue, vdata in venues.items():
            if vdata:
                print(f"VENUE:{venue}:{vdata.get('currency','?')}:{vdata.get('balance',0):.2f}:{vdata.get('positions_count',0)}")
except Exception as e:
    print(f"BRIEFING_ERROR:{e}")
EOF
)
if echo "$BRIEFING" | grep -q "RISK_ALERTS:"; then
    echo "⚠️  Risk alerts detected, skipping trading:" >> /dev/stderr
    echo "$BRIEFING" | grep "RISK_ALERTS:" | sed 's/RISK_ALERTS://' | jq -r '.[]' >> /dev/stderr
    exit 0
fi
# Log venue summary
echo "$BRIEFING" | grep "^VENUE:" | while IFS=: read -r venue currency balance positions; do
    echo "  $venue: $balance $currency, $positions positions" >> /dev/stderr
done

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/mert_sniper_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Run Mert Sniper with live trading, smart sizing, 60‑min expiry, 60/40 split (updated threshold)
cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper
OUTPUT=$(python3 mert_sniper.py --live --smart-sizing --expiry 60 --set min_split=0.6 2>&1)

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Extract trade count
TRADES=$(echo "$OUTPUT" | grep "Trades executed:" | awk '{print $3}')
NEAR=$(echo "$OUTPUT" | grep "Near expiry:" | awk '{print $3}')

if [ -z "$TRADES" ]; then
    TRADES=0
fi

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

if [ "$TRADES" -gt 0 ]; then
    # Trades executed — output full summary
    echo "$OUTPUT" | grep -A10 "Summary:"
elif [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours, no trade — stay silent (no output)
    exit 0
else
    # Daytime, no trade — output concise status
    echo "Mert Sniper: ${NEAR:-0} markets near expiry, ${TRADES} trades (60min, 60% split)."
fi