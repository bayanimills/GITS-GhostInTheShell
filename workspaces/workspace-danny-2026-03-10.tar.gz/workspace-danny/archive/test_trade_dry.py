#!/usr/bin/env python3
import os
import sys

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

print("🔍 Finding a market for dry‑run trade")
markets = client.get_markets(limit=20, status='active')
candidates = []
for m in markets:
    # Filter for near-expiry but not too soon
    if hasattr(m, 'volume_usdc') and m.volume_usdc and m.volume_usdc > 100:
        candidates.append(m)

if not candidates:
    print("No suitable markets found")
    sys.exit(0)

market = candidates[0]
print(f"\nSelected market:")
print(f"  Question: {market.question[:80]}...")
print(f"  Market ID: {market.id}")
print(f"  Current probability: {market.current_probability:.2%}")
print(f"  Volume USDC: {market.volume_usdc}")
print(f"  Resolves at: {market.resolves_at}")

print("\n🧪 Testing trade endpoint with dry‑run")
print(f"  Side: YES, amount: 0.001 USDC")
try:
    # Try to call trade method; check if dry_run param exists
    # We'll use _request to be safe
    import json
    payload = {
        "market_id": market.id,
        "side": "YES",
        "amount": 0.001,
        "venue": "polymarket",
        "dry_run": True,
        "source": "sdk:api-test"
    }
    print(f"  Payload: {json.dumps(payload, indent=2)}")
    result = client._request("POST", "/api/sdk/trade", json=payload)
    print(f"  ✅ Dry‑run trade succeeded")
    print(f"  Result keys: {list(result.keys())}")
    print(f"  Order ID: {result.get('order_id')}")
    print(f"  Filled shares: {result.get('filled_shares')}")
    print(f"  Cost basis: {result.get('cost_basis')}")
except Exception as e:
    print(f"  ❌ Error: {type(e).__name__}: {e}")
    # Try with dry_run=False maybe it's not supported
    print("\nTrying without dry_run parameter (maybe dry_run not supported)...")
    try:
        payload2 = {
            "market_id": market.id,
            "side": "YES",
            "amount": 0.001,
            "venue": "polymarket",
            "source": "sdk:api-test"
        }
        result2 = client._request("POST", "/api/sdk/trade", json=payload2)
        print(f"  Trade succeeded (real?)")
        print(f"  Result: {result2}")
    except Exception as e2:
        print(f"  Second error: {e2}")

print("\n📋 Checking if trade appears in trades list")
try:
    trades = client._request("GET", "/api/sdk/trades", params={"limit": 5})
    print(f"  Recent trades: {len(trades)}")
    if trades:
        print(f"  Latest trade: {trades[0].get('market_question', 'N/A')[:50]}...")
except Exception as e:
    print(f"  Error fetching trades: {e}")