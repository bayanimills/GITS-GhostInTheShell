#!/usr/bin/env python3
import os
import sys
sys.path.append('/home/agent/.openclaw/workspace/skills/polymarket-fast-loop')

from simmer_sdk import SimmerClient

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("SIMMER_API_KEY not set")
    sys.exit(1)

client = SimmerClient(api_key=api_key)

# Get all active markets
markets = client.get_markets(limit=100, status='active')
print(f"Total active markets: {len(markets)}")

fast_markets = []
for m in markets:
    if 'fast' in m.question.lower() and 'btc' in m.question.lower():
        fast_markets.append(m)

print(f"BTC fast markets: {len(fast_markets)}")
for m in fast_markets:
    print(f"  {m.id}: {m.question}")
    print(f"    YES price: {m.current_probability:.3f}, NO price: {1-m.current_probability:.3f}")
    print(f"    Expires: {m.expires_at}")