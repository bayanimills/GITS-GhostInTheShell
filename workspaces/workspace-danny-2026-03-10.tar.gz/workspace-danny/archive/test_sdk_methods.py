#!/usr/bin/env python3
import os
import sys

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

import simmer_sdk
from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

print("Testing get_markets() with no params:")
try:
    markets = client.get_markets()
    print(f"  Success, returned {len(markets)} markets")
    if markets:
        m = markets[0]
        print(f"  First market keys: {list(m.keys())}")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting get_markets(limit=5):")
try:
    markets = client.get_markets(limit=5)
    print(f"  Success, returned {len(markets)} markets")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting get_markets with status='active':")
try:
    markets = client.get_markets(status='active')
    print(f"  Success, returned {len(markets)} markets")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting get_markets with tags='weather':")
try:
    markets = client.get_markets(tags='weather')
    print(f"  Success, returned {len(markets)} markets")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting find_markets method:")
try:
    markets = client.find_markets()
    print(f"  Success, returned {len(markets)} markets")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting get_market_context:")
if markets:
    try:
        ctx = client.get_market_context(markets[0]['id'])
        print(f"  Success, keys: {list(ctx.keys())}")
    except Exception as e:
        print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting get_portfolio:")
try:
    portfolio = client.get_portfolio()
    print(f"  Success, keys: {list(portfolio.keys())}")
    print(f"  Balance USDC: {portfolio.get('balance_usdc')}")
    print(f"  Positions count: {portfolio.get('positions_count')}")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

print("\nTesting get_positions:")
try:
    positions = client.get_positions()
    print(f"  Success, returned {len(positions)} positions")
    if positions:
        print(f"  First position keys: {list(positions[0].keys())}")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

# Check if there's a briefing endpoint via _request
print("\nTesting _request to /api/sdk/briefing:")
try:
    resp = client._request("GET", "/api/sdk/briefing")
    print(f"  Success, keys: {list(resp.keys())}")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")