#!/usr/bin/env python3
import os
import sys

# Add skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

try:
    import simmer_sdk
    from simmer_sdk import SimmerClient
except ImportError as e:
    print(f"Import error: {e}")
    sys.exit(1)

print(f"Simmer SDK version: {simmer_sdk.__version__ if hasattr(simmer_sdk, '__version__') else 'unknown'}")

# Load API key
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

if not api_key:
    print("No API key")
    sys.exit(1)

client = SimmerClient(api_key=api_key)

print("\nClient object type:", type(client))
print("\nMethods:")
for attr in dir(client):
    if not attr.startswith("_"):
        print(f"  {attr}")

print("\nChecking for specific methods:")
for method in ['get_briefing', 'briefing', 'markets', 'get_markets', 'portfolio', 'get_portfolio', 'positions', 'get_positions', 'context', 'get_market_context']:
    has = hasattr(client, method)
    print(f"  {method}: {has}")

# Try to call get_portfolio
print("\nCalling get_portfolio():")
try:
    portfolio = client.get_portfolio()
    print(f"  Success: {portfolio.keys() if isinstance(portfolio, dict) else 'non-dict'}")
except Exception as e:
    print(f"  Error: {type(e).__name__}: {e}")

# Try to call get_briefing via possible attribute
print("\nLooking for briefing attribute:")
if hasattr(client, 'briefing'):
    print(f"  client.briefing: {type(client.briefing)}")
    # Maybe briefing.get()
    if hasattr(client.briefing, 'get'):
        try:
            briefing = client.briefing.get()
            print(f"  client.briefing.get() succeeded")
        except Exception as e:
            print(f"  client.briefing.get() error: {e}")
elif hasattr(client, 'get_briefing'):
    print("  client.get_briefing exists")
else:
    print("  No briefing attribute")

# Try to call markets.list (maybe that's the pattern)
print("\nLooking for markets attribute:")
if hasattr(client, 'markets'):
    print(f"  client.markets: {type(client.markets)}")
    for attr in dir(client.markets):
        if not attr.startswith("_"):
            print(f"    markets.{attr}")
    # Try list
    if hasattr(client.markets, 'list'):
        try:
            markets = client.markets.list(limit=1)
            print(f"  markets.list succeeded, got {len(markets)}")
        except Exception as e:
            print(f"  markets.list error: {e}")