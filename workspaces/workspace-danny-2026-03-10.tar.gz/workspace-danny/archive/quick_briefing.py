#!/usr/bin/env python3
import os
import json
from simmer_sdk import SimmerClient

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
    if os.path.exists(secrets_path):
        with open(secrets_path, 'r') as f:
            for line in f:
                if line.startswith('SIMMER_API_KEY='):
                    api_key = line.strip().split('=', 1)[1]
                    break

client = SimmerClient(api_key=api_key)
briefing = client._request("/api/sdk/briefing")
print(json.dumps(briefing, indent=2))