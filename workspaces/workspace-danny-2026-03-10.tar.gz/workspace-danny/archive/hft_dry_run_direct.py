#!/usr/bin/env python3
"""
HFT Dry Run Loop - Direct FastLoop trader calls, 10‑second scans for 1 hour.
15‑minute reports.
"""

import os
import sys
import time
import json
import subprocess
from datetime import datetime, timedelta

# HFT Configuration
os.environ['ENTRY_THRESHOLD'] = '0.03'      # $0.03 divergence from 50¢
os.environ['MIN_MOMENTUM_PCT'] = '0.3'      # 0.3% minimum BTC momentum
os.environ['LOOKBACK_MINUTES'] = '3'        # 3‑minute lookback

# Paths
WORKSPACE = "/home/agent/.openclaw/workspace-danny"
SKILL_DIR = "/home/agent/.openclaw/workspace/skills/polymarket-fast-loop"
LOG_DIR = os.path.join(WORKSPACE, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# Load API key
secrets_path = os.path.join(WORKSPACE, ".openclaw", "secrets.env")
api_key = None
if os.path.exists(secrets_path):
    with open(secrets_path, 'r') as f:
        for line in f:
            if line.startswith('SIMMER_API_KEY='):
                api_key = line.strip().split('=', 1)[1]
                break
if api_key:
    os.environ['SIMMER_API_KEY'] = api_key

SESSION_LOG = os.path.join(LOG_DIR, "hft_dry_run_direct.log")
REPORT_LOG = os.path.join(LOG_DIR, "hft_reports_direct.json")

def log(msg):
    """Log to file and stdout."""
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    with open(SESSION_LOG, 'a', encoding='utf-8') as f:
        f.write(line + '\n')

def run_fastloop_scan():
    """Execute one FastLoop scan directly."""
    cmd = [
        sys.executable, 'fastloop_trader.py',
        '--dry-run'
        # '--quiet'  # keep verbose for parsing
    ]
    env = os.environ.copy()
    
    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            env=env,
            cwd=SKILL_DIR,
            capture_output=True,
            text=True,
            timeout=25
        )
        elapsed = time.time() - start
        
        stdout = proc.stdout
        stderr = proc.stderr
        returncode = proc.returncode
        
        # Parse output
        result = {
            'timestamp': datetime.now().isoformat(),
            'returncode': returncode,
            'duration': elapsed,
            'trade_found': False,
            'markets_found': 0,
            'momentum_pct': None,
            'error': None
        }
        
        # Look for "Found X active fast markets"
        for line in stdout.split('\n'):
            if 'Found' in line and 'active fast markets' in line:
                # Example: "Found 0 active fast markets"
                parts = line.split()
                try:
                    result['markets_found'] = int(parts[1])
                except:
                    pass
            if 'Momentum:' in line and '%' in line:
                # Example: "Momentum: -0.039%"
                try:
                    pct = line.split(':')[1].strip().replace('%', '')
                    result['momentum_pct'] = float(pct)
                except:
                    pass
            # Trade indicators (in dry-run it says "Would buy YES/NO")
            if 'Would buy' in line or 'trade' in line.lower() and 'executed' in line.lower():
                result['trade_found'] = True
        
        if returncode != 0:
            result['error'] = f'Exit {returncode}: {stderr[:200]}'
        
        return result
        
    except subprocess.TimeoutExpired:
        return {
            'timestamp': datetime.now().isoformat(),
            'error': 'Timeout (25s)',
            'duration': 25,
            'trade_found': False,
            'markets_found': 0
        }
    except Exception as e:
        return {
            'timestamp': datetime.now().isoformat(),
            'error': str(e),
            'duration': 0,
            'trade_found': False,
            'markets_found': 0
        }

def generate_report(scan_history, start_time, current_time, report_number):
    """Generate a 15‑minute report."""
    period_start = current_time - 15 * 60
    period_scans = [s for s in scan_history if datetime.fromisoformat(s['timestamp']).timestamp() >= period_start]
    
    total_scans = len(scan_history)
    period_scans_count = len(period_scans)
    
    total_trades = sum(1 for s in scan_history if s.get('trade_found'))
    period_trades = sum(1 for s in period_scans if s.get('trade_found'))
    
    markets_found = [s.get('markets_found', 0) for s in scan_history]
    avg_markets = sum(markets_found) / len(markets_found) if markets_found else 0
    
    momentums = [s['momentum_pct'] for s in scan_history if s['momentum_pct'] is not None]
    avg_momentum = sum(momentums) / len(momentums) if momentums else 0
    
    errors = sum(1 for s in scan_history if s.get('error'))
    
    report = {
        'report_number': report_number,
        'period': f"{(report_number-1)*15}-{report_number*15} minutes",
        'start_time': datetime.fromtimestamp(start_time).isoformat(),
        'end_time': datetime.fromtimestamp(current_time).isoformat(),
        'total_scans': total_scans,
        'period_scans': period_scans_count,
        'total_trades_found': total_trades,
        'period_trades_found': period_trades,
        'avg_markets_found': round(avg_markets, 1),
        'avg_momentum_pct': round(avg_momentum, 3),
        'errors': errors,
        'config': {
            'entry_threshold': os.environ.get('ENTRY_THRESHOLD'),
            'min_momentum_pct': os.environ.get('MIN_MOMENTUM_PCT'),
            'lookback_minutes': os.environ.get('LOOKBACK_MINUTES')
        }
    }
    
    # Save report
    reports = []
    if os.path.exists(REPORT_LOG):
        try:
            with open(REPORT_LOG, 'r') as f:
                reports = json.load(f)
        except:
            pass
    reports.append(report)
    with open(REPORT_LOG, 'w') as f:
        json.dump(reports, f, indent=2)
    
    # Human‑readable summary
    lines = []
    lines.append(f"📊 HFT DRY‑RUN REPORT #{report_number} (Minutes {(report_number-1)*15}-{report_number*15})")
    lines.append("=" * 60)
    lines.append(f"Scans performed: {period_scans_count}")
    lines.append(f"Fast markets found (avg): {report['avg_markets_found']}")
    lines.append(f"Avg BTC momentum: {report['avg_momentum_pct']}%")
    lines.append(f"Trade opportunities: {period_trades}")
    if period_trades > 0:
        lines.append(f"  → Would have executed {period_trades} trades")
    lines.append(f"Errors: {errors}")
    lines.append("")
    lines.append("⚙️  HFT Configuration:")
    lines.append(f"  • Entry threshold: ${report['config']['entry_threshold']} divergence")
    lines.append(f"  • Min momentum: {report['config']['min_momentum_pct']}%")
    lines.append(f"  • Lookback: {report['config']['lookback_minutes']} minutes")
    lines.append("")
    
    # Strategy assessment
    if avg_markets == 0:
        lines.append("⚠️  NO FAST MARKETS DETECTED")
        lines.append("   The HFT strategy cannot run — no BTC fast markets are active.")
        lines.append("   Consider: different assets (ETH, SOL) or regular markets.")
    elif period_trades == 0:
        lines.append("⚠️  No trade opportunities.")
        lines.append("   Momentum threshold too high or markets not moving.")
        lines.append("   Suggested: lower momentum to 0.2%, entry threshold to $0.02.")
    else:
        lines.append("✅ Strategy generating opportunities.")
        lines.append(f"   Trade frequency: {period_trades} per 15 min.")
    
    lines.append("=" * 60)
    return '\n'.join(lines)

def main():
    """Main loop."""
    log("🚀 HFT Dry‑Run Loop (Direct) – 1 hour, 10‑second scans")
    log(f"Configuration: ENTRY_THRESHOLD={os.environ['ENTRY_THRESHOLD']}, MIN_MOMENTUM_PCT={os.environ['MIN_MOMENTUM_PCT']}%, LOOKBACK_MINUTES={os.environ['LOOKBACK_MINUTES']}min")
    
    total_duration = 60 * 60  # 1 hour
    scan_interval = 10        # 10 seconds
    report_interval = 15 * 60 # 15 minutes
    
    start_time = time.time()
    last_report_time = start_time
    scan_history = []
    report_number = 1
    
    log(f"Started at {datetime.fromtimestamp(start_time).strftime('%H:%M:%S')}")
    log(f"Reports at 0, 15, 30, 45, 60 minutes.")
    
    try:
        while time.time() - start_time < total_duration:
            loop_start = time.time()
            
            # Run scan
            result = run_fastloop_scan()
            scan_history.append(result)
            
            # Log summary
            markets = result.get('markets_found', 0)
            momentum = result.get('momentum_pct', 'N/A')
            trade = "TRADE" if result.get('trade_found') else "no trade"
            log(f"Scan #{len(scan_history)}: {markets} markets, momentum {momentum}%, {trade}")
            
            # 15‑minute report
            current_time = time.time()
            if current_time - last_report_time >= report_interval:
                report_text = generate_report(scan_history, start_time, current_time, report_number)
                print("\n" + report_text + "\n")
                last_report_time = current_time
                report_number += 1
            
            # Sleep until next scan
            elapsed = time.time() - loop_start
            sleep_time = max(0.5, scan_interval - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
                
    except KeyboardInterrupt:
        log("Interrupted.")
    except Exception as e:
        log(f"Error: {e}")
    
    # Final report
    final_report = generate_report(scan_history, start_time, time.time(), report_number)
    print("\n" + final_report + "\n")
    
    # Summary
    total_scans = len(scan_history)
    total_trades = sum(1 for s in scan_history if s.get('trade_found'))
    avg_markets = sum(s.get('markets_found', 0) for s in scan_history) / max(total_scans, 1)
    
    log("=" * 60)
    log("🎯 HFT DRY‑RUN COMPLETE")
    log(f"Total scans: {total_scans}")
    log(f"Total trade opportunities: {total_trades}")
    log(f"Average fast markets per scan: {avg_markets:.1f}")
    log("=" * 60)
    
    # Final verdict
    if avg_markets == 0:
        log("❌ NO FAST MARKETS — HFT strategy not viable.")
        log("   Consider alternative: regular markets, other assets, or micro‑arbitrage.")
    elif total_trades == 0:
        log("⚠️  No trades — adjust thresholds or wait for market movement.")
    else:
        log("✅ Strategy viable — ready for live test with small positions.")
    
    log(f"Reports saved to {REPORT_LOG}")

if __name__ == "__main__":
    main()