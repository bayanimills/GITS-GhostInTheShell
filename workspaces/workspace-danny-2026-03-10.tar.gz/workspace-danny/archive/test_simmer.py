#!/usr/bin/env python3
import os
import sys
import time
from datetime import datetime

print(f"Testing Simmer SDK at {datetime.now()}")
print("=" * 50)

# Add the skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

try:
    print("1. Testing import of simmer_sdk...")
    import simmer_sdk
    print("   ✓ Import successful")
    
    print("2. Testing SimmerClient initialization...")
    start_time = time.time()
    
    # Try to initialize with timeout
    import signal
    
    def timeout_handler(signum, frame):
        raise TimeoutError("SimmerClient initialization timed out")
    
    # Set timeout for 30 seconds
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(30)
    
    try:
        client = simmer_sdk.SimmerClient()
        elapsed = time.time() - start_time
        print(f"   ✓ Initialization successful in {elapsed:.2f} seconds")
        signal.alarm(0)  # Cancel the alarm
        
        print("3. Testing basic API call...")
        try:
            markets = client.markets.list(limit=1)
            print(f"   ✓ API call successful, got {len(markets)} market(s)")
        except Exception as e:
            print(f"   ✗ API call failed: {type(e).__name__}: {e}")
            
    except TimeoutError:
        print("   ✗ Initialization TIMED OUT after 30 seconds")
        print("   This is likely the root cause of the hanging")
    except Exception as e:
        print(f"   ✗ Initialization failed: {type(e).__name__}: {e}")
        
except ImportError as e:
    print(f"   ✗ Import failed: {e}")
except Exception as e:
    print(f"   ✗ Unexpected error: {type(e).__name__}: {e}")

print("=" * 50)
print(f"Test completed at {datetime.now()}")