#!/usr/bin/env python3
import os
import sys
import json
sys.path.insert(0, '/home/agent/.openclaw/workspace-danny/.venv/lib/python3.12/site-packages')

from simmer_sdk import SimmerClient

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("SIMMER_API_KEY missing")
    sys.exit(1)

client = SimmerClient(api_key=api_key, venue="polymarket")
print("Fetching portfolio...")
portfolio = client.portfolio()
print(json.dumps(portfolio, indent=2))

print("\nFetching briefing...")
briefing = client._request("GET", "/api/sdk/briefing")
print(json.dumps(briefing, indent=2))