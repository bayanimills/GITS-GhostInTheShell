#!/bin/bash
set -e

cd /home/agent/.openclaw/workspace-danny

# Load secrets
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
else
    echo "ERROR: secrets.env not found" >&2
    exit 1
fi

# Briefing check (align with simmer skill)
echo "🔮 Simmer alignment check..." >&2
BRIEFING_OUTPUT=$(python3 << 'EOF'
import requests, os, json, sys
api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY missing", file=sys.stderr)
    sys.exit(1)
headers = {"Authorization": f"Bearer {api_key}"}
try:
    r = requests.get("https://api.simmer.markets/api/sdk/briefing", headers=headers, timeout=15)
    r.raise_for_status()
    data = r.json()
except Exception as e:
    print(f"BRIEFING_ERROR:{e}", file=sys.stderr)
    sys.exit(1)

# Risk alerts
risk_alerts = data.get("risk_alerts", [])
if risk_alerts:
    print("RISK_ALERTS:" + json.dumps(risk_alerts))
    sys.exit(0)

# Venue breakdown
venues = data.get("venues", {})
for venue, vdata in venues.items():
    if vdata:
        currency = vdata.get("currency", "?")
        balance = vdata.get("balance", 0)
        positions = vdata.get("positions_count", 0)
        print(f"VENUE:{venue}:{currency}:{balance:.2f}:{positions}")
EOF
)

if [ $? -ne 0 ]; then
    echo "⚠️  Briefing check failed, continuing anyway..." >&2
fi

if echo "$BRIEFING_OUTPUT" | grep -q "RISK_ALERTS:"; then
    alerts=$(echo "$BRIEFING_OUTPUT" | grep "RISK_ALERTS:" | sed 's/RISK_ALERTS://')
    echo "⛔ Risk alerts detected, skipping trading:" >&2
    echo "$alerts" | jq -r '.[]' | while read -r alert; do echo "   - $alert" >&2; done
    exit 0
fi

# Extract polymarket balance for reporting
POLYMARKET_BALANCE=$(echo "$BRIEFING_OUTPUT" | grep "^VENUE:polymarket:" | cut -d: -f4 2>/dev/null || echo "")
SIM_BALANCE=$(echo "$BRIEFING_OUTPUT" | grep "^VENUE:simmer:" | cut -d: -f4 2>/dev/null || echo "")

# Log venue summary
echo "$BRIEFING_OUTPUT" | grep "^VENUE:" | while IFS=: read -r venue currency balance positions; do
    echo "  $venue: $balance $currency, $positions positions" >&2
done

# Log file
LOG_DIR="/home/agent/.openclaw/workspace-danny/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/fastloop_real.log"

# Timestamp
echo "=== $(date '+%Y‑m‑d %H:%M:%S') ===" >> "$LOG_FILE"

# Determine mode: live if LIVE_TRADING is set
MODE_FLAGS="--quiet"
if [[ -n "$LIVE_TRADING" && "$LIVE_TRADING" == "true" ]]; then
    echo "✅ LIVE TRADING ENABLED — executing real trades" >> "$LOG_FILE"
    MODE_FLAGS="--live --smart-sizing --quiet"
else
    echo "⚠️  Live trading disabled — dry‑run only" >> "$LOG_FILE"
fi

# Run the FastLoop trader and capture output
cd /home/agent/.openclaw/workspace/skills/polymarket-fast-loop
OUTPUT=$(python3 fastloop_trader.py $MODE_FLAGS 2>&1)

# Log everything
echo "$OUTPUT" >> "$LOG_FILE"

# Check for trade execution (case-insensitive)
TRADE_FOUND=0
if echo "$OUTPUT" | grep -qi "buy yes\|buy no\|sell\|executed trade\|trade executed\|position opened"; then
    TRADE_FOUND=1
fi

# Current hour in AEST
HOUR=$(TZ=Australia/Sydney date +%H)
# Remove leading zero to avoid octal interpretation
HOUR=${HOUR#0}

# Quiet hours: 23:00-07:00 (inclusive)
QUIET=0
if [[ "$HOUR" -ge 23 || "$HOUR" -lt 7 ]]; then
    QUIET=1
fi

# Decide output
if [[ "$TRADE_FOUND" -eq 1 ]]; then
    # Trade executed — output details
    echo "$OUTPUT"
    # Add venue balance context
    if [ -n "$POLYMARKET_BALANCE" ]; then
        echo "  Balance: $POLYMARKET_BALANCE USDC"
    fi
elif [[ "$QUIET" -eq 1 ]]; then
    # Quiet hours, no trade — stay silent (no output)
    exit 0
else
    # Daytime, no trade — output brief status with balance
    # Extract momentum line if present
    MOMENTUM=$(echo "$OUTPUT" | grep -o "Momentum: [-0-9.]*%" | head -1)
    if [[ -n "$MOMENTUM" ]]; then
        STATUS="FastLoop: $MOMENTUM — no trade"
    else
        STATUS="FastLoop: no trade opportunity"
    fi
    if [ -n "$POLYMARKET_BALANCE" ]; then
        STATUS="$STATUS, balance $POLYMARKET_BALANCE USDC"
    fi
    echo "$STATUS."
fi