#!/usr/bin/env python3
import os
import sys
import time
from datetime import datetime

print(f"Testing Simmer SDK with environment at {datetime.now()}")
print("=" * 50)

# Load environment from secrets
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    print(f"1. Loading environment from {secrets_path}")
    with open(secrets_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key] = value
    print(f"   ✓ Loaded environment variables")
else:
    print(f"   ✗ Secrets file not found at {secrets_path}")

print(f"2. Checking SIMMER_API_KEY environment variable...")
api_key = os.environ.get('SIMMER_API_KEY')
if api_key:
    print(f"   ✓ API key present ({len(api_key)} chars)")
    # Show first and last few chars for verification
    print(f"   Key sample: {api_key[:8]}...{api_key[-8:]}")
else:
    print(f"   ✗ API key NOT FOUND in environment")

# Add the skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

try:
    print("3. Testing import of simmer_sdk...")
    import simmer_sdk
    print("   ✓ Import successful")
    
    print("4. Testing SimmerClient initialization with API key...")
    start_time = time.time()
    
    # Try to initialize with timeout
    import signal
    
    def timeout_handler(signum, frame):
        raise TimeoutError("SimmerClient initialization timed out")
    
    # Set timeout for 30 seconds
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(30)
    
    try:
        client = simmer_sdk.SimmerClient(api_key=api_key, venue='polymarket')
        elapsed = time.time() - start_time
        print(f"   ✓ Initialization successful in {elapsed:.2f} seconds")
        signal.alarm(0)  # Cancel the alarm
        
        print("5. Testing basic API call (markets list)...")
        try:
            markets = client.markets.list(limit=1)
            print(f"   ✓ API call successful, got {len(markets)} market(s)")
            if markets:
                print(f"   First market: {markets[0].title[:50]}...")
        except Exception as e:
            print(f"   ✗ API call failed: {type(e).__name__}: {e}")
            
    except TimeoutError:
        print("   ✗ Initialization TIMED OUT after 30 seconds")
        print("   THIS IS THE LIKELY ROOT CAUSE OF THE HANGING")
    except Exception as e:
        print(f"   ✗ Initialization failed: {type(e).__name__}: {e}")
        
except ImportError as e:
    print(f"   ✗ Import failed: {e}")
except Exception as e:
    print(f"   ✗ Unexpected error: {type(e).__name__}: {e}")

print("=" * 50)
print(f"Test completed at {datetime.now()}")