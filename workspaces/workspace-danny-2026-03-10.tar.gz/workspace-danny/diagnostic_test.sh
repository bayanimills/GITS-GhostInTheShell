#!/bin/bash
echo "=== MERT SNIPER DIAGNOSTIC TEST ==="
echo "Start time: $(date)"
echo "==================================="

cd /home/agent/.openclaw/workspace-danny

# Load environment
if [ -f .openclaw/secrets.env ]; then
    set -a
    source .openclaw/secrets.env
    set +a
    echo "✓ Environment loaded"
fi

cd /home/agent/.openclaw/workspace/skills/polymarket-mert-sniper

echo ""
echo "TEST 1: Dry-run mode (should work)"
echo "-----------------------------------"
timeout 30 python3 mert_sniper.py --dry-run --expiry 5 --set min_split=0.65 2>&1 | grep -E "(Summary:|Trades executed:|Near expiry:|Error:|✓|✗)" | head -20

echo ""
echo "TEST 2: Live mode without smart-sizing"
echo "--------------------------------------"
timeout 30 python3 mert_sniper.py --live --expiry 5 --set min_split=0.65 2>&1 | grep -E "(Summary:|Trades executed:|Near expiry:|Error:|✓|✗|Fetching|Executing)" | head -30

echo ""
echo "TEST 3: Check script version and dependencies"
echo "--------------------------------------------"
python3 -c "
import mert_sniper
import inspect
print('Script location:', inspect.getfile(mert_sniper))
print('Functions available:', [name for name in dir(mert_sniper) if not name.startswith('_')])
"

echo ""
echo "==================================="
echo "Diagnostic completed at: $(date)"
echo ""
echo "RECOMMENDATION:"
echo "1. If Test 1 works but Test 2 hangs: LIVE TRADING LOGIC IS BROKEN"
echo "2. Disable cron job immediately"
echo "3. Debug live trading functions in mert_sniper.py"
echo "4. Only re-enable after fixing live trading issues"