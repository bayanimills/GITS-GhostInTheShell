#!/usr/bin/env python3
import os
from datetime import datetime, timezone, timedelta

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

from simmer_sdk import SimmerClient
client = SimmerClient(api_key=api_key)

print("=== Market Scan (active, expiring within 120min) ===")
markets = client.get_markets(limit=200, status='active')
now = datetime.now(timezone.utc)
threshold = now + timedelta(minutes=120)
print(f"Total active markets: {len(markets)}")
print(f"Now UTC: {now}")
print(f"Expiry threshold (UTC): {threshold}")

candidates = []
for m in markets:
    expiry = m.resolves_at
    if not expiry:
        continue
    if expiry > threshold:
        continue
    prob = m.current_probability
    mins_left = (expiry - now).total_seconds() / 60
    # Check split thresholds
    min_split = 0.54  # test lower threshold
    if prob < min_split and prob > (1 - min_split):
        # split too narrow
        pass
    else:
        # eligible
        underdog_price = prob if prob <= (1 - min_split) else (1 - prob)
        underdog_side = "YES" if prob <= (1 - min_split) else "NO"
        candidates.append((mins_left, prob, m, underdog_side, underdog_price))

print(f"\nCandidates with min_split {min_split}:")
for mins_left, prob, m, side, price in sorted(candidates, key=lambda x: x[0]):
    print(f"  {m.id}: {m.question[:60]}...")
    print(f"    Expires: {mins_left:.1f} min, Split: YES {prob:.1%} / NO {1-prob:.1%}")
    print(f"    Underdog: {side} @ {price:.1%}")

print(f"\nTotal candidates: {len(candidates)}")