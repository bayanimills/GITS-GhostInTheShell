#!/usr/bin/env python3
"""
Generate comprehensive report for Simmer positions, April markets, and arbitrage opportunities.
"""
import json
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY = 'sk_live_a20bb67064b7db925e7f8c854de2e91e4ffc3ef495acd91f5f170d9eb6224671'
BASE_URL = 'https://api.simmer.markets/api/sdk'
HEADERS = {
    'Authorization': f'Bearer {API_KEY}',
    'Content-Type': 'application/json',
    'User-Agent': 'DannyTrader/1.0'
}
REQUEST_DELAY = 1.5  # seconds between API calls

# Paths
TRADES_PATH = '/home/agent/.openclaw/workspace/skills/prediction-trade-journal/data/trades.json'

def api_get(endpoint: str, params: dict = None) -> Optional[Dict]:
    """Make GET request to Simmer API."""
    url = f"{BASE_URL}/{endpoint}"
    try:
        resp = requests.get(url, headers=HEADERS, params=params, timeout=30, verify=False)
        if resp.status_code == 200:
            return resp.json()
        else:
            print(f"  API error {resp.status_code} on {endpoint}: {resp.text[:200]}")
            return None
    except Exception as e:
        print(f"  Exception on {endpoint}: {e}")
        return None

def get_portfolio(venue: str) -> Optional[Dict]:
    """Get portfolio for a venue."""
    return api_get('portfolio', {'venue': venue})

def get_positions(venue: str, status: str = None) -> Optional[Dict]:
    """Get positions for a venue with optional status filter."""
    params = {'venue': venue}
    if status:
        params['status'] = status
    return api_get('positions', params)

def get_market(market_id: str) -> Optional[Dict]:
    """Get market details."""
    return api_get(f'markets/{market_id}')

def list_markets(limit: int = 100) -> Optional[List]:
    """List markets with pagination."""
    params = {'limit': limit}
    data = api_get('markets', params)
    if data and 'markets' in data:
        return data['markets']
    return []

def analyze_positions():
    """Answer question 1: Open positions discrepancy."""
    print("\n" + "="*80)
    print("1. OPEN POSITIONS DISCREPANCY")
    print("="*80)
    
    venues = ['polymarket', 'simmer']
    
    for venue in venues:
        print(f"\n--- Venue: {venue} ---")
        portfolio = get_portfolio(venue)
        if not portfolio:
            print("  Failed to fetch portfolio")
            continue
        print(f"  Portfolio keys: {list(portfolio.keys())}")
        positions_count = portfolio.get('positions_count', 0)
        balance_usdc = portfolio.get('balance_usdc', 'N/A')
        balance_sim = portfolio.get('balance_sim', 'N/A')
        print(f"  positions_count: {positions_count}")
        print(f"  balance_usdc: {balance_usdc}")
        print(f"  balance_sim: {balance_sim}")
        
        # Get positions with default (active)
        positions_data = get_positions(venue)
        if not positions_data:
            print("  Failed to fetch positions")
            continue
        positions = positions_data.get('positions', [])
        position_counts = positions_data.get('position_counts', {})
        print(f"  Positions array length: {len(positions)}")
        print(f"  Position counts: {position_counts}")
        
        # Check discrepancy
        if positions_count > 0 and len(positions) == 0:
            print(f"  ⚠️  DISCREPANCY: portfolio shows {positions_count} positions but positions array empty.")
            print(f"  Explanation: positions are not active (status resolved or closed).")
        
        # Fetch resolved positions
        resolved_data = get_positions(venue, status='resolved')
        resolved_positions = resolved_data.get('positions', []) if resolved_data else []
        print(f"  Resolved positions: {len(resolved_positions)}")
        # Fetch closed positions
        closed_data = get_positions(venue, status='closed')
        closed_positions = closed_data.get('positions', []) if closed_data else []
        print(f"  Closed positions: {len(closed_positions)}")
        
        # If there are resolved positions, list them
        if resolved_positions:
            print(f"  Resolved position details:")
            for pos in resolved_positions[:5]:  # limit
                market_id = pos.get('market_id')
                side = pos.get('side')
                shares = pos.get('shares')
                cost = pos.get('cost')
                print(f"    - {market_id} side {side} shares {shares} cost ${cost}")
                # Fetch market details for resolution date
                market = get_market(market_id)
                if market:
                    resolves_at = market.get('resolves_at')
                    print(f"      Resolves at: {resolves_at}")
                time.sleep(REQUEST_DELAY)
        
        # Check if any positions are resolved but not redeemed (only for polymarket)
        if venue == 'polymarket' and resolved_positions:
            # Check trade journal for unresolved trades
            print(f"\n  Checking trade journal for unresolved trades...")
            if os.path.exists(TRADES_PATH):
                with open(TRADES_PATH, 'r') as f:
                    trades_data = json.load(f)
                trades = trades_data.get('trades', [])
                unresolved = [t for t in trades if not t.get('outcome', {}).get('resolved', False)]
                print(f"    Total trades: {len(trades)}")
                print(f"    Unresolved trades: {len(unresolved)}")
                # For each resolved position, check if redeemed
                for pos in resolved_positions:
                    market_id = pos.get('market_id')
                    side = pos.get('side')
                    # Find trades for this market and side
                    market_trades = [t for t in trades if t.get('market_id') == market_id and t.get('side') == side]
                    for t in market_trades:
                        outcome = t.get('outcome', {})
                        if outcome.get('resolved') and not outcome.get('redeemed_at'):
                            print(f"    ❗ Position not redeemed: market {market_id} side {side}")
            else:
                print("    Trade journal not found.")
        
        # Clarify $SIM vs USDC positions
        if venue == 'simmer':
            print(f"\n  $SIM positions analysis:")
            print(f"    Balance SIM: {balance_sim}")
            # Check if any positions are denominated in SIM
            sim_positions = [p for p in resolved_positions + closed_positions if p.get('currency') == 'SIM']
            print(f"    Positions denominated in SIM: {len(sim_positions)}")
            if sim_positions:
                print(f"    SIM positions IDs: {[p.get('market_id') for p in sim_positions]}")
            else:
                print(f"    No SIM positions found.")
    
    # Additional analysis: compare position counts with trade journal
    print(f"\n--- Cross-venue summary ---")
    total_resolved = 0
    total_closed = 0
    for venue in venues:
        resolved_data = get_positions(venue, status='resolved')
        closed_data = get_positions(venue, status='closed')
        total_resolved += len(resolved_data.get('positions', [])) if resolved_data else 0
        total_closed += len(closed_data.get('positions', [])) if closed_data else 0
    print(f"  Total resolved positions across venues: {total_resolved}")
    print(f"  Total closed positions across venues: {total_closed}")
    print(f"  Matches user's 16 simmer venue positions (6 resolved, 10 closed)?")
    print(f"    Resolved: {total_resolved} vs 6")
    print(f"    Closed: {total_closed} vs 10")

def analyze_april_markets():
    """Answer question 2: Markets expiring in April 2026."""
    print("\n" + "="*80)
    print("2. MARKETS ACCESSIBLE FOR REVIEW (April 2026 expiry)")
    print("="*80)
    
    print("\nFetching markets (limit 100)...")
    markets = list_markets(limit=100)
    if not markets:
        print("Failed to fetch markets.")
        return
    
    april_markets = []
    for market in markets:
        resolves_at = market.get('resolves_at')
        if not resolves_at:
            continue
        try:
            dt = datetime.fromisoformat(resolves_at.replace('Z', '+00:00'))
            if dt.year == 2026 and dt.month == 4:
                april_markets.append(market)
        except:
            continue
    
    print(f"Found {len(april_markets)} markets expiring in April 2026.")
    if not april_markets:
        return
    
    # For each market, fetch current prices, liquidity, divergence
    print("\nDetailed analysis of April markets:")
    for market in april_markets[:10]:  # limit to 10 for brevity
        market_id = market.get('id')
        question = market.get('question', 'Unknown')
        resolves_at = market.get('resolves_at')
        yes_price = market.get('yes_price')
        no_price = market.get('no_price')
        volume = market.get('volume_24h')
        liquidity = market.get('liquidity')
        simmer_prob = market.get('simmer_probability')
        
        print(f"\n  Market: {question[:80]}...")
        print(f"    ID: {market_id}")
        print(f"    Expires: {resolves_at}")
        print(f"    Yes price: {yes_price}")
        print(f"    No price: {no_price}")
        print(f"    Volume 24h: {volume}")
        print(f"    Liquidity: {liquidity}")
        print(f"    Simmer probability: {simmer_prob}")
        
        # Check for price divergence
        if yes_price is not None and no_price is not None:
            sum_price = yes_price + no_price
            if abs(sum_price - 1.0) > 0.01:
                print(f"    ⚠️  Price sum deviation: {sum_price:.4f} (should be 1.0)")
        
        if simmer_prob is not None and yes_price is not None:
            diff = simmer_prob - yes_price
            if abs(diff) > 0.1:
                print(f"    ⚠️  Significant divergence Simmer vs market: {diff:+.3f}")
        
        time.sleep(REQUEST_DELAY)
    
    # If more than 10, just list the rest
    if len(april_markets) > 10:
        print(f"\n  ... and {len(april_markets) - 10} more April markets.")

def analyze_arbitrage():
    """Answer question 3: True arbitrage opportunities."""
    print("\n" + "="*80)
    print("3. TRUE ARBITRAGE OPPORTUNITIES")
    print("="*80)
    
    print("\nFetching markets to examine arbitrage potential...")
    markets = list_markets(limit=50)  # reasonable sample
    if not markets:
        print("Failed to fetch markets.")
        return
    
    print(f"Analyzing {len(markets)} markets for arbitrage.")
    
    # Strategy 1: Simple yes+no price sum deviation (LMSR arbitrage)
    print("\n--- Strategy 1: LMSR price sum deviation ---")
    deviations = []
    for market in markets:
        yes_price = market.get('yes_price')
        no_price = market.get('no_price')
        if yes_price is not None and no_price is not None:
            sum_price = yes_price + no_price
            deviation = abs(sum_price - 1.0)
            if deviation > 0.001:  # threshold
                deviations.append((deviation, market))
    
    if deviations:
        deviations.sort(key=lambda x: x[0], reverse=True)
        print(f"Found {len(deviations)} markets with price sum ≠ 1.0")
        for dev, market in deviations[:5]:
            yes_price = market.get('yes_price')
            no_price = market.get('no_price')
            sum_price = yes_price + no_price
            print(f"  Market: {market.get('question', 'Unknown')[:60]}...")
            print(f"    Yes: {yes_price:.4f}, No: {no_price:.4f}, Sum: {sum_price:.4f}")
            print(f"    Deviation: {dev:.4f}")
            # Calculate arbitrage profit if buy both sides at current prices
            profit_per_share = 1.0 - sum_price
            if profit_per_share > 0:
                print(f"    Potential profit per share: {profit_per_share:.4f} (buy both, redeem for $1)")
            else:
                print(f"    Loss per share: {profit_per_share:.4f} (sell both)")
    else:
        print("No significant deviations found (LMSR efficient).")
    
    # Strategy 2: Cross-market arbitrage (same question different platforms)
    # We only have Polymarket via Simmer; cannot access other platforms.
    print("\n--- Strategy 2: Cross-market arbitrage ---")
    print("  Requires access to multiple prediction markets platforms (e.g., Polymarket, Kalshi, Metaculus).")
    print("  Currently only have Polymarket via Simmer SDK.")
    print("  No cross-market opportunities detectable.")
    
    # Strategy 3: Time arbitrage (price differences over time)
    print("\n--- Strategy 3: Time arbitrage ---")
    print("  Requires historical price data and ability to short-sell.")
    print("  Not feasible with current API access.")
    
    # Strategy 4: Structural arbitrage (market mechanism inefficiencies)
    print("\n--- Strategy 4: Structural arbitrage ---")
    print("  Example: Mispricing between Simmer AI probability and market price.")
    print("  Scanning for significant divergences...")
    divergences = []
    for market in markets:
        simmer_prob = market.get('simmer_probability')
        yes_price = market.get('yes_price')
        if simmer_prob is not None and yes_price is not None:
            diff = simmer_prob - yes_price
            if abs(diff) > 0.1:  # threshold 10%
                divergences.append((abs(diff), diff, market))
    
    if divergences:
        divergences.sort(key=lambda x: x[0], reverse=True)
        print(f"  Found {len(divergences)} markets with >10% divergence.")
        for _, diff, market in divergences[:3]:
            print(f"    Market: {market.get('question', 'Unknown')[:60]}...")
            print(f"      Simmer AI: {market.get('simmer_probability'):.3f}")
            print(f"      Market Yes price: {market.get('yes_price'):.3f}")
            print(f"      Difference: {diff:+.3f}")
            print(f"      Suggested action: {'Buy Yes' if diff > 0 else 'Buy No'}")
    else:
        print("  No significant divergences found.")
    
    # Strategy 5: Pair trading across correlated markets
    print("\n--- Strategy 5: Pair trading across correlated markets ---")
    print("  Requires identifying correlated questions (e.g., same event different wording).")
    print("  Not implemented due to complexity.")
    
    print("\nArbitrage feasibility assessment:")
    print("  - Simple yes+no arbitrage extremely rare on LMSR (none found).")
    print("  - Cross-market arbitrage not possible without multi-platform access.")
    print("  - Time arbitrage requires historical data and short-selling.")
    print("  - Structural arbitrage (Simmer AI vs market) possible but requires capital and risk.")
    print("  - Pair trading requires sophisticated correlation analysis.")

def main():
    print("Generating comprehensive report...")
    print("Timestamp:", datetime.now().isoformat())
    
    # Question 1
    analyze_positions()
    time.sleep(REQUEST_DELAY)
    
    # Question 2
    analyze_april_markets()
    time.sleep(REQUEST_DELAY)
    
    # Question 3
    analyze_arbitrage()
    
    print("\n" + "="*80)
    print("REPORT COMPLETE")
    print("="*80)

if __name__ == '__main__':
    main()