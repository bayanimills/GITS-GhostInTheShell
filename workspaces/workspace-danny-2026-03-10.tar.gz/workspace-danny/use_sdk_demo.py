#!/usr/bin/env python3
"""
Demonstrate SDK usage per user request.
Performs a dry-run trade using Simmer SDK's trade method,
with pre-trade context check and market scanning.
"""

import sys
import os
from datetime import datetime, timezone, timedelta

# Add skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

from simmer_sdk import SimmerClient

# Load API key
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

if not api_key:
    print("❌ SIMMER_API_KEY not found")
    sys.exit(1)

client = SimmerClient(api_key=api_key, venue="polymarket")
print("✅ SimmerClient initialized")

# Step 1: Fetch active markets with near expiry
print("\n🔍 Scanning for near‑expiry markets (≤120 minutes)...")
markets = client.get_markets(status='active', limit=100)
candidates = []
now = datetime.now(timezone.utc)
for m in markets:
    if not hasattr(m, 'resolves_at') or not m.resolves_at:
        continue
    try:
        resolves = datetime.fromisoformat(m.resolves_at.replace('Z', '+00:00'))
    except Exception:
        continue
    hours_to_res = (resolves - now).total_seconds() / 3600
    if 0 < hours_to_res <= 2:  # within 2 hours
        candidates.append((m, hours_to_res))

print(f"   Found {len(candidates)} markets expiring within 2h")

# Step 2: Filter for underdog side (≤45% probability) as per counter‑bot strategy
print("\n🎯 Filtering for underdog side (≤45% probability)...")
trade_candidates = []
for m, hours in candidates:
    prob = m.current_probability
    if prob <= 0.45:
        trade_candidates.append((m, hours, 'YES', prob))
    elif prob >= 0.55:
        trade_candidates.append((m, hours, 'NO', 1 - prob))

print(f"   {len(trade_candidates)} candidates meet underdog criteria")

if not trade_candidates:
    print("No suitable underdog markets found. Trying any market for demo.")
    # Pick any near-expiry market for demo
    if candidates:
        m, hours = candidates[0]
        side = 'YES' if m.current_probability <= 0.5 else 'NO'
        trade_candidates.append((m, hours, side, m.current_probability if side == 'YES' else 1 - m.current_probability))

if not trade_candidates:
    print("❌ No markets found for demo.")
    sys.exit(0)

# Pick the first candidate
market, hours_to_res, side, implied_prob = trade_candidates[0]
print(f"\n📊 Selected market:")
print(f"   Question: {market.question[:80]}...")
print(f"   Market ID: {market.id}")
print(f"   Current YES probability: {market.current_probability:.2%}")
print(f"   Side to trade: {side} (implied probability: {implied_prob:.2%})")
print(f"   Resolves at: {market.resolves_at} ({hours_to_res:.1f}h from now)")

# Step 3: Pre‑trade context check (mandatory for safety)
print("\n🧪 Getting market context...")
try:
    ctx = client.get_market_context(market.id)
    warnings = ctx.get('warnings', [])
    if warnings:
        print(f"   ⚠️  Warnings: {warnings}")
    else:
        print("   ✅ No warnings")
    # Check slippage
    slippage = ctx.get('slippage', {}).get('estimates', [])
    if slippage:
        print(f"   📉 Slippage estimate: {slippage[0].get('slippage_pct', 0):.1%}")
except Exception as e:
    print(f"   ❌ Context fetch failed: {e}")
    ctx = None

# Step 4: Dry‑run trade using SDK's trade method
print("\n💰 Attempting dry‑run trade via SDK trade() method...")
try:
    # Try with dry_run parameter (might not be supported)
    result = client.trade(
        market_id=market.id,
        side=side.lower(),  # 'yes' or 'no'
        amount=0.001,       # tiny amount
        venue='polymarket',
        source='sdk:demo',
        reasoning='Demonstrating SDK usage per user request.',
        dry_run=True
    )
    print("   ✅ Dry‑run trade succeeded")
    # Result may be a TradeResult object; try to access attributes
    if hasattr(result, 'shares_bought'):
        print(f"   Shares bought: {result.shares_bought}")
    if hasattr(result, 'cost'):
        print(f"   Cost: {result.cost}")
    # Print all attributes
    print(f"   Result object: {result}")
except TypeError as e:
    if "dry_run" in str(e):
        print(f"   ⚠️  dry_run parameter not supported, trying without...")
        # Retry without dry_run but with tiny amount (risk minimal)
        try:
            result = client.trade(
                market_id=market.id,
                side=side.lower(),
                amount=0.001,
                venue='polymarket',
                source='sdk:demo',
                reasoning='Demonstrating SDK usage (real trade, tiny amount).'
            )
            print(f"   ⚠️  Real trade executed (tiny amount). Result: {result}")
        except Exception as e2:
            print(f"   ❌ Trade failed: {e2}")
    else:
        print(f"   ❌ Trade error: {e}")
except Exception as e:
    print(f"   ❌ Unexpected error: {e}")

# Step 5: Verify trade appears in recent trades list
print("\n📋 Checking recent trades...")
try:
    trades = client._request("GET", "/api/sdk/trades", params={"limit": 5})
    print(f"   Recent trades count: {len(trades)}")
    if trades:
        latest = trades[0]
        print(f"   Latest trade: {latest.get('market_question', 'N/A')[:60]}...")
except Exception as e:
    print(f"   ❌ Could not fetch trades: {e}")

print("\n🎯 SDK usage demonstration complete.")