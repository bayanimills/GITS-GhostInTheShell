#!/usr/bin/env python3
"""
Check redeemable positions using Simmer SDK.
Answer user question: "Are you redeeming as per SDK/"
"""

import sys
import os
from datetime import datetime

# Add skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

from simmer_sdk import SimmerClient

# Load API key
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

if not api_key:
    print("❌ SIMMER_API_KEY not found")
    sys.exit(1)

client = SimmerClient(api_key=api_key, venue="polymarket")
print("✅ SimmerClient initialized")

print("\n🔍 Checking portfolio...")
portfolio = client.get_portfolio()
print(f"   Balance: ${portfolio.get('balance', 0):.2f} USDC")
print(f"   Positions count: {portfolio.get('positions_count', 0)}")
print(f"   Exposure: ${portfolio.get('exposure', 0):.2f}")

print("\n📋 Fetching positions...")
try:
    positions = client.get_positions()
    print(f"   API returned {len(positions)} positions")
except Exception as e:
    print(f"   ❌ Failed to fetch positions: {e}")
    positions = []

if positions:
    print("\n📊 Position details:")
    redeemable_positions = []
    for i, pos in enumerate(positions):
        market_id = pos.get('market_id', 'N/A')
        shares_yes = pos.get('shares_yes', 0)
        shares_no = pos.get('shares_no', 0)
        redeemable = pos.get('redeemable', False)
        status = pos.get('status', 'unknown')
        print(f"   {i+1}. {market_id[:8]}... | YES: {shares_yes:.1f} | NO: {shares_no:.1f} | Redeemable: {redeemable} | Status: {status}")
        if redeemable:
            redeemable_positions.append((market_id, shares_yes, shares_no))
    
    if redeemable_positions:
        print(f"\n🎉 Found {len(redeemable_positions)} redeemable position(s)!")
        for market_id, yes, no in redeemable_positions:
            side = 'YES' if yes > 0 else 'NO'
            print(f"   Market {market_id[:8]}... side {side}")
            # Could redeem here using client.redeem(market_id, side.lower())
    else:
        print("\n📭 No redeemable positions found.")
else:
    print("\n📭 No positions returned by get_positions() (API inconsistency).")

# Alternative: check briefing for positions
print("\n🔍 Checking briefing for positions...")
try:
    briefing = client._request("GET", "/api/sdk/briefing")
    active_positions = briefing.get('positions', {}).get('active', [])
    print(f"   Briefing active positions: {len(active_positions)}")
    if active_positions:
        for pos in active_positions[:3]:
            print(f"   - {pos.get('market_question', 'N/A')[:60]}...")
except Exception as e:
    print(f"   ❌ Briefing fetch failed: {e}")

print("\n💰 SDK redeem method available:")
try:
    # Check if redeem method exists and can be called
    import inspect
    sig = inspect.signature(client.redeem)
    print(f"   client.redeem(market_id, side) signature: {sig}")
except Exception as e:
    print(f"   ❌ Cannot inspect redeem: {e}")

print("\n🎯 Answer for user:")
if positions:
    redeemable_count = sum(1 for p in positions if p.get('redeemable', False))
    if redeemable_count > 0:
        print("   YES – there are redeemable positions. Use SDK's `client.redeem(market_id, side)` to redeem.")
        print("   Example: client.redeem('market-uuid', 'yes')")
    else:
        print("   NO redeemable positions currently. All positions are active/unresolved.")
else:
    print("   NO positions returned by API (inconsistency). Cannot determine redeemable status.")
    print("   However, SDK redeem method is available for when positions become redeemable.")

print("\n✅ Check complete.")