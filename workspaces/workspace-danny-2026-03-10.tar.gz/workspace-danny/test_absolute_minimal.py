#!/usr/bin/env python3
import os
import sys
import time

# Load environment
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key] = value

print("=== ABSOLUTE MINIMAL TEST ===")
print(f"SIMMER_API_KEY present: {'YES' if os.environ.get('SIMMER_API_KEY') else 'NO'}")

# Add skill directory to path
skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

try:
    print("1. Importing mert_sniper modules...")
    import mert_sniper
    print("   ✓ Import successful")
    
    print("2. Testing get_client() function...")
    client = mert_sniper.get_client()
    print("   ✓ Client obtained")
    
    print("3. Testing fetch_markets() function...")
    markets = mert_sniper.fetch_markets()
    print(f"   ✓ Fetched {len(markets)} markets")
    
    print("4. Testing find_near_expiry() function...")
    near = mert_sniper.find_near_expiry(markets, expiry_minutes=60)
    print(f"   ✓ Found {len(near)} near-expiry markets")
    
    print("=== TEST COMPLETE ===")
    
except Exception as e:
    print(f"✗ ERROR: {type(e).__name__}: {e}")
    import traceback
    print(f"Traceback:\n{traceback.format_exc()}")