#!/usr/bin/env python3
import os
import sys
from pathlib import Path

# Add simmer-sdk to path if installed locally
try:
    from simmer_sdk import SimmerClient
except ImportError:
    os.system("pip install simmer-sdk -q")
    from simmer_sdk import SimmerClient

# Get API key
API_KEY = os.environ.get("SIMMER_API_KEY", "")
if not API_KEY:
    secrets_path = Path("/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env")
    if secrets_path.exists():
        with open(secrets_path) as f:
            for line in f:
                if line.strip().startswith("SIMMER_API_KEY="):
                    API_KEY = line.strip().split("=", 1)[1].split()[0]
                    break

if not API_KEY:
    print("❌ SIMMER_API_KEY not set")
    sys.exit(1)

client = SimmerClient(api_key=API_KEY, venue="polymarket")

print("📊 Portfolio:")
portfolio = client.get_portfolio()
print(f"   Balance: ${portfolio.get('balance', 0):.2f}")
print(f"   Exposure: ${portfolio.get('exposure', 0):.2f}")
print(f"   Positions count: {portfolio.get('positions_count', 0)}")
print()

print("📋 Positions:")
try:
    positions = client.get_positions()
    print(f"   Retrieved {len(positions)} positions")
    redeemable = []
    for p in positions:
        redeemable_flag = p.get('redeemable', False)
        if redeemable_flag:
            redeemable.append(p)
        # Print first few
        if len(redeemable) <= 5:
            print(f"   Market: {p.get('question', 'Unknown')[:50]}")
            print(f"     Side: {p.get('side', '?')}")
            print(f"     Value: ${p.get('current_value', 0):.2f}")
            print(f"     Redeemable: {redeemable_flag}")
            print()
    
    if len(redeemable) > 0:
        print(f"🎯 {len(redeemable)} redeemable positions found!")
        for p in redeemable[:10]:
            print(f"   - {p.get('question', 'Unknown')[:50]} | {p.get('side', '?')} | ${p.get('current_value', 0):.2f}")
    else:
        print("📭 No redeemable positions found.")
    
except Exception as e:
    print(f"   Error: {e}")
    import traceback
    traceback.print_exc()