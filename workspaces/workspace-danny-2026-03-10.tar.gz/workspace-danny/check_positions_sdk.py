#!/usr/bin/env python3
"""
Check positions via SDK endpoints to understand inconsistency.
"""

import sys
import os
import json

skill_dir = "/home/agent/.openclaw/workspace/skills/polymarket-mert-sniper"
if skill_dir not in sys.path:
    sys.path.insert(0, skill_dir)

from simmer_sdk import SimmerClient

secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
api_key = None
with open(secrets_path) as f:
    for line in f:
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            break

client = SimmerClient(api_key=api_key)

print("🔍 Checking portfolio endpoint...")
portfolio = client._request("GET", "/api/sdk/portfolio")
print(json.dumps(portfolio, indent=2, default=str))

print("\n🔍 Checking positions endpoint...")
positions = client._request("GET", "/api/sdk/positions")
print(f"Positions array length: {len(positions)}")
if positions:
    print("First position:")
    print(json.dumps(positions[0], indent=2, default=str))

print("\n🔍 Checking briefing positions...")
briefing = client._request("GET", "/api/sdk/briefing")
active = briefing.get('positions', {}).get('active', [])
print(f"Briefing active positions: {len(active)}")
if active:
    print("First active:")
    print(json.dumps(active[0], indent=2, default=str))

# Check if any positions have redeemable true
if positions:
    redeemable = [p for p in positions if p.get('redeemable')]
    print(f"\n💰 Redeemable positions: {len(redeemable)}")
    for p in redeemable:
        print(f"  Market {p.get('market_id')[:8]}... side YES: {p.get('shares_yes')} NO: {p.get('shares_no')}")
else:
    print("\n📭 No positions returned.")

# Also check markets that might be resolved but positions not showing
print("\n🔍 Checking markets endpoint (active)...")
markets = client.get_markets(status='active', limit=20)
print(f"Active markets: {len(markets)}")
# Check for resolved markets
markets2 = client.get_markets(status='resolved', limit=10)
print(f"Resolved markets: {len(markets2)}")
for m in markets2[:5]:
    print(f"  {m.id[:8]}... {m.question[:50]}")

print("\n✅ Done.")