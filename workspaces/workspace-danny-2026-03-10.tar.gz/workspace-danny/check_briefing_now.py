#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from simmer_sdk import SimmerClient

# Load API key
secrets_path = "/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env"
if os.path.exists(secrets_path):
    with open(secrets_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key] = value

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    print("ERROR: SIMMER_API_KEY not found")
    sys.exit(1)

client = SimmerClient(api_key=api_key)
briefing = client._request("GET", "/api/sdk/briefing")
print("Briefing active positions:", briefing.get("positions", {}).get("active", 0))
print("Briefing balance:", briefing.get("venues", {}).get("polymarket", {}).get("balance"))
print("Positions count:", briefing.get("venues", {}).get("polymarket", {}).get("positions_count"))

# Also get portfolio
portfolio = client._request("GET", "/api/sdk/portfolio")
print("Portfolio positions_count:", portfolio.get("positions_count"))
print("Portfolio balance:", portfolio.get("balance"))

# Check if any trades today
trades = client._request("GET", "/api/sdk/trades")
print("Total trades count:", len(trades) if isinstance(trades, list) else "N/A")
today_trades = [t for t in trades if isinstance(t, dict) and t.get("created_at", "").startswith("2026-02-28")]
print("Today trades count:", len(today_trades))