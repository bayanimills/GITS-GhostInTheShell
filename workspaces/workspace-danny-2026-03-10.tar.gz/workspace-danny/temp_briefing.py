#!/usr/bin/env python3
import os
import json
from pathlib import Path

# Get API key
API_KEY = os.environ.get("SIMMER_API_KEY", "")
if not API_KEY:
    secrets_path = Path("/home/agent/.openclaw/workspace-danny/.openclaw/secrets.env")
    if secrets_path.exists():
        with open(secrets_path) as f:
            for line in f:
                if line.strip().startswith("SIMMER_API_KEY="):
                    API_KEY = line.strip().split("=", 1)[1].split()[0]
                    break

if not API_KEY:
    print("❌ SIMMER_API_KEY not set")
    exit(1)

import requests

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

# Try both venues
for venue in ["polymarket", "polymarket-test"]:
    print(f"\n📡 Briefing for venue: {venue}")
    try:
        response = requests.get(
            f"https://api.simmer.io/api/sdk/briefing?venue={venue}",
            headers=headers,
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            print(json.dumps(data, indent=2))
        else:
            print(f"   HTTP {response.status_code}: {response.text[:100]}")
    except Exception as e:
        print(f"   Error: {e}")