# SKILL.md – Aged Care Transition

## Purpose
Guide a patient (default: Edward Mills) through the entire aged‑care transition process—from assessment to moving in—using verified data and automated tools.

## Components

### 1. Knowledge Base (`knowledge/`)
Structured notes extracted from agedcareguide.com.au and My Aged Care:
- `types_of_care.md` – Overview of home care, residential care, dementia care, respite, palliative.
- `costs_fees.md` – RAD/DAP, daily fees, means‑tested fees, subsidies.
- `assessment_process.md` – ACAT/ACAS referral, assessment criteria, outcomes.
- `rights_standards.md` – Charter of Aged Care Rights, Quality Standards, complaints, advocacy.
- `finding_home.md` – Search strategies, facility visits, questions to ask.

### 2. Patient Profile (`profile/`)
Editable template capturing:
- Medical needs, medications, mobility, cognitive status.
- Preferences (location, room type, cultural/religious needs).
- Financial summary (assets, income, home ownership).
- Family contacts, GP details, key decision‑makers.

Default profile: `edward_mills.json` (linked to Dart patient‑edward‑mills tasks).

### 3. Facility Matcher (`matcher/`)
Uses Notion database **Northern Beaches Nursing Homes** (ID: `6088ea51‑fa49‑4102‑a6fb‑250eccc9f1ad`).
- Filters by suburb, postcode, service type, specialised services (stroke rehab, dementia).
- Fetches real‑time Star Ratings and complaints history via agedcareguide.com.au.
- Outputs comparison table (cost, distance, features).

### 4. Cost Estimator (`estimator/`)
Python script using My Aged Care fee formulas:
- Calculates approximate RAD, daily fees, means‑tested fees based on asset/income input.
- Generates simple report for family discussion.

### 5. Step‑by‑Step Checklist (`checklist/`)
Interactive checklist (Markdown + Dart integration):
1. ACAT referral (template letter to GP).
2. Gather financial documents.
3. Shortlist facilities (Notion filter).
4. Visit facilities (questions list).
5. Submit applications.
6. Arrange finances (RAD/DAP decision).
7. Move‑in planning.

Each step creates a Dart subtask under the stroke event (`YhH8uggrObRf`).

### 6. Integration (`integration/`)
- **Dart:** Creates/updates tasks in Edward Mills’ workspace.
- **Notion:** Reads/writes facility data.
- **AgentMail:** Sends updates to family/GP.
- **Cron:** Weekly check‑ins on progress.

## Usage

### Command‑line
```bash
# Load patient profile (default: Edward Mills)
./skills/aged-care-transition/load_profile.sh

# Run cost estimator (example for Edward Mills)
./skills/aged-care-transition/estimator/estimate.py --assets 800000 --income 30000 --homeowner

# Generate facility shortlist
./skills/aged-care-transition/matcher/match.py --suburb "Manly Vale" --service-type "Nursing Home"

# Update checklist
./skills/aged-care-transition/checklist/next_step.py --next

# Mark step as completed
./skills/aged-care-transition/checklist/next_step.py --complete "ACAT referral"

# Create Dart subtask for next step
./skills/aged-care-transition/checklist/next_step.py --next --create-dart

# Orchestration (suggest next steps)
./skills/aged-care-transition/integration/orchestrate.py
```

### Within OpenClaw session
Use the skill by reading this file, then:
1. Load patient profile (`load_profile.sh`).
2. Recommend next steps based on current stage (`orchestrate.py`).
3. Search facilities (`match.py`).
4. Estimate costs (`estimate.py`).
5. Update checklist and Dart tasks (`next_step.py`).

All scripts are in the respective subdirectories of this skill.

## Dependencies
- Notion API key (`~/.config/notion/api_key`)
- Dart API token (`DART_API_TOKEN` environment variable)
- Northern Beaches Nursing Homes Notion database (ID: `6088ea51‑fa49‑4102‑a6fb‑250eccc9f1ad`)
- Edward Mills’ Dart workspace (tag `patient‑edward‑mills`)
- Python 3.8+ with requests library
- `jq` command‑line tool (for load_profile.sh)
- OpenClaw browser automation (optional, for scraping Star Ratings)

## Integration with Edward Mills’ Stroke Event
- Parent Dart task: `YhH8uggrObRf` (Stroke Event 2026‑02‑18 – RNSH)
- Sub‑tasks will be created under this parent with tag `aged‑care‑transition`.
- Notion database is already populated with 12 real Northern Beaches facilities.
- Use the checklist to track progress; each step can be linked to a Dart sub‑task.

## Enhancements Implemented
| Enhancement | Status | Location |
|-------------|--------|----------|
| Star Ratings integration | Properties added to Notion; scraper skeleton ready | `enhancements/update_notion_properties.py`, `scrape_star_ratings.py` |
| ACAT referral template | ✅ Complete – generates draft letter for GP | `enhancements/acat_referral.py` |
| Family notification | ✅ Script ready (AgentMail integration) | `enhancements/family_notification.py` |
| Progress dashboard | ✅ HTML dashboard generator | `enhancements/dashboard.py` |
| Risk scoring | ✅ Algorithm implemented; updates Notion Risk Score | `enhancements/risk_scoring.py` |
| Document generation (PDF) | ✅ Markdown generator; PDF via pandoc | `enhancements/generate_document.py` |
| Cron automation | ✅ Daily cron job added (8 AM Sydney) | `enhancements/cron_check_updates.py` |
| Multi‑patient support | *Planned* | |

## Notes
- **Never invent data.** All facility information must come from agedcareguide.com.au or My Aged Care.
- **Always confirm with family** before taking financial/legal actions.
- **Log all steps** in `memory/YYYY‑MM‑DD.md` and `MEMORY.md`.

---
*Skill created 2026‑02‑21. Updated automatically as new insights are gathered.*