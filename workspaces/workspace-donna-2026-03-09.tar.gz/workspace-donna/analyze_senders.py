#!/usr/bin/env python3
"""
Analyze most prolific email senders in inbox over last 30 days.
"""
import subprocess
import json
import sys
from collections import Counter
from email.utils import parseaddr
import re

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def extract_domain(email_address):
    """Extract domain from email address."""
    _, email = parseaddr(email_address)
    if '@' in email:
        return email.lower().split('@')[1]
    return email.lower()

def analyze_senders(days=30):
    """Fetch emails from last N days and count sender domains."""
    print(f"Fetching emails from last {days} days...")
    
    # First get thread IDs
    query = f"in:inbox newer_than:{days}d"
    cmd = ["gmail", "search", query, "--max", "500", "--json"]
    success, output = run_gog(cmd)
    if not success:
        print("Failed to fetch threads.")
        return
    
    try:
        data = json.loads(output)
        threads = data.get('threads', [])
    except json.JSONDecodeError:
        print("Failed to parse JSON response.")
        return
    
    if not threads:
        print("No threads found.")
        return
    
    print(f"Found {len(threads)} threads.")
    
    # Get messages for each thread to extract sender
    sender_counter = Counter()
    sender_details = {}  # domain -> list of (sender, subject)
    
    for i, thread in enumerate(threads):
        if not isinstance(thread, dict) or 'id' not in thread:
            continue
            
        thread_id = thread['id']
        # Get thread details
        cmd = ["gmail", "thread", "get", thread_id, "--json"]
        success, thread_output = run_gog(cmd)
        if not success:
            continue
            
        try:
            thread_data = json.loads(thread_output)
        except json.JSONDecodeError:
            continue
            
        if not isinstance(thread_data, dict) or 'messages' not in thread_data:
            continue
            
        messages = thread_data['messages']
        if not messages:
            continue
            
        # Use first message's sender
        first_msg = messages[0]
        headers = first_msg.get('headers', {})
        sender = headers.get('From', '')
        subject = headers.get('Subject', 'No subject')[:50]
        
        domain = extract_domain(sender)
        sender_counter[domain] += 1
        
        if domain not in sender_details:
            sender_details[domain] = []
        sender_details[domain].append((sender, subject))
        
        if i % 50 == 0:
            print(f"Processed {i+1}/{len(threads)} threads...")
    
    print("\n" + "="*60)
    print(f"Top 20 sender domains (last {days} days):")
    print("="*60)
    
    for domain, count in sender_counter.most_common(20):
        examples = sender_details.get(domain, [])
        sample_senders = set(s[0] for s in examples[:3])
        print(f"\n{domain}: {count} emails")
        print(f"  Sample senders: {', '.join(list(sample_senders)[:2])}")
        if examples:
            print(f"  Sample subject: {examples[0][1]}")
    
    # Also analyze by full sender address
    print("\n" + "="*60)
    print("Analysis for bulk-sender archiving:")
    print("="*60)
    
    # Identify potential bulk senders (more than 5 emails from same domain)
    bulk_domains = [(d, c) for d, c in sender_counter.items() if c >= 5]
    print(f"\nDomains with 5+ emails: {len(bulk_domains)}")
    
    for domain, count in sorted(bulk_domains, key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {domain}: {count} emails")
    
    # Check overlap with promotional category
    print("\n" + "="*60)
    print("Checking promotional emails overlap...")
    print("="*60)
    
    # Fetch promotional threads
    cmd = ["gmail", "search", "in:inbox category:promotions", "--max", "100", "--json"]
    success, output = run_gog(cmd)
    promo_threads = []
    if success:
        try:
            data = json.loads(output)
            promo_threads = data.get('threads', [])
        except json.JSONDecodeError:
            pass
    
    promo_domains = set()
    for thread in promo_threads[:50]:  # Sample 50
        if not isinstance(thread, dict) or 'id' not in thread:
            continue
        thread_id = thread['id']
        cmd = ["gmail", "thread", "get", thread_id, "--json"]
        success, thread_output = run_gog(cmd)
        if not success:
            continue
        try:
            thread_data = json.loads(thread_output)
            if thread_data.get('messages'):
                first_msg = thread_data['messages'][0]
                sender = first_msg.get('headers', {}).get('From', '')
                promo_domains.add(extract_domain(sender))
        except (json.JSONDecodeError, KeyError):
            continue
    
    print(f"\nPromotional category covers {len(promo_domains)} unique domains")
    
    # Check which bulk domains are already covered by promotional filter
    bulk_domain_list = [d for d, _ in bulk_domains]
    already_covered = [d for d in bulk_domain_list if d in promo_domains]
    not_covered = [d for d in bulk_domain_list if d not in promo_domains]
    
    print(f"\nBulk domains already covered by promotional filter: {len(already_covered)}")
    if already_covered:
        print("  " + ", ".join(already_covered[:10]))
    
    print(f"\nBulk domains NOT covered by promotional filter: {len(not_covered)}")
    if not_covered:
        print("  " + ", ".join(not_covered[:10]))
    
    return sender_counter, sender_details

if __name__ == "__main__":
    analyze_senders(30)