#!/usr/bin/env python3
"""
Check Emergent emails for attachments.
"""
import subprocess
import json
import sys
import re

def run_cmd(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    return result.stdout, result.stderr, result.returncode

def has_attachments(thread_id):
    """Check if thread has any attachments."""
    gog = "/home/agent/.linuxbrew/bin/gog"
    account = "bayanimills@gmail.com"
    
    stdout, stderr, rc = run_cmd([gog, "gmail", "thread", thread_id, "--json", "--account", account])
    if rc != 0:
        print(f"Error fetching thread {thread_id}: {stderr}")
        return False
    
    try:
        data = json.loads(stdout)
        messages = data.get("thread", {}).get("messages", [])
        if not messages:
            return False
        
        message = messages[0]
        
        def check_parts(parts):
            for part in parts:
                body = part.get("body", {})
                filename = part.get("filename")
                attachment_id = body.get("attachmentId")
                if filename and attachment_id:
                    return True
                if "parts" in part:
                    if check_parts(part["parts"]):
                        return True
            return False
        
        payload = message.get("payload", {})
        parts = payload.get("parts", [])
        return check_parts(parts)
    except Exception as e:
        print(f"Error parsing thread {thread_id}: {e}")
        return False

def main():
    # Search for Emergent emails
    gog = "/home/agent/.linuxbrew/bin/gog"
    account = "bayanimills@gmail.com"
    
    # Search queries
    queries = [
        "from:emergentagent.com",
        "Emergent",
        '"EMERGENT LABS INC"'
    ]
    
    all_threads = []
    seen_ids = set()
    
    for query in queries:
        print(f"Searching: {query}")
        stdout, stderr, rc = run_cmd([gog, "gmail", "search", query, "--max", "30", "--json", "--account", account])
        if rc != 0:
            print(f"Search failed: {stderr}")
            continue
        
        try:
            data = json.loads(stdout)
            threads = data.get("threads", [])
            for thread in threads:
                thread_id = thread.get("id")
                if thread_id not in seen_ids:
                    seen_ids.add(thread_id)
                    all_threads.append(thread)
        except json.JSONDecodeError as e:
            print(f"Parse error: {e}")
            continue
    
    print(f"\nFound {len(all_threads)} unique Emergent threads")
    
    # Check each thread for attachments
    threads_with_attachments = []
    
    for i, thread in enumerate(all_threads):
        thread_id = thread.get("id")
        subject = thread.get("subject", "")[:60]
        labels = thread.get("labels", [])
        
        print(f"\nChecking {i+1}/{len(all_threads)}: {subject}")
        print(f"  Labels: {', '.join(labels)}")
        
        has_att = has_attachments(thread_id)
        if has_att:
            print(f"  ✓ Has attachments")
            threads_with_attachments.append(thread)
        else:
            print(f"  ✗ No attachments")
        
        # Limit to checking first 10 for speed
        if i >= 9:
            print(f"\nChecked first 10 threads, stopping...")
            break
    
    print(f"\nSummary:")
    print(f"Total Emergent threads: {len(all_threads)}")
    print(f"Threads with attachments: {len(threads_with_attachments)}")
    
    # If any have attachments, show them
    if threads_with_attachments:
        print(f"\nThreads with attachments:")
        for thread in threads_with_attachments:
            print(f"  - {thread.get('subject', '')[:60]}")

if __name__ == "__main__":
    main()