#!/usr/bin/env python3
"""
Quick check for attachments in emails from specific domains.
"""
import subprocess
import json
import sys

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

DOMAINS = [
    "e.kogan.com",
    "cluborange.org", 
    "email.livenation.com.au",
    "edm2.umart.com.au",
    "buckettys.com.au",
    "coinspot.com.au",
    "au.enews.bp.email",
    "thinlizzy.com.au",
    "emergentagent.com"
]

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            return False, result.stderr
    except subprocess.TimeoutExpired:
        return False, "timeout"

def check_domain(domain):
    print(f"\n=== {domain} ===")
    
    # Search for emails
    query = f"from:{domain} newer_than:90d"
    cmd = ["gmail", "search", query, "--max", "5", "--json"]
    ok, out = run_gog(cmd)
    if not ok:
        print("  Search failed")
        return
    
    try:
        data = json.loads(out)
        threads = data.get('threads', [])
        if not threads:
            print("  No emails found")
            return
    except:
        print("  Parse error")
        return
    
    print(f"  Found {len(threads)} threads")
    
    # Check first 2 threads for attachments
    for i, thread in enumerate(threads[:2]):
        thread_id = thread.get('id')
        subject = thread.get('subject', '')[:50]
        labels = thread.get('labels', [])
        
        print(f"\n  Thread {i+1}: {subject}...")
        print(f"    Labels: {', '.join(labels[:3])}")
        
        # Get thread details
        cmd = ["gmail", "thread", "get", thread_id, "--json"]
        ok, out = run_gog(cmd)
        if not ok:
            print("    Failed to get details")
            continue
        
        try:
            details = json.loads(out)
            messages = details.get('messages', [])
            total_attachments = 0
            pdf_count = 0
            
            for msg in messages:
                attachments = msg.get('attachments', [])
                total_attachments += len(attachments)
                for att in attachments:
                    filename = att.get('filename', '').lower()
                    if filename.endswith('.pdf'):
                        pdf_count += 1
            
            print(f"    Attachments: {total_attachments} total, {pdf_count} PDFs")
            if pdf_count > 0:
                print("    ⚠️  PDFs found in promotional email")
                
        except:
            print("    Parse error in details")

def main():
    print("Quick attachment check for top domains")
    print("="*50)
    
    for domain in DOMAINS:
        check_domain(domain)
    
    print("\n" + "="*50)
    print("Summary:")
    print("- If no PDFs found, promotional classification is likely safe")
    print("- If PDFs found, consider manual review of those threads")
    print("- EmergentAgent.com specifically checked as requested")

if __name__ == "__main__":
    main()