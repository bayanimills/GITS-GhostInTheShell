#!/usr/bin/env python3
"""Clean up duplicate API/competitor pricing tasks created by night‑executive."""

import os
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import get, delete

def fetch_all_tasks():
    """Fetch all tasks (paginated)."""
    all_tasks = []
    url = '/tasks/list'
    while url:
        result = get(url)
        tasks = result.get('results', [])
        all_tasks.extend(tasks)
        url = result.get('next')  # next page URL
    return all_tasks

def find_duplicate_task_groups(tasks):
    """Group tasks by normalized title."""
    groups = {}
    for task in tasks:
        title = task.get('title', '').strip()
        if not title:
            continue
        # Normalize: lowercase, remove extra spaces
        norm = ' '.join(title.lower().split())
        groups.setdefault(norm, []).append(task)
    # Filter groups with >1 task
    return {k: v for k, v in groups.items() if len(v) > 1}

def select_keep_task(tasks):
    """Select which task to keep from a duplicate group.
    Prefer 'Done' tasks, then earliest due date, then earliest created (by id).
    """
    # First, check for any 'Done' tasks
    done_tasks = [t for t in tasks if t.get('status') == 'Done']
    if done_tasks:
        # Keep the earliest due among done tasks, or first if no due
        keep = min(done_tasks, key=lambda t: t.get('dueAt') or '9999-99-99')
        return keep
    
    # All are 'To-do' or similar; keep earliest due date
    # If no due date, keep the first in list (arbitrary)
    return min(tasks, key=lambda t: t.get('dueAt') or '9999-99-99')

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Clean up duplicate tasks.')
    parser.add_argument('--yes', '-y', action='store_true', help='Skip confirmation prompt')
    parser.add_argument('--dry-run', action='store_true', help='Only show what would be deleted')
    args = parser.parse_args()
    
    print("Fetching all tasks...")
    all_tasks = fetch_all_tasks()
    print(f"Total tasks: {len(all_tasks)}")
    
    groups = find_duplicate_task_groups(all_tasks)
    print(f"Found {len(groups)} duplicate groups:")
    for title, tasks in groups.items():
        print(f"  '{title}' → {len(tasks)} duplicates")
    
    if not groups:
        print("No duplicates found.")
        return
    
    to_delete = []
    keep_map = {}
    for title, tasks in groups.items():
        keep = select_keep_task(tasks)
        keep_map[title] = keep['id']
        for task in tasks:
            if task['id'] != keep['id']:
                to_delete.append(task)
    
    print(f"\nWill keep {len(keep_map)} tasks (one per group):")
    for title, task_id in keep_map.items():
        task = next(t for t in groups[title] if t['id'] == task_id)
        print(f"  {task_id}: {title[:80]} | due {task.get('dueAt', 'none')} | status {task.get('status', 'unknown')}")
    
    print(f"\nWill delete {len(to_delete)} duplicates:")
    for task in to_delete:
        print(f"  {task['id']}: {task.get('title', '')[:80]} | due {task.get('dueAt', 'none')}")
    
    if args.dry_run:
        print("\nDry run - no deletions performed.")
        return
    
    if not args.yes:
        if input("\nProceed? (y/N): ").strip().lower() != 'y':
            print("Aborted.")
            return
    
    deleted = []
    failed = []
    for task in to_delete:
        try:
            delete(f"/tasks/{task['id']}")
            deleted.append(task['id'])
            print(f"  ✓ Deleted {task['id']}")
        except Exception as e:
            failed.append((task['id'], str(e)))
            print(f"  ✗ Failed to delete {task['id']}: {e}")
    
    print(f"\nCleanup complete: {len(deleted)} deleted, {len(failed)} failed.")
    if failed:
        print("Failed IDs:", [f[0] for f in failed])

if __name__ == '__main__':
    main()