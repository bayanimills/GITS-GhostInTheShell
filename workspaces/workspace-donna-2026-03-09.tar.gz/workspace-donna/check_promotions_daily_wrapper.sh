#!/bin/bash

# Wrapper for daily promotional email check that sends Telegram notification
# Runs check_promotions_daily.py once, captures output, sends Telegram

cd /home/agent/.openclaw/workspace-donna

LOG_FILE="/home/agent/.openclaw/workspace-donna/promotions-check.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S AEDT')

echo "[$TIMESTAMP] Starting promotions check wrapper..." >> "$LOG_FILE"

# Run script with timeout (5 minutes) and capture output
OUTPUT=$(timeout 300 python3 check_promotions_daily.py --max 200 --dry-run 2>&1)
EXIT_CODE=$?

if [ $EXIT_CODE -eq 124 ]; then
    SUMMARY="Promotions check timed out after 5 minutes."
    echo "[$TIMESTAMP] Script timed out." >> "$LOG_FILE"
elif [ $EXIT_CODE -ne 0 ]; then
    SUMMARY="Promotions check failed with exit code $EXIT_CODE."
    echo "[$TIMESTAMP] Script failed with exit code $EXIT_CODE." >> "$LOG_FILE"
else
    # Extract summary lines
    SUMMARY=$(echo "$OUTPUT" | grep -E "PROMOTIONAL INBOX REPORT|Total:|Immediate archive|Delayed domains|Candidates for archiving|Top domains:" | head -15)
    echo "[$TIMESTAMP] Script succeeded." >> "$LOG_FILE"
fi

# Format Telegram message
MESSAGE="📧 *Daily Promotions Check* ($TIMESTAMP)

\`\`\`
$SUMMARY
\`\`\`"

# Send Telegram notification
echo "[$TIMESTAMP] Sending Telegram notification..." >> "$LOG_FILE"
openclaw message send \
    --channel telegram \
    --target "548072941" \
    --message "$MESSAGE" \
    >> "$LOG_FILE" 2>&1

TELEGRAM_EXIT=$?
echo "[$TIMESTAMP] Telegram send exit code: $TELEGRAM_EXIT" >> "$LOG_FILE"

exit $EXIT_CODE