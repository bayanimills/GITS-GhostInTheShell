#!/usr/bin/env python3
import subprocess, json, base64, re

def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout, result.stderr, result.returncode

def extract_pdf_links_from_parts(parts):
    """Recursively search parts for PDF links."""
    links = set()
    for part in parts:
        mime = part.get("mimeType", "")
        # If text/plain or text/html, decode body
        if mime in ["text/plain", "text/html"]:
            body_data = part.get("body", {}).get("data")
            if body_data:
                try:
                    body = base64.b64decode(body_data).decode('utf-8', errors='ignore')
                    # Search for Stripe PDF links
                    invoice_pattern = r'https://pay\.stripe\.com/invoice/[^\s"\')<>]+?pdf'
                    receipt_pattern = r'https://dashboard\.stripe\.com/receipts/invoices/[^\s"\')<>]+?pdf'
                    found = re.findall(invoice_pattern, body, re.IGNORECASE)
                    links.update(found)
                    found = re.findall(receipt_pattern, body, re.IGNORECASE)
                    links.update(found)
                except:
                    pass
        # Recurse into subparts
        if "parts" in part:
            sublinks = extract_pdf_links_from_parts(part["parts"])
            links.update(sublinks)
    return links

thread_id = "19cbbf542d31ead5"
stdout, stderr, rc = run(["/home/agent/.linuxbrew/bin/gog", "gmail", "thread", thread_id, "--json", "--account", "bayanimills@gmail.com"])
if rc != 0:
    print(stderr)
    exit(1)
data = json.loads(stdout)
messages = data.get("thread", {}).get("messages", [])
for msg in messages:
    payload = msg.get("payload", {})
    parts = payload.get("parts", [])
    links = extract_pdf_links_from_parts(parts)
    print(f"Found {len(links)} links:")
    for link in links:
        print(f"  {link}")