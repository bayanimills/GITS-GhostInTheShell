#!/usr/bin/env python3
"""
Skill recommender integration for agent workflow.
Provides formatted recommendations and logs usage.
"""
import subprocess
import sys
import os
import json
from typing import List, Dict

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

try:
    from skill_recommender import SkillRecommender
    RECOMMENDER_AVAILABLE = True
except ImportError:
    RECOMMENDER_AVAILABLE = False
    print("Warning: Could not import SkillRecommender, falling back to subprocess", file=sys.stderr)

METADATA_PATH = os.path.join(SCRIPT_DIR, "skills_metadata.json")

def log_recommender_usage(task: str, recommendations_count: int):
    """Log that recommender was used."""
    try:
        # Use existing log_skill_usage.py if available
        log_script = os.path.join(SCRIPT_DIR, "log_skill_usage.py")
        if os.path.exists(log_script):
            cmd = [sys.executable, log_script, "skill_recommender", "--success", "true"]
            env = os.environ.copy()
            env["EXECUTION_TIME_MS"] = "100"  # Approximate
            subprocess.run(cmd, env=env, capture_output=True)
    except:
        pass  # Non-critical

def get_recommendations(task: str, limit: int = 5, category: str = None) -> List[Dict]:
    """Get skill recommendations for a task."""
    # Use direct import if available
    if RECOMMENDER_AVAILABLE:
        try:
            recommender = SkillRecommender()
            if category:
                recommendations = recommender.recommend_by_category(category, limit=limit)
            else:
                recommendations = recommender.recommend_by_context(task, limit=limit)
            
            # Convert to expected format
            result = []
            for rec in recommendations:
                result.append({
                    'skill': rec['skill'],
                    'category': rec.get('category', ''),
                    'score': rec.get('score', 0),
                    'description': rec.get('description', ''),
                    'success_rate': rec.get('success_rate', 'unknown'),
                    'test_status': rec.get('test_status', 'unknown')
                })
            return result
        except Exception as e:
            print(f"Error using SkillRecommender: {e}", file=sys.stderr)
            # Fall back to subprocess
    
    # Fallback: subprocess call
    cmd = [sys.executable, "skill_recommender.py", task, "--limit", str(limit)]
    if category:
        cmd.extend(["--category", category])
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, cwd=SCRIPT_DIR)
        if result.returncode != 0:
            print(f"Error running recommender: {result.stderr}", file=sys.stderr)
            return []
        
        # Parse the formatted output
        lines = result.stdout.strip().split('\n')
        if not lines or 'Recommendations for:' not in lines[0]:
            return []
        
        recommendations = []
        current_rec = {}
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('Recommendations for:'):
                continue
            
            # Check for recommendation line: "1. skill (category)"
            if line[0].isdigit() and '. ' in line:
                # Save previous recommendation
                if current_rec:
                    recommendations.append(current_rec)
                
                parts = line.split('. ', 1)
                if len(parts) < 2:
                    continue
                
                skill_part = parts[1]
                # Extract skill name and category: "skill (category)"
                import re
                match = re.match(r'(.+?) \((.+?)\)', skill_part)
                if match:
                    skill_name, skill_category = match.groups()
                    current_rec = {
                        'skill': skill_name.strip(),
                        'category': skill_category.strip(),
                        'score': 0,
                        'description': ''
                    }
                else:
                    # Fallback: just skill name
                    current_rec = {
                        'skill': skill_part.strip(),
                        'category': '',
                        'score': 0,
                        'description': ''
                    }
            
            elif line.startswith('   Score:'):
                score_part = line.split('Score:', 1)[1].strip()
                try:
                    current_rec['score'] = int(score_part.split()[0])
                except:
                    pass
            
            elif line.startswith('   Description:'):
                desc = line.split('Description:', 1)[1].strip()
                current_rec['description'] = desc
        
        # Add last recommendation
        if current_rec:
            recommendations.append(current_rec)
        
        return recommendations
        
    except subprocess.TimeoutExpired:
        print("Recommender timeout", file=sys.stderr)
        return []
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return []

def format_recommendations(task: str, recommendations: List[Dict]) -> str:
    """Format recommendations for display."""
    if not recommendations:
        return f"No skill recommendations found for: {task}"
    
    lines = []
    lines.append(f"📚 **Skill Recommendations for**: {task}")
    lines.append("")
    
    for i, rec in enumerate(recommendations, 1):
        lines.append(f"{i}. **{rec['skill']}** ({rec['category']})")
        lines.append(f"   Score: {rec['score']}")
        if rec['description']:
            desc = rec['description']
            if len(desc) > 120:
                desc = desc[:117] + "..."
            lines.append(f"   {desc}")
        lines.append("")
    
    lines.append("Use: `skill_recommender.py --task \"your task\"` for more options.")
    return '\n'.join(lines)

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Get skill recommendations for a task')
    parser.add_argument('task', help='Task description')
    parser.add_argument('--limit', type=int, default=3, help='Number of recommendations')
    parser.add_argument('--category', help='Filter by category')
    parser.add_argument('--quiet', action='store_true', help='Minimal output')
    parser.add_argument('--json', action='store_true', help='Output JSON format')
    args = parser.parse_args()
    
    # Get recommendations
    recs = get_recommendations(args.task, args.limit, args.category)
    
    # Log usage
    log_recommender_usage(args.task, len(recs))
    
    # Output
    if args.json:
        print(json.dumps(recs, indent=2))
    elif args.quiet:
        # Just skill names
        print(', '.join([r['skill'] for r in recs]))
    else:
        print(format_recommendations(args.task, recs))

if __name__ == '__main__':
    main()