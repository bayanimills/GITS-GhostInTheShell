#!/usr/bin/env python3
import json
import sys

path = '/home/agent/.openclaw/cron/jobs.json'
with open(path, 'r') as f:
    data = json.load(f)

modified = False
for job in data.get('jobs', []):
    if job.get('id') == 'd35d18dd-a50e-45f8-b614-b65bbf9e5586':
        # Disable job
        if job.get('enabled', False):
            job['enabled'] = False
            modified = True
            print(f"Disabled job: {job.get('name')}")
        
        # Update delivery mode to none
        if job.get('delivery', {}).get('mode') == 'announce':
            job['delivery']['mode'] = 'none'
            modified = True
            print(f"Updated delivery mode to none")
        break

if modified:
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)
    print("Saved changes")
else:
    print("No changes needed")
    sys.exit(0)