#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from weekly_receipt_collector import generate_better_filename

test_cases = [
    {
        'original': 'Invoice-WH4AQ3XP-0002.pdf',
        'subject': 'Your receipt from Anthropic, PBC #2154-0922-9602',
        'sender': 'Anthropic <no-reply@anthropic.com>',
        'date': '1741345200000',
        'label': 'Finance/Invoices/Personal',
        'expected': '2025-03-07_Anthropic_WH4AQ3XP-0002_Invoice.pdf'  # invoice number from filename
    },
    {
        'original': 'receipt.pdf',
        'subject': 'Uber Receipt #UBER12345',
        'sender': 'Uber <uber@uber.com>',
        'date': '1741345200000',
        'label': 'Finance/Receipts/Personal',
        'expected': '2025-03-07_Uber_UBER12345_Receipt.pdf'
    },
    {
        'original': 'invoice.pdf',
        'subject': 'Invoice from Vendor',
        'sender': 'vendor@example.com',
        'date': '1741345200000',
        'label': 'Finance/Invoices/Business',
        'expected': '2025-03-07_Example_Invoice.pdf'  # no invoice number
    },
    {
        'original': 'statement.pdf',
        'subject': 'Bank Statement',
        'sender': 'Bank <statements@bank.com>',
        'date': '1741345200000',
        'label': 'Finance/Statements/Personal',
        'expected': '2025-03-07_Bank_Statement.pdf'
    },
]

for i, tc in enumerate(test_cases):
    result = generate_better_filename(tc['original'], tc['subject'], tc['sender'], tc['date'], tc['label'])
    print(f'Test {i}:')
    print(f'  Original: {tc["original"]}')
    print(f'  Subject: {tc["subject"]}')
    print(f'  Sender: {tc["sender"]}')
    print(f'  Label: {tc["label"]}')
    print(f'  Expected: {tc["expected"]}')
    print(f'  Got: {result}')
    print(f'  Pass: {result == tc["expected"]}')
    print()