#!/bin/bash
# Archive promotional emails hourly to maintain inbox zero
ACCOUNT="bayanimills@gmail.com"
MAX_FETCH=200
BATCH=20

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log "Starting promotional email archive..."

# Fetch promotional threads
ids=$(timeout 60 gog gmail search "category:promotions" --max "$MAX_FETCH" --json --account "$ACCOUNT" | jq -r '.threads[].id' | tr '\n' ' ')
if [ -z "$ids" ]; then
    log "No promotional threads found."
    exit 0
fi

count=$(echo "$ids" | wc -w)
log "Found $count promotional threads. Archiving..."

# Archive in batches
echo "$ids" | tr ' ' '\n' | xargs -n "$BATCH" timeout 60 gog gmail labels modify --remove INBOX --account "$ACCOUNT"
if [ $? -eq 0 ]; then
    log "Successfully archived $count threads."
else
    log "Error archiving some threads."
fi

# Final check
remaining=$(timeout 30 gog gmail search "in:inbox category:promotions" --max 5 --json --account "$ACCOUNT" | jq -r '.threads | length')
log "Remaining promotional threads in inbox: $remaining."