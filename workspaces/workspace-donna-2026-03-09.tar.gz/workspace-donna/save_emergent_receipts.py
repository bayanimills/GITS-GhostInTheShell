#!/usr/bin/env python3
"""
Save Emergent receipts to Nextcloud as HTML/text files.
"""
import os
import sys
import json
import subprocess
import tempfile
import re
import base64
from datetime import datetime
from pathlib import Path

# Configuration
WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/emergent_receipts_state.json")
LOG_FILE = os.path.join(WORKSPACE, "memory/emergent_receipts.log")
ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

# Nextcloud configuration
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"

# Target folder in Nextcloud
NEXTCLOUD_FOLDER = "/_private/businesses/Bayani%20Enterprises/Receipts/"

def run_cmd(cmd, timeout=60):
    """Run shell command and return stdout, stderr, returncode."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124
    except Exception as e:
        return "", str(e), 1

def log_message(message, level="INFO"):
    """Log message to log file and print to stdout."""
    timestamp = datetime.now().isoformat()
    log_entry = f"{timestamp} [{level}] {message}"
    print(f"[{level}] {message}")
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(log_entry + "\n")

def search_emergent_emails(max_results=200):
    """Search for Emergent-related emails."""
    # Search for emails with Finance/Bayani Enterprises label OR from emergentagent.com
    queries = [
        "label:Finance/Bayani Enterprises",
        "from:emergentagent.com",
        '"EMERGENT LABS INC"'
    ]
    
    all_threads = []
    seen_ids = set()
    
    for query in queries:
        log_message(f"Searching: {query}")
        cmd = [GOG, "gmail", "search", query, "--max", str(max_results), "--json", "--account", ACCOUNT]
        stdout, stderr, rc = run_cmd(cmd, timeout=120)
        
        if rc != 0:
            log_message(f"Search failed for '{query}': {stderr}", "WARNING")
            continue
        
        try:
            data = json.loads(stdout)
            threads = data.get("threads", [])
            for thread in threads:
                thread_id = thread.get("id")
                if thread_id not in seen_ids:
                    seen_ids.add(thread_id)
                    all_threads.append(thread)
        except json.JSONDecodeError as e:
            log_message(f"Failed to parse results for '{query}': {e}", "WARNING")
    
    log_message(f"Found {len(all_threads)} unique Emergent-related threads")
    return all_threads

def get_thread_details(thread_id):
    """Get full thread details."""
    cmd = [GOG, "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to get thread {thread_id}: {stderr}", "ERROR")
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse thread details for {thread_id}: {e}", "ERROR")
        return None

def extract_email_body(message, prefer_html=True):
    """Extract HTML or plain text body from message."""
    def extract_from_parts(parts, target_mime):
        for part in parts:
            if part.get("mimeType") == target_mime:
                body = part.get("body", {})
                data = body.get("data")
                if data:
                    try:
                        return base64.b64decode(data).decode('utf-8', errors='ignore')
                    except:
                        return None
            if "parts" in part:
                content = extract_from_parts(part["parts"], target_mime)
                if content:
                    return content
        return None
    
    payload = message.get("payload", {})
    parts = payload.get("parts", [])
    
    if prefer_html:
        html = extract_from_parts(parts, "text/html")
        if html:
            return html, "html"
    
    # Fall back to plain text
    text = extract_from_parts(parts, "text/plain")
    if text:
        return text, "txt"
    
    # No body found
    return None, None

def create_filename(thread, extension="html"):
    """Create filename for receipt."""
    subject = thread.get("subject", "")
    from_field = thread.get("from", "")
    date_str = thread.get("date", "")
    
    # Clean subject for filename
    clean_subject = re.sub(r'[^\w\s-]', '', subject)
    clean_subject = re.sub(r'\s+', '_', clean_subject)
    clean_subject = clean_subject[:50]
    
    # Extract date
    clean_date = ""
    if date_str:
        # Try to parse date string like "2026-02-21 17:54"
        match = re.search(r'(\d{4}-\d{2}-\d{2})', date_str)
        if match:
            clean_date = match.group(1)
    
    if clean_date:
        filename = f"{clean_date}_{clean_subject}.{extension}"
    else:
        filename = f"{clean_subject}.{extension}"
    
    # Ensure unique
    return filename

def ensure_nextcloud_folder(folder_path):
    """Create Nextcloud folder if it doesn't exist."""
    url = f"{NEXTCLOUD_BASE_URL}{folder_path}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        log_message(f"Created folder: {folder_path}")
        return True
    elif "405" in stderr:  # Already exists
        log_message(f"Folder already exists: {folder_path}")
        return True
    else:
        log_message(f"Failed to create folder {folder_path}: {stderr}", "WARNING")
        return False

def upload_to_nextcloud(filepath, filename):
    """Upload file to Nextcloud."""
    import urllib.parse
    encoded_filename = urllib.parse.quote(filename)
    dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{encoded_filename}"
    
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-T", filepath,
        dest_url
    ]
    
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to upload {filename}: {stderr}", "ERROR")
        return False
    
    log_message(f"Uploaded {filename} to {NEXTCLOUD_FOLDER}")
    return True

def add_label(thread_id, label):
    """Add label to thread."""
    cmd = [GOG, "gmail", "labels", "modify", "--add", label, thread_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to add label {label}: {stderr}", "WARNING")
        return False
    log_message(f"Added label '{label}' to thread {thread_id}")
    return True

def process_thread(thread, dry_run=True):
    """Process a single thread - save email body to Nextcloud."""
    thread_id = thread.get("id")
    subject = thread.get("subject", "")
    from_field = thread.get("from", "")
    labels = thread.get("labels", [])
    
    log_message(f"Processing thread: {thread_id} - {subject[:50]}...")
    
    # Skip if already archived
    if "Archived-to-Nextcloud" in labels:
        log_message(f"Thread {thread_id} already archived, skipping")
        return {"status": "already_archived"}
    
    # Get thread details
    thread_details = get_thread_details(thread_id)
    if not thread_details:
        return {"status": "failed"}
    
    messages = thread_details.get("thread", {}).get("messages", [])
    if not messages:
        log_message(f"No messages in thread {thread_id}", "WARNING")
        return {"status": "no_messages"}
    
    message = messages[0]
    
    # Extract email body
    body, extension = extract_email_body(message, prefer_html=True)
    if not body:
        log_message(f"No body content found in thread {thread_id}", "WARNING")
        return {"status": "no_content"}
    
    log_message(f"Extracted {extension.upper()} body ({len(body)} chars)")
    
    # Create filename
    filename = create_filename(thread, extension)
    log_message(f"Filename: {filename}")
    
    if dry_run:
        log_message(f"DRY RUN: Would save as {filename}")
        # Preview first 200 chars
        preview = body[:200].replace('\n', ' ')
        log_message(f"Preview: {preview}...")
        return {"status": "dry_run", "filename": filename, "size": len(body)}
    
    # Save to temp file
    temp_dir = tempfile.gettempdir()
    temp_file = os.path.join(temp_dir, filename)
    
    try:
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(body)
        log_message(f"Saved to temp file: {temp_file}")
    except Exception as e:
        log_message(f"Failed to save temp file: {e}", "ERROR")
        return {"status": "save_error"}
    
    # Ensure Nextcloud folder exists
    if not ensure_nextcloud_folder(NEXTCLOUD_FOLDER):
        log_message(f"Failed to ensure Nextcloud folder", "ERROR")
        return {"status": "folder_error"}
    
    # Upload to Nextcloud
    if upload_to_nextcloud(temp_file, filename):
        # Add labels
        add_label(thread_id, "Archived-to-Nextcloud")
        add_label(thread_id, "Emergent-Receipts")
        
        # Clean up temp file
        try:
            os.remove(temp_file)
        except OSError:
            pass
        
        return {"status": "success", "filename": filename, "size": len(body)}
    else:
        return {"status": "upload_failed"}

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Save Emergent receipts to Nextcloud")
    parser.add_argument("--dry-run", action="store_true", default=True, help="Dry run (default)")
    parser.add_argument("--process", action="store_true", help="Actually save and upload")
    parser.add_argument("--max", type=int, default=10, help="Max emails to process")
    parser.add_argument("--resume", action="store_true", help="Resume from state file")
    args = parser.parse_args()
    
    dry_run = not args.process
    
    log_message(f"Starting Emergent receipts processing (dry_run={dry_run})")
    
    # Search for Emergent emails
    threads = search_emergent_emails(max_results=args.max)
    
    if not threads:
        log_message("No Emergent threads found")
        return
    
    log_message(f"Found {len(threads)} threads to process")
    
    # Process threads
    results = []
    for i, thread in enumerate(threads):
        log_message(f"Processing {i+1}/{len(threads)}")
        result = process_thread(thread, dry_run=dry_run)
        results.append(result)
        
        # Limit for testing
        if dry_run and i >= 2:  # Show first 3 in dry run
            log_message(f"Dry run: processed {i+1} threads, stopping preview")
            break
    
    # Summary
    if dry_run:
        log_message(f"\nDRY RUN SUMMARY: Would process {len(threads)} threads")
        log_message(f"Previewed {len(results)} threads")
    else:
        successful = sum(1 for r in results if r["status"] == "success")
        failed = sum(1 for r in results if r["status"] in ["failed", "upload_failed"])
        log_message(f"\nPROCESSING COMPLETE:")
        log_message(f"  Successful: {successful}")
        log_message(f"  Failed: {failed}")
        log_message(f"  Total processed: {len(results)}")
    
    log_message("\nDone.")

if __name__ == "__main__":
    main()