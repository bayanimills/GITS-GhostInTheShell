#!/usr/bin/env python3
"""
Analyze promotional email senders from last 90 days.
"""
import subprocess
import json
import sys
from collections import Counter
from email.utils import parseaddr

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def extract_domain(email_address):
    """Extract domain from email address."""
    _, email = parseaddr(email_address)
    if '@' in email:
        return email.lower().split('@')[1]
    return email.lower()

def analyze_promo_senders(days=90, max_threads=500):
    """Fetch promotional emails from last N days."""
    print(f"Fetching promotional emails from last {days} days (max {max_threads})...")
    
    query = f"category:promotions newer_than:{days}d"
    cmd = ["gmail", "search", query, "--max", str(max_threads), "--json"]
    success, output = run_gog(cmd)
    if not success:
        print("Failed to fetch promotional threads.")
        return
    
    try:
        data = json.loads(output)
        threads = data.get('threads', [])
    except json.JSONDecodeError:
        print("Failed to parse JSON response.")
        return
    
    if not threads:
        print("No promotional threads found.")
        return
    
    print(f"Analyzing {len(threads)} promotional threads...")
    
    # Count domains
    domain_counter = Counter()
    sender_examples = {}  # domain -> list of (sender, subject)
    
    for thread in threads:
        sender = thread.get('from', '')
        subject = thread.get('subject', 'No subject')
        
        domain = extract_domain(sender)
        domain_counter[domain] += 1
        
        if domain not in sender_examples:
            sender_examples[domain] = []
        sender_examples[domain].append((sender, subject[:60]))
    
    print("\n" + "="*70)
    print(f"Top 30 promotional sender domains (last {days} days):")
    print("="*70)
    
    for domain, count in domain_counter.most_common(30):
        examples = sender_examples.get(domain, [])
        sample_senders = set(s[0] for s in examples[:3])
        print(f"\n{domain}: {count} emails")
        if sample_senders:
            print(f"  From: {list(sample_senders)[0]}")
        if examples:
            print(f"  Subject: {examples[0][1]}")
    
    # Analyze patterns
    print("\n" + "="*70)
    print("Pattern analysis:")
    print("="*70)
    
    total_emails = sum(domain_counter.values())
    top_10_domains = domain_counter.most_common(10)
    top_10_count = sum(count for _, count in top_10_domains)
    top_10_pct = (top_10_count / total_emails) * 100 if total_emails else 0
    
    print(f"\nTotal promotional emails analyzed: {total_emails}")
    print(f"Top 10 domains account for: {top_10_count} emails ({top_10_pct:.1f}%)")
    
    print("\nTop 10 domains:")
    for domain, count in top_10_domains:
        pct = (count / total_emails) * 100
        print(f"  {domain}: {count} emails ({pct:.1f}%)")
    
    # Identify spam patterns
    print("\n" + "="*70)
    print("Spam pattern recognition:")
    print("="*70)
    
    # Common spam indicators
    spam_keywords = ['unsubscribe', 'newsletter', 'offer', 'deal', 'sale', 'discount', 
                     'promo', 'update', 'alert', 'digest', 'weekly', 'monthly']
    
    domain_patterns = {}
    for domain, examples_list in sender_examples.items():
        if len(examples_list) < 3:
            continue
        subjects = ' '.join([s[1].lower() for s in examples_list[:5]])
        matched_keywords = [kw for kw in spam_keywords if kw in subjects]
        domain_patterns[domain] = matched_keywords
    
    print("\nDomains with common spam keywords in subjects:")
    for domain, keywords in list(domain_patterns.items())[:15]:
        if keywords:
            count = domain_counter[domain]
            print(f"  {domain} ({count} emails): {', '.join(keywords[:3])}")
    
    # Recommendations
    print("\n" + "="*70)
    print("Bulk-sender archiving recommendations:")
    print("="*70)
    
    bulk_domains = [(d, c) for d, c in domain_counter.items() if c >= 5]
    print(f"\nFound {len(bulk_domains)} domains with 5+ promotional emails")
    
    if bulk_domains:
        print("\nPriority targets for bulk-sender archiving:")
        for domain, count in sorted(bulk_domains, key=lambda x: x[1], reverse=True)[:15]:
            print(f"  {domain}: {count} emails")
        
        print("\nImplementation notes:")
        print("1. Current promotional archiving catches ALL promotional emails hourly")
        print("2. Bulk-sender archiving would add time-based filtering (archive after X days)")
        print("3. Could reduce inbox clutter for promotional emails you might want to briefly see")
        print("4. Consider archive delay of 3-7 days for unread promotional emails")
    else:
        print("\nFew domains send 5+ promotional emails.")
        print("Bulk-sender archiving may not provide significant additional value.")
    
    return domain_counter, sender_examples

if __name__ == "__main__":
    analyze_promo_senders(90, 500)