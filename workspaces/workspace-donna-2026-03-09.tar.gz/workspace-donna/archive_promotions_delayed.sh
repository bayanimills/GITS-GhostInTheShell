#!/bin/bash
# Archive promotional emails with 3-day delay for top domains
cd /home/agent/.openclaw/workspace-donna
python3 archive_promotions_with_delay.py 2>&1