#!/usr/bin/env python3
"""
Classifier rule updater - adjusts pattern priorities based on corrections.
Reads classifier_corrections.json and enhanced_label_rules.json.
Implements simple reinforcement learning: increase priority for patterns matching chosen label,
decrease for patterns matching rejected label.
"""
import json
import re
import sys
from pathlib import Path

# Paths
CORRECTIONS_FILE = Path("/home/agent/.openclaw/workspace-donna/classifier_corrections.json")
RULES_FILE = Path("/home/agent/.openclaw/workspace-donna/enhanced_label_rules.json")
BACKUP_SUFFIX = ".backup"

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def save_json(data, path):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def find_matching_patterns(text, patterns):
    """Return list of pattern indices that match text (case-insensitive)."""
    matches = []
    for i, pattern in enumerate(patterns):
        regex = pattern.get('regex', '')
        try:
            if re.search(regex, text, re.IGNORECASE):
                matches.append(i)
        except re.error:
            continue
    return matches

def adjust_priority(priority, delta, min_val=1, max_val=5):
    """Adjust priority within bounds."""
    new = priority + delta
    if new < min_val:
        return min_val
    if new > max_val:
        return max_val
    return new

def main():
    if not CORRECTIONS_FILE.exists():
        print("No corrections file found. Exiting.")
        return
    if not RULES_FILE.exists():
        print("Rules file not found. Exiting.")
        return
    
    corrections = load_json(CORRECTIONS_FILE)
    rules = load_json(RULES_FILE)
    
    if 'patterns' not in rules:
        print("Rules file missing 'patterns' key.")
        return
    
    patterns = rules['patterns']
    changes = []
    
    for corr in corrections:
        if not corr.get('applied', False):
            continue
        chosen = corr.get('chosen_label')
        # Determine rejected label (the one not chosen)
        label1 = corr.get('original_label1')
        label2 = corr.get('original_label2')
        rejected = label2 if chosen == label1 else label1
        
        subject = corr.get('subject', '')
        sender = corr.get('sender', '')
        text = f"{subject} {sender}"
        
        # Find patterns matching chosen label
        for i, pat in enumerate(patterns):
            if pat.get('label') == chosen:
                # Check if pattern regex matches the text
                if re.search(pat['regex'], text, re.IGNORECASE):
                    old_prio = pat.get('priority', 1)
                    new_prio = adjust_priority(old_prio, +1)
                    if new_prio != old_prio:
                        patterns[i]['priority'] = new_prio
                        changes.append(f"↑ Pattern {i} ({pat['regex'][:30]}...) priority {old_prio}→{new_prio} (chosen label: {chosen})")
        
        # Find patterns matching rejected label
        for i, pat in enumerate(patterns):
            if pat.get('label') == rejected:
                if re.search(pat['regex'], text, re.IGNORECASE):
                    old_prio = pat.get('priority', 1)
                    new_prio = adjust_priority(old_prio, -1)
                    if new_prio != old_prio:
                        patterns[i]['priority'] = new_prio
                        changes.append(f"↓ Pattern {i} ({pat['regex'][:30]}...) priority {old_prio}→{new_prio} (rejected label: {rejected})")
    
    if changes:
        # Backup original file
        backup_path = RULES_FILE.with_suffix(BACKUP_SUFFIX)
        save_json(rules, backup_path)
        # Update rules
        rules['patterns'] = patterns
        save_json(rules, RULES_FILE)
        print(f"Updated {len(changes)} pattern priorities. Backup saved to {backup_path}")
        for c in changes:
            print(f"  {c}")
    else:
        print("No pattern adjustments needed.")

if __name__ == '__main__':
    main()