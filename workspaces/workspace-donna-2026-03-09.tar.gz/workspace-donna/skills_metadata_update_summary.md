# Skills Metadata Update Summary

**Date**: 2026-02-27 (manual review overnight)
**Updated skills**: 10

## Updated Skills
- ✅ bluebubbles
- ✅ canvas
- ✅ coding-agent
- ✅ discord
- ✅ food-order
- ✅ healthcheck
- ✅ notion
- ✅ skill-creator
- ✅ slack
- ✅ voice-call

## Dependency Changes (based on SKILL.md analysis)

### bluebubbles
- **config**: channels.bluebubbles
- **external**: BlueBubbles server

### canvas
- **bins**: tailscale, jq (optional)
- **config**: canvasHost.enabled
- **external**: OpenClaw nodes with canvas capability

### coding-agent
- **bins**: bash, claude, codex, opencode, pi (any of these)
- **external**: Codex/Claude Code/Pi agent access

### discord
- **config**: channels.discord.token

### food-order
- **bins**: ordercli
- **external**: Foodora account

### healthcheck
- **bins**: openclaw

### notion
- **credentials**: NOTION_API_KEY

### skill-creator
- **bins**: python3

### slack
- **config**: channels.slack

### voice-call
- **bins**: openclaw
- **config**: plugins.entries.voice-call.enabled

## Next Steps
1. Validate dependencies with check_binary_deps.py
2. Install missing critical binaries (ordercli, tailscale, etc.) if needed
3. Test skill functionality where possible

## Notes
- Manual review completed during overnight session (10:55 PM Australia/Sydney)
- Dependencies now accurately reflect SKILL.md requirements
- 26 missing binaries still remain across all skills (deferred)
