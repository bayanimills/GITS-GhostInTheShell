#!/bin/bash
ACCOUNT="bayanimills@gmail.com"
BATCH_SIZE=20
MAX_FETCH=100

echo "Starting inbox archive..."
total=0
while true; do
    echo "Fetching up to $MAX_FETCH threads..."
    ids=$(gog gmail search "in:inbox" --max "$MAX_FETCH" --json --account "$ACCOUNT" | jq -r '.threads[].id' | tr '\n' ' ')
    if [ -z "$ids" ]; then
        echo "No more threads found."
        break
    fi
    count=$(echo "$ids" | wc -w)
    echo "Processing $count threads..."
    # Process in batches of BATCH_SIZE
    echo "$ids" | tr ' ' '\n' | xargs -n "$BATCH_SIZE" gog gmail labels modify --remove INBOX --account "$ACCOUNT"
    if [ $? -ne 0 ]; then
        echo "Error processing batch, stopping."
        exit 1
    fi
    total=$((total + count))
    echo "Archived $count threads (total: $total)."
    sleep 1
done
echo "Done. Total archived: $total threads."