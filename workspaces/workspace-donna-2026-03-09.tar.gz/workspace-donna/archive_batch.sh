#!/bin/bash
ACCOUNT="bayanimills@gmail.com"
for i in {1..20}; do
  echo "Batch $i"
  ids=$(gog gmail search "in:inbox" --max 5 --json --account "$ACCOUNT" | jq -r '.threads[].id' | tr '\n' ' ')
  if [ -z "$ids" ]; then
    echo "No more threads."
    break
  fi
  echo "IDs: $ids"
  gog gmail labels modify $ids --remove INBOX --account "$ACCOUNT"
  sleep 1
done
echo "Done."