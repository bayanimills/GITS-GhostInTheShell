#!/usr/bin/env python3
"""
Search for Emergent-related emails, identify receipts/financial records,
and optionally upload to Nextcloud.
"""
import os
import sys
import json
import subprocess
import tempfile
import re
from datetime import datetime
from pathlib import Path

# Configuration
WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/emergent_receipts_state.json")
LOG_FILE = os.path.join(WORKSPACE, "memory/emergent_receipts.log")
ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

# Nextcloud configuration
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"

# Target folder in Nextcloud
# Using Bayani Enterprises folder - check if exists, otherwise use Finmills
NEXTCLOUD_FOLDER = "/_private/businesses/Bayani%20Enterprises/Receipts/"

# Keywords to identify receipts/financial records
RECEIPT_KEYWORDS = [
    "receipt", "invoice", "payment", "order", "purchase", 
    "transaction", "bill", "statement", "tax", "paid",
    "confirmation", "summary", "subscription", "renewal",
    "fee", "charge", "amount", "total", "$", "USD", "AUD"
]

def run_cmd(cmd, timeout=60):
    """Run shell command and return stdout, stderr, returncode."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124
    except Exception as e:
        return "", str(e), 1

def log_message(message, level="INFO"):
    """Log message to log file and print to stdout."""
    timestamp = datetime.now().isoformat()
    log_entry = f"{timestamp} [{level}] {message}"
    print(f"[{level}] {message}")
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(log_entry + "\n")

def search_emergent_emails(max_results=200):
    """Search for Emergent-related emails."""
    # Search for emails from emergentagent.com or containing "Emergent"
    queries = [
        "from:emergentagent.com",
        "Emergent",
        "subject:Emergent",
        '"Emergent Agent"'
    ]
    
    all_threads = []
    seen_ids = set()
    
    for query in queries:
        log_message(f"Searching for: {query}")
        cmd = [GOG, "gmail", "search", query, "--max", str(max_results), "--json", "--account", ACCOUNT]
        stdout, stderr, rc = run_cmd(cmd, timeout=120)
        
        if rc != 0:
            log_message(f"Search failed for '{query}': {stderr}", "WARNING")
            continue
        
        try:
            data = json.loads(stdout)
            threads = data.get("threads", [])
            for thread in threads:
                thread_id = thread.get("id")
                if thread_id not in seen_ids:
                    seen_ids.add(thread_id)
                    all_threads.append(thread)
        except json.JSONDecodeError as e:
            log_message(f"Failed to parse results for '{query}': {e}", "WARNING")
    
    log_message(f"Found {len(all_threads)} unique Emergent-related threads")
    return all_threads

def get_thread_details(thread_id):
    """Get full thread details including messages."""
    cmd = [GOG, "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to get thread {thread_id}: {stderr}", "ERROR")
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse thread details for {thread_id}: {e}", "ERROR")
        return None

def is_financial_email(thread):
    """Check if email appears to be a receipt/financial record."""
    subject = thread.get("subject", "").lower()
    from_field = thread.get("from", "").lower()
    
    # Check for receipt keywords in subject
    keyword_matches = sum(1 for kw in RECEIPT_KEYWORDS if kw.lower() in subject)
    
    # Check if from financial domains
    financial_domains = ["stripe", "paypal", "square", "xero", "quickbooks", "bank", "wise", "transferwise"]
    domain_matches = any(domain in from_field for domain in financial_domains)
    
    # Check labels
    labels = thread.get("labels", [])
    financial_labels = ["receipt", "invoice", "finance", "statement", "payment"]
    label_matches = any(label.lower() in " ".join(labels).lower() for label in financial_labels)
    
    return keyword_matches > 0 or domain_matches or label_matches

def extract_attachments(message):
    """Extract attachment info from message."""
    attachments = []
    
    def extract_from_parts(parts):
        for part in parts:
            body = part.get("body", {})
            filename = part.get("filename")
            attachment_id = body.get("attachmentId")
            if filename and attachment_id:
                attachments.append({
                    "id": attachment_id,
                    "filename": filename,
                    "size": body.get("size", 0),
                    "mimeType": part.get("mimeType", "")
                })
            if "parts" in part:
                extract_from_parts(part["parts"])
    
    payload = message.get("payload", {})
    extract_from_parts(payload.get("parts", []))
    return attachments

def download_attachment(message_id, attachment_id, filename):
    """Download attachment to temp file."""
    cmd = [GOG, "gmail", "attachment", message_id, attachment_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    if rc != 0:
        log_message(f"Failed to download attachment {attachment_id}: {stderr}", "ERROR")
        return None
    
    temp_dir = tempfile.gettempdir()
    filepath = os.path.join(temp_dir, filename)
    
    try:
        with open(filepath, "wb") as f:
            f.write(stdout.encode('utf-8') if isinstance(stdout, str) else stdout)
        log_message(f"Downloaded {filename} to {filepath}")
        return filepath
    except Exception as e:
        log_message(f"Failed to save attachment {filename}: {e}", "ERROR")
        return None

def ensure_nextcloud_folder(folder_path):
    """Create Nextcloud folder if it doesn't exist."""
    url = f"{NEXTCLOUD_BASE_URL}{folder_path}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        log_message(f"Created folder: {folder_path}")
        return True
    elif "405" in stderr:  # Already exists
        log_message(f"Folder already exists: {folder_path}")
        return True
    else:
        log_message(f"Failed to create folder {folder_path}: {stderr}", "WARNING")
        return False

def upload_to_nextcloud(filepath, filename):
    """Upload file to Nextcloud."""
    import urllib.parse
    encoded_filename = urllib.parse.quote(filename)
    dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{encoded_filename}"
    
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-T", filepath,
        dest_url
    ]
    
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to upload {filename}: {stderr}", "ERROR")
        return False
    
    log_message(f"Uploaded {filename} to {NEXTCLOUD_FOLDER}")
    return True

def add_label(thread_id, label):
    """Add label to thread."""
    cmd = [GOG, "gmail", "labels", "modify", "--add", label, thread_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to add label {label}: {stderr}", "WARNING")
        return False
    log_message(f"Added label '{label}' to thread {thread_id}")
    return True

def process_thread(thread, dry_run=True):
    """Process a single thread for Emergent receipts."""
    thread_id = thread.get("id")
    subject = thread.get("subject", "")
    from_field = thread.get("from", "")
    labels = thread.get("labels", [])
    
    log_message(f"Processing thread: {thread_id} - {subject[:50]}...")
    
    # Skip if already archived
    if "Archived-to-Nextcloud" in labels:
        log_message(f"Thread {thread_id} already archived, skipping")
        return {"status": "already_archived", "attachments": 0}
    
    # Get full thread details
    thread_details = get_thread_details(thread_id)
    if not thread_details:
        return {"status": "failed", "attachments": 0}
    
    # Get first message (usually the only one for receipts)
    messages = thread_details.get("thread", {}).get("messages", [])
    if not messages:
        log_message(f"No messages in thread {thread_id}", "WARNING")
        return {"status": "no_messages", "attachments": 0}
    
    message = messages[0]
    message_id = message.get("id")
    
    # Extract attachments
    attachments = extract_attachments(message)
    if not attachments:
        log_message(f"No attachments in thread {thread_id}")
        return {"status": "no_attachments", "attachments": 0}
    
    log_message(f"Found {len(attachments)} attachments in thread {thread_id}")
    
    # Process attachments in dry-run mode
    if dry_run:
        for att in attachments:
            log_message(f"  Would upload: {att['filename']} ({att['size']} bytes, {att['mimeType']})")
        return {"status": "dry_run", "attachments": len(attachments)}
    
    # Ensure Nextcloud folder exists
    if not ensure_nextcloud_folder(NEXTCLOUD_FOLDER):
        log_message(f"Failed to ensure Nextcloud folder, skipping upload", "ERROR")
        return {"status": "folder_error", "attachments": len(attachments)}
    
    # Process each attachment
    successful_uploads = 0
    for att in attachments:
        filename = att["filename"]
        
        # Download attachment
        temp_file = download_attachment(message_id, att["id"], filename)
        if not temp_file:
            continue
        
        # Upload to Nextcloud
        if upload_to_nextcloud(temp_file, filename):
            successful_uploads += 1
        
        # Clean up temp file
        try:
            os.remove(temp_file)
        except OSError:
            pass
    
    # Add label if successful
    if successful_uploads > 0:
        add_label(thread_id, "Archived-to-Nextcloud")
        add_label(thread_id, "Emergent-Receipts")
    
    return {
        "status": "success" if successful_uploads > 0 else "upload_failed",
        "attachments": len(attachments),
        "uploaded": successful_uploads
    }

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Find and process Emergent receipts")
    parser.add_argument("--dry-run", action="store_true", default=True, help="Dry run (default)")
    parser.add_argument("--process", action="store_true", help="Actually download and upload")
    parser.add_argument("--max", type=int, default=100, help="Max emails to search")
    args = parser.parse_args()
    
    dry_run = not args.process
    
    log_message(f"Starting Emergent receipts search (dry_run={dry_run})")
    
    # Search for Emergent emails
    threads = search_emergent_emails(max_results=args.max)
    
    # Analyze each thread
    financial_threads = []
    non_financial_threads = []
    
    for thread in threads:
        if is_financial_email(thread):
            financial_threads.append(thread)
        else:
            non_financial_threads.append(thread)
    
    log_message(f"Analysis complete:")
    log_message(f"  Total Emergent threads: {len(threads)}")
    log_message(f"  Financial/receipt threads: {len(financial_threads)}")
    log_message(f"  Non-financial threads: {len(non_financial_threads)}")
    
    # Show financial threads
    if financial_threads:
        log_message("\nFinancial/Receipt threads found:")
        for i, thread in enumerate(financial_threads[:10]):  # Show first 10
            subject = thread.get("subject", "")[:60]
            from_field = thread.get("from", "")
            labels = thread.get("labels", [])
            log_message(f"  {i+1}. {subject}")
            log_message(f"     From: {from_field}")
            log_message(f"     Labels: {', '.join(labels)}")
    
    # Process financial threads
    if financial_threads and not dry_run:
        log_message(f"\nProcessing {len(financial_threads)} financial threads...")
        results = []
        for thread in financial_threads:
            result = process_thread(thread, dry_run=False)
            results.append(result)
        
        # Summary
        successful = sum(1 for r in results if r["status"] == "success")
        failed = sum(1 for r in results if r["status"] in ["failed", "upload_failed"])
        total_attachments = sum(r["attachments"] for r in results)
        
        log_message(f"\nProcessing complete:")
        log_message(f"  Successful: {successful}")
        log_message(f"  Failed: {failed}")
        log_message(f"  Total attachments: {total_attachments}")
    elif financial_threads and dry_run:
        log_message(f"\nDRY RUN: Would process {len(financial_threads)} financial threads")
        # Process first 3 as example
        for i, thread in enumerate(financial_threads[:3]):
            result = process_thread(thread, dry_run=True)
            log_message(f"  Thread {i+1}: {result['status']} with {result['attachments']} attachments")
    
    log_message("\nDone.")

if __name__ == "__main__":
    main()