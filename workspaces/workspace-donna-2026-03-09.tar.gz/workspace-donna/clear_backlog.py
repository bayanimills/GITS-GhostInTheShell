#!/usr/bin/env python3
import subprocess
import sys
import time
import json

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"
BATCH_SIZE = 20
MAX_FETCH = 1000
TIMEOUT = 60

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def fetch_threads(max_count):
    success, output = run_gog(["gmail", "search", "in:inbox", "--max", str(max_count), "--json"])
    if not success:
        return []
    data = json.loads(output)
    return [t["id"] for t in data.get("threads", [])]

def archive_batch(batch):
    args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
    success, _ = run_gog(args)
    return success

def main():
    print("Clearing inbox backlog...")
    total = 0
    # Fetch all current threads
    ids = fetch_threads(MAX_FETCH)
    if not ids:
        print("Inbox already empty.")
        return
    print(f"Found {len(ids)} threads to archive.")
    
    # Process in batches
    for i in range(0, len(ids), BATCH_SIZE):
        batch = ids[i:i+BATCH_SIZE]
        success = archive_batch(batch)
        if not success:
            print("Batch failed, aborting.")
            sys.exit(1)
        total += len(batch)
        print(f"  Batch {i//BATCH_SIZE + 1}: {len(batch)} threads archived")
        time.sleep(0.5)
    
    print(f"Backlog cleared. Total archived: {total} threads.")
    
    # Check for new arrivals (up to 2 times)
    for attempt in range(2):
        new_ids = fetch_threads(200)
        if not new_ids:
            print(f"No new arrivals after clearing (attempt {attempt+1}).")
            break
        print(f"New arrivals detected: {len(new_ids)} threads. Archiving...")
        for i in range(0, len(new_ids), BATCH_SIZE):
            batch = new_ids[i:i+BATCH_SIZE]
            success = archive_batch(batch)
            if not success:
                print("Batch failed on new arrivals, stopping.")
                break
            total += len(batch)
            print(f"  New batch {i//BATCH_SIZE + 1}: {len(batch)} threads")
            time.sleep(0.5)
        print(f"New arrivals archived. Total so far: {total}")
    
    # Final count
    remaining = fetch_threads(10)
    print(f"Remaining in inbox: {len(remaining)} threads.")
    if remaining:
        print("Sample thread IDs:", remaining[:3])

if __name__ == "__main__":
    main()