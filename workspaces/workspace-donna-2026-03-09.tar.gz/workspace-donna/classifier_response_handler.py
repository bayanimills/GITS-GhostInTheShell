#!/usr/bin/env python3
"""
Classifier review response handler.
Processes user's choice (1 or 2) for pending classifier review question.
Applies chosen label to email thread, logs correction, and clears pending state.
"""
import os
import sys
import json
import datetime
import subprocess
from pathlib import Path

# Configuration
ACCOUNT = "bayanimills@gmail.com"
GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
PENDING_FILE = Path("/home/agent/.openclaw/workspace-donna/classifier_pending.json")
CORRECTIONS_FILE = Path("/home/agent/.openclaw/workspace-donna/classifier_corrections.json")

def run_gog(args, account=ACCOUNT):
    """Run gog command and return parsed JSON if available."""
    cmd = [GOG_BIN] + args + ["--account", account]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        print(f"gog timeout: command took too long: {' '.join(cmd)}", file=sys.stderr)
        return None
    except subprocess.CalledProcessError as e:
        print(f"gog error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

def load_pending():
    """Load pending classifier question."""
    if not PENDING_FILE.exists():
        print("  No pending classifier question.", file=sys.stderr)
        return None
    with open(PENDING_FILE) as f:
        return json.load(f)

def save_correction(pending, chosen_label):
    """Save correction to corrections log."""
    corrections = []
    if CORRECTIONS_FILE.exists():
        with open(CORRECTIONS_FILE) as f:
            corrections = json.load(f)
    
    correction_entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "thread_id": pending["thread_id"],
        "subject": pending["subject"],
        "sender": pending["sender"],
        "original_label1": pending["label1"],
        "original_label2": pending["label2"],
        "chosen_label": chosen_label,
        "applied": False  # will be set True after successful label application
    }
    corrections.append(correction_entry)
    with open(CORRECTIONS_FILE, "w") as f:
        json.dump(corrections, f, indent=2)
    
    return correction_entry

def apply_label(thread_id, label):
    """Apply label to email thread via gog."""
    # First, ensure label exists (create if not) - using gmail labels create
    label_create_result = run_gog(["gmail", "labels", "create", label])
    if label_create_result is None:
        print(f"  Warning: label creation may have failed; proceeding anyway.")
    
    # Apply label to thread
    result = run_gog(["gmail", "thread", "modify", thread_id, "--add", label])
    if result is None:
        print(f"  ERROR: Failed to apply label {label} to thread {thread_id}.", file=sys.stderr)
        return False
    print(f"  Applied label: {label}")
    return True

def main():
    if len(sys.argv) != 2:
        print("Usage: python classifier_response_handler.py <choice>")
        print("  choice: 1 or 2 (corresponding to label options)")
        sys.exit(1)
    
    choice = sys.argv[1].strip()
    if choice not in ("1", "2"):
        print("  ERROR: Choice must be 1 or 2.", file=sys.stderr)
        sys.exit(1)
    
    print(f"Classifier response handler — {datetime.datetime.now().isoformat()}")
    
    # Load pending question
    pending = load_pending()
    if not pending:
        sys.exit(1)
    
    print(f"  Thread: {pending['thread_id']}")
    print(f"  Subject: {pending['subject']}")
    print(f"  Sender: {pending['sender']}")
    print(f"  Options: 1) {pending['label1']}, 2) {pending['label2']}")
    print(f"  User choice: {choice}")
    
    # Determine chosen label
    chosen_label = pending["label1"] if choice == "1" else pending["label2"]
    print(f"  Selected label: {chosen_label}")
    
    # Apply label
    success = apply_label(pending["thread_id"], chosen_label)
    if not success:
        sys.exit(1)
    
    # Log correction
    correction = save_correction(pending, chosen_label)
    correction["applied"] = True
    # Update correction entry with applied status
    if CORRECTIONS_FILE.exists():
        with open(CORRECTIONS_FILE) as f:
            corrections = json.load(f)
        if corrections:
            corrections[-1]["applied"] = True
            with open(CORRECTIONS_FILE, "w") as f:
                json.dump(corrections, f, indent=2)
    
    # Clear pending file
    PENDING_FILE.unlink()
    print("  Pending cleared. Correction logged.")
    
    # Optionally, also archive the email after labeling? Not needed; label is enough.
    # We could also remove from INBOX if label is not an "inbox" label.
    # For now, just apply label.
    
    # Update classifier rules based on correction
    print("  Updating classifier rules...")
    rule_updater_script = "/home/agent/.openclaw/workspace-donna/classifier_rule_updater.py"
    if os.path.exists(rule_updater_script):
        import subprocess
        result = subprocess.run([sys.executable, rule_updater_script], capture_output=True, text=True)
        if result.returncode == 0:
            print("  Rules updated successfully.")
        else:
            print(f"  Rule updater exited with code {result.returncode}: {result.stderr}")
    else:
        print("  Rule updater script not found.")
    
    print("  Done.")

if __name__ == "__main__":
    main()