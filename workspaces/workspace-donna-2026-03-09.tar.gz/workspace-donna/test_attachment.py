#!/usr/bin/env python3
import subprocess, json, base64, sys

def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout, result.stderr, result.returncode

thread_id = "19cbb4fb74d2a389"
stdout, stderr, rc = run(["/home/agent/.linuxbrew/bin/gog", "gmail", "thread", thread_id, "--json", "--account", "bayanimills@gmail.com"])
if rc != 0:
    print(stderr)
    exit(1)
data = json.loads(stdout)
messages = data.get("thread", {}).get("messages", [])
for msg in messages:
    msg_id = msg.get('id')
    print(f"Message ID: {msg_id}")
    payload = msg.get("payload", {})
    def walk(part, depth=0):
        mime = part.get("mimeType", "")
        filename = part.get("filename", "")
        body = part.get("body", {})
        attachmentId = body.get("attachmentId")
        if attachmentId:
            print("  " * depth + f"Attachment: {filename} ({mime}) id={attachmentId}")
        if "parts" in part:
            for sub in part["parts"]:
                walk(sub, depth+1)
    walk(payload)
    break