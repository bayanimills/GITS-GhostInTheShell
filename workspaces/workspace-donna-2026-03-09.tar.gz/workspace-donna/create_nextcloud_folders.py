#!/usr/bin/env python3
"""
Create Nextcloud folder structure for financial attachments.
"""
import subprocess
import sys

NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"

def mkcol(path):
    """Create directory via WebDAV MKCOL."""
    url = f"{NEXTCLOUD_BASE_URL}{path}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        url
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"Created directory: {path}")
        return True
    elif "405" in result.stderr:  # Method Not Allowed - directory may already exist
        print(f"Directory already exists: {path}")
        return True
    else:
        print(f"Failed to create directory {path}: {result.stderr}")
        return False

def main():
    folders = [
        # Business folders (should already exist)
        "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Invoices/",
        "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Receipts/",
        "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Statements/",
        # Personal folders
        "/_private/personal/Finances/Invoices/",
        "/_private/personal/Finances/Receipts/",
        "/_private/personal/Finances/Receipts/Food/",
        "/_private/personal/Finances/Receipts/Crypto/",
        "/_private/personal/Finances/Statements/",
    ]
    
    for folder in folders:
        mkcol(folder)

if __name__ == "__main__":
    main()