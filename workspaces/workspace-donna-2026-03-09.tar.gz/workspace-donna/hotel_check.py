#!/usr/bin/env python3
"""
Hotel availability monthly check.
Reads hotel_tracking.md and outputs reminder for monthly review.
"""
import os
import sys
import subprocess
from datetime import datetime

def send_telegram(message):
    """Send message via openclaw CLI."""
    if not message or message.strip() == "":
        return False
    # Truncate if too long (Telegram limit ~4096 chars)
    if len(message) > 4000:
        message = message[:3997] + "..."
    cmd = ["openclaw", "message", "send", "--channel", "telegram", "--target", "548072941", "--message", message]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            print(f"Failed to send Telegram: {result.stderr}", file=sys.stderr)
            return False
        return True
    except Exception as e:
        print(f"Error sending Telegram: {e}", file=sys.stderr)
        return False

def main():
    tracking_file = os.path.join(os.path.dirname(__file__), "hotel_tracking.md")
    if not os.path.exists(tracking_file):
        msg = "Hotel tracking file not found."
        success = send_telegram(msg)
        sys.exit(0 if success else 1)
    
    with open(tracking_file, 'r') as f:
        content = f.read()
    
    # Extract relevant info - simple parsing
    lines = content.split('\n')
    hotels = []
    current_hotel = None
    for line in lines:
        line = line.strip()
        if line.startswith('### '):
            current_hotel = line[4:].strip()
        elif line.startswith('- **Last checked:**'):
            last_checked = line.split(':', 1)[1].strip()
        elif line.startswith('- **Next check due:**'):
            next_check = line.split(':', 1)[1].strip()
            if current_hotel:
                hotels.append((current_hotel, next_check))
    
    today = datetime.now().strftime('%Y-%m-%d')
    msg_parts = []
    msg_parts.append(f"🏨 **Monthly Hotel Availability Check** ({today})")
    msg_parts.append("")
    if hotels:
        for hotel, next_check in hotels:
            msg_parts.append(f"• **{hotel}** – next check due {next_check}")
    else:
        msg_parts.append("No hotel tracking data found.")
    msg_parts.append("")
    msg_parts.append("Review hotel_tracking.md for details and check booking sites.")
    
    message = "\n".join(msg_parts)
    success = send_telegram(message)
    if not success:
        print("Failed to send Telegram message.", file=sys.stderr)
        sys.exit(1)
    else:
        print("Hotel check reminder sent.")

if __name__ == "__main__":
    main()