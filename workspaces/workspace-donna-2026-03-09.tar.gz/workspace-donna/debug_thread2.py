#!/usr/bin/env python3
import subprocess, json, base64, sys

def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout, result.stderr, result.returncode

thread_id = sys.argv[1] if len(sys.argv) > 1 else "19cbb4fb74d2a389"
stdout, stderr, rc = run(["/home/agent/.linuxbrew/bin/gog", "gmail", "thread", thread_id, "--json", "--account", "bayanimills@gmail.com"])
if rc != 0:
    print(stderr)
    exit(1)
data = json.loads(stdout)
messages = data.get("thread", {}).get("messages", [])
for msg in messages:
    print(f"Subject: {msg.get('subject')}")
    payload = msg.get("payload", {})
    def walk(part, depth=0):
        mime = part.get("mimeType", "")
        print("  " * depth + f"mime: {mime}")
        if mime in ["text/plain", "text/html"]:
            body_data = part.get("body", {}).get("data")
            if body_data:
                try:
                    body = base64.b64decode(body_data).decode('utf-8', errors='ignore')
                    lines = body.split('\n')
                    for line in lines:
                        if 'http' in line:
                            print("  " * depth + line[:200])
                except:
                    pass
        if "parts" in part:
            for sub in part["parts"]:
                walk(sub, depth+1)
    walk(payload)
    break