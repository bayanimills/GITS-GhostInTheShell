#!/usr/bin/env python3
"""
Classifier review script for Gmail automation.
Runs at scheduled times (8am & 2pm AEST) to ask a single question about ambiguous emails.
Implements: single question, twice daily, with two confidence-based folder options.
"""
import os
import sys
import json
import datetime
import subprocess
import re
from pathlib import Path

# Configuration
ACCOUNT = "bayanimills@gmail.com"
LABEL_RULES_PATH = Path("/home/agent/.openclaw/workspace/skills/gmail-skill/config/label_rules.json")
GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
MAX_EMAILS = 50  # Scan last 50 emails for review
CONFIDENCE_THRESHOLD = 3  # priority_score < 3 considered low confidence
HIGH_PRIORITY_KEYWORDS = ["finance", "calendar", "family", "business", "medical", "urgent"]
REVIEW_TIMES = ["08:00", "14:00"]  # AEST
STATE_FILE = Path("/home/agent/.openclaw/workspace-donna/classifier_review_state.json")
CORRECTIONS_FILE = Path("/home/agent/.openclaw/workspace-donna/classifier_corrections.json")
PENDING_FILE = Path("/home/agent/.openclaw/workspace-donna/classifier_pending.json")

def run_gog(args, account=ACCOUNT):
    """Run gog command and return parsed JSON if available."""
    cmd = [GOG_BIN] + args + ["--account", account]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        print(f"gog timeout: command took too long: {' '.join(cmd)}", file=sys.stderr)
        return None
    except subprocess.CalledProcessError as e:
        print(f"gog error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

def fetch_inbox_threads(max_results=MAX_EMAILS):
    """Fetch threads from INBOX (excluding promotions)."""
    query = "in:inbox -category:promotions newer_than:7d"
    data = run_gog(["gmail", "search", query, "--max", str(max_results), "--json"])
    if not data:
        return []
    return data.get("threads", [])

def load_classifier():
    """Load enhanced classifier."""
    try:
        sys.path.insert(0, str(Path(__file__).parent))
        from classifier import EmailClassifier
        return EmailClassifier(LABEL_RULES_PATH)
    except ImportError as e:
        print(f"Failed to load classifier: {e}", file=sys.stderr)
        return None

def is_high_priority(sender, subject):
    """Check if email appears high-priority based on sender or keywords."""
    text = (subject + " " + sender).lower()
    for kw in HIGH_PRIORITY_KEYWORDS:
        if kw in text:
            return True
    # Check sender domains
    high_priority_domains = ["bank", "gov", "service.nsw", "ato", "tax", "medical", "hospital", "doctor"]
    for domain in high_priority_domains:
        if domain in sender.lower():
            return True
    return False

def get_two_candidate_labels(classifier, subject, sender):
    """
    Return two candidate labels for ambiguous email.
    First candidate: classifier's primary label.
    Second candidate: second best matching label (if multiple patterns) or generic fallback.
    """
    # Get primary classification
    label, delay, metadata = classifier.classify(subject, sender)
    priority_score = metadata.get("priority_score", 0)
    
    # Get matched patterns with labels
    matched_patterns = classifier.match_patterns(subject, sender)
    
    # Collect unique labels from matched patterns
    pattern_labels = []
    for pattern in matched_patterns:
        pattern_label = pattern.get("label")
        if pattern_label and pattern_label not in pattern_labels:
            pattern_labels.append(pattern_label)
    
    second_label = None
    
    # If we have at least two distinct pattern labels, use second
    if len(pattern_labels) >= 2:
        second_label = pattern_labels[1]  # second distinct label
    elif len(pattern_labels) == 1:
        # Only one pattern label; try to infer alternative from subject/sender
        second_label = infer_alternative_label(subject, sender, pattern_labels[0])
    else:
        # No patterns matched, fallback generic
        second_label = infer_alternative_label(subject, sender, None)
    
    return label, second_label, priority_score, metadata

def infer_alternative_label(subject, sender, primary_label):
    """Infer a reasonable alternative label based on email content."""
    subject_lower = subject.lower()
    sender_lower = sender.lower()
    
    # Generic categories
    if "finance" in subject_lower or "invoice" in subject_lower or "receipt" in subject_lower:
        return "Finance/Personal"
    elif "calendar" in subject_lower or "meeting" in subject_lower or "appointment" in subject_lower:
        return "Calendar"
    elif "medical" in subject_lower or "health" in subject_lower or "doctor" in sender_lower:
        return "Medical"
    elif "family" in subject_lower or "family" in sender_lower:
        return "Family"
    elif "work" in subject_lower or "business" in subject_lower:
        return "Work"
    elif "shopping" in subject_lower or "order" in subject_lower:
        return "Shopping"
    else:
        return "ToReview"  # generic catch-all

def load_state():
    """Load review state (last review time, questions asked today)."""
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {
        "last_review_date": None,
        "questions_asked_today": 0,
        "last_question_time": None
    }

def save_state(state):
    """Save review state."""
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def load_corrections():
    """Load existing corrections."""
    if CORRECTIONS_FILE.exists():
        with open(CORRECTIONS_FILE) as f:
            return json.load(f)
    return []

def save_corrections(corrections):
    """Save corrections."""
    with open(CORRECTIONS_FILE, "w") as f:
        json.dump(corrections, f, indent=2)

def should_ask_question(state):
    """
    Determine if we should ask a question now.
    Rules:
    - Only between 08:00-20:00 AEST (awake hours)
    - Max 1 question per review (2 per day)
    - Not asked already today (or reset at midnight)
    """
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M")
    current_date = now.strftime("%Y-%m-%d")
    
    # Check awake hours (08:00-20:00 AEST)
    hour = now.hour
    if hour < 8 or hour >= 20:
        return False
    
    # Reset daily counter if new day
    if state.get("last_review_date") != current_date:
        state["last_review_date"] = current_date
        state["questions_asked_today"] = 0
    
    # Check daily cap (max 2 questions per day)
    if state["questions_asked_today"] >= 2:
        return False
    
    # Check if we already asked a question in this review window
    # (prevent asking multiple questions within same hour)
    last_question = state.get("last_question_time")
    if last_question:
        last = datetime.datetime.fromisoformat(last_question)
        if (now - last).total_seconds() < 3600:  # 1 hour cooldown
            return False
    
    return True

def ask_question_via_telegram(subject, sender, label1, label2, thread_id):
    """
    Send classifier review question via Telegram.
    Returns message ID for tracking (not implemented).
    """
    # Format message (clean, Telegram-friendly)
    message = f"""💬 [Classifier Review]
Subject: {subject[:80]}{'…' if len(subject) > 80 else ''}
From: {sender[:60]}{'…' if len(sender) > 60 else ''}

Options:
1) {label1}
2) {label2}

Which label is correct? (Reply with 1 or 2)"""
    
    # Store pending question for response handler
    pending_file = PENDING_FILE
    pending_data = {
        "thread_id": thread_id,
        "subject": subject,
        "sender": sender,
        "label1": label1,
        "label2": label2,
        "timestamp": datetime.datetime.now().isoformat()
    }
    with open(pending_file, "w") as f:
        json.dump(pending_data, f, indent=2)
    
    # Print for agent to capture and send via message tool
    print(message)
    return "simulated_message_id"

def main():
    print(f"Classifier review — {datetime.datetime.now().isoformat()}")
    
    # Load state
    state = load_state()
    
    # Check if we should ask a question
    if not should_ask_question(state):
        print("  Skipping: question not permitted at this time.")
        return
    
    # Load classifier
    classifier = load_classifier()
    if not classifier:
        print("  ERROR: Classifier not available.")
        return
    
    # Fetch inbox threads
    threads = fetch_inbox_threads()
    if not threads:
        print("  No INBOX threads to review.")
        return
    
    # Find ambiguous emails
    ambiguous_candidates = []
    for thread in threads:
        thread_id = thread["id"]
        subject = thread.get("subject", "")
        sender = thread.get("from", "")
        
        # Skip if not high priority
        if not is_high_priority(sender, subject):
            continue
        
        # Classify
        label, second_label, priority_score, metadata = get_two_candidate_labels(
            classifier, subject, sender
        )
        
        # Check confidence threshold
        if priority_score < CONFIDENCE_THRESHOLD:
            ambiguous_candidates.append({
                "thread_id": thread_id,
                "subject": subject,
                "sender": sender,
                "label1": label,
                "label2": second_label,
                "priority_score": priority_score,
                "metadata": metadata
            })
    
    if not ambiguous_candidates:
        print("  No ambiguous emails found.")
        return
    
    # Sort by priority_score (lowest = most ambiguous)
    ambiguous_candidates.sort(key=lambda x: x["priority_score"])
    
    # Pick the most ambiguous email
    candidate = ambiguous_candidates[0]
    print(f"  Selected ambiguous email: {candidate['subject']}")
    print(f"    From: {candidate['sender']}")
    print(f"    Priority score: {candidate['priority_score']}")
    print(f"    Candidate labels: 1) {candidate['label1']} 2) {candidate['label2']}")
    
    # Ask question
    message_id = ask_question_via_telegram(
        candidate['subject'],
        candidate['sender'],
        candidate['label1'],
        candidate['label2'],
        candidate['thread_id']
    )
    
    # Update state
    state["questions_asked_today"] += 1
    state["last_question_time"] = datetime.datetime.now().isoformat()
    save_state(state)
    
    print("  Question sent. Waiting for user response...")
    # Note: Response handling would be separate script

if __name__ == "__main__":
    main()