#!/usr/bin/env python3
import subprocess
import sys
import time

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"
BATCH_SIZE = 100
MAX_FETCH = 500

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def main():
    total = 0
    while True:
        print(f"Fetching up to {MAX_FETCH} threads...")
        success, output = run_gog(["gmail", "search", "in:inbox", "--max", str(MAX_FETCH), "--json"])
        if not success:
            print("Failed to fetch threads.")
            break
        import json
        data = json.loads(output)
        threads = data.get("threads", [])
        ids = [t["id"] for t in threads]
        if not ids:
            print("Inbox empty.")
            break
        print(f"Processing {len(ids)} threads...")
        # Process in batches
        for i in range(0, len(ids), BATCH_SIZE):
            batch = ids[i:i+BATCH_SIZE]
            args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
            success, _ = run_gog(args)
            if not success:
                print("Batch failed, stopping.")
                sys.exit(1)
            print(f"  Batch {i//BATCH_SIZE + 1}: {len(batch)} threads archived")
            total += len(batch)
            time.sleep(0.5)
        print(f"Total archived so far: {total}")
        # If we got fewer than MAX_FETCH, we've cleared the backlog (new arrivals may appear)
        if len(threads) < MAX_FETCH:
            print("Backlog cleared.")
            break
    print(f"Done. Total archived: {total} threads.")
    # Final count
    success, output = run_gog(["gmail", "search", "in:inbox", "--max", "10", "--json"])
    if success:
        data = json.loads(output)
        remaining = len(data.get("threads", []))
        print(f"Remaining in inbox: {remaining}")
    else:
        print("Could not verify final count.")

if __name__ == "__main__":
    main()