#!/usr/bin/env python3
import subprocess, json, base64

def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout, result.stderr, result.returncode

thread_id = "19cbbf542d31ead5"
stdout, stderr, rc = run(["/home/agent/.linuxbrew/bin/gog", "gmail", "thread", thread_id, "--json", "--account", "bayanimills@gmail.com"])
if rc != 0:
    print(stderr)
    exit(1)
data = json.loads(stdout)
thread = data.get("thread", {})
messages = thread.get("messages", [])
for i, msg in enumerate(messages):
    print(f"Message {i}:")
    print(f"  Subject: {msg.get('subject')}")
    print(f"  From: {msg.get('from')}")
    print(f"  Parts: {len(msg.get('parts', []))}")
    for j, part in enumerate(msg.get('parts', [])):
        print(f"    Part {j}: mimeType={part.get('mimeType')}, size={len(part.get('body', {}).get('data', ''))}")
        if part.get('body', {}).get('data'):
            try:
                decoded = base64.b64decode(part['body']['data']).decode('utf-8', errors='ignore')
                print(f"      Preview: {decoded[:200]}")
            except:
                pass
    # Also look for 'body' at top level
    if 'body' in msg:
        print(f"  Top-level body: {msg['body']}")