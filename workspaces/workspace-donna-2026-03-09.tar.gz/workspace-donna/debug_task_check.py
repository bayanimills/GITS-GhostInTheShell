#!/usr/bin/env python3
import sys
sys.path.append('/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import get

def debug_existing_task_check(title, assignee):
    try:
        result = get('/tasks/list', params={'limit': 100})
        tasks = result.get('results', [])
        print(f"Total tasks fetched: {len(tasks)}")
        for idx, task in enumerate(tasks):
            print(f"\n--- Task {idx} ---")
            print(f"Task keys: {list(task.keys())}")
            item = task.get('item', task)
            print(f"Item keys: {list(item.keys()) if isinstance(item, dict) else 'not dict'}")
            
            # Check each field with safe access
            title_val = item.get('title')
            assignee_val = item.get('assignee')
            status_val = item.get('status')
            print(f"title: {repr(title_val)}")
            print(f"assignee: {repr(assignee_val)}")
            print(f"status: {repr(status_val)}")
            
            # Try the strip calls that might fail
            try:
                task_title = item.get('title', '').strip()
                print(f"title strip ok: {repr(task_title)}")
            except Exception as e:
                print(f"title strip error: {e}")
            try:
                task_assignee = item.get('assignee', '').strip()
                print(f"assignee strip ok: {repr(task_assignee)}")
            except Exception as e:
                print(f"assignee strip error: {e}")
            try:
                task_status = item.get('status', '').strip()
                print(f"status strip ok: {repr(task_status)}")
            except Exception as e:
                print(f"status strip error: {e}")
            
            # Check if matches
            if title_val and assignee_val:
                if title_val.strip() == title.strip() and assignee_val.strip() == assignee.strip():
                    print(f"MATCH FOUND! Task ID: {item.get('id') or task.get('id')}")
                    return item.get('id') or task.get('id')
    except Exception as e:
        print(f"Error in debug: {e}")
        import traceback
        traceback.print_exc()
    return None

if __name__ == '__main__':
    print("Checking for API task...")
    api_id = debug_existing_task_check(
        'Research current API rate limits and document implications for scaling',
        'Bayani Mills'
    )
    print(f"\nAPI task ID found: {api_id}")
    
    print("\n\nChecking for competitor task...")
    comp_id = debug_existing_task_check(
        'Analyze competitor pricing and propose updated tier structure',
        'Bayani Mills'
    )
    print(f"\nCompetitor task ID found: {comp_id}")