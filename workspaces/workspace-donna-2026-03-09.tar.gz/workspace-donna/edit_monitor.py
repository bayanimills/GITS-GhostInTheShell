#!/usr/bin/env python3
import sys
import os

path = '/home/agent/.openclaw/workspace/skills/gmail-skill/scripts/monitor_gmail_enhanced.py'

with open(path, 'r') as f:
    lines = f.readlines()

# Find line with "Priority breakdown"
insert_index = None
for i, line in enumerate(lines):
    if 'Priority breakdown' in line:
        # Find the next line that is not part of the same block
        # Actually we want to insert after the block, before "# Optional detailed log"
        # Let's find the line with "# Optional detailed log"
        pass

# Simpler: find line with "# Optional detailed log" and insert before that
for i, line in enumerate(lines):
    if '# Optional detailed log' in line:
        insert_index = i
        break

if insert_index is None:
    # fallback: insert before the last 5 lines (where if __name__ is)
    for i, line in enumerate(lines):
        if 'if __name__' in line:
            insert_index = i - 1  # before the blank line before if __name__
            break

if insert_index is None:
    print("Could not find insertion point")
    sys.exit(1)

# Insert new lines
new_lines = [
    '\n',
    '    # Run financial attachment processing every 4 hours (aligned with hourly cron)\n',
    '    current_hour = datetime.datetime.now().hour\n',
    '    if current_hour % 4 == 0:\n',
    '        print("\\nRunning financial attachment processing...")\n',
    '        script_path = "/home/agent/.openclaw/workspace-donna/process_financial_attachments.py"\n',
    '        try:\n',
    '            subprocess.run([sys.executable, script_path, "--max-per-label", "10"], \n',
    '                          check=True, timeout=300)\n',
    '            print("  Financial attachment processing completed.")\n',
    '        except subprocess.TimeoutExpired:\n',
    '            print("  Financial attachment processing timed out after 5 minutes.")\n',
    '        except subprocess.CalledProcessError as e:\n',
    '            print(f"  Financial attachment processing failed: {e}")\n',
]

# Ensure we have proper indentation (already indented inside main)
lines[insert_index:insert_index] = new_lines

# Write back
with open(path, 'w') as f:
    f.writelines(lines)

print(f"Updated {path}")
print("Added financial attachment processing trigger every 4 hours.")