#!/usr/bin/env python3
"""
Daily check-in for promotional emails.
Reports counts, top domains, and age distribution.
Optionally archives emails older than threshold (default: 7 days).
"""
import subprocess
import sys
import json
import datetime
import re
import argparse
from collections import Counter
from pathlib import Path

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"
DEFAULT_ARCHIVE_DAYS = 7
DELAY_DAYS = 3
DELAY_SECONDS = DELAY_DAYS * 24 * 60 * 60

# Top eight domains from original analysis (Feb 27 2026)
DELAY_DOMAINS = {
    'e.kogan.com',
    'cluborange.org',
    'email.livenation.com.au',
    'edm2.umart.com.au',
    'buckettys.com.au',
    'coinspot.com.au',
    'au.enews.bp.email',
    'thinlizzy.com.au',
}

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def extract_domain(sender):
    """Extract domain from From field, e.g., 'Kogan <email@e.kogan.com>' -> 'e.kogan.com'"""
    match = re.search(r'@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', sender)
    if match:
        return match.group(1).lower()
    if '@' in sender:
        return sender.split('@')[-1].strip('>').lower()
    return ''

def parse_date(date_str):
    """Parse DATE column (e.g., '2026-02-21 17:54') to datetime."""
    try:
        return datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M")
    except ValueError:
        return datetime.datetime.now()

def format_age(seconds):
    days = seconds // (24 * 3600)
    hours = (seconds % (24 * 3600)) // 3600
    if days > 0:
        return f"{days}d{hours}h"
    return f"{hours}h"

def main():
    parser = argparse.ArgumentParser(description='Daily check-in for promotional emails.')
    parser.add_argument('--dry-run', action='store_true', default=True,
                       help='Dry run, do not archive (default)')
    parser.add_argument('--archive', action='store_true',
                       help='Actually archive emails older than threshold')
    parser.add_argument('--max', type=int, default=500, help='Maximum threads to fetch')
    parser.add_argument('--archive-days', type=int, default=DEFAULT_ARCHIVE_DAYS,
                       help='Archive emails older than this many days (default: 7)')
    args = parser.parse_args()
    
    now = datetime.datetime.now()
    archive_threshold = args.archive_days * 24 * 60 * 60
    
    print(f"Daily promotional email check — {now.isoformat()}")
    if args.dry_run and not args.archive:
        print("DRY RUN - no changes will be made")
    
    # Fetch all promotional threads in inbox
    success, output = run_gog(["gmail", "search", "in:inbox category:promotions", "--max", str(args.max), "--json"])
    if not success:
        print("Failed to fetch promotional threads.")
        return
    
    try:
        data = json.loads(output)
        threads = data.get("threads")
        if threads is None:
            threads = []
    except (json.JSONDecodeError, TypeError, AttributeError):
        print("Failed to parse thread data.")
        return
    
    total = len(threads)
    print(f"Found {total} promotional threads in inbox.")
    sys.stdout.flush()
    
    # Categorize
    domain_counter = Counter()
    immediate = []
    delayed_domain = []
    delayed_recent = []
    delayed_old = []
    archive_candidates = []  # threads older than archive_threshold
    
    for thread in threads:
        thread_id = thread["id"]
        sender = thread.get("from") or ""
        date_str = thread.get("date") or ""
        domain = extract_domain(sender)
        domain_counter[domain] += 1
        
        received = parse_date(date_str)
        age_seconds = (now - received).total_seconds()
        
        if domain in DELAY_DOMAINS:
            if age_seconds >= DELAY_SECONDS:
                delayed_old.append((thread_id, domain, age_seconds))
            else:
                delayed_recent.append((thread_id, domain, age_seconds))
        else:
            immediate.append((thread_id, domain, age_seconds))
        
        if age_seconds >= archive_threshold:
            archive_candidates.append((thread_id, domain, age_seconds))
    
    # Summary report
    print("\n=== PROMOTIONAL INBOX REPORT ===")
    print(f"Total: {total}")
    print(f"Immediate archive (non-delay domains): {len(immediate)}")
    print(f"Delayed domains (top eight): {len(delayed_old) + len(delayed_recent)}")
    print(f"  - Old enough (>={DELAY_DAYS} days): {len(delayed_old)}")
    print(f"  - Recent (<{DELAY_DAYS} days): {len(delayed_recent)}")
    print(f"Candidates for archiving (>={args.archive_days} days): {len(archive_candidates)}")
    
    # Top domains
    if domain_counter:
        print("\nTop domains:")
        for domain, count in domain_counter.most_common(10):
            print(f"  {domain}: {count}")
    
    # Recent delayed threads (sample)
    if delayed_recent:
        print(f"\nRecent delayed threads (kept in inbox):")
        for thread_id, domain, age in delayed_recent[:3]:
            print(f"  {domain} ({format_age(age)})")
        if len(delayed_recent) > 3:
            print(f"  ... and {len(delayed_recent) - 3} more")
    
    # Archive candidates (sample)
    if archive_candidates:
        print(f"\nOld threads (>={args.archive_days} days):")
        for thread_id, domain, age in archive_candidates[:5]:
            print(f"  {domain} ({format_age(age)})")
        if len(archive_candidates) > 5:
            print(f"  ... and {len(archive_candidates) - 5} more")
    
    # Action
    if args.archive and not args.dry_run:
        print(f"\nArchiving {len(archive_candidates)} threads older than {args.archive_days} days...")
        batch_size = 5
        for i in range(0, len(archive_candidates), batch_size):
            batch = [tc[0] for tc in archive_candidates[i:i+batch_size]]
            gog_args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
            success, _ = run_gog(gog_args)
            if not success:
                print(f"Error archiving batch {i//batch_size + 1}")
        print("Archive complete.")
    elif args.archive and args.dry_run:
        print(f"\nDry run: would archive {len(archive_candidates)} threads older than {args.archive_days} days.")
    else:
        print(f"\nNo archiving performed (dry-run).")
    
    # Final count
    success, output = run_gog(["gmail", "search", "in:inbox category:promotions", "--max", "10", "--json"])
    if success:
        try:
            data = json.loads(output)
            threads = data.get("threads")
            if threads is None:
                threads = []
            remaining = len(threads)
            print(f"Remaining promotional threads in inbox: {remaining}")
        except (json.JSONDecodeError, TypeError, AttributeError):
            print("Could not parse verification output.")
    else:
        print("Could not verify remaining threads.")
    
    print("\n=== END REPORT ===")

if __name__ == "__main__":
    main()