#!/usr/bin/env python3
"""
Quick analysis of prolific email senders using thread list only.
"""
import subprocess
import json
import sys
from collections import Counter
from email.utils import parseaddr
import re

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def extract_domain(email_address):
    """Extract domain from email address."""
    _, email = parseaddr(email_address)
    if '@' in email:
        return email.lower().split('@')[1]
    return email.lower()

def analyze_senders(days=30, max_threads=200):
    """Fetch emails from last N days and count sender domains."""
    print(f"Fetching emails from last {days} days (max {max_threads})...")
    
    query = f"in:inbox newer_than:{days}d"
    cmd = ["gmail", "search", query, "--max", str(max_threads), "--json"]
    success, output = run_gog(cmd)
    if not success:
        print("Failed to fetch threads.")
        return
    
    try:
        data = json.loads(output)
        threads = data.get('threads', [])
    except json.JSONDecodeError:
        print("Failed to parse JSON response.")
        return
    
    if not threads:
        print("No threads found.")
        return
    
    print(f"Analyzing {len(threads)} threads...")
    
    # Count domains
    domain_counter = Counter()
    sender_examples = {}  # domain -> list of (sender, subject, labels)
    
    for thread in threads:
        sender = thread.get('from', '')
        subject = thread.get('subject', 'No subject')
        labels = thread.get('labels', [])
        
        domain = extract_domain(sender)
        domain_counter[domain] += 1
        
        if domain not in sender_examples:
            sender_examples[domain] = []
        sender_examples[domain].append((sender, subject[:50], labels))
    
    print("\n" + "="*60)
    print(f"Top 20 sender domains (last {days} days):")
    print("="*60)
    
    for domain, count in domain_counter.most_common(20):
        examples = sender_examples.get(domain, [])
        sample_senders = set(s[0] for s in examples[:3])
        # Check if any have promotional labels
        promo_labels = any('CATEGORY_PROMOTIONS' in ' '.join(s[2]) for s in examples[:5])
        print(f"\n{domain}: {count} emails {'[PROMO]' if promo_labels else ''}")
        print(f"  Sample: {list(sample_senders)[0] if sample_senders else 'N/A'}")
        if examples:
            print(f"  Subject: {examples[0][1]}")
    
    # Bulk sender analysis
    print("\n" + "="*60)
    print("Bulk-sender analysis (domains with 5+ emails):")
    print("="*60)
    
    bulk_domains = [(d, c) for d, c in domain_counter.items() if c >= 5]
    print(f"\nFound {len(bulk_domains)} domains with 5+ emails")
    
    for domain, count in sorted(bulk_domains, key=lambda x: x[1], reverse=True)[:15]:
        examples = sender_examples.get(domain, [])
        promo_count = sum(1 for s in examples if 'CATEGORY_PROMOTIONS' in ' '.join(s[2]))
        promo_pct = (promo_count / len(examples)) * 100 if examples else 0
        print(f"  {domain}: {count} emails ({promo_count} promo, {promo_pct:.0f}%)")
    
    # Check promotional category coverage
    print("\n" + "="*60)
    print("Promotional category coverage:")
    print("="*60)
    
    # Count threads with CATEGORY_PROMOTIONS label
    promo_threads = [t for t in threads if 'CATEGORY_PROMOTIONS' in t.get('labels', [])]
    print(f"Threads with CATEGORY_PROMOTIONS label: {len(promo_threads)}/{len(threads)} ({len(promo_threads)/len(threads)*100:.1f}%)")
    
    # Domains in promotional category
    promo_domains = set()
    for thread in promo_threads:
        sender = thread.get('from', '')
        promo_domains.add(extract_domain(sender))
    
    print(f"Unique domains in promotional category: {len(promo_domains)}")
    
    # Overlap analysis
    bulk_domain_list = [d for d, _ in bulk_domains]
    already_covered = [d for d in bulk_domain_list if d in promo_domains]
    not_covered = [d for d in bulk_domain_list if d not in promo_domains]
    
    print(f"\nBulk domains already covered by promotional filter: {len(already_covered)}")
    if already_covered:
        print("  " + ", ".join(already_covered[:10]))
    
    print(f"\nBulk domains NOT covered by promotional filter: {len(not_covered)}")
    if not_covered:
        print("  Top 10 not covered:")
        for domain in not_covered[:10]:
            count = domain_counter[domain]
            print(f"    {domain}: {count} emails")
    
    # Recommendations
    print("\n" + "="*60)
    print("Recommendations for bulk-sender archiving:")
    print("="*60)
    
    if not_covered:
        print("\n1. Target these domains for bulk-sender archiving (archive after 7 days if unread):")
        for domain in not_covered[:10]:
            count = domain_counter[domain]
            print(f"   - {domain} ({count} emails)")
        
        print("\n2. Implementation approach:")
        print("   - Add to label_rules.json with 'archive_after_days_unread: 7'")
        print("   - Use pattern matching on sender domain")
        print("   - Monitor engagement (opens/clicks) via Gmail API if available")
    
    else:
        print("\nPromotional filter already covers all bulk senders.")
        print("Bulk-sender archiving would be redundant with current promotional archiving.")
    
    return domain_counter, sender_examples

if __name__ == "__main__":
    analyze_senders(30, 200)