#!/usr/bin/env python3
import subprocess
import json
import sys

def run_cmd(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    return result.stdout, result.stderr, result.returncode

# Search for Emergent emails
gog = "/home/agent/.linuxbrew/bin/gog"
account = "bayanimills@gmail.com"

stdout, stderr, rc = run_cmd([gog, "gmail", "search", "Emergent", "--max", "20", "--json", "--account", account])
if rc != 0:
    print(f"Error: {stderr}")
    sys.exit(1)

data = json.loads(stdout)
threads = data.get("threads", [])
print(f"Found {len(threads)} Emergent threads:")
for i, thread in enumerate(threads):
    thread_id = thread.get("id")
    subject = thread.get("subject", "")[:80]
    from_field = thread.get("from", "")
    labels = thread.get("labels", [])
    print(f"{i+1}. {subject}")
    print(f"   From: {from_field}")
    print(f"   Labels: {', '.join(labels)}")
    print()