#!/usr/bin/env python3
"""
Group Stripe PDF receipts by issuer using log file extraction.
"""
import os
import sys
import json
import re
import urllib.parse
import subprocess
from datetime import datetime

WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/stripe_pdfs_state.json")
LOG_FILE = "/tmp/stripe_pdf5.log"  # main log from latest run

# Nextcloud configuration
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"
NEXTCLOUD_FOLDER = "/_private/businesses/Bayani%20Enterprises/Receipts/"

def run_cmd(cmd, timeout=30):
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", "Command timed out", 124
    except Exception as e:
        return "", str(e), 1

def list_nextcloud_files():
    """List files in Nextcloud folder via WebDAV PROPFIND."""
    import xml.etree.ElementTree as ET
    url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}"
    if not url.endswith('/'):
        url += '/'
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "PROPFIND",
        "-H", "Depth: 1",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc != 0:
        print(f"[ERROR] Failed to list Nextcloud files: {stderr}")
        return []
    try:
        root = ET.fromstring(stdout)
        ns = {'d': 'DAV:'}
        files = []
        for response in root.findall('d:response', ns):
            href = response.find('d:href', ns).text
            # Decode percent encoding
            href = urllib.parse.unquote(href)
            # Extract filename after last slash
            parts = href.rstrip('/').split('/')
            filename = parts[-1] if parts else ''
            # Skip if empty or if it's a directory (filename contains dot? but directories have no dot)
            # We'll skip entries where href ends with '/' (already stripped)
            if filename and '.' in filename:  # simple heuristic for files
                files.append(filename)
            else:
                # Could be a subdirectory, ignore
                pass
        print(f"[DEBUG] Found {len(files)} files in Nextcloud folder.")
        # Deduplicate (just in case)
        files = list(set(files))
        return files
    except Exception as e:
        print(f"[ERROR] Failed to parse PROPFIND response: {e}")
        return []

def create_nextcloud_subfolder(subfolder):
    full_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{urllib.parse.quote(subfolder)}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        full_url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        print(f"[INFO] Created subfolder: {subfolder}")
        return True
    elif "405" in stderr:
        print(f"[INFO] Subfolder already exists: {subfolder}")
        return True
    else:
        print(f"[ERROR] Failed to create subfolder {subfolder}: {stderr}")
        return False

def move_nextcloud_file(src_filename, dest_subfolder, dry_run=True):
    src_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{urllib.parse.quote(src_filename)}"
    dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{urllib.parse.quote(dest_subfolder)}/{urllib.parse.quote(src_filename)}"
    if dry_run:
        print(f"[DRY-RUN] Would move {src_filename} -> {dest_subfolder}/")
        return True
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MOVE",
        "-H", f"Destination: {dest_url}",
        src_url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        print(f"[INFO] Moved {src_filename} to {dest_subfolder}/")
        return True
    else:
        print(f"[ERROR] Failed to move {src_filename}: {stderr}")
        return False

def upload_readme(content, dry_run=True):
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
        f.write(content)
        temp_path = f.name
    try:
        dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}README.md"
        if dry_run:
            print(f"[DRY-RUN] Would upload README.md to {NEXTCLOUD_FOLDER}")
            return True
        cmd = [
            "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
            "-T", temp_path,
            dest_url
        ]
        stdout, stderr, rc = run_cmd(cmd, timeout=30)
        if rc == 0:
            print(f"[INFO] Uploaded README.md to {NEXTCLOUD_FOLDER}")
            return True
        else:
            print(f"[ERROR] Failed to upload README.md: {stderr}")
            return False
    finally:
        os.unlink(temp_path)

def extract_issuer_from_subject(subject):
    if not subject:
        return "Unknown"
    match = re.search(r'from\s+([^#]+?)\s+#', subject, re.IGNORECASE)
    if match:
        issuer = match.group(1).strip()
        return issuer
    parts = subject.split('#')
    if len(parts) > 1:
        return parts[0].strip()
    return subject.strip()

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Group receipts by issuer using log")
    parser.add_argument("--dry-run", action="store_true", help="Dry run, no changes")
    args = parser.parse_args()
    dry_run = args.dry_run
    if dry_run:
        print("[INFO] Running in dry-run mode, no changes will be made.")
    
    # Load state
    with open(STATE_FILE) as f:
        state = json.load(f)
    print(f"[INFO] Loaded state with {len(state)} threads.")
    
    # Parse log for thread -> subject mapping
    thread_subject = {}
    if not os.path.exists(LOG_FILE):
        print(f"[ERROR] Log file not found: {LOG_FILE}")
        sys.exit(1)
    with open(LOG_FILE) as f:
        for line in f:
            # Pattern: "Processing thread: 19cbbf542d31ead5 - Your receipt from EMERGENT LABS INC #2599-4382..."
            match = re.search(r'Processing thread:\s+([a-f0-9]+)\s+-\s+(.+)', line)
            if match:
                tid = match.group(1)
                subject = match.group(2).strip()
                thread_subject[tid] = subject
                # Also extract issuer
                issuer = extract_issuer_from_subject(subject)
                print(f"[INFO] Thread {tid[:8]} -> issuer: {issuer}")
    
    # Build issuer groups
    issuer_groups = {}
    for tid, info in state.items():
        subject = thread_subject.get(tid)
        if not subject:
            # fallback: try to fetch from gog (optional)
            print(f"[WARNING] No subject for thread {tid}, skipping")
            continue
        issuer = extract_issuer_from_subject(subject)
        filenames = info.get('downloaded_pdfs', [])
        if issuer not in issuer_groups:
            issuer_groups[issuer] = []
        issuer_groups[issuer].extend(filenames)
    
    # Deduplicate
    for issuer, files in issuer_groups.items():
        issuer_groups[issuer] = sorted(set(files))
    
    print("\n[INFO] Issuer groups:")
    for issuer, files in issuer_groups.items():
        print(f"  {issuer}: {len(files)} files")
    
    # List current files in Nextcloud
    existing_files = list_nextcloud_files()
    print(f"[INFO] Found {len(existing_files)} files in Nextcloud folder.")
    
    # Verify all expected files exist
    all_expected = [f for files in issuer_groups.values() for f in files]
    missing = [f for f in all_expected if f not in existing_files]
    if missing:
        print(f"[WARNING] {len(missing)} expected files not found in Nextcloud:")
        for f in missing[:5]:
            print(f"  {f}")
        if len(missing) > 5:
            print(f"  ... and {len(missing)-5} more")
    else:
        print("[INFO] All expected files present in Nextcloud.")
    
    # Create subfolders and move files
    moved = []
    for issuer, files in issuer_groups.items():
        folder_name = re.sub(r'[^\w\-\.]', '_', issuer)
        if not folder_name:
            folder_name = "Unknown"
        if not create_nextcloud_subfolder(folder_name):
            continue
        for filename in files:
            if filename in existing_files:
                success = move_nextcloud_file(filename, folder_name, dry_run=dry_run)
                if success and not dry_run:
                    moved.append((filename, folder_name))
            else:
                print(f"[WARNING] File {filename} not found, skipping.")
    
    # Generate README
    readme_lines = [
        "# Receipts Folder Structure",
        "",
        "This folder contains Stripe PDF receipts downloaded from Gmail.",
        "Files are grouped by issuer (the merchant name from the email subject).",
        "",
        "## Summary",
        "",
        f"**Total files:** {len(all_expected)}",
        f"**Issuers:** {len(issuer_groups)}",
        f"**Last updated:** {datetime.now().isoformat()}",
        "",
        "## Issuer Groups",
        ""
    ]
    for issuer, files in sorted(issuer_groups.items()):
        folder_name = re.sub(r'[^\w\-\.]', '_', issuer)
        readme_lines.append(f"### {issuer}")
        readme_lines.append(f"**Folder:** `{folder_name}/`")
        readme_lines.append(f"**Count:** {len(files)}")
        readme_lines.append("")
        for f in sorted(files):
            readme_lines.append(f"- `{f}`")
        readme_lines.append("")
    readme_lines.append("## Notes")
    readme_lines.append("- Files were downloaded via Stripe's signed S3 URLs or Gmail attachments.")
    readme_lines.append("- Invoices and receipts are paired per transaction.")
    readme_lines.append("- Generated by OpenClaw automation.")
    
    readme_content = "\n".join(readme_lines)
    print("\n" + "="*60)
    print(readme_content)
    print("="*60 + "\n")
    
    if not dry_run:
        upload_readme(readme_content, dry_run=False)
    else:
        upload_readme(readme_content, dry_run=True)
    
    print(f"[INFO] {'Dry run completed.' if dry_run else 'Processing complete.'}")
    if moved:
        print(f"[INFO] Moved {len(moved)} files to issuer subfolders.")

if __name__ == "__main__":
    main()