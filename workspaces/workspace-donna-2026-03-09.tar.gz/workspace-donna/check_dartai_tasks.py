#!/usr/bin/env python3
import os
import sys
import json
import requests

# Add the dartai scripts directory to path
dartai_dir = "/home/agent/.openclaw/workspace/skills/dartai"
sys.path.insert(0, os.path.join(dartai_dir, 'scripts'))

from dartai_client import get

# Get all tasks
response = get('tasks', params={'limit': 100})
if response.status_code == 200:
    tasks = response.json()
    print(f'Total tasks: {len(tasks)}')
    
    # Count by status
    status_counts = {}
    for task in tasks:
        status = task.get('status', 'Unknown')
        status_counts[status] = status_counts.get(status, 0) + 1
    
    print('\nTask status breakdown:')
    for status, count in status_counts.items():
        print(f'  {status}: {count}')
    
    # Show oldest tasks
    print('\nOldest tasks (by created_at):')
    sorted_tasks = sorted(tasks, key=lambda x: x.get('created_at', ''))
    for i, task in enumerate(sorted_tasks[:5]):
        title = task.get('title', 'No title')
        status = task.get('status', 'Unknown')
        created = task.get('created_at', 'Unknown')
        print(f'  {i+1}. {title[:50]}... - Status: {status} - Created: {created}')
        
else:
    print(f'Error: {response.status_code} - {response.text}')