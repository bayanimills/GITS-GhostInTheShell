#!/usr/bin/env python3
"""
Calendar reminder script for executive operator.
Fetches Google Calendar events via gog CLI and sends reminders for events starting soon.
Run via cron every 15 minutes.
Sends reminders directly via OpenClaw Telegram message (no agent forwarding).
"""

import os
import sys
import json
import subprocess
from datetime import datetime, timedelta, timezone
import logging

logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
GOG_ACCOUNT = "bayanimills@gmail.com"
REMINDER_OFFSETS = [60, 15]  # Remind 60 minutes and 15 minutes before event (minutes)
WINDOW_TOLERANCE = 5  # Remind if within offset ± tolerance (minutes)
STATE_FILE = os.path.join(os.path.dirname(__file__), ".calendar_reminders_state.json")
# Telegram recipient (same as user chat ID)
TELEGRAM_TO = "548072941"

def send_telegram_message(text):
    """Send a message via OpenClaw Telegram plugin."""
    try:
        cmd = ["openclaw", "message", "send", "--channel", "telegram", "--target", TELEGRAM_TO, "--message", text]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            logger.error(f"Failed to send Telegram message: {result.stderr}")
            return False
        logger.info("Telegram message sent successfully")
        return True
    except Exception as e:
        logger.error(f"Exception sending Telegram message: {e}")
        return False

def fetch_upcoming_events(account, hours_ahead=24):
    """Fetch events from now to hours_ahead."""
    try:
        # Use --from now --days 1 to get next 24 hours
        cmd = ["gog", "calendar", "list", "--account", account, "--json", "--from", "now", "--days", "1"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            logger.warning(f"gog calendar failed: {result.stderr}")
            return []
        data = json.loads(result.stdout)
        events = data.get("events", [])
        # Filter confirmed events with dateTime start
        filtered = []
        for event in events:
            if event.get("status") != "confirmed":
                continue
            start = event.get("start", {})
            if "dateTime" not in start:
                continue
            filtered.append(event)
        # Sort by start time
        filtered.sort(key=lambda e: e["start"]["dateTime"])
        return filtered
    except Exception as e:
        logger.warning(f"Failed to fetch calendar events: {e}")
        return []

def parse_iso_datetime(dt_str):
    """Parse ISO datetime string with timezone to aware datetime."""
    # Remove trailing Z and replace with +00:00 if needed
    if dt_str.endswith('Z'):
        dt_str = dt_str[:-1] + '+00:00'
    # Python's fromisoformat handles offset like +11:00
    try:
        return datetime.fromisoformat(dt_str)
    except ValueError:
        # Fallback to naive parsing (strip timezone)
        dt_str = dt_str[:19]
        return datetime.fromisoformat(dt_str).replace(tzinfo=timezone.utc)

def load_state():
    """Load reminded event IDs with offsets sent."""
    if not os.path.exists(STATE_FILE):
        return {}
    try:
        with open(STATE_FILE, 'r') as f:
            raw = json.load(f)
        # Migrate old format (event_id -> timestamp) to new format
        migrated = {}
        for event_id, value in raw.items():
            if isinstance(value, str):
                # Old format: timestamp string
                migrated[event_id] = {
                    "last_reminded": value,
                    "offsets_sent": []
                }
            else:
                # New format: dict with offsets_sent
                migrated[event_id] = value
        return migrated
    except Exception as e:
        logger.warning(f"Failed to load state: {e}")
        return {}

def save_state(state):
    """Save state to file."""
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        logger.warning(f"Failed to save state: {e}")

def should_remind(event, state):
    """Determine if we should send a reminder for this event.
    Returns offset (minutes) if reminder should be sent, else None."""
    event_id = event.get("id")
    start_str = event["start"]["dateTime"]
    start_dt = parse_iso_datetime(start_str)
    now = datetime.now(start_dt.tzinfo if start_dt.tzinfo else timezone.utc)
    
    # Time until event
    delta = start_dt - now
    delta_minutes = delta.total_seconds() / 60
    
    # If event already started or more than max offset + tolerance, skip
    max_offset = max(REMINDER_OFFSETS) + WINDOW_TOLERANCE
    if delta_minutes < 0 or delta_minutes > max_offset:
        return None
    
    # Get state for this event
    event_state = state.get(event_id, {})
    offsets_sent = event_state.get("offsets_sent", [])
    
    for offset in REMINDER_OFFSETS:
        if offset in offsets_sent:
            continue  # already reminded for this offset
        # Check if delta_minutes within tolerance of offset
        if abs(delta_minutes - offset) <= WINDOW_TOLERANCE:
            return offset
    
    return None

def format_reminder(event, offset=None):
    """Format a reminder message for an event.
    offset: minutes before event (e.g., 60 for 1‑hour reminder)."""
    summary = event.get("summary", "No title")
    start = parse_iso_datetime(event["start"]["dateTime"])
    end = parse_iso_datetime(event["end"]["dateTime"])
    location = event.get("location", "")
    
    time_str = f"{start.strftime('%H:%M')}–{end.strftime('%H:%M')}"
    date_str = start.strftime('%a %d %b')
    
    # Choose prefix based on offset
    if offset == 60:
        prefix = "📅 **1‑hour reminder:**"
    elif offset == 15:
        prefix = "📅 **15‑minute reminder:**"
    elif offset is not None:
        prefix = f"📅 **{offset}‑minute reminder:**"
    else:
        prefix = "📅 **Reminder:**"
    
    lines = []
    lines.append(f"{prefix} {summary}")
    lines.append(f"   ⏰ {date_str} {time_str}")
    if location:
        lines.append(f"   📍 {location}")
    # Add description? maybe not.
    return "\n".join(lines)

def main():
    state = load_state()
    events = fetch_upcoming_events(GOG_ACCOUNT)
    
    reminders = []  # list of (event, offset)
    for event in events:
        offset = should_remind(event, state)
        if offset is not None:
            reminders.append((event, offset))
            # Update state for this event
            event_id = event["id"]
            if event_id not in state:
                state[event_id] = {"offsets_sent": [], "last_reminded": None}
            event_state = state[event_id]
            if offset not in event_state["offsets_sent"]:
                event_state["offsets_sent"].append(offset)
            event_state["last_reminded"] = datetime.now().isoformat()
    
    if reminders:
        # Combine all reminders into one message
        message_lines = []
        for event, offset in reminders:
            message_lines.append(format_reminder(event, offset))
            message_lines.append("")  # blank line between reminders
        # Remove trailing blank line
        if message_lines and message_lines[-1] == "":
            message_lines.pop()
        message = "\n".join(message_lines)
        
        # Send via Telegram
        success = send_telegram_message(message)
        if success:
            # Save state only if message sent successfully
            save_state(state)
            sys.exit(0)
        else:
            # If sending fails, fallback to stdout (agent will forward)
            # This ensures reminders are not lost if openclaw CLI fails
            print(message)
            save_state(state)
            sys.exit(0)
    else:
        # No reminders needed
        # Do nothing, no output
        logger.info("No upcoming events requiring reminder.")
        sys.exit(0)

if __name__ == "__main__":
    main()