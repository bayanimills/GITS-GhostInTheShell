#!/usr/bin/env python3
"""
Simple test version of Gmail monitor
"""
import subprocess
import json
import datetime

GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
ACCOUNT = "bayanimills@gmail.com"

def run_gog(args):
    """Run gog command and return parsed JSON if available."""
    cmd = [GOG_BIN] + args + ["--account", ACCOUNT, "--json"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        return json.loads(result.stdout)
    except subprocess.TimeoutExpired:
        print(f"gog timeout: command took too long: {' '.join(cmd)}")
        return None
    except subprocess.CalledProcessError as e:
        print(f"gog error: {e.stderr}")
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return None

def main():
    print(f"Gmail digest (test) — {datetime.datetime.now().isoformat()}")
    
    # Simple search for inbox messages
    result = run_gog(["gmail", "search", "in:inbox", "--limit", "20"])
    
    if result and "threads" in result:
        threads = result["threads"]
        print(f"  Found {len(threads)} threads in inbox")
        
        # Simple categorization
        categories = {
            "Finance": 0,
            "Calendar": 0,
            "Medical": 0,
            "Family": 0,
            "Newsletters": 0,
            "Social": 0,
            "Spam": 0
        }
        
        for thread in threads:
            subject = thread.get("subject", "").lower()
            from_addr = thread.get("from", "").lower()
            labels = thread.get("labels", [])
            
            # Simple keyword matching
            if any(word in subject or word in from_addr for word in ["invoice", "bill", "payment", "bank", "ledn", "crypto"]):
                categories["Finance"] += 1
            elif any(word in subject or word in from_addr for word in ["calendar", "meeting", "appointment"]):
                categories["Calendar"] += 1
            elif any(word in subject or word in from_addr for word in ["medical", "doctor", "health", "hospital"]):
                categories["Medical"] += 1
            elif any(word in subject or word in from_addr for word in ["family", "mom", "dad", "sister", "brother"]):
                categories["Family"] += 1
            elif any(word in subject or word in from_addr for word in ["newsletter", "update", "digest"]):
                categories["Newsletters"] += 1
            elif any(word in subject or word in from_addr for word in ["facebook", "twitter", "instagram", "social"]):
                categories["Social"] += 1
            elif any(word in subject or word in from_addr for word in ["spam", "junk", "phishing"]):
                categories["Spam"] += 1
        
        print(f"Scanned: {len(threads)} messages")
        for cat, count in categories.items():
            if count > 0:
                print(f"- {cat}: {count}")
    else:
        print("  No results or error occurred")

if __name__ == "__main__":
    main()