#!/usr/bin/env python3
"""
Seasonal email cleanup: archive emails older than 1 year (365 days).
Dry-run mode lists emails without archiving.
"""
import os
import sys
import json
import datetime
import subprocess
from pathlib import Path

# Configuration
ACCOUNT = "bayanimills@gmail.com"
GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
DRY_RUN = True  # default dry-run for safety
MAX_EMAILS = 500  # limit scan to 500 threads

def run_gog(args, account=ACCOUNT):
    """Run gog command and return parsed JSON if available."""
    cmd = [GOG_BIN] + args + ["--account", account]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        print(f"gog timeout: command took too long: {' '.join(cmd)}", file=sys.stderr)
        return None
    except subprocess.CalledProcessError as e:
        print(f"gog error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

def fetch_old_threads(days_old=365, max_results=MAX_EMAILS):
    """Fetch threads older than specified days from INBOX."""
    # Gmail search query: older_than with 'd' suffix
    query = f"in:inbox older_than:{days_old}d"
    data = run_gog(["gmail", "search", query, "--max", str(max_results), "--json"])
    if not data:
        return []
    return data.get("threads", [])

def should_skip_label(thread):
    """Check if thread has labels that should be preserved (e.g., important)."""
    labels = thread.get("labels", [])
    skip_labels = {"IMPORTANT", "STARRED", "UNREAD", "DRAFT", "SENT"}
    for label in labels:
        if label.upper() in skip_labels:
            return True
    return False

def archive_thread(thread_id):
    """Archive thread (remove INBOX label)."""
    result = run_gog(["gmail", "thread", "modify", thread_id, "--remove", "INBOX"])
    return result is not None

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Archive emails older than 1 year.")
    parser.add_argument("--days", type=int, default=365, help="Days threshold (default: 365)")
    parser.add_argument("--apply", action="store_true", help="Actually archive emails (default dry-run)")
    parser.add_argument("--limit", type=int, default=MAX_EMAILS, help="Max threads to process")
    args = parser.parse_args()
    
    dry_run = not args.apply
    days_old = args.days
    limit = args.limit
    
    print(f"Seasonal email cleanup — {datetime.datetime.now().isoformat()}")
    print(f"  Mode: {'DRY-RUN (list only)' if dry_run else 'APPLY (archiving)'}")
    print(f"  Threshold: older than {days_old} days")
    print(f"  Scanning up to {limit} threads...")
    
    threads = fetch_old_threads(days_old, limit)
    if not threads:
        print("  No old threads found.")
        return
    
    print(f"  Found {len(threads)} thread(s) older than {days_old} days.")
    
    skipped = 0
    to_archive = []
    
    for thread in threads:
        thread_id = thread["id"]
        subject = thread.get("subject", "(no subject)")
        date = thread.get("date", "")
        labels = thread.get("labels", [])
        
        if should_skip_label(thread):
            skipped += 1
            continue
        
        to_archive.append((thread_id, subject, date))
    
    print(f"  Skipping {skipped} thread(s) with important labels.")
    print(f"  {len(to_archive)} thread(s) eligible for archiving.")
    
    if dry_run:
        for idx, (thread_id, subject, date) in enumerate(to_archive[:10]):  # show first 10
            print(f"    {idx+1}. [{date}] {subject[:80]}{'…' if len(subject) > 80 else ''}")
        if len(to_archive) > 10:
            print(f"    ... and {len(to_archive) - 10} more.")
    else:
        print("  Archiving...")
        success = 0
        for thread_id, subject, date in to_archive:
            if archive_thread(thread_id):
                success += 1
                print(f"    Archived: {subject[:60]}{'…' if len(subject) > 60 else ''}")
            else:
                print(f"    Failed: {subject[:60]}")
        print(f"  Successfully archived {success} of {len(to_archive)} threads.")
    
    # Summary
    print("\n  Summary:")
    print(f"    Total old threads: {len(threads)}")
    print(f"    Skipped (important): {skipped}")
    print(f"    Eligible: {len(to_archive)}")
    if dry_run:
        print(f"    Dry-run: no changes made.")
        print(f"    To apply, run with --apply flag.")
    else:
        print(f"    Archived: {success}")

if __name__ == "__main__":
    main()