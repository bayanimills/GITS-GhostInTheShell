#!/bin/bash
# Wrapper for AWS completion report that ensures openclaw is in PATH
export PATH="/home/agent/.local/bin:$PATH"
export OPENCLAW_WORKSPACE="/home/agent/.openclaw/workspace-donna"
cd "$OPENCLAW_WORKSPACE"
python3 /home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/aws-completion-report.py
