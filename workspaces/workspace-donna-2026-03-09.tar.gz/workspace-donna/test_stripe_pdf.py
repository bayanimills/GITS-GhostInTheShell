#!/usr/bin/env python3
"""
Test Stripe PDF extraction and download for a single thread.
"""
import os
import sys
import json
import re
import base64
import subprocess
import tempfile

WORKSPACE = "/home/agent/.openclaw/workspace-donna"
ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_cmd(cmd, timeout=60):
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return "", str(e), 1

def get_thread_details(thread_id):
    cmd = [GOG, "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        print(f"Failed: {stderr}")
        return None
    try:
        return json.loads(stdout)
    except Exception as e:
        print(f"Parse error: {e}")
        return None

def extract_pdf_links_from_message(message):
    parts = message.get("parts", [])
    links = set()
    for part in parts:
        mime_type = part.get("mimeType", "")
        body_data = part.get("body", {}).get("data", "")
        if not body_data:
            continue
        try:
            body = base64.b64decode(body_data).decode("utf-8")
        except Exception:
            continue
        # Look for invoice and receipt PDF links
        invoice_pattern = r'https://pay\.stripe\.com/invoice/[^\s"\')<>]+?pdf'
        receipt_pattern = r'https://dashboard\.stripe\.com/receipts/invoices/[^\s"\')<>]+?pdf'
        found = re.findall(invoice_pattern, body, re.IGNORECASE)
        links.update(found)
        found = re.findall(receipt_pattern, body, re.IGNORECASE)
        links.update(found)
    return list(links)

def download_pdf(url, dest_path):
    cmd = ["curl", "-L", "-s", "-H", "User-Agent: Mozilla/5.0", url, "-o", dest_path]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    if rc != 0:
        print(f"Download failed: {stderr}")
        return False
    # Verify PDF
    if os.path.getsize(dest_path) < 100:
        print("File too small")
        return False
    with open(dest_path, "rb") as f:
        header = f.read(4)
        if header != b'%PDF':
            print("Not a PDF")
            return False
    print(f"Downloaded {os.path.getsize(dest_path)} bytes")
    return True

def main():
    # Known thread with Stripe receipt
    thread_id = "19cbbf542d31ead5"
    print(f"Fetching thread {thread_id}")
    details = get_thread_details(thread_id)
    if not details:
        return
    messages = details.get("thread", {}).get("messages", [])
    if not messages:
        print("No messages")
        return
    for i, msg in enumerate(messages):
        print(f"Message {i}:")
        links = extract_pdf_links_from_message(msg)
        print(f"Found {len(links)} links")
        for link in links:
            print(f"  {link[:100]}...")
            # Download test
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
                tmp_path = tmp.name
                if download_pdf(link, tmp_path):
                    print(f"  Success: {tmp_path}")
                    # Keep file for inspection
                    print(f"  File kept at {tmp_path}")
                else:
                    print("  Failed")
                # Cleanup
                os.unlink(tmp_path)

if __name__ == "__main__":
    main()