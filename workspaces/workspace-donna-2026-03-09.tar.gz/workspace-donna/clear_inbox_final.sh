#!/bin/bash
ACCOUNT="bayanimills@gmail.com"
MAX_CYCLES=20
FETCH=100
BATCH=10

echo "Starting inbox clearing (max $MAX_CYCLES cycles)..."
total=0
for cycle in $(seq 1 $MAX_CYCLES); do
    echo "Cycle $cycle: fetching up to $FETCH threads..."
    ids=$(timeout 60 gog gmail search "in:inbox" --max $FETCH --json --account "$ACCOUNT" | jq -r '.threads[].id' | tr '\n' ' ')
    if [ -z "$ids" ]; then
        echo "No threads found. Inbox empty."
        break
    fi
    count=$(echo "$ids" | wc -w)
    echo "  Processing $count threads in batches of $BATCH..."
    echo "$ids" | tr ' ' '\n' | xargs -n $BATCH timeout 60 gog gmail labels modify --remove INBOX --account "$ACCOUNT"
    if [ $? -ne 0 ]; then
        echo "  Error in batch, continuing..."
    fi
    total=$((total + count))
    echo "  Archived $count threads (total: $total)."
    sleep 1
done
echo "Done. Total archived: $total threads."
# Final check
remaining=$(timeout 30 gog gmail search "in:inbox" --max 20 --json --account "$ACCOUNT" | jq -r '.threads | length')
echo "Remaining in inbox: $remaining threads."