#!/usr/bin/env python3
"""
Download Stripe PDF receipts from Gmail emails.
Extracts invoice and receipt PDF links from Stripe emails (label Finance/Bayani Enterprises),
downloads PDFs via signed S3 URLs, and uploads to Nextcloud.
"""
import os
import sys
import json
import re
import base64
import tempfile
import subprocess
from datetime import datetime
from urllib.parse import urlparse, parse_qs, unquote

# Configuration
WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/stripe_pdfs_state.json")
LOG_FILE = os.path.join(WORKSPACE, "memory/stripe_pdfs.log")
ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

# Nextcloud configuration (same as save_emergent_receipts.py)
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"
NEXTCLOUD_FOLDER = "/_private/businesses/Bayani%20Enterprises/Receipts/"

# Regex patterns for Stripe PDF links
INVOICE_PDF_PATTERN = r'https://pay\.stripe\.com/invoice/[^\s"\')<>]+?pdf(?:\?[^\s"\')<>]*)?'
RECEIPT_PDF_PATTERN = r'https://dashboard\.stripe\.com/receipts/invoices/[^\s"\')<>]+?pdf(?:\?[^\s"\')<>]*)?'
# Also match short URLs (stripe.com/invoice/...)
STRIPE_PDF_PATTERN = r'https://(?:pay|dashboard)\.stripe\.com/(?:invoice|receipts/invoices)/[^\s"\')<>]+?pdf(?:\?[^\s"\')<>]*)?'

def run_cmd(cmd, timeout=60):
    """Run shell command and return stdout, stderr, returncode."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124
    except Exception as e:
        return "", str(e), 1

def log_message(message, level="INFO"):
    """Log message to log file and print to stdout."""
    timestamp = datetime.now().isoformat()
    log_entry = f"{timestamp} [{level}] {message}"
    print(f"[{level}] {message}")
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(log_entry + "\n")

def load_state():
    """Load state of processed PDFs."""
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            log_message(f"Failed to load state: {e}", "WARNING")
            return {}
    return {}

def save_state(state):
    """Save state."""
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)
    log_message(f"State saved with {len(state)} entries")

def search_stripe_emails(max_results=200):
    """Search for Stripe receipt emails."""
    query = "label:Finance/Bayani Enterprises from:stripe.com"
    log_message(f"Searching: {query}")
    cmd = [GOG, "gmail", "search", query, "--max", str(max_results), "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    if rc != 0:
        log_message(f"Search failed: {stderr}", "ERROR")
        return []
    try:
        data = json.loads(stdout)
        threads = data.get("threads", [])
        log_message(f"Found {len(threads)} threads")
        return threads
    except Exception as e:
        log_message(f"Failed to parse search results: {e}", "ERROR")
        return []

def get_thread_details(thread_id):
    """Get full thread details."""
    cmd = [GOG, "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to get thread {thread_id}: {stderr}", "ERROR")
        return None
    try:
        return json.loads(stdout)
    except Exception as e:
        log_message(f"Failed to parse thread details: {e}", "ERROR")
        return None

def extract_pdf_links_from_message(message):
    """Recursively extract Stripe PDF links from email message parts."""
    links = set()
    
    def search_parts(parts):
        for part in parts:
            mime = part.get("mimeType", "")
            if mime in ["text/plain", "text/html"]:
                body_data = part.get("body", {}).get("data")
                if body_data:
                    try:
                        body = base64.b64decode(body_data).decode('utf-8', errors='ignore')
                        # Search for Stripe PDF links
                        for pattern in [INVOICE_PDF_PATTERN, RECEIPT_PDF_PATTERN]:
                            found = re.findall(pattern, body, re.IGNORECASE)
                            links.update(found)
                    except Exception:
                        pass
            if "parts" in part:
                search_parts(part["parts"])
    
    payload = message.get("payload", {})
    parts = payload.get("parts", [])
    search_parts(parts)
    return list(links)

def extract_receipt_info(message):
    """Extract invoice and receipt numbers from email message."""
    info = {}
    def search_parts(parts):
        for part in parts:
            mime = part.get("mimeType", "")
            if mime in ["text/plain", "text/html"]:
                body_data = part.get("body", {}).get("data")
                if body_data:
                    try:
                        body = base64.b64decode(body_data).decode('utf-8', errors='ignore')
                        # Invoice number pattern: "Invoice number TNBFQJ1W-0035"
                        invoice_match = re.search(r'Invoice number\s+([A-Z0-9\-]+)', body)
                        if invoice_match:
                            info['invoice_number'] = invoice_match.group(1)
                        # Receipt number pattern: "Receipt number 2599-4382"
                        receipt_match = re.search(r'Receipt number\s+([0-9\-]+)', body)
                        if receipt_match:
                            info['receipt_number'] = receipt_match.group(1)
                    except:
                        pass
            if "parts" in part:
                search_parts(part["parts"])
    
    payload = message.get("payload", {})
    parts = payload.get("parts", [])
    search_parts(parts)
    return info

def extract_pdf_attachments_from_message(message):
    """Extract PDF attachments from email message."""
    attachments = []
    def walk(part):
        mime = part.get("mimeType", "")
        filename = part.get("filename", "")
        body = part.get("body", {})
        attachment_id = body.get("attachmentId")
        if attachment_id and mime == "application/pdf":
            attachments.append({
                "attachmentId": attachment_id,
                "filename": filename,
                "mimeType": mime
            })
        if "parts" in part:
            for sub in part["parts"]:
                walk(sub)
    payload = message.get("payload", {})
    walk(payload)
    return attachments

def download_attachment(message_id, attachment_id, dest_path):
    """Download attachment via gog."""
    cmd = [GOG, "gmail", "attachment", message_id, attachment_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    if rc != 0:
        log_message(f"Failed to download attachment {attachment_id}: {stderr}", "ERROR")
        return False
    try:
        data = json.loads(stdout)
        # The attachment is saved as a file; path is in 'path' field
        src_path = data.get("path")
        if not src_path or not os.path.exists(src_path):
            log_message(f"No valid path for attachment {attachment_id}", "ERROR")
            return False
        # Copy the file
        import shutil
        shutil.copyfile(src_path, dest_path)
        log_message(f"Downloaded attachment {attachment_id} ({os.path.getsize(dest_path)} bytes)")
        return True
    except Exception as e:
        log_message(f"Error processing attachment {attachment_id}: {e}", "ERROR")
        return False

def extract_filename_from_url(url):
    """Extract filename from Stripe S3 redirect URL."""
    # First try to get filename from location header by making HEAD request
    # We'll parse the original URL query param 'filename' or from redirect
    # For now, generate generic name based on URL hash
    parsed = urlparse(url)
    # Extract from path
    path = parsed.path
    # If path ends with .pdf, use that
    if path.endswith('.pdf'):
        return os.path.basename(path)
    # Otherwise generate from query params
    query = parse_qs(parsed.query)
    if 'filename' in query:
        filename = query['filename'][0]
        return filename.strip('"')
    if 'response-content-disposition' in query:
        disp = query['response-content-disposition'][0]
        # attachment; filename="Invoice-TNBFQJ1W-0035.pdf"; filename*=UTF-8''Invoice-TNBFQJ1W-0035.pdf
        match = re.search(r'filename\*?=["\']?(?:UTF-8\'\')?([^"\';]+)', disp)
        if match:
            return unquote(match.group(1))
        match = re.search(r'filename=["\']([^"\']+)["\']', disp)
        if match:
            return match.group(1)
    # Fallback: use invoice/receipt id from URL
    if '/invoice/' in url:
        match = re.search(r'/invoice/[^/]+/([^/]+)/pdf', url)
        if match:
            return f"Invoice-{match.group(1)}.pdf"
    elif '/receipts/' in url:
        match = re.search(r'/receipts/invoices/([^/]+)/pdf', url)
        if match:
            return f"Receipt-{match.group(1)}.pdf"
    # Final fallback
    return f"stripe_{hash(url) & 0xffffffff}.pdf"

def download_pdf(url, dest_path):
    """Download PDF from Stripe signed URL."""
    # Use curl with follow redirects
    cmd = ["curl", "-L", "-s", "-H", "User-Agent: Mozilla/5.0", url, "-o", dest_path]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    if rc != 0:
        log_message(f"Failed to download {url}: {stderr}", "ERROR")
        return False
    # Verify PDF magic number
    if os.path.getsize(dest_path) < 100:
        log_message(f"Downloaded file too small: {dest_path}", "WARNING")
        return False
    with open(dest_path, "rb") as f:
        header = f.read(4)
        if header != b'%PDF':
            log_message(f"Downloaded file not a PDF: {dest_path}", "ERROR")
            return False
    log_message(f"Downloaded PDF ({os.path.getsize(dest_path)} bytes) from {url[:100]}...")
    return True

def upload_to_nextcloud(filepath, filename):
    """Upload file to Nextcloud."""
    import urllib.parse
    encoded_filename = urllib.parse.quote(filename)
    dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{encoded_filename}"
    
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-T", filepath,
        dest_url
    ]
    
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to upload {filename}: {stderr}", "ERROR")
        return False
    
    log_message(f"Uploaded {filename} to {NEXTCLOUD_FOLDER}")
    return True

def ensure_nextcloud_folder():
    """Create Nextcloud folder if it doesn't exist."""
    url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        log_message(f"Created folder: {NEXTCLOUD_FOLDER}")
        return True
    elif "405" in stderr:  # Already exists
        log_message(f"Folder already exists: {NEXTCLOUD_FOLDER}")
        return True
    else:
        log_message(f"Failed to create folder {NEXTCLOUD_FOLDER}: {stderr}", "WARNING")
        return False

def process_thread(thread, state):
    """Process a single thread, extract PDF links, download and upload."""
    thread_id = thread.get("id")
    subject = thread.get("subject", "")
    log_message(f"Processing thread: {thread_id} - {subject[:80]}...")
    
    # Skip if already processed (all PDFs downloaded)
    if state.get(thread_id, {}).get("pdfs_processed"):
        log_message(f"Thread {thread_id} already processed, skipping")
        return {"status": "already_processed"}
    
    # Get thread details
    details = get_thread_details(thread_id)
    if not details:
        return {"status": "failed"}
    
    messages = details.get("thread", {}).get("messages", [])
    if not messages:
        log_message(f"No messages in thread {thread_id}", "WARNING")
        return {"status": "no_messages"}
    
    # Process each message (usually one)
    downloaded_pdfs = []
    for msg in messages:
        links = extract_pdf_links_from_message(msg)
        attachments = extract_pdf_attachments_from_message(msg)
        if not links and not attachments:
            log_message(f"No PDF links or attachments found in thread {thread_id}", "INFO")
            continue
        
        # Extract invoice and receipt numbers from email body (for links)
        info = extract_receipt_info(msg)
        log_message(f"Found {len(links)} PDF links, {len(attachments)} attachments, invoice: {info.get('invoice_number')}, receipt: {info.get('receipt_number')}")
        for link in links:
            # Check if this specific link already processed
            link_hash = hash(link) & 0xffffffff
            if state.get(thread_id, {}).get("links", {}).get(str(link_hash)):
                log_message(f"Link already processed: {link[:80]}...")
                continue
            
            # Download PDF
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
                tmp_path = tmp.name
                if not download_pdf(link, tmp_path):
                    log_message(f"Failed to download PDF: {link[:80]}...", "ERROR")
                    continue
                
                # Determine filename based on link type and extracted numbers
                if '/invoice/' in link:
                    number = info.get('invoice_number')
                    prefix = 'Invoice'
                elif '/receipts/' in link:
                    number = info.get('receipt_number')
                    prefix = 'Receipt'
                else:
                    number = None
                    prefix = 'Stripe'
                
                if number:
                    filename = f"{prefix}-{number}.pdf"
                else:
                    filename = extract_filename_from_url(link)
                    # Ensure .pdf extension
                    if not filename.lower().endswith('.pdf'):
                        filename += '.pdf'
                
                # Upload to Nextcloud
                if upload_to_nextcloud(tmp_path, filename):
                    downloaded_pdfs.append(filename)
                    # Update state for this link
                    if thread_id not in state:
                        state[thread_id] = {"links": {}, "pdfs_processed": False}
                    state[thread_id]["links"][str(link_hash)] = {
                        "url": link,
                        "filename": filename,
                        "downloaded_at": datetime.now().isoformat()
                    }
                else:
                    log_message(f"Failed to upload PDF: {filename}", "ERROR")
            
            # Cleanup temp file
            os.unlink(tmp_path)
        
        # Process PDF attachments
        for att in attachments:
            attachment_id = att["attachmentId"]
            filename = att["filename"]
            # Check if already processed
            if state.get(thread_id, {}).get("attachments", {}).get(attachment_id):
                log_message(f"Attachment already processed: {filename}")
                continue
            # Download attachment
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
                tmp_path = tmp.name
                if not download_attachment(msg['id'], attachment_id, tmp_path):
                    log_message(f"Failed to download attachment: {filename}", "ERROR")
                    continue
                # Upload to Nextcloud
                if upload_to_nextcloud(tmp_path, filename):
                    downloaded_pdfs.append(filename)
                    # Update state
                    if thread_id not in state:
                        state[thread_id] = {"links": {}, "attachments": {}, "pdfs_processed": False}
                    state[thread_id].setdefault("attachments", {})[attachment_id] = {
                        "filename": filename,
                        "downloaded_at": datetime.now().isoformat()
                    }
                else:
                    log_message(f"Failed to upload attachment: {filename}", "ERROR")
                os.unlink(tmp_path)
    
    # Mark thread as processed if we downloaded at least one PDF
    if downloaded_pdfs:
        state.setdefault(thread_id, {})["pdfs_processed"] = True
        state[thread_id]["processed_at"] = datetime.now().isoformat()
        state[thread_id]["downloaded_pdfs"] = downloaded_pdfs
        log_message(f"Downloaded {len(downloaded_pdfs)} PDFs for thread {thread_id}")
        return {"status": "success", "downloaded": downloaded_pdfs}
    else:
        return {"status": "no_pdfs"}

def main():
    """Main entry point."""
    log_message("Starting Stripe PDF downloader")
    
    # Ensure Nextcloud folder
    if not ensure_nextcloud_folder():
        log_message("Cannot ensure Nextcloud folder, aborting", "ERROR")
        return 1
    
    # Load state
    state = load_state()
    log_message(f"Loaded state with {len(state)} processed threads")
    
    # Search for Stripe emails
    threads = search_stripe_emails(max_results=50)
    if not threads:
        log_message("No Stripe emails found", "INFO")
        return 0
    
    # Process each thread
    processed = 0
    for thread in threads:
        result = process_thread(thread, state)
        if result.get("status") == "success":
            processed += 1
        # Save state after each thread to persist progress
        save_state(state)
    
    log_message(f"Processed {processed} threads, total threads: {len(threads)}")
    return 0

if __name__ == "__main__":
    sys.exit(main())