#!/usr/bin/env python3
"""
Check dependencies for skills.
"""
import subprocess
import os
import re
from typing import Dict, List, Set

def binary_exists(binary_name: str) -> bool:
    """Check if a binary exists in PATH."""
    try:
        result = subprocess.run(['which', binary_name], 
                              capture_output=True, text=True, timeout=2)
        return result.returncode == 0
    except:
        return False

def check_binaries(binaries: List[str]) -> Dict[str, bool]:
    """Check which binaries exist."""
    return {bin: binary_exists(bin) for bin in binaries}

def parse_package_spec(package: str) -> tuple:
    """
    Parse package spec like 'brew:gh', 'apt:gh', 'npm:something'.
    Returns (manager, package_name).
    """
    if ':' not in package:
        return ('unknown', package)
    manager, name = package.split(':', 1)
    return (manager.strip(), name.strip())

def check_package_installed(package_spec: str) -> bool:
    """Check if a package is installed (brew, apt, npm)."""
    manager, name = parse_package_spec(package_spec)
    if manager == 'brew':
        try:
            result = subprocess.run(['brew', 'list', name], 
                                  capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    elif manager == 'apt':
        try:
            # dpkg -l package
            result = subprocess.run(['dpkg', '-l', name], 
                                  capture_output=True, text=True, timeout=5)
            # dpkg returns 0 if installed
            return result.returncode == 0
        except:
            return False
    elif manager == 'npm':
        try:
            result = subprocess.run(['npm', 'list', '-g', name], 
                                  capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    else:
        # Unknown package manager, assume installed
        return True

def check_dependencies(skill_deps: dict) -> Dict[str, Dict[str, bool]]:
    """
    Check all dependencies for a skill.
    Returns dict with 'bins', 'packages', 'credentials', 'external' status.
    """
    result = {
        'bins': {},
        'packages': {},
        'credentials': {},  # not checked
        'external': {}      # not checked
    }
    
    # Check binaries
    bins = skill_deps.get('bins', [])
    for bin_name in bins:
        result['bins'][bin_name] = binary_exists(bin_name)
    
    # Check packages
    packages = skill_deps.get('packages', [])
    for pkg in packages:
        result['packages'][pkg] = check_package_installed(pkg)
    
    # Credentials and external dependencies not checked automatically
    creds = skill_deps.get('credentials', [])
    for cred in creds:
        result['credentials'][cred] = False  # assume not available
    
    external = skill_deps.get('external', [])
    for ext in external:
        result['external'][ext] = False  # assume not available
    
    return result

def availability_score(dependency_status: Dict[str, Dict[str, bool]]) -> float:
    """
    Calculate availability score (0.0 to 1.0).
    Weight: binaries 70%, packages 30%.
    Missing credentials/external reduce score by 0.1 each.
    """
    total_weight = 0
    score = 0
    
    # Binaries weight 70%
    bins = dependency_status.get('bins', {})
    if bins:
        available = sum(1 for v in bins.values() if v)
        total_weight += 0.7
        score += 0.7 * (available / len(bins))
    
    # Packages weight 30%
    packages = dependency_status.get('packages', {})
    if packages:
        available = sum(1 for v in packages.values() if v)
        total_weight += 0.3
        score += 0.3 * (available / len(packages))
    
    # Credentials and external: penalty
    creds = dependency_status.get('credentials', {})
    if creds:
        # Assume unavailable, reduce score by 0.1 per credential up to 0.5
        penalty = min(0.1 * len(creds), 0.5)
        score -= penalty
    
    external = dependency_status.get('external', {})
    if external:
        penalty = min(0.1 * len(external), 0.5)
        score -= penalty
    
    # Normalize if total_weight < 1 (e.g., no bins/packages)
    if total_weight == 0:
        return 0.0
    
    # Ensure score between 0 and 1
    return max(0.0, min(1.0, score))

def get_skill_availability(skill_deps: dict) -> tuple:
    """
    Return (availability_score, missing_critical, status_dict).
    missing_critical is list of missing binaries/packages.
    """
    status = check_dependencies(skill_deps)
    score = availability_score(status)
    
    missing = []
    for bin_name, available in status['bins'].items():
        if not available:
            missing.append(f"binary:{bin_name}")
    for pkg, available in status['packages'].items():
        if not available:
            missing.append(f"package:{pkg}")
    
    return score, missing, status

if __name__ == '__main__':
    # Test with a sample skill
    sample = {
        'bins': ['curl', 'git', 'nonexistent'],
        'packages': ['brew:gh', 'apt:notinstalled'],
        'credentials': ['GITHUB_TOKEN'],
        'external': []
    }
    status = check_dependencies(sample)
    print("Status:", status)
    score = availability_score(status)
    print("Score:", score)