#!/usr/bin/env python3
import sys
import json
sys.path.append('/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import get

def safe_str(val):
    return str(val).strip() if val is not None else ""

def main():
    result = get('/tasks/list', params={'limit': 100})
    tasks = result.get('results', [])
    
    api_tasks = []
    comp_tasks = []
    all_tasks = []
    
    for task in tasks:
        item = task.get('item', task)
        task_id = item.get('id') or task.get('id')
        title = safe_str(item.get('title', ''))
        assignee = safe_str(item.get('assignee', ''))
        created = item.get('createdAt', '')
        status = item.get('status', '')
        
        all_tasks.append({
            'id': task_id,
            'title': title,
            'assignee': assignee,
            'created': created,
            'status': status
        })
        
        if 'api rate' in title.lower() and 'bayani' in assignee.lower():
            api_tasks.append({'id': task_id, 'title': title, 'created': created, 'status': status})
        if 'competitor pricing' in title.lower() and 'bayani' in assignee.lower():
            comp_tasks.append({'id': task_id, 'title': title, 'created': created, 'status': status})
    
    print(f"Total tasks scanned: {len(all_tasks)}")
    print(f"\nAPI tasks: {len(api_tasks)}")
    for t in api_tasks:
        print(f"  {t['id']}: {t['title'][:60]}...")
        print(f"    created: {t['created']}, status: {t['status']}")
    
    print(f"\nCompetitor tasks: {len(comp_tasks)}")
    for t in comp_tasks:
        print(f"  {t['id']}: {t['title'][:60]}...")
        print(f"    created: {t['created']}, status: {t['status']}")
    
    # Check for tasks created today (2026-03-03)
    today = '2026-03-03'
    new_api = [t for t in api_tasks if t['created'].startswith(today)]
    new_comp = [t for t in comp_tasks if t['created'].startswith(today)]
    
    print(f"\nAPI tasks created today ({today}): {len(new_api)}")
    print(f"Competitor tasks created today: {len(new_comp)}")
    
    if new_api or new_comp:
        print("\n⚠️  NEW DUPLICATES CREATED!")
        for t in new_api + new_comp:
            print(f"  {t['id']}: {t['title'][:50]}...")

if __name__ == '__main__':
    main()