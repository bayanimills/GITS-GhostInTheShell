#!/usr/bin/env python3
"""
Check for PDF attachments in emails from specific domains and verify classification.
Focus on top promotional domains and emergentagent.com.
"""
import subprocess
import json
import sys
import re
from collections import defaultdict
from email.utils import parseaddr

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

# Domains to check (top 8 from analysis + emergent)
DOMAINS_TO_CHECK = [
    "e.kogan.com",
    "cluborange.org", 
    "email.livenation.com.au",
    "edm2.umart.com.au",
    "buckettys.com.au",
    "coinspot.com.au",
    "au.enews.bp.email",
    "thinlizzy.com.au",
    "emergentagent.com"  # Specifically requested
]

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def extract_domain(email_address):
    """Extract domain from email address."""
    _, email = parseaddr(email_address)
    if '@' in email:
        return email.lower().split('@')[1]
    return email.lower()

def get_thread_details(thread_id):
    """Fetch full thread details with messages and attachments."""
    cmd = ["gmail", "thread", "get", thread_id, "--json"]
    success, output = run_gog(cmd)
    if not success:
        return None
    try:
        return json.loads(output)
    except json.JSONDecodeError:
        return None

def check_domain_emails(domain, days=90):
    """Check emails from a specific domain for PDF attachments."""
    print(f"\n{'='*70}")
    print(f"Checking domain: {domain}")
    print(f"{'='*70}")
    
    # Search for emails from this domain
    query = f"from:{domain} newer_than:{days}d"
    cmd = ["gmail", "search", query, "--max", "50", "--json"]
    success, output = run_gog(cmd)
    if not success:
        print(f"  Failed to search for domain {domain}")
        return []
    
    try:
        data = json.loads(output)
        threads = data.get('threads', [])
    except json.JSONDecodeError:
        print(f"  Failed to parse JSON for domain {domain}")
        return []
    
    if not threads:
        print(f"  No emails found from {domain} in last {days} days")
        return []
    
    print(f"  Found {len(threads)} threads")
    
    results = []
    for i, thread in enumerate(threads):
        thread_id = thread.get('id')
        subject = thread.get('subject', 'No subject')
        labels = thread.get('labels', [])
        is_promo = 'CATEGORY_PROMOTIONS' in labels
        
        # Get thread details to check attachments
        thread_data = get_thread_details(thread_id)
        if not thread_data or 'messages' not in thread_data:
            continue
        
        # Check each message for attachments
        pdf_attachments = []
        other_attachments = []
        for msg in thread_data['messages']:
            attachments = msg.get('attachments', [])
            for att in attachments:
                filename = att.get('filename', '').lower()
                if filename.endswith('.pdf'):
                    pdf_attachments.append({
                        'filename': att.get('filename', 'unknown'),
                        'size': att.get('size', 0)
                    })
                else:
                    other_attachments.append({
                        'filename': att.get('filename', 'unknown'),
                        'size': att.get('size', 0)
                    })
        
        if pdf_attachments or other_attachments:
            result = {
                'thread_id': thread_id,
                'subject': subject[:80],
                'labels': labels,
                'is_promo': is_promo,
                'pdf_count': len(pdf_attachments),
                'other_count': len(other_attachments),
                'pdfs': pdf_attachments[:3],  # Limit to first 3
                'others': other_attachments[:3]
            }
            results.append(result)
            
            # Print immediate finding
            print(f"\n  Thread: {subject[:60]}...")
            print(f"    Labels: {', '.join(labels[:3])}")
            print(f"    Promotional classification: {is_promo}")
            print(f"    PDF attachments: {len(pdf_attachments)}")
            if pdf_attachments:
                for pdf in pdf_attachments[:2]:
                    print(f"      - {pdf['filename']} ({pdf['size']} bytes)")
            print(f"    Other attachments: {len(other_attachments)}")
    
    return results

def main():
    print("PDF Attachment Check for Top Promotional Domains")
    print("="*70)
    print(f"Checking {len(DOMAINS_TO_CHECK)} domains for PDF attachments")
    print("Focus: Ensure PDF documents aren't misclassified as promotional")
    print()
    
    all_results = []
    domain_results = {}
    
    for domain in DOMAINS_TO_CHECK:
        results = check_domain_emails(domain, days=90)
        domain_results[domain] = results
        all_results.extend(results)
    
    # Summary report
    print("\n" + "="*70)
    print("SUMMARY REPORT")
    print("="*70)
    
    total_threads_with_pdfs = sum(1 for r in all_results if r['pdf_count'] > 0)
    total_threads_with_attachments = len(all_results)
    total_promotional_with_pdfs = sum(1 for r in all_results if r['pdf_count'] > 0 and r['is_promo'])
    
    print(f"\nTotal threads with attachments found: {total_threads_with_attachments}")
    print(f"Threads with PDF attachments: {total_threads_with_pdfs}")
    print(f"Threads with PDFs classified as promotional: {total_promotional_with_pdfs}")
    
    # Check for potential misclassification
    print("\n" + "="*70)
    print("POTENTIAL MISCLASSIFICATION REVIEW")
    print("="*70)
    
    misclassified = []
    for result in all_results:
        if result['pdf_count'] > 0 and result['is_promo']:
            # Check if any financial keywords in subject
            subject_lower = result['subject'].lower()
            financial_keywords = ['invoice', 'receipt', 'statement', 'tax', 'bill', 'payment']
            has_financial = any(kw in subject_lower for kw in financial_keywords)
            
            misclassified.append({
                'thread_id': result['thread_id'],
                'subject': result['subject'],
                'pdf_count': result['pdf_count'],
                'has_financial_keywords': has_financial
            })
    
    if misclassified:
        print(f"\nFound {len(misclassified)} threads with PDFs classified as promotional:")
        for item in misclassified:
            print(f"\n  Thread: {item['subject']}")
            print(f"    ID: {item['thread_id']}")
            print(f"    PDFs: {item['pdf_count']}")
            print(f"    Financial keywords: {item['has_financial_keywords']}")
        
        print("\nRECOMMENDATION: Review these threads manually to ensure")
        print("PDF documents (invoices, receipts, etc.) aren't being archived")
        print("prematurely via promotional email automation.")
    else:
        print("\nNo threads with PDF attachments found to be classified as promotional.")
        print("Classification appears correct.")
    
    # Domain-specific attachment statistics
    print("\n" + "="*70)
    print("DOMAIN-SPECIFIC ATTACHMENT STATISTICS")
    print("="*70)
    
    for domain in DOMAINS_TO_CHECK:
        results = domain_results.get(domain, [])
        if not results:
            continue
        
        pdf_threads = sum(1 for r in results if r['pdf_count'] > 0)
        promo_with_pdfs = sum(1 for r in results if r['pdf_count'] > 0 and r['is_promo'])
        
        print(f"\n{domain}:")
        print(f"  Total threads checked: {len(results)}")
        print(f"  Threads with PDFs: {pdf_threads}")
        print(f"  PDF threads marked promotional: {promo_with_pdfs}")
    
    # Archiving recommendations for top domains
    print("\n" + "="*70)
    print("ARCHIVING RECOMMENDATIONS FOR TOP DOMAINS")
    print("="*70)
    
    print("\nBased on analysis:")
    print("1. Current promotional archiving catches ALL category:promotions emails hourly")
    print("2. Adding domain-specific archiving for these 8 domains would:")
    print("   - Archive emails even if not categorized as promotional")
    print("   - Allow custom archive delays (e.g., 3 days instead of immediate)")
    print("   - Provide finer control over specific senders")
    
    if misclassified:
        print("\n⚠️  IMPORTANT: Found PDF attachments in promotional emails.")
        print("   Consider adjusting classification rules for these domains.")
        print("   OR exclude emails with PDFs from automatic archiving.")
    
    print("\nImplementation options:")
    print("A. Add to label_rules.json sender_domains section")
    print("   Example: 'e.kogan.com': 'ToArchive/3days'")
    print("B. Create separate cron job for domain-specific archiving")
    print("C. Adjust existing promotional archiving to skip emails with PDFs")
    
    return all_results

if __name__ == "__main__":
    main()