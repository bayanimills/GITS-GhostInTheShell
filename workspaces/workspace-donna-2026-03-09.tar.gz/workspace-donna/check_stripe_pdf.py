#!/usr/bin/env python3
"""
Check if Stripe receipt email has PDF download link.
"""
import subprocess
import json
import re
import sys

def run_cmd(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    return result.stdout, result.stderr, result.returncode

def extract_body(parts, mime_type="text/html"):
    """Extract body content from message parts."""
    for part in parts:
        if part.get("mimeType") == mime_type:
            body = part.get("body", {})
            data = body.get("data")
            if data:
                # Base64 decode
                import base64
                try:
                    return base64.b64decode(data).decode('utf-8', errors='ignore')
                except:
                    return None
        if "parts" in part:
            content = extract_body(part["parts"], mime_type)
            if content:
                return content
    return None

gog = "/home/agent/.linuxbrew/bin/gog"
account = "bayanimills@gmail.com"
thread_id = "19cc4a1409a9c8ba"

# Get thread
stdout, stderr, rc = run_cmd([gog, "gmail", "thread", thread_id, "--json", "--account", account])
if rc != 0:
    print(f"Error: {stderr}")
    sys.exit(1)

data = json.loads(stdout)
messages = data.get("thread", {}).get("messages", [])
if not messages:
    print("No messages")
    sys.exit(1)

message = messages[0]
payload = message.get("payload", {})
parts = payload.get("parts", [])

# Extract HTML body
html = extract_body(parts, "text/html")
if html:
    print("Found HTML body")
    # Look for PDF links
    pdf_patterns = [
        r'href="([^"]+\.pdf[^"]*)"',
        r'href="([^"]*download[^"]*\.pdf[^"]*)"',
        r'href="([^"]*receipt[^"]*\.pdf[^"]*)"',
        r'href="([^"]*\.pdf\?[^"]*)"',
        r'Download.*?(https://[^"]+)',
    ]
    
    pdf_links = []
    for pattern in pdf_patterns:
        matches = re.findall(pattern, html, re.IGNORECASE)
        pdf_links.extend(matches)
    
    if pdf_links:
        print(f"Found {len(pdf_links)} PDF links:")
        for link in pdf_links[:5]:
            print(f"  {link}")
    else:
        print("No PDF links found")
        # Save sample HTML to file for inspection
        with open("/tmp/stripe_email.html", "w") as f:
            f.write(html[:2000])
        print("Saved first 2000 chars of HTML to /tmp/stripe_email.html")
        
        # Also check for "receipt" text
        if "receipt" in html.lower():
            print("Contains 'receipt' in HTML")
        
        # Look for any links
        all_links = re.findall(r'href="(https?://[^"]+)"', html)
        print(f"Found {len(all_links)} total links")
        for link in all_links[:3]:
            print(f"  {link}")
else:
    print("No HTML body found")
    # Try plain text
    text = extract_body(parts, "text/plain")
    if text:
        print(f"Plain text preview: {text[:500]}...")
    else:
        print("No text body either")