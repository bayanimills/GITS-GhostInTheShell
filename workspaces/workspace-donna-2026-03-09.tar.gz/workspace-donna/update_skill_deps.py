#!/usr/bin/env python3
"""
Update skill dependencies for skills with empty dependency lists.
"""
import json
import os
import sys

def main():
    metadata_path = '/home/agent/.openclaw/workspace-donna/skills_metadata.json'
    with open(metadata_path, 'r') as f:
        data = json.load(f)
    
    # Skill-specific dependencies extracted from SKILL.md review
    updates = {
        'bluebubbles': {
            'bins': [],
            'packages': [],
            'credentials': [],
            'external': ['BlueBubbles server'],
            'config': ['channels.bluebubbles']
        },
        'canvas': {
            'bins': ['tailscale', 'jq'],  # optional but useful
            'packages': [],
            'credentials': [],
            'external': ['OpenClaw nodes with canvas capability'],
            'config': ['canvasHost.enabled']
        },
        'coding-agent': {
            'bins': ['bash', 'claude', 'codex', 'opencode', 'pi'],  # any of these
            'packages': [],
            'credentials': [],
            'external': [],
            'config': []
        },
        'discord': {
            'bins': [],
            'packages': [],
            'credentials': [],
            'external': [],
            'config': ['channels.discord.token']
        },
        'food-order': {
            'bins': ['ordercli'],
            'packages': [],
            'credentials': [],
            'external': ['Foodora account'],
            'config': []
        },
        'healthcheck': {
            'bins': ['openclaw'],
            'packages': [],
            'credentials': [],
            'external': [],
            'config': []
        },
        'notion': {
            'bins': [],
            'packages': [],
            'credentials': ['NOTION_API_KEY'],
            'external': [],
            'config': []
        },
        'skill-creator': {
            'bins': ['python3'],
            'packages': [],
            'credentials': [],
            'external': [],
            'config': []
        },
        'slack': {
            'bins': [],
            'packages': [],
            'credentials': [],
            'external': [],
            'config': ['channels.slack']
        },
        'voice-call': {
            'bins': ['openclaw'],
            'packages': [],
            'credentials': [],
            'external': [],
            'config': ['plugins.entries.voice-call.enabled']
        }
    }
    
    for skill_name, deps in updates.items():
        if skill_name in data['skills']:
            skill = data['skills'][skill_name]
            # Update dependencies field
            if 'dependencies' not in skill:
                skill['dependencies'] = {}
            # Ensure all keys exist
            for key in ['bins', 'packages', 'credentials', 'external', 'config']:
                if key not in skill['dependencies']:
                    skill['dependencies'][key] = []
                # Replace with new deps (but keep existing ones if any)
                # For bins, we might want to merge, but for simplicity replace
                # because we have complete list from manual review
                skill['dependencies'][key] = deps.get(key, [])
            print(f'Updated {skill_name}')
        else:
            print(f'Skill {skill_name} not found in metadata')
    
    # Write back
    with open(metadata_path, 'w') as f:
        json.dump(data, f, indent=2)
    print(f'Updated {len(updates)} skills in {metadata_path}')

if __name__ == '__main__':
    main()