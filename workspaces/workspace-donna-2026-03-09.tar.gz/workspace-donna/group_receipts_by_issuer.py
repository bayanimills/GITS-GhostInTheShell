#!/usr/bin/env python3
"""
Group Stripe PDF receipts by issuer (merchant name) and reorganize Nextcloud folder.
"""
import os
import sys
import json
import re
import subprocess
import urllib.parse
from datetime import datetime

WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/stripe_pdfs_state.json")
ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

# Nextcloud configuration
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"
NEXTCLOUD_FOLDER = "/_private/businesses/Bayani%20Enterprises/Receipts/"

def run_cmd(cmd, timeout=30):
    """Run shell command and return stdout, stderr, returncode."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", "Command timed out", 124
    except Exception as e:
        return "", str(e), 1

def get_thread_details(thread_id):
    """Fetch thread details via gog."""
    cmd = [GOG, "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        print(f"[ERROR] Failed to get thread {thread_id}: {stderr}")
        return None
    try:
        return json.loads(stdout)
    except Exception as e:
        print(f"[ERROR] Failed to parse thread details: {e}")
        return None

def extract_issuer_from_subject(subject):
    """Extract issuer name from email subject.
    Expected pattern: 'Your receipt from EMERGENT LABS INC #xxxx-xxxx' or similar.
    """
    if not subject:
        return "Unknown"
    # Look for "from X" pattern
    match = re.search(r'from\s+([^#]+?)\s+#', subject, re.IGNORECASE)
    if match:
        issuer = match.group(1).strip()
        return issuer
    # Fallback: use whole subject up to '#'
    parts = subject.split('#')
    if len(parts) > 1:
        return parts[0].strip()
    return subject.strip()

def list_nextcloud_files():
    """List files in Nextcloud folder via WebDAV PROPFIND."""
    import xml.etree.ElementTree as ET
    url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "PROPFIND",
        "-H", "Depth: 1",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc != 0:
        print(f"[ERROR] Failed to list Nextcloud files: {stderr}")
        return []
    # Parse XML response
    try:
        root = ET.fromstring(stdout)
        ns = {'d': 'DAV:'}
        files = []
        for response in root.findall('d:response', ns):
            href = response.find('d:href', ns).text
            # Remove base URL and decode
            base_url = url.rstrip('/')
            if href.startswith(base_url):
                rel_path = href[len(base_url)+1:]
                rel_path = urllib.parse.unquote(rel_path)
                if rel_path and not rel_path.endswith('/'):
                    files.append(rel_path)
        return files
    except Exception as e:
        print(f"[ERROR] Failed to parse PROPFIND response: {e}")
        return []

def create_nextcloud_subfolder(subfolder):
    """Create subfolder in Nextcloud via MKCOL."""
    full_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{urllib.parse.quote(subfolder)}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        full_url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        print(f"[INFO] Created subfolder: {subfolder}")
        return True
    elif "405" in stderr:  # Already exists
        print(f"[INFO] Subfolder already exists: {subfolder}")
        return True
    else:
        print(f"[ERROR] Failed to create subfolder {subfolder}: {stderr}")
        return False

def move_nextcloud_file(src_filename, dest_subfolder, dry_run=True):
    """Move file within Nextcloud via WebDAV MOVE."""
    src_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{urllib.parse.quote(src_filename)}"
    dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}{urllib.parse.quote(dest_subfolder)}/{urllib.parse.quote(src_filename)}"
    if dry_run:
        print(f"[DRY-RUN] Would move {src_filename} -> {dest_subfolder}/")
        return True
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MOVE",
        "-H", f"Destination: {dest_url}",
        src_url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        print(f"[INFO] Moved {src_filename} to {dest_subfolder}/")
        return True
    else:
        print(f"[ERROR] Failed to move {src_filename}: {stderr}")
        return False

def upload_readme(content, dry_run=True):
    """Upload README.md to Nextcloud root folder."""
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
        f.write(content)
        temp_path = f.name
    try:
        dest_url = f"{NEXTCLOUD_BASE_URL}{NEXTCLOUD_FOLDER}README.md"
        if dry_run:
            print(f"[DRY-RUN] Would upload README.md to {NEXTCLOUD_FOLDER}")
            return True
        cmd = [
            "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
            "-T", temp_path,
            dest_url
        ]
        stdout, stderr, rc = run_cmd(cmd, timeout=30)
        if rc == 0:
            print(f"[INFO] Uploaded README.md to {NEXTCLOUD_FOLDER}")
            return True
        else:
            print(f"[ERROR] Failed to upload README.md: {stderr}")
            return False
    finally:
        os.unlink(temp_path)

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Group Stripe receipts by issuer")
    parser.add_argument("--dry-run", action="store_true", help="Dry run, no changes")
    args = parser.parse_args()
    dry_run = args.dry_run
    if dry_run:
        print("[INFO] Running in dry-run mode, no changes will be made.")
    
    # Load state
    if not os.path.exists(STATE_FILE):
        print(f"[ERROR] State file not found: {STATE_FILE}")
        sys.exit(1)
    with open(STATE_FILE) as f:
        state = json.load(f)
    print(f"[INFO] Loaded state with {len(state)} threads.")
    
    # Map thread IDs to issuer
    thread_issuer = {}
    issuer_groups = {}  # issuer -> list of filenames
    for thread_id, info in state.items():
        # Get thread details
        details = get_thread_details(thread_id)
        if not details:
            continue
        thread = details.get("thread", {})
        messages = thread.get("messages", [])
        if not messages:
            continue
        first_msg = messages[0]
        subject = first_msg.get("subject", "")
        # Extract issuer
        issuer = extract_issuer_from_subject(subject)
        thread_issuer[thread_id] = issuer
        # Get filenames for this thread
        filenames = info.get("downloaded_pdfs", [])
        if issuer not in issuer_groups:
            issuer_groups[issuer] = []
        issuer_groups[issuer].extend(filenames)
        print(f"[INFO] Thread {thread_id[:8]} -> issuer: {issuer}, files: {len(filenames)}")
        # Small delay to avoid rate limiting
        import time
        time.sleep(0.5)
    
    # Remove duplicates across threads (some files may be duplicated due to links+attachments)
    for issuer, files in issuer_groups.items():
        issuer_groups[issuer] = sorted(set(files))
    
    print("\n[INFO] Issuer groups:")
    for issuer, files in issuer_groups.items():
        print(f"  {issuer}: {len(files)} files")
    
    # List current files in Nextcloud
    existing_files = list_nextcloud_files()
    print(f"[INFO] Found {len(existing_files)} files in Nextcloud folder.")
    
    # Verify all expected files exist
    all_expected = [f for files in issuer_groups.values() for f in files]
    missing = [f for f in all_expected if f not in existing_files]
    if missing:
        print(f"[WARNING] {len(missing)} expected files not found in Nextcloud:")
        for f in missing[:5]:
            print(f"  {f}")
        if len(missing) > 5:
            print(f"  ... and {len(missing)-5} more")
    else:
        print("[INFO] All expected files present in Nextcloud.")
    
    # Create subfolders and move files
    moved = []
    for issuer, files in issuer_groups.items():
        # Sanitize folder name
        folder_name = re.sub(r'[^\w\-\.]', '_', issuer)
        if not folder_name:
            folder_name = "Unknown"
        # Create subfolder
        if not create_nextcloud_subfolder(folder_name):
            continue
        # Move each file
        for filename in files:
            if filename in existing_files:
                success = move_nextcloud_file(filename, folder_name, dry_run=dry_run)
                if success and not dry_run:
                    moved.append((filename, folder_name))
            else:
                print(f"[WARNING] File {filename} not found, skipping.")
    
    # Generate README
    readme_lines = [
        "# Receipts Folder Structure",
        "",
        "This folder contains Stripe PDF receipts downloaded from Gmail.",
        "Files are grouped by issuer (the merchant name from the email subject).",
        "",
        "## Summary",
        "",
        f"**Total files:** {len(all_expected)}",
        f"**Issuers:** {len(issuer_groups)}",
        f"**Last updated:** {datetime.now().isoformat()}",
        "",
        "## Issuer Groups",
        ""
    ]
    for issuer, files in sorted(issuer_groups.items()):
        folder_name = re.sub(r'[^\w\-\.]', '_', issuer)
        readme_lines.append(f"### {issuer}")
        readme_lines.append(f"**Folder:** `{folder_name}/`")
        readme_lines.append(f"**Count:** {len(files)}")
        readme_lines.append("")
        for f in sorted(files):
            readme_lines.append(f"- `{f}`")
        readme_lines.append("")
    readme_lines.append("## Notes")
    readme_lines.append("- Files were downloaded via Stripe's signed S3 URLs or Gmail attachments.")
    readme_lines.append("- Invoices and receipts are paired per transaction.")
    readme_lines.append("- Generated by OpenClaw automation.")
    
    readme_content = "\n".join(readme_lines)
    print("\n" + "="*60)
    print(readme_content)
    print("="*60 + "\n")
    
    if not dry_run:
        upload_readme(readme_content, dry_run=False)
    else:
        upload_readme(readme_content, dry_run=True)
    
    print(f"[INFO] {'Dry run completed.' if dry_run else 'Processing complete.'}")
    if moved:
        print(f"[INFO] Moved {len(moved)} files to issuer subfolders.")

if __name__ == "__main__":
    main()