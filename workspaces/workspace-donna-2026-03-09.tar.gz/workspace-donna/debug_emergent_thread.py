#!/usr/bin/env python3
import subprocess
import json
import sys

def run_cmd(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    return result.stdout, result.stderr, result.returncode

gog = "/home/agent/.linuxbrew/bin/gog"
account = "bayanimills@gmail.com"
thread_id = "19cc4a1409a9c8ba"  # First Emergent receipt from earlier

# Get thread details
stdout, stderr, rc = run_cmd([gog, "gmail", "thread", thread_id, "--json", "--account", account])
if rc != 0:
    print(f"Error: {stderr}")
    sys.exit(1)

data = json.loads(stdout)
thread = data.get("thread", {})
messages = thread.get("messages", [])
print(f"Thread has {len(messages)} messages")

if messages:
    message = messages[0]
    message_id = message.get("id")
    print(f"Message ID: {message_id}")
    
    # Check for attachments
    def extract_attachments(parts, indent=0):
        attachments = []
        for part in parts:
            filename = part.get("filename")
            body = part.get("body", {})
            attachment_id = body.get("attachmentId")
            mime_type = part.get("mimeType", "")
            print(f"{'  '*indent}Part: mimeType={mime_type}, filename={filename}, attachmentId={attachment_id}")
            if filename and attachment_id:
                attachments.append({
                    "filename": filename,
                    "id": attachment_id,
                    "size": body.get("size", 0)
                })
            if "parts" in part:
                attachments.extend(extract_attachments(part["parts"], indent+1))
        return attachments
    
    payload = message.get("payload", {})
    parts = payload.get("parts", [])
    attachments = extract_attachments(parts)
    
    print(f"\nFound {len(attachments)} attachments:")
    for att in attachments:
        print(f"  - {att['filename']} (id: {att['id']}, size: {att['size']} bytes)")
    
    # Also check for inline attachments or PDFs
    print(f"\nFull message structure keys: {list(message.keys())}")
    print(f"Payload keys: {list(payload.keys())}")
    
else:
    print("No messages in thread")