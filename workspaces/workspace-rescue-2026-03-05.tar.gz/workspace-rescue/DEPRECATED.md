# DEPRECATED - Rescue Agent Workspace

**Status**: Deprecated as of 2026-02-23  
**Reason**: Centralized recovery testing no longer needed; use main agent workspace for recovery procedures  
**Action**: This workspace should not be used for new work

## Deprecation Details

- **Date Deprecated**: 2026-02-23
- **Deprecated By**: Kaira (Delegation Agent) per user instruction
- **Reason**: Rescue profile and workspace are no longer required for OpenClaw ecosystem operations
- **Alternative**: Use the main agent workspace (`/home/agent/.openclaw/workspace`) for recovery testing

## What This Means

1. **No New Work**: Do not create new files, cron jobs, or configurations in this workspace
2. **Existing Files**: Preserved for historical reference only
3. **Recovery Procedures**: Update RECOVERY_CONFIGURATION.md to reference main workspace instead
4. **Profile Usage**: The `--profile rescue` OpenClaw flag should be considered deprecated

## Migration Steps

If you need recovery testing functionality:

1. Use the main agent workspace (`/home/agent/.openclaw/workspace`)
2. Update any scripts referencing `/home/agent/.openclaw/workspace-rescue`
3. Consider using agent-specific workspaces for specialized testing

## Archive Consideration

This workspace may be archived or removed after 2026-03-23 if no dependencies remain.

---
*Deprecation logged in `memory/2026-02-23.md`*