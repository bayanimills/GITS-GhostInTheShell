#!/usr/bin/env python3
"""
Test Simmer dry-run with $SIM balance.
"""

import os
from simmer_sdk import SimmerClient

# Use the WORKING API key (second key)
API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

print("Testing Simmer Dry-Run with $SIM...")
print("="*60)

try:
    # Initialize client
    client = SimmerClient(api_key=API_KEY)
    
    # Test connection - get briefing
    print("1. Testing API connection...")
    briefing = client._request("GET", "/api/sdk/briefing")
    
    print(f"   ✅ Connection successful!")
    print(f"   Agent: {briefing.get('agent', {}).get('name', 'Unknown')}")
    print(f"   Agent ID: {briefing.get('agent', {}).get('id', 'Unknown')}")
    print(f"   Real trading enabled: {briefing.get('agent', {}).get('real_trading_enabled', False)}")
    
    # Check $SIM balance
    print("\n2. Checking $SIM balance...")
    sim_balance = briefing.get('agent', {}).get('balance', 0)
    print(f"   $SIM Balance: {sim_balance:,} $SIM")
    
    # Check Polymarket balance (USDC)
    print("\n3. Checking Polymarket venue...")
    venues = briefing.get('venues', {})
    polymarket = venues.get('polymarket', {})
    print(f"   Polymarket USDC balance: {polymarket.get('balance', 0)} USDC")
    print(f"   Positions count: {polymarket.get('positions_count', 0)}")
    
    # Get some markets
    print("\n4. Fetching active markets...")
    markets = client.get_markets(limit=5, status='active')
    print(f"   Found {len(markets)} active markets")
    
    if markets:
        print("\n5. Sample market (for dry-run testing):")
        market = markets[0]
        print(f"   Market ID: {market.id}")
        print(f"   Question: {market.question[:80]}...")
        print(f"   Current probability: {market.current_probability:.1%}")
        
        # Get market context
        print("\n6. Getting market context (dry-run check)...")
        context = client.get_market_context(market.id)
        print(f"   Redeemable: {context.get('redeemable', False)}")
        print(f"   Position: {context.get('position', 'None')}")
        print(f"   Slippage estimate: {context.get('slippage_estimate', 'N/A')}")
    
    print("\n" + "="*60)
    print("DRY-RUN READY!")
    print(f"You have {sim_balance:,} $SIM for testing")
    print("The API key is valid and working")
    print("="*60)
    
except Exception as e:
    print(f"❌ Error: {e}")
    print("\nTroubleshooting:")
    print("1. Check if API key is still valid")
    print("2. Check network connectivity")
    print("3. Try visiting simmer.markets/dashboard")