#!/usr/bin/env python3
"""
Improved LMSR Analysis with Realistic Filtering
Properly handles 100% probability markets and date filtering.
"""

import sys
from datetime import datetime, timezone

def analyze_with_improved_filters():
    """Analyze markets with improved filtering logic."""
    
    print("=" * 80)
    print("IMPROVED LMSR ANALYSIS - 3:29 PM SCAN")
    print("=" * 80)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Australia/Sydney: Thursday, March 12th, 2026 — 3:29 PM")
    print(f"API Key: sk_live_92983b88e10d... (validated)")
    print()
    
    # Markets from scan - now including March 12 markets
    markets = [
        {
            'name': 'XRP Up or Down - March 12, 12:00AM-12:05AM ET',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'Crypto',
            'date': 'March 12',
            'time': '12:00-12:05AM ET (4-4:05 PM AEST)',
            'status': 'JUST EXPIRED'
        },
        {
            'name': 'XRP Up or Down - March 12, 12:00AM-12:15AM ET',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'Crypto',
            'date': 'March 12',
            'time': '12:00-12:15AM ET (4-4:15 PM AEST)',
            'status': 'JUST EXPIRED'
        },
        {
            'name': 'Spread: Oklahoma Sooners (-7.5)',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'NCAA Basketball',
            'date': 'March 11 (likely)',
            'time': 'Unknown',
            'status': 'LIKELY RESOLVED'
        },
        {
            'name': 'Bitcoin Up or Down - March 11, 11PM ET',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'Crypto',
            'date': 'March 11',
            'time': '11PM ET (2PM AEST Mar 12)',
            'status': 'RESOLVED'
        },
        {
            'name': 'Spread: Oklahoma Sooners (-8.5)',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'NCAA Basketball',
            'date': 'March 11 (likely)',
            'time': 'Unknown',
            'status': 'LIKELY RESOLVED'
        }
    ]
    
    print("IMPROVED FILTERING LOGIC")
    print("-" * 80)
    print("Filter 1: Remove 100% probability markets (resolved/certain)")
    print("Filter 2: Remove expired markets (past their end time)")
    print("Filter 3: Remove March 11 markets (yesterday)")
    print("Filter 4: Keep probabilities 10-90% only")
    print("Filter 5: Minimum net edge after convexity: 15%")
    print()
    
    actionable_markets = []
    
    for i, market in enumerate(markets, 1):
        print(f"{i}. {market['name'][:55]}...")
        print(f"   Probability: {market['prob']:.1%}")
        print(f"   Action: {market['action']}")
        print(f"   Category: {market['category']}")
        print(f"   Date: {market['date']} | Time: {market['time']}")
        print(f"   Status: {market['status']}")
        
        # Apply improved filters
        filters_failed = []
        
        # Filter 1: 100% probability
        if market['prob'] >= 0.999:
            filters_failed.append("100% probability (resolved/certain)")
        
        # Filter 2: Expired markets (time-based)
        if "JUST EXPIRED" in market['status'] or "RESOLVED" in market['status']:
            filters_failed.append("Market expired/resolved")
        
        # Filter 3: March 11 markets
        if "March 11" in market['date']:
            filters_failed.append("March 11 market (yesterday)")
        
        # Filter 4: Probability range
        if not (0.10 <= market['prob'] <= 0.90):
            filters_failed.append(f"Probability {market['prob']:.1%} outside 10-90% range")
        
        if filters_failed:
            print(f"   ❌ FILTERED OUT:")
            for fail in filters_failed:
                print(f"      • {fail}")
        else:
            # Calculate realistic edge
            if market['prob'] > 0.5:
                # Mean reversion for high probability markets
                revert_strength = 0.3  # 30% reversion toward 50%
                p_true = market['prob'] - (market['prob'] - 0.5) * revert_strength
            else:
                # Mean reversion for low probability markets
                revert_strength = 0.3
                p_true = market['prob'] + (0.5 - market['prob']) * revert_strength
            
            gross_edge = abs(p_true - market['prob'])
            
            # Adjust for BUY NO actions
            if market['action'] == 'BUY NO':
                gross_edge = abs((1 - p_true) - (1 - market['prob']))
            
            # Convexity cost based on probability
            if market['prob'] > 0.8 or market['prob'] < 0.2:
                convexity_pct = 0.4  # 40% for extreme probabilities
            elif market['prob'] > 0.7 or market['prob'] < 0.3:
                convexity_pct = 0.3  # 30% for high probabilities
            else:
                convexity_pct = 0.2  # 20% for moderate probabilities
            
            net_edge = gross_edge * (1 - convexity_pct)
            
            if net_edge >= 0.15:
                print(f"   ✅ PASSED FILTERS")
                print(f"   Model Probability: {p_true:.1%}")
                print(f"   Gross Edge: {gross_edge:.1%}")
                print(f"   Convexity Cost: {convexity_pct:.0%} of gross edge")
                print(f"   Net Edge: {net_edge:.1%} (≥15%)")
                
                actionable_markets.append({
                    'market': market,
                    'gross_edge': gross_edge,
                    'net_edge': net_edge,
                    'convexity_pct': convexity_pct,
                    'p_true': p_true
                })
            else:
                print(f"   ❌ FILTERED OUT - Net edge {net_edge:.1%} < 15%")
        
        print()
    
    print("\n" + "=" * 80)
    print("ACTIONABLE OPPORTUNITIES")
    print("=" * 80)
    
    if actionable_markets:
        print(f"\n✓ Found {len(actionable_markets)} potentially actionable markets")
        print("\nDetailed Trade Analysis:")
        
        for i, item in enumerate(actionable_markets, 1):
            market = item['market']
            net_edge = item['net_edge']
            gross_edge = item['gross_edge']
            convexity_pct = item['convexity_pct']
            p_true = item['p_true']
            
            # Position sizing with conservative assumptions
            if market['action'] == 'BUY NO':
                p_market_trade = 1 - market['prob']
                p_true_trade = 1 - p_true
            else:
                p_market_trade = market['prob']
                p_true_trade = p_true
            
            max_position_usd = 50.0
            base_shares = max_position_usd / p_market_trade if p_market_trade > 0 else 0
            
            # Conservative sizing: 60% of base, plus 20% convexity buffer
            optimal_shares = base_shares * 0.6 * 0.8
            
            position_value = optimal_shares * p_market_trade
            expected_ev = net_edge * optimal_shares * 100  # Convert to USD
            
            print(f"\n{i}. {market['name'][:50]}...")
            print(f"   Action: {market['action']}")
            print(f"   Market: {market['prob']:.1%} → Model: {p_true:.1%}")
            print(f"   Edge: Gross {gross_edge:.1%} → Net {net_edge:.1%}")
            print(f"   Convexity Impact: {convexity_pct:.0%} reduction")
            print(f"   Trade: {market['action']} {optimal_shares:.1f} shares")
            print(f"   Position Cost: ${position_value:.2f}")
            print(f"   Expected EV: ${expected_ev:.2f}")
            print(f"   Expected ROI: {(expected_ev/position_value*100):.1f}%" if position_value > 0 else "   ROI: N/A")
            print(f"   Risk Level: MODERATE (probability in range)")
        
        # Summary
        total_cost = sum(item['market']['prob'] * 50 * 0.48 for item in actionable_markets)  # 0.6 * 0.8 = 0.48
        total_ev = sum(item['net_edge'] * 50 * 0.48 * 100 for item in actionable_markets)
        
        print("\n" + "-" * 80)
        print("PORTFOLIO SUMMARY (Conservative Estimate):")
        print(f"  Total Investment: ${total_cost:.2f}")
        print(f"  Total Expected EV: ${total_ev:.2f}")
        print(f"  Expected Portfolio ROI: {(total_ev/total_cost*100):.1f}%" if total_cost > 0 else "  ROI: N/A")
        print(f"  Average Net Edge: {sum(item['net_edge'] for item in actionable_markets)/len(actionable_markets):.1%}")
        
    else:
        print("\n✗ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("\nAnalysis of Current Market State:")
        print("1. Market Timing Issue:")
        print("   • Current time: 3:29 PM AEST, March 12")
        print("   • Many markets expiring around 4:00 PM AEST")
        print("   • These show 100% probability as they resolve")
        
        print("\n2. Crypto Market Pattern:")
        print("   • XRP markets: 12:00-12:15AM ET (4:00-4:15 PM AEST)")
        print("   • Just expired at scan time")
        print("   • 100% probability indicates resolution")
        
        print("\n3. Sports Markets:")
        print("   • NCAA games from March 11 (US time)")
        print("   • These are resolved overnight AEST")
        print("   • Showing 100% probability as outcomes known")
        
        print("\n4. System Timing Issue:")
        print("   • Scan catching markets at resolution moment")
        print("   • Need to scan earlier in market lifecycle")
        print("   • Avoid scanning near market expiration")
    
    print("\n" + "=" * 80)
    print("CRITICAL INSIGHT: MARKET TIMING")
    print("=" * 80)
    
    print("\nCurrent Scan Time: 3:29 PM AEST")
    print("Key Market Expiry Times:")
    print("• Crypto 5-minute markets: Every 5 minutes")
    print("• Crypto 15-minute markets: :00, :15, :30, :45 past hour")
    print("• March 12, 12:00AM ET = 4:00 PM AEST")
    print("• March 12, 12:15AM ET = 4:15 PM AEST")
    
    print("\nProblem Identified:")
    print("• Scanning at 3:29 PM AEST")
    print("• Markets expiring at 4:00 PM AEST showing 100%")
    print("• These are resolving, not active trading opportunities")
    
    print("\nSolution:")
    print("1. Scan earlier: 2:30-3:00 PM AEST")
    print("2. Avoid scanning near :00 and :30 past hour")
    print("3. Focus on markets with >30 minutes to expiry")
    
    print("\n" + "=" * 80)
    print("REALISTIC EDGE CALCULATION FOR 100% MARKETS")
    print("=" * 80)
    
    print("\nExample: XRP Up/Down market at 100% probability")
    print("• Market view: XRP went DOWN in that period")
    print("• Probability XRP actually went DOWN: ~99.9%")
    print("• True probability: 99.9%")
    print("• Market probability: 100%")
    print("• Edge for BUY NO: -0.1% (NEGATIVE)")
    print("• Expected EV: NEGATIVE")
    
    print("\nWhy 100% probability markets have no edge:")
    print("1. They're either correct (true prob ≈ 100%) → Edge: 0% or negative")
    print("2. Or they're data errors → Edge: unknown, high risk")
    print("3. Never positive expected value")
    
    print("\n" + "=" * 80)
    print("TRADING DECISION & RECOMMENDATIONS")
    print("=" * 80)
    
    print("\n🔴 DECISION: DO NOT TRADE")
    print("\nPrimary Reasons:")
    print("1. All identified markets show 100% probability")
    print("2. Markets are at/near expiration (resolving)")
    print("3. No edge possible in certain/resolved outcomes")
    print("4. Expected EV negative or zero")
    
    print("\nSecondary Reasons:")
    print("1. Timing issue: Scanning near market expiry")
    print("2. Data issue: API showing resolving markets as 'active'")
    print("3. Filter issue: Need to exclude 100% probability")
    print("4. Edge calculation: 100% markets have 0% edge")
    
    print("\nImmediate Actions:")
    print("1. DO NOT execute any trades")
    print("2. Update scanner to filter out 100% probability")
    print("3. Change scan time to avoid market expiry times")
    print("4. Add time-to-expiry filtering")
    
    print("\nNext Steps:")
    print("1. Reschedule scan for 2:30 PM AEST tomorrow")
    print("2. Implement probability range filter (10-90%)")
    print("3. Add minimum time-to-expiry filter (30+ minutes)")
    print("4. Test with smaller probability thresholds")
    
    print("\n" + "=" * 80)
    print("FINAL VERDICT")
    print("=" * 80)
    print("SCAN TIME: 3:29 PM AEST - BAD TIMING")
    print("MARKETS FOUND: 50 with extreme probabilities")
    print("ACTIONABLE: 0 (all 100% probability)")
    print("ISSUE: Scanning near market expiration")
    print("SOLUTION: Reschedule scan, improve filters")
    print("TRADES EXECUTED: 0")
    print("DECISION: DO NOT TRADE")
    print("=" * 80)
    
    return 0

if __name__ == "__main__":
    sys.exit(analyze_with_improved_filters())