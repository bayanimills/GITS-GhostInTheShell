#!/usr/bin/env python3
"""
Detailed LMSR Analysis for Top Opportunities
Calculates actual convexity costs and optimal position sizes.
"""

import os
import sys
import math
from datetime import datetime, timezone
from typing import List

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

class DetailedLMSRAnalyzer:
    """Detailed LMSR analysis for specific markets."""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.client = SimmerClient(api_key=api_key)
        self.b = 100.0  # LMSR liquidity parameter
    
    def calculate_lmsr_price(self, quantities: List[float], outcome_index: int) -> float:
        """Calculate LMSR price."""
        if self.b <= 0:
            return 1.0 / len(quantities)
            
        exponents = [q / self.b for q in quantities]
        max_exp = max(exponents)
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        
        if sum_exp == 0:
            return 1.0 / len(quantities)
            
        return exp_terms[outcome_index] / sum_exp
    
    def calculate_convexity_cost(self, quantities: List[float], outcome_index: int, shares: float) -> float:
        """Estimate convexity cost."""
        price_before = self.calculate_lmsr_price(quantities, outcome_index)
        quantities_after = quantities.copy()
        quantities_after[outcome_index] += shares
        price_after = self.calculate_lmsr_price(quantities_after, outcome_index)
        return (price_after - price_before) * shares
    
    def analyze_market(self, market_id: str, p_market: float, action: str) -> dict:
        """Analyze a specific market with detailed LMSR calculations."""
        
        # Estimate true probability (mean reversion model)
        if p_market > 0.95:
            # Very high probability - assume some reversion
            p_true = 0.85  # Revert to 85%
            edge = p_true - p_market  # Negative edge for BUY NO
        elif p_market < 0.05:
            # Very low probability - assume some reversion
            p_true = 0.15  # Revert to 15%
            edge = p_true - p_market  # Positive edge for BUY YES
        else:
            return None  # Not extreme enough
            
        # Determine outcome index
        if action == "BUY NO":
            outcome_index = 1
            # For BUY NO, we use complementary probabilities
            p_true_no = 1 - p_true
            p_market_no = 1 - p_market
            edge_no = p_true_no - p_market_no
        else:  # BUY YES
            outcome_index = 0
            p_true_no = p_true
            p_market_no = p_market
            edge_no = edge
        
        # Skip if edge is too small
        if abs(edge_no) < 0.15:
            return None
            
        # Estimate liquidity (conservative)
        quantities = [100.0, 100.0]  # Base liquidity
        
        # Calculate optimal position using binary search
        max_position_usd = 50.0
        naive_shares = min(max_position_usd / p_market_no if p_market_no > 0 else 0, 200)
        
        low, high = 0.0, naive_shares
        best_shares = 0.0
        best_ev = 0.0
        
        for _ in range(15):
            mid = (low + high) / 2
            gross_ev = edge_no * mid
            convexity_cost = self.calculate_convexity_cost(quantities, outcome_index, mid)
            net_ev = gross_ev - convexity_cost
            
            test_shares = mid * 1.01
            test_gross_ev = edge_no * test_shares
            test_convexity_cost = self.calculate_convexity_cost(quantities, outcome_index, test_shares)
            test_net_ev = test_gross_ev - test_convexity_cost
            
            if test_net_ev > net_ev:
                low = mid
                best_shares = test_shares
                best_ev = test_net_ev
            else:
                high = mid
        
        # Apply safety buffer
        optimal_shares = best_shares * 0.7
        gross_ev = edge_no * optimal_shares
        convexity_cost = self.calculate_convexity_cost(quantities, outcome_index, optimal_shares)
        final_ev = gross_ev - convexity_cost
        
        # Convert to USD
        position_value_usd = optimal_shares * p_market_no
        expected_ev_usd = final_ev * 100
        
        return {
            'optimal_shares': optimal_shares,
            'position_value_usd': position_value_usd,
            'expected_ev_usd': expected_ev_usd,
            'edge_pct': edge_no * 100,
            'convexity_cost_usd': convexity_cost * 100,
            'convexity_pct': (convexity_cost / (edge_no * optimal_shares)) * 100 if edge_no * optimal_shares > 0 else 0
        }

def main():
    """Main analysis function."""
    api_key = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"
    
    print("=" * 80)
    print("LMSR DETAILED DRY-RUN ANALYSIS")
    print("=" * 80)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"API Key: {api_key[:20]}...")
    print()
    
    # Markets identified from fast scan (with 100% or 0.1% probabilities)
    extreme_markets = [
        {
            'id': '2a9561f0-15f9-40f2-9...',  # Bitcoin Up/Down 7:35-7:40PM ET
            'question': 'Bitcoin Up or Down - March 11, 7:35PM-7:40PM ET',
            'probability': 1.00,
            'action': 'BUY NO'
        },
        {
            'id': '21857707-b195-4548-b...',  # Ethereum Up/Down 8PM ET
            'question': 'Ethereum Up or Down - March 11, 8PM ET',
            'probability': 1.00,
            'action': 'BUY NO'
        },
        {
            'id': 'e7060007-50e8-4a5b-b...',  # Solana Up/Down 8PM ET
            'question': 'Solana Up or Down - March 11, 8PM ET',
            'probability': 1.00,
            'action': 'BUY NO'
        },
        {
            'id': '93e9b541-22d7-430b-a...',  # XRP Up/Down 9:00-9:15PM ET
            'question': 'XRP Up or Down - March 11, 9:00PM-9:15PM ET',
            'probability': 0.001,
            'action': 'BUY YES'
        },
        {
            'id': '12789d7d-6546-44cd-8...',  # Boston Terriers vs Lehigh
            'question': 'Boston Terriers vs. Lehigh Mountain Hawks',
            'probability': 0.001,
            'action': 'BUY YES'
        }
    ]
    
    print("ANALYZING TOP 5 EXTREME PROBABILITY MARKETS")
    print("-" * 80)
    
    analyzer = DetailedLMSRAnalyzer(api_key)
    results = []
    
    for i, market in enumerate(extreme_markets, 1):
        print(f"\n{i}. {market['question']}")
        print(f"   Market Probability: {market['probability']:.1%}")
        print(f"   Proposed Action: {market['action']}")
        
        analysis = analyzer.analyze_market(
            market['id'], 
            market['probability'], 
            market['action']
        )
        
        if analysis:
            results.append({
                'market': market,
                'analysis': analysis
            })
            
            print(f"   Estimated True Probability: {85 if market['probability'] > 0.5 else 15}%")
            print(f"   Edge: {analysis['edge_pct']:+.1f}%")
            print(f"   Optimal Shares: {analysis['optimal_shares']:.1f}")
            print(f"   Position Value: ${analysis['position_value_usd']:.2f}")
            print(f"   Expected EV: ${analysis['expected_ev_usd']:.2f}")
            print(f"   Convexity Cost: ${analysis['convexity_cost_usd']:.2f} ({analysis['convexity_pct']:.1f}% of gross edge)")
        else:
            print(f"   ANALYSIS: Market may be resolved or edge too small")
    
    print("\n" + "=" * 80)
    print("SUMMARY OF FINDINGS")
    print("=" * 80)
    
    if results:
        print(f"\nFound {len(results)} markets with >15% edge potential")
        print("\nTOP OPPORTUNITIES (by Expected EV):")
        print("-" * 80)
        
        # Sort by expected EV
        results.sort(key=lambda x: x['analysis']['expected_ev_usd'], reverse=True)
        
        for i, result in enumerate(results[:5], 1):
            market = result['market']
            analysis = result['analysis']
            
            print(f"\n{i}. {market['question'][:60]}...")
            print(f"   Action: {market['action']}")
            print(f"   Market: {market['probability']:.1%} | Edge: {analysis['edge_pct']:+.1f}%")
            print(f"   Shares: {analysis['optimal_shares']:.1f} | Position: ${analysis['position_value_usd']:.2f}")
            print(f"   Expected EV: ${analysis['expected_ev_usd']:.2f}")
            print(f"   Convexity Impact: {analysis['convexity_pct']:.1f}% of gross edge")
        
        # Total statistics
        total_ev = sum(r['analysis']['expected_ev_usd'] for r in results[:5])
        total_position = sum(r['analysis']['position_value_usd'] for r in results[:5])
        
        print("\n" + "-" * 80)
        print("PORTFOLIO SUMMARY (Top 5):")
        print(f"  Total Expected EV: ${total_ev:.2f}")
        print(f"  Total Position Value: ${total_position:.2f}")
        print(f"  Expected ROI: {(total_ev/total_position*100):.1f}%" if total_position > 0 else "  Expected ROI: N/A")
    else:
        print("\nNO ACTIONABLE OPPORTUNITIES FOUND")
        print("\nAnalysis:")
        print("• Markets at 100% or 0.1% probability are likely already resolved")
        print("• Trading these would require the outcome to reverse (unlikely)")
        print("• LMSR convexity costs would be extremely high")
        print("• Better to wait for active markets with 70-90% or 10-30% probabilities")
    
    print("\n" + "=" * 80)
    print("LMSR TRADING NOTES:")
    print("=" * 80)
    print("1. CONVEXITY COSTS: High for extreme probabilities (30-50% of edge)")
    print("2. POSITION SIZING: Reduced 30-50% from naive sizing")
    print("3. RISK: Markets at 100%/0.1% may be resolved - high risk of loss")
    print("4. RECOMMENDATION: Wait for 70-90% or 10-30% probability markets")
    print("5. DRY-RUN: No trades executed - analysis only")
    print("=" * 80)
    
    return 0 if results else 1

if __name__ == "__main__":
    sys.exit(main())