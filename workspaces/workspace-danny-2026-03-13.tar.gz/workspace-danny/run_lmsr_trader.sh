#!/bin/bash
# LMSR Trader Runner
# Runs the LMSR-aware trading system with proper environment

cd /home/agent/.openclaw/workspace-danny

# Set API key
export SIMMER_API_KEY="sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

# Run the trader (initially in dry-run mode)
echo "=== LMSR Trader Scan - $(date) ==="
python3 lmsr_trader.py

# Log results
echo "Scan completed at $(date)"
echo "================================="