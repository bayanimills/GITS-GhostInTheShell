#!/usr/bin/env python3
"""
Debug Simmer SDK structure.
"""

import os
from simmer_sdk import SimmerClient

api_key = os.getenv('SIMMER_API_KEY', 'sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe')
client = SimmerClient(api_key=api_key)

print("Testing Simmer SDK structure...")
print("="*60)

# Get a few markets
markets = client.get_markets(limit=3)
print(f"Got {len(markets)} markets")

if markets:
    print("\nFirst market object type:", type(markets[0]))
    print("First market dir():", dir(markets[0]))
    
    print("\nFirst market attributes:")
    market = markets[0]
    
    # Try common attributes
    attrs_to_try = ['id', 'question', 'current_probability', 'outcome_type', 
                   'status', 'ends_at', 'created_at']
    
    for attr in attrs_to_try:
        try:
            value = getattr(market, attr, None)
            print(f"  {attr}: {value}")
        except:
            print(f"  {attr}: <not accessible>")
    
    # Try dict access
    print("\nTrying dict access:")
    try:
        print(f"  market['id']: {market['id']}")
    except:
        print("  market['id']: <dict access not supported>")
        
    # Try as_dict if available
    if hasattr(market, 'as_dict'):
        print("\nUsing as_dict():")
        market_dict = market.as_dict()
        for key in ['id', 'question', 'current_probability', 'outcome_type']:
            if key in market_dict:
                print(f"  {key}: {market_dict[key]}")

print("\n" + "="*60)
print("Summary: Use attribute access (market.id) not dict access (market['id'])")