#!/usr/bin/env python3
"""
LMSR Analysis for 2:59 PM Scan
Advanced filtering and opportunity detection.
"""

import sys
from datetime import datetime, timezone

def analyze_259pm_markets():
    """Analyze current market conditions at 2:59 PM with advanced filtering."""
    
    print("=" * 80)
    print("LMSR DRY-RUN SCAN - 2:59 PM ADVANCED ANALYSIS")
    print("=" * 80)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"Australia/Sydney: Thursday, March 12th, 2026 — 2:59 PM")
    print(f"API Key: sk_live_92983b88e10d... (validated)")
    print()
    
    # From scan results - focusing on diverse market types
    markets = [
        {
            'name': 'Will Trump post "Epstein" on Truth Social this week? (March ...',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'Politics/Social Media',
            'date_note': 'Current week - ACTIVE',
            'resolution_risk': 'HIGH - 100% probability'
        },
        {
            'name': 'OG Anunoby: Points O/U 16.5',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'NBA Player Prop',
            'date_note': 'March 11 game - RESOLVED',
            'resolution_risk': 'DEFINITELY RESOLVED'
        },
        {
            'name': 'Mikal Bridges: Rebounds O/U 4.5',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'NBA Player Prop',
            'date_note': 'March 11 game - RESOLVED',
            'resolution_risk': 'DEFINITELY RESOLVED'
        },
        {
            'name': 'Karl-Anthony Towns: Points O/U 19.5',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'NBA Player Prop',
            'date_note': 'March 11 game - RESOLVED',
            'resolution_risk': 'DEFINITELY RESOLVED'
        },
        {
            'name': 'Kyle Filipowski: Points O/U 13.5',
            'prob': 1.000,
            'action': 'BUY NO',
            'category': 'NBA Player Prop',
            'date_note': 'March 11 game - RESOLVED',
            'resolution_risk': 'DEFINITELY RESOLVED'
        }
    ]
    
    print("ADVANCED MARKET FILTERING")
    print("-" * 80)
    print("Filter 1: Remove definitely resolved markets (100% probability)")
    print("Filter 2: Remove March 11 markets")
    print("Filter 3: Keep markets with 70-95% or 5-30% probability")
    print("Filter 4: Minimum net edge after convexity: 15%")
    print()
    
    filtered_markets = []
    
    for i, market in enumerate(markets, 1):
        print(f"{i}. {market['name'][:60]}...")
        print(f"   Probability: {market['prob']:.1%}")
        print(f"   Action: {market['action']}")
        print(f"   Category: {market['category']}")
        print(f"   Date Status: {market['date_note']}")
        print(f"   Resolution Risk: {market['resolution_risk']}")
        
        # Apply filters
        if market['prob'] >= 0.999:
            filter_result = "❌ FILTERED OUT - Probability 100% (resolved)"
            edge = 0.0
        elif "March 11" in market['date_note'] and market['prob'] > 0.95:
            filter_result = "❌ FILTERED OUT - March 11 market, likely resolved"
            edge = 0.0
        elif market['prob'] >= 0.70 or market['prob'] <= 0.30:
            # Calculate potential edge
            if market['prob'] > 0.5:
                p_true = market['prob'] - (market['prob'] - 0.5) * 0.35  # 35% reversion
            else:
                p_true = market['prob'] + (0.5 - market['prob']) * 0.35  # 35% reversion
            
            gross_edge = abs(p_true - market['prob'])
            
            # Adjust for BUY NO actions
            if market['action'] == 'BUY NO':
                gross_edge = abs((1 - p_true) - (1 - market['prob']))
            
            # Apply convexity cost based on probability
            if market['prob'] > 0.9 or market['prob'] < 0.1:
                convexity_pct = 0.5  # 50% for extreme probabilities
            elif market['prob'] > 0.8 or market['prob'] < 0.2:
                convexity_pct = 0.4  # 40% for high probabilities
            elif market['prob'] > 0.7 or market['prob'] < 0.3:
                convexity_pct = 0.3  # 30% for moderate probabilities
            else:
                convexity_pct = 0.2  # 20% for near-balanced
            
            net_edge = gross_edge * (1 - convexity_pct)
            
            if net_edge >= 0.15:
                filter_result = f"✅ PASSED FILTERS - Net edge: {net_edge:.1%}"
                filtered_markets.append({
                    'market': market,
                    'gross_edge': gross_edge,
                    'net_edge': net_edge,
                    'convexity_pct': convexity_pct,
                    'p_true': p_true
                })
            else:
                filter_result = f"❌ FILTERED OUT - Net edge {net_edge:.1%} < 15%"
        else:
            filter_result = "❌ FILTERED OUT - Probability not in target range"
            edge = 0.0
        
        print(f"   Filter Result: {filter_result}")
        if 'gross_edge' in locals() and gross_edge > 0:
            print(f"   Gross Edge: {gross_edge:.1%} → Net: {net_edge:.1%} (after {convexity_pct:.0%} convexity)")
        print()
    
    print("\n" + "=" * 80)
    print("ACTIONABLE OPPORTUNITIES ANALYSIS")
    print("=" * 80)
    
    if filtered_markets:
        print(f"\n✓ Found {len(filtered_markets)} potentially actionable markets")
        print("\nDetailed Trade Analysis:")
        
        for i, item in enumerate(filtered_markets, 1):
            market = item['market']
            net_edge = item['net_edge']
            gross_edge = item['gross_edge']
            convexity_pct = item['convexity_pct']
            p_true = item['p_true']
            
            # Calculate position sizing with LMSR considerations
            if market['action'] == 'BUY NO':
                p_market_trade = 1 - market['prob']
                p_true_trade = 1 - p_true
            else:
                p_market_trade = market['prob']
                p_true_trade = p_true
            
            # Conservative position sizing
            max_position_usd = 50.0
            base_shares = max_position_usd / p_market_trade if p_market_trade > 0 else 0
            
            # Additional reduction for convexity impact
            convexity_reduction = 0.3  # 30% reduction for convexity
            optimal_shares = base_shares * (1 - convexity_reduction) * 0.8  # Extra 20% safety
            
            position_value = optimal_shares * p_market_trade
            expected_ev = net_edge * optimal_shares * 100  # Convert to USD
            
            print(f"\n{i}. {market['name'][:50]}...")
            print(f"   Action: {market['action']}")
            print(f"   Market Probability: {market['prob']:.1%}")
            print(f"   Model Probability: {p_true:.1%}")
            print(f"   Gross Edge: {gross_edge:.1%}")
            print(f"   Convexity Cost: {convexity_pct:.0%} of gross edge")
            print(f"   Net Edge: {net_edge:.1%} (meets 15% threshold)")
            print(f"   Trade: {market['action']} {optimal_shares:.1f} shares")
            print(f"   Position Cost: ${position_value:.2f}")
            print(f"   Expected EV: ${expected_ev:.2f}")
            print(f"   Expected ROI: {(expected_ev/position_value*100):.1f}%" if position_value > 0 else "   ROI: N/A")
            print(f"   Risk Assessment: MODERATE-HIGH (100% probability)")
        
        # Portfolio summary
        total_cost = sum(item['market']['prob'] * 50 * 0.8 for item in filtered_markets)  # Rough estimate
        total_ev = sum(item['net_edge'] * 50 * 0.8 * 100 for item in filtered_markets)  # Rough estimate
        
        print("\n" + "-" * 80)
        print("PORTFOLIO SUMMARY (Estimated):")
        print(f"  Total Investment: ${total_cost:.2f}")
        print(f"  Total Expected EV: ${total_ev:.2f}")
        print(f"  Expected Portfolio ROI: {(total_ev/total_cost*100):.1f}%" if total_cost > 0 else "  ROI: N/A")
        print(f"  Average Net Edge: {sum(item['net_edge'] for item in filtered_markets)/len(filtered_markets):.1%}")
        
    else:
        print("\n✗ NO ACTIONABLE OPPORTUNITIES FOUND")
        print("\nDetailed Analysis of Filter Results:")
        print("1. Trump Truth Social Market (100% probability):")
        print("   • Filtered: Probability 100% suggests market view is certain")
        print("   • Risk: Trading against 100% consensus is extremely risky")
        print("   • Edge: Likely 0% after accounting for market certainty")
        
        print("\n2. NBA Player Prop Markets (100% probability, March 11):")
        print("   • Filtered: Games from yesterday, outcomes known")
        print("   • These are definitely resolved markets")
        print("   • Trading would be betting against known outcomes")
        
        print("\n3. Current Market Environment:")
        print("   • High proportion of 100% probability markets")
        print("   • Indicates many resolved/near-resolution markets")
        print("   • Need markets with probabilities in 70-95% range")
        
        print("\n4. Edge Calculation Reality Check:")
        print("   • Market at 100%: True probability ≈ 100%")
        print("   • Gross edge if reverts to 50%: 50% (theoretical)")
        print("   • Realistic edge: 0-5% (market likely correct)")
        print("   • After convexity (50%): 0-2.5% (<15% threshold)")
    
    print("\n" + "=" * 80)
    print("SPECIAL ANALYSIS: TRUMP TRUTH SOCIAL MARKET")
    print("=" * 80)
    
    print("\nMarket: Will Trump post 'Epstein' on Truth Social this week?")
    print("Current Probability: 100.0%")
    print("Market Interpretation: Traders believe Trump WILL NOT post 'Epstein'")
    print("\nAnalysis:")
    print("• 100% probability means market consensus is CERTAIN")
    print("• Trading BUY NO = betting Trump won't post (agreeing with consensus)")
    print("• Trading BUY YES = betting Trump will post (against consensus)")
    print("• Edge calculation depends on actual probability Trump posts")
    
    print("\nRealistic Edge Assessment:")
    print("• If true probability Trump posts: 5%")
    print("• Market probability he won't post: 100%")
    print("• True probability he won't post: 95%")
    print("• Edge for BUY NO: -5% (negative edge)")
    print("• Expected EV: NEGATIVE")
    
    print("\n" + "=" * 80)
    print("TRADING DECISION & RISK ASSESSMENT")
    print("=" * 80)
    
    if filtered_markets:
        print("\n⚠️ CONDITIONAL RECOMMENDATION: EXTREME CAUTION")
        print("\nConcerns:")
        print("1. 100% probability markets are unusual")
        print("2. May indicate data issues or resolved markets")
        print("3. Trading against 100% consensus is extremely risky")
        print("4. True edge likely much lower than calculated")
        
        print("\nIf Trading (High Risk):")
        print("• Maximum position: $10 (80% reduction from normal)")
        print("• Stop-loss: Exit if any probability movement")
        print("• Only trade if you have strong contrary evidence")
        print("• Be prepared for 100% loss")
    else:
        print("\n🔴 RECOMMENDATION: DO NOT TRADE")
        print("\nPrimary Reasons:")
        print("1. All identified markets show 100% probability")
        print("2. High likelihood these are resolved markets")
        print("3. Trading resolved markets = guaranteed loss")
        print("4. No edge possible in certain outcomes")
        
        print("\nSystem Issue Identified:")
        print("• Scanner detecting resolved markets as 'active'")
        print("• Need to filter out 100% probability markets")
        print("• Need date-based filtering for past events")
        print("• API may be returning resolving markets")
    
    print("\n" + "=" * 80)
    print("IMMEDIATE ACTIONS & NEXT STEPS")
    print("=" * 80)
    
    print("\n1. Scanner Improvements (Required):")
    print("   • Add filter: Exclude probability >99%")
    print("   • Add filter: Exclude March 11 markets")
    print("   • Add filter: Minimum probability 5%, maximum 95%")
    print("   • Add market creation date tracking")
    
    print("\n2. Next Scan Timing:")
    print("   • Wait for new market creation (3:00-4:00 PM AEST)")
    print("   • Focus on March 12 markets only")
    print("   • Target probabilities: 70-90% or 10-30%")
    
    print("\n3. Risk Management:")
    print("   • Never trade 100% probability markets")
    print("   • Verify market dates before trading")
    print("   • Start with $10 test positions only")
    print("   • Implement strict stop-losses")
    
    print("\n" + "=" * 80)
    print("FINAL VERDICT")
    print("=" * 80)
    print("DRY-RUN STATUS: COMPLETE")
    print("TRADES EXECUTED: 0")
    print("DECISION: DO NOT TRADE - 100% PROBABILITY MARKETS")
    print("ISSUE: Scanner detecting resolved markets")
    print("ACTION: Improve filters, rescan at 3:30 PM")
    print("=" * 80)
    
    return 0

if __name__ == "__main__":
    sys.exit(analyze_259pm_markets())