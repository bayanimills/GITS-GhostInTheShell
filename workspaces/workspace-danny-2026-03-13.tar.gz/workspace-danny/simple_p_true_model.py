#!/usr/bin/env python3
"""
Simple p_true model using FinTool data.
This is your starting point for building sophisticated probability models.
"""

import os
import json
import subprocess
from typing import Dict, List, Optional
from datetime import datetime

class FinToolClient:
    """Wrapper for FinTool CLI commands."""
    
    def __init__(self, scripts_dir: str = None):
        self.scripts_dir = scripts_dir or "/home/agent/.openclaw/skills/fintool/scripts"
        
    def run_command(self, cmd: str, args: List[str]) -> Dict:
        """Run a FinTool command and return JSON output."""
        # Build JSON command
        if cmd == "fintool":
            if args[0] == "quote":
                json_cmd = json.dumps({"command": "quote", "symbol": args[1]})
            elif args[0] == "news":
                json_cmd = json.dumps({"command": "news", "symbol": args[1]})
            else:
                return {"error": f"Unsupported fintool command: {args[0]}"}
        elif cmd == "polymarket":
            if args[0] == "list":
                json_cmd = json.dumps({
                    "command": "list",
                    "query": args[2] if len(args) > 2 else "",
                    "limit": int(args[4]) if len(args) > 4 else 10
                })
            elif args[0] == "quote":
                json_cmd = json.dumps({"command": "quote", "market": args[1]})
            else:
                return {"error": f"Unsupported polymarket command: {args[0]}"}
        else:
            return {"error": f"Unsupported command: {cmd}"}
        
        full_cmd = [os.path.join(self.scripts_dir, cmd), "--json", json_cmd]
        
        try:
            result = subprocess.run(
                full_cmd,
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                return {"error": result.stderr}
                
        except Exception as e:
            return {"error": str(e)}
    
    def get_quote(self, symbol: str) -> Dict:
        """Get enriched quote with trend analysis."""
        return self.run_command("fintool", ["quote", symbol])
    
    def get_news(self, symbol: str) -> Dict:
        """Get latest news headlines."""
        return self.run_command("fintool", ["news", symbol])
    
    def list_markets(self, query: str = "", limit: int = 10) -> Dict:
        """List Polymarket prediction markets."""
        args = ["list"]
        if query:
            args.extend(["--query", query])
        if limit:
            args.extend(["--limit", str(limit)])
        
        return self.run_command("polymarket", args)
    
    def get_market_quote(self, market_id: str) -> Dict:
        """Get Polymarket market details."""
        return self.run_command("polymarket", ["quote", market_id])


class SimpleProbabilityModel:
    """
    Simple p_true model using FinTool data.
    This is where you start building your edge.
    """
    
    def __init__(self, fin_tool: FinToolClient):
        self.fin_tool = fin_tool
        
    def extract_topic_keywords(self, market_question: str) -> List[str]:
        """Extract keywords from market question."""
        # Simple keyword extraction
        keywords = []
        
        # Common topics
        topics = {
            'bitcoin': ['bitcoin', 'btc', 'crypto'],
            'ethereum': ['ethereum', 'eth', 'crypto'],
            'tesla': ['tesla', 'tsla', 'elon', 'musk'],
            'weather': ['temperature', 'weather', '°C', '°F'],
            'sports': ['vs', 'win', 'match', 'game', 'team'],
            'politics': ['election', 'president', 'congress', 'senate'],
            'tech': ['apple', 'google', 'meta', 'openai', 'gpt']
        }
        
        question_lower = market_question.lower()
        for topic, words in topics.items():
            if any(word in question_lower for word in words):
                keywords.append(topic)
                
        return keywords if keywords else ['general']
    
    def get_related_data(self, keywords: List[str]) -> Dict:
        """Get related market data for keywords."""
        data = {}
        
        for keyword in keywords:
            if keyword == 'bitcoin':
                data['btc_quote'] = self.fin_tool.get_quote('BTC')
                data['btc_news'] = self.fin_tool.get_news('BTC')
            elif keyword == 'ethereum':
                data['eth_quote'] = self.fin_tool.get_quote('ETH')
                data['eth_news'] = self.fin_tool.get_news('ETH')
            elif keyword == 'tesla':
                data['tsla_quote'] = self.fin_tool.get_quote('TSLA')
                data['tsla_news'] = self.fin_tool.get_news('TSLA')
            elif keyword == 'weather':
                # Weather markets often correlate with energy
                data['oil_quote'] = self.fin_tool.get_quote('OIL')
                data['natgas_quote'] = self.fin_tool.get_quote('NATGAS')
            elif keyword == 'general':
                # General market sentiment
                data['sp500_quote'] = self.fin_tool.get_quote('SP500')
                data['vix_quote'] = self.fin_tool.get_quote('VIX')
                
        return data
    
    def analyze_sentiment(self, data: Dict) -> float:
        """Simple sentiment analysis from data."""
        sentiment = 0.0
        weight = 0.0
        
        for key, value in data.items():
            if 'quote' in key and isinstance(value, dict):
                # Check trend from quote
                trend = value.get('trend', '')
                if trend == 'bullish':
                    sentiment += 0.3
                elif trend == 'bearish':
                    sentiment -= 0.3
                weight += 1.0
                
                # Check price change
                change = value.get('change_24h_pct', 0)
                sentiment += change * 0.01  # Scale: 1% change = 0.01 sentiment
                weight += 0.5
        
        # Normalize
        if weight > 0:
            sentiment = sentiment / weight
            
        return max(-1.0, min(1.0, sentiment))
    
    def calculate_p_true(self, market_question: str, p_market: float) -> float:
        """
        Calculate p_true using simple model.
        This is your starting point - improve this!
        """
        # Step 1: Extract keywords
        keywords = self.extract_topic_keywords(market_question)
        
        # Step 2: Get related data
        data = self.get_related_data(keywords)
        
        # Step 3: Analyze sentiment
        sentiment = self.analyze_sentiment(data)
        
        # Step 4: Calculate p_true adjustment
        # sentiment = +0.2 → increase probability by 10%
        # sentiment = -0.2 → decrease probability by 10%
        adjustment = sentiment * 0.5
        
        # Step 5: Apply mean reversion for extreme markets
        if p_market > 0.7:
            # Market overconfident, revert toward 50%
            mean_reversion = 0.6 - p_market
            adjustment += mean_reversion * 0.3
        elif p_market < 0.3:
            # Market underconfident, revert toward 50%
            mean_reversion = 0.4 - p_market
            adjustment += mean_reversion * 0.3
        
        # Calculate p_true
        p_true = p_market + adjustment
        
        # Bound between 0.01 and 0.99
        return max(0.01, min(0.99, p_true))
    
    def calculate_edge(self, market_question: str, p_market: float) -> float:
        """Calculate edge: p_true - p_market."""
        p_true = self.calculate_p_true(market_question, p_market)
        return p_true - p_market


def main():
    """Test the simple probability model."""
    print("="*70)
    print("SIMPLE p_true MODEL TEST")
    print("Using FinTool for market intelligence")
    print("="*70)
    
    # Initialize FinTool client
    fin_tool = FinToolClient()
    
    # Test FinTool connection
    print("\n1. Testing FinTool connection...")
    btc_quote = fin_tool.get_quote("BTC")
    
    if 'error' in btc_quote:
        print(f"   ❌ Error: {btc_quote['error']}")
        print("\n   Make sure to configure ~/.fintool/config.toml")
        return
    else:
        print(f"   ✅ Connected!")
        price = btc_quote.get('price')
        if isinstance(price, (int, float)):
            print(f"   BTC price: ${price:,.2f}")
        else:
            print(f"   BTC price: {price}")
        print(f"   Trend: {btc_quote.get('trend', 'N/A')}")
    
    # Initialize probability model
    model = SimpleProbabilityModel(fin_tool)
    
    # Test cases
    test_cases = [
        {
            "question": "Will Bitcoin reach $100,000 by June 2026?",
            "p_market": 0.45
        },
        {
            "question": "Will Tesla stock close above $300 on March 31, 2026?",
            "p_market": 0.55
        },
        {
            "question": "Will the highest temperature in Miami be 90°F or higher on March 13?",
            "p_market": 0.25
        },
        {
            "question": "Will there be a major earthquake (>7.0) in California by EOY 2026?",
            "p_market": 0.18
        }
    ]
    
    print("\n2. Testing probability model...")
    print("-"*70)
    
    for i, test in enumerate(test_cases, 1):
        question = test["question"]
        p_market = test["p_market"]
        
        # Calculate p_true and edge
        p_true = model.calculate_p_true(question, p_market)
        edge = p_true - p_market
        
        print(f"\n{i}. {question[:60]}...")
        print(f"   Market: {p_market:.1%} → Model: {p_true:.1%}")
        print(f"   Edge: {edge:+.2%}")
        
        if abs(edge) > 0.05:
            print(f"   📈 SIGNIFICANT EDGE FOUND!")
            print(f"   Trade: {'BUY YES' if edge > 0 else 'BUY NO'}")
        else:
            print(f"   ⚠️  Small edge, consider passing")
    
    print("\n" + "="*70)
    print("NEXT STEPS:")
    print("1. Configure ~/.fintool/config.toml with your wallet key")
    print("2. Add OpenAI API key for better sentiment analysis")
    print("3. Improve the probability model with more data sources")
    print("4. Test with real Polymarket data")
    print("5. Integrate with LMSR trading system")
    print("="*70)


if __name__ == "__main__":
    main()