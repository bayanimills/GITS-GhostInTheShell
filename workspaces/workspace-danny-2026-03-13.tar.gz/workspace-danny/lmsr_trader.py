#!/usr/bin/env python3
"""
LMSR-Aware Polymarket Trader
Implements Bayani's LMSR insights:
- EV = p_true - p_market
- Accounts for convexity cost (slippage)
- Optimal position sizing
"""

import os
import json
import math
from typing import Dict, List, Tuple, Optional
import requests
from datetime import datetime

# Simmer SDK
try:
    from simmer_sdk import SimmerClient
    SIMMER_AVAILABLE = True
except ImportError:
    SIMMER_AVAILABLE = False
    print("Warning: simmer_sdk not installed. Install with: pip install simmer-sdk")

class LMSRTrader:
    """
    LMSR-aware trading system for Polymarket.
    
    Key insights:
    1. Market uses LMSR: C(q) = b × ln(∑ e^(qi/b))
    2. Price function: p_k(q) = e^(qk/b) / ∑ e^(qi/b) (softmax)
    3. Edge: EV = p_true - p_market
    4. Convexity cost: Your trade moves price against you
    """
    
    def __init__(self, api_key: str, liquidity_parameter: float = 100.0):
        """
        Initialize trader.
        
        Args:
            api_key: Simmer API key
            liquidity_parameter: LMSR 'b' parameter (higher = more liquidity)
        """
        self.api_key = api_key
        self.b = liquidity_parameter  # LMSR liquidity parameter
        
        if SIMMER_AVAILABLE:
            self.client = SimmerClient(api_key=api_key)
        else:
            self.client = None
            
        # Trading parameters
        self.min_edge = 0.05  # Minimum edge (5%)
        self.max_position_usd = 50.0  # Max position size in USD
        self.convexity_buffer = 0.1  # Buffer for convexity cost (10%)
        
    def calculate_lmsr_price(self, quantities: List[float], outcome_index: int) -> float:
        """
        Calculate LMSR price for a specific outcome.
        
        Args:
            quantities: List of quantities for each outcome
            outcome_index: Index of outcome to price
            
        Returns:
            Price (probability) for the outcome
        """
        if self.b <= 0:
            raise ValueError("Liquidity parameter b must be positive")
            
        # LMSR price formula: p_k = e^(qk/b) / ∑ e^(qi/b)
        exponents = [q / self.b for q in quantities]
        max_exp = max(exponents)  # For numerical stability
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        
        if sum_exp == 0:
            return 1.0 / len(quantities)  # Equal probability if all zero
            
        return exp_terms[outcome_index] / sum_exp
    
    def calculate_convexity_cost(self, current_quantities: List[float], 
                                outcome_index: int, shares: float) -> float:
        """
        Estimate convexity cost (slippage) for buying shares.
        
        Args:
            current_quantities: Current market quantities
            outcome_index: Outcome to buy
            shares: Number of shares to buy
            
        Returns:
            Estimated convexity cost in probability units
        """
        # Price before trade
        price_before = self.calculate_lmsr_price(current_quantities, outcome_index)
        
        # Quantities after trade
        quantities_after = current_quantities.copy()
        quantities_after[outcome_index] += shares
        
        # Price after trade
        price_after = self.calculate_lmsr_price(quantities_after, outcome_index)
        
        # Convexity cost = average price increase per share
        # In LMSR, price increases as you buy (convexity)
        return (price_after - price_before) * shares
    
    def calculate_optimal_position(self, p_true: float, p_market: float,
                                 current_quantities: List[float],
                                 outcome_index: int) -> Tuple[float, float]:
        """
        Calculate optimal position size considering convexity cost.
        
        Args:
            p_true: Your model's true probability
            p_market: Current market probability
            current_quantities: Current market quantities
            outcome_index: Outcome index
            
        Returns:
            Tuple of (optimal_shares, expected_ev)
        """
        if p_true <= p_market:
            return 0.0, 0.0  # No edge
            
        # Initial edge per share
        edge_per_share = p_true - p_market
        
        # Start with naive position (ignoring convexity)
        naive_shares = self.max_position_usd / p_market if p_market > 0 else 0
        
        # Binary search for optimal position
        low, high = 0.0, naive_shares
        best_shares = 0.0
        best_ev = 0.0
        
        for _ in range(20):  # 20 iterations for precision
            mid = (low + high) / 2
            
            # Calculate total EV at this position
            gross_ev = edge_per_share * mid
            convexity_cost = self.calculate_convexity_cost(
                current_quantities, outcome_index, mid
            )
            net_ev = gross_ev - convexity_cost
            
            # Calculate EV at slightly larger position
            test_shares = mid * 1.01
            test_gross_ev = edge_per_share * test_shares
            test_convexity_cost = self.calculate_convexity_cost(
                current_quantities, outcome_index, test_shares
            )
            test_net_ev = test_gross_ev - test_convexity_cost
            
            # Check if increasing position increases EV
            if test_net_ev > net_ev:
                low = mid  # Can increase position
                best_shares = test_shares
                best_ev = test_net_ev
            else:
                high = mid  # Should decrease position
                
        # Apply convexity buffer
        optimal_shares = best_shares * (1 - self.convexity_buffer)
        
        # Recalculate EV with buffer
        gross_ev = edge_per_share * optimal_shares
        convexity_cost = self.calculate_convexity_cost(
            current_quantities, outcome_index, optimal_shares
        )
        final_ev = gross_ev - convexity_cost
        
        return optimal_shares, final_ev
    
    def find_trading_opportunities(self, markets: List) -> List[Dict]:
        """
        Find markets with significant edge.
        
        Args:
            markets: List of Market objects from Simmer
            
        Returns:
            List of trading opportunities
        """
        opportunities = []
        
        for market in markets:
            # Skip if no probability data
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            # Get market probability
            p_market = market.current_probability
            
            # TODO: Implement your probability model here
            # This is where your edge comes from!
            # For now, using a simple mean-reversion model
            
            # Strategy 1: Mean reversion (crowd tends to overreact)
            if p_market > 0.7:
                p_true = 0.6  # Crowd too bullish, true prob lower
            elif p_market < 0.3:
                p_true = 0.4  # Crowd too bearish, true prob higher
            else:
                # For balanced markets, look for small edges
                # Example: if market is 45-55%, assume slight mispricing
                if p_market > 0.5:
                    p_true = p_market - 0.05  # Slight correction down
                elif p_market < 0.5:
                    p_true = p_market + 0.05  # Slight correction up
                else:
                    continue  # Exactly 50%, no edge
                
            # Calculate edge
            edge = p_true - p_market
            if abs(edge) < self.min_edge:
                continue
                
            # Get market quantities (simplified - in reality need from API)
            # For binary markets, assume liquidity based on probability
            # Higher probability outcomes have more liquidity
            base_liquidity = 100.0
            current_quantities = [
                base_liquidity * p_market,      # YES liquidity
                base_liquidity * (1 - p_market) # NO liquidity
            ]
            
            # Calculate optimal position
            outcome_index = 0 if edge > 0 else 1  # Buy YES if p_true > p_market
            shares, expected_ev = self.calculate_optimal_position(
                abs(p_true), abs(p_market), current_quantities, outcome_index
            )
            
            if shares > 0 and expected_ev > 0:
                opportunities.append({
                    'market_id': market.id,
                    'market_question': market.question[:100] if hasattr(market, 'question') else 'Unknown',
                    'p_market': p_market,
                    'p_true': p_true,
                    'edge': edge,
                    'optimal_shares': shares,
                    'expected_ev_usd': expected_ev * 100,  # Convert to USD (per share = $1)
                    'outcome': 'YES' if outcome_index == 0 else 'NO'
                })
                
        # Sort by expected EV
        opportunities.sort(key=lambda x: x['expected_ev_usd'], reverse=True)
        return opportunities
    
    def execute_trade(self, market_id: str, outcome: str, shares: float, 
                     dry_run: bool = True) -> Dict:
        """
        Execute a trade through Simmer.
        
        Args:
            market_id: Market ID
            outcome: 'YES' or 'NO'
            shares: Number of shares to buy
            dry_run: If True, don't actually trade
            
        Returns:
            Trade result
        """
        if not SIMMER_AVAILABLE or self.client is None:
            return {'error': 'Simmer SDK not available'}
            
        try:
            # Get market context first
            context = self.client.get_market_context(market_id)
            
            # Prepare trade
            trade_data = {
                'market_id': market_id,
                'outcome': outcome,
                'shares': shares,
                'dry_run': dry_run
            }
            
            # Execute trade
            if not dry_run:
                # Note: Actual trade method depends on Simmer SDK version
                # This is a placeholder - adjust based on actual SDK
                result = self.client._request('POST', '/api/sdk/trade', json=trade_data)
            else:
                result = {'status': 'dry_run', 'trade': trade_data}
                
            return result
            
        except Exception as e:
            return {'error': str(e)}
    
    def run_scan(self, dry_run: bool = True) -> Dict:
        """
        Run a complete scan and trade cycle.
        
        Args:
            dry_run: If True, don't execute trades
            
        Returns:
            Scan results
        """
        if not SIMMER_AVAILABLE or self.client is None:
            return {'error': 'Simmer SDK not available'}
            
        try:
            # Fetch markets
            markets = self.client.get_markets(limit=100, status='active')
            
            # Find opportunities
            opportunities = self.find_trading_opportunities(markets)
            
            # Execute trades
            trades = []
            for opp in opportunities[:3]:  # Limit to top 3 opportunities
                trade_result = self.execute_trade(
                    opp['market_id'],
                    opp['outcome'],
                    opp['optimal_shares'],
                    dry_run=dry_run
                )
                
                trades.append({
                    'opportunity': opp,
                    'result': trade_result
                })
                
            return {
                'timestamp': datetime.now().isoformat(),
                'markets_scanned': len(markets),
                'opportunities_found': len(opportunities),
                'trades_executed': len(trades),
                'opportunities': opportunities[:10],  # Top 10
                'trades': trades
            }
            
        except Exception as e:
            return {'error': str(e), 'timestamp': datetime.now().isoformat()}


def main():
    """Main function for testing."""
    # Get API key from environment
    api_key = os.getenv('SIMMER_API_KEY')
    
    if not api_key:
        print("Error: SIMMER_API_KEY environment variable not set")
        print("Set it with: export SIMMER_API_KEY='your_key_here'")
        return
    
    # Initialize trader
    trader = LMSRTrader(api_key=api_key, liquidity_parameter=100.0)
    
    # Run scan in dry-run mode
    print("Running LMSR-aware scan (dry-run mode)...")
    results = trader.run_scan(dry_run=True)
    
    # Print results
    print("\n" + "="*60)
    print("LMSR TRADING SCAN RESULTS")
    print("="*60)
    
    if 'error' in results:
        print(f"Error: {results['error']}")
        return
        
    print(f"Markets scanned: {results['markets_scanned']}")
    print(f"Opportunities found: {results['opportunities_found']}")
    print(f"Trades executed (dry-run): {results['trades_executed']}")
    
    if results['opportunities']:
        print(f"\nTOP {len(results['opportunities'])} OPPORTUNITIES:")
        for i, opp in enumerate(results['opportunities'], 1):
            print(f"\n{i}. {opp['market_question']}")
            print(f"   Market: {opp['p_market']:.1%} | Model: {opp['p_true']:.1%}")
            print(f"   Edge: {opp['edge']:+.1%} | Shares: {opp['optimal_shares']:.1f}")
            print(f"   Expected EV: ${opp['expected_ev_usd']:.2f}")
            print(f"   Trade: BUY {opp['outcome']} @ {opp['optimal_shares']:.1f} shares")
            
        # Summary statistics
        total_ev = sum(opp['expected_ev_usd'] for opp in results['opportunities'])
        avg_edge = sum(opp['edge'] for opp in results['opportunities']) / len(results['opportunities'])
        print(f"\nSummary:")
        print(f"  Total expected EV: ${total_ev:.2f}")
        print(f"  Average edge: {avg_edge:+.1%}")
        print(f"  Best edge: {max(opp['edge'] for opp in results['opportunities']):+.1%}")
    else:
        print("\nNo trading opportunities found.")
    
    print("\n" + "="*60)
    print("To enable live trading:")
    print("1. Review and refine the probability model (p_true calculation)")
    print("2. Adjust min_edge and max_position_usd parameters")
    print("3. Set dry_run=False in trader.run_scan()")
    print("="*60)


if __name__ == "__main__":
    main()