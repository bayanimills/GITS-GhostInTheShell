# Installing FinTool for LMSR Probability Models

## **Step 1: Install as OpenClaw Skill**
```bash
# Tell your OpenClaw agent to install the skill
Read https://raw.githubusercontent.com/second-state/fintool/refs/heads/main/skills/install.md and install the fintool skill.
```

## **Step 2: Configuration**
Create `~/.fintool/config.toml`:
```toml
[wallet]
private_key = "0x..."  # Your Ethereum private key

[api_keys]
openai_api_key = "sk-..."  # Optional: for LLM-enriched analysis

[polymarket]
signature_type = "proxy"  # Default
```

## **Step 3: Test Installation**
```bash
# Test market intelligence
fintool quote BTC
fintool news ETH
fintool report annual AAPL

# Test Polymarket integration
polymarket list --query "bitcoin" --limit 5
polymarket quote will-bitcoin-hit-100k
```

## **Step 4: Build Probability Models**

### **Model 1: News Sentiment Analysis**
```python
def p_true_from_news(market_topic):
    # Get news for related symbols
    news = fintool.news(get_related_symbols(market_topic))
    
    # Analyze sentiment using LLM
    sentiment = analyze_sentiment(news)
    
    # Convert sentiment to probability adjustment
    p_adjustment = sentiment_to_probability(sentiment)
    
    return p_market + p_adjustment
```

### **Model 2: Cross-Market Correlation**
```python
def p_true_from_correlation(market):
    # Get prices of correlated assets
    btc_price = fintool.quote("BTC")['price']
    sp500_trend = fintool.quote("SP500")['trend']
    vix_level = fintool.quote("VIX")['price']
    
    # Calculate correlation-based probability
    correlation_factor = calculate_correlation_factor(
        btc_price, sp500_trend, vix_level
    )
    
    return p_market * correlation_factor
```

### **Model 3: Fundamental Analysis (for stock/company markets)**
```python
def p_true_from_fundamentals(company_market):
    # Get SEC filings
    annual_report = fintool.report_annual(company_symbol)
    quarterly_report = fintool.report_quarterly(company_symbol)
    
    # Extract key metrics
    revenue_growth = extract_revenue_growth(annual_report)
    profit_margin = extract_profit_margin(quarterly_report)
    
    # Calculate fundamental score
    fundamental_score = calculate_fundamental_score(
        revenue_growth, profit_margin
    )
    
    return fundamental_score_to_probability(fundamental_score)
```

## **Step 5: Integrate with LMSR Trader**
```python
class SophisticatedLMSRTrader:
    def __init__(self):
        self.models = [
            NewsSentimentModel(),
            CrossMarketCorrelationModel(),
            FundamentalAnalysisModel(),
            TechnicalAnalysisModel(),
            SocialSentimentModel()
        ]
    
    def calculate_p_true(self, market):
        # Get predictions from all models
        predictions = [model.predict(market) for model in self.models]
        
        # Weight models based on historical accuracy
        weights = self.get_model_weights()
        
        # Weighted average
        p_true = sum(p * w for p, w in zip(predictions, weights))
        
        return p_true
    
    def get_edge(self, market):
        p_market = market.current_probability
        p_true = self.calculate_p_true(market)
        
        # LMSR-aware edge calculation
        edge = p_true - p_market
        convexity_adjusted_edge = self.adjust_for_convexity(edge)
        
        return convexity_adjusted_edge
```

## **Step 6: Start Small & Iterate**
1. **Week 1:** Install FinTool, test data feeds
2. **Week 2:** Build 1-2 simple probability models
3. **Week 3:** Backtest models on historical data
4. **Week 4:** Deploy best model with small positions
5. **Month 2:** Add more sophisticated models
6. **Month 3:** Scale position sizes

## **Key Advantages of FinTool:**
1. **Real-time data:** Live prices, news, SEC filings
2. **Multi-source aggregation:** Reduces data bias
3. **LLM integration:** For sophisticated analysis
4. **Built for agents:** JSON mode for programmatic use
5. **Exchange integration:** Direct trading capability
6. **Open source:** Can customize and extend

## **Your Edge = Your Models**
The LMSR mechanism gives you the framework. FinTool gives you the data. **Your probability models give you the edge.**