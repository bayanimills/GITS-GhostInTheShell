#!/usr/bin/env python3
"""
Improved LMSR Trader with better filtering and probability models.
"""

import os
import json
import math
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timezone
from simmer_sdk import SimmerClient

class ImprovedLMSRTrader:
    """
    Improved LMSR trader with multiple probability models.
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.client = SimmerClient(api_key=api_key)
        
        # Trading parameters
        self.min_edge = 0.08  # 8% minimum edge
        self.max_position_usd = 20.0  # Conservative position sizing
        self.liquidity_param = 100.0  # LMSR b parameter
        
        # Market filters
        self.min_probability = 0.05  # 5% minimum
        self.max_probability = 0.95  # 95% maximum
        self.min_time_to_resolve_hours = 1.0  # At least 1 hour to resolve
        
    def filter_valid_markets(self, markets: List) -> List:
        """Filter out invalid/expired markets."""
        valid_markets = []
        now = datetime.now(timezone.utc)
        
        for market in markets:
            # Skip if no probability
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            p = market.current_probability
            
            # Skip extreme probabilities (likely data errors or settled markets)
            if p < self.min_probability or p > self.max_probability:
                continue
                
            # Skip if no resolution time
            if not hasattr(market, 'resolves_at') or market.resolves_at is None:
                continue
                
            # Check time to resolution
            try:
                resolves_at = datetime.fromisoformat(market.resolves_at.replace('Z', '+00:00'))
                time_to_resolve = (resolves_at - now).total_seconds() / 3600
                
                if time_to_resolve < self.min_time_to_resolve_hours:
                    continue  # Too close to resolution
            except:
                continue  # Can't parse time
                
            valid_markets.append(market)
            
        return valid_markets
    
    def calculate_probability_models(self, market) -> List[float]:
        """
        Calculate multiple probability estimates.
        Returns: [p_market, p_model1, p_model2, ...]
        """
        p_market = market.current_probability
        
        # Model 1: Mean reversion (crowd overreacts)
        # If market is extreme, revert toward 50%
        if p_market > 0.7:
            p_mean_rev = 0.6 + (p_market - 0.7) * 0.2  # Partial reversion
        elif p_market < 0.3:
            p_mean_rev = 0.4 - (0.3 - p_market) * 0.2  # Partial reversion
        else:
            p_mean_rev = 0.5  # Balanced markets tend to 50%
            
        # Model 2: Momentum (trend continuation)
        # If we had historical data, we'd use it here
        # For now, assume slight momentum
        p_momentum = p_market * 0.9 + 0.5 * 0.1  # Slight regression to mean
        
        # Model 3: Market microstructure (liquidity effects)
        # Thinly traded markets may have distorted prices
        # Assume more efficient markets are closer to true value
        p_micro = p_market  # Placeholder - would need volume data
        
        return [p_market, p_mean_rev, p_momentum, p_micro]
    
    def calculate_lmsr_impact(self, p_current: float, shares: float, buy_yes: bool = True) -> float:
        """
        Estimate price impact using LMSR formula.
        Simplified version for binary markets.
        """
        # Convert to quantities (simplified)
        # For binary market with probability p, approximate quantities as:
        # q_yes = b * ln(p / (1-p))  [inverse of softmax]
        b = self.liquidity_param
        
        if p_current <= 0 or p_current >= 1:
            return p_current  # Edge case
            
        # Current implied quantities
        q_yes = b * math.log(p_current / (1 - p_current))
        q_no = 0  # Reference point
        
        # Add shares
        if buy_yes:
            q_yes += shares
        else:
            q_no += shares
            
        # New probability
        new_p = math.exp(q_yes / b) / (math.exp(q_yes / b) + math.exp(q_no / b))
        
        return new_p
    
    def calculate_optimal_position(self, p_true: float, p_market: float) -> Tuple[float, float]:
        """
        Calculate optimal position considering convexity.
        """
        edge = p_true - p_market
        
        if edge <= 0:
            return 0.0, 0.0
            
        # Estimate convexity cost
        # For small positions, cost ≈ edge² / (2 * liquidity)
        liquidity = self.liquidity_param
        convexity_cost = (edge ** 2) / (2 * liquidity)
        
        # Effective edge after convexity
        effective_edge = edge - convexity_cost
        
        if effective_edge <= 0:
            return 0.0, 0.0
            
        # Position size (in shares)
        # Convert USD to shares: shares = USD / price
        price_per_share = p_market  # For YES shares
        max_shares = self.max_position_usd / price_per_share if price_per_share > 0 else 0
        
        # Optimal shares (simplified Kelly-like)
        # kelly_fraction = edge / price
        kelly_fraction = effective_edge / price_per_share
        optimal_shares = min(max_shares * 0.1,  # Conservative: 10% of max
                           kelly_fraction * self.max_position_usd / price_per_share)
        
        # Expected value
        expected_ev = optimal_shares * effective_edge * 100  # Convert to USD
        
        return optimal_shares, expected_ev
    
    def find_best_opportunities(self, markets: List, top_n: int = 10) -> List[Dict]:
        """Find the best trading opportunities."""
        opportunities = []
        
        for market in markets:
            # Calculate probability estimates
            probabilities = self.calculate_probability_models(market)
            p_market = probabilities[0]
            
            # Try each model
            for i, p_model in enumerate(probabilities[1:], 1):
                edge = p_model - p_market
                
                if abs(edge) < self.min_edge:
                    continue
                    
                # Determine trade direction
                buy_yes = edge > 0
                outcome = 'YES' if buy_yes else 'NO'
                
                # Calculate optimal position
                shares, expected_ev = self.calculate_optimal_position(
                    abs(p_model), abs(p_market)
                )
                
                if shares <= 0 or expected_ev <= 0:
                    continue
                    
                # Estimate price impact
                p_after = self.calculate_lmsr_impact(p_market, shares, buy_yes)
                price_impact = (p_after - p_market) * 100  # Percentage points
                
                opportunities.append({
                    'market_id': market.id,
                    'question': market.question[:80] + '...' if len(market.question) > 80 else market.question,
                    'p_market': p_market,
                    'p_model': p_model,
                    'model_name': ['Mean Reversion', 'Momentum', 'Microstructure'][i-1],
                    'edge': edge,
                    'shares': shares,
                    'expected_ev_usd': expected_ev,
                    'price_impact_pct': price_impact,
                    'outcome': outcome,
                    'resolves_at': market.resolves_at if hasattr(market, 'resolves_at') else 'Unknown'
                })
        
        # Sort by expected EV
        opportunities.sort(key=lambda x: x['expected_ev_usd'], reverse=True)
        return opportunities[:top_n]
    
    def run_scan(self, dry_run: bool = True) -> Dict:
        """Run a complete scan."""
        try:
            # Fetch markets
            print("Fetching markets...")
            all_markets = self.client.get_markets(limit=200, status='active')
            print(f"Found {len(all_markets)} total markets")
            
            # Filter valid markets
            valid_markets = self.filter_valid_markets(all_markets)
            print(f"After filtering: {len(valid_markets)} valid markets")
            
            if not valid_markets:
                return {'error': 'No valid markets found'}
            
            # Find opportunities
            opportunities = self.find_best_opportunities(valid_markets, top_n=15)
            
            return {
                'timestamp': datetime.now().isoformat(),
                'total_markets': len(all_markets),
                'valid_markets': len(valid_markets),
                'opportunities_found': len(opportunities),
                'opportunities': opportunities
            }
            
        except Exception as e:
            return {'error': str(e), 'timestamp': datetime.now().isoformat()}


def main():
    """Main function."""
    api_key = os.getenv('SIMMER_API_KEY')
    
    if not api_key:
        print("Error: SIMMER_API_KEY not set")
        return
    
    print("="*70)
    print("IMPROVED LMSR TRADER SCAN")
    print("="*70)
    
    trader = ImprovedLMSRTrader(api_key=api_key)
    results = trader.run_scan(dry_run=True)
    
    print("\n" + "="*70)
    print("SCAN RESULTS")
    print("="*70)
    
    if 'error' in results:
        print(f"Error: {results['error']}")
        return
        
    print(f"Total markets: {results['total_markets']}")
    print(f"Valid markets: {results['valid_markets']}")
    print(f"Opportunities found: {results['opportunities_found']}")
    
    if results['opportunities']:
        print(f"\nTOP {len(results['opportunities'])} OPPORTUNITIES:")
        print("-"*70)
        
        for i, opp in enumerate(results['opportunities'], 1):
            print(f"\n{i}. {opp['question']}")
            print(f"   Model: {opp['model_name']}")
            print(f"   Market: {opp['p_market']:.1%} → Model: {opp['p_model']:.1%}")
            print(f"   Edge: {opp['edge']:+.2%}")
            print(f"   Trade: BUY {opp['outcome']} @ {opp['shares']:.1f} shares")
            print(f"   Expected EV: ${opp['expected_ev_usd']:.2f}")
            print(f"   Price impact: {opp['price_impact_pct']:+.2f}%")
            if opp['resolves_at'] != 'Unknown':
                print(f"   Resolves: {opp['resolves_at']}")
                
        # Summary
        total_ev = sum(opp['expected_ev_usd'] for opp in results['opportunities'])
        avg_edge = sum(opp['edge'] for opp in results['opportunities']) / len(results['opportunities'])
        
        print(f"\n" + "="*70)
        print("SUMMARY:")
        print(f"  Total expected EV: ${total_ev:.2f}")
        print(f"  Average edge: {avg_edge:+.2%}")
        print(f"  Best edge: {max(opp['edge'] for opp in results['opportunities']):+.2%}")
        print(f"  Position sizing: ${trader.max_position_usd} max per trade")
        
    else:
        print("\nNo trading opportunities found with current filters.")
    
    print("\n" + "="*70)
    print("NEXT STEPS:")
    print("1. Review probability models - this is where YOUR edge comes from")
    print("2. Adjust min_edge (currently {trader.min_edge:.0%})")
    print("3. Adjust position sizing (currently ${trader.max_position_usd})")
    print("4. Add your own probability models based on your research")
    print("5. Test with small positions before scaling")
    print("="*70)


if __name__ == "__main__":
    main()