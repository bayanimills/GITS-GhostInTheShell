#!/usr/bin/env python3
"""
Test LMSR calculations and Simmer connection.
"""

import os
import math

def test_lmsr_calculations():
    """Test the core LMSR calculations."""
    print("Testing LMSR Calculations...")
    print("="*50)
    
    # Test 1: Basic LMSR price calculation
    b = 100.0  # Liquidity parameter
    quantities = [100.0, 100.0]  # Equal quantities for binary market
    
    def lmsr_price(qs, index, b_param):
        """Calculate LMSR price for outcome at index."""
        exponents = [q / b_param for q in qs]
        max_exp = max(exponents)
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        return exp_terms[index] / sum_exp
    
    # Initial prices should be 50/50
    price_yes = lmsr_price(quantities, 0, b)
    price_no = lmsr_price(quantities, 1, b)
    print(f"Initial market (100 YES, 100 NO):")
    print(f"  YES price: {price_yes:.3f} ({price_yes*100:.1f}%)")
    print(f"  NO price:  {price_no:.3f} ({price_no*100:.1f}%)")
    print(f"  Sum: {price_yes + price_no:.3f}")
    
    # Test 2: Buy 10 YES shares
    print(f"\nBuying 10 YES shares...")
    quantities_after = [110.0, 100.0]  # 10 more YES shares
    price_yes_after = lmsr_price(quantities_after, 0, b)
    price_no_after = lmsr_price(quantities_after, 1, b)
    print(f"  New YES price: {price_yes_after:.3f} ({price_yes_after*100:.1f}%)")
    print(f"  New NO price:  {price_no_after:.3f} ({price_no_after*100:.1f}%)")
    print(f"  Price impact: +{(price_yes_after - price_yes)*100:.2f}%")
    
    # Test 3: Calculate convexity cost
    print(f"\nConvexity cost calculation:")
    shares_bought = 10.0
    avg_price_increase = (price_yes_after - price_yes) / 2  # Approximate average
    convexity_cost = avg_price_increase * shares_bought
    print(f"  Shares bought: {shares_bought}")
    print(f"  Price before: {price_yes:.3f}")
    print(f"  Price after:  {price_yes_after:.3f}")
    print(f"  Avg price increase: {avg_price_increase:.5f}")
    print(f"  Convexity cost: {convexity_cost:.3f} shares equivalent")
    
    # Test 4: Edge calculation example
    print(f"\nEdge calculation example:")
    p_market = 0.4  # Market says 40%
    p_true = 0.6    # Your model says 60%
    edge_per_share = p_true - p_market
    print(f"  Market probability: {p_market:.1%}")
    print(f"  True probability:   {p_true:.1%}")
    print(f"  Edge per share:     {edge_per_share:.1%} (${edge_per_share:.2f} per $1 share)")
    
    # Test 5: Optimal position with convexity
    print(f"\nOptimal position sizing:")
    max_position_usd = 50.0
    naive_shares = max_position_usd / p_market if p_market > 0 else 0
    print(f"  Naive position (ignore convexity): {naive_shares:.1f} shares (${naive_shares * p_market:.2f})")
    
    # Estimate convexity cost for naive position
    # Simplified: assume convexity cost = 10% of edge
    convexity_factor = 0.1
    effective_edge = edge_per_share * (1 - convexity_factor)
    optimal_shares = max_position_usd * effective_edge / p_market
    print(f"  With 10% convexity buffer: {optimal_shares:.1f} shares")
    print(f"  Expected EV: ${optimal_shares * effective_edge:.2f}")
    
    print("\n" + "="*50)
    print("Key Insights:")
    print("1. Every trade moves the price against you (convexity)")
    print("2. Your edge = p_true - p_market")
    print("3. Optimal position considers convexity cost")
    print("4. Smaller positions = less convexity cost")
    print("="*50)

def test_simmer_connection():
    """Test Simmer SDK connection."""
    print("\n\nTesting Simmer Connection...")
    print("="*50)
    
    api_key = os.getenv('SIMMER_API_KEY')
    
    if not api_key:
        print("SIMMER_API_KEY not set in environment")
        print("To set: export SIMMER_API_KEY='your_key_here'")
        return False
    
    print(f"API key found: {api_key[:10]}...{api_key[-10:]}")
    
    try:
        from simmer_sdk import SimmerClient
        client = SimmerClient(api_key=api_key)
        
        # Test connection
        print("Testing connection to Simmer...")
        
        # Try to get briefing (common endpoint)
        try:
            briefing = client._request("GET", "/api/sdk/briefing")
            print(f"✓ Connection successful")
            print(f"  Balance: {briefing.get('venues', {}).get('polymarket', {}).get('balance', 'N/A')} USDC")
            return True
        except Exception as e:
            print(f"✗ Briefing failed: {e}")
            
            # Try markets endpoint instead
            try:
                markets = client.get_markets(limit=5)
                print(f"✓ Markets endpoint works")
                print(f"  Found {len(markets)} markets")
                return True
            except Exception as e2:
                print(f"✗ Markets also failed: {e2}")
                return False
                
    except ImportError:
        print("✗ simmer_sdk not installed")
        print("Install with: pip install simmer-sdk")
        return False
    except Exception as e:
        print(f"✗ Connection failed: {e}")
        return False

if __name__ == "__main__":
    print("LMSR Trading System Test")
    print("="*60)
    
    # Test calculations
    test_lmsr_calculations()
    
    # Test Simmer connection
    if test_simmer_connection():
        print("\n✓ All tests passed!")
        print("\nNext steps:")
        print("1. Review and refine probability model (p_true)")
        print("2. Adjust parameters in lmsr_trader.py")
        print("3. Run live test with small positions")
    else:
        print("\n✗ Some tests failed")
        print("\nFix issues before proceeding with live trading.")