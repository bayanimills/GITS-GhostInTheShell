#!/usr/bin/env python3
"""
LMSR Dry-Run with $SIM/Simmer - Real API connection but simulated trades.
"""

import os
import math
from datetime import datetime
from simmer_sdk import SimmerClient

class LMSRDryRunTrader:
    """
    LMSR trader that connects to real Simmer API but only simulates trades.
    Uses real market data, calculates real edges, but doesn't execute.
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.client = SimmerClient(api_key=api_key)
        
        # Trading parameters
        self.min_edge = 0.15  # 15% minimum edge
        self.max_position_usd = 10.0  # Small positions for testing
        self.liquidity_param = 100.0
        
        # Statistics
        self.scan_count = 0
        self.opportunities_found = 0
        self.total_expected_ev = 0.0
        
    def calculate_edge(self, p_market: float) -> float:
        """
        Calculate edge using simple mean reversion model.
        In reality, you'd use your sophisticated probability model here.
        """
        # Simple model: if market is extreme (>70% or <30%), revert toward 50%
        if p_market > 0.7:
            p_true = 0.6  # Market overconfident
            return p_true - p_market
        elif p_market < 0.3:
            p_true = 0.4  # Market underconfident
            return p_true - p_market
        elif p_market > 0.55:
            p_true = p_market - 0.1  # Slight correction down
            return p_true - p_market
        elif p_market < 0.45:
            p_true = p_market + 0.1  # Slight correction up
            return p_true - p_market
        else:
            return 0.0  # No edge in balanced markets
            
    def calculate_position_size(self, p_market: float, edge: float) -> float:
        """
        Calculate optimal position size considering LMSR convexity.
        """
        if edge <= 0:
            return 0.0
            
        # Convert USD to shares
        price_per_share = p_market if edge > 0 else (1 - p_market)
        max_shares = self.max_position_usd / price_per_share if price_per_share > 0 else 0
        
        # Kelly-like position sizing with convexity buffer
        kelly_fraction = abs(edge) / price_per_share
        optimal_shares = min(max_shares * 0.2,  # Conservative: 20% of max
                           kelly_fraction * self.max_position_usd / price_per_share)
        
        return optimal_shares
        
    def scan_markets(self, limit: int = 50) -> list:
        """
        Scan real markets from Simmer API.
        """
        opportunities = []
        
        try:
            # Get real markets from Simmer
            markets = self.client.get_markets(limit=limit, status='active')
            self.scan_count += 1
            
            for market in markets:
                if not hasattr(market, 'current_probability') or market.current_probability is None:
                    continue
                    
                p_market = market.current_probability
                
                # Skip extreme probabilities (likely data issues)
                if p_market < 0.05 or p_market > 0.95:
                    continue
                    
                # Calculate edge
                edge = self.calculate_edge(p_market)
                
                if abs(edge) < self.min_edge:
                    continue
                    
                # Calculate position size
                shares = self.calculate_position_size(p_market, edge)
                
                if shares <= 0:
                    continue
                    
                # Calculate expected value
                expected_ev = shares * abs(edge) * 100  # Convert to USD
                
                # Determine trade direction
                if edge > 0:
                    outcome = "YES"
                    p_true = p_market + edge
                else:
                    outcome = "NO"
                    p_true = p_market + edge  # edge is negative
                    
                opportunities.append({
                    'market_id': market.id,
                    'question': market.question[:100] + '...' if len(market.question) > 100 else market.question,
                    'p_market': p_market,
                    'p_true': p_true,
                    'edge': edge,
                    'shares': shares,
                    'expected_ev_usd': expected_ev,
                    'outcome': outcome,
                    'trade_value_usd': shares * (p_market if outcome == "YES" else (1 - p_market))
                })
                
                self.opportunities_found += 1
                self.total_expected_ev += expected_ev
                
        except Exception as e:
            print(f"Error scanning markets: {e}")
            
        # Sort by expected EV
        opportunities.sort(key=lambda x: x['expected_ev_usd'], reverse=True)
        return opportunities
        
    def run_dry_scan(self) -> dict:
        """
        Run a complete dry scan.
        """
        print("="*70)
        print("LMSR DRY-RUN SCAN WITH REAL MARKET DATA")
        print("="*70)
        print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"API: Connected to Simmer (real market data)")
        print(f"Mode: DRY-RUN - No trades executed")
        print(f"Min edge: {self.min_edge:.0%}")
        print(f"Max position: ${self.max_position_usd}")
        print("-"*70)
        
        # Scan markets
        opportunities = self.scan_markets(limit=100)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'opportunities_found': len(opportunities),
            'opportunities': opportunities[:10],  # Top 10
            'total_expected_ev': self.total_expected_ev,
            'scan_count': self.scan_count
        }
        
        return result


def main():
    """Main function."""
    # Use the WORKING API key
    API_KEY = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"
    
    print("\n🚀 STARTING LMSR DRY-RUN WITH $SIM/Simmer")
    print("Using REAL market data from Simmer API")
    print("Executing SIMULATED trades only")
    print("="*70)
    
    try:
        # Initialize trader
        trader = LMSRDryRunTrader(api_key=API_KEY)
        
        # Run scan
        results = trader.run_dry_scan()
        
        # Print results
        print(f"\n📊 SCAN RESULTS:")
        print(f"Markets scanned: 100 (via Simmer API)")
        print(f"Opportunities found: {results['opportunities_found']}")
        print(f"Total expected EV: ${results['total_expected_ev']:.2f}")
        
        if results['opportunities']:
            print(f"\n🏆 TOP {len(results['opportunities'])} OPPORTUNITIES:")
            print("-"*70)
            
            for i, opp in enumerate(results['opportunities'], 1):
                print(f"\n{i}. {opp['question']}")
                print(f"   Market: {opp['p_market']:.1%} → Model: {opp['p_true']:.1%}")
                print(f"   Edge: {opp['edge']:+.2%}")
                print(f"   Trade: BUY {opp['outcome']} @ {opp['shares']:.1f} shares")
                print(f"   Trade value: ${opp['trade_value_usd']:.2f}")
                print(f"   Expected EV: ${opp['expected_ev_usd']:.2f}")
                
            # Summary
            avg_edge = sum(opp['edge'] for opp in results['opportunities']) / len(results['opportunities'])
            max_edge = max(abs(opp['edge']) for opp in results['opportunities'])
            
            print(f"\n" + "="*70)
            print("📈 SUMMARY:")
            print(f"  Total expected EV: ${results['total_expected_ev']:.2f}")
            print(f"  Average edge: {avg_edge:+.2%}")
            print(f"  Maximum edge: {max_edge:.2%}")
            print(f"  Position sizing: ${trader.max_position_usd} max per trade")
            
        else:
            print("\n❌ No trading opportunities found with current filters.")
            print("Try adjusting min_edge (currently 15%) or position sizing.")
            
        print(f"\n" + "="*70)
        print("💡 NEXT STEPS FOR LIVE TRADING:")
        print("1. Enable real trading in Simmer dashboard")
        print("2. Fund with $SIM or USDC")
        print("3. Replace simple edge model with your sophisticated probability model")
        print("4. Adjust parameters based on backtesting")
        print("5. Start with small positions ($1-5)")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\nTroubleshooting:")
        print("1. Check API key validity")
        print("2. Check network connectivity")
        print("3. Visit simmer.markets/dashboard")


if __name__ == "__main__":
    main()