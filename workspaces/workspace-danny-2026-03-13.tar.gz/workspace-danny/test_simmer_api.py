#!/usr/bin/env python3
"""
Test Simmer API connection and market data.
"""

import os
import sys
from datetime import datetime

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

# Use the provided API key
api_key = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"

print(f"Testing Simmer API with key: {api_key[:20]}...")
print(f"Time: {datetime.now().isoformat()}")

try:
    client = SimmerClient(api_key=api_key)
    
    # Test basic API calls
    print("\n1. Testing get_markets()...")
    markets = client.get_markets(limit=10, status='active')
    print(f"   Retrieved {len(markets)} active markets")
    
    if markets:
        print("\n2. Sample market data:")
        for i, market in enumerate(markets[:3]):
            print(f"   Market {i+1}:")
            print(f"     ID: {market.id}")
            print(f"     Question: {market.question[:80]}..." if len(market.question) > 80 else f"     Question: {market.question}")
            print(f"     Probability: {market.current_probability:.1%}" if hasattr(market, 'current_probability') and market.current_probability is not None else "     Probability: N/A")
            print(f"     Expires: {market.expires_at}" if hasattr(market, 'expires_at') else "     Expires: N/A")
            print()
    
    # Test get_market_context for first market
    if markets:
        print("3. Testing get_market_context()...")
        market_id = markets[0].id
        try:
            context = client.get_market_context(market_id)
            print(f"   Context type: {type(context)}")
            if isinstance(context, dict):
                print(f"   Context keys: {list(context.keys())[:10]}...")
            else:
                print(f"   Context: {str(context)[:200]}...")
        except Exception as e:
            print(f"   Error getting context: {e}")
    
    # Test portfolio/briefing
    print("\n4. Testing portfolio/briefing...")
    try:
        # Try to get briefing
        result = client._request("GET", "/api/sdk/briefing")
        print(f"   Briefing available: {len(result) > 0 if isinstance(result, dict) else 'N/A'}")
    except Exception as e:
        print(f"   Briefing error (may be normal): {e}")
    
    print("\n✓ API connection successful!")
    
except Exception as e:
    print(f"\n✗ API connection failed: {e}")
    import traceback
    traceback.print_exc()