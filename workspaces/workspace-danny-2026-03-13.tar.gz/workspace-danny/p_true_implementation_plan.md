# p_true Implementation Plan for LMSR Trading

## **Core Insight:**
**Edge = p_true - p_market**
Where:
- **p_market** = Current Polymarket probability (from LMSR)
- **p_true** = Your model's estimate of true probability
- **Edge** = Mispricing per share (in probability units)

## **Phase 1: Foundation (Week 1)**

### **1.1 Install FinTool**
```bash
# Install as OpenClaw skill
# The agent will handle platform-specific binaries
```

### **1.2 Data Pipeline Setup**
```python
class DataPipeline:
    def __init__(self):
        self.sources = {
            'prices': FinToolPriceSource(),
            'news': FinToolNewsSource(),
            'sec': FinToolSECSource(),
            'social': TwitterAPI(),
            'onchain': EthereumRPC()
        }
    
    def fetch_market_context(self, market_topic):
        """Fetch all relevant data for a market topic."""
        data = {}
        for name, source in self.sources.items():
            try:
                data[name] = source.fetch(market_topic)
            except:
                data[name] = None
        return data
```

### **1.3 Simple Baseline Models**
```python
class BaselineModels:
    """Simple models to establish baseline performance."""
    
    def mean_reversion(self, p_market):
        """If market is extreme, revert toward 50%."""
        if p_market > 0.7:
            return 0.6 + (p_market - 0.7) * 0.2
        elif p_market < 0.3:
            return 0.4 - (0.3 - p_market) * 0.2
        return 0.5
    
    def momentum(self, p_market, historical_prices):
        """Simple momentum model."""
        if len(historical_prices) < 2:
            return p_market
        
        recent_trend = historical_prices[-1] - historical_prices[-2]
        return p_market + (recent_trend * 0.1)
    
    def volume_weighted(self, p_market, volume_data):
        """Weight by trading volume."""
        if not volume_data:
            return p_market
        
        avg_volume = sum(volume_data) / len(volume_data)
        recent_volume = volume_data[-1] if volume_data else avg_volume
        
        # Higher volume = more efficient price
        volume_ratio = min(recent_volume / avg_volume, 2.0)
        efficiency_factor = 0.5 + (volume_ratio * 0.25)
        
        return 0.5 + (p_market - 0.5) * efficiency_factor
```

## **Phase 2: Sophisticated Models (Week 2-3)**

### **2.1 News Sentiment Model**
```python
class NewsSentimentModel:
    def __init__(self, openai_key=None):
        self.llm_client = OpenAI(api_key=openai_key) if openai_key else None
    
    def analyze_sentiment(self, news_articles):
        """Analyze news sentiment for market topic."""
        if not self.llm_client:
            return 0.0  # Neutral
        
        # Prepare prompt for LLM
        prompt = f"""
        Analyze these news articles about {market_topic}:
        {news_articles}
        
        On a scale of -1.0 (very bearish) to +1.0 (very bullish), 
        what is the overall sentiment?
        Return only a number.
        """
        
        response = self.llm_client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        
        try:
            sentiment = float(response.choices[0].message.content)
            return max(-1.0, min(1.0, sentiment))
        except:
            return 0.0
    
    def sentiment_to_probability(self, sentiment, p_market):
        """Convert sentiment to probability adjustment."""
        # Sentiment of +0.2 → increase probability by 10%
        # Sentiment of -0.2 → decrease probability by 10%
        adjustment = sentiment * 0.5  # Scale factor
        return p_market + adjustment
```

### **2.2 Cross-Market Correlation Model**
```python
class CrossMarketCorrelationModel:
    def __init__(self):
        self.correlation_matrix = self.load_correlation_data()
    
    def get_related_assets(self, market_topic):
        """Find assets correlated with market topic."""
        # Example: Bitcoin market → BTC price, crypto index, tech stocks
        correlations = {
            'bitcoin': ['BTC', 'ETH', 'MSTR', 'COIN', '^NDX'],
            'ethereum': ['ETH', 'BTC', 'SOL', '^NDX'],
            'tesla': ['TSLA', '^NDX', '^GSPC', '^VIX'],
            'weather': ['^GSPC', 'USO', 'UNG'],  # Energy correlations
            'sports': []  # Limited correlations
        }
        return correlations.get(market_topic.lower(), [])
    
    def calculate_correlation_factor(self, market_topic):
        """Calculate probability adjustment based on correlated assets."""
        related_assets = self.get_related_assets(market_topic)
        if not related_assets:
            return 1.0  # No adjustment
        
        # Get current prices and trends
        trends = []
        for asset in related_assets:
            try:
                quote = fintool.quote(asset)
                trend = 1.0 if quote.get('trend') == 'bullish' else -1.0
                trends.append(trend)
            except:
                continue
        
        if not trends:
            return 1.0
        
        # Average trend of correlated assets
        avg_trend = sum(trends) / len(trends)
        
        # Convert to probability factor
        # avg_trend = +0.3 → factor = 1.15 (increase by 15%)
        # avg_trend = -0.3 → factor = 0.85 (decrease by 15%)
        return 1.0 + (avg_trend * 0.5)
```

### **2.3 Market Microstructure Model**
```python
class MarketMicrostructureModel:
    """Analyze market microstructure for edge."""
    
    def analyze_liquidity(self, market_id):
        """Analyze liquidity patterns."""
        # Get order book data (if available)
        # Analyze bid-ask spread
        # Analyze depth at different price levels
        # Identify large resting orders
        
        # Simplified: use trading volume as proxy
        volume = self.get_trading_volume(market_id)
        avg_volume = self.get_average_volume(market_id)
        
        volume_ratio = volume / avg_volume if avg_volume > 0 else 1.0
        
        # High volume → more efficient price
        # Low volume → potential mispricing
        efficiency = min(volume_ratio, 2.0) / 2.0  # 0.0 to 1.0
        
        return efficiency
    
    def calculate_microstructure_edge(self, p_market, efficiency):
        """Calculate edge based on market microstructure."""
        # Inefficient markets (low volume) have larger potential mispricing
        # But also higher convexity costs
        
        base_edge = 0.1  # Base edge assumption
        adjusted_edge = base_edge * (1.0 - efficiency)
        
        return adjusted_edge
```

## **Phase 3: Ensemble Model (Week 4)**

### **3.1 Weighted Ensemble**
```python
class EnsembleProbabilityModel:
    def __init__(self):
        self.models = {
            'news_sentiment': NewsSentimentModel(),
            'cross_market': CrossMarketCorrelationModel(),
            'microstructure': MarketMicrostructureModel(),
            'mean_reversion': MeanReversionModel(),
            'momentum': MomentumModel()
        }
        
        # Initial weights (will be updated based on performance)
        self.weights = {
            'news_sentiment': 0.25,
            'cross_market': 0.25,
            'microstructure': 0.20,
            'mean_reversion': 0.15,
            'momentum': 0.15
        }
    
    def predict(self, market):
        """Weighted average of all model predictions."""
        predictions = {}
        
        for name, model in self.models.items():
            try:
                predictions[name] = model.predict(market)
            except Exception as e:
                print(f"Model {name} failed: {e}")
                predictions[name] = None
        
        # Filter out None predictions
        valid_predictions = {
            k: v for k, v in predictions.items() 
            if v is not None
        }
        
        if not valid_predictions:
            return market.current_probability  # Fallback
        
        # Weighted average
        total_weight = sum(
            self.weights[name] for name in valid_predictions.keys()
        )
        
        weighted_sum = sum(
            pred * self.weights[name] 
            for name, pred in valid_predictions.items()
        )
        
        return weighted_sum / total_weight
    
    def update_weights(self, performance_data):
        """Update model weights based on historical performance."""
        # Calculate accuracy for each model
        accuracies = {}
        for name in self.models.keys():
            if name in performance_data:
                correct = performance_data[name]['correct']
                total = performance_data[name]['total']
                accuracies[name] = correct / total if total > 0 else 0.0
        
        # Normalize to sum to 1.0
        total_accuracy = sum(accuracies.values())
        if total_accuracy > 0:
            self.weights = {
                name: accuracy / total_accuracy
                for name, accuracy in accuracies.items()
            }
```

### **3.2 LMSR-Aware Edge Calculation**
```python
class LMSRAwareTrader:
    def __init__(self, probability_model):
        self.probability_model = probability_model
        self.liquidity_param = 100.0  # LMSR b parameter
    
    def calculate_edge(self, market):
        """Calculate edge with LMSR convexity awareness."""
        p_market = market.current_probability
        p_true = self.probability_model.predict(market)
        
        # Raw edge
        raw_edge = p_true - p_market
        
        # Adjust for convexity cost
        # Convexity cost ≈ edge² / (2 * liquidity)
        convexity_cost = (raw_edge ** 2) / (2 * self.liquidity_param)
        
        # Effective edge after convexity
        effective_edge = raw_edge - convexity_cost
        
        return effective_edge
    
    def calculate_optimal_position(self, market, max_position_usd=10.0):
        """Calculate optimal position size."""
        edge = self.calculate_edge(market)
        
        if edge <= 0:
            return 0.0, 0.0
        
        # Kelly-like position sizing
        p_market = market.current_probability
        price_per_share = p_market if edge > 0 else (1 - p_market)
        
        # Maximum shares based on budget
        max_shares = max_position_usd / price_per_share
        
        # Kelly fraction
        kelly_fraction = edge / price_per_share
        
        # Optimal shares (conservative: 20% of Kelly)
        optimal_shares = min(
            max_shares * 0.2,  # Risk management
            kelly_fraction * max_position_usd / price_per_share
        )
        
        # Expected value
        expected_ev = optimal_shares * edge * 100  # Convert to USD
        
        return optimal_shares, expected_ev
```

## **Phase 4: Deployment & Scaling**

### **4.1 Dry-Run Validation**
```python
def validate_models(historical_data):
    """Backtest models on historical data."""
    results = {}
    
    for model_name, model in models.items():
        correct = 0
        total = 0
        
        for market_data in historical_data:
            prediction = model.predict(market_data)
            actual = market_data['outcome']
            
            # Check if prediction was correct
            if (prediction > 0.5 and actual == 1) or (prediction < 0.5 and actual == 0):
                correct += 1
            total += 1
        
        accuracy = correct / total if total > 0 else 0.0
        results[model_name] = {
            'accuracy': accuracy,
            'correct': correct,
            'total': total
        }
    
    return results
```

### **4.2 Live Trading Pipeline**
```python
class LiveTradingPipeline:
    def __init__(self, trader, simmer_client):
        self.trader = trader
        self.simmer_client = simmer_client
        self.performance_tracker = PerformanceTracker()
    
    def run_scan(self):
        """Run a complete trading scan."""
        # Fetch markets
        markets = self.simmer_client.get_markets(limit=100, status='active')
        
        opportunities = []
        for market in markets:
            # Calculate edge and position
            shares, expected_ev = self.trader.calculate_optimal_position(market)
            
            if shares > 0 and expected_ev > 0:
                opportunities.append({
                    'market': market,
                    'shares': shares,
                    'expected_ev': expected_ev,
                    'edge': self.trader.calculate_edge(market)
                })
        
        # Sort by expected EV
        opportunities.sort(key=lambda x: x['expected_ev'], reverse=True)
        
        # Execute top opportunities
        for opp in opportunities[:3]:  # Limit to top 3
            self.execute_trade(opp)
        
        return opportunities
    
    def execute_trade(self, opportunity):
        """Execute a trade with proper risk management."""
        market = opportunity['market']
        shares = opportunity['shares']
        
        # Check risk limits
        if not self.risk_manager.approve_trade(market, shares):
            return
        
        # Execute trade
        try:
            result = self.simmer_client.trade(
                market_id=market.id,
                outcome='YES' if opportunity['edge'] > 0 else 'NO',
                shares=shares,
                dry_run=False  # Live trading
            )
            
            # Track performance
            self.performance_tracker.record_trade(
                market=market,
                shares=shares,
                result=result
            )
            
        except Exception as e:
            print(f"Trade failed: {e}")
```

## **Implementation Timeline:**

### **Week 1: Foundation**
- Install FinTool and set up data pipeline
- Implement baseline models (mean reversion, momentum)
- Dry-run testing with historical data

### **Week 2: Sophisticated Models**
- Implement news sentiment model (requires OpenAI key)
- Implement cross-market correlation model
- Backtest and compare model performance

### **Week 3: Ensemble & Optimization**
- Implement weighted ensemble model
- Add market microstructure analysis
- Optimize LMSR-aware position sizing

### **Week 4: Live Deployment**
- Deploy with small positions ($1-5)
- Real-time performance tracking
- Model weight updating based on live results

### **Month 2: Scaling**
- Add more data sources
- Implement machine learning models
- Scale position sizes based on performance
- Add cross-market arbitrage

## **Key Success Metrics:**
1. **Model accuracy:** >55% (beating market)
2. **Average edge:** >5% after convexity costs
3. **Sharpe ratio:** >1.0
4. **Maximum drawdown:** <20%
5. **Daily expected EV:** $50-100 with $10 positions

## **Your Edge = Your Data + Your Models**
FinTool provides the data pipeline. The LMSR framework provides the trading mechanism. **Your probability models provide the edge.** Start simple, iterate quickly, and scale based on performance.