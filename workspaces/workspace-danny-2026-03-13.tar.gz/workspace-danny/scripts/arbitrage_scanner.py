#!/usr/bin/env python3
"""
Enhanced Market Scanner for Risk-Free Profit Opportunities
Phase 1: Identify mispriced markets and calculate theoretical arbitrage
"""

import os
import sys
import json
import time
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import simmer_sdk

# Configuration
API_KEY = 'sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe'
MIN_PROFIT_THRESHOLD = 0.01  # 1% minimum profit after fees
MAX_FEES = 0.10  # 10% maximum fees (fast markets)
MIN_LIQUIDITY = 100  # Minimum $100 in market for consideration

class ArbitrageScanner:
    """Scanner for identifying risk-free profit opportunities"""
    
    def __init__(self, api_key: str):
        self.client = simmer_sdk.SimmerClient(api_key=api_key)
        self.opportunities = []
        
    def scan_all_markets(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Scan all available markets for arbitrage opportunities"""
        print(f"🔍 Scanning {limit} markets for arbitrage opportunities...")
        
        try:
            markets = self.client.get_markets(limit=limit)
            print(f"✅ Found {len(markets)} markets")
            
            for market in markets:
                self.analyze_market(market)
                
            return self.opportunities
            
        except Exception as e:
            print(f"❌ Error scanning markets: {e}")
            return []
    
    def analyze_market(self, market) -> Optional[Dict[str, Any]]:
        """Analyze a single market for arbitrage potential"""
        try:
            # Skip resolved markets
            price = market.current_probability
            if price < 0.01 or price > 0.99:
                return None  # Market already resolved
            
            # Get market context for more info
            context = self.client.get_market_context(market.id)
            
            # Calculate theoretical arbitrage
            yes_price = price
            no_price = 1 - price  # Theoretical NO price (assuming efficient market)
            
            # Account for fees (2-10% on Polymarket)
            # Fast markets typically have 10% fees
            fee_rate = self.estimate_fee_rate(market.question)
            total_fees = fee_rate * 2  # Fees on both YES and NO sides
            
            # Calculate total cost and profit
            total_cost = yes_price + no_price + total_fees
            theoretical_profit = 1.00 - total_cost
            
            # Check if profitable after fees
            if theoretical_profit >= MIN_PROFIT_THRESHOLD:
                opportunity = {
                    'market_id': market.id,
                    'question': market.question,
                    'yes_price': yes_price,
                    'theoretical_no_price': no_price,
                    'fee_rate': fee_rate,
                    'total_fees': total_fees,
                    'total_cost': total_cost,
                    'theoretical_profit': theoretical_profit,
                    'theoretical_profit_pct': theoretical_profit * 100,
                    'status': market.status,
                    'current_price': price,
                    'context': {
                        'redeemable': context.get('redeemable', False),
                        'has_position': context.get('position', {}).get('has_position', False),
                        'warnings': context.get('warnings', [])
                    }
                }
                
                self.opportunities.append(opportunity)
                return opportunity
            
            return None
            
        except Exception as e:
            print(f"⚠️ Error analyzing market {market.id[:8]}...: {e}")
            return None
    
    def estimate_fee_rate(self, question: str) -> float:
        """Estimate fee rate based on market type"""
        question_lower = question.lower()
        
        # Fast markets (5m, 15m windows) have higher fees
        if any(time_indicator in question_lower for time_indicator in ['5m', '15m', 'fast', 'sprint']):
            return 0.10  # 10% for fast markets
        
        # Regular markets have lower fees
        return 0.02  # 2% for regular markets
    
    def analyze_extreme_prices(self, markets: List) -> List[Dict[str, Any]]:
        """Analyze markets with extreme prices for potential mispricing"""
        extreme_opportunities = []
        
        for market in markets:
            price = market.current_probability
            
            # Look for extreme mispricing
            if price < 0.05 or price > 0.95:
                # This could indicate market inefficiency
                opportunity = {
                    'market_id': market.id,
                    'question': market.question,
                    'price': price,
                    'type': 'extreme_mispricing',
                    'potential_arbitrage': abs(price - 0.5) * 2,  # Maximum possible if opposite side available
                    'status': market.status
                }
                
                # Check if this is a fast market (higher chance of mispricing)
                if any(time_indicator in market.question.lower() 
                       for time_indicator in ['5m', '15m', 'fast', 'sprint']):
                    opportunity['market_type'] = 'fast_market'
                    opportunity['fee_rate'] = 0.10
                else:
                    opportunity['market_type'] = 'regular_market'
                    opportunity['fee_rate'] = 0.02
                
                extreme_opportunities.append(opportunity)
        
        return extreme_opportunities
    
    def generate_report(self, opportunities: List[Dict[str, Any]]) -> str:
        """Generate a human-readable report of opportunities"""
        if not opportunities:
            return "📊 No arbitrage opportunities found above threshold.\n"
        
        report = []
        report.append("🚀 ARBITRAGE OPPORTUNITIES FOUND")
        report.append("=" * 60)
        
        # Sort by profit percentage (highest first)
        sorted_ops = sorted(opportunities, key=lambda x: x['theoretical_profit_pct'], reverse=True)
        
        for i, opp in enumerate(sorted_ops[:10]):  # Show top 10
            report.append(f"\n{i+1}. {opp['question'][:80]}...")
            report.append(f"   Market ID: {opp['market_id'][:16]}...")
            report.append(f"   YES Price: ${opp['yes_price']:.3f}")
            report.append(f"   Theoretical NO Price: ${opp['theoretical_no_price']:.3f}")
            report.append(f"   Fees: {opp['fee_rate']*100:.0f}% (${opp['total_fees']:.3f} total)")
            report.append(f"   Total Cost: ${opp['total_cost']:.3f}")
            report.append(f"   Theoretical Profit: ${opp['theoretical_profit']:.3f} ({opp['theoretical_profit_pct']:.1f}%)")
            report.append(f"   Status: {opp['status']}")
            
            if opp['context']['warnings']:
                report.append(f"   ⚠️ Warnings: {', '.join(opp['context']['warnings'])}")
        
        # Summary statistics
        report.append("\n" + "=" * 60)
        report.append("📈 SUMMARY STATISTICS")
        report.append(f"Total opportunities found: {len(opportunities)}")
        
        if opportunities:
            avg_profit = sum(o['theoretical_profit_pct'] for o in opportunities) / len(opportunities)
            max_profit = max(o['theoretical_profit_pct'] for o in opportunities)
            min_profit = min(o['theoretical_profit_pct'] for o in opportunities)
            
            report.append(f"Average profit: {avg_profit:.1f}%")
            report.append(f"Maximum profit: {max_profit:.1f}%")
            report.append(f"Minimum profit: {min_profit:.1f}%")
            
            # Count by market type
            fast_markets = sum(1 for o in opportunities if o['fee_rate'] == 0.10)
            regular_markets = sum(1 for o in opportunities if o['fee_rate'] == 0.02)
            report.append(f"Fast markets: {fast_markets}, Regular markets: {regular_markets}")
        
        report.append("\n⚠️ IMPORTANT LIMITATIONS:")
        report.append("1. Theoretical NO price assumes efficient market")
        report.append("2. Real NO price may be different (need order book data)")
        report.append("3. Fees reduce actual profit significantly")
        report.append("4. Simultaneous execution required for true arbitrage")
        report.append("5. Liquidity may not support large positions")
        
        return "\n".join(report)

def main():
    """Main execution function"""
    print("🤖 Enhanced Arbitrage Scanner - Phase 1")
    print("=" * 60)
    print(f"Start time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    
    # Initialize scanner
    scanner = ArbitrageScanner(API_KEY)
    
    # Scan for opportunities
    opportunities = scanner.scan_all_markets(limit=100)
    
    # Generate report
    report = scanner.generate_report(opportunities)
    print(report)
    
    # Also analyze extreme price markets
    print("\n🔍 Analyzing extreme price markets...")
    markets = scanner.client.get_markets(limit=100)
    extreme_ops = scanner.analyze_extreme_prices(markets)
    
    if extreme_ops:
        print(f"Found {len(extreme_ops)} markets with extreme prices")
        print("Top extreme price opportunities:")
        for i, opp in enumerate(extreme_ops[:5]):
            print(f"{i+1}. ${opp['price']:.3f}: {opp['question'][:60]}...")
            print(f"   Potential: {opp['potential_arbitrage']*100:.1f}% if NO available")
    else:
        print("No extreme price opportunities found")
    
    # Save results to file
    output_file = f"/tmp/arbitrage_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w') as f:
        json.dump({
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'opportunities_found': len(opportunities),
            'opportunities': opportunities[:20],  # Limit to first 20
            'extreme_opportunities': extreme_ops[:10],
            'scan_parameters': {
                'min_profit_threshold': MIN_PROFIT_THRESHOLD,
                'max_fees': MAX_FEES,
                'min_liquidity': MIN_LIQUIDITY
            }
        }, f, indent=2)
    
    print(f"\n💾 Results saved to: {output_file}")
    print(f"✅ Scan completed at: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    
    # Return exit code based on findings
    if opportunities:
        print(f"\n🚀 Found {len(opportunities)} potential arbitrage opportunities!")
        return 0
    else:
        print("\n⏸️ No arbitrage opportunities found above threshold.")
        return 1

if __name__ == "__main__":
    sys.exit(main())