#!/usr/bin/env python3
"""
Practical Arbitrage Scanner
Identifies markets that COULD have arbitrage if order book prices differ from consensus
"""

import os
import sys
import json
from datetime import datetime, timezone
from typing import List, Dict, Any
import simmer_sdk

API_KEY = 'sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe'

class PracticalArbitrageScanner:
    """Scanner for identifying POTENTIAL arbitrage opportunities"""
    
    def __init__(self, api_key: str):
        self.client = simmer_sdk.SimmerClient(api_key=api_key)
        
    def scan_practical_opportunities(self, limit: int = 100) -> Dict[str, Any]:
        """Scan for practical arbitrage opportunities"""
        print("🔍 Scanning for PRACTICAL arbitrage opportunities...")
        print("=" * 60)
        
        results = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'total_markets_scanned': 0,
            'potential_opportunities': [],
            'insights': [],
            'recommendations': []
        }
        
        try:
            markets = self.client.get_markets(limit=limit)
            results['total_markets_scanned'] = len(markets)
            
            print(f"Scanned {len(markets)} markets")
            print()
            
            # Key insight: Markets are efficient at consensus level
            # But order book might have inefficiencies
            efficient_markets = 0
            near_efficient = 0
            potentially_inefficient = 0
            
            for market in markets:
                price = market.current_probability
                total = price + (1 - price)  # YES + theoretical NO
                
                # Check how efficient the market is
                if abs(total - 1.00) < 0.001:  # Within 0.1¢
                    efficient_markets += 1
                elif abs(total - 1.00) < 0.01:  # Within 1¢
                    near_efficient += 1
                else:
                    potentially_inefficient += 1
                    
                    # This could be a real opportunity if order book differs
                    opportunity = {
                        'market_id': market.id,
                        'question': market.question,
                        'consensus_price': price,
                        'theoretical_total': total,
                        'inefficiency': abs(total - 1.00),
                        'status': market.status,
                        'market_type': self.classify_market(market.question)
                    }
                    results['potential_opportunities'].append(opportunity)
            
            # Generate insights
            results['insights'].append(f"Efficient markets (YES+NO ≈ $1.00): {efficient_markets} ({efficient_markets/len(markets)*100:.1f}%)")
            results['insights'].append(f"Near-efficient (within 1¢): {near_efficient} ({near_efficient/len(markets)*100:.1f}%)")
            results['insights'].append(f"Potentially inefficient: {potentially_inefficient} ({potentially_inefficient/len(markets)*100:.1f}%)")
            
            # Check for resolved markets showing as active
            resolved_but_active = sum(1 for m in markets 
                                     if (m.current_probability < 0.01 or m.current_probability > 0.99) 
                                     and m.status == 'active')
            if resolved_but_active > 0:
                results['insights'].append(f"Resolved markets still showing as active: {resolved_but_active}")
            
            # Generate recommendations
            if potentially_inefficient > 0:
                results['recommendations'].append(f"Found {potentially_inefficient} potentially inefficient markets")
                results['recommendations'].append("These markets have YES+NO ≠ $1.00 at consensus level")
                results['recommendations'].append("Need order book data to confirm actual arbitrage")
            else:
                results['recommendations'].append("All markets appear efficient at consensus level")
                results['recommendations'].append("True arbitrage would require order book inefficiencies")
            
            # Check specific market types
            self.analyze_market_types(markets, results)
            
            return results
            
        except Exception as e:
            print(f"❌ Error: {e}")
            results['error'] = str(e)
            return results
    
    def classify_market(self, question: str) -> str:
        """Classify market type based on question"""
        q_lower = question.lower()
        
        if any(asset in q_lower for asset in ['btc', 'bitcoin']):
            return 'BTC_fast_market'
        elif any(asset in q_lower for asset in ['eth', 'ethereum']):
            return 'ETH_fast_market'
        elif any(asset in q_lower for asset in ['sol', 'solana']):
            return 'SOL_fast_market'
        elif any(asset in q_lower for asset in ['xrp']):
            return 'XRP_fast_market'
        elif any(indicator in q_lower for indicator in ['5m', '15m', 'fast', 'sprint']):
            return 'fast_market'
        elif any(indicator in q_lower for indicator in ['election', 'politics']):
            return 'politics'
        elif any(indicator in q_lower for indicator in ['sports', 'game', 'match']):
            return 'sports'
        else:
            return 'other'
    
    def analyze_market_types(self, markets: List, results: Dict[str, Any]):
        """Analyze efficiency by market type"""
        type_efficiency = {}
        
        for market in markets:
            market_type = self.classify_market(market.question)
            price = market.current_probability
            total = price + (1 - price)
            efficiency = abs(total - 1.00)
            
            if market_type not in type_efficiency:
                type_efficiency[market_type] = {
                    'count': 0,
                    'total_efficiency': 0,
                    'min_efficiency': float('inf'),
                    'max_efficiency': 0
                }
            
            stats = type_efficiency[market_type]
            stats['count'] += 1
            stats['total_efficiency'] += efficiency
            stats['min_efficiency'] = min(stats['min_efficiency'], efficiency)
            stats['max_efficiency'] = max(stats['max_efficiency'], efficiency)
        
        # Add to results
        results['market_type_analysis'] = {}
        for market_type, stats in type_efficiency.items():
            avg_efficiency = stats['total_efficiency'] / stats['count'] if stats['count'] > 0 else 0
            results['market_type_analysis'][market_type] = {
                'count': stats['count'],
                'avg_inefficiency': avg_efficiency,
                'min_inefficiency': stats['min_efficiency'],
                'max_inefficiency': stats['max_efficiency']
            }
    
    def generate_report(self, results: Dict[str, Any]) -> str:
        """Generate human-readable report"""
        report = []
        report.append("📊 PRACTICAL ARBITRAGE SCANNER REPORT")
        report.append("=" * 60)
        report.append(f"Scan time: {results['timestamp']}")
        report.append(f"Markets scanned: {results['total_markets_scanned']}")
        report.append("")
        
        # Insights
        report.append("🔍 KEY INSIGHTS:")
        for insight in results.get('insights', []):
            report.append(f"  • {insight}")
        
        # Market type analysis
        if 'market_type_analysis' in results:
            report.append("")
            report.append("📈 MARKET TYPE ANALYSIS:")
            for market_type, analysis in results['market_type_analysis'].items():
                report.append(f"  {market_type}:")
                report.append(f"    Count: {analysis['count']}")
                report.append(f"    Avg inefficiency: ${analysis['avg_inefficiency']:.4f}")
                report.append(f"    Range: ${analysis['min_inefficiency']:.4f} - ${analysis['max_inefficiency']:.4f}")
        
        # Potential opportunities
        opportunities = results.get('potential_opportunities', [])
        if opportunities:
            report.append("")
            report.append("🎯 POTENTIAL OPPORTUNITIES:")
            # Sort by inefficiency (highest first)
            sorted_ops = sorted(opportunities, key=lambda x: x['inefficiency'], reverse=True)
            for i, opp in enumerate(sorted_ops[:5]):  # Show top 5
                report.append(f"{i+1}. {opp['question'][:60]}...")
                report.append(f"   Type: {opp['market_type']}")
                report.append(f"   Consensus: ${opp['consensus_price']:.3f}")
                report.append(f"   YES+NO: ${opp['theoretical_total']:.3f}")
                report.append(f"   Inefficiency: ${opp['inefficiency']:.3f}")
                report.append(f"   Status: {opp['status']}")
                report.append("")
        else:
            report.append("")
            report.append("⏸️ No potentially inefficient markets found")
        
        # Recommendations
        report.append("")
        report.append("💡 RECOMMENDATIONS:")
        for rec in results.get('recommendations', []):
            report.append(f"  • {rec}")
        
        # Critical limitations
        report.append("")
        report.append("⚠️ CRITICAL LIMITATIONS:")
        report.append("  1. Using consensus prices, not order book prices")
        report.append("  2. Can't check actual YES/NO bid-ask spreads")
        report.append("  3. Fees (2-10%) make most theoretical arbitrage unprofitable")
        report.append("  4. Need simultaneous execution for true risk-free profit")
        report.append("  5. Liquidity constraints may prevent large positions")
        
        report.append("")
        report.append("🚀 NEXT STEPS:")
        report.append("  1. Get direct Polymarket API access for order book data")
        report.append("  2. Monitor bid-ask spreads in real-time")
        report.append("  3. Test small positions to validate assumptions")
        report.append("  4. Build execution engine for simultaneous trades")
        
        return "\n".join(report)

def main():
    """Main execution"""
    print("🤖 Practical Arbitrage Scanner")
    print("=" * 60)
    
    scanner = PracticalArbitrageScanner(API_KEY)
    results = scanner.scan_practical_opportunities(limit=100)
    
    report = scanner.generate_report(results)
    print(report)
    
    # Save results
    output_file = f"/tmp/practical_arbitrage_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 Results saved to: {output_file}")
    
    # Return summary
    opportunities = len(results.get('potential_opportunities', []))
    if opportunities > 0:
        print(f"\n✅ Found {opportunities} potentially inefficient markets")
        return 0
    else:
        print("\n⏸️ All markets appear efficient at consensus level")
        return 1

if __name__ == "__main__":
    sys.exit(main())