#!/bin/bash
# FastLoop wrapper script - only sends Telegram message if trade executes or error occurs

cd /home/agent/.openclaw/workspace/skills/polymarket-fast-loop

# Run FastLoop trader and capture output
OUTPUT=$(SIMMER_API_KEY="sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe" python3 fastloop_trader.py --live --quiet 2>&1)

# Check if trade was executed (look for "Bought" or "Trade failed" in output)
if echo "$OUTPUT" | grep -q "Bought\|Trade failed\|❌ Trade failed\|✅ Bought"; then
    # Trade executed or failed - send message
    echo "🚨 FastLoop trade activity detected"
    echo "Output:"
    echo "$OUTPUT"
    
    # Extract relevant trade info
    TRADE_INFO=$(echo "$OUTPUT" | grep -A2 -B2 "Bought\|Trade failed\|❌\|✅")
    
    # Send Telegram message (this would need to be implemented with OpenClaw messaging)
    # For now, just log it
    echo "TRADE DETECTED - Would send Telegram notification"
    echo "$TRADE_INFO"
    
    # Log to file for debugging
    echo "[$(date)] Trade detected:" >> /tmp/fastloop_trades.log
    echo "$OUTPUT" >> /tmp/fastloop_trades.log
    echo "---" >> /tmp/fastloop_trades.log
else
    # No trade - just log quietly
    echo "[$(date)] No trade executed" >> /tmp/fastloop_scans.log
fi

# Also check for errors in the output
if echo "$OUTPUT" | grep -q "Error\|error\|failed\|Failed\|❌"; then
    echo "⚠️ Error detected in FastLoop output"
    ERROR_MSG=$(echo "$OUTPUT" | grep -i "error\|failed\|❌" | head -3)
    echo "Error: $ERROR_MSG"
    
    # Log error
    echo "[$(date)] Error detected:" >> /tmp/fastloop_errors.log
    echo "$OUTPUT" >> /tmp/fastloop_errors.log
    echo "---" >> /tmp/fastloop_errors.log
fi