#!/usr/bin/env python3
"""
FastLoop trader with smart notifications
Only sends Telegram messages when trades execute or errors occur
"""

import os
import subprocess
import sys
from datetime import datetime

def run_fastloop():
    """Run FastLoop trader and capture output"""
    cmd = [
        "cd", "/home/agent/.openclaw/workspace/skills/polymarket-fast-loop",
        "&&",
        "SIMMER_API_KEY=sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe",
        "python3", "fastloop_trader.py", "--live", "--quiet"
    ]
    
    env = os.environ.copy()
    env['SIMMER_API_KEY'] = 'sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe'
    
    try:
        # Run the command
        result = subprocess.run(
            " ".join(cmd),
            shell=True,
            capture_output=True,
            text=True,
            env=env,
            cwd="/home/agent/.openclaw/workspace/skills/polymarket-fast-loop"
        )
        
        output = result.stdout + result.stderr
        return output, result.returncode
        
    except Exception as e:
        return f"Error running FastLoop: {e}", 1

def analyze_output(output):
    """Analyze output to determine if trade occurred or error happened"""
    trade_indicators = [
        "Bought",
        "Trade failed",
        "❌ Trade failed",
        "✅ Bought",
        "Executing",
        "shares @ $"
    ]
    
    error_indicators = [
        "Error:",
        "error:",
        "failed:",
        "Failed:",
        "❌",
        "⚠️",
        "Exception:",
        "Traceback"
    ]
    
    has_trade = any(indicator in output for indicator in trade_indicators)
    has_error = any(indicator in output for indicator in error_indicators)
    
    # Extract relevant lines
    relevant_lines = []
    lines = output.split('\n')
    
    if has_trade or has_error:
        # Get lines around indicators
        for i, line in enumerate(lines):
            if any(indicator in line for indicator in trade_indicators + error_indicators):
                # Add context (previous and next lines)
                start = max(0, i-2)
                end = min(len(lines), i+3)
                relevant_lines.extend(lines[start:end])
    
    return has_trade, has_error, relevant_lines

def create_message(has_trade, has_error, relevant_lines, output):
    """Create appropriate message based on what happened"""
    timestamp = datetime.now().strftime("%H:%M")
    
    if has_trade:
        # Trade executed
        trade_lines = "\n".join(relevant_lines[:10])  # Limit to 10 lines
        return f"🚨 FastLoop Trade Executed ({timestamp})\n\n{trade_lines}"
    
    elif has_error:
        # Error occurred
        error_lines = "\n".join(relevant_lines[:10])
        return f"⚠️ FastLoop Error ({timestamp})\n\n{error_lines}"
    
    else:
        # No trade, no error - return None (no message)
        return None

def main():
    print(f"🔄 FastLoop scan started at {datetime.now().strftime('%H:%M:%S')}")
    
    # Run FastLoop
    output, returncode = run_fastloop()
    
    # Analyze output
    has_trade, has_error, relevant_lines = analyze_output(output)
    
    # Create message if needed
    message = create_message(has_trade, has_error, relevant_lines, output)
    
    if message:
        # This is where we would send the Telegram message
        # In a cron job agentTurn, the agent would need to send the message
        print("📤 Would send Telegram message:")
        print(message)
        
        # For cron job delivery, we need to output this in a way that gets delivered
        # Since delivery.mode="none", we need the agent to send the message
        # This script would be called by an agent that can use the message tool
        print("\n[ACTION REQUIRED: Agent should send Telegram message if trade/error]")
    else:
        print("✅ Scan complete - no trade executed, no errors")
        print("📊 Summary: Market conditions not met for entry")
    
    # Log to file for debugging
    with open("/tmp/fastloop_scan.log", "a") as f:
        f.write(f"\n=== Scan at {datetime.now().isoformat()} ===\n")
        f.write(f"Trade: {has_trade}, Error: {has_error}\n")
        if has_trade or has_error:
            f.write("Relevant output:\n")
            f.write("\n".join(relevant_lines[:20]) + "\n")
        f.write("---\n")
    
    return 0 if not has_error else 1

if __name__ == "__main__":
    sys.exit(main())