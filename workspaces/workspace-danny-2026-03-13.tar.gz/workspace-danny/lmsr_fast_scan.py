#!/usr/bin/env python3
"""
Fast LMSR Dry-Run Scan
Quick scan for markets with extreme probabilities that might offer >15% edge.
"""

import os
import sys
from datetime import datetime, timezone

try:
    from simmer_sdk import SimmerClient
except ImportError:
    print("Error: simmer_sdk not installed")
    sys.exit(1)

def main():
    """Fast scan for extreme probability markets."""
    api_key = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"
    
    print("Fast LMSR Dry-Run Scan")
    print("=" * 60)
    print(f"Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print(f"API Key: {api_key[:20]}...")
    print()
    
    try:
        client = SimmerClient(api_key=api_key)
        
        # Fetch markets
        print("Fetching active markets...")
        markets = client.get_markets(limit=100, status='active')
        print(f"Found {len(markets)} active markets")
        print()
        
        # Look for markets with extreme probabilities
        extreme_markets = []
        for market in markets:
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            p = market.current_probability
            
            # Look for very high or very low probabilities
            if p > 0.75 or p < 0.25:
                extreme_markets.append({
                    'id': market.id,
                    'question': market.question[:60] + '...' if len(market.question) > 60 else market.question,
                    'probability': p,
                    'edge_opportunity': abs(p - 0.5)  # Distance from 50%
                })
        
        print(f"Found {len(extreme_markets)} markets with probabilities >75% or <25%")
        print()
        
        if not extreme_markets:
            print("No extreme probability markets found.")
            print("Current market probabilities are mostly balanced (25%-75% range).")
            print()
            print("For >15% edge opportunities, we need markets where:")
            print("  - Market probability > 80% (suggest BUY NO with >15% edge)")
            print("  - Market probability < 20% (suggest BUY YES with >15% edge)")
            return 1
        
        # Sort by edge opportunity (descending)
        extreme_markets.sort(key=lambda x: x['edge_opportunity'], reverse=True)
        
        print("TOP EXTREME PROBABILITY MARKETS:")
        print("-" * 60)
        
        for i, market in enumerate(extreme_markets[:10], 1):
            p = market['probability']
            edge_from_50 = market['edge_opportunity']
            
            if p > 0.75:
                action = "BUY NO"
                potential_edge = p - 0.5  # If true probability is 50%
                if p > 0.8:
                    edge_estimate = f"{potential_edge:.1%}+ (if mean reverts to 50%)"
                else:
                    edge_estimate = f"{potential_edge:.1%} (if mean reverts to 50%)"
            else:  # p < 0.25
                action = "BUY YES"
                potential_edge = 0.5 - p  # If true probability is 50%
                if p < 0.2:
                    edge_estimate = f"{potential_edge:.1%}+ (if mean reverts to 50%)"
                else:
                    edge_estimate = f"{potential_edge:.1%} (if mean reverts to 50%)"
            
            print(f"{i}. {market['question']}")
            print(f"   Probability: {p:.1%}")
            print(f"   Action: {action}")
            print(f"   Potential Edge: {edge_estimate}")
            print(f"   Market ID: {market['id'][:20]}...")
            print()
        
        # Check for >15% edge opportunities
        strong_opportunities = []
        for market in extreme_markets:
            p = market['probability']
            edge_from_50 = market['edge_opportunity']
            
            # Markets with >80% or <20% offer >30% edge if mean reverts to 50%
            if p > 0.8 or p < 0.2:
                strong_opportunities.append(market)
        
        print("=" * 60)
        print("STRONG EDGE OPPORTUNITIES (>15% potential edge):")
        print("-" * 60)
        
        if strong_opportunities:
            for i, market in enumerate(strong_opportunities[:5], 1):
                p = market['probability']
                action = "BUY NO" if p > 0.8 else "BUY YES"
                edge = abs(p - 0.5)
                
                print(f"{i}. {market['question']}")
                print(f"   Market: {p:.1%} | Action: {action}")
                print(f"   Edge if reverts to 50%: {edge:.1%}")
                print(f"   LMSR Note: High convexity cost expected at this edge")
                print()
            
            print("LMSR CONSIDERATIONS:")
            print("  • Markets with extreme probabilities have high convexity costs")
            print("  • Optimal position sizes will be smaller due to slippage")
            print("  • Expected EV must account for price impact of your trade")
            print()
            print("RECOMMENDED NEXT STEPS:")
            print("  1. Analyze these markets for mean reversion patterns")
            print("  2. Calculate precise LMSR convexity costs")
            print("  3. Determine optimal position sizes")
            print("  4. Execute small test trades if edge persists")
        else:
            print("No markets with >80% or <20% probability found.")
            print("Current extreme markets are in 25%-75% range.")
            print()
            print("For immediate >15% edge opportunities:")
            print("  • Wait for markets to become more extreme (>80% or <20%)")
            print("  • Look for new markets with imbalanced initial probabilities")
            print("  • Consider shorter timeframes for mean reversion plays")
        
        print()
        print("=" * 60)
        print("DRY-RUN COMPLETE - NO TRADES EXECUTED")
        print("=" * 60)
        
        return 0
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())