#!/usr/bin/env python3
"""
LMSR Dry-Run Scan with Real Market Data
Scans for opportunities with >15% edge, calculates optimal position sizes
considering LMSR convexity, and reports top 5 opportunities.
"""

import os
import sys
import math
import json
from datetime import datetime, timezone
from typing import List, Dict, Tuple, Optional

# Add workspace to path for imports
sys.path.insert(0, '/home/agent/.openclaw/workspace-danny')

try:
    from simmer_sdk import SimmerClient
    SIMMER_AVAILABLE = True
except ImportError:
    SIMMER_AVAILABLE = False
    print("Error: simmer_sdk not installed. Install with: pip install simmer-sdk")
    sys.exit(1)

class LMSRDryRunScanner:
    """
    LMSR-aware scanner for Polymarket opportunities with >15% edge.
    """
    
    def __init__(self, api_key: str):
        """
        Initialize scanner with API key.
        
        Args:
            api_key: Simmer API key (sk_live_...)
        """
        self.api_key = api_key
        self.client = SimmerClient(api_key=api_key)
        
        # LMSR parameters
        self.b = 100.0  # Liquidity parameter (higher = more liquid)
        self.min_edge = 0.15  # Minimum 15% edge requirement
        self.max_position_usd = 100.0  # Max position size
        
        # Probability model parameters
        self.mean_reversion_factor = 0.15  # How much to revert toward 50%
        self.crowd_extreme_threshold = 0.75  # Consider extreme when >75% or <25%
        
    def calculate_lmsr_price(self, quantities: List[float], outcome_index: int) -> float:
        """
        Calculate LMSR price for a specific outcome.
        
        Args:
            quantities: List of quantities for each outcome
            outcome_index: Index of outcome to price
            
        Returns:
            Price (probability) for the outcome
        """
        if self.b <= 0:
            raise ValueError("Liquidity parameter b must be positive")
            
        # LMSR price formula: p_k = e^(qk/b) / ∑ e^(qi/b)
        exponents = [q / self.b for q in quantities]
        max_exp = max(exponents)  # For numerical stability
        exp_terms = [math.exp(exp - max_exp) for exp in exponents]
        sum_exp = sum(exp_terms)
        
        if sum_exp == 0:
            return 1.0 / len(quantities)  # Equal probability if all zero
            
        return exp_terms[outcome_index] / sum_exp
    
    def calculate_convexity_cost(self, current_quantities: List[float], 
                                outcome_index: int, shares: float) -> float:
        """
        Estimate convexity cost (slippage) for buying shares.
        
        Args:
            current_quantities: Current market quantities
            outcome_index: Outcome to buy
            shares: Number of shares to buy
            
        Returns:
            Estimated convexity cost in probability units
        """
        # Price before trade
        price_before = self.calculate_lmsr_price(current_quantities, outcome_index)
        
        # Quantities after trade
        quantities_after = current_quantities.copy()
        quantities_after[outcome_index] += shares
        
        # Price after trade
        price_after = self.calculate_lmsr_price(quantities_after, outcome_index)
        
        # Convexity cost = average price increase per share
        return (price_after - price_before) * shares
    
    def calculate_optimal_position(self, p_true: float, p_market: float,
                                 current_quantities: List[float],
                                 outcome_index: int) -> Tuple[float, float]:
        """
        Calculate optimal position size considering convexity cost.
        
        Args:
            p_true: Your model's true probability
            p_market: Current market probability
            current_quantities: Current market quantities
            outcome_index: Outcome index
            
        Returns:
            Tuple of (optimal_shares, expected_ev)
        """
        if p_true <= p_market:
            return 0.0, 0.0  # No edge
            
        # Initial edge per share
        edge_per_share = p_true - p_market
        
        # Start with naive position (ignoring convexity)
        naive_shares = min(self.max_position_usd / p_market if p_market > 0 else 0, 1000)
        
        # Binary search for optimal position
        low, high = 0.0, naive_shares
        best_shares = 0.0
        best_ev = 0.0
        
        for _ in range(20):  # 20 iterations for precision
            mid = (low + high) / 2
            
            # Calculate total EV at this position
            gross_ev = edge_per_share * mid
            convexity_cost = self.calculate_convexity_cost(
                current_quantities, outcome_index, mid
            )
            net_ev = gross_ev - convexity_cost
            
            # Calculate EV at slightly larger position
            test_shares = mid * 1.01
            test_gross_ev = edge_per_share * test_shares
            test_convexity_cost = self.calculate_convexity_cost(
                current_quantities, outcome_index, test_shares
            )
            test_net_ev = test_gross_ev - test_convexity_cost
            
            # Check if increasing position increases EV
            if test_net_ev > net_ev:
                low = mid  # Can increase position
                best_shares = test_shares
                best_ev = test_net_ev
            else:
                high = mid  # Should decrease position
                
        # Apply safety buffer (10%)
        optimal_shares = best_shares * 0.9
        
        # Recalculate EV with buffer
        gross_ev = edge_per_share * optimal_shares
        convexity_cost = self.calculate_convexity_cost(
            current_quantities, outcome_index, optimal_shares
        )
        final_ev = gross_ev - convexity_cost
        
        return optimal_shares, final_ev
    
    def estimate_true_probability(self, p_market: float, market_data: Dict) -> float:
        """
        Estimate true probability based on market data.
        This is where the edge comes from - replace with your actual model!
        
        Current simple model: Mean reversion + crowd psychology
        """
        # Extreme crowd positions tend to revert
        if p_market > self.crowd_extreme_threshold:
            # Market is overly bullish, true probability likely lower
            revert_amount = (p_market - 0.5) * self.mean_reversion_factor
            p_true = p_market - revert_amount
        elif p_market < (1 - self.crowd_extreme_threshold):
            # Market is overly bearish, true probability likely higher
            revert_amount = (0.5 - p_market) * self.mean_reversion_factor
            p_true = p_market + revert_amount
        else:
            # Moderate market, look for smaller edges
            # Slight mean reversion toward 50%
            revert_amount = (p_market - 0.5) * (self.mean_reversion_factor / 2)
            p_true = p_market - revert_amount
        
        # Ensure probability stays in [0.01, 0.99] range
        p_true = max(0.01, min(0.99, p_true))
        
        return p_true
    
    def get_market_liquidity(self, market_id: str) -> List[float]:
        """
        Estimate market liquidity from market context.
        Returns estimated quantities for YES and NO outcomes.
        """
        try:
            context = self.client.get_market_context(market_id)
            
            # Try to extract liquidity information
            # This is a simplified estimation - real implementation would parse context
            if isinstance(context, dict):
                # Check for volume or liquidity indicators
                volume = context.get('volume_24h', 0)
                if volume > 0:
                    # Assume liquidity proportional to volume
                    base_liquidity = volume / 10.0
                else:
                    base_liquidity = 50.0  # Default base liquidity
            else:
                base_liquidity = 50.0
                
            return [base_liquidity, base_liquidity]
            
        except Exception as e:
            # Fallback to default liquidity
            return [50.0, 50.0]
    
    def scan_markets(self, limit: int = 100) -> List[Dict]:
        """
        Scan active markets for opportunities with >15% edge.
        
        Args:
            limit: Maximum number of markets to scan
            
        Returns:
            List of trading opportunities
        """
        opportunities = []
        
        print(f"Fetching {limit} active markets...")
        try:
            markets = self.client.get_markets(limit=limit, status='active')
        except Exception as e:
            print(f"Error fetching markets: {e}")
            return []
        
        print(f"Scanning {len(markets)} markets for >{self.min_edge:.0%} edge opportunities...")
        
        for i, market in enumerate(markets):
            # Skip if no probability data
            if not hasattr(market, 'current_probability') or market.current_probability is None:
                continue
                
            # Get market probability
            p_market = market.current_probability
            
            # Skip if market is too close to resolution (probability near 0 or 1)
            if p_market < 0.02 or p_market > 0.98:
                continue
                
            # Estimate true probability (this is where edge comes from)
            market_data = {
                'id': market.id,
                'question': market.question if hasattr(market, 'question') else 'Unknown',
                'p_market': p_market
            }
            
            p_true = self.estimate_true_probability(p_market, market_data)
            
            # Calculate edge
            edge = p_true - p_market
            abs_edge = abs(edge)
            
            # Check if edge meets minimum threshold
            if abs_edge < self.min_edge:
                continue
                
            # Determine trade direction
            if edge > 0:
                outcome_index = 0  # Buy YES
                outcome = "YES"
            else:
                outcome_index = 1  # Buy NO
                outcome = "NO"
                # For NO outcome, use complementary probabilities
                p_true = 1 - p_true
                p_market = 1 - p_market
                edge = abs(edge)
            
            # Get market liquidity
            current_quantities = self.get_market_liquidity(market.id)
            
            # Calculate optimal position
            shares, expected_ev = self.calculate_optimal_position(
                p_true, p_market, current_quantities, outcome_index
            )
            
            # Convert EV to USD (each share = $1 at resolution)
            expected_ev_usd = expected_ev * 100  # Since probability is 0-1 scale
            
            # Skip if position too small or EV negative
            if shares < 1.0 or expected_ev_usd <= 0:
                continue
                
            # Calculate position value
            position_value_usd = shares * p_market
            
            opportunities.append({
                'market_id': market.id,
                'market_question': market.question[:80] + '...' if len(market.question) > 80 else market.question,
                'p_market': p_market,
                'p_true': p_true,
                'edge_pct': edge * 100,  # Convert to percentage
                'optimal_shares': shares,
                'position_value_usd': position_value_usd,
                'expected_ev_usd': expected_ev_usd,
                'outcome': outcome,
                'edge_abs': edge,
                'convexity_impact': (expected_ev_usd / (shares * edge)) if shares * edge > 0 else 0
            })
            
            # Progress indicator
            if (i + 1) % 20 == 0:
                print(f"  Scanned {i + 1}/{len(markets)} markets...")
        
        # Sort by expected EV (descending)
        opportunities.sort(key=lambda x: x['expected_ev_usd'], reverse=True)
        
        return opportunities
    
    def generate_report(self, opportunities: List[Dict], top_n: int = 5) -> str:
        """
        Generate formatted report of top opportunities.
        
        Args:
            opportunities: List of opportunities
            top_n: Number of top opportunities to include
            
        Returns:
            Formatted report string
        """
        if not opportunities:
            return "No opportunities found with >15% edge."
        
        report_lines = []
        report_lines.append("=" * 80)
        report_lines.append("LMSR DRY-RUN SCAN RESULTS")
        report_lines.append("=" * 80)
        report_lines.append(f"Scan time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
        report_lines.append(f"Markets scanned: {len(opportunities)} opportunities found")
        report_lines.append(f"Minimum edge threshold: {self.min_edge:.0%}")
        report_lines.append("")
        
        # Top opportunities
        top_opportunities = opportunities[:top_n]
        report_lines.append(f"TOP {len(top_opportunities)} OPPORTUNITIES:")
        report_lines.append("")
        
        for i, opp in enumerate(top_opportunities, 1):
            report_lines.append(f"{i}. {opp['market_question']}")
            report_lines.append(f"   Market ID: {opp['market_id']}")
            report_lines.append(f"   Market Probability: {opp['p_market']:.1%}")
            report_lines.append(f"   Model Probability: {opp['p_true']:.1%}")
            report_lines.append(f"   Edge: {opp['edge_pct']:+.1f}%")
            report_lines.append(f"   Trade: BUY {opp['outcome']} @ {opp['optimal_shares']:.1f} shares")
            report_lines.append(f"   Position Value: ${opp['position_value_usd']:.2f}")
            report_lines.append(f"   Expected EV: ${opp['expected_ev_usd']:.2f}")
            report_lines.append(f"   Convexity Impact: {opp['convexity_impact']:.1%} of gross edge")
            report_lines.append("")
        
        # Summary statistics
        if len(opportunities) > 0:
            total_ev = sum(opp['expected_ev_usd'] for opp in opportunities[:top_n])
            avg_edge = sum(opp['edge_pct'] for opp in opportunities[:top_n]) / len(top_opportunities)
            max_edge = max(opp['edge_pct'] for opp in opportunities[:top_n])
            
            report_lines.append("SUMMARY STATISTICS:")
            report_lines.append(f"  Total expected EV (top {top_n}): ${total_ev:.2f}")
            report_lines.append(f"  Average edge: {avg_edge:+.1f}%")
            report_lines.append(f"  Maximum edge: {max_edge:+.1f}%")
            report_lines.append(f"  Opportunities meeting >15% edge: {len(opportunities)}")
        
        report_lines.append("")
        report_lines.append("=" * 80)
        report_lines.append("NOTE: This is a DRY-RUN only - no trades were executed.")
        report_lines.append("Probability model uses mean reversion + crowd psychology.")
        report_lines.append("LMSR convexity costs are estimated and included in EV calculation.")
        report_lines.append("=" * 80)
        
        return "\n".join(report_lines)


def main():
    """Main function for LMSR dry-run scan."""
    # Use the provided API key
    api_key = "sk_live_92983b88e10d6472bce8ae6fa82383c4ee38f93a08dca8eca715f894006f00fe"
    
    print("Initializing LMSR Dry-Run Scanner...")
    print(f"Using API key: {api_key[:20]}...")
    
    # Initialize scanner
    scanner = LMSRDryRunScanner(api_key=api_key)
    
    # Run scan
    print("\nStarting market scan...")
    opportunities = scanner.scan_markets(limit=150)  # Scan more markets for better coverage
    
    # Generate and print report
    report = scanner.generate_report(opportunities, top_n=5)
    print("\n" + report)
    
    # Also save report to file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"/home/agent/.openclaw/workspace-danny/lmsr_dry_run_{timestamp}.txt"
    
    with open(report_file, 'w') as f:
        f.write(report)
    
    print(f"\nFull report saved to: {report_file}")
    
    # Return exit code based on findings
    if opportunities:
        print(f"\n✓ Found {len(opportunities)} opportunities with >15% edge.")
        return 0
    else:
        print("\n✗ No opportunities found with >15% edge.")
        return 1


if __name__ == "__main__":
    sys.exit(main())