#!/usr/bin/env python3
import requests
import os

NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}
DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"

# Task ID for task 6
task_id = "lFyocju88D30"

filter_prop = {
    "property": "Dart Task ID",
    "rich_text": {"contains": task_id}
}

url = f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query"
print(f"Querying Notion data source for task ID {task_id}...")
try:
    resp = requests.post(url, headers=NOTION_HEADERS, json={"filter": filter_prop}, timeout=(10, 30))
    print(f"Status: {resp.status_code}")
    if resp.status_code == 200:
        data = resp.json()
        print(f"Results: {len(data.get('results', []))}")
        for r in data.get('results', []):
            print(f"  Page ID: {r.get('id')}")
    else:
        print(f"Error: {resp.text}")
except Exception as e:
    print(f"Exception: {e}")
    import traceback
    traceback.print_exc()