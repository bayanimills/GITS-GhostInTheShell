#!/usr/bin/env python3
import os
import sys
import requests
import json
import time
import signal

class TimeoutException(Exception):
    pass

def timeout_handler(signum, frame):
    raise TimeoutException("Function timed out")

# Load .env file for DART_API_TOKEN
env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))
from scripts.dart_client import DartClient

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"
DATABASE_ID = "37691f15-655f-4a54-a3eb-915692442433"
STROKE_TASK_ID = "YhH8uggrObRf"

def log(msg):
    print(f"[{time.time():.2f}] {msg}")
    sys.stdout.flush()

def query_notion_database(filter_dict=None):
    """Query Notion database using data_source_id."""
    url = f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query"
    payload = {}
    if filter_dict:
        payload["filter"] = filter_dict
    log(f"  POST {url}")
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    data = resp.json()
    return data.get("results", [])

def update_page(page_id, properties):
    """Update an existing page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    log(f"  PATCH {url}")
    resp = requests.patch(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    return resp.json()

def dart_task_to_notion_properties(task):
    """Convert Dart task to Notion properties."""
    title = task.get("title", "Untitled")
    status = task.get("status", "To-do")
    priority = task.get("priority", "Medium")
    due_at = task.get("dueAt")
    tags = task.get("tags", [])
    task_id = task.get("id")
    parent_id = task.get("parentId")
    
    phase = "General"
    if "stroke-followup" in tags:
        phase = "Stroke Follow-up"
    elif parent_id == STROKE_TASK_ID:
        phase = "Stroke Follow-up"
    elif "patient-edward-mills" in tags:
        phase = "Patient Management"
    
    due_date = None
    if due_at:
        try:
            if "T" in due_at:
                due_date = due_at.split("T")[0]
            else:
                due_date = due_at
        except:
            pass
    
    properties = {
        "Name": {"title": [{"text": {"content": title}}]},
        "Status": {"select": {"name": status if status in ["To-do", "Doing", "Done"] else "To-do"}},
        "Priority": {"select": {"name": priority if priority else "Medium"}},
        "Phase": {"select": {"name": phase}},
        "Dart Task ID": {"rich_text": [{"text": {"content": task_id}}]},
        "Tags": {"multi_select": [{"name": tag} for tag in tags if tag not in ["patient-edward-mills", "stroke-followup"]]},
    }
    if due_date:
        properties["Due Date"] = {"date": {"start": due_date}}
    
    return properties

def main():
    log("Starting debug")
    client = DartClient()
    log("Fetching tasks")
    response = client.list_tasks(limit=200)
    all_tasks = response.get("results", []) if isinstance(response, dict) else response
    log(f"Total tasks: {len(all_tasks)}")
    
    edward_tasks = []
    for t in all_tasks:
        tags = t.get("tags", [])
        parent = t.get("parentId")
        if "patient-edward-mills" in tags:
            edward_tasks.append(t)
        elif parent == STROKE_TASK_ID:
            edward_tasks.append(t)
        elif "stroke-followup" in tags:
            edward_tasks.append(t)
    
    log(f"Edward tasks: {len(edward_tasks)}")
    # Limit to first 6
    edward_tasks = edward_tasks[:6]
    
    for i, task in enumerate(edward_tasks):
        log(f"\n=== Processing task {i+1}: {task.get('title')} ({task.get('id')}) ===")
        task_id = task["id"]
        # Set alarm for 15 seconds per task
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(15)
        try:
            log("  Step 1: Query Notion")
            filter_prop = {"property": "Dart Task ID", "rich_text": {"contains": task_id}}
            existing = query_notion_database(filter_prop)
            log(f"  Query result: {len(existing)} pages")
            properties = dart_task_to_notion_properties(task)
            if existing:
                page_id = existing[0]["id"]
                log(f"  Step 2: Update page {page_id}")
                update_page(page_id, properties)
            else:
                log("  Step 2: Create new page (skipping)")
            log("  Task completed")
        except TimeoutException:
            log(f"  TIMEOUT on task {i+1}")
            break
        except Exception as e:
            log(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
        finally:
            signal.alarm(0)  # disable alarm
        time.sleep(1)
    
    log("Debug finished")

if __name__ == "__main__":
    main()