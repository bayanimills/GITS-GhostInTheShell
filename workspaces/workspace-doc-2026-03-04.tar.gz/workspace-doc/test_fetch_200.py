#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import time

print(f"Starting fetch at {time.time()}")
client = DartClient()
print("Client created, calling list_tasks(limit=200)")
response = client.list_tasks(limit=200)
print(f"Response type: {type(response)}")
if isinstance(response, dict):
    print(f"Count: {response.get('count')}")
    print(f"Results length: {len(response.get('results', []))}")
else:
    print(f"Response: {response}")
print(f"Done at {time.time()}")