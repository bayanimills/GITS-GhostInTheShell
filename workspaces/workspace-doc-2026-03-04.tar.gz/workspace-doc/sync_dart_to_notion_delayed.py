#!/usr/bin/env python3
"""
Sync Dart tasks to Notion Patient Tasks database.
"""
import os
import sys
import requests
import json
import time
from datetime import datetime, timezone

# Load .env file for DART_API_TOKEN
env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val
else:
    print(f"Warning: .env file not found at {env_path}")

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))
from scripts.dart_client import DartClient

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Database IDs (from created database)
DATABASE_ID = "37691f15-655f-4a54-a3eb-915692442433"
DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"

# Stroke task ID (parent)
STROKE_TASK_ID = "YhH8uggrObRf"

# Status mapping from Dart to Notion (Dart status values are exactly "To-do", "Doing", "Done")
STATUS_MAP = {
    "To-do": "To-do",
    "Doing": "Doing",
    "Done": "Done",
}

def query_notion_database(filter_dict=None):
    """Query Notion database with optional filter."""
    url = f"https://api.notion.com/v1/databases/{DATABASE_ID}/query"
    payload = {}
    if filter_dict:
        payload["filter"] = filter_dict
    try:
        resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
        resp.raise_for_status()
        return resp.json().get("results", [])
    except Exception as e:
        print(f"  Notion query error: {e}")
        return []

def create_page_in_database(properties):
    """Create a new page in the database."""
    url = "https://api.notion.com/v1/pages"
    payload = {
        "parent": {"database_id": DATABASE_ID},
        "properties": properties,
    }
    try:
        resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"  Notion create error: {e}")
        return None

def update_page(page_id, properties):
    """Update an existing page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    try:
        resp = requests.patch(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"  Notion update error: {e}")
        return None

def dart_task_to_notion_properties(task):
    """Convert Dart task to Notion properties."""
    title = task.get("title", "Untitled")
    status = task.get("status", "To-do")
    priority = task.get("priority", "Medium")
    due_at = task.get("dueAt")
    tags = task.get("tags", [])
    task_id = task.get("id")
    folder = task.get("dartboard", "")
    parent_id = task.get("parentId")
    
    # Determine phase based on tags or parent
    phase = "General"
    if "stroke-followup" in tags:
        phase = "Stroke Follow-up"
    elif parent_id == STROKE_TASK_ID:
        phase = "Stroke Follow-up"
    elif "patient-edward-mills" in tags:
        phase = "Patient Management"
    
    # Format due date
    due_date = None
    if due_at:
        try:
            # Dart dueAt can be just date "YYYY-MM-DD" or full ISO
            if "T" in due_at:
                due_date = due_at.split("T")[0]
            else:
                due_date = due_at
        except:
            pass
    
    properties = {
        "Name": {"title": [{"text": {"content": title}}]},
        "Status": {"select": {"name": STATUS_MAP.get(status, "To-do")}},
        "Priority": {"select": {"name": priority if priority else "Medium"}},
        "Phase": {"select": {"name": phase}},
        "Dart Task ID": {"rich_text": [{"text": {"content": task_id}}]},
        "Tags": {"multi_select": [{"name": tag} for tag in tags if tag not in ["patient-edward-mills", "stroke-followup"]]},
    }
    if due_date:
        properties["Due Date"] = {"date": {"start": due_date}}
    
    return properties

def sync_dart_tasks():
    """Main sync function."""
    client = DartClient()
    # Fetch Edward Mills tasks (filter by tag)
    response = client.list_tasks(limit=200)
    all_tasks = response.get("results", []) if isinstance(response, dict) else response
    print(f"Total tasks fetched from Dart: {len(all_tasks)}")
    # Include tasks tagged patient-edward-mills, subtasks of stroke task, or stroke-followup
    edward_tasks = []
    for t in all_tasks:
        tags = t.get("tags", [])
        parent = t.get("parentId")
        if "patient-edward-mills" in tags:
            edward_tasks.append(t)
        elif parent == STROKE_TASK_ID:
            edward_tasks.append(t)
        elif "stroke-followup" in tags:
            edward_tasks.append(t)
    print(f"Found {len(edward_tasks)} Edward Mills tasks in Dart.")
    # Optional limit for debugging
    import os
    limit = os.environ.get('SYNC_LIMIT')
    if limit:
        limit = int(limit)
        edward_tasks = edward_tasks[:limit]
        print(f"Limiting to {limit} tasks for debugging.")
    
    # For each task, sync
    for i, task in enumerate(edward_tasks):
        try:
            task_id = task["id"]
            print(f"Syncing task {i+1}/{len(edward_tasks)}: {task['title']} ({task_id})")
            # Check if already exists in Notion
            filter_prop = {
                "property": "Dart Task ID",
                "rich_text": {"contains": task_id}
            }
            existing = query_notion_database(filter_prop)
            properties = dart_task_to_notion_properties(task)
            if existing:
                # Update existing page
                page_id = existing[0]["id"]
                print(f"  Updating existing page {page_id}")
                update_page(page_id, properties)
            else:
                # Create new page
                print(f"  Creating new page")
                create_page_in_database(properties)
            print(f"  Done")
            # Add delay between tasks to avoid rate limiting (1 second)
            if i < len(edward_tasks) - 1:
                time.sleep(1)
        except Exception as e:
            print(f"  Error syncing task {task_id}: {e}")
            import traceback
            traceback.print_exc()
    
    print("Sync completed.")

if __name__ == "__main__":
    try:
        sync_dart_tasks()
    except Exception as e:
        print(f"Error during sync: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)