#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient

client = DartClient()
tasks = client.list_tasks(limit=5)
print(f"Type of response: {type(tasks)}")
print(f"Response: {tasks}")
if isinstance(tasks, list):
    print(f"Length: {len(tasks)}")
    for i, t in enumerate(tasks):
        print(f"Item {i} type: {type(t)}")
        if isinstance(t, dict):
            print(f"  Title: {t.get('title')}")
            print(f"  ID: {t.get('id')}")
            print(f"  Tags: {t.get('tags')}")
        else:
            print(f"  Value: {t}")
else:
    print(f"Tasks is not a list: {tasks}")