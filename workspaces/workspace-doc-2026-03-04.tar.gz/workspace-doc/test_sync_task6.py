#!/usr/bin/env python3
import os
import sys
import requests
import time

# Load .env file for DART_API_TOKEN
env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))
from scripts.dart_client import DartClient

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Database IDs (from created database)
DATABASE_ID = "37691f15-655f-4a54-a3eb-915692442433"
DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"

# Stroke task ID (parent)
STROKE_TASK_ID = "YhH8uggrObRf"

# Status mapping from Dart to Notion (Dart status values are exactly "To-do", "Doing", "Done")
STATUS_MAP = {
    "To-do": "To-do",
    "Doing": "Doing",
    "Done": "Done",
}

def query_notion_database(filter_dict=None):
    """Query Notion database using data_source_id."""
    url = f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query"
    payload = {}
    if filter_dict:
        payload["filter"] = filter_dict
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    data = resp.json()
    return data.get("results", [])

def update_page(page_id, properties):
    """Update an existing page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    print(f"  Updating page {page_id} with payload: {json.dumps(payload, indent=2)}")
    resp = requests.patch(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    return resp.json()

def dart_task_to_notion_properties(task):
    """Convert Dart task to Notion properties."""
    title = task.get("title", "Untitled")
    status = task.get("status", "To-do")
    priority = task.get("priority", "Medium")
    due_at = task.get("dueAt")
    tags = task.get("tags", [])
    task_id = task.get("id")
    folder = task.get("dartboard", "")
    parent_id = task.get("parentId")
    
    # Determine phase based on tags or parent
    phase = "General"
    if "stroke-followup" in tags:
        phase = "Stroke Follow-up"
    elif parent_id == STROKE_TASK_ID:
        phase = "Stroke Follow-up"
    elif "patient-edward-mills" in tags:
        phase = "Patient Management"
    
    # Format due date
    due_date = None
    if due_at:
        try:
            # Dart dueAt can be just date "YYYY-MM-DD" or full ISO
            if "T" in due_at:
                due_date = due_at.split("T")[0]
            else:
                due_date = due_at
        except:
            pass
    
    properties = {
        "Name": {"title": [{"text": {"content": title}}]},
        "Status": {"select": {"name": STATUS_MAP.get(status, "To-do")}},
        "Priority": {"select": {"name": priority if priority else "Medium"}},
        "Phase": {"select": {"name": phase}},
        "Dart Task ID": {"rich_text": [{"text": {"content": task_id}}]},
        "Tags": {"multi_select": [{"name": tag} for tag in tags if tag not in ["patient-edward-mills", "stroke-followup"]]},
    }
    if due_date:
        properties["Due Date"] = {"date": {"start": due_date}}
    
    return properties

import json

client = DartClient()
response = client.list_tasks(limit=200)
all_tasks = response.get("results", []) if isinstance(response, dict) else response

# Find task 6
task6 = None
for t in all_tasks:
    if t.get("id") == "lFyocju88D30":
        task6 = t
        break

if task6:
    print(f"Found task: {task6.get('title')}")
    task_id = task6["id"]
    # Check if already exists in Notion
    filter_prop = {
        "property": "Dart Task ID",
        "rich_text": {"contains": task_id}
    }
    print("Querying Notion...")
    existing = query_notion_database(filter_prop)
    print(f"Existing pages: {len(existing)}")
    properties = dart_task_to_notion_properties(task6)
    print(f"Properties: {json.dumps(properties, indent=2)}")
    if existing:
        page_id = existing[0]["id"]
        print(f"Updating page {page_id}")
        result = update_page(page_id, properties)
        print(f"Update result: {result}")
    else:
        print("No existing page")
else:
    print("Task not found")