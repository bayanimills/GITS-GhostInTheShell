#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient

client = DartClient()
response = client.list_tasks(limit=200)
all_tasks = response.get("results", []) if isinstance(response, dict) else response

STROKE_TASK_ID = "YhH8uggrObRf"
edward_tasks = []
for t in all_tasks:
    tags = t.get("tags", [])
    parent = t.get("parentId")
    if "patient-edward-mills" in tags:
        edward_tasks.append(t)
    elif parent == STROKE_TASK_ID:
        edward_tasks.append(t)
    elif "stroke-followup" in tags:
        edward_tasks.append(t)

print(f"Found {len(edward_tasks)} Edward Mills tasks:")
for i, t in enumerate(edward_tasks):
    print(f"{i+1}. ID: {t.get('id')}")
    print(f"   Title: {t.get('title')}")
    print(f"   Status: {t.get('status')}")
    print(f"   Tags: {t.get('tags')}")
    print(f"   Parent: {t.get('parentId')}")
    print()