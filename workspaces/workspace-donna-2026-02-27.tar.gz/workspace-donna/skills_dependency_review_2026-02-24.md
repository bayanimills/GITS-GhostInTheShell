# Skills Dependency Review
## Manual Review of 10 Skills Without Dependency Metadata

**Date**: 2026-02-24  
**Time**: 03:55 AM (Australia/Sydney)  
**Context**: Autonomous work window (03:30‑07:00) for internal/non‑destructive operations  
**Total skills**: 54  
**Skills needing review**: 10  

**Goal**: Review each SKILL.md file, extract dependencies, update `skills_metadata.json`

---

## Review Process
1. Read SKILL.md frontmatter and content
2. Identify required:
   - Binaries (bins)
   - Packages (packages) 
   - Credentials (credentials)
   - External services (external)
   - Configuration (config)
3. Update dependencies in `skills_metadata.json`
4. Test if possible (optional)

---

## Skill Reviews

### 1. bluebubbles
- **Location**: `/home/agent/openclaw/skills/bluebubbles/SKILL.md`
- **Frontmatter metadata**: `{ "openclaw": { "emoji": "🫧", "requires": { "config": ["channels.bluebubbles"] } } }`
- **Description**: iMessage integration via BlueBubbles
- **Dependencies found**:
  - **Config**: `channels.bluebubbles` (serverUrl/password/webhookPath)
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: BlueBubbles server configuration
  - **External**: BlueBubbles server
- **Update required**: Add config dependency to metadata

### 2. canvas
- **Location**: `/home/agent/openclaw/skills/canvas/SKILL.md`
- **Frontmatter metadata**: None
- **Description**: Display HTML content on connected OpenClaw nodes (Mac app, iOS, Android)
- **Dependencies found**:
  - **Config**: None specified (but requires node bridge setup)
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: None
  - **External**: OpenClaw nodes with canvas capability
- **Update required**: No explicit dependencies; mark as minimal

### 3. coding-agent
- **Location**: `/home/agent/openclaw/skills/coding-agent/SKILL.md`
- **Frontmatter metadata**: None
- **Description**: Delegate coding tasks to Codex, Claude Code, or Pi agents via background process
- **Dependencies found**:
  - **Config**: None specified
  - **Binaries**: `bash` with pty support (implicit)
  - **Packages**: None specified
  - **Credentials**: None
  - **External**: Codex, Claude Code, or Pi agent access
- **Update required**: Add implicit bash dependency

### 4. discord
- **Location**: `/home/agent/openclaw/skills/discord/SKILL.md`
- **Frontmatter metadata**: `{ "openclaw": { "emoji": "👾", "requires": { "config": ["channels.discord"] } } }`
- **Description**: Use when you need to control Discord from OpenClaw via the discord tool
- **Dependencies found**:
  - **Config**: `channels.discord` (bot token configuration)
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: Discord bot token
  - **External**: Discord API
- **Update required**: Add config dependency to metadata

### 5. food-order
- **Location**: `/home/agent/openclaw/skills/food-order/SKILL.md`
- **Frontmatter metadata**: None
- **Description**: Food ordering automation (Uber Eats, DoorDash, etc.)
- **Dependencies found**:
  - **Config**: None specified
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: Food delivery service accounts (implicit)
  - **External**: Food delivery APIs (Uber Eats, DoorDash)
- **Update required**: No explicit dependencies; mark as external service dependent

### 6. healthcheck
- **Location**: `/home/agent/openclaw/skills/healthcheck/SKILL.md`
- **Frontmatter metadata**: `{ "openclaw": { "emoji": "🩺", "requires": { "env": ["OPENCLAW_GOVERNANCE_RISK_TOLERANCE"] } } }`
- **Description**: Host security hardening and risk‑tolerance configuration for OpenClaw deployments
- **Dependencies found**:
  - **Env**: `OPENCLAW_GOVERNANCE_RISK_TOLERANCE`
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: None
  - **External**: None
- **Update required**: Add env dependency to metadata

### 7. notion
- **Location**: `/home/agent/openclaw/skills/notion/SKILL.md`
- **Frontmatter metadata**: `{ "openclaw": { "emoji": "📝", "requires": { "env": ["NOTION_API_KEY"] }, "primaryEnv": "NOTION_API_KEY" } }`
- **Description**: Notion API for creating and managing pages, databases, and blocks
- **Dependencies found**:
  - **Env**: `NOTION_API_KEY`
  - **Binaries**: `curl` (for API calls, implicit)
  - **Packages**: None specified
  - **Credentials**: Notion API key
  - **External**: Notion API
- **Update required**: Add env dependency to metadata

### 8. skill-creator
- **Location**: `/home/agent/openclaw/skills/skill-creator/SKILL.md`
- **Frontmatter metadata**: None
- **Description**: Create or update AgentSkills
- **Dependencies found**:
  - **Config**: None specified
  - **Binaries**: `python3` (for scripts)
  - **Packages**: None specified
  - **Credentials**: None
  - **External**: None
- **Update required**: Add python3 dependency

### 9. slack
- **Location**: `/home/agent/openclaw/skills/slack/SKILL.md`
- **Frontmatter metadata**: `{ "openclaw": { "emoji": "💬", "requires": { "config": ["channels.slack"] } } }`
- **Description**: Use when you need to control Slack from OpenClaw via the slack tool
- **Dependencies found**:
  - **Config**: `channels.slack` (bot token configuration)
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: Slack bot token
  - **External**: Slack API
- **Update required**: Add config dependency to metadata

### 10. voice-call
- **Location**: `/home/agent/openclaw/skills/voice-call/SKILL.md`
- **Frontmatter metadata**: `{ "openclaw": { "emoji": "📞", "skillKey": "voice-call", "requires": { "config": ["plugins.entries.voice-call.enabled"] } } }`
- **Description**: Start voice calls via the OpenClaw voice‑call plugin
- **Dependencies found**:
  - **Config**: `plugins.entries.voice-call.enabled` (and provider config)
  - **Binaries**: None specified
  - **Packages**: None specified
  - **Credentials**: Twilio/Telnyx/Plivo API keys (depending on provider)
  - **External**: Voice service provider (Twilio, Telnyx, Plivo)
- **Update required**: Add config dependency to metadata

---

## Summary of Changes Needed

### ✅ **All updates completed (03:56)**
- **Metadata file updated**: `skills_metadata.json` with dependencies for all 10 skills
- **Update script**: `update_skills_metadata.py` applied changes
- **Backup created**: `skills_metadata.json.backup`
- **Summary report**: `skills_metadata_update_summary.md`

### **Dependency Categories Added**
1. **Config dependencies** (4 skills):
   - `bluebubbles` → `channels.bluebubbles`
   - `discord` → `channels.discord`
   - `slack` → `channels.slack`
   - `voice-call` → `plugins.entries.voice-call.enabled`

2. **Environment dependencies** (2 skills):
   - `healthcheck` → `OPENCLAW_GOVERNANCE_RISK_TOLERANCE`
   - `notion` → `NOTION_API_KEY`

3. **Binary dependencies** (3 skills):
   - `coding-agent` → `bash`
   - `notion` → `curl`
   - `skill-creator` → `python3`

4. **Credential dependencies** (6 skills):
   - `bluebubbles` → BlueBubbles server config
   - `discord` → Discord bot token
   - `food-order` → Uber Eats/DoorDash accounts
   - `notion` → Notion API key
   - `slack` → Slack bot token
   - `voice-call` → Twilio/Telnyx/Plivo API keys

5. **External service dependencies** (7 skills):
   - `bluebubbles` → BlueBubbles server
   - `canvas` → OpenClaw nodes with canvas capability
   - `coding-agent` → Codex/Claude Code/Pi agent access
   - `discord` → Discord API
   - `food-order` → Uber Eats/DoorDash APIs
   - `notion` → Notion API
   - `slack` → Slack API
   - `voice-call` → Twilio/Telnyx/Plivo API

### **Metadata Source Updated**
- All 10 skills now have `"metadata_source": "manual_review"`
- `last_verified` date updated to 2026-02-24

### **Verification Status**
- ✅ Dependencies documented in this file
- ✅ Metadata file updated
- ✅ Backup preserved
- ❌ Functional testing not performed (autonomous work constraints)

---

## Notes
- Some skills may have dependencies not explicitly stated in SKILL.md
- Configuration dependencies are different from binary/package dependencies
- Update `metadata_source` to "manual_review" for reviewed skills
- **Next step**: Run validation script (`check_dependencies.py`) to confirm dependencies

---

**File created by**: Donna (autonomous work during 03:30‑07:00 window)