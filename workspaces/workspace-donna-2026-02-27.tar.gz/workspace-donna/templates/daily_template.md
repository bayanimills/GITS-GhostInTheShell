---
timestamp: {{timestamp}}
agent: donna
tags: [#daily]
source: manual
---

# {{date}} — Daily Summary

Summary:
- 

Decisions:
- 

Actions:
- 

Alerts:
- 

External events:
- 

Next steps:
- 

Source: {{path}}
