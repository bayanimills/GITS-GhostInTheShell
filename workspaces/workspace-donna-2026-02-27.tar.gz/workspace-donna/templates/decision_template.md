---
timestamp: {{timestamp}}
agent: donna
tags: [#decision]
source: manual
---

# Decision: {{title}}

Rationale:

Alternatives considered:

Owner:

Impact:

Review date:

Source: {{path}}
