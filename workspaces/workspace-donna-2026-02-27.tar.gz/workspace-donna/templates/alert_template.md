---
timestamp: {{timestamp}}
agent: donna
tags: [#alert]
severity: {{severity}}
source: automation
---

# Alert: {{summary}}

Timestamp: {{timestamp}}

Evidence:
- {{evidence}}

Suggested remediation:
- 

Source: {{path}}
