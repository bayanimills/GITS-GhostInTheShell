#!/bin/bash
# Mark all unread emails as read
set -e
ACCOUNT="bayanimills@gmail.com"
GOG="/home/agent/.linuxbrew/bin/gog"

echo "Fetching unread threads..."
JSON=$("$GOG" gmail search "is:unread" --max 100 --json --account "$ACCOUNT")
if [ $? -ne 0 ]; then
    echo "Failed to fetch threads."
    exit 1
fi

IDS=$(echo "$JSON" | jq -r '.threads[] | .id')
COUNT=$(echo "$IDS" | wc -l)
echo "Found $COUNT unread threads."

i=0
for id in $IDS; do
    ((i++))
    echo -n "[$i/$COUNT] Marking read: $id ... "
    "$GOG" gmail labels modify "$id" --remove UNREAD --account "$ACCOUNT" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "OK"
    else
        echo "FAILED"
    fi
done

echo "Done."