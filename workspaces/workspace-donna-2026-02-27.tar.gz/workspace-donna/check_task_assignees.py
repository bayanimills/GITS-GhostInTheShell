#!/usr/bin/env python3
"""
Quick script to check assignees of overdue tasks mentioned in memory.
"""

import os
import sys

# Add DartAI scripts to path
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')

try:
    from dartai_client import get
except ImportError as e:
    print(f"Error importing dartai_client: {e}")
    sys.exit(1)

def fetch_all_tasks_with_assignees():
    """Fetch all tasks and show assignees for specific titles."""
    try:
        # Fetch tasks (limit 100)
        result = get('tasks/list', params={'limit': 100, 'no_defaults': True})
        tasks = result.get('results', [])
        
        print(f"Total tasks fetched: {len(tasks)}")
        
        # Look for specific titles mentioned in memory
        target_patterns = [
            'New financial files detected',
            'Aria Test',
            'Test task from OpenClaw integration',
            'SMBF',
            'Notion dashboard',
            'calendar event'
        ]
        
        matches = []
        for task in tasks:
            title = task.get('title', '').lower()
            for pattern in target_patterns:
                if pattern.lower() in title:
                    matches.append(task)
                    break
        
        print(f"\nMatching tasks found: {len(matches)}")
        
        # Print details
        for task in matches:
            title = task.get('title', 'No title')
            assignee = task.get('assignee', 'Unassigned')
            due = task.get('due', 'No due date')
            status = task.get('status', 'No status')
            task_id = task.get('id', 'No ID')
            print(f"- {title}")
            print(f"  Assignee: {assignee}")
            print(f"  Status: {status}")
            print(f"  Due: {due}")
            print(f"  ID: {task_id}")
            print()
        
        # Also show all assignees distribution
        print("\n=== All task assignee distribution ===")
        assignee_counts = {}
        for task in tasks:
            assignee = task.get('assignee', 'Unassigned')
            assignee_counts[assignee] = assignee_counts.get(assignee, 0) + 1
        
        for assignee, count in sorted(assignee_counts.items(), key=lambda x: x[1], reverse=True):
            print(f"{assignee}: {count} tasks")
        
        return matches
        
    except Exception as e:
        print(f"Error fetching tasks: {e}")
        return []

if __name__ == '__main__':
    # Check API key
    if not os.environ.get('DARTAI_API_KEY') and not os.environ.get('DARTAI_SHARED_TOKEN'):
        print("Warning: No DartAI API key found in environment")
        print("Set DARTAI_API_KEY or DARTAI_SHARED_TOKEN environment variable")
        # Continue anyway - might work without auth for public endpoints
    
    fetch_all_tasks_with_assignees()