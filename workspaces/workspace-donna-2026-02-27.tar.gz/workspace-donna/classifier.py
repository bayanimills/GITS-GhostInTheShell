#!/usr/bin/env python3
"""
Enhanced email classifier for Gmail automation.
Provides pattern matching, priority scoring, and archive delay calibration.
"""
import re
import json
from typing import Dict, List, Tuple, Optional, Any

class EmailClassifier:
    def __init__(self, config_path: str):
        with open(config_path) as f:
            self.config = json.load(f)
        
        # Load legacy mappings for compatibility
        self.label_mappings = self.config.get("label_mappings", {})
        self.archive_delays = self.config.get("archive_delays", {})
        self.default_archive_delay = self.config.get("default_archive_delay", 604800)
        
        # Enhanced patterns
        self.patterns = self.config.get("patterns", [])
        self.sender_domains = self.config.get("sender_domains", {})
        
        # Priority scoring config
        self.priority_config = self.config.get("priority_scoring", {})
        self.high_priority_keywords = self.priority_config.get("high_priority_keywords", [])
        self.medium_priority_keywords = self.priority_config.get("medium_priority_keywords", [])
        self.high_priority_senders = self.priority_config.get("high_priority_senders", [])
        
        # Archive delay adjustments
        self.delay_adjustments = self.config.get("archive_delay_adjustments", {})
        
    def extract_domain(self, sender: str) -> str:
        """Extract domain from sender email address."""
        match = re.search(r'@([a-zA-Z0-9.-]+)', sender)
        if match:
            return match.group(1).lower()
        return ""
    
    def match_sender_domain(self, sender: str) -> Optional[str]:
        """Check if sender domain matches any in sender_domains mapping."""
        domain = self.extract_domain(sender)
        if not domain:
            return None
        # Exact match
        if domain in self.sender_domains:
            return self.sender_domains[domain]
        # Partial match (subdomain)
        for pat, label in self.sender_domains.items():
            if domain.endswith('.' + pat) or domain == pat:
                return label
        return None
    
    def match_patterns(self, subject: str, sender: str) -> List[Dict[str, Any]]:
        """Match subject and sender against regex patterns."""
        text = (subject + " " + sender).lower()
        matches = []
        for pattern in self.patterns:
            regex = pattern.get("regex", "")
            if not regex:
                continue
            try:
                if re.search(regex, text, re.IGNORECASE):
                    matches.append(pattern)
            except re.error:
                continue
        return matches
    
    def legacy_classify(self, subject: str, sender: str) -> Tuple[Optional[str], Optional[int]]:
        """Original classification logic from monitor_gmail.py."""
        text = (subject + " " + sender).lower()
        words = set(re.findall(r'\\b\\w+\\b', text))
        
        for key, label in self.label_mappings.items():
            key_lower = key.lower()
            key_words = set(re.findall(r'\\b\\w+\\b', key_lower))
            stop = {'the', 'a', 'an', 'and', 'or', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
            key_words = key_words - stop
            if not key_words:
                continue
            if any(kw in text for kw in key_words):
                delay = self.archive_delays.get(key, self.default_archive_delay)
                return label, delay
        return None, None
    
    def compute_priority_score(self, subject: str, sender: str, matched_patterns: List[Dict]) -> int:
        """Compute priority score based on keywords and sender."""
        score = 0
        text = (subject + " " + sender).lower()
        
        # High priority keywords
        for kw in self.high_priority_keywords:
            if kw.lower() in text:
                score += 3
        
        # Medium priority keywords
        for kw in self.medium_priority_keywords:
            if kw.lower() in text:
                score += 2
        
        # Sender priority
        sender_lower = sender.lower()
        for sender_kw in self.high_priority_senders:
            if sender_kw.lower() in sender_lower:
                score += 3
        
        # Pattern priority contributions
        for pattern in matched_patterns:
            score += pattern.get("priority", 0)
        
        return score
    
    def get_priority_level(self, score: int) -> str:
        """Convert score to priority level."""
        high_thresh = self.priority_config.get("score_threshold_high", 5)
        medium_thresh = self.priority_config.get("score_threshold_medium", 3)
        
        if score >= high_thresh:
            return "high"
        elif score >= medium_thresh:
            return "medium"
        else:
            return "low"
    
    def adjust_archive_delay(self, base_delay: int, priority: str) -> int:
        """Adjust archive delay based on priority level."""
        multipliers = {
            "high": self.delay_adjustments.get("high_priority_multiplier", 2.0),
            "medium": self.delay_adjustments.get("medium_priority_multiplier", 1.5),
            "low": self.delay_adjustments.get("low_priority_multiplier", 0.5)
        }
        multiplier = multipliers.get(priority, 1.0)
        return int(base_delay * multiplier)
    
    def classify(self, subject: str, sender: str) -> Tuple[Optional[str], Optional[int], Dict[str, Any]]:
        """
        Enhanced classification.
        Returns (label, archive_delay_seconds, metadata)
        where metadata includes priority_score, priority_level, matched_patterns
        """
        metadata = {
            "priority_score": 0,
            "priority_level": "low",
            "matched_patterns": [],
            "matched_sender_domain": None
        }
        
        # Step 1: Check sender domain
        domain_label = self.match_sender_domain(sender)
        if domain_label:
            metadata["matched_sender_domain"] = domain_label
        
        # Step 2: Match patterns
        matched_patterns = self.match_patterns(subject, sender)
        metadata["matched_patterns"] = [p.get("regex") for p in matched_patterns]
        
        # Step 3: Legacy classification (fallback)
        legacy_label, legacy_delay = self.legacy_classify(subject, sender)
        
        # Determine final label and base delay
        label = None
        base_delay = self.default_archive_delay
        
        # Prefer pattern matches over legacy
        if matched_patterns:
            # Use the first matched pattern (could be improved to choose highest priority)
            pattern = matched_patterns[0]
            label = pattern.get("label")
            base_delay = pattern.get("archive_delay", self.default_archive_delay)
        elif domain_label:
            label = domain_label
            base_delay = self.default_archive_delay
        elif legacy_label:
            label = legacy_label
            base_delay = legacy_delay
        
        # Step 4: Compute priority score
        score = self.compute_priority_score(subject, sender, matched_patterns)
        metadata["priority_score"] = score
        priority_level = self.get_priority_level(score)
        metadata["priority_level"] = priority_level
        
        # Step 5: Adjust archive delay based on priority
        if label:
            adjusted_delay = self.adjust_archive_delay(base_delay, priority_level)
            return label, adjusted_delay, metadata
        
        return None, None, metadata

# Example usage
if __name__ == "__main__":
    classifier = EmailClassifier("/home/agent/.openclaw/workspace/skills/gmail-skill/config/label_rules.json")
    
    # Test with example emails
    test_emails = [
        ("Your receipt from EMERGENT LABS INC #2179-7685", "EMERGENT LABS INC <invoice+statements+acct_1QMlxNIhzbhimiMI@stripe.com>"),
        ("Service NSW Renew Registration receipt", "Service NSW <no-reply@service.nsw.gov.au>"),
        ("URGENT: Action required on your bank account", "Bank of Australia <alerts@bank.com>"),
        ("Weekly newsletter", "Newsletter Corp <news@example.com>")
    ]
    
    for subject, sender in test_emails:
        label, delay, meta = classifier.classify(subject, sender)
        print(f"Subject: {subject}")
        print(f"  Label: {label}, Delay: {delay}, Priority: {meta['priority_level']} (score {meta['priority_score']})")
        print()