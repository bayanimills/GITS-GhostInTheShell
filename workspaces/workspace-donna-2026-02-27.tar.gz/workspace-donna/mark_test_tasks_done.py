#!/usr/bin/env python3
"""Mark test tasks as done in DartAI."""

import os
import sys
sys.path.append('/home/agent/.openclaw/workspace/skills/dartai/scripts')

from dartai_client import get, put

API_KEY = os.environ.get('DARTAI_API_KEY')
if not API_KEY:
    print("Error: DARTAI_API_KEY not set")
    sys.exit(1)

def find_test_tasks():
    """Find tasks with 'Bayani Test' or 'Aria Test' in title."""
    test_tasks = []
    url = '/tasks/list'
    while url:
        result = get(url)
        tasks = result.get('results', [])
        for task in tasks:
            title = task.get('title', '')
            if 'Bayani Test' in title or 'Aria Test' in title:
                test_tasks.append(task)
        url = result.get('next')  # next page URL
    return test_tasks

def mark_task_done(task_id):
    """Update task status to 'Done'."""
    data = {'item': {'id': task_id, 'status': 'Done'}}
    try:
        result = put(f'/tasks/{task_id}', json_body=data)
        return True, result
    except Exception as e:
        return False, str(e)

def main():
    print("Searching for test tasks...")
    test_tasks = find_test_tasks()
    if not test_tasks:
        print("No test tasks found.")
        sys.exit(0)
    
    print(f"Found {len(test_tasks)} test tasks:")
    for task in test_tasks:
        print(f"  - {task['id']}: {task['title']} (status: {task.get('status', 'N/A')})")
    
    print("\nMarking as done...")
    successes = []
    failures = []
    for task in test_tasks:
        success, result = mark_task_done(task['id'])
        if success:
            successes.append(task['id'])
            print(f"  ✓ {task['id']}: marked done")
        else:
            failures.append((task['id'], result))
            print(f"  ✗ {task['id']}: {result}")
    
    print(f"\nSummary: {len(successes)} succeeded, {len(failures)} failed.")
    if failures:
        sys.exit(1)

if __name__ == '__main__':
    main()