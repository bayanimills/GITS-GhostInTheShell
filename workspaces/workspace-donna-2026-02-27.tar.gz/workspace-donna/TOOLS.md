# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.

## Skill Recommender Integration (2026-02-21)

**Wrapper script**: `recommend_for_task.py`
**Usage**: `python3 recommend_for_task.py "task description" [--limit N] [--category CAT]`
**Output**: Formatted skill recommendations with scores and descriptions
**Logging**: Automatically logs usage to skills registry via `log_skill_usage.py`

**Examples**:
- `python3 recommend_for_task.py "github operations"` → suggests github, gh-issues skills
- `python3 recommend_for_task.py "email automation" --category productivity`

**Integration note**: Use for task planning to discover relevant skills. The recommender searches across 52 skills with dependency metadata.

## Unsubscribe Automation (Phase 1)

**Prototype**: `unsubscribe_prototype.py`
**Usage**: `python3 unsubscribe_prototype.py [--limit N]`
**Output**: Lists emails with ToUnsubscribe label for manual review
**Phases**:
- Phase 1 ✅ Manual review (complete)
- Phase 2 Browser automation (extract/click unsubscribe links)
- Phase 3 Fully automated processing

**Current status**: Detects 3 emails with ToUnsubscribe label (Dune, Shop Bitcoin Australia, Afterpay)
