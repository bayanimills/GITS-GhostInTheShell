#!/usr/bin/env python3
import json
import subprocess
import re

def run_gog(args, account="bayanimills@gmail.com"):
    cmd = ["/home/agent/.linuxbrew/bin/gog"] + args + ["--account", account]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"gog error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

# Load label rules
with open('/home/agent/.openclaw/workspace/skills/gmail-skill/config/label_rules.json') as f:
    rules = json.load(f)

label_mappings = rules.get("label_mappings", {})
archive_delays = rules.get("archive_delays", {})

# Fetch threads from INBOX (same as monitor)
query = "in:inbox -category:promotions newer_than:7d"
data = run_gog(["gmail", "search", query, "--max", "100", "--json"])
if not data:
    exit(1)

threads = data.get("threads", [])
print(f"Total threads: {len(threads)}")

finance_count = 0
finance_threads = []

for thread in threads:
    thread_id = thread["id"]
    subject = thread.get("subject", "")
    sender = thread.get("from", "")
    labels = thread.get("labels", [])
    
    text = (subject + " " + sender).lower()
    words = set(re.findall(r'\b\w+\b', text))
    
    matched = False
    matched_key = None
    matched_label = None
    
    for key, label in label_mappings.items():
        key_lower = key.lower()
        key_words = set(re.findall(r'\b\w+\b', key_lower))
        stop = {'the', 'a', 'an', 'and', 'or', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
        key_words = key_words - stop
        if not key_words:
            continue
        if any(kw in text for kw in key_words):
            matched = True
            matched_key = key
            matched_label = label
            break
    
    if matched:
        if "finance" in matched_label.lower():
            finance_count += 1
            finance_threads.append({
                "id": thread_id,
                "subject": subject,
                "from": sender,
                "matched_key": matched_key,
                "matched_label": matched_label,
                "labels": labels
            })

print(f"Finance threads matched: {finance_count}")
for ft in finance_threads:
    print(f"---")
    print(f"Subject: {ft['subject']}")
    print(f"From: {ft['from']}")
    print(f"Matched key: {ft['matched_key']}")
    print(f"Matched label: {ft['matched_label']}")
    print(f"Existing labels: {ft['labels']}")
    print()