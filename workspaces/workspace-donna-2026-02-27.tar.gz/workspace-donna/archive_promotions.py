#!/usr/bin/env python3
import subprocess
import sys
import time

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def main():
    # Fetch promotion threads in inbox
    print("Fetching promotion threads in inbox...")
    cmd = ["gmail", "search", "in:inbox category:promotions", "--max", "100", "--json"]
    success, output = run_gog(cmd)
    if not success:
        print("Failed to fetch threads.")
        return
    import json
    data = json.loads(output)
    threads = data.get("threads", [])
    ids = [t["id"] for t in threads]
    print(f"Found {len(ids)} promotion threads in inbox.")
    
    # Batch remove INBOX label
    batch_size = 20
    for i in range(0, len(ids), batch_size):
        batch = ids[i:i+batch_size]
        print(f"Batch {i//batch_size + 1}: {len(batch)} threads")
        args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
        success, _ = run_gog(args)
        if not success:
            print("Batch failed, stopping.")
            break
        time.sleep(1)
    
    print("Done. Promotions archived.")

if __name__ == "__main__":
    main()