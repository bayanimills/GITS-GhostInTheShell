#!/usr/bin/env python3
"""
Verify executive task filtering.
"""
import sys
import os

# Add DartAI scripts to path
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/tools')

try:
    from standup_report import fetch_all_tasks, filter_meta_tasks, filter_executive_tasks
except ImportError as e:
    print(f"Error importing: {e}")
    sys.exit(1)

def main():
    # Fetch tasks
    tasks = fetch_all_tasks(limit=100)
    print(f"Total tasks fetched: {len(tasks)}")
    
    # Filter meta tasks
    filtered = filter_meta_tasks(tasks)
    print(f"After meta-task filtering: {len(filtered)}")
    
    # Get executive tasks
    executive_tuples = filter_executive_tasks(filtered)
    print(f"\nExecutive tasks found: {len(executive_tuples)}")
    
    # Count by category
    categories = {}
    for task, category in executive_tuples:
        categories[category] = categories.get(category, 0) + 1
    
    print("\n=== Executive tasks by category ===")
    for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        print(f"{category}: {count}")
    
    print("\n=== Detailed executive task list ===")
    for task, category in executive_tuples:
        title = task.get('title', 'No title')
        assignee = task.get('assignee', 'Unassigned')
        status = task.get('status', 'No status')
        due = task.get('due', 'No due date')
        print(f"- {title}")
        print(f"  Category: {category}")
        print(f"  Assignee: {assignee}, Status: {status}, Due: {due}")
        print()
    
    # Check what was filtered out
    executive_task_ids = [t[0].get('id') for t in executive_tuples]
    non_executive = [t for t in filtered if t.get('id') not in executive_task_ids]
    
    print(f"\n=== Non-executive tasks filtered out ({len(non_executive)}) ===")
    # Show some examples
    for i, task in enumerate(non_executive[:10]):
        title = task.get('title', 'No title')
        assignee = task.get('assignee', 'Unassigned')
        print(f"{i+1}. {title} ({assignee})")
    
    if len(non_executive) > 10:
        print(f"... and {len(non_executive) - 10} more")

if __name__ == '__main__':
    main()