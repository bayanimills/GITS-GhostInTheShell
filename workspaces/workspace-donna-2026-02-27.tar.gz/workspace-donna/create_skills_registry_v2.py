#!/usr/bin/env python3
"""
Create a skills registry in DartAI (General/Tasks dartboard).
Each available skill becomes a task with tag 'skills-registry'.
"""
import os
import sys
import json
from datetime import datetime

# Add dartai scripts to path
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')

try:
    from dartai_client import post, get
except ImportError as e:
    print(f"Failed to import dartai_client: {e}", file=sys.stderr)
    sys.exit(1)

def fetch_tasks():
    """Fetch existing tasks to avoid duplicates."""
    try:
        # Get up to 100 tasks
        result = get('tasks', params={'limit': 100})
        return result.get('items', [])
    except Exception as e:
        print(f"Warning: Could not fetch existing tasks: {e}", file=sys.stderr)
        return []

def create_task(task_def):
    """Create a task in DartAI."""
    try:
        result = post('tasks', json_body={'item': task_def})
        task_id = result.get('item', {}).get('id', 'unknown')
        print(f"✅ Created task: {task_def['title']} (ID: {task_id})")
        return result
    except Exception as e:
        print(f"❌ Failed to create task '{task_def['title']}': {e}", file=sys.stderr)
        return None

def main():
    # Check API key
    if not os.environ.get('DARTAI_API_KEY'):
        print("Error: DARTAI_API_KEY environment variable not set", file=sys.stderr)
        print("Set it with: export DARTAI_API_KEY='your_key'", file=sys.stderr)
        sys.exit(1)
    
    existing_tasks = fetch_tasks()
    existing_titles = {t.get('title', '') for t in existing_tasks}
    
    # Skills data from available_skills block
    skills = [
        {
            "name": "clawhub",
            "description": "Use the ClawHub CLI to search, install, update, and publish agent skills from clawhub.com.",
            "location": "~/openclaw/skills/clawhub/SKILL.md"
        },
        {
            "name": "coding-agent",
            "description": "Delegate coding tasks to Codex, Claude Code, or Pi agents via background process.",
            "location": "~/openclaw/skills/coding-agent/SKILL.md"
        },
        {
            "name": "gh-issues",
            "description": "Fetch GitHub issues, spawn sub‑agents to implement fixes and open PRs, then monitor and address PR review comments.",
            "location": "~/openclaw/skills/gh-issues/SKILL.md"
        },
        {
            "name": "github",
            "description": "GitHub operations via `gh` CLI: issues, PRs, CI runs, code review, API queries.",
            "location": "~/openclaw/skills/github/SKILL.md"
        },
        {
            "name": "gog",
            "description": "Google Workspace CLI for Gmail, Calendar, Drive, Contacts, Sheets, and Docs.",
            "location": "~/openclaw/skills/gog/SKILL.md"
        },
        {
            "name": "healthcheck",
            "description": "Host security hardening and risk‑tolerance configuration for OpenClaw deployments.",
            "location": "~/openclaw/skills/healthcheck/SKILL.md"
        },
        {
            "name": "nano-pdf",
            "description": "Edit PDFs with natural‑language instructions using the nano‑pdf CLI.",
            "location": "~/openclaw/skills/nano-pdf/SKILL.md"
        },
        {
            "name": "skill-creator",
            "description": "Create or update AgentSkills. Use when designing, structuring, or packaging skills with scripts, references, and assets.",
            "location": "~/openclaw/skills/skill-creator/SKILL.md"
        },
        {
            "name": "weather",
            "description": "Get current weather and forecasts via wttr.in or Open‑Meteo.",
            "location": "~/openclaw/skills/weather/SKILL.md"
        }
    ]
    
    print(f"Creating skills registry for {len(skills)} skills...")
    
    # Master index task
    master_title = "Skills Registry – Master Index"
    if master_title not in existing_titles:
        placeholder = {
            'title': master_title,
            'description': '''**Skills Registry Overview**

This registry contains all available skills in the OpenClaw ecosystem. Each skill task includes:
- Description and triggering conditions
- Location path
- Usage examples and common commands
- Dependencies and configuration notes
- Last‑verified timestamp

**Purpose:** Centralized reference for skill discovery, reducing context‑window bloat and ensuring skill‑discoverability across agents.

**Maintenance:** 
- Weekly validation of skill paths
- Update when new skills are installed or deprecated
- Usage tracking and feedback collection''',
            'dartboard': 'General/Tasks',
            'status': 'Done',
            'assignee': 'Donna',
            'tags': ['skills', 'registry', 'master', 'index', 'openclaw', 'skills-registry'],
            'priority': 'medium'
        }
        create_task(placeholder)
    else:
        print(f"⏭️  Master index already exists: {master_title}")
    
    # Create each skill task
    created = 0
    skipped = 0
    for skill in skills:
        title = f'Skill Registry: {skill["name"]}'
        if title in existing_titles:
            print(f"⏭️  Skill already registered: {title}")
            skipped += 1
            continue
        
        # Example usage based on skill name
        examples = {
            'clawhub': '`clawhub search pdf` – `clawhub install my-skill`',
            'coding-agent': 'Spawn a coding agent for complex refactoring',
            'gh-issues': '`/gh-issues openclaw/openclaw --label bug --limit 5`',
            'github': '`gh pr list --state open` – `gh issue view 123`',
            'gog': '`gog email --json list` – `gog calendar add`',
            'healthcheck': 'Security audit, firewall hardening, risk assessment',
            'nano-pdf': '`nano-pdf rotate input.pdf --degrees 90`',
            'skill-creator': 'Create new skill from template with `init_skill.py`',
            'weather': '`weather Sydney` – `weather --forecast London`'
        }
        
        task = {
            'title': title,
            'description': f'''**{skill["name"]}**

**Description:** {skill["description"]}

**Location:** `{skill["location"]}`

**Triggering:** Use when {skill["description"].split("Use when")[-1].split(".")[0].strip() if "Use when" in skill["description"] else "Task matches skill description."}

**Example usage:** {examples.get(skill["name"], "Check SKILL.md for examples.")}

**Configuration:** 
- Skill loaded automatically when description matches task
- Read SKILL.md before proceeding
- May require environment variables or authentication

**Status:** Available
**Last verified:** {datetime.now().strftime("%Y-%m-%d")}

**Metadata:**
- Category: {'tooling' if 'cli' in skill["description"].lower() else 'integration'}
- Dependencies: None stored
- Version: Latest (tracked in skill directory)''',
            'dartboard': 'General/Tasks',
            'status': 'Done',
            'assignee': 'Donna',
            'tags': ['skill', 'registry', skill['name'], 'openclaw', 'skills-registry'],
            'priority': 'low'
        }
        if create_task(task):
            created += 1
    
    print(f"\n✅ Skills registry updated.")
    print(f"   Created: {created} new skill tasks")
    print(f"   Skipped: {skipped} already existing")
    print(f"   Total skills registered: {created + skipped}")

if __name__ == '__main__':
    main()