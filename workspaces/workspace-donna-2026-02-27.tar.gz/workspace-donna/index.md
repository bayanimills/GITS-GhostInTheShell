# Memory Index

This index provides quick access to key memory files:

- **MEMORY.md:** Long-term strategic memory
- **SOUL.md:** Core identity and schema
- **IDENTITY.md:** Personal identity
- **USER.md:** User profile and preferences
- **HEARTBEAT.md:** System heartbeat logs
- **WORKFLOW_AUTO.md:** Automated workflows (placeholder)

Use this index for rapid navigation and reference.