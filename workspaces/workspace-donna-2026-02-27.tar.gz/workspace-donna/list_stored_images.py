#!/usr/bin/env python3
"""
Utility to list stored image references for future analysis.
"""

import os
import json
from datetime import datetime

def list_image_references():
    """List all image references stored in workspace."""
    
    # Paths to check
    workspace_dir = os.path.dirname(os.path.abspath(__file__))
    memory_file = os.path.join(workspace_dir, "memory", f"{datetime.now().strftime('%Y-%m-%d')}.md")
    image_ref_file = os.path.join(workspace_dir, "image_references.md")
    
    print("📸 Stored Image References")
    print("=" * 60)
    
    # Check if image_references.md exists
    if os.path.exists(image_ref_file):
        print(f"\n✅ Found: {image_ref_file}")
        with open(image_ref_file, 'r') as f:
            content = f.read()
            # Extract image paths (handle markdown backtick formatting)
            import re
            # Look for paths that start with /home/agent/.openclaw/media/inbound/
            # and capture until whitespace, backtick, or end of line
            image_paths = []
            for line in content.split('\n'):
                if '/home/agent/.openclaw/media/inbound/' in line:
                    # Find the path in the line
                    match = re.search(r'(/home/agent/\.openclaw/media/inbound/[^\s`]+)', line)
                    if match:
                        image_paths.append(match.group(1))
            
            if image_paths:
                print(f"\n📁 {len(image_paths)} image(s) referenced:")
                for i, path in enumerate(image_paths, 1):
                    if os.path.exists(path):
                        size = os.path.getsize(path) / 1024
                        print(f"  {i}. {os.path.basename(path)} ({size:.1f} KB) - ✅ File exists")
                    else:
                        print(f"  {i}. {os.path.basename(path)} - ❌ File not found")
            else:
                print("\n⚠️  No image paths found in references file")
    else:
        print(f"\n❌ Not found: {image_ref_file}")
    
    # Check today's memory file
    if os.path.exists(memory_file):
        print(f"\n📝 Also referenced in: {os.path.basename(memory_file)}")
        with open(memory_file, 'r') as f:
            content = f.read()
            if "image" in content.lower():
                print("  (Contains image references)")
    
    print("\n" + "=" * 60)
    print("Note: Image analysis currently unavailable due to Anthropic credit depletion.")
    print("References stored for future consideration when capability restored.")

if __name__ == "__main__":
    list_image_references()