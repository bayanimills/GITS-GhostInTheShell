#!/usr/bin/env python3
import os
import sys
import json
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import get

tasks = get('tasks/list', params={'limit': 10})
results = tasks.get('results', [])
for i, task in enumerate(results):
    print(f"=== Task {i} ===")
    print(json.dumps(task, indent=2))
    print()