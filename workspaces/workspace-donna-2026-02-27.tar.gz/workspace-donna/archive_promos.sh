#!/bin/bash
ACCOUNT="bayanimills@gmail.com"
GOG="/home/agent/.linuxbrew/bin/gog"

echo "Fetching promotion thread IDs..."
IDS=$("$GOG" gmail search "in:inbox category:promotions" --max 100 --json --account "$ACCOUNT" | jq -r '.threads[].id')
COUNT=$(echo "$IDS" | wc -l)
echo "Found $COUNT threads."

echo "Processing in batches of 10..."
echo "$IDS" | xargs -n 10 bash -c '
    echo "Batch: $@"
    "$GOG" gmail labels modify "$@" --remove INBOX --account "$ACCOUNT"
' _

echo "Done."