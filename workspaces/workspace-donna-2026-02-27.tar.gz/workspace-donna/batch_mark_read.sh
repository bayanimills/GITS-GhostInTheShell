#!/bin/bash
ACCOUNT="bayanimills@gmail.com"
GOG="/home/agent/.linuxbrew/bin/gog"

# Read IDs from stdin (space-separated)
IFS=' ' read -ra IDS <<< "$1"
TOTAL=${#IDS[@]}
echo "Processing $TOTAL unread threads in batches of 20..."

BATCH_SIZE=20
for ((i=0; i<TOTAL; i+=BATCH_SIZE)); do
    BATCH=("${IDS[@]:i:BATCH_SIZE}")
    echo "Batch $((i/BATCH_SIZE + 1)): ${#BATCH[@]} threads"
    "$GOG" gmail labels modify "${BATCH[@]}" --remove UNREAD --account "$ACCOUNT"
    sleep 1
done

echo "Done."