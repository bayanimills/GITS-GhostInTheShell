#!/usr/bin/env python3
"""
Process ToUnsubscribe emails per recommendations.
Create DartAI tasks for transactional emails, unsubscribe marketing, label removal.
"""
import subprocess
import json
import sys
import os
import re
from typing import List, Dict, Optional

GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
ACCOUNT = "bayanimills@gmail.com"
DARTAI_BIN = "/home/agent/.openclaw/workspace/skills/dartai/bin/dartai"

def run_gog(cmd: List[str], timeout: int = 30) -> Optional[Dict]:
    """Run gog command and return JSON output."""
    full_cmd = [GOG_BIN, 'gmail'] + cmd + ['--account', ACCOUNT, '--json']
    try:
        result = subprocess.run(full_cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            print(f"gog error: {result.stderr}", file=sys.stderr)
            return None
        return json.loads(result.stdout)
    except subprocess.TimeoutExpired:
        print(f"gog command timed out after {timeout}s: {' '.join(full_cmd)}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return None

def get_unsubscribe_emails() -> List[Dict]:
    """Fetch emails with label ToUnsubscribe."""
    data = run_gog(['messages', 'search', 'label:ToUnsubscribe', '--max', '50'])
    if not data or 'messages' not in data:
        return []
    return data['messages']

def remove_label(thread_id: str, label: str = 'ToUnsubscribe') -> bool:
    """Remove a label from a thread."""
    data = run_gog(['thread', 'modify', thread_id, '--remove', label])
    if data and 'modified' in data:
        print(f"Removed label {label} from thread {thread_id}")
        return True
    return False

def archive_thread(thread_id: str) -> bool:
    """Remove INBOX label (archive)."""
    data = run_gog(['thread', 'modify', thread_id, '--remove', 'INBOX'])
    if data and 'modified' in data:
        print(f"Archived thread {thread_id}")
        return True
    return False

def create_dartai_task(title: str, description: str = "") -> Optional[str]:
    """Create a task in DartAI using CLI."""
    body = {
        "title": title,
        "description": description,
        "status": "unstarted"
    }
    cmd = [DARTAI_BIN, "post", "/tasks", json.dumps(body)]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            resp = json.loads(result.stdout)
            task_id = resp.get("id")
            return task_id
        else:
            print(f"DartAI error: {result.stderr}")
            return None
    except Exception as e:
        print(f"Failed to create task: {e}")
        return None

def main():
    emails = get_unsubscribe_emails()
    if not emails:
        print("No emails with ToUnsubscribe label.")
        return
    
    print(f"Found {len(emails)} emails with ToUnsubscribe label:")
    
    for msg in emails:
        subject = msg.get("subject", "")
        from_addr = msg.get("from", "")
        thread_id = msg.get("threadId", "")
        body_preview = msg.get("body", "")[:100]
        
        print(f"\n--- {subject}")
        print(f"    From: {from_addr}")
        
        # Determine action
        from_lower = from_addr.lower()
        subject_lower = subject.lower()
        
        task_created = False
        
        # Australia Post - parcel collection
        if "australia post" in from_lower or "parcel" in subject_lower:
            title = "Collect parcel from Australia Post"
            description = f"Email: {subject}\nFrom: {from_addr}\nBody preview: {body_preview}"
            task_id = create_dartai_task(title, description)
            if task_id:
                print(f"    Created DartAI task: {title} (ID: {task_id})")
                task_created = True
            else:
                print("    Failed to create DartAI task")
        
        # Crazy Domains - domain renewal
        elif "crazy domains" in from_lower or "auto-renew" in subject_lower:
            title = "Review domain renewal for Business Starter"
            description = f"Email: {subject}\nFrom: {from_addr}\nAuto-renewal in 30 days."
            task_id = create_dartai_task(title, description)
            if task_id:
                print(f"    Created DartAI task: {title} (ID: {task_id})")
                task_created = True
            else:
                print("    Failed to create DartAI task")
        
        # Tenant Insurance - marketing unsubscribe
        elif "tenant" in subject_lower or "insurance" in subject_lower:
            print("    Marketing email - no task needed")
        
        # Default
        else:
            print("    Unknown type - no task")
        
        # Label removal and archiving
        if remove_label(thread_id):
            archive_thread(thread_id)
            print("    Label removed, archived.")
        else:
            print("    Failed to remove label")
    
    print("\nProcessing complete.")

if __name__ == "__main__":
    main()