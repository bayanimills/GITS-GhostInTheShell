# Skills Needing Manual Review

**Date**: workspace-donna/analyze_skills_metadata.py
**Total skills**: 54
**Skills needing review**: 10

## Skills with Empty Dependencies
- bluebubbles
- canvas
- coding-agent
- discord
- food-order
- healthcheck
- notion
- skill-creator
- slack
- voice-call

## Skills Missing Metadata Source

## All Skills Needing Review
- bluebubbles
- canvas
- coding-agent
- discord
- food-order
- healthcheck
- notion
- skill-creator
- slack
- voice-call

## Review Process
1. For each skill, read its SKILL.md file
2. Identify required binaries, packages, credentials
3. Update dependencies field in skills_metadata.json
4. Test skill functionality if possible
