# Heartbeat

Last check: 2026-02-20T10:14:38.943841+00:00

Summary:
- cpu_info: %Cpu(s):  3.8 us,  3.8 sy,  0.0 ni, 57.7 id, 34.6 wa,  0.0 hi,  0.0 si,  0.0 st
- mem_info: total        used        free      shared  buff/cache   available
Mem:            7836        2625        3362         388        2506        5210
Swap:           4095           0        4095
- gateway_status: Service: systemd (enabled)
File logs: /tmp/openclaw/openclaw-2026-02-20.log
Command: /usr/bin/node /home/agent/openclaw/dist/entry.js gateway --port 18789
Service file: ~/.config/systemd/user/openclaw...
- sessions: {
  "path": "/home/agent/.openclaw/agents/main/sessions/sessions.json",
  "count": 8,
  "activeMinutes": null,
  "sessions": [
    {
      "key": "agent:main:main",
      "kind": "direct",
      "upda...
- session_validation: {
  "heartbeat": {
    "defaultAgentId": "main",
    "agents": [
      {
        "agentId": "main",
        "enabled": true,
        "every": "30m",
        "everyMs": 1800000
      },
      {
       ...
- conn_api.telegram.org: OK
- conn_example.com: OK
