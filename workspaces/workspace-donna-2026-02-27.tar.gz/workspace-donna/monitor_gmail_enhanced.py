#!/usr/bin/env python3
"""
Enhanced Gmail monitor using the new classifier module.
Maintains backward compatibility with original label_rules.json structure.
"""
import os
import sys
import json
import datetime
import subprocess
import re
from pathlib import Path

# Try to import enhanced classifier; fall back to original
try:
    sys.path.insert(0, str(Path(__file__).parent))
    from classifier import EmailClassifier
    ENHANCED_CLASSIFIER_AVAILABLE = True
except ImportError:
    ENHANCED_CLASSIFIER_AVAILABLE = False

# Configuration
ACCOUNT = "bayanimills@gmail.com"
LABEL_RULES_PATH = Path(__file__).parent / "config" / "label_rules.json"
GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
MAX_EMAILS = 100

def load_rules():
    with open(LABEL_RULES_PATH) as f:
        return json.load(f)

def run_gog(args, account=ACCOUNT):
    cmd = [GOG_BIN] + args + ["--account", account]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"gog error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

def get_label_map():
    data = run_gog(["gmail", "labels", "list", "--json"])
    if not data or "labels" not in data:
        return {}
    mapping = {}
    for label in data["labels"]:
        mapping[label["name"]] = label["id"]
    return mapping

def fetch_inbox_threads(max_results=MAX_EMAILS):
    query = "in:inbox -category:promotions newer_than:7d"
    data = run_gog(["gmail", "search", query, "--max", str(max_results), "--json"])
    if not data:
        return []
    return data.get("threads", [])

def original_classify_thread(subject, sender, labels, rules):
    """Original classification logic."""
    label_mappings = rules.get("label_mappings", {})
    archive_delays = rules.get("archive_delays", {})
    text = (subject + " " + sender).lower()
    
    words = set(re.findall(r'\b\w+\b', text))
    
    for key, label in label_mappings.items():
        key_lower = key.lower()
        key_words = set(re.findall(r'\b\w+\b', key_lower))
        stop = {'the', 'a', 'an', 'and', 'or', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
        key_words = key_words - stop
        if not key_words:
            continue
        if any(kw in text for kw in key_words):
            delay = archive_delays.get(key, rules.get("default_archive_delay", 604800))
            return label, delay
    return None, None

def classify_thread_enhanced(subject, sender, labels, rules, classifier):
    """Enhanced classification using classifier module."""
    label, delay, metadata = classifier.classify(subject, sender)
    return label, delay

def add_label_to_thread(thread_id, label_id):
    run_gog(["gmail", "labels", "modify", thread_id, "--add", label_id])

def remove_label_from_thread(thread_id, label_id):
    run_gog(["gmail", "labels", "modify", thread_id, "--remove", label_id])

def parse_date(date_str):
    try:
        return datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M")
    except ValueError:
        return datetime.datetime.now()

def should_skip(labels, rules):
    return False

def main():
    print(f"Gmail digest (enhanced) — {datetime.datetime.now().isoformat()}")
    if ENHANCED_CLASSIFIER_AVAILABLE:
        print("  Using enhanced classifier with priority scoring")
    else:
        print("  WARNING: Enhanced classifier not available, falling back to original")
    
    rules = load_rules()
    label_map = get_label_map()
    if not label_map:
        print("Error: could not fetch label map.")
        return
    
    # Initialize classifier if available
    classifier = None
    if ENHANCED_CLASSIFIER_AVAILABLE:
        classifier = EmailClassifier(LABEL_RULES_PATH)
    
    threads = fetch_inbox_threads()
    if not threads:
        print("Scanned: 0 messages")
        print("- Finance: 0")
        print("- Calendar: 0")
        print("- Medical: 0")
        print("- Family: 0")
        print("- Newsletters: 0")
        print("- Social: 0")
        print("- Spam: 0")
        return
    
    stats = {
        "total_scanned": len(threads),
        "labeled": 0,
        "archived": 0,
        "skipped": 0,
        "counts": {cat: 0 for cat in ["finance", "calendar", "medical", "family", "newsletters", "social", "spam"]},
        "priority_counts": {"high": 0, "medium": 0, "low": 0}
    }
    
    for thread in threads:
        thread_id = thread["id"]
        subject = thread.get("subject", "")
        sender = thread.get("from", "")
        date_str = thread.get("date", "")
        labels = thread.get("labels", [])
        
        if should_skip(labels, rules):
            stats["skipped"] += 1
            continue
        
        # Determine classification
        if classifier:
            label_name, delay = classify_thread_enhanced(subject, sender, labels, rules, classifier)
        else:
            label_name, delay = original_classify_thread(subject, sender, labels, rules)
        
        # Update stats (simplified mapping)
        if label_name:
            if "finance" in label_name.lower():
                stats["counts"]["finance"] += 1
            elif "calendar" in label_name.lower():
                stats["counts"]["calendar"] += 1
            elif "medical" in label_name.lower():
                stats["counts"]["medical"] += 1
            elif "family" in label_name.lower():
                stats["counts"]["family"] += 1
            elif "newsletter" in label_name.lower():
                stats["counts"]["newsletters"] += 1
            elif "social" in label_name.lower():
                stats["counts"]["social"] += 1
            elif "spam" in label_name.lower():
                stats["counts"]["spam"] += 1
            
            # Add label if not present
            if label_name not in labels:
                label_id = label_map.get(label_name)
                if label_id:
                    add_label_to_thread(thread_id, label_id)
                    stats["labeled"] += 1
                else:
                    print(f"  Warning: label '{label_name}' not found.", file=sys.stderr)
        
        # Archive if delay has passed
        if delay and "INBOX" in labels:
            received = parse_date(date_str)
            now = datetime.datetime.now()
            if now > received + datetime.timedelta(seconds=delay):
                inbox_id = label_map.get("INBOX")
                if inbox_id:
                    remove_label_from_thread(thread_id, inbox_id)
                    stats["archived"] += 1
    
    # Output digest
    print(f"Scanned: {stats['total_scanned']} messages")
    for cat, c in stats["counts"].items():
        print(f"- {cat.title()}: {c}")
    
    # Enhanced stats
    if ENHANCED_CLASSIFIER_AVAILABLE:
        print(f"  (Labeled: {stats['labeled']}, Archived: {stats['archived']}, Skipped: {stats['skipped']})")
        # Optional: print priority distribution if tracked

if __name__ == "__main__":
    main()