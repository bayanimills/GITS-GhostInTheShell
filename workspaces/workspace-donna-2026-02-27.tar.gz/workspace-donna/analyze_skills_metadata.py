#!/usr/bin/env python3
"""
Analyze skills metadata to identify skills needing manual review.
Specifically looks for skills without dependency metadata.
"""

import json
import os
from pathlib import Path

def analyze_skills_metadata():
    """Analyze skills metadata and identify gaps."""
    
    metadata_file = Path(__file__).parent / "skills_metadata.json"
    
    if not metadata_file.exists():
        print("❌ skills_metadata.json not found")
        return
    
    with open(metadata_file, 'r') as f:
        data = json.load(f)
    
    skills = data.get("skills", {})
    
    print("🔍 Skills Metadata Analysis")
    print("=" * 60)
    print(f"Total skills: {len(skills)}")
    print()
    
    # Skills with empty dependencies
    empty_deps = []
    for name, skill in skills.items():
        deps = skill.get("dependencies", {})
        bins = deps.get("bins", [])
        packages = deps.get("packages", [])
        credentials = deps.get("credentials", [])
        external = deps.get("external", [])
        
        if not bins and not packages and not credentials and not external:
            empty_deps.append(name)
    
    print(f"Skills with empty dependencies: {len(empty_deps)}")
    for skill in empty_deps:
        print(f"  • {skill}")
    
    print()
    
    # Skills with missing metadata_source or other fields
    missing_fields = []
    for name, skill in skills.items():
        metadata_source = skill.get("metadata_source", "")
        if not metadata_source:
            missing_fields.append(name)
    
    print(f"Skills missing metadata_source: {len(missing_fields)}")
    for skill in missing_fields[:10]:  # Limit display
        print(f"  • {skill}")
    if len(missing_fields) > 10:
        print(f"  ... and {len(missing_fields) - 10} more")
    
    print()
    
    # Skills that might need manual review
    need_review = list(set(empty_deps + missing_fields))
    print(f"Skills likely needing manual review: {len(need_review)}")
    for i, skill in enumerate(sorted(need_review), 1):
        print(f"  {i:2d}. {skill}")
    
    print()
    print("=" * 60)
    print("Next steps:")
    print("1. Review each skill's SKILL.md file for dependencies")
    print("2. Update dependencies field in skills_metadata.json")
    print("3. Run validation script to confirm")
    
    # Write summary to file
    summary_file = Path(__file__).parent / "skills_needing_review.md"
    with open(summary_file, 'w') as f:
        f.write("# Skills Needing Manual Review\n\n")
        f.write(f"**Date**: {Path(__file__).parent.name}/analyze_skills_metadata.py\n")
        f.write(f"**Total skills**: {len(skills)}\n")
        f.write(f"**Skills needing review**: {len(need_review)}\n\n")
        
        f.write("## Skills with Empty Dependencies\n")
        for skill in sorted(empty_deps):
            f.write(f"- {skill}\n")
        
        f.write("\n## Skills Missing Metadata Source\n")
        for skill in sorted(missing_fields):
            f.write(f"- {skill}\n")
        
        f.write("\n## All Skills Needing Review\n")
        for skill in sorted(need_review):
            f.write(f"- {skill}\n")
        
        f.write("\n## Review Process\n")
        f.write("1. For each skill, read its SKILL.md file\n")
        f.write("2. Identify required binaries, packages, credentials\n")
        f.write("3. Update dependencies field in skills_metadata.json\n")
        f.write("4. Test skill functionality if possible\n")
    
    print(f"\n✅ Summary written to: {summary_file}")

if __name__ == "__main__":
    analyze_skills_metadata()