#!/usr/bin/env python3
import subprocess
import json
import sys

cmd = ["/home/agent/.linuxbrew/bin/gog", "gmail", "messages", "list", 
       "--account", "bayanimills@gmail.com", "--label", "INBOX", "--limit", "5", "--json"]

try:
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    if result.returncode == 0:
        data = json.loads(result.stdout)
        messages = data.get("messages", [])
        print(f"Found {len(messages)} messages:")
        for msg in messages:
            print(f"  - ID: {msg.get('id')}")
            print(f"    Subject: {msg.get('subject', '(no subject)')}")
            print(f"    From: {msg.get('from', 'unknown')}")
            print(f"    Date: {msg.get('date', 'unknown')}")
            print()
    else:
        print(f"Error: {result.stderr}")
except subprocess.TimeoutExpired:
    print("Timeout")
except json.JSONDecodeError as e:
    print(f"JSON decode error: {e}")
    print(f"Output: {result.stdout[:200]}")