#!/usr/bin/env python3
"""
Mark unread emails as read by removing UNREAD label.
"""
import subprocess
import json
import sys

def run_gog(args):
    cmd = ["/home/agent/.linuxbrew/bin/gog"] + args + ["--account", "bayanimills@gmail.com"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return None
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

def main():
    # Fetch unread threads
    data = run_gog(["gmail", "search", "is:unread", "--max", "50", "--json"])
    if not data:
        print("Failed to fetch unread threads.")
        return
    
    threads = data.get("threads", [])
    print(f"Found {len(threads)} unread threads.")
    
    for i, thread in enumerate(threads):
        thread_id = thread["id"]
        subject = thread.get("subject", "")
        labels = thread.get("labels", [])
        if "UNREAD" in labels:
            # Remove UNREAD label
            result = run_gog(["gmail", "labels", "modify", thread_id, "--remove", "UNREAD"])
            if result is None:
                print(f"Failed to mark read: {subject}")
            else:
                print(f"Marked read ({i+1}/{len(threads)}): {subject}")
        else:
            print(f"Already read ({i+1}/{len(threads)}): {subject}")
    
    print("Done.")

if __name__ == "__main__":
    main()