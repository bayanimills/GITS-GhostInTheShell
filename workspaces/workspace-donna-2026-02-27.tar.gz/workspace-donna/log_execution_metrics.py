#!/usr/bin/env python3
"""
Performance tracking module for skills.
Logs execution time, success/failure, and error patterns.
Can be imported by skill scripts or called as standalone.
"""
import os
import sys
import json
import datetime
from pathlib import Path

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'

def load_metadata():
    try:
        with open(METADATA_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Metadata file not found at {METADATA_PATH}")
        return None

def save_metadata(metadata):
    metadata['updated'] = datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z'
    with open(METADATA_PATH, 'w') as f:
        json.dump(metadata, f, indent=2)

def log_execution(skill_name, success=True, execution_time_ms=None, error_type=None, error_details=None):
    """
    Log execution metrics for a skill.
    
    Args:
        skill_name: Name of the skill
        success: Whether execution succeeded
        execution_time_ms: Execution time in milliseconds (optional)
        error_type: Category of error if any (e.g., 'dependency', 'timeout', 'auth')
        error_details: Additional error details (optional)
    """
    metadata = load_metadata()
    if metadata is None:
        return False
    
    skills = metadata.get('skills', {})
    if skill_name not in skills:
        print(f"Skill '{skill_name}' not found in metadata")
        return False
    
    skill_data = skills[skill_name]
    
    # Initialize performance metrics if not present
    if 'performance_metrics' not in skill_data:
        skill_data['performance_metrics'] = {
            'total_executions': 0,
            'successful_executions': 0,
            'failed_executions': 0,
            'total_execution_time_ms': 0,
            'average_execution_time_ms': 0,
            'last_execution_time_ms': 0,
            'last_execution_outcome': '',
            'last_execution_timestamp': '',
            'error_patterns': {}
        }
    
    metrics = skill_data['performance_metrics']
    
    # Update execution counts
    metrics['total_executions'] += 1
    if success:
        metrics['successful_executions'] += 1
        outcome = 'success'
    else:
        metrics['failed_executions'] += 1
        outcome = 'failure'
        
        # Update error patterns
        if error_type:
            error_patterns = metrics.get('error_patterns', {})
            error_patterns[error_type] = error_patterns.get(error_type, 0) + 1
            metrics['error_patterns'] = error_patterns
    
    # Update execution time metrics
    if execution_time_ms is not None:
        metrics['total_execution_time_ms'] += execution_time_ms
        metrics['last_execution_time_ms'] = execution_time_ms
        metrics['average_execution_time_ms'] = metrics['total_execution_time_ms'] // metrics['total_executions']
    
    metrics['last_execution_outcome'] = outcome
    metrics['last_execution_timestamp'] = datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z'
    
    # Store additional error details if provided
    if not success and error_details:
        if 'recent_errors' not in skill_data:
            skill_data['recent_errors'] = []
        skill_data['recent_errors'].append({
            'timestamp': metrics['last_execution_timestamp'],
            'error_type': error_type,
            'details': error_details[:500]
        })
        # Keep only last 10 errors
        skill_data['recent_errors'] = skill_data['recent_errors'][-10:]
    
    skills[skill_name] = skill_data
    metadata['skills'] = skills
    
    save_metadata(metadata)
    print(f"Logged execution for {skill_name}: outcome={outcome}, time={execution_time_ms}ms")
    return True

def get_skill_metrics(skill_name):
    """Retrieve performance metrics for a skill."""
    metadata = load_metadata()
    if not metadata:
        return None
    
    skill_data = metadata.get('skills', {}).get(skill_name)
    if not skill_data:
        return None
    
    return skill_data.get('performance_metrics')

def generate_performance_report():
    """Generate a summary performance report."""
    metadata = load_metadata()
    if not metadata:
        return None
    
    skills = metadata.get('skills', {})
    report = {
        'generated_at': datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z',
        'total_skills': len(skills),
        'skills_tested': 0,
        'skills_with_metrics': 0,
        'success_rate_overall': 0,
        'top_performers': [],
        'needs_attention': []
    }
    
    total_executions = 0
    total_successful = 0
    
    for skill_name, skill_data in skills.items():
        metrics = skill_data.get('performance_metrics')
        if metrics:
            report['skills_with_metrics'] += 1
            total_executions += metrics.get('total_executions', 0)
            total_successful += metrics.get('successful_executions', 0)
            
            # Calculate success rate
            execs = metrics.get('total_executions', 0)
            if execs > 0:
                success_rate = metrics.get('successful_executions', 0) / execs
                avg_time = metrics.get('average_execution_time_ms', 0)
                
                if execs >= 5:  # Only consider skills with sufficient data
                    if success_rate >= 0.9:
                        report['top_performers'].append({
                            'skill': skill_name,
                            'success_rate': success_rate,
                            'avg_time_ms': avg_time,
                            'total_executions': execs
                        })
                    elif success_rate < 0.5:
                        report['needs_attention'].append({
                            'skill': skill_name,
                            'success_rate': success_rate,
                            'avg_time_ms': avg_time,
                            'total_executions': execs
                        })
        
        # Check test status
        if skill_data.get('test_status') == 'pass':
            report['skills_tested'] += 1
    
    # Calculate overall success rate
    if total_executions > 0:
        report['success_rate_overall'] = total_successful / total_executions
    
    # Sort top performers by success rate, then avg time
    report['top_performers'].sort(key=lambda x: (-x['success_rate'], x['avg_time_ms']))
    report['needs_attention'].sort(key=lambda x: (x['success_rate'], -x['total_executions']))
    
    return report

def main():
    """Command line interface for logging execution metrics."""
    import argparse
    parser = argparse.ArgumentParser(description='Log execution metrics for a skill')
    parser.add_argument('skill', help='Skill name')
    parser.add_argument('--success', type=str, default='true', help='Whether execution succeeded')
    parser.add_argument('--execution-time-ms', type=int, help='Execution time in milliseconds')
    parser.add_argument('--error-type', type=str, help='Error type/category')
    parser.add_argument('--error-details', type=str, help='Error details')
    parser.add_argument('--report', action='store_true', help='Generate performance report')
    
    args = parser.parse_args()
    
    if args.report:
        report = generate_performance_report()
        if report:
            print(json.dumps(report, indent=2))
            sys.exit(0)
        else:
            sys.exit(1)
    
    success = args.success.lower() == 'true'
    log_execution(
        args.skill,
        success=success,
        execution_time_ms=args.execution_time_ms,
        error_type=args.error_type,
        error_details=args.error_details
    )
    sys.exit(0)

if __name__ == '__main__':
    main()