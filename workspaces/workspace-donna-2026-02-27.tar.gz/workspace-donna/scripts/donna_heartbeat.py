#!/usr/bin/env python3
import os,subprocess,time,json
from datetime import datetime,timezone
W= '/home/agent/.openclaw/workspace-donna'
MEM_DIR = os.path.join(W,'memory')
LOG_DIR = os.path.join(W,'logs')
os.makedirs(MEM_DIR,exist_ok=True)
os.makedirs(LOG_DIR,exist_ok=True)
now = datetime.now(timezone.utc).isoformat()
report = {'timestamp': now, 'checks':{}}
# CPU, mem, disk
try:
    import psutil
except:
    psutil=None
if psutil:
    report['checks']['cpu_percent']=psutil.cpu_percent(interval=1)
    mem=psutil.virtual_memory()
    report['checks']['memory_percent']=mem.percent
    disk=psutil.disk_usage('/')
    report['checks']['disk_percent']=disk.percent
else:
    # fallback to simple linux commands
    try:
        cpu = subprocess.check_output(["/bin/sh","-c","top -bn1 | grep 'Cpu(s)' || true"],text=True)
        report['checks']['cpu_info']=cpu.strip()
    except Exception as e:
        report['checks']['cpu_info']=repr(e)
    try:
        mem = subprocess.check_output(["/bin/sh","-c","free -m || true"],text=True)
        report['checks']['mem_info']=mem.strip()
    except Exception as e:
        report['checks']['mem_info']=repr(e)
# OpenClaw gateway status
try:
    g = subprocess.check_output(["/home/agent/.local/bin/openclaw","gateway","status"],text=True,stderr=subprocess.STDOUT)
    report['checks']['gateway_status']=g.strip()
except Exception as e:
    report['checks']['gateway_status']=repr(e)
# sessions_list via openclaw CLI
try:
    s = subprocess.check_output(["/home/agent/.local/bin/openclaw","sessions","--limit","10","--json"],text=True,stderr=subprocess.STDOUT)
    report['checks']['sessions']=s.strip()
except Exception as e:
    report['checks']['sessions']=repr(e)
# Orphaned files / session validation: use openclaw status to get session paths and counts
try:
    st = subprocess.check_output(["/home/agent/.local/bin/openclaw","status","--json"],text=True,stderr=subprocess.STDOUT)
    report['checks']['session_validation']=st.strip()
except Exception as e:
    report['checks']['session_validation']=repr(e)
# External connectivity quick check with retries
import time
import shlex

def check_host(host):
    cmd = ["/usr/bin/curl","-I","-m","10","https://%s"%host]
    for attempt in range(3):
        try:
            subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT)
            return 'OK'
        except Exception as e:
            last=repr(e)
            time.sleep(1)
    return last

for host in ("api.telegram.org","example.com"):
    report['checks'][f'conn_{host}']=check_host(host)
# Write report
fname = os.path.join(MEM_DIR,'heartbeat-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'.json')
with open(fname,'w') as f:
    json.dump(report,f,indent=2)
# Update HEARTBEAT.md summary
hb = os.path.join(W,'HEARTBEAT.md')
summary = f"# Heartbeat\n\nLast check: {now}\n\nSummary:\n"
for k,v in report['checks'].items():
    val = v
    if isinstance(v, str) and len(v)>200:
        val = v[:200]+"..."
    summary += f"- {k}: {val}\n"
with open(hb,'w') as f:
    f.write(summary)
# Optionally send alert if failures (simple heuristic)
failures = [k for k,v in report['checks'].items() if isinstance(v,str) and ('Failed' in v or 'error' in v.lower() or 'Traceback' in v)]
if failures:
    # write an alert file for manual pick-up
    alertf = os.path.join(MEM_DIR,'heartbeat-alert-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'.md')
    with open(alertf,'w') as af:
        af.write('# Heartbeat Alert\n')
        af.write(now+'\n\n')
        for k in failures:
            af.write(f'- {k}: {report["checks"][k]}\n')
# append to log
with open(os.path.join(LOG_DIR,'heartbeat.log'),'a') as lf:
    lf.write(now+" " + json.dumps({k: (v if isinstance(v,(str,int,float)) else str(type(v))) for k,v in report['checks'].items()}) + "\n")
print('heartbeat written',fname)
