#!/usr/bin/env python3
import os,sys,json,shutil
from datetime import datetime, timedelta
W='/home/agent/.openclaw/workspace-donna'
MEM=os.path.join(W,'memory')
TEMPL=os.path.join(W,'templates')
now=datetime.utcnow()
cutoff=now - timedelta(days=30)
index_file=os.path.join(MEM,'index.json')
entries=[]
for fn in sorted(os.listdir(MEM)):
    if not fn.endswith('.md') and not fn.endswith('.json'):
        continue
    path=os.path.join(MEM,fn)
    mtime=datetime.utcfromtimestamp(os.path.getmtime(path))
    if mtime < cutoff:
        continue
    # skip heartbeat/json already
    if fn.startswith('heartbeat-') or fn.startswith('heartbeat-alert-'):
        continue
    # read file
    with open(path,'r',encoding='utf-8',errors='ignore') as f:
        content=f.read()
    # ensure front matter
    if content.lstrip().startswith('---'):
        # already has frontmatter, just index
        meta = content.split('---',2)[1]
    else:
        # create frontmatter from template daily
        date_part = fn.split('.md')[0]
        timestamp = mtime.isoformat()+'Z'
        template_path = os.path.join(TEMPL,'daily_template.md')
        with open(template_path,'r') as tf:
            tmpl = tf.read()
        new = tmpl.replace('{{timestamp}}',timestamp).replace('{{date}}',date_part).replace('{{path}}',path)
        # backup original
        shutil.copy2(path,path+'.bak')
        with open(path,'w') as f:
            f.write(new+'\n\n'+content)
    entries.append({'path':path,'mtime':mtime.isoformat()+'Z'})
# write index
with open(index_file,'w') as ix:
    json.dump({'generated':datetime.utcnow().isoformat()+'Z','entries':entries},ix,indent=2)
print('migrated',len(entries),'entries')
