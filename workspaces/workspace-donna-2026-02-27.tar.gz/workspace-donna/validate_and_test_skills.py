#!/usr/bin/env python3
"""
Combined weekly skill validation and testing.
Runs file validation and functional tests.
Generates combined report.
"""
import os
import sys
import subprocess
import datetime

SCRIPTS_DIR = os.path.dirname(__file__)
VALIDATE_SCRIPT = os.path.join(SCRIPTS_DIR, 'validate_skills.py')
TEST_SCRIPT = os.path.join(SCRIPTS_DIR, 'test_skills.py')
USAGE_REPORT_SCRIPT = os.path.join(SCRIPTS_DIR, 'skill_usage_report.py')

def run_script(path, description):
    """Run a script and capture output."""
    print(f"\n=== {description} ===")
    try:
        result = subprocess.run([sys.executable, path], capture_output=True, text=True, timeout=60)
        print(result.stdout)
        if result.stderr:
            print(f"Stderr: {result.stderr}")
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        print(f"Timeout running {description}")
        return False
    except Exception as e:
        print(f"Error running {description}: {e}")
        return False

def main():
    print(f"Weekly Skill Health Check — {datetime.datetime.now().isoformat()}")
    
    # Run validation
    success_val = run_script(VALIDATE_SCRIPT, "Skill Validation (file checks)")
    
    # Run functional tests
    success_test = run_script(TEST_SCRIPT, "Skill Functional Tests")
    
    # Generate usage report
    success_report = run_script(USAGE_REPORT_SCRIPT, "Skill Usage Report")
    
    # Overall status
    print(f"\n=== Summary ===")
    print(f"Validation: {'PASS' if success_val else 'FAIL'}")
    print(f"Functional tests: {'PASS' if success_test else 'FAIL'}")
    print(f"Usage report: {'PASS' if success_report else 'FAIL'}")
    
    overall = success_val and success_test
    if overall:
        print("All checks passed.")
        sys.exit(0)
    else:
        print("Some checks failed.")
        sys.exit(1)

if __name__ == '__main__':
    main()