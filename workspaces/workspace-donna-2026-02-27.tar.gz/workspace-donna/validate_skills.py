#!/usr/bin/env python3
"""
Weekly skill validation cron.
Checks each skill's SKILL.md file exists, updates last_verified date.
Flags missing dependencies or broken paths.
"""
import os
import sys
import json
import subprocess
from datetime import datetime
from pathlib import Path

# Load metadata
METADATA_PATH = '/home/agent/.openclaw/workspace-donna/skills_metadata.json'
with open(METADATA_PATH, 'r') as f:
    metadata = json.load(f)

def check_skill_file(skill_path):
    """Check if skill file exists and is readable."""
    # Expand ~ to home directory
    expanded_path = os.path.expanduser(skill_path)
    return os.path.exists(expanded_path) and os.path.isfile(expanded_path)

def check_dependencies(skill_name):
    """Check if skill dependencies are installed (placeholder)."""
    # For now, just return empty list (no dependency checking implemented)
    return []

def validate_skill(skill_name, skill_data):
    """Validate a single skill."""
    print(f"Validating {skill_name}...")
    
    issues = []
    
    # Check SKILL.md file
    skill_path = skill_data['location']
    if not check_skill_file(skill_path):
        issues.append(f"SKILL.md file not found at {skill_path}")
    
    # Check dependencies
    deps_issues = check_dependencies(skill_name)
    issues.extend(deps_issues)
    
    # Update last_verified
    skill_data['last_verified'] = datetime.now().strftime('%Y-%m-%d')
    
    if issues:
        skill_data['validation_status'] = 'failed'
        skill_data['validation_issues'] = issues
        print(f"  ❌ Issues: {issues}")
    else:
        skill_data['validation_status'] = 'passed'
        if 'validation_issues' in skill_data:
            del skill_data['validation_issues']
        print(f"  ✅ Valid")
    
    return skill_data

def main():
    print(f"Starting skill validation at {datetime.now().isoformat()}")
    
    skills = metadata['skills']
    validation_results = {
        'total': len(skills),
        'passed': 0,
        'failed': 0,
        'updated': datetime.now().isoformat()
    }
    
    for skill_name, skill_data in skills.items():
        updated_skill = validate_skill(skill_name, skill_data)
        skills[skill_name] = updated_skill
        
        if updated_skill.get('validation_status') == 'passed':
            validation_results['passed'] += 1
        else:
            validation_results['failed'] += 1
    
    # Update metadata
    metadata['skills'] = skills
    metadata['updated'] = datetime.now().isoformat() + 'Z'
    
    with open(METADATA_PATH, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    # Print summary
    print(f"\nValidation complete:")
    print(f"  Total skills: {validation_results['total']}")
    print(f"  Passed: {validation_results['passed']}")
    print(f"  Failed: {validation_results['failed']}")
    
    # Create summary for cron reporting
    summary_path = '/tmp/skill_validation_summary.txt'
    with open(summary_path, 'w') as f:
        f.write(f"Skill Validation Report - {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"Total skills: {validation_results['total']}\n")
        f.write(f"Passed: {validation_results['passed']}\n")
        f.write(f"Failed: {validation_results['failed']}\n")
        if validation_results['failed'] > 0:
            f.write("\nFailed skills:\n")
            for skill_name, skill_data in skills.items():
                if skill_data.get('validation_status') == 'failed':
                    f.write(f"- {skill_name}: {', '.join(skill_data.get('validation_issues', []))}\n")
    
    # Return non-zero exit code if any failures
    sys.exit(1 if validation_results['failed'] > 0 else 0)

if __name__ == '__main__':
    main()