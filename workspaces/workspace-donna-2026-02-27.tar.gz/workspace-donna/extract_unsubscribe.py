#!/usr/bin/env python3
import subprocess
import json
import re

def get_emails():
    cmd = ['gog', 'gmail', 'messages', 'search', 'label:ToUnsubscribe', 
           '--account', 'bayanimills@gmail.com', '--json', '--include-body', '--max', '10']
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error running gog: {result.stderr}")
            return []
        data = json.loads(result.stdout)
        return data.get('messages', [])
    except Exception as e:
        print(f"Exception: {e}")
        return []

def extract_unsubscribe_links(body):
    # Look for common unsubscribe patterns
    patterns = [
        r'href=["\'](https?://[^"\']*unsubscribe[^"\']*)["\']',
        r'href=["\'](https?://[^"\']*optout[^"\']*)["\']',
        r'href=["\'](https?://[^"\']*preferences[^"\']*)["\']',
        r'unsubscribe\s*:\s*(https?://\S+)',
        r'(https?://[^\s]*unsubscribe[^\s]*)',
    ]
    links = []
    for pattern in patterns:
        matches = re.findall(pattern, body, re.IGNORECASE)
        links.extend(matches)
    # Deduplicate
    seen = set()
    unique = []
    for link in links:
        if link not in seen:
            seen.add(link)
            unique.append(link)
    return unique

def main():
    emails = get_emails()
    print(f"Found {len(emails)} emails with ToUnsubscribe label")
    for email in emails:
        print(f"\n--- Email: {email['subject']} ---")
        print(f"From: {email['from']}")
        print(f"ID: {email['id']}")
        body = email.get('body', '')
        if body:
            links = extract_unsubscribe_links(body)
            if links:
                print(f"Unsubscribe links ({len(links)}):")
                for link in links:
                    print(f"  - {link}")
            else:
                print("No unsubscribe links found in body")
        else:
            print("No body content")
    # Also print decision recommendations
    print("\n=== Decision Recommendations ===")
    for email in emails:
        if 'trustpilot' in email['from'].lower():
            print(f"{email['subject']}: UNSUBSCRIBE (business review invitation)")
        elif 'dune' in email['from'].lower():
            print(f"{email['subject']}: UNSUBSCRIBE (marketing update)")
        elif 'afterpay' in email['from'].lower():
            print(f"{email['subject']}: CREATE TASK + ARCHIVE (transactional reminder)")

if __name__ == '__main__':
    main()