#!/usr/bin/env python3
"""
Generate weekly skill usage report.
Reads metadata and outputs usage statistics, success rates, etc.
"""
import json
import datetime
import sys

METADATA_PATH = '/home/agent/.openclaw/workspace-donna/skills_metadata.json'

def main():
    try:
        with open(METADATA_PATH) as f:
            metadata = json.load(f)
    except FileNotFoundError:
        print("Error: Metadata file not found.")
        sys.exit(1)
    
    skills = metadata.get('skills', {})
    total = len(skills)
    if total == 0:
        print("No skills found.")
        return
    
    # Calculate totals
    total_usage = 0
    total_success = 0
    skills_with_usage = 0
    skills_without_usage = 0
    for skill_name, data in skills.items():
        usage = data.get('usage_count', 0)
        success = data.get('success_count', 0)
        total_usage += usage
        total_success += success
        if usage > 0:
            skills_with_usage += 1
        else:
            skills_without_usage += 1
    
    # Generate report
    report = []
    report.append(f"Skill Usage Report — {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append("=" * 50)
    report.append(f"Total skills: {total}")
    report.append(f"Skills with usage: {skills_with_usage}")
    report.append(f"Skills never used: {skills_without_usage}")
    report.append(f"Total invocations: {total_usage}")
    if total_usage > 0:
        overall_success_rate = total_success / total_usage * 100
        report.append(f"Overall success rate: {overall_success_rate:.1f}%")
    else:
        report.append("Overall success rate: N/A")
    report.append("")
    
    # Per-skill breakdown
    report.append("Per-skill details:")
    for skill_name, data in sorted(skills.items()):
        usage = data.get('usage_count', 0)
        success = data.get('success_count', 0)
        success_rate = success / usage * 100 if usage > 0 else 0
        last_used = data.get('last_used', 'never')
        test_status = data.get('test_status', 'unknown')
        validation = data.get('validation_status', 'unknown')
        
        if usage > 0:
            line = f"- {skill_name}: used {usage} times, success {success_rate:.1f}%, last {last_used}, test {test_status}, validation {validation}"
        else:
            line = f"- {skill_name}: never used, test {test_status}, validation {validation}"
        report.append(line)
    
    # Print report
    print("\n".join(report))
    
    # Write to file for cron delivery
    out_path = '/tmp/skill_usage_report.txt'
    with open(out_path, 'w') as f:
        f.write("\n".join(report))
    print(f"\nReport saved to {out_path}")

if __name__ == '__main__':
    main()