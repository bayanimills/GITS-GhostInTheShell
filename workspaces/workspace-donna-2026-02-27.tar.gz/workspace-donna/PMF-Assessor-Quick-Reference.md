# PMF Assessor - Quick Reference
## For CNC Workshop (Older Equipment, Low‑Volume, High‑Margin)

**When to use**: Screening new opportunity ideas (5‑10 min assessment)

---

## 🎯 Quick Screening Template

```
Opportunity: _________________________
Date: _________________________

### 1. Core Value Proposition (one sentence):
_________________________________________

### 2. Target Customer (specific):
_________________________________________

### 3. Estimated Price (per unit/project):
$_________ (Target 50‑70%+ margin)

### 4. Equipment Match:
Mill: □   Lathe: □   Both: □
Key operations: _________________________

### 5. Initial Score (1‑10 gut feeling):
_________

**Next Step**: □ Research  □ Customer Contact  □ Reject
```

---

## 📊 Three‑Pillar Scoring (Weighted)

### **Pillar 1: Market Viability (40%)**
*Score 1‑10 each, multiply by 0.4*
- Customer pain severity (are they desperate?)
- Pricing power (can you charge premium?)
- Market size vs. volume (enough customers at low volume?)
- Competition intensity (few players in niche?)
- Referral potential (word‑of‑mouth likely?)

### **Pillar 2: Technical Feasibility (35%)**
*Score 1‑10 each, multiply by 0.35*
- Equipment suitability (machines can do this well)
- Skill match (you know how or can learn quickly)
- Process maturity (proven methods vs. R&D needed)
- Quality consistency (can maintain tolerances)
- Development risk (time/cost to master)

### **Pillar 3: Business Fit (25%)**
*Score 1‑10 each, multiply by 0.25*
- Gross margin potential (target 50‑70%+)
- Cash flow friendliness (deposits, quick turnaround)
- Capital requirements (minimal equipment investment)
- Strategic alignment (builds useful skills/customers)
- Risk level (what could go wrong?)

**Weighted Score** = (Market × 0.40) + (Technical × 0.35) + (Business × 0.25)

**Thresholds**:
- **< 6.0**: Reject
- **6.0‑7.4**: Validate with customers
- **7.5‑8.4**: Develop minimum viable offering
- **8.5+**: Prioritize immediately

---

## 🎪 Top 5 Opportunity Archetypes

### **1. Prototype & Development Parts**
- **Target**: Engineers, inventors, startups
- **Volume**: 1‑50 units
- **Margin**: 60‑80%+
- **Key**: Rapid turnaround, design collaboration

### **2. Legacy Equipment Repair Parts**
- **Target**: Manufacturers with obsolete machinery
- **Volume**: 1‑20 units
- **Margin**: 70‑90%+
- **Key**: Reverse engineering, material matching

### **3. Niche Industry Production**
- **Target**: Medical, aerospace, specialty vehicles
- **Volume**: 10‑200 units/year
- **Margin**: 50‑70%
- **Key**: Documentation, traceability, certification

### **4. Artisan Collaborations**
- **Target**: Artists, architects, designers
- **Volume**: 1‑100 units
- **Margin**: 60‑80%+
- **Key**: Aesthetic finish, creative problem‑solving

### **5. Research Components**
- **Target**: Universities, labs
- **Volume**: 1‑30 units
- **Margin**: 50‑70%
- **Key**: Precision, unusual materials, custom geometries

---

## 💰 Financial Quick Check

### **Margin Target Calculator**
```
Selling Price: $______
Material Cost: $______ (______% of price)
Machine Time: ______ hours @ $______/hour
Labor/Setup: ______ hours @ $______/hour
Total Cost: $______
Gross Profit: $______
Gross Margin: ______%  (Target: 50‑70%+)
```

### **Break‑Even Analysis**
```
Monthly Fixed Costs: $______
Contribution per Unit: $______ (Price − Variable Costs)
Break‑even Units: ______ (Fixed Costs ÷ Contribution)
```

---

## 🚀 Week 1 Action Plan

1. **Brainstorm** 10‑15 opportunity ideas
2. **Quick Screen** each (5 minutes max)
3. **Select Top 3** for detailed assessment
4. **Find 2‑3 potential customers** for each top idea
5. **Have discovery conversations** using questions below

### **Customer Discovery Questions**
1. "What's your biggest challenge with [problem area]?"
2. "How are you currently solving this?"
3. "What would an ideal solution look like?"
4. "What's it costing you to not have a good solution?"
5. "What would you pay for a solution that... [describe]?"
6. "Who else should I talk to about this?"

---

## ⚠️ Red Flags (Reject If...)

- Requires major equipment investment (>$5k)
- Competing with mass‑production shops on price
- Unclear customer or vague value proposition
- Gross margin < 40% after all costs
- Long sales cycle (>3 months) for first customer
- Highly seasonal or unpredictable demand
- Regulatory/certification hurdles you can't meet

---

## ✅ Green Lights (Prioritize If...)

- Solves urgent, expensive problem for specific customers
- Leverages existing equipment/skills with minimal upgrades
- 60%+ gross margin achievable
- Customers willing to pay deposits
- Word‑of‑mouth referrals likely in niche community
- Builds capabilities for future higher‑margin work
- 1‑2 month path to first paying customer

---

## 📞 Next Steps

**Full Framework**: `Product‑Market‑Fit‑Development‑Assessor.md`
**Image References**: `image_references.md` (paths to the two provided images)
**Memory Context**: `memory/2026‑02‑24.md`

**Immediate Action**: 
1. Fill out Quick Screening Template for 5 ideas right now
2. Score your best idea using Three‑Pillar system
3. Have one customer conversation this week

---

*"Older machines don't compete on speed—they compete on what they'll do that no one else will."*