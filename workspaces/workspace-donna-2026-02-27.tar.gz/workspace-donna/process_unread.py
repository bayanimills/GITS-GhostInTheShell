#!/usr/bin/env python3
import subprocess
import sys
import time

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return True
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False

def main():
    # Fetch unread thread IDs
    print("Fetching unread thread IDs...")
    cmd = [GOG, "gmail", "search", "is:unread", "--max", "100", "--json", "--account", ACCOUNT]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        print("Failed to fetch threads.")
        return
    import json
    data = json.loads(result.stdout)
    threads = data.get("threads", [])
    ids = [t["id"] for t in threads]
    print(f"Found {len(ids)} unread threads.")
    
    # Skip first 10 already processed (optional)
    # ids = ids[10:]
    
    # Process in batches of 20
    batch_size = 20
    for i in range(0, len(ids), batch_size):
        batch = ids[i:i+batch_size]
        print(f"Batch {i//batch_size + 1}: {len(batch)} threads")
        args = ["gmail", "labels", "modify"] + batch + ["--remove", "UNREAD"]
        success = run_gog(args)
        if not success:
            print("Batch failed, stopping.")
            break
        time.sleep(1)
    
    print("Done.")

if __name__ == "__main__":
    main()