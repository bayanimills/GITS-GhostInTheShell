#!/usr/bin/env python3
import subprocess
import logging
logging.basicConfig(level=logging.INFO)

def send_telegram_message(text):
    """Send a message via OpenClaw Telegram plugin."""
    try:
        cmd = ["openclaw", "message", "send", "--channel", "telegram", "--target", "548072941", "--message", text]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            logging.error(f"Failed to send Telegram message: {result.stderr}")
            return False
        logging.info("Telegram message sent successfully")
        return True
    except Exception as e:
        logging.error(f"Exception sending Telegram message: {e}")
        return False

if __name__ == "__main__":
    send_telegram_message("🔧 Calendar reminder system test - please ignore.")