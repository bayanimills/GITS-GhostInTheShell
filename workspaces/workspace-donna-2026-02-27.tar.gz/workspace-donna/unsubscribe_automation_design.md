# Unsubscribe Automation - Browser Workflow Design

## Objective
Automatically unsubscribe from emails labeled `ToUnsubscribe` using browser automation.

## Current State
- Emails with "Dune reminder" are labeled `ToUnsubscribe` via keyword matching
- No automatic unsubscribe action currently performed

## Proposed Workflow

### 1. Detection & Selection
- **Trigger**: Daily or weekly batch processing
- **Query**: Find emails with label `ToUnsubscribe` that are still in INBOX (or any folder)
- **Limit**: Process max 10 emails per session to avoid rate limiting

### 2. Browser Automation Steps
For each email:
1. **Open email**: Use Gmail web interface (mail.google.com)
2. **Extract unsubscribe link**:
   - Look for `List-Unsubscribe` header (if available via API)
   - Search email body for common unsubscribe patterns:
     - `<a href="...">unsubscribe</a>`
     - `mailto:unsubscribe@...`
     - `https://.../unsubscribe`
3. **Click unsubscribe link**:
   - If link is HTTP(s): navigate and follow unsubscribe page
   - If mailto: compose unsubscribe email (optional)
4. **Confirm unsubscribe**:
   - Handle confirmation pages (checkboxes, "Confirm" buttons)
   - Wait for success message
5. **Label processed email**:
   - Add label `Unsubscribed` (or remove `ToUnsubscribe`)
   - Archive email

### 3. Safety Measures
- **Dry-run mode**: Log actions without performing them
- **Manual confirmation**: Option to confirm each unsubscribe
- **Rate limiting**: Pause between emails (5-10 seconds)
- **Error handling**: Capture screenshots on failure, skip problematic emails

### 4. Implementation Components

#### Browser Automation Script
```python
from selenium.webdriver import Chrome
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class UnsubscribeAutomation:
    def __init__(self, browser_profile="chrome"):
        self.driver = self.setup_browser(browser_profile)
    
    def process_email(self, email_id):
        # Open Gmail email URL
        self.driver.get(f"https://mail.google.com/mail/u/0/#inbox/{email_id}")
        # Wait for email to load
        # Extract unsubscribe link
        # Navigate and perform unsubscribe
        # Return success/failure
```

#### Integration with Gmail Skill
- Add new command `gmailskill unsubscribe --dry-run`
- Schedule via cron (weekly)
- Log results to file

### 5. Alternative Approaches
- **Gmail API**: Use `users.messages.modify` to add/remove labels
- **Third-party services**: Use dedicated unsubscribe services (Unroll.me, CleanEmail)
- **Manual batch**: Provide list of unsubscribe links for user to review

## Recommended Implementation Phases

**Phase 1: Manual Review Prototype**
- Script extracts unsubscribe links from labeled emails
- Presents list to user for manual clicking
- Validates workflow

**Phase 2: Semi-Automated**
- Browser opens each unsubscribe link automatically
- Requires user confirmation before proceeding
- Handles simple cases (single-click unsubscribe)

**Phase 3: Fully Automated**
- Complete hands-off processing
- Advanced detection of confirmation steps
- Comprehensive error recovery

## Technical Considerations
- **Gmail web interface changes**: Use stable selectors (ARIA labels, data attributes)
- **CAPTCHA handling**: May trigger anti-bot measures; require manual intervention
- **Authentication**: Maintain logged-in session via browser profile
- **Performance**: Process during low-activity hours

## Success Metrics
- Reduction in `ToUnsubscribe` labeled emails over time
- User satisfaction with reduced newsletter clutter
- Low error rate (<5% failures)