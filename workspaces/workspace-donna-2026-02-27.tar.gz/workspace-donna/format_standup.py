#!/usr/bin/env python3
import sys
import re

# Read from stdin (the markdown report)
markdown = sys.stdin.read()

# Extract date
date_match = re.search(r'Daily Standup Report - (\d{4}-\d{2}-\d{2})', markdown)
date = date_match.group(1) if date_match else '2026-02-22'

# Extract total tasks
total_match = re.search(r'\*\*Total Tasks:\*\* (\d+)', markdown)
total = total_match.group(1) if total_match else '?'

# Extract status lines
status_lines = []
in_status = False
for line in markdown.split('\n'):
    if '### By Status' in line:
        in_status = True
        continue
    if in_status and line.strip() == '':
        in_status = False
        continue
    if in_status and line.startswith('- **'):
        # - **Doing**: 5
        m = re.match(r'- \*\*([\w\-]+)\*\*: (\d+)', line)
        if m:
            status_lines.append((m.group(1), m.group(2)))

# Extract assignee lines
assignee_lines = []
in_assignee = False
for line in markdown.split('\n'):
    if '### By Assignee' in line:
        in_assignee = True
        continue
    if in_assignee and line.strip() == '':
        in_assignee = False
        continue
    if in_assignee and line.startswith('- **'):
        m = re.match(r'- \*\*(.+)\*\*: (\d+)', line)
        if m:
            assignee_lines.append((m.group(1), m.group(2)))

# Extract due dates
overdue = due_today = due_tomorrow = completed = 0
in_due = False
for line in markdown.split('\n'):
    if '### Due Dates' in line:
        in_due = True
        continue
    if in_due and line.strip() == '':
        in_due = False
        continue
    if in_due and line.startswith('- '):
        if '⚠️' in line:
            m = re.search(r'(\d+)', line)
            if m:
                overdue = m.group(1)
        elif '📅' in line:
            m = re.search(r'(\d+)', line)
            if m:
                due_today = m.group(1)
        elif '📆' in line:
            m = re.search(r'(\d+)', line)
            if m:
                due_tomorrow = m.group(1)
        elif '✅' in line:
            m = re.search(r'(\d+)', line)
            if m:
                completed = m.group(1)

# Extract overdue tasks
overdue_tasks = []
in_overdue = False
task = None
for line in markdown.split('\n'):
    if '## ⚠️ Overdue Tasks' in line:
        in_overdue = True
        continue
    if in_overdue and line.startswith('## '):
        break
    if in_overdue and line.startswith('- **'):
        title = re.match(r'- \*\*(.+)\*\*', line).group(1)
        overdue_tasks.append({'title': title})
        # next lines contain details
        # we'll just capture the first one

# Extract due today tasks
due_today_tasks = []
in_due_today = False
for line in markdown.split('\n'):
    if '## 📅 Tasks Due Today' in line:
        in_due_today = True
        continue
    if in_due_today and line.startswith('## '):
        break
    if in_due_today and line.startswith('- **'):
        title = re.match(r'- \*\*(.+)\*\*', line).group(1)
        due_today_tasks.append({'title': title})

# Extract top dartboards
dartboards = []
in_dartboards = False
for line in markdown.split('\n'):
    if '## 🎯 Top Dartboards' in line:
        in_dartboards = True
        continue
    if in_dartboards and line.startswith('## '):
        break
    if in_dartboards and line.startswith('- **'):
        m = re.match(r'- \*\*(.+)\*\*: (\d+) tasks', line)
        if m:
            dartboards.append((m.group(1), m.group(2)))

# Build formatted message
lines = []
lines.append(f"📊 **Donna Daily Standup Report** 📊")
lines.append(f"Date: {date}")
lines.append(f"Total Tasks: {total}")
lines.append("")
lines.append("**Status Breakdown:**")
for status, count in status_lines:
    emoji = {'Doing': '🔄', 'Done': '✅', 'To-do': '📝'}.get(status, '•')
    lines.append(f"{emoji} {status}: {count}")
lines.append("")
lines.append("**Assignee Breakdown:**")
for assignee, count in assignee_lines:
    lines.append(f"👤 {assignee}: {count}")
lines.append("")
lines.append("**Due Dates:**")
lines.append(f"⚠️ Overdue: {overdue}")
lines.append(f"📅 Due Today: {due_today}")
lines.append(f"📆 Due Tomorrow: {due_tomorrow}")
lines.append(f"✅ Completed Today: {completed}")
lines.append("")
lines.append("**Top Dartboards:**")
for dartboard, count in dartboards[:5]:
    lines.append(f"🎯 {dartboard}: {count} tasks")
lines.append("")
if int(overdue) > 0:
    lines.append("**Overdue Tasks:**")
    for i, task in enumerate(overdue_tasks[:5], 1):
        lines.append(f"{i}. {task['title']}")
    lines.append("")
if int(due_today) > 0:
    lines.append("**Tasks Due Today:**")
    # deduplicate tasks by title count
    from collections import Counter
    titles = [t['title'] for t in due_today_tasks]
    for title, cnt in Counter(titles).items():
        if cnt > 1:
            lines.append(f"• {cnt} × {title}")
        else:
            lines.append(f"• {title}")
    lines.append("")
lines.append("—")
lines.append("Generated via DartAI • OpenClaw")

print('\n'.join(lines))