#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import delete

task_id = '9vqjEr723GCD'  # example meta-task
try:
    print(f"Attempting to delete task {task_id}...")
    result = delete(f'tasks/{task_id}')
    print(f"Result: {result}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()