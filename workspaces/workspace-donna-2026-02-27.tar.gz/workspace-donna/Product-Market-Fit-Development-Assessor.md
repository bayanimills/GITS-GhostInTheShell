# Product-Market Fit Development Assessor
## For CNC Manufacturing Workshop (Older CNC Mills & Lathes)

**Version**: 1.0  
**Created**: 2026-02-24  
**Context**: Workshop with older CNC equipment, focusing on low-volume, high-margin opportunities  
**Author**: Donna (Executive Operator)

---

## 📋 Executive Summary

This assessor provides a structured framework to evaluate product-market fit (PMF) opportunities for a CNC manufacturing workshop with older CNC Mills and Lathes. The focus is on **low-volume, high-margin** opportunities that leverage existing equipment capabilities while targeting premium customer segments.

**Key Constraints & Advantages:**
- ✅ **Older Equipment**: May limit speed/throughput but often has proven reliability
- ✅ **Low-Volume Focus**: Avoids competing with mass-production facilities
- ✅ **High-Margin Target**: Premium pricing for specialized, hard-to-find, or urgent services
- ✅ **Workshop Context**: Full-time operation provides stable base for incremental expansion

---

## 🎯 Assessment Framework Overview

### **Three-Pillar Evaluation System**

| Pillar | Weight | Description |
|--------|--------|-------------|
| **1. Market Viability** | 40% | Customer demand, competition, pricing power |
| **2. Technical Feasibility** | 35% | Equipment capability, skill requirements, process complexity |
| **3. Business Fit** | 25% | Margin structure, cash flow, strategic alignment |

### **Scoring Scale (1-10)**
- **1-3**: Poor fit (high risk, low reward)
- **4-6**: Moderate fit (requires validation)
- **7-8**: Good fit (worth pursuing)
- **9-10**: Excellent fit (prioritize immediately)

---

## 🔍 Pillar 1: Market Viability Assessment

### **1.1 Target Customer Analysis**
```markdown
[ ] **Niche Identification**: Highly specialized industry segments
[ ] **Pain Point Clarity**: Clear, urgent problems you can solve
[ ] **Purchasing Power**: Customers willing/able to pay premium prices
[ ] **Repeat Potential**: One-time vs. recurring revenue streams
[ ] **Referral Likelihood**: Word-of-mouth potential in niche communities
```

### **1.2 Competitive Landscape**
```markdown
[ ] **Direct Competitors**: Few existing providers in your niche
[ ] **Substitute Solutions**: Alternative ways customers solve the problem
[ ] **Barriers to Entry**: Specialized knowledge/equipment requirements
[ ] **Differentiation**: Unique value proposition vs. competitors
[ ] **Pricing Power**: Ability to charge above market rates
```

### **1.3 Market Validation Questions**
1. **Demand Evidence**: Is there documented demand or customer inquiries?
2. **Willingness to Pay**: Have customers paid premium prices for similar solutions?
3. **Market Size**: Enough customers to sustain business at low volumes?
4. **Growth Potential**: Can this niche expand or lead to adjacent opportunities?
5. **Seasonality**: Consistent demand or cyclical patterns?

### **Scoring Worksheet: Market Viability**
| Metric | Score (1-10) | Notes |
|--------|--------------|-------|
| Customer Pain Severity | | |
| Pricing Power | | |
| Market Size vs. Volume | | |
| Competition Intensity | | |
| Referral Potential | | |
| **Subtotal** | **/50** | |

---

## ⚙️ Pillar 2: Technical Feasibility Assessment

### **2.1 Equipment Capability Matrix**
*Evaluate what your older CNC Mills and Lathes can realistically produce*

```markdown
## CNC Mill Capabilities
[ ] **Material Range**: Aluminum, steel, plastics, exotic metals?
[ ] **Tolerance Level**: ±0.001", ±0.005", or looser?
[ ] **Size Limits**: Max workpiece dimensions
[ ] **Complexity**: 2.5D, 3D, 4th axis capability?
[ ] **Surface Finish**: Required post-processing?

## CNC Lathe Capabilities  
[ ] **Diameter Range**: Minimum/maximum turning diameter
[ ] **Length Capacity**: Maximum part length
[ ] **Threading**: Metric, imperial, special threads
[ ] **Live Tooling**: Milling capability on lathe?
[ ] **Material Expertise**: Experience with specific materials
```

### **2.2 Skill & Process Assessment**
```markdown
[ ] **Programming**: CAD/CAM software proficiency
[ ] **Setup Efficiency**: Time/cost for job changeovers
[ ] **Quality Control**: Inspection equipment and processes
[ ] **Material Sourcing**: Reliable supply chains for niche materials
[ ] **Post-Processing**: Finishing, heat treatment, coating capabilities
```

### **2.3 Technical Risk Factors**
1. **Equipment Limitations**: What can't you do with current machines?
2. **Learning Curve**: New skills/software required?
3. **Process Development**: R&D time/cost to master new techniques
4. **Quality Consistency**: Ability to maintain tolerances across low volumes
5. **Scalability Constraints**: What if demand exceeds low-volume targets?

### **Scoring Worksheet: Technical Feasibility**
| Metric | Score (1-10) | Notes |
|--------|--------------|-------|
| Equipment Suitability | | |
| Skill Match | | |
| Process Maturity | | |
| Quality Consistency | | |
| Development Risk | | |
| **Subtotal** | **/50** | |

---

## 💰 Pillar 3: Business Fit Assessment

### **3.1 Financial Model Evaluation**
*For low-volume, high-margin businesses*

```markdown
## Revenue Structure
[ ] **Price Point**: Target $/part or $/hour
[ ] **Volume Estimate**: Realistic monthly/quarterly unit sales
[ ] **Customer Lifetime Value**: Repeat business potential
[ ] **Ancillary Revenue**: Design services, consulting, maintenance

## Cost Analysis
[ ] **Material Cost**: % of selling price
[ ] **Machine Time**: Hours/part at full utilization cost
[ ] **Setup/Labor**: Changeover and programming time
[ ] **Overhead Allocation**: Workshop space, utilities, maintenance
[ ] **Customer Acquisition**: Marketing/sales costs per customer
```

### **3.2 Margin & Cash Flow Projection**
```markdown
Target Margins for Low-Volume CNC Work:
- **Acceptable**: 40-50% gross margin
- **Good**: 50-60% gross margin  
- **Excellent**: 60%+ gross margin

Cash Flow Considerations:
- **Payment Terms**: Upfront deposits vs. net-30
- **Material Financing**: Customer-supplied vs. workshop-purchased
- **Equipment Investment**: Minor upgrades vs. major purchases
- **Working Capital**: Cash needed to fund 2-3 month production cycle
```

### **3.3 Strategic Alignment**
```markdown
[ ] **Workshop Utilization**: Fills gaps in current schedule
[ ] **Skill Development**: Builds capabilities for future opportunities
[ ] **Customer Synergy**: Complements existing customer relationships
[ ] **Brand Enhancement**: Positions workshop as specialized expert
[ ] **Risk Diversification**: Reduces dependency on current revenue streams
```

### **Scoring Worksheet: Business Fit**
| Metric | Score (1-10) | Notes |
|--------|--------------|-------|
| Gross Margin Potential | | |
| Cash Flow Friendliness | | |
| Capital Requirements | | |
| Strategic Alignment | | |
| Risk Level | | |
| **Subtotal** | **/50** | |

---

## 📊 Opportunity Scoring & Prioritization

### **Weighted Scoring Formula**
```
Total Score = (Market Viability × 0.40) + (Technical Feasibility × 0.35) + (Business Fit × 0.25)
```

### **Scoring Thresholds**
- **< 6.0**: Reject or significantly rework concept
- **6.0-7.4**: Moderate fit - validate with customer conversations
- **7.5-8.4**: Good fit - develop minimum viable offering
- **8.5+**: Excellent fit - prioritize for immediate development

### **Decision Matrix**
| Opportunity | Market | Technical | Business | **Weighted Score** | Priority |
|-------------|--------|-----------|----------|-------------------|----------|
| *Example: Prototype Parts* | 8.5 | 7.0 | 8.0 | **7.9** | 🟡 Validate |
| *Example: Legacy Machine Repair* | 9.0 | 8.5 | 9.0 | **8.8** | 🟢 Prioritize |

---

## 🎪 Low-Volume, High-Margin Opportunity Archetypes

*Based on older CNC equipment constraints*

### **Archetype 1: Prototype & Development Parts**
- **Target**: Engineering firms, inventors, startups
- **Volume**: 1-50 units
- **Margin**: 60-80%+
- **Key Requirement**: Rapid turnaround, design collaboration
- **Equipment Fit**: Older machines excel at one-offs with careful setup

### **Archetype 2: Legacy Equipment Repair Parts**
- **Target**: Manufacturers with obsolete machinery
- **Volume**: 1-20 units (custom replacements)
- **Margin**: 70-90%+
- **Key Requirement**: Reverse engineering, material matching
- **Equipment Fit**: Lathes ideal for shafts, bushings, custom fasteners

### **Archetype 3: Low-Volume Production for Niche Industries**
- **Target**: Medical devices, aerospace, specialty vehicles
- **Volume**: 10-200 units annually
- **Margin**: 50-70%
- **Key Requirement**: Documentation, traceability, certification
- **Equipment Fit**: Consistent quality across small batches

### **Archetype 4: Artisan & Designer Collaborations**
- **Target**: Artists, architects, high-end product designers
- **Volume**: 1-100 units
- **Margin**: 60-80%+
- **Key Requirement**: Aesthetic finish, material experimentation
- **Equipment Fit**: Creative problem-solving with available tools

### **Archetype 5: Research & Academic Components**
- **Target**: Universities, research labs
- **Volume**: 1-30 units
- **Margin**: 50-70%
- **Key Requirement**: Precision, unusual materials, custom geometries
- **Equipment Fit**: Tolerance capability more important than speed

---

## 🚀 Implementation Roadmap

### **Phase 1: Opportunity Identification (Weeks 1-2)**
1. **Brainstorm Session**: List 10-15 potential niche opportunities
2. **Initial Screening**: Apply quick filters (margin potential, equipment fit)
3. **Top 3 Selection**: Choose most promising candidates for detailed assessment
4. **Customer Discovery**: Identify 2-3 potential customers for each

### **Phase 2: Validation & Assessment (Weeks 3-6)**
1. **Deep-Dive Assessment**: Complete full scoring for top 3 opportunities
2. **Customer Conversations**: Discuss needs, pain points, budget with prospects
3. **Capability Testing**: Run small proof-of-concept projects
4. **Financial Modeling**: Build detailed revenue/cost projections

### **Phase 3: Pilot Development (Weeks 7-12)**
1. **Minimum Viable Offering**: Define simplest version of chosen opportunity
2. **Pilot Customer**: Secure first paying customer for pilot project
3. **Process Documentation**: Capture all steps, times, costs
4. **Quality Validation**: Ensure output meets customer expectations

### **Phase 4: Scale Refinement (Months 4-6)**
1. **Process Optimization**: Reduce setup time, improve efficiency
2. **Marketing Materials**: Create case studies, capability sheets
3. **Pricing Refinement**: Adjust based on actual costs and customer feedback
4. **Systematization**: Develop repeatable processes for consistency

---

## 📝 Assessment Templates

### **Quick Screening Template**
```
Opportunity: _________________________
Date: _________________________

1. **Core Value Proposition** (one sentence):
   _________________________________________

2. **Target Customer** (specific description):
   _________________________________________

3. **Estimated Price Point** (per unit/project):
   $_________

4. **Equipment Match** (what machines, what operations):
   _________________________________________

5. **Initial Score** (1-10, gut feeling):
   _________

**Next Step**: □ Research □ Customer Contact □ Reject
```

### **Customer Discovery Interview Guide**
```
1. "What's the biggest challenge you face with [problem area]?"
2. "How are you currently solving this problem?"
3. "What would an ideal solution look like?"
4. "What's the cost of not having a good solution?"
5. "What would you be willing to pay for a solution that... [describe your offering]?"
6. "Who else should I talk to about this?"
```

### **Financial Projection Worksheet**
```
Monthly Projection (Year 1):
- Units Sold: ______
- Price per Unit: $______
- Gross Revenue: $______
- Material Cost: $______ (____% of revenue)
- Machine Time: ______ hours @ $______/hour
- Labor/Setup: ______ hours @ $______/hour  
- Gross Profit: $______
- Gross Margin: ______%

Break-even Analysis:
- Monthly Fixed Costs: $______
- Contribution Margin per Unit: $______
- Break-even Units: ______
- Break-even Revenue: $______
```

---

## ⚠️ Risk Mitigation Strategies

### **Technical Risks**
- **Machine Limitations**: Start with simplest versions, subcontract complex operations
- **Quality Issues**: Implement rigorous inspection protocols, offer revisions guarantee
- **Skill Gaps**: Partner with designers/programmers, invest in targeted training

### **Market Risks**
- **Demand Uncertainty**: Secure letters of intent before major investment
- **Price Resistance**: Demonstrate value through case studies, testimonials
- **Competitive Response**: Build customer relationships, focus on service quality

### **Financial Risks**
- **Cash Flow Gaps**: Require 50% deposits, phase payments by milestone
- **Cost Overruns**: Detailed quoting process with contingency buffers
- **Equipment Failure**: Maintenance schedule, backup capacity planning

### **Operational Risks**
- **Schedule Conflicts**: Clear communication of lead times, buffer for urgent work
- **Material Availability**: Identify multiple suppliers, customer-supplied options
- **Documentation Burden**: Develop templates for repeat jobs

---

## 🔄 Continuous Improvement Framework

### **Monthly Review Cycle**
1. **Performance Metrics**:
   - Revenue/opportunity
   - Actual vs. projected margins
   - Customer satisfaction scores
   - Equipment utilization rates

2. **Learning Capture**:
   - What worked well?
   - What challenges emerged?
   - What would we do differently?
   - New opportunity ideas generated

3. **Framework Refinement**:
   - Adjust scoring weights based on experience
   - Add new assessment criteria
   - Update opportunity archetypes
   - Refine financial models

### **Quarterly Strategic Review**
1. **Portfolio Assessment**: Balance of opportunities across risk/reward spectrum
2. **Equipment Planning**: Minor upgrades to enable higher-margin work
3. **Skill Development**: Training priorities based on opportunity pipeline
4. **Market Trends**: Emerging niches, changing customer needs

---

## 🎯 Next Steps & Immediate Actions

### **Week 1 Action Plan**
1. **Review Images Provided**: Analyze the two documents/images for specific opportunity ideas
2. **Brainstorm Session**: Generate 10-15 low-volume, high-margin opportunity ideas
3. **Quick Screen**: Apply 5-minute assessment to each idea
4. **Select Top 3**: Choose most promising for detailed assessment
5. **Customer Identification**: Find 2-3 potential customers for each top idea

### **Image Analysis Note**
*The two images provided (file_7 and file_8) could not be analyzed due to Anthropic credit depletion. Once image analysis capability is restored, examine them for:*
- Specific product ideas or niche markets
- Technical drawings or specifications
- Customer pain points or needs
- Competitive landscape information

### **Immediate Assessment Candidates**
*Consider starting with these common high-margin niches for older CNC equipment:*
1. **Obsolete Part Reproduction**: Replacement parts for discontinued machinery
2. **Custom Tooling**: Specialized jigs, fixtures, molds for other manufacturers
3. **Prototype Components**: One-off parts for product development
4. **Artisan Collaborations**: Metal components for artists/designers
5. **Research Apparatus**: Custom lab equipment components

---

## 📞 Contact & Support

**Framework Author**: Donna (Executive Operator)  
**Last Updated**: 2026-02-24  
**Version**: 1.0  
**Workspace**: `/home/agent/.openclaw/workspace-donna/`

**Related Files**:
- `image_references.md` - Contains paths to the two provided images for future analysis
- `memory/2026-02-24.md` - Context about this framework development

**Update Schedule**: Review quarterly, update based on real-world application experience

---

*"The advantage of older equipment isn't what it can do fastest, but what it can do that others won't."*