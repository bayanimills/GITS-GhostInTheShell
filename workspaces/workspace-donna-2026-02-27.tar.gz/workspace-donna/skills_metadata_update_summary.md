# Skills Metadata Update Summary

**Date**: 2026-02-24 03:55:51
**Updated skills**: 10

## Updated Skills
- ✅ bluebubbles
- ✅ canvas
- ✅ coding-agent
- ✅ discord
- ✅ food-order
- ✅ healthcheck
- ✅ notion
- ✅ skill-creator
- ✅ slack
- ✅ voice-call

## Dependency Changes

### bluebubbles
- **config**: channels.bluebubbles
- **credentials**: bluebubbles_server
- **external**: BlueBubbles server

### canvas
- **external**: OpenClaw nodes with canvas capability

### coding-agent
- **bins**: bash
- **external**: Codex/Claude Code/Pi agent access

### discord
- **config**: channels.discord
- **credentials**: discord_bot_token
- **external**: Discord API

### food-order
- **credentials**: uber_eats_account, doordash_account
- **external**: Uber Eats API, DoorDash API

### healthcheck
- **env**: OPENCLAW_GOVERNANCE_RISK_TOLERANCE

### notion
- **env**: NOTION_API_KEY
- **bins**: curl
- **credentials**: notion_api_key
- **external**: Notion API

### skill-creator
- **bins**: python3

### slack
- **config**: channels.slack
- **credentials**: slack_bot_token
- **external**: Slack API

### voice-call
- **config**: plugins.entries.voice-call.enabled
- **credentials**: twilio_api_keys, telnyx_api_keys, plivo_api_keys
- **external**: Twilio/Telnyx/Plivo API

## Next Steps
1. Run validation script to confirm dependencies
2. Test critical skills if possible
3. Update any missing dependencies for other skills
