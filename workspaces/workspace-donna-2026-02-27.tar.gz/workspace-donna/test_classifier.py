#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-donna')
from classifier import EmailClassifier

# Use the enhanced config
classifier = EmailClassifier("/home/agent/.openclaw/workspace-donna/enhanced_label_rules.json")

# Test with the 16 finance emails we identified
test_cases = [
    ("Your receipt from EMERGENT LABS INC #2179-7685", "EMERGENT LABS INC <invoice+statements+acct_1QMlxNIhzbhimiMI@stripe.com>"),
    ("Service NSW Renew Registration receipt", "Service NSW <no-reply@service.nsw.gov.au>"),
    ("New in Satlantis 🌴 Bitcoin Wallet + Stripe!", "Jordi from Satlantis <jordi@satlantis.io>"),
    ("Receipt of payment for 16/942 Pittwater Road, DEE WHY NSW 2099", "Felicia Mezei - Doyle Spillane Real Estate <doylespillane@email.propertyme.com>"),
    ("1-5 Days Arrears Reminder - 16/942 Pittwater Road, DEE WHY NSW 2099", "Felicia Mezei - Doyle Spillane Real Estate <doylespillane@email.propertyme.com>"),
    ("🚨 Action needed: Your Deployment may go offline", "Team Emergent <noreply@app.emergentnet.io>"),
    ("Your statement is ready", "E-Toll <E-Toll@notifications.transport.nsw.gov.au>"),
    ("Receipt of payment for 16/942 Pittwater Road, DEE WHY NSW 2099", "Felicia Mezei - Doyle Spillane Real Estate <doylespillane@email.propertyme.com>"),
    ("1-5 Days Arrears Reminder - 16/942 Pittwater Road, DEE WHY NSW 2099", "Felicia Mezei - Doyle Spillane Real Estate <doylespillane@email.propertyme.com>"),
    ("Instant Payouts now available for payout to linked bank account", "Stripe <notifications@stripe.com>"),
    ("Your receipt from EMERGENT LABS INC #2563-9899", "EMERGENT LABS INC <invoice+statements+acct_1QMlxNIhzbhimiMI@stripe.com>"),
    ("pilot - dedicated support, tech help - emergent", "avi@emergent.sh"),
    ("You have an unpaid toll for travel on Sydney Harbour Bridge & Tunnel", "NSW Motorways <notifications@motorways.nsw.gov.au>"),
    ("Your receipt from EMERGENT LABS INC #2179-9750", "EMERGENT LABS INC <invoice+statements+acct_1QMlxNIhzbhimiMI@stripe.com>"),
    ("Your receipt from EMERGENT LABS INC #2833-2431", "EMERGENT LABS INC <invoice+statements+acct_1QMlxNIhzbhimiMI@stripe.com>"),
    ("Your receipt from EMERGENT LABS INC #2989-5015", "EMERGENT LABS INC <invoice+statements+acct_1QMlxNIhzbhimiMI@stripe.com>")
]

print("Testing enhanced classifier on finance emails:")
for i, (subject, sender) in enumerate(test_cases):
    label, delay, meta = classifier.classify(subject, sender)
    print(f"{i+1}. {subject[:50]}...")
    print(f"   Label: {label}, Delay: {delay}, Priority: {meta['priority_level']} (score {meta['priority_score']})")
    if meta['matched_patterns']:
        print(f"   Patterns: {meta['matched_patterns']}")
    print()