# Dependency Resolution Plan - 2026-02-21

## Overview
29 skills require missing binaries. This prevents them from functioning correctly. Resolution strategy: prioritize by skill usage, category importance, and installation complexity.

## Missing Binaries by Priority

### Tier 1: Critical (Security/Productivity)
| Binary | Required By | Category | Installation | Notes |
|--------|-------------|----------|--------------|-------|
| `op` | 1password | Security | `brew install 1password-cli` | 1Password CLI for password management |
| `ffmpeg` | camsnap, media skills | Media | `brew install ffmpeg` | Video/audio processing |
| `memo` | apple-notes | Productivity | `brew install memo` | Apple Notes CLI (if formula exists) |

### Tier 2: High Usage Categories
| Binary | Required By | Category | Installation |
|--------|-------------|----------|--------------|
| `gemini` | gemini | AI | `brew install gemini` (if exists) |
| `himalaya` | himalaya | Communication | `brew install himalaya` |
| `imsg` | imsg | Communication | May need manual build |
| `codexbar` | model-usage | AI | Likely custom binary |

### Tier 3: Lower Priority
| Binary | Required By | Category |
|--------|-------------|----------|
| `remindctl` | apple-reminders | Productivity |
| `grizzly` | bear-notes | Productivity |
| `blogwatcher` | blogwatcher | System |
| `blu` | blucli | Utility |
| `camsnap` | camsnap | Media |
| `eightctl` | eightctl | Utility |
| `gifgrep` | gifgrep | Web |
| `goplaces` | goplaces | Lifestyle |
| `mcporter` | mcporter | Security |

## Installation Strategy

### Phase 1: Critical Dependencies (15 mins)
```bash
# Security and core productivity
brew install 1password-cli ffmpeg

# Check availability of other formulas
brew search memo gemini himalaya
```

### Phase 2: Skill-Specific Installation (30 mins)
- Install available formulas
- Document unavailable formulas
- Disable skills with unavailable dependencies

### Phase 3: Validation (15 mins)
```bash
# Re-run dependency check
python3 check_dependencies.py

# Test critical skills
python3 test_skills.py --filter security,productivity
```

## Risk Assessment

### Low Risk
- Installing well-maintained Homebrew formulas (1password-cli, ffmpeg)
- These are standard tools with wide usage

### Medium Risk  
- Formulas that might not exist (memo, gemini, himalaya)
- May require manual installation or alternative approaches

### High Risk
- Custom binaries (codexbar, imsg, camsnap)
- May require compilation or special installation procedures

## Fallback Options

1. **Skill Disabling**: Temporarily disable skills with unmet dependencies
2. **Alternative Skills**: Use alternative skills with similar functionality
3. **Dependency Mocking**: Create placeholder binaries for testing
4. **Manual Review**: Investigate each skill's actual requirements

## Recommended Actions

### Immediate (Request Permission)
1. Install 1password-cli and ffmpeg via Homebrew
2. Search for other available formulas
3. Document unavailable dependencies

### Short-term (Next 24h)
1. Disable skills with unavailable dependencies
2. Update skills_metadata.json with installation status
3. Create skill health dashboard

### Long-term
1. Implement dependency checking in skill loading
2. Add automated dependency installation for common tools
3. Create skill compatibility matrix

## Success Metrics
- Binary dependencies satisfied for critical skills
- No skill failures due to missing dependencies
- Dependency tracking integrated into skills registry
- Automated validation of skill readiness