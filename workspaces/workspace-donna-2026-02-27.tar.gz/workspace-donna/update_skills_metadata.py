#!/usr/bin/env python3
"""
Update skills_metadata.json with dependencies for 10 skills without metadata.
Based on manual review conducted 2026-02-24.
"""

import json
import os
from datetime import datetime

def update_skills_metadata():
    """Update metadata file with dependencies."""
    
    metadata_file = os.path.join(os.path.dirname(__file__), "skills_metadata.json")
    
    if not os.path.exists(metadata_file):
        print(f"❌ {metadata_file} not found")
        return
    
    # Load current metadata
    with open(metadata_file, 'r') as f:
        data = json.load(f)
    
    skills = data.get("skills", {})
    
    # Dependency mappings based on manual review
    updates = {
        "bluebubbles": {
            "dependencies": {
                "config": ["channels.bluebubbles"],
                "bins": [],
                "packages": [],
                "credentials": ["bluebubbles_server"],
                "external": ["BlueBubbles server"]
            },
            "metadata_source": "manual_review"
        },
        "canvas": {
            "dependencies": {
                "config": [],
                "bins": [],
                "packages": [],
                "credentials": [],
                "external": ["OpenClaw nodes with canvas capability"]
            },
            "metadata_source": "manual_review"
        },
        "coding-agent": {
            "dependencies": {
                "config": [],
                "bins": ["bash"],
                "packages": [],
                "credentials": [],
                "external": ["Codex/Claude Code/Pi agent access"]
            },
            "metadata_source": "manual_review"
        },
        "discord": {
            "dependencies": {
                "config": ["channels.discord"],
                "bins": [],
                "packages": [],
                "credentials": ["discord_bot_token"],
                "external": ["Discord API"]
            },
            "metadata_source": "manual_review"
        },
        "food-order": {
            "dependencies": {
                "config": [],
                "bins": [],
                "packages": [],
                "credentials": ["uber_eats_account", "doordash_account"],
                "external": ["Uber Eats API", "DoorDash API"]
            },
            "metadata_source": "manual_review"
        },
        "healthcheck": {
            "dependencies": {
                "env": ["OPENCLAW_GOVERNANCE_RISK_TOLERANCE"],
                "config": [],
                "bins": [],
                "packages": [],
                "credentials": [],
                "external": []
            },
            "metadata_source": "manual_review"
        },
        "notion": {
            "dependencies": {
                "env": ["NOTION_API_KEY"],
                "config": [],
                "bins": ["curl"],
                "packages": [],
                "credentials": ["notion_api_key"],
                "external": ["Notion API"]
            },
            "metadata_source": "manual_review"
        },
        "skill-creator": {
            "dependencies": {
                "config": [],
                "bins": ["python3"],
                "packages": [],
                "credentials": [],
                "external": []
            },
            "metadata_source": "manual_review"
        },
        "slack": {
            "dependencies": {
                "config": ["channels.slack"],
                "bins": [],
                "packages": [],
                "credentials": ["slack_bot_token"],
                "external": ["Slack API"]
            },
            "metadata_source": "manual_review"
        },
        "voice-call": {
            "dependencies": {
                "config": ["plugins.entries.voice-call.enabled"],
                "bins": [],
                "packages": [],
                "credentials": ["twilio_api_keys", "telnyx_api_keys", "plivo_api_keys"],
                "external": ["Twilio/Telnyx/Plivo API"]
            },
            "metadata_source": "manual_review"
        }
    }
    
    # Apply updates
    updated_count = 0
    for skill_name, update_data in updates.items():
        if skill_name in skills:
            skill = skills[skill_name]
            
            # Update dependencies
            current_deps = skill.get("dependencies", {})
            new_deps = update_data["dependencies"]
            
            # Merge: for config/env/bins/packages/credentials/external arrays, combine unique
            for dep_type in ["config", "env", "bins", "packages", "credentials", "external"]:
                if dep_type in new_deps:
                    current_items = current_deps.get(dep_type, [])
                    new_items = new_deps[dep_type]
                    # Add only new items not already present
                    for item in new_items:
                        if item not in current_items:
                            current_items.append(item)
                    if current_items:
                        current_deps[dep_type] = current_items
                    elif dep_type in current_deps:
                        # Remove empty arrays
                        del current_deps[dep_type]
            
            skill["dependencies"] = current_deps
            
            # Update metadata_source
            skill["metadata_source"] = update_data["metadata_source"]
            
            # Update last_verified date
            skill["last_verified"] = datetime.now().strftime("%Y-%m-%d")
            
            updated_count += 1
            print(f"✅ Updated {skill_name}")
        else:
            print(f"⚠️  Skill {skill_name} not found in metadata")
    
    # Update global timestamp
    data["updated"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    
    # Write back to file
    backup_file = metadata_file + ".backup"
    with open(backup_file, 'w') as f:
        json.dump(data, f, indent=2)
    
    # Replace original
    os.replace(backup_file, metadata_file)
    
    print(f"\n📊 Summary: Updated {updated_count} skills")
    print(f"💾 Backup saved to: {backup_file}")
    print(f"✅ Metadata file updated: {metadata_file}")
    
    # Create summary report
    summary_file = os.path.join(os.path.dirname(__file__), "skills_metadata_update_summary.md")
    with open(summary_file, 'w') as f:
        f.write("# Skills Metadata Update Summary\n\n")
        f.write(f"**Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**Updated skills**: {updated_count}\n\n")
        
        f.write("## Updated Skills\n")
        for skill_name in updates.keys():
            if skill_name in skills:
                f.write(f"- ✅ {skill_name}\n")
            else:
                f.write(f"- ❌ {skill_name} (not found)\n")
        
        f.write("\n## Dependency Changes\n")
        for skill_name, update_data in updates.items():
            if skill_name in skills:
                f.write(f"\n### {skill_name}\n")
                deps = update_data["dependencies"]
                for dep_type, items in deps.items():
                    if items:
                        f.write(f"- **{dep_type}**: {', '.join(items)}\n")
        
        f.write("\n## Next Steps\n")
        f.write("1. Run validation script to confirm dependencies\n")
        f.write("2. Test critical skills if possible\n")
        f.write("3. Update any missing dependencies for other skills\n")
    
    print(f"\n📝 Summary report: {summary_file}")

if __name__ == "__main__":
    update_skills_metadata()