#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import post

task_def = {
    'title': 'Afterpay payment due: $282.13 (overdue)',
    'description': '''Payment reminder email (ID: 19c67f7bdf8d804d)
- Total: $282.13 for 3 orders
- Due date: Fri, 20 Feb 2026 (overdue)
- Payment method: Mastercard •••• 8260
- Orders: Bunnings Warehouse etc.

Email labeled ToUnsubscribe but marked as important transactional reminder.
Action: Pay via Afterpay app/website.''',
    'dartboard': 'General/Tasks',
    'status': 'To-do',
    'assignee': 'Bayani Mills',
    'tags': ['payment', 'afterpay', 'urgent', 'finance'],
    'priority': 'high',
}

try:
    result = post('tasks', json_body={'item': task_def})
    task_id = result.get('item', {}).get('id', 'unknown')
    print(f"Task created successfully! ID: {task_id}")
    print(f"Title: {task_def['title']}")
    print(f"Description preview: {task_def['description'][:100]}...")
except Exception as e:
    print(f"Error creating task: {e}")
    sys.exit(1)