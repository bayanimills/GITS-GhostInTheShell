#!/usr/bin/env python3
"""
Process the 3 emails with ToUnsubscribe label per recommendations:
- Australia Post: create DartAI task, archive after task created
- Crazy Domains: create DartAI task, archive after task created  
- Tenant Insurance: unsubscribe (marketing), archive
"""
import subprocess
import json
import sys
import os
from pathlib import Path

# Paths
GOG_BIN = "/home/agent/.linuxbrew/bin/gog"
ACCOUNT = "bayanimills@gmail.com"
DARTAI_BIN = "/home/agent/.openclaw/workspace/skills/dartai/bin/dartai"

def run_gog(args):
    cmd = [GOG_BIN] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if '--json' in args:
            return json.loads(result.stdout)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return None
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return None

def get_unsubscribe_emails():
    """Return list of emails with ToUnsubscribe label."""
    # Get label ID for ToUnsubscribe
    labels = run_gog(["gmail", "labels", "list", "--json"])
    if not labels or "labels" not in labels:
        return []
    label_id = None
    for label in labels["labels"]:
        if label.get("name") == "ToUnsubscribe":
            label_id = label.get("id")
            break
    if not label_id:
        return []
    
    # Fetch messages with that label
    messages = run_gog(["gmail", "messages", "list", "--label", label_id, "--json"])
    if not messages or "messages" not in messages:
        return []
    return messages["messages"]

def create_dartai_task(title, description=""):
    """Create a task in DartAI."""
    # Build request body
    body = {
        "title": title,
        "description": description,
        "status": "unstarted"
    }
    # Use dartai CLI to POST
    cmd = [DARTAI_BIN, "post", "/tasks", json.dumps(body)]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            resp = json.loads(result.stdout)
            task_id = resp.get("id")
            print(f"Created task: {title} (ID: {task_id})")
            return task_id
        else:
            print(f"DartAI error: {result.stderr}")
            return None
    except Exception as e:
        print(f"Failed to create task: {e}")
        return None

def remove_label_and_archive(thread_id):
    """Remove ToUnsubscribe label and archive thread."""
    # Get label ID again
    labels = run_gog(["gmail", "labels", "list", "--json"])
    label_id = None
    for label in labels.get("labels", []):
        if label.get("name") == "ToUnsubscribe":
            label_id = label.get("id")
            break
    if not label_id:
        print(f"  Could not find ToUnsubscribe label ID")
        return False
    
    # Remove label
    result = run_gog(["gmail", "thread", "modify", "--thread", thread_id, 
                      "--remove-labels", label_id])
    if result is None:
        print(f"  Failed to remove label")
        return False
    
    # Archive (remove INBOX label)
    inbox_label_id = None
    for label in labels.get("labels", []):
        if label.get("name") == "INBOX":
            inbox_label_id = label.get("id")
            break
    if inbox_label_id:
        run_gog(["gmail", "thread", "modify", "--thread", thread_id,
                 "--remove-labels", inbox_label_id])
        print(f"  Archived thread {thread_id}")
    else:
        print(f"  Could not find INBOX label")
    
    return True

def main():
    emails = get_unsubscribe_emails()
    if not emails:
        print("No emails with ToUnsubscribe label.")
        return
    
    print(f"Found {len(emails)} emails with ToUnsubscribe label:")
    
    # Classify and process
    for msg in emails:
        subject = msg.get("subject", "").lower()
        from_addr = msg.get("from", "").lower()
        thread_id = msg.get("threadId")
        
        print(f"\n--- Processing: {subject[:50]}...")
        print(f"    From: {from_addr}")
        
        # Determine action
        if "australia post" in from_addr or "parcel" in subject:
            # Create task
            title = "Collect parcel from Australia Post"
            description = f"Email subject: {msg.get('subject')}\nFrom: {from_addr}"
            task_id = create_dartai_task(title, description)
            if task_id:
                remove_label_and_archive(thread_id)
                print("  ✓ Task created, label removed, archived.")
            else:
                print("  ✗ Failed to create task.")
        
        elif "crazy domains" in from_addr or "auto-renew" in subject:
            title = "Review domain renewal for Business Starter"
            description = f"Email subject: {msg.get('subject')}\nFrom: {from_addr}\nAuto-renewal in 30 days."
            task_id = create_dartai_task(title, description)
            if task_id:
                remove_label_and_archive(thread_id)
                print("  ✓ Task created, label removed, archived.")
            else:
                print("  ✗ Failed to create task.")
        
        elif "tenant" in subject or "insurance" in subject:
            # Marketing unsubscribe - just label removal
            print("  Marketing email - removing label and archiving (no task).")
            remove_label_and_archive(thread_id)
            print("  ✓ Label removed, archived.")
        
        else:
            # Default: just remove label and archive
            print("  Unknown type - removing label and archiving.")
            remove_label_and_archive(thread_id)
    
    print("\nDone.")

if __name__ == "__main__":
    main()