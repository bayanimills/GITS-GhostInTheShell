# Gmail Label Refinement - Phase 2 Report

## Executive Summary
Analysis of current Gmail automation system identified opportunities to improve classification accuracy, priority detection, and archive timing. Proposed enhancements include regex-based pattern matching, priority scoring, dynamic archive delays, and unsubscribe automation design.

## Current System Analysis

### Classification Performance (Sample: 100 emails)
- **Total scanned**: 100 messages
- **Finance emails detected**: 16 (16%)
- **Current classification logic**: Simple keyword matching with 2 primary patterns:
  1. "EMERGENT LABS (Stripe)" → Finance/Bayani Enterprises
  2. "Service NSW registration" → Finance/Personal
- **Limitations**:
  - Misses other finance categories (banking, taxes, investments)
  - No context or proximity analysis
  - No sender domain matching
  - Fixed archive delays regardless of importance

## Proposed Enhancements

### 1. Enhanced Classification Engine
**Key Improvements**:
- **Regex pattern matching**: 8 new patterns covering receipts, statements, taxes, investments, crypto
- **Sender domain mapping**: Direct mapping for service.nsw.gov.au, stripe.com, etc.
- **Priority scoring**: Detects urgent/important emails based on keywords and sender reputation
- **Backward compatibility**: Maintains existing label_mappings

**Expected Impact**:
- Increase finance email detection from 16 to potentially 25+ (based on keyword analysis)
- Reduce false positives with more precise regex patterns
- Better categorization into sub-labels (Receipt, Crypto, etc.)

### 2. Priority Scoring Module
**Scoring Factors**:
- High-priority keywords: "urgent", "action required", "overdue", "reminder"
- Medium-priority keywords: "update", "notification", "alert"
- Sender reputation: Government, bank, tax domains
- Pattern-specific priority weights

**Priority Levels**:
- **High** (score ≥5): 2x archive delay multiplier
- **Medium** (score ≥3): 1.5x multiplier  
- **Low** (score <3): 0.5x multiplier

### 3. Archive Timing Calibration
**Recommendations**:
- Implement priority-based delay adjustments
- Category-specific default delays (3 days for receipts, 14 days for statements)
- Future calibration using actual INBOX retention metrics
- Dynamic adjustments based on read/starred status

### 4. Unsubscribe Automation Design
**Workflow**:
- Batch processing of `ToUnsubscribe` labeled emails
- Browser automation to click unsubscribe links
- Safety measures: dry-run mode, rate limiting, error handling
- Phased implementation approach

## Implementation Plan

### Phase 1: Immediate Improvements (1-2 hours)
1. Update `label_rules.json` with enhanced patterns and sender domains
2. Deploy `classifier.py` module to gmail-skill directory
3. Modify `monitor_gmail.py` to use enhanced classifier (optional fallback)
4. Test with dry-run and verify no regression

### Phase 2: Priority Scoring Integration (2-3 hours)
1. Integrate priority scoring into classification
2. Adjust archive delays based on priority
3. Add logging for calibration data collection

### Phase 3: Unsubscribe Automation Prototype (4-8 hours)
1. Develop browser automation script
2. Test with sample emails
3. Integrate with Gmail skill as optional command

## Metrics & Success Measurement

### Classification Metrics
- **Precision**: % of emails correctly labeled per category
- **Recall**: % of relevant emails detected per category
- **F1-score**: Balance of precision and recall

### Automation Metrics
- **Archive accuracy**: % of emails archived at appropriate time
- **User overrides**: Count of manually re-added INBOX labels
- **Processing time**: Time saved per week

### User Satisfaction
- **INBOX zero frequency**: How often INBOX reaches zero
- **Manual sorting time**: Reduction in time spent manually organizing
- **Feedback**: User ratings of automation effectiveness

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Over-classification (false positives) | Start with conservative patterns, dry-run mode |
| Important emails archived too soon | Priority scoring with longer delays for high priority |
| Unsubscribe automation triggers anti-bot measures | Rate limiting, manual confirmation mode |
| Gmail API rate limits | Batch processing, exponential backoff |

## Next Steps
1. **Review and approve** enhanced label_rules.json
2. **Test** classifier with sample email dataset
3. **Deploy** updated configuration
4. **Monitor** for 7 days and collect metrics
5. **Iterate** based on performance data

## Conclusion
The proposed enhancements will transform the Gmail automation from simple keyword matching to an intelligent classification system with priority awareness. This will reduce manual email management while ensuring important emails receive appropriate attention.