#!/usr/bin/env python3
"""
Log skill usage to metadata file.
Call from skills when they are invoked.
Usage: python3 log_skill_usage.py <skill-name> [--success true]
"""
import os
import sys
import json
import argparse
from datetime import datetime

# Load metadata
METADATA_PATH = '/home/agent/.openclaw/workspace-donna/skills_metadata.json'

def log_usage(skill_name, success=True, execution_time_ms=None):
    """Log skill usage in metadata."""
    try:
        with open(METADATA_PATH, 'r') as f:
            metadata = json.load(f)
    except FileNotFoundError:
        print(f"Metadata file not found at {METADATA_PATH}")
        return False
    
    skills = metadata.get('skills', {})
    if skill_name not in skills:
        print(f"Skill '{skill_name}' not found in metadata")
        return False
    
    skill_data = skills[skill_name]
    
    # Update usage stats
    skill_data['last_used'] = datetime.now().strftime('%Y-%m-%d')
    skill_data['usage_count'] = skill_data.get('usage_count', 0) + 1
    
    if success:
        skill_data['success_count'] = skill_data.get('success_count', 0) + 1
    
    # Calculate success rate
    if skill_data['usage_count'] > 0:
        success_rate = skill_data.get('success_count', 0) / skill_data['usage_count']
        skill_data['success_rate'] = f"{success_rate:.1%}"
    else:
        skill_data['success_rate'] = "0%"
    
    # Update performance metrics if execution time provided
    if execution_time_ms is not None:
        if 'performance_metrics' not in skill_data:
            skill_data['performance_metrics'] = {
                'total_executions': 0,
                'successful_executions': 0,
                'failed_executions': 0,
                'total_execution_time_ms': 0,
                'average_execution_time_ms': 0,
                'last_execution_time_ms': 0,
                'last_execution_outcome': '',
                'last_execution_timestamp': ''
            }
        metrics = skill_data['performance_metrics']
        metrics['total_executions'] += 1
        if success:
            metrics['successful_executions'] += 1
            outcome = 'success'
        else:
            metrics['failed_executions'] += 1
            outcome = 'failure'
        metrics['total_execution_time_ms'] += execution_time_ms
        metrics['average_execution_time_ms'] = metrics['total_execution_time_ms'] // metrics['total_executions']
        metrics['last_execution_time_ms'] = execution_time_ms
        metrics['last_execution_outcome'] = outcome
        metrics['last_execution_timestamp'] = datetime.now().isoformat() + 'Z'
    
    skills[skill_name] = skill_data
    metadata['skills'] = skills
    metadata['updated'] = datetime.now().isoformat() + 'Z'
    
    # Save
    with open(METADATA_PATH, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"Logged usage for {skill_name}: count={skill_data['usage_count']}, success_rate={skill_data['success_rate']}")
    return True

def main():
    parser = argparse.ArgumentParser(description='Log skill usage')
    parser.add_argument('skill', help='Skill name')
    parser.add_argument('--success', type=str, default='true', help='Whether usage was successful (true/false)')
    parser.add_argument('--execution-time-ms', type=int, help='Execution time in milliseconds')
    
    args = parser.parse_args()
    success = args.success.lower() == 'true'
    execution_time_ms = args.execution_time_ms
    
    # Also check environment variable
    if execution_time_ms is None:
        env_time = os.environ.get('EXECUTION_TIME_MS')
        if env_time:
            try:
                execution_time_ms = int(env_time)
            except ValueError:
                pass
    
    if log_usage(args.skill, success, execution_time_ms):
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    main()