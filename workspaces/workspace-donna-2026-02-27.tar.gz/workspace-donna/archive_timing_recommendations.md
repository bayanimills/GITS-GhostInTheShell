# Archive Timing Calibration Recommendations

## Current Archive Delays
- **MetaMask**: 1 hour (urgent crypto alerts)
- **Google security alerts**: 12 hours (security notifications)
- **Trezor seed verification**: 12 hours (scam/phishing)
- **Square receipts**: 7 days (purchase receipts)
- **Australia Post**: 7 days (shipping notifications)
- **Service NSW registration**: 7 days (government transactions)
- **Default**: 7 days

## Analysis
Current delays are based on fixed values without considering:
1. **Email priority** (urgent vs informational)
2. **Category-specific review needs** (financial statements vs receipts)
3. **User's actual review patterns** (how long emails stay in INBOX before manual archive)

## Recommended Improvements

### 1. Priority-Based Delay Adjustment
Implement priority scoring to adjust delays:
- **High priority** (urgent, action required): Increase delay by 2x (keep longer)
- **Medium priority** (important notifications): Increase delay by 1.5x
- **Low priority** (informational, receipts): Reduce delay by 0.5x (archive faster)

### 2. Category-Specific Default Delays
| Category | Recommended Delay | Rationale |
|----------|------------------|-----------|
| Security Alerts | 24 hours | Review security events within a day |
| Financial Receipts | 3 days | Verify transactions, then archive |
| Bank Statements | 14 days | Monthly review cycle |
| Bills & Invoices | 7 days | Pay within a week |
| Government Notices | 7 days | Time to process |
| Crypto Alerts | 12 hours | Time-sensitive market movements |
| Newsletters | 1 day | Quick skim, then archive |
| Promotional | 12 hours | Low value, archive quickly |

### 3. Dynamic Delay Based on Email Age
- For emails older than 30 days: force archive (auto-archive)
- For emails with "read" status: reduce delay by 50%
- For emails with "starred" status: double delay (keep until unstarred)

### 4. Calibration Method
To calibrate based on actual user behavior:
1. **Log INBOX retention times**: Track how long emails stay in INBOX before being archived manually
2. **Compute median retention per category**: Use historical data to set delays
3. **A/B testing**: Try different delays for a subset of emails and measure user satisfaction

## Implementation Plan
1. Extend `label_rules.json` with `priority_scoring` and `archive_delay_adjustments`
2. Modify `monitor_gmail.py` to use priority scores when computing archive delays
3. Add logging to measure actual retention times for future calibration

## Expected Benefits
- Reduce INBOX clutter by archiving low-priority emails faster
- Keep important emails visible longer
- Align automation with user's natural review patterns