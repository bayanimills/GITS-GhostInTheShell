#!/usr/bin/env python3
import json
from pathlib import Path
from datetime import datetime

skills_metadata_path = Path("/home/agent/.openclaw/workspace-donna/skills_metadata.json")

with open(skills_metadata_path, 'r') as f:
    data = json.load(f)

# Skills to deprecate (merged into system-maintenance)
deprecate_skills = ["system-integrity", "proactive-prep"]

for skill_name in deprecate_skills:
    if skill_name in data["skills"]:
        data["skills"][skill_name]["lifecycle"] = "deprecated"
        data["skills"][skill_name]["description"] += " [DEPRECATED - Merged into system-maintenance]"
        data["skills"][skill_name]["last_verified"] = datetime.now().strftime("%Y-%m-%d")
        print(f"Deprecated {skill_name}")
    else:
        print(f"Skill {skill_name} not found in metadata")

data["updated"] = datetime.now().isoformat()

with open(skills_metadata_path, 'w') as f:
    json.dump(data, f, indent=2)

print("Updated skills_metadata.json")