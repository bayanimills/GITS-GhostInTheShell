#!/usr/bin/env python3
"""
Complete inventory of all skills in /home/agent/openclaw/skills/
Extracts metadata from SKILL.md frontmatter and updates skills_metadata.json
"""
import os
import sys
import json
import yaml
import datetime
from pathlib import Path

SKILLS_DIR = Path('/home/agent/openclaw/skills')
METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'

# Category mapping based on skill name/keywords
CATEGORY_MAP = {
    # Development
    'coding-agent': 'development',
    'skill-creator': 'development',
    'github': 'github',
    'gh-issues': 'github',
    'gog': 'google',
    'clawhub': 'tooling',
    'healthcheck': 'security',
    'nano-pdf': 'productivity',
    'weather': 'utility',
    # Add more as needed
}

# Default category fallbacks
DEFAULT_CATEGORIES = {
    'github': 'github',
    'git': 'github',
    'code': 'development',
    'agent': 'development',
    'skill': 'development',
    'pdf': 'productivity',
    'note': 'productivity',
    'notes': 'productivity',
    'email': 'communication',
    'chat': 'communication',
    'slack': 'communication',
    'discord': 'communication',
    'message': 'communication',
    'whatsapp': 'communication',
    'telegram': 'communication',
    'calendar': 'productivity',
    'reminder': 'productivity',
    'todo': 'productivity',
    'task': 'productivity',
    'weather': 'utility',
    'time': 'utility',
    'location': 'utility',
    'map': 'utility',
    'search': 'utility',
    'music': 'entertainment',
    'audio': 'entertainment',
    'video': 'entertainment',
    'image': 'media',
    'photo': 'media',
    'camera': 'media',
    'security': 'security',
    'auth': 'security',
    'password': 'security',
    'health': 'health',
    'food': 'lifestyle',
    'order': 'lifestyle',
    'shopping': 'lifestyle',
    'travel': 'lifestyle',
    'places': 'lifestyle',
    'home': 'iot',
    'hue': 'iot',
    'light': 'iot',
    'sonos': 'iot',
    'spotify': 'entertainment',
    'ssh': 'system',
    'tmux': 'system',
    'terminal': 'system',
    'cron': 'system',
    'log': 'system',
    'session': 'system',
    'browser': 'web',
    'web': 'web',
    'fetch': 'web',
    'search': 'web',
    'openai': 'ai',
    'ai': 'ai',
    'model': 'ai',
    'whisper': 'ai',
    'tts': 'ai',
    'speech': 'ai',
    'summarize': 'ai',
    'gemini': 'ai',
    'oracle': 'ai',
}

def categorize_skill(skill_name, description):
    """Determine category for a skill."""
    # First check explicit mapping
    if skill_name in CATEGORY_MAP:
        return CATEGORY_MAP[skill_name]
    
    # Check keywords in skill name
    for keyword, category in DEFAULT_CATEGORIES.items():
        if keyword in skill_name.lower():
            return category
    
    # Check description keywords
    desc_lower = description.lower()
    for keyword, category in DEFAULT_CATEGORIES.items():
        if keyword in desc_lower:
            return category
    
    # Default fallback
    return 'utility'

def extract_metadata(skill_path):
    """Extract metadata from SKILL.md frontmatter."""
    skill_md = skill_path / 'SKILL.md'
    if not skill_md.exists():
        return None
    
    content = skill_md.read_text()
    # Parse frontmatter between --- delimiters
    if content.startswith('---'):
        parts = content.split('---', 2)
        if len(parts) >= 3:
            frontmatter = parts[1].strip()
            try:
                data = yaml.safe_load(frontmatter)
                return data
            except yaml.YAMLError as e:
                print(f"  Warning: Failed to parse YAML for {skill_path.name}: {e}")
                return None
    return None

def get_dependencies(metadata):
    """Extract dependency information from metadata."""
    deps = {
        'bins': [],
        'packages': [],
        'credentials': [],
        'external': []
    }
    
    if not metadata:
        return deps
    
    openclaw = metadata.get('metadata', {}).get('openclaw', {})
    requires = openclaw.get('requires', {})
    
    # Binary dependencies
    bins = requires.get('bins', [])
    if isinstance(bins, list):
        deps['bins'] = bins
    
    # Package dependencies (from install section)
    install = openclaw.get('install', [])
    for item in install:
        if isinstance(item, dict):
            kind = item.get('kind')
            if kind in ['brew', 'apt', 'pip', 'npm', 'cargo']:
                package = item.get('formula') or item.get('package')
                if package:
                    deps['packages'].append(f"{kind}:{package}")
    
    # OS restrictions
    os_list = openclaw.get('os', [])
    if os_list:
        deps['external'].append(f"os:{','.join(os_list)}")
    
    return deps

def main():
    print(f"Scanning skills directory: {SKILLS_DIR}")
    
    # Load existing metadata
    if METADATA_PATH.exists():
        with open(METADATA_PATH) as f:
            metadata = json.load(f)
    else:
        metadata = {
            "version": "1.0.0",
            "updated": "",
            "skills": {},
            "automation_scripts": {}
        }
    
    existing_skills = set(metadata.get('skills', {}).keys())
    print(f"Existing skills in metadata: {len(existing_skills)}")
    
    # Iterate over skill directories
    skill_dirs = [d for d in SKILLS_DIR.iterdir() if d.is_dir()]
    print(f"Found {len(skill_dirs)} skill directories")
    
    new_skills = []
    updated_skills = []
    
    for skill_dir in sorted(skill_dirs):
        skill_name = skill_dir.name
        print(f"Processing {skill_name}...")
        
        # Extract metadata from SKILL.md
        meta = extract_metadata(skill_dir)
        
        # Determine description
        description = ""
        if meta:
            description = meta.get('description', '')
        else:
            # Fallback: read first line of SKILL.md after frontmatter
            skill_md = skill_dir / 'SKILL.md'
            if skill_md.exists():
                content = skill_md.read_text()
                lines = content.split('\n')
                for line in lines:
                    if line.strip() and not line.startswith('---'):
                        description = line.strip()[:200]
                        break
        
        # Get dependencies
        deps = get_dependencies(meta)
        
        # Determine category
        category = categorize_skill(skill_name, description)
        
        # Generate skill ID (consistent if already exists)
        skill_id = None
        if skill_name in metadata['skills']:
            skill_id = metadata['skills'][skill_name].get('id')
            updated_skills.append(skill_name)
        else:
            # Generate deterministic ID from skill name hash
            import hashlib
            hash_obj = hashlib.sha256(skill_name.encode())
            skill_id = hash_obj.hexdigest()[:12]
            new_skills.append(skill_name)
        
        # Build skill entry
        skill_entry = {
            'id': skill_id,
            'name': skill_name,
            'description': description,
            'location': f"~/openclaw/skills/{skill_name}/SKILL.md",
            'version': '1.0.0',  # Default, could extract from metadata
            'dependencies': deps,
            'last_used': metadata['skills'].get(skill_name, {}).get('last_used', ''),
            'usage_count': metadata['skills'].get(skill_name, {}).get('usage_count', 0),
            'success_count': metadata['skills'].get(skill_name, {}).get('success_count', 0),
            'test_status': metadata['skills'].get(skill_name, {}).get('test_status', 'untested'),
            'last_verified': metadata['skills'].get(skill_name, {}).get('last_verified', ''),
            'lifecycle': 'active',
            'category': category,
            'triggering': metadata['skills'].get(skill_name, {}).get('triggering', ''),
            'metadata_source': 'inventory',
            'validation_status': 'pending',
            'last_tested': metadata['skills'].get(skill_name, {}).get('last_tested', ''),
            'success_rate': metadata['skills'].get(skill_name, {}).get('success_rate', '0.0%')
        }
        
        # Update metadata
        metadata['skills'][skill_name] = skill_entry
    
    # Update timestamp
    metadata['updated'] = datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z'
    
    # Save updated metadata
    with open(METADATA_PATH, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\nInventory complete!")
    print(f"New skills added: {len(new_skills)}")
    print(f"Existing skills updated: {len(updated_skills)}")
    print(f"Total skills in metadata: {len(metadata['skills'])}")
    
    # List new skills
    if new_skills:
        print(f"\nNew skills:")
        for skill in new_skills:
            print(f"  - {skill}")
    
    return 0

if __name__ == '__main__':
    sys.exit(main())