#!/usr/bin/env python3
"""
Check if skill dependencies (binaries, packages) are installed.
Reports missing dependencies for skills.
"""
import json
import os
import sys
import subprocess
from pathlib import Path

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'
print('Script starting...')

def check_binary_exists(binary_name):
    """Check if binary exists in PATH."""
    try:
        result = subprocess.run(['which', binary_name], capture_output=True, text=True, timeout=10)
        return result.returncode == 0, result.stdout.strip()
    except subprocess.TimeoutExpired:
        return False, "timeout after 10 seconds"
    except Exception as e:
        return False, str(e)

def check_brew_package(package_name):
    """Check if Homebrew package is installed."""
    try:
        result = subprocess.run(['brew', 'list', package_name], capture_output=True, text=True, timeout=10)
        return result.returncode == 0, result.stdout.strip()
    except subprocess.TimeoutExpired:
        return False, "timeout after 10 seconds"
    except Exception as e:
        return False, str(e)

def check_package_manager(package, manager='brew'):
    """Check package using specified package manager."""
    if manager == 'brew':
        return check_brew_package(package)
    # Add other package managers as needed
    return False, f"Unsupported package manager: {manager}"

def load_metadata():
    try:
        with open(METADATA_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Metadata file not found at {METADATA_PATH}")
        return None

def main():
    print("Loading metadata...")
    metadata = load_metadata()
    if not metadata:
        print("Failed to load metadata")
        sys.exit(1)
    print(f"Loaded metadata for {len(metadata.get('skills', {}))} skills")
    skills = metadata.get('skills', {})
    if not skills:
        print("No skills found in metadata")
        return
    
    print("Skill Dependency Check")
    print("=" * 60)
    
    all_pass = True
    missing_summary = {}
    
    for skill_name, skill_data in sorted(skills.items()):
        deps = skill_data.get('dependencies', {})
        if not deps:
            # Skills without dependency info
            print(f"{skill_name}: ⚠️  No dependency information")
            missing_summary[skill_name] = ['no dependency info']
            continue
        
        bins = deps.get('bins', [])
        packages = deps.get('packages', [])
        
        missing = []
        
        # Check binaries
        for binary in bins:
            exists, location = check_binary_exists(binary)
            if exists:
                print(f"{skill_name}: ✅ {binary} ({location})")
            else:
                print(f"{skill_name}: ❌ {binary} (not found in PATH)")
                missing.append(f"binary:{binary}")
                all_pass = False
        
        # Check packages
        for package in packages:
            # Parse package spec (e.g., "brew:1password-cli")
            if ':' in package:
                manager, pkg = package.split(':', 1)
            else:
                manager, pkg = 'brew', package
            
            exists, info = check_package_manager(pkg, manager)
            if exists:
                print(f"{skill_name}: ✅ {package} (installed via {manager})")
            else:
                print(f"{skill_name}: ❌ {package} (not installed)")
                missing.append(f"package:{package}")
                all_pass = False
        
        if not bins and not packages:
            print(f"{skill_name}: ℹ️  No binary or package dependencies")
        
        if missing:
            missing_summary[skill_name] = missing
    
    print("\n" + "=" * 60)
    print("Summary:")
    
    if missing_summary:
        print("Missing dependencies:")
        for skill_name, missing_list in missing_summary.items():
            if missing_list != ['no dependency info']:
                print(f"  {skill_name}: {', '.join(missing_list)}")
    else:
        print("All dependencies satisfied!")
    
    # Skills without dependency info
    no_info = [name for name, missing in missing_summary.items() if missing == ['no dependency info']]
    if no_info:
        print(f"\nSkills needing manual dependency review ({len(no_info)}):")
        for name in no_info:
            print(f"  - {name}")
    
    if all_pass:
        print("\n✅ All checks passed!")
        sys.exit(0)
    else:
        print("\n❌ Some dependencies missing")
        sys.exit(1)

if __name__ == '__main__':
    main()