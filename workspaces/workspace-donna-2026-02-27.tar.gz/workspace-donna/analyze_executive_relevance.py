#!/usr/bin/env python3
"""
Analyze tasks for executive relevance based on Donna's SOUL.md responsibilities.
"""

import os
import sys
import re

# Add DartAI scripts to path
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')

try:
    from dartai_client import get
except ImportError as e:
    print(f"Error importing dartai_client: {e}")
    sys.exit(1)

def fetch_all_tasks():
    """Fetch all tasks."""
    try:
        result = get('tasks/list', params={'limit': 100, 'no_defaults': True})
        return result.get('results', [])
    except Exception as e:
        print(f"Error fetching tasks: {e}")
        return []

def is_executive_relevant(task):
    """
    Determine if a task is executive-relevant based on Donna's responsibilities.
    
    Criteria from SOUL.md:
    1. Situational Command - total contextual awareness, strategic timing
    2. Reputation Stewardship - credibility, narrative control, trust
    3. Crisis Containment - detecting instability, resolving quietly
    4. Executive Enablement - clearing cognitive space for leadership
    
    Returns: (bool, category, reason)
    """
    title = task.get('title', '').lower()
    description = task.get('description', '').lower() if task.get('description') else ''
    tags = task.get('tags', [])
    
    # Executive keywords by category
    situational_keywords = [
        'situational', 'contextual', 'strategic', 'awareness', 'timing',
        'coordinate', 'oversight', 'monitor', 'review', 'brief', 'assessment'
    ]
    
    reputation_keywords = [
        'reputation', 'brand', 'credibility', 'trust', 'narrative',
        'integrity', 'stewardship', 'perception', 'image', 'pr'
    ]
    
    crisis_keywords = [
        'crisis', 'containment', 'emergency', 'urgent', 'critical',
        'risk', 'threat', 'vulnerability', 'breach', 'failure'
    ]
    
    enablement_keywords = [
        'enablement', 'leadership', 'cognitive', 'space', 'focus',
        'decision', 'strategic', 'briefing', 'preparation', 'support'
    ]
    
    # Check title and description
    all_text = title + ' ' + description
    
    # Situational Command
    if any(keyword in all_text for keyword in situational_keywords):
        return True, 'Situational Command', 'Contains situational/strategic keywords'
    
    # Reputation Stewardship  
    if any(keyword in all_text for keyword in reputation_keywords):
        return True, 'Reputation Stewardship', 'Contains reputation/brand keywords'
    
    # Crisis Containment
    if any(keyword in all_text for keyword in crisis_keywords):
        return True, 'Crisis Containment', 'Contains crisis/risk keywords'
    
    # Executive Enablement
    if any(keyword in all_text for keyword in enablement_keywords):
        return True, 'Executive Enablement', 'Contains enablement/leadership keywords'
    
    # Check for executive tags
    executive_tags = ['executive', 'strategic', 'reputation', 'crisis', 'leadership']
    if any(tag in executive_tags for tag in tags):
        return True, 'Tag-based', f'Has executive tag: {tags}'
    
    # Check assignee - Donna's tasks might be executive by default
    assignee = task.get('assignee', '')
    if assignee == 'Donna':
        # But we need to filter out operational Donna tasks
        # Check if it looks operational
        operational_patterns = [
            r'add to calendar', r'calendar event', r'notion', r'knowledge base',
            r'set up', r'test', r'import', r'follow up', r'patient', r'stroke',
            r'update meeting'
        ]
        is_operational = any(re.search(pattern, title, re.IGNORECASE) for pattern in operational_patterns)
        if not is_operational:
            return True, 'Donna Assigned', 'Assigned to Donna and not obviously operational'
    
    return False, 'Non-executive', 'Does not meet executive criteria'

def main():
    tasks = fetch_all_tasks()
    print(f"Total tasks: {len(tasks)}")
    
    executive_tasks = []
    
    print("\n=== Executive Relevance Analysis ===")
    for task in tasks:
        is_exec, category, reason = is_executive_relevant(task)
        if is_exec:
            executive_tasks.append((task, category, reason))
            title = task.get('title', 'No title')
            assignee = task.get('assignee', 'Unassigned')
            print(f"✓ {title}")
            print(f"  Assignee: {assignee}, Category: {category}")
            print(f"  Reason: {reason}")
            print()
    
    print(f"\n=== Summary ===")
    print(f"Executive-relevant tasks: {len(executive_tasks)}/{len(tasks)}")
    
    # Categorize by Donna's responsibilities
    categories = {}
    for task, category, reason in executive_tasks:
        categories[category] = categories.get(category, 0) + 1
    
    print("\nBy executive category:")
    for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        print(f"  {category}: {count}")
    
    # Recommendations
    print("\n=== Standup Recommendations ===")
    print("1. Show only executive-relevant tasks (above)")
    print("2. Group by Donna's four responsibilities")
    print("3. Include strategic context, not just task lists")
    print("4. Focus on what needs executive attention vs operational status")

if __name__ == '__main__':
    # Check API key
    if not os.environ.get('DARTAI_API_KEY') and not os.environ.get('DARTAI_SHARED_TOKEN'):
        print("Warning: No DartAI API key found in environment")
    
    main()