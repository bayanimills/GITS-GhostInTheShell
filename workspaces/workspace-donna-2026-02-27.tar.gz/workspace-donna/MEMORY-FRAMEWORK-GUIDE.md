# MEMORY FRAMEWORK GUIDE - For Donna Agent

## Overview
This guide documents the memory framework features that Donna should implement to match the main agent's context-drift prevention capabilities.

## Core Memory Features to Implement

### 1. Mandatory Memory Search Protocol
**Before answering anything about prior work, decisions, dates, people, preferences, or todos:**
1. Run `memory_search` on MEMORY.md + memory/*.md
2. Use `memory_get` to pull only needed lines
3. If low confidence after search, say you checked
4. Include citations: `Source: <path#line>` when helpful

**Example workflow:**
```bash
# When user asks about previous system issues:
memory_search "system issues gateway downtime"
# Then read specific snippets
memory_get "/home/agent/.openclaw/workspace-donna/memory/2026-02-17.md" from=10 lines=5
```

### 2. Daily Memory Logs
**File:** `memory/YYYY-MM-DD.md`
**Purpose:** Record daily activities, system checks, issues, decisions

**Required sections:**
- **System Status**: Gateway, sessions, backups
- **Heartbeat Checks**: Results of daily validation
- **Issues Found**: Any problems detected
- **Actions Taken**: Maintenance performed
- **Decisions Made**: Configuration changes
- **Tags**: #system-alert, #maintenance, #decision

**Append-only rule:** Never overwrite, always append new content

### 3. Memory Flush Protocol
**When:** After significant work, before conversation compaction, or when user requests
**Command:** `echo "## Memory Flush: [TIMESTAMP]" >> memory/YYYY-MM-DD.md`
**Content:** Store durable memories about system state, decisions, next steps

### 4. Tagging System
**Required tags:**
- `#project-{name}` - Project identification (e.g., #project-system-monitoring)
- `#decision` - Important configuration or operational decisions
- `#action-item` - Tasks to complete
- `#system-alert` - System issues requiring attention
- `#maintenance` - Maintenance operations performed
- `#heartbeat-check` - Results of system validation

### 5. Conversation Management
**For long conversations:**
1. Monitor conversation length
2. Suggest compaction when appropriate
3. Store key points to memory before compaction
4. Reference memory after compaction for continuity

## Implementation Checklist

### ✅ Completed
- [x] MEMORY.md created with project structure
- [x] Memory directory created (`memory/`)
- [x] Memory framework guide created

### 🔄 In Progress
- [ ] Daily memory log for today (`memory/2026-02-17.md`)
- [ ] Memory search integration into workflow
- [ ] Tagging system implementation

### 📋 To Do
- [ ] Create memory flush script
- [ ] Setup supermemory backup cron
- [ ] Implement weekly review script
- [ ] Setup monthly audit script
- [ ] Create memory dashboard

## Quick Reference Commands

```bash
# Search memory
memory_search "query about previous work"

# Read specific memory file
memory_get "path/to/memory.md" from=20 lines=10

# Append to daily log
echo "## New Entry" >> memory/$(date +%Y-%m-%d).md

# Memory flush
echo "## Memory Flush: $(date)" >> memory/$(date +%Y-%m-%d).md
echo "- Key decision: ..." >> memory/$(date +%Y-%m-%d).md
echo "- System status: ..." >> memory/$(date +%Y-%m-%d).md
echo "- Next steps: ..." >> memory/$(date +%Y-%m-%d).md
```

## Integration with HEARTBEAT.md

**Memory framework enhances HEARTBEAT.md by:**
1. **Logging results** - All heartbeat checks go to daily memory
2. **Tracking issues** - System alerts stored with timestamps
3. **Documenting fixes** - Maintenance actions recorded
4. **Providing context** - Historical data for trend analysis

**Workflow:**
1. Run heartbeat check
2. Record results in `memory/YYYY-MM-DD.md`
3. Tag with `#heartbeat-check`
4. Include system status summary
5. Note any issues requiring follow-up

## Success Metrics

- **100% of heartbeat checks** logged to memory
- **All system issues** tagged and tracked
- **Memory search used** before answering about prior work
- **Daily logs maintained** with proper tagging
- **Memory flushes performed** after significant work

---

*This framework ensures Donna maintains context awareness and prevents drift, matching the main agent's capabilities.*

**Last Updated:** 2026-02-17 04:50 UTC