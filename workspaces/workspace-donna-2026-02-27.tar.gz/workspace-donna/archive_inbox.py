#!/usr/bin/env python3
import subprocess
import sys
import time

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def main():
    # Fetch all inbox threads
    print("Fetching inbox threads...")
    cmd = ["gmail", "search", "in:inbox", "--max", "200", "--json"]
    success, output = run_gog(cmd)
    if not success:
        print("Failed to fetch threads.")
        return
    import json
    data = json.loads(output)
    threads = data.get("threads", [])
    ids = [t["id"] for t in threads]
    print(f"Found {len(ids)} threads in inbox.")
    
    # Batch remove INBOX label
    batch_size = 20
    archived = 0
    for i in range(0, len(ids), batch_size):
        batch = ids[i:i+batch_size]
        print(f"Batch {i//batch_size + 1}: {len(batch)} threads")
        args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
        success, _ = run_gog(args)
        if not success:
            print("Batch failed, stopping.")
            break
        archived += len(batch)
        time.sleep(1)
    
    print(f"Archived {archived} threads.")
    # Verify
    cmd = ["gmail", "search", "in:inbox", "--max", "5", "--json"]
    success, output = run_gog(cmd)
    if success:
        data = json.loads(output)
        remaining = len(data.get("threads", []))
        print(f"Remaining in inbox: {remaining}")
    else:
        print("Could not verify.")

if __name__ == "__main__":
    main()