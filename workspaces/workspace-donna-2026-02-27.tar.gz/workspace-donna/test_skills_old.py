#!/usr/bin/env python3
"""
Test each skill to verify it's operational.
Updates metadata with test status and logs usage.
"""
import os
import sys
import json
import subprocess
import datetime
from pathlib import Path

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'
LOG_USAGE_SCRIPT = Path(__file__).parent / 'log_skill_usage.py'

def load_metadata():
    with open(METADATA_PATH) as f:
        return json.load(f)

def save_metadata(metadata):
    metadata['updated'] = datetime.datetime.now().isoformat() + 'Z'
    with open(METADATA_PATH, 'w') as f:
        json.dump(metadata, f, indent=2)

def run_test(skill_name):
    """Run test for a skill, return (success, output)."""
    # Mapping of skill name to test command
    tests = {
        'clawhub': ['which', 'clawhub'],
        'coding-agent': ['ls', '-la', '/home/agent/openclaw/skills/coding-agent/SKILL.md'],
        'gh-issues': ['gh', '--version'],  # Check gh exists, not auth status
        'github': ['gh', '--help'],
        'gog': ['gog', '--help'],
        'healthcheck': ['which', 'ssh'],
        'nano-pdf': ['which', 'nano-pdf'],
        'skill-creator': ['ls', '-la', '/home/agent/openclaw/skills/skill-creator/SKILL.md'],
        'weather': ['curl', '--version'],  # Check curl exists, not network
    }
    
    if skill_name not in tests:
        return False, f"No test defined for {skill_name}"
    
    cmd = tests[skill_name]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        success = result.returncode == 0
        output = result.stdout.strip()[:200]
        if not output:
            output = result.stderr.strip()[:200]
        return success, output
    except subprocess.TimeoutExpired:
        return False, "Timeout"
    except Exception as e:
        return False, str(e)

def log_usage(skill_name, success):
    """Call log_skill_usage.py."""
    cmd = [sys.executable, str(LOG_USAGE_SCRIPT), skill_name]
    if not success:
        cmd.append('--success')
        cmd.append('false')
    try:
        subprocess.run(cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        print(f"Warning: Failed to log usage for {skill_name}: {e}")

def main():
    print("Testing skills...")
    metadata = load_metadata()
    skills = metadata.get('skills', {})
    
    results = {}
    for skill_name in skills:
        print(f"Testing {skill_name}...", end=' ')
        success, output = run_test(skill_name)
        status = 'pass' if success else 'fail'
        print(status)
        if output:
            print(f"  Output: {output}")
        
        # Update metadata
        skill_data = skills[skill_name]
        skill_data['test_status'] = status
        skill_data['last_tested'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if not success:
            skill_data['last_test_error'] = output[:500]
        else:
            skill_data.pop('last_test_error', None)
        
        # Log usage (test invocation)
        log_usage(skill_name, success)
        
        results[skill_name] = success
    
    # Save updated metadata
    save_metadata(metadata)
    
    # Print summary
    passed = sum(1 for s in results.values() if s)
    total = len(results)
    print(f"\nSummary: {passed}/{total} skills passed")
    
    if passed < total:
        failed = [name for name, ok in results.items() if not ok]
        print(f"Failed: {', '.join(failed)}")
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()