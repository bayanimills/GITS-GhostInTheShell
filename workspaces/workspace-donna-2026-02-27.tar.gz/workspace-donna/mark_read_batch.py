#!/usr/bin/env python3
import subprocess
import json
import sys

def run_gog(args):
    cmd = ["/home/agent/.linuxbrew/bin/gog"] + args + ["--account", "bayanimills@gmail.com"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return None
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return None

def main():
    # Fetch up to 100 unread threads
    print("Fetching unread threads...")
    cmd = ["gmail", "search", "is:unread", "--max", "100", "--json"]
    result = run_gog(cmd)
    if not result:
        print("Failed to fetch threads.")
        return
    try:
        data = json.loads(result)
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return
    
    threads = data.get("threads", [])
    print(f"Found {len(threads)} unread threads.")
    
    for i, thread in enumerate(threads):
        thread_id = thread["id"]
        subject = thread.get("subject", "No subject")[:50]
        labels = thread.get("labels", [])
        if "UNREAD" not in labels:
            print(f"[{i+1}/{len(threads)}] Already read: {subject}")
            continue
        # Remove UNREAD label
        res = run_gog(["gmail", "labels", "modify", thread_id, "--remove", "UNREAD"])
        if res is None:
            print(f"[{i+1}/{len(threads)}] Failed: {subject}")
        else:
            print(f"[{i+1}/{len(threads)}] Marked read: {subject}")
    
    print("Done.")

if __name__ == "__main__":
    main()