#!/usr/bin/env python3
"""
Contextual skill recommendation system.
Recommends skills based on task description, category, and usage patterns.
"""
import json
import re
import sys
from pathlib import Path
from collections import defaultdict

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'

class SkillRecommender:
    def __init__(self, metadata_path=METADATA_PATH):
        self.metadata = self.load_metadata(metadata_path)
        self.skills = self.metadata.get('skills', {})
        self.build_index()
    
    def load_metadata(self, path):
        try:
            with open(path) as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Metadata file not found at {path}")
            return {'skills': {}}
    
    def build_index(self):
        """Build keyword index from skill names, descriptions, categories."""
        self.keyword_index = defaultdict(list)
        self.category_index = defaultdict(list)
        
        for skill_name, skill_data in self.skills.items():
            # Keywords from skill name
            name_keywords = self.extract_keywords(skill_name)
            for kw in name_keywords:
                self.keyword_index[kw].append(skill_name)
            
            # Keywords from description
            desc = skill_data.get('description', '')
            desc_keywords = self.extract_keywords(desc)
            for kw in desc_keywords:
                self.keyword_index[kw].append(skill_name)
            
            # Category
            category = skill_data.get('category', '')
            if category:
                self.category_index[category].append(skill_name)
    
    def extract_keywords(self, text):
        """Extract meaningful keywords from text."""
        if not text:
            return []
        # Convert to lowercase, remove punctuation
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        words = text.split()
        
        # Filter out common stopwords
        stopwords = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should', 'could', 'can', 'may', 'might', 'must', 'from', 'as', 'so', 'that', 'this', 'these', 'those', 'it', 'its', 'they', 'them', 'their', 'we', 'our', 'you', 'your', 'i', 'me', 'my', 'he', 'him', 'his', 'she', 'her', 'us'}
        keywords = [w for w in words if w not in stopwords and len(w) > 2]
        
        # Also include bigrams for common skill terms
        bigrams = []
        for i in range(len(keywords) - 1):
            bigrams.append(f"{keywords[i]}_{keywords[i+1]}")
        
        return keywords + bigrams
    
    def recommend_by_keywords(self, task_description, limit=5):
        """Recommend skills based on keyword matching with task description."""
        task_keywords = self.extract_keywords(task_description)
        
        # Score skills based on keyword matches
        scores = defaultdict(int)
        for kw in task_keywords:
            if kw in self.keyword_index:
                for skill_name in self.keyword_index[kw]:
                    scores[skill_name] += 1
        
        # Boost score for exact matches in skill name
        for skill_name in self.skills:
            if any(kw in skill_name.lower() for kw in task_keywords):
                scores[skill_name] += 3
        
        # Sort by score, then by usage count (if available)
        sorted_skills = sorted(scores.items(), key=lambda x: (-x[1], -self.skills[x[0]].get('usage_count', 0)))
        
        # Return top N
        recommendations = []
        for skill_name, score in sorted_skills[:limit]:
            skill_data = self.skills[skill_name]
            recommendations.append({
                'skill': skill_name,
                'score': score,
                'category': skill_data.get('category', ''),
                'description': skill_data.get('description', '')[:100],
                'success_rate': skill_data.get('success_rate', 'unknown'),
                'test_status': skill_data.get('test_status', 'unknown')
            })
        
        return recommendations
    
    def recommend_by_category(self, category, limit=5):
        """Recommend skills within a specific category."""
        if category not in self.category_index:
            # Try fuzzy match
            matched = [c for c in self.category_index.keys() if category.lower() in c.lower()]
            if not matched:
                return []
            category = matched[0]
        
        skill_names = self.category_index[category]
        # Sort by usage count and success rate
        sorted_skills = sorted(skill_names, key=lambda name: (
            -self.skills[name].get('usage_count', 0),
            -self.skills[name].get('success_rate', 0)
        ))
        
        recommendations = []
        for skill_name in sorted_skills[:limit]:
            skill_data = self.skills[skill_name]
            recommendations.append({
                'skill': skill_name,
                'category': category,
                'usage_count': skill_data.get('usage_count', 0),
                'success_rate': skill_data.get('success_rate', 'unknown'),
                'test_status': skill_data.get('test_status', 'unknown')
            })
        
        return recommendations
    
    def recommend_by_context(self, task_description, categories=None, limit=5):
        """Hybrid recommendation using both keywords and categories."""
        keyword_recs = self.recommend_by_keywords(task_description, limit=limit*2)
        
        # If categories specified, filter by categories
        if categories:
            filtered = []
            for rec in keyword_recs:
                if any(cat.lower() in rec['category'].lower() for cat in categories):
                    filtered.append(rec)
            keyword_recs = filtered
        
        # Deduplicate and rank
        seen = set()
        final_recs = []
        for rec in keyword_recs:
            if rec['skill'] not in seen:
                seen.add(rec['skill'])
                final_recs.append(rec)
                if len(final_recs) >= limit:
                    break
        
        return final_recs
    
    def get_skill_details(self, skill_name):
        """Get detailed information about a skill."""
        if skill_name not in self.skills:
            return None
        return self.skills[skill_name]

def main():
    """Command line interface for skill recommendations."""
    import argparse
    parser = argparse.ArgumentParser(description='Recommend skills based on context')
    parser.add_argument('task', nargs='?', help='Task description')
    parser.add_argument('--category', help='Filter by category')
    parser.add_argument('--limit', type=int, default=5, help='Number of recommendations')
    parser.add_argument('--list-categories', action='store_true', help='List all categories')
    parser.add_argument('--skill-details', help='Get details for a specific skill')
    
    args = parser.parse_args()
    
    recommender = SkillRecommender()
    
    if args.list_categories:
        categories = set()
        for skill_data in recommender.skills.values():
            cat = skill_data.get('category')
            if cat:
                categories.add(cat)
        print("Available categories:")
        for cat in sorted(categories):
            print(f"  - {cat}")
        return
    
    if args.skill_details:
        details = recommender.get_skill_details(args.skill_details)
        if details:
            print(json.dumps(details, indent=2))
        else:
            print(f"Skill '{args.skill_details}' not found")
        return
    
    if not args.task:
        parser.print_help()
        return
    
    if args.category:
        recommendations = recommender.recommend_by_category(args.category, limit=args.limit)
    else:
        recommendations = recommender.recommend_by_context(args.task, limit=args.limit)
    
    if not recommendations:
        print("No matching skills found.")
        return
    
    print(f"Recommendations for: '{args.task}'")
    for i, rec in enumerate(recommendations, 1):
        print(f"{i}. {rec['skill']} ({rec['category']})")
        print(f"   Score: {rec.get('score', 'N/A')}")
        print(f"   Description: {rec['description']}")
        print(f"   Success rate: {rec['success_rate']}, Test status: {rec['test_status']}")
        print()

if __name__ == '__main__':
    main()