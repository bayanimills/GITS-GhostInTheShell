#!/usr/bin/env python3
"""
Enhanced skill testing framework.
Tests all skills in skills_metadata.json, verifying dependencies and basic functionality.
Updates metadata with test results and execution metrics.
"""
import os
import sys
import json
import subprocess
import datetime
import time
from pathlib import Path

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'
LOG_USAGE_SCRIPT = Path(__file__).parent / 'log_skill_usage.py'

def load_metadata():
    with open(METADATA_PATH) as f:
        return json.load(f)

def save_metadata(metadata):
    metadata['updated'] = datetime.datetime.now().isoformat() + 'Z'
    with open(METADATA_PATH, 'w') as f:
        json.dump(metadata, f, indent=2)

def test_binary_exists(binary):
    """Test if a binary exists in PATH."""
    try:
        result = subprocess.run(['which', binary], capture_output=True, text=True, timeout=5)
        return result.returncode == 0, result.stdout.strip()
    except subprocess.TimeoutExpired:
        return False, "Timeout checking binary"
    except Exception as e:
        return False, str(e)

def test_binary_version(binary):
    """Test binary with --version or --help."""
    # Try --version first, then --help
    for flag in ['--version', '--help', '']:
        try:
            cmd = [binary, flag] if flag else [binary]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                output = result.stdout.strip()[:200]
                if not output:
                    output = result.stderr.strip()[:200]
                return True, output
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue
        except Exception:
            continue
    return False, "Cannot execute binary"

def skill_has_binary_dependencies(skill_data):
    """Check if skill has any binary dependencies."""
    deps = skill_data.get('dependencies', {})
    bins = deps.get('bins', [])
    return len(bins) > 0

def run_test(skill_name, skill_data):
    """Run test for a skill, return (success, output, execution_time_ms)."""
    start_time = time.time()
    
    deps = skill_data.get('dependencies', {})
    bins = deps.get('bins', [])
    
    # If skill has binary dependencies, test each one
    if bins:
        for binary in bins:
            # Test existence
            exists, output = test_binary_exists(binary)
            if not exists:
                elapsed = int((time.time() - start_time) * 1000)
                return False, f"Binary not found: {binary}", elapsed
            
            # Test functionality (try to get version/help)
            works, output = test_binary_version(binary)
            if not works:
                elapsed = int((time.time() - start_time) * 1000)
                return False, f"Binary not executable: {binary}", elapsed
        
        # All binaries passed
        elapsed = int((time.time() - start_time) * 1000)
        return True, f"All dependencies verified: {', '.join(bins)}", elapsed
    else:
        # No binary dependencies, verify SKILL.md exists
        location = skill_data.get('location', '').replace('~', os.path.expanduser('~'))
        if os.path.exists(location):
            elapsed = int((time.time() - start_time) * 1000)
            return True, "Skill file exists", elapsed
        else:
            elapsed = int((time.time() - start_time) * 1000)
            return False, f"Skill file not found: {location}", elapsed

def log_usage(skill_name, success, execution_time_ms):
    """Call log_skill_usage.py with execution time."""
    cmd = [sys.executable, str(LOG_USAGE_SCRIPT), skill_name]
    if not success:
        cmd.append('--success')
        cmd.append('false')
    # Add execution time as argument and environment variable
    cmd.extend(['--execution-time-ms', str(execution_time_ms)])
    env = os.environ.copy()
    env['EXECUTION_TIME_MS'] = str(execution_time_ms)
    try:
        subprocess.run(cmd, check=True, capture_output=True, env=env)
    except subprocess.CalledProcessError as e:
        print(f"Warning: Failed to log usage for {skill_name}: {e}")

# Performance metrics are now updated by log_skill_usage.py
# This function kept for compatibility but does nothing
def update_performance_metrics(metadata, skill_name, success, execution_time_ms):
    pass

def main():
    print("Enhanced skill testing framework")
    metadata = load_metadata()
    skills = metadata.get('skills', {})
    
    print(f"Testing {len(skills)} skills...\n")
    
    results = {}
    for skill_name, skill_data in skills.items():
        print(f"Testing {skill_name}...", end=' ')
        success, output, exec_time = run_test(skill_name, skill_data)
        status = 'pass' if success else 'fail'
        print(f"{status} ({exec_time}ms)")
        if output:
            print(f"  Output: {output}")
        
        # Update metadata with test status
        skill_data['test_status'] = status
        skill_data['last_tested'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if not success:
            skill_data['last_test_error'] = output[:500]
        else:
            skill_data.pop('last_test_error', None)
        
        # Update performance metrics
        update_performance_metrics(metadata, skill_name, success, exec_time)
        
        # Log usage (test invocation)
        log_usage(skill_name, success, exec_time)
        
        results[skill_name] = success
    
    # Save updated metadata
    save_metadata(metadata)
    
    # Print summary
    passed = sum(1 for s in results.values() if s)
    total = len(results)
    print(f"\nSummary: {passed}/{total} skills passed")
    
    if passed < total:
        failed = [name for name, ok in results.items() if not ok]
        print(f"Failed: {', '.join(failed)}")
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()