#!/usr/bin/env python3
"""
Delete remaining meta-tasks from DartAI.
"""
import os
import sys
import time
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
try:
    from dartai_client import delete
except ImportError as e:
    print(f"Error importing dartai_client: {e}")
    sys.exit(1)

# IDs captured from previous list
task_ids = [
    'Nb7A8CvuxvgL',  # Primary Responsibility: Reputation Stewardship
    'NBFW5biknk7p',  # Primary Responsibility: Crisis Containment
    'lMuvRA5Cns6w',  # Primary Responsibility: Executive Enablement
    'FS9EJ6vJhnYd',  # Support Ecosystem: Agent Coordination
    'rY3OnWbHHgGH',  # Support Ecosystem: Capability Development
    'mPg43nR0mVRV',  # Support Ecosystem: Security & Risk
    'BFzJT1ieg5a3',  # Support Ecosystem: Automation
    'iorobLHJpZKL',  # Executive Protocols: Core Principles
    'F8IY7FW71Jlh',  # Primary Responsibility: Situational Command
    'Fp66zI0RhVi8',  # Primary Responsibility: Reputation Stewardship
    'UZCsLfSCUfQZ',  # Primary Responsibility: Crisis Containment
    '6cRqrk4w2hbq',  # Primary Responsibility: Executive Enablement
    'yFmv9QNtfQKA',  # Executive Protocols: Core Principles
    'IszAajLXVHsU',  # Executive Protocols: Daily Rhythm
]

def delete_task(task_id, title=''):
    """Delete a task by ID."""
    try:
        result = delete(f'tasks/{task_id}')
        print(f"✓ Deleted: {title} (ID: {task_id})")
        return True
    except Exception as e:
        print(f"✗ Failed to delete {title} (ID: {task_id}): {e}")
        return False

def main():
    print(f"Deleting {len(task_ids)} meta-tasks...")
    deleted = 0
    failed = 0
    
    for i, task_id in enumerate(task_ids):
        # Simple title for logging
        title = f"Meta-task {i+1}"
        success = delete_task(task_id, title)
        if success:
            deleted += 1
        else:
            failed += 1
        time.sleep(0.5)  # Rate limiting
    
    print(f"\nDeletion completed: {deleted} deleted, {failed} failed.")

if __name__ == '__main__':
    main()