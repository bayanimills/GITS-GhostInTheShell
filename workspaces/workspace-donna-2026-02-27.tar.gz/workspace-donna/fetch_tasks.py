#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import get

tasks = get('tasks/list', params={'limit': 50})
print(f"Total tasks: {len(tasks.get('results', []))}")
for i, task in enumerate(tasks.get('results', [])):
    title = task.get('title', 'No title')
    assignee = task.get('assignee', 'Unassigned')
    status = task.get('status', 'N/A')
    due_at = task.get('dueAt', 'N/A')
    print(f"{i}: {title} | {assignee} | {status} | {due_at}")