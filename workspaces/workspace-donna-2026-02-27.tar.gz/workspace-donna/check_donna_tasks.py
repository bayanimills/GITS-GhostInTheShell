#!/usr/bin/env python3
"""
Check what tasks are assigned to Donna.
"""

import os
import sys

# Add DartAI scripts to path
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')

try:
    from dartai_client import get
except ImportError as e:
    print(f"Error importing dartai_client: {e}")
    sys.exit(1)

def fetch_donna_tasks():
    """Fetch tasks assigned to Donna."""
    try:
        # Fetch tasks (limit 100)
        result = get('tasks/list', params={'limit': 100, 'no_defaults': True})
        tasks = result.get('results', [])
        
        donna_tasks = []
        for task in tasks:
            assignee = task.get('assignee', '')
            if assignee == 'Donna':
                donna_tasks.append(task)
        
        print(f"Total tasks: {len(tasks)}")
        print(f"Tasks assigned to Donna: {len(donna_tasks)}")
        
        # Categorize Donna's tasks
        print("\n=== Donna's Tasks ===")
        for task in donna_tasks:
            title = task.get('title', 'No title')
            status = task.get('status', 'No status')
            due = task.get('due', 'No due date')
            tags = task.get('tags', [])
            task_id = task.get('id', 'No ID')
            
            # Check if this looks like executive work or administrative tracking
            is_executive = any(keyword in title.lower() for keyword in [
                'strategic', 'reputation', 'crisis', 'executive', 'leadership',
                'oversight', 'coordination', 'risk', 'governance'
            ])
            
            is_meta = any(pattern in title for pattern in [
                'Skill Registry:', 'Support Ecosystem:', 'Primary Responsibility:',
                'Executive Protocols:', 'Skills Registry'
            ]) or 'skills-registry' in tags
            
            category = "Executive" if is_executive else "Meta/Admin" if is_meta else "Operational"
            
            print(f"- {title}")
            print(f"  Status: {status}, Due: {due}")
            print(f"  Category: {category}")
            print(f"  ID: {task_id}")
            print()
        
        # Summary
        print("\n=== Donna Task Analysis ===")
        print("Donna's role: Executive operator (judgment, situational command, reputation, crisis, enablement)")
        print("Appropriate tasks: Strategic oversight, reputation risks, crisis containment, executive decisions")
        print("Inappropriate tasks: Routine operations, administrative tracking, domain-specific work")
        
        return donna_tasks
        
    except Exception as e:
        print(f"Error fetching tasks: {e}")
        return []

if __name__ == '__main__':
    # Check API key
    if not os.environ.get('DARTAI_API_KEY') and not os.environ.get('DARTAI_SHARED_TOKEN'):
        print("Warning: No DartAI API key found in environment")
    
    fetch_donna_tasks()