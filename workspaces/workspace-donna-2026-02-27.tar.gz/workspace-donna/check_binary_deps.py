#!/usr/bin/env python3
"""
Quick check for binary dependencies.
"""
import json
import subprocess
import sys
from pathlib import Path

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'

def check_binary(binary):
    try:
        result = subprocess.run(['which', binary], capture_output=True, text=True, timeout=2)
        return result.returncode == 0, result.stdout.strip()
    except:
        return False, ""

def main():
    with open(METADATA_PATH) as f:
        data = json.load(f)
    
    skills = data.get('skills', {})
    
    print("Binary Dependency Check")
    print("=" * 60)
    
    missing = {}
    
    for name, skill in skills.items():
        deps = skill.get('dependencies', {})
        bins = deps.get('bins', [])
        
        if not bins:
            continue
        
        for binary in bins:
            exists, loc = check_binary(binary)
            if exists:
                print(f"{name:20} ✅ {binary:15} ({loc})")
            else:
                print(f"{name:20} ❌ {binary:15} (not found)")
                if name not in missing:
                    missing[name] = []
                missing[name].append(binary)
    
    print("\n" + "=" * 60)
    
    if missing:
        print("Missing binaries:")
        for name, bins in missing.items():
            print(f"  {name}: {', '.join(bins)}")
        sys.exit(1)
    else:
        print("✅ All binary dependencies satisfied!")
        sys.exit(0)

if __name__ == '__main__':
    main()