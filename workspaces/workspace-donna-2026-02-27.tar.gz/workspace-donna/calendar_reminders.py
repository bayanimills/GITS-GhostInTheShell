#!/usr/bin/env python3
"""
Calendar reminder script for executive operator.
Fetches Google Calendar events via gog CLI and sends reminders for events starting soon.
Run via cron every 15 minutes.
Sends reminders directly via OpenClaw Telegram message (no agent forwarding).
"""

import os
import sys
import json
import subprocess
from datetime import datetime, timedelta, timezone
import logging

logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
GOG_ACCOUNT = "bayanimills@gmail.com"
REMINDER_WINDOW_MINUTES = 30  # Remind if event starts within this window
REMINDER_EARLY_MINUTES = 15   # Don't remind earlier than this (to avoid duplicate reminders)
STATE_FILE = os.path.join(os.path.dirname(__file__), ".calendar_reminders_state.json")
# Telegram recipient (same as user chat ID)
TELEGRAM_TO = "548072941"

def send_telegram_message(text):
    """Send a message via OpenClaw Telegram plugin."""
    try:
        cmd = ["openclaw", "message", "send", "--channel", "telegram", "--target", TELEGRAM_TO, "--message", text]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            logger.error(f"Failed to send Telegram message: {result.stderr}")
            return False
        logger.info("Telegram message sent successfully")
        return True
    except Exception as e:
        logger.error(f"Exception sending Telegram message: {e}")
        return False

def fetch_upcoming_events(account, hours_ahead=24):
    """Fetch events from now to hours_ahead."""
    try:
        # Use --from now --days 1 to get next 24 hours
        cmd = ["gog", "calendar", "list", "--account", account, "--json", "--from", "now", "--days", "1"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            logger.warning(f"gog calendar failed: {result.stderr}")
            return []
        data = json.loads(result.stdout)
        events = data.get("events", [])
        # Filter confirmed events with dateTime start
        filtered = []
        for event in events:
            if event.get("status") != "confirmed":
                continue
            start = event.get("start", {})
            if "dateTime" not in start:
                continue
            filtered.append(event)
        # Sort by start time
        filtered.sort(key=lambda e: e["start"]["dateTime"])
        return filtered
    except Exception as e:
        logger.warning(f"Failed to fetch calendar events: {e}")
        return []

def parse_iso_datetime(dt_str):
    """Parse ISO datetime string with timezone to aware datetime."""
    # Remove trailing Z and replace with +00:00 if needed
    if dt_str.endswith('Z'):
        dt_str = dt_str[:-1] + '+00:00'
    # Python's fromisoformat handles offset like +11:00
    try:
        return datetime.fromisoformat(dt_str)
    except ValueError:
        # Fallback to naive parsing (strip timezone)
        dt_str = dt_str[:19]
        return datetime.fromisoformat(dt_str).replace(tzinfo=timezone.utc)

def load_state():
    """Load reminded event IDs and last reminder time."""
    if not os.path.exists(STATE_FILE):
        return {}
    try:
        with open(STATE_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Failed to load state: {e}")
        return {}

def save_state(state):
    """Save state to file."""
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        logger.warning(f"Failed to save state: {e}")

def should_remind(event, state):
    """Determine if we should send a reminder for this event."""
    event_id = event.get("id")
    start_str = event["start"]["dateTime"]
    start_dt = parse_iso_datetime(start_str)
    now = datetime.now(start_dt.tzinfo if start_dt.tzinfo else timezone.utc)
    
    # Time until event
    delta = start_dt - now
    delta_minutes = delta.total_seconds() / 60
    
    # Check if within reminder window and not too early
    if delta_minutes > REMINDER_WINDOW_MINUTES or delta_minutes < 0:
        return False
    if delta_minutes > REMINDER_WINDOW_MINUTES - REMINDER_EARLY_MINUTES:
        # Within early window, but check if already reminded
        last_reminded = state.get(event_id)
        if last_reminded:
            # Check if reminded within last 30 minutes
            last_time = datetime.fromisoformat(last_reminded)
            if (now - last_time).total_seconds() < 1800:  # 30 minutes
                return False
        return True
    return False

def format_reminder(event):
    """Format a reminder message for an event."""
    summary = event.get("summary", "No title")
    start = parse_iso_datetime(event["start"]["dateTime"])
    end = parse_iso_datetime(event["end"]["dateTime"])
    location = event.get("location", "")
    
    time_str = f"{start.strftime('%H:%M')}–{end.strftime('%H:%M')}"
    date_str = start.strftime('%a %d %b')
    
    lines = []
    lines.append(f"📅 **Reminder: {summary}**")
    lines.append(f"   ⏰ {date_str} {time_str}")
    if location:
        lines.append(f"   📍 {location}")
    # Add description? maybe not.
    return "\n".join(lines)

def main():
    state = load_state()
    events = fetch_upcoming_events(GOG_ACCOUNT)
    
    reminders = []
    for event in events:
        if should_remind(event, state):
            reminders.append(event)
            # Update state
            state[event["id"]] = datetime.now().isoformat()
    
    if reminders:
        # Combine all reminders into one message
        message_lines = []
        for event in reminders:
            message_lines.append(format_reminder(event))
            message_lines.append("")  # blank line between reminders
        # Remove trailing blank line
        if message_lines and message_lines[-1] == "":
            message_lines.pop()
        message = "\n".join(message_lines)
        
        # Send via Telegram
        success = send_telegram_message(message)
        if success:
            # Save state only if message sent successfully
            save_state(state)
            sys.exit(0)
        else:
            # If sending fails, fallback to stdout (agent will forward)
            # This ensures reminders are not lost if openclaw CLI fails
            print(message)
            save_state(state)
            sys.exit(0)
    else:
        # No reminders needed
        # Do nothing, no output
        logger.info("No upcoming events requiring reminder.")
        sys.exit(0)

if __name__ == "__main__":
    main()