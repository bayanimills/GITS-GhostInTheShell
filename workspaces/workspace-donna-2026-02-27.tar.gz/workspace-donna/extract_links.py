#!/usr/bin/env python3
import subprocess
import json
import re
import sys

def get_email_body(email_id):
    cmd = ['gog', 'gmail', 'messages', 'search', f'label:ToUnsubscribe from:{email_id}', 
           '--account', 'bayanimills@gmail.com', '--json', '--include-body', '--max', '1']
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return None
        data = json.loads(result.stdout)
        if data.get('messages'):
            return data['messages'][0]['body']
    except Exception as e:
        print(f"Exception: {e}", file=sys.stderr)
    return None

def extract_links(html):
    # Simple regex for href values
    hrefs = re.findall(r'href=[\'"]?([^\'" >]+)', html, re.IGNORECASE)
    return hrefs

if __name__ == '__main__':
    # Dune email ID not known, but we can search for dune
    cmd = ['gog', 'gmail', 'messages', 'search', 'label:ToUnsubscribe', 
           '--account', 'bayanimills@gmail.com', '--json', '--include-body', '--max', '10']
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        print("Failed to fetch emails")
        sys.exit(1)
    data = json.loads(result.stdout)
    for msg in data.get('messages', []):
        print(f"\n=== {msg['subject']} ===")
        print(f"From: {msg['from']}")
        body = msg.get('body', '')
        links = extract_links(body)
        print(f"Total links: {len(links)}")
        for link in links[:15]:  # show first 15
            if 'unsubscribe' in link.lower() or 'opt' in link.lower() or 'preference' in link.lower():
                print(f"  🔗 {link}")
            else:
                print(f"  {link}")