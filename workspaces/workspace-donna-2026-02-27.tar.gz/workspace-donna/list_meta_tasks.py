#!/usr/bin/env python3
"""
List meta-tasks in DartAI for review before deletion.
"""
import os
import sys
import re
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
try:
    from dartai_client import get
except ImportError as e:
    print(f"Error importing dartai_client: {e}")
    sys.exit(1)

def fetch_all_tasks(limit=200):
    """Fetch tasks with pagination."""
    all_tasks = []
    offset = 0
    batch_size = min(50, limit)
    
    while len(all_tasks) < limit:
        params = {
            'limit': batch_size,
            'offset': offset,
            'no_defaults': True
        }
        
        try:
            result = get('tasks/list', params=params)
            tasks = result.get('results', [])
            if not tasks:
                break
            all_tasks.extend(tasks)
            offset += len(tasks)
            if not result.get('next') or len(all_tasks) >= limit:
                break
        except Exception as e:
            print(f"Error fetching tasks: {e}")
            break
    
    return all_tasks[:limit]

def is_meta_task(task):
    """Check if task is a meta-tracking entry."""
    title = task.get('title', '')
    tags = task.get('tags', [])
    
    meta_patterns = [
        r'^Skill Registry:',
        r'^Support Ecosystem:',
        r'^Primary Responsibility:',
        r'^Executive Protocols:',
        r'^Skills Registry – Master Index$'
    ]
    
    for pattern in meta_patterns:
        if re.search(pattern, title, re.IGNORECASE):
            return True
    
    if 'skills-registry' in tags:
        return True
    
    return False

def main():
    print("Fetching tasks from DartAI...")
    tasks = fetch_all_tasks(limit=200)
    print(f"Total tasks: {len(tasks)}")
    
    meta_tasks = [t for t in tasks if is_meta_task(t)]
    print(f"Meta-tasks found: {len(meta_tasks)}")
    
    for i, task in enumerate(meta_tasks):
        title = task.get('title', 'No title')
        task_id = task.get('id', 'N/A')
        assignee = task.get('assignee', 'Unassigned')
        status = task.get('status', 'N/A')
        tags = task.get('tags', [])
        print(f"{i+1}. {title}")
        print(f"   ID: {task_id}, Assignee: {assignee}, Status: {status}, Tags: {tags}")
        print()

if __name__ == '__main__':
    main()