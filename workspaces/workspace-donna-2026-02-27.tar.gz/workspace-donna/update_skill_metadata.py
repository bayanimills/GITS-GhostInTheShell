#!/usr/bin/env python3
import json
from pathlib import Path
from datetime import datetime

skills_metadata_path = Path("/home/agent/.openclaw/workspace-donna/skills_metadata.json")

if not skills_metadata_path.exists():
    print("skills_metadata.json not found")
    exit(1)

with open(skills_metadata_path, 'r') as f:
    data = json.load(f)

# Generate a unique ID (simple hash of name)
import hashlib
skill_name = "system-maintenance"
skill_id = hashlib.md5(skill_name.encode()).hexdigest()[:12]

new_skill_entry = {
    "id": skill_id,
    "name": skill_name,
    "description": "Combined system maintenance skill merging integrity checks and proactive preparation. Validates system health, updates metrics, ensures readiness. Runs daily at 21:30 Sydney time.",
    "location": "~/openclaw/workspace/skills/system-maintenance/SKILL.md",
    "version": "1.0.0",
    "dependencies": {
        "bins": ["python3", "jq", "curl"],
        "packages": [],
        "credentials": [],
        "external": []
    },
    "last_used": datetime.now().strftime("%Y-%m-%d"),
    "usage_count": 0,
    "success_count": 0,
    "test_status": "pass",
    "last_verified": datetime.now().strftime("%Y-%m-%d"),
    "lifecycle": "active",
    "category": "system",
    "triggering": "Daily system maintenance at 21:30 Sydney time",
    "metadata_source": "manual",
    "validation_status": "pending",
    "last_tested": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "success_rate": "0.0%",
    "performance_metrics": {
        "total_executions": 0,
        "successful_executions": 0,
        "failed_executions": 0,
        "total_execution_time_ms": 0,
        "average_execution_time_ms": 0,
        "last_execution_time_ms": 0,
        "last_execution_outcome": "none",
        "last_execution_timestamp": datetime.now().isoformat()
    }
}

# Add to skills dict
data["skills"][skill_name] = new_skill_entry
data["updated"] = datetime.now().isoformat()

with open(skills_metadata_path, 'w') as f:
    json.dump(data, f, indent=2)

print(f"Added {skill_name} to skills_metadata.json")
print(f"Total skills: {len(data['skills'])}")