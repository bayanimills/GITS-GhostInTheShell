#!/usr/bin/env python3
"""
Delete meta-tasks from DartAI.
"""
import os
import sys
import re
import time
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
try:
    from dartai_client import get, delete
except ImportError as e:
    print(f"Error importing dartai_client: {e}")
    sys.exit(1)

def fetch_all_tasks(limit=200):
    """Fetch tasks with pagination."""
    all_tasks = []
    offset = 0
    batch_size = min(50, limit)
    
    while len(all_tasks) < limit:
        params = {
            'limit': batch_size,
            'offset': offset,
            'no_defaults': True
        }
        
        try:
            result = get('tasks/list', params=params)
            tasks = result.get('results', [])
            if not tasks:
                break
            all_tasks.extend(tasks)
            offset += len(tasks)
            if not result.get('next') or len(all_tasks) >= limit:
                break
        except Exception as e:
            print(f"Error fetching tasks: {e}")
            break
    
    return all_tasks[:limit]

def is_meta_task(task):
    """Check if task is a meta-tracking entry."""
    title = task.get('title', '')
    tags = task.get('tags', [])
    
    meta_patterns = [
        r'^Skill Registry:',
        r'^Support Ecosystem:',
        r'^Primary Responsibility:',
        r'^Executive Protocols:',
        r'^Skills Registry – Master Index$'
    ]
    
    for pattern in meta_patterns:
        if re.search(pattern, title, re.IGNORECASE):
            return True
    
    if 'skills-registry' in tags:
        return True
    
    return False

def delete_task(task_id, title):
    """Delete a task by ID."""
    try:
        # Assuming endpoint is 'tasks/{id}'
        result = delete(f'tasks/{task_id}')
        print(f"Deleted: {title} (ID: {task_id})")
        return True
    except Exception as e:
        print(f"Failed to delete {title} (ID: {task_id}): {e}")
        return False

def main():
    print("Fetching tasks from DartAI...")
    tasks = fetch_all_tasks(limit=200)
    print(f"Total tasks: {len(tasks)}")
    
    meta_tasks = [t for t in tasks if is_meta_task(t)]
    print(f"Meta-tasks found: {len(meta_tasks)}")
    
    if not meta_tasks:
        print("No meta-tasks to delete.")
        return
    
    print("\nMeta-tasks to delete:")
    for i, task in enumerate(meta_tasks):
        title = task.get('title', 'No title')
        task_id = task.get('id', 'N/A')
        assignee = task.get('assignee', 'Unassigned')
        status = task.get('status', 'N/A')
        print(f"{i+1}. {title} (ID: {task_id}, Assignee: {assignee}, Status: {status})")
    
    # Ask for confirmation
    response = input("\nProceed with deletion? (yes/no): ").strip().lower()
    if response not in ('yes', 'y'):
        print("Deletion cancelled.")
        return
    
    print("\nDeleting meta-tasks...")
    deleted = 0
    failed = 0
    
    for task in meta_tasks:
        task_id = task.get('id')
        title = task.get('title', 'No title')
        if task_id and task_id != 'N/A':
            success = delete_task(task_id, title)
            if success:
                deleted += 1
            else:
                failed += 1
            time.sleep(0.5)  # Rate limiting
    
    print(f"\nDeletion completed: {deleted} deleted, {failed} failed.")

if __name__ == '__main__':
    main()