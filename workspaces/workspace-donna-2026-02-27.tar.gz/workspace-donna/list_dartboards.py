#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace/skills/dartai/scripts')
from dartai_client import get

try:
    config = get('config')
    print('=== Dartboards ===')
    for db in config.get('dartboards', []):
        print(f"ID: {db['id']}, Title: {db.get('title', 'N/A')}, Path: {db.get('path', 'N/A')}")
    print('\n=== Statuses ===')
    for st in config.get('statuses', []):
        print(f"ID: {st['id']}, Title: {st.get('title', 'N/A')}")
    print('\n=== Assignees ===')
    for asn in config.get('assignees', []):
        print(f"ID: {asn['id']}, Name: {asn.get('name', 'N/A')}")
except Exception as e:
    print(f'Error: {e}')