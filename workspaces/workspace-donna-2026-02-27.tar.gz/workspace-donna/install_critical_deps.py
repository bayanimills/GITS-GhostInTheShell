#!/usr/bin/env python3
"""
Install critical missing dependencies for skills.
Safe with dry-run mode and confirmation prompts.
"""
import subprocess
import sys
import json
from pathlib import Path

METADATA_PATH = Path(__file__).parent / 'skills_metadata.json'

def run_command(cmd, timeout=30):
    """Run command with timeout."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout.strip(), result.stderr.strip()
    except subprocess.TimeoutExpired:
        return False, "", f"Command timed out: {' '.join(cmd)}"
    except Exception as e:
        return False, "", str(e)

def check_binary_exists(binary):
    """Check if binary exists in PATH."""
    ok, stdout, stderr = run_command(['which', binary], timeout=5)
    return ok

def brew_formula_exists(formula):
    """Check if Homebrew formula exists."""
    ok, stdout, stderr = run_command(['brew', 'info', formula], timeout=10)
    return ok and 'Not installed' not in stdout  # Formula exists even if not installed

def install_brew_formula(formula):
    """Install Homebrew formula."""
    print(f"  Installing {formula} via Homebrew...")
    ok, stdout, stderr = run_command(['brew', 'install', formula], timeout=120)
    if ok:
        print(f"  ✅ {formula} installed successfully")
    else:
        print(f"  ❌ Failed to install {formula}: {stderr}")
    return ok

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Install critical skill dependencies')
    parser.add_argument('--dry-run', action='store_true', help='Show what would be installed')
    parser.add_argument('--yes', action='store_true', help='Skip confirmation prompts')
    parser.add_argument('--formulas', nargs='+', help='Specific formulas to install')
    args = parser.parse_args()
    
    # Critical dependencies (skill name -> binary -> brew formula)
    critical_deps = {
        '1password': {'binary': 'op', 'formula': '1password-cli', 'priority': 1},
        'media skills': {'binary': 'ffmpeg', 'formula': 'ffmpeg', 'priority': 1},
        'gemini': {'binary': 'gemini', 'formula': 'gemini', 'priority': 2},
        'himalaya': {'binary': 'himalaya', 'formula': 'himalaya', 'priority': 2},
        # Note: memo doesn't seem to have a brew formula
    }
    
    # Load metadata to check which skills are actually used
    try:
        with open(METADATA_PATH) as f:
            metadata = json.load(f)
        skills = metadata.get('skills', {})
    except:
        skills = {}
    
    print("Critical Dependency Installation")
    print("=" * 60)
    
    # Determine what to install
    to_install = []
    
    for skill_name, dep_info in critical_deps.items():
        binary = dep_info['binary']
        formula = dep_info['formula']
        priority = dep_info['priority']
        
        # Check if binary already exists
        if check_binary_exists(binary):
            print(f"✅ {binary} already installed")
            continue
        
        # Check if formula exists
        if brew_formula_exists(formula):
            print(f"📦 {formula} available via Homebrew (priority {priority})")
            to_install.append((formula, priority, binary, skill_name))
        else:
            print(f"⚠️  {formula} not available via Homebrew")
    
    if not to_install:
        print("\n✅ All critical dependencies are already installed!")
        return
    
    # Sort by priority (lower number = higher priority)
    to_install.sort(key=lambda x: x[1])
    
    print(f"\nWould install {len(to_install)} formulas:")
    for formula, priority, binary, skill_name in to_install:
        print(f"  {formula} (for {binary}, used by {skill_name}, priority {priority})")
    
    if args.dry_run:
        print("\nDry run complete - no changes made.")
        return
    
    if not args.yes:
        response = input("\nProceed with installation? (y/N): ")
        if response.lower() not in ['y', 'yes']:
            print("Installation cancelled.")
            return
    
    # Install
    print("\nInstalling dependencies...")
    installed = []
    failed = []
    
    for formula, priority, binary, skill_name in to_install:
        if install_brew_formula(formula):
            installed.append(formula)
        else:
            failed.append(formula)
    
    # Summary
    print("\n" + "=" * 60)
    print("Installation Summary:")
    print(f"✅ Installed: {len(installed)} formulas")
    if installed:
        print(f"   {', '.join(installed)}")
    print(f"❌ Failed: {len(failed)} formulas")
    if failed:
        print(f"   {', '.join(failed)}")
    
    if failed:
        sys.exit(1)
    else:
        print("\n✅ Installation complete!")
        sys.exit(0)

if __name__ == '__main__':
    main()