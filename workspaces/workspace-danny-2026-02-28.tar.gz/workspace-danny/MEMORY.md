# MEMORY.md - Quick Reference

## Active Projects
- **Danny workspace setup** – memory framework established, daily logs operational
- **Polymarket trading automation** – AI Divergence Scanner and Mert Sniper deployed
- **Cron job monitoring** – real-time execution tracking with quiet hours enforcement
- **Counter‑position strategy implementation** – Mert Sniper counter‑bot deployed (underdog ≤40%, $1 positions, A/B test)

## Recent Decisions
- **Quiet hours (23:00‑07:00)** implemented across all trading scripts – suppress non‑trade output
- **AI Divergence Scanner** configured with 10% threshold, 30‑min scans, Telegram announcements
- **Mert Sniper** configured with 65% conviction threshold, 10‑min scans, smart sizing (5% of balance)
- **Log‑first verification** – all cron job updates verified against actual log files before delivery
- **Simmer skill alignment** (2026‑02‑27) – All trading scripts updated with briefing‑check pattern (risk‑alert gate, venue‑specific formatting)
- **Threshold adjustments** (2026‑02‑27) – AI Divergence threshold lowered to 8%, Mert Sniper conviction threshold lowered to 60% for more opportunities
- **Counter‑bot deployment** (2026‑02‑27) – Mert Sniper Counter (underdog ≤40%) scheduled every 10 minutes for A/B testing with $1 position sizes
- **Recommendations implemented** (2026‑02‑27) – Counter‑bot active, original Mert Sniper not scheduled, thresholds lowered (AI Divergence 8%, Mert Sniper 60%), A/B test started
- **Counter‑position strategy validated** – Mathematical proof that betting opposite side of Mert Sniper would be profitable (58% win rate vs 35% required)
- **Agent timeout increased** – `agents.defaults.timeoutSeconds` set to 1800 seconds per user request
- **Systematic reporting framework deployed** – Parser, daily report script, and scheduled 8am/8pm Gateway cron job for automated outcome reporting
- **Max bet increased** (2026‑02‑27) – Counter‑bot max bet raised from $2 to $5 to overcome minimum share constraints
- **Order type updated** (2026‑02‑27) – Changed from FAK to GTC with 0.5% price tolerance to improve fill rate for illiquid underdog markets

## User Preferences (Updated 2026‑02‑23)
- **Reporting protocol:** Only notify when positions are taken (trades executed)
- **Do NOT report:** Routine Mert Sniper scan outcomes or AI Divergence updates unless they result in a position
- **Continue with:** 8am & 8pm overviews including position status and expected returns

## Trading Insights (2026‑02‑23)
- **Weather markets** showed highest divergence (±32%) early morning but dropped below threshold by 09:09
- **Election markets** (Nepal Congress) provided stable medium‑conviction opportunities (+11‑17%)
- **New opportunities emerged:** Elon Musk tweet‑count markets (±20%/13.6%), Netflix show (+20%)
- **Near‑expiry conviction trading** requires ≥65% split – markets remained balanced (46‑54% splits)
- **Order execution issues** encountered: decimal precision errors, liquidity gaps in order books
- **Significant trading activity:** 20 trades executed via other strategies/manual trading
- **Portfolio volatility:** Balance dropped from $162.24 to $82.90 by evening, exposure fluctuated $0‑$108
- **Current status (21:58):** $82.90 balance, $108.29 exposure (9 positions) – high‑risk leveraged state

## Trading Insights (2026‑02‑27)
- **Simmer skill alignment completed**: All trading scripts updated with briefing‑check pattern (risk‑alert gate, venue‑specific formatting)
- **Portfolio clean**: 0 active USDC positions, all 28 trades resolved, $164.91 USDC balance, +$2.78 net PnL
- **API inconsistency identified**: Portfolio endpoint reports `positions_count:5` but returns empty positions array
- **Trade attribution**: All 26 executed trades from Mert Sniper (AI Divergence & FastLoop bots active but zero executions)
- **Mert Sniper performance**: 42% win rate (11/26) on favorites (≥65% price) – below required 65% threshold → losing strategy
- **Counter‑position opportunity**: Betting opposite side (underdogs ≤35%) would yield 58% win rate → profitable edge
- **Active cron jobs for counter‑targeting**: Weather Trader (2‑min), AI Divergence Scanner (30‑min), FastLoop BTC (5‑min)
- **Threshold adjustments implemented**: AI Divergence threshold lowered to 8%, Mert Sniper conviction lowered to 60% (both original and counter‑bot)
- **Expired trades resolved**: Ethereum Feb 22 and Royce O’Neale positions identified as losses (already processed)
- **Counter‑bot deployed**: Mert Sniper Counter (underdog ≤40%) scheduled every 10 minutes with $1 positions for A/B test

## Action Items
- **Counter‑position implementation** – ✅ **Completed**: Mert Sniper counter‑bot built and scheduled (underdog ≤40%, $1 positions, every 10 minutes)
- **Bot threshold tuning** – ✅ **Completed**: AI Divergence threshold lowered to 8%, Mert Sniper conviction lowered to 60% (both original and counter‑bot)
- **API inconsistency investigation** – ✅ **Completed**: Discrepancy due to resolved vs open positions; no action needed
- **Simmer SDK monitoring** – **Ongoing**: Watch for `skill_slug` parameter support in future SDK releases
- **Live A/B test** – **In progress**: Counter‑bot vs original Mert Sniper with $1 positions, 48‑hour data collection; reporting framework now tracks metrics.
- **Systematic reporting framework** – ✅ **Completed**: Parser, daily report, scheduled cron jobs for 8am/8pm automated reporting.
- **Cross‑platform arbitrage exploration** – **Pending**: Research Kalshi/PredictIt API setup for cross‑market opportunities

## Notes
- Created by maintenance review on 2026-02-21.
- Updated with trading operations insights on 2026-02-23.
- 8pm overview delivered late (00:16 AM Feb 24) – portfolio leveraged at $82.90 balance, $108.29 exposure.
- Updated with Simmer alignment and counter‑position analysis on 2026-02-27.
