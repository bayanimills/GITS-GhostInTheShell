#!/usr/bin/env python3
import os
import json
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-danny/.venv/lib/python3.12/site-packages')

from simmer_sdk import SimmerClient

api_key = os.environ.get("SIMMER_API_KEY")
if not api_key:
    api_key = open(".openclaw/secrets.env").read().strip()
    for line in api_key.splitlines():
        if line.startswith("SIMMER_API_KEY="):
            api_key = line.split("=",1)[1].strip()
            break

client = SimmerClient(api_key=api_key, venue="polymarket")

print("Fetching positions...")
try:
    positions = client.get_positions()
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)

print(f"Total positions: {len(positions)}")
for i, pos in enumerate(positions):
    print(f"\n--- Position {i+1} ---")
    print(json.dumps(pos, indent=2))

# Search for specific markets
search_terms = ["Ethereum Up or Down", "Royce O'Neale"]
for term in search_terms:
    print(f"\nSearching for '{term}':")
    matches = [p for p in positions if term in p.get('market_question', '')]
    for m in matches:
        print(f"  Market: {m.get('market_question')}")
        print(f"    Side: {m.get('side')}, Shares: {m.get('shares')}, Avg Price: {m.get('avg_price')}")
        print(f"    Status: {m.get('status')}, PnL: {m.get('realized_pnl')}")