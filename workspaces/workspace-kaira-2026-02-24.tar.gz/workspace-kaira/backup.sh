#!/bin/bash
# Kaira Workspace Backup Script
# Version: 1.0.0

set -euo pipefail

# Configuration
WORKSPACE="/home/agent/.openclaw/workspace-kaira"
LOG_FILE="$WORKSPACE/memory/backup-$(date +%Y-%m-%d).md"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date +'%Y-%m-%d %H:%M:%S') - $1"
    echo "- $(date +'%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date +'%Y-%m-%d %H:%M:%S') - $1"
    echo "- $(date +'%Y-%m-%d %H:%M:%S') - ERROR: $1" >> "$LOG_FILE"
}

# Create log directory if needed
mkdir -p "$(dirname "$LOG_FILE")"

# Start backup
log_info "Starting Kaira workspace backup"

# Check if in git repository
cd "$WORKSPACE"
if [ ! -d ".git" ]; then
    log_error "Not a git repository. Initializing..."
    git init
    git add .
    git commit -m "Initial commit: Kaira workspace"
fi

# Check for changes
if git diff --quiet && git diff --cached --quiet; then
    log_info "No changes to commit"
else
    # Add all changes
    git add .
    
    # Commit with timestamp
    COMMIT_MSG="Backup: $(date +'%Y-%m-%d %H:%M:%S')"
    git commit -m "$COMMIT_MSG"
    
    log_info "Committed changes: $COMMIT_MSG"
    
    # Show commit stats
    COMMIT_HASH=$(git rev-parse --short HEAD)
    FILES_CHANGED=$(git diff --name-only HEAD~1 HEAD 2>/dev/null | wc -l)
    log_info "Commit $COMMIT_HASH: $FILES_CHANGED files changed"
fi

# Check git status
log_info "Git status:"
git status --short

# Backup complete
log_info "Backup complete"

# Summary
echo "" >> "$LOG_FILE"
echo "## Backup Summary - $(date +'%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo "- Workspace: $WORKSPACE" >> "$LOG_FILE"
echo "- Files tracked: $(find . -name "*.md" -type f | wc -l)" >> "$LOG_FILE"
echo "- Memory files: $(find memory -name "*.md" -type f | wc -l)" >> "$LOG_FILE"
echo "- Last commit: $(git log -1 --oneline 2>/dev/null || echo 'No commits')" >> "$LOG_FILE"

exit 0