#!/usr/bin/env python3
import sys

def main():
    with open('bootstrap-agent.sh', 'r') as f:
        lines = f.readlines()
    
    # Find start and end of the workspace script validation block
    start = None
    for i, line in enumerate(lines):
        if '# 2.6 Workspace script validation' in line:
            start = i
            break
    
    if start is None:
        print("Could not find workspace script validation section")
        sys.exit(1)
    
    # Find the next empty line after the block? Actually find the line before SECTION 3
    # Look for '# ============================================================================'
    end = None
    for i in range(start, len(lines)):
        if '# ============================================================================' in lines[i] and 'SECTION 3' in lines[i+1]:
            end = i - 1  # line before the separator
            break
    
    if end is None:
        print("Could not find end of section")
        sys.exit(1)
    
    print(f"Replacing lines {start+1} to {end+1}")
    
    # New block
    new_block = '''# 2.6 Workspace script validation
log_info "Testing workspace script validation..."
if [ -f "$DEFAULT_WORKSPACE/backup.sh" ]; then
    # Check if backup.sh is executable
    if [ -x "$DEFAULT_WORKSPACE/backup.sh" ]; then
        log_test 0 "Backup script is executable"
    else
        log_warn "Backup script exists but is not executable"
        log_skip "Backup script execution"
    fi
else
    log_skip "Backup script not found (optional)"
fi

# 2.7 Cron job configuration
log_info "Checking cron job configuration..."
if command -v openclaw >/dev/null 2>&1; then
    openclaw cron list 2>/dev/null | grep -q "$AGENT_ID"
    if [ $? -eq 0 ]; then
        log_test 0 "Cron jobs found for agent $AGENT_ID"
    else
        log_warn "No cron jobs found for agent $AGENT_ID (consider setting up autonomous workflows)"
        log_skip "Cron job configuration"
    fi
else
    log_skip "OpenClaw CLI not available for cron check"
fi
'''
    
    # Replace
    lines[start:end+1] = [new_block]
    
    with open('bootstrap-agent.sh', 'w') as f:
        f.writelines(lines)
    
    print("Added cron job configuration test")

if __name__ == '__main__':
    main()