def load_telegram_config() -> Dict:
    """Load Telegram status configuration from JSON file."""
    config_path = WORKSPACE / "aws-telegram-status.json"
    default_config = {
        "enable_telegram_status": False,
        "chat_id": "548072941",
        "message_id": None,
        "last_updated": None,
        "last_summary_hash": None,
        "update_interval_minutes": 30
    }
    
    if not config_path.exists():
        return default_config
    
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        # Ensure all required keys exist
        for key, value in default_config.items():
            if key not in config:
                config[key] = value
        return config
    except Exception as e:
        logger.warning(f"Failed to load Telegram config: {e}")
        return default_config

def save_telegram_config(config: Dict):
    """Save Telegram status configuration."""
    config_path = WORKSPACE / "aws-telegram-status.json"
    try:
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        logger.warning(f"Failed to save Telegram config: {e}")

def get_active_subagents() -> List[Dict]:
    """Get list of sub‑agents spawned by this agent."""
    try:
        result = subprocess.run(
            ['openclaw', 'subagents', 'list'],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode != 0:
            logger.debug(f"subagents list failed: {result.stderr}")
            return []
        
        # Parse output - simple approach: look for lines with labels
        subagents = []
        for line in result.stdout.split('\n'):
            if 'label:' in line.lower():
                # Extract label
                parts = line.split(':')
                if len(parts) >= 2:
                    label = parts[1].strip()
                    subagents.append({'label': label, 'status': 'running'})
        return subagents
    except Exception as e:
        logger.debug(f"Error getting subagents: {e}")
        return []

def build_status_content(summary: Dict, tasks: List[Dict], completed_tasks: List[Dict], active_subagents: List[Dict]) -> str:
    """Build formatted Telegram message with bullet lists."""
    now = datetime.datetime.now()
    time_str = now.strftime("%Y-%m-%d %H:%M %Z")
    
    # Determine greeting based on presence
    greeting = "I've not heard from you, so in the meantime I am going to refer to my list of tasks."
    # If there are completed tasks, switch to past tense
    if completed_tasks:
        greeting = "While you have been away, I have completed:"
    
    # Build completed tasks list
    completed_lines = []
    for task in completed_tasks[-5:]:  # Show last 5 completed
        header = task.get('header', 'Unknown')
        # Remove priority prefix if present
        header = re.sub(r'^(High|Medium|Low)\s+', '', header)
        completed_lines.append(f"✅ {header}")
    
    # Build current tasks (pending tasks that match permission)
    current_lines = []
    for task in tasks:
        status = task.get('Status', '').lower()
        if status == 'pending':
            header = task.get('header', 'Unknown')
            header = re.sub(r'^(High|Medium|Low)\s+', '', header)
            current_lines.append(f"🔄 {header}")
            break  # Only show one current task
    
    # Build sub-agents list
    subagent_lines = []
    for sub in active_subagents:
        label = sub.get('label', 'Unknown')
        subagent_lines.append(f"🔄 {label}")
    
    if not subagent_lines:
        subagent_lines.append("🔍 No sub‑agents currently running")
    
    # Calculate next check time (30 minutes from now)
    next_check = now + datetime.timedelta(minutes=30)
    next_str = next_check.strftime("%H:%M %Z")
    
    # Build message
    lines = [
        f"🤖 **AWS v2.0 Status Report**  ",
        f"*Last updated: {time_str}*  ",
        f"",
        f"**{greeting}**  ",
        f""
    ]
    
    if completed_lines:
        lines.append("**Completed since last update:**  ")
        lines.extend(completed_lines)
        lines.append("")
    
    if current_lines:
        lines.append("**Currently working on:**  ")
        lines.extend(current_lines)
        lines.append("")
    
    lines.append("**Sub‑agents active:**  ")
    lines.extend(subagent_lines)
    lines.append("")
    
    lines.append(f"**Next check**: {next_str}  ")
    lines.append("*Status updates via message edit – no new messages*")
    
    return '\n'.join(lines)

def send_or_update_status_message(config: Dict, content: str) -> Dict:
    """Send new message or edit existing one via message tool."""
    if not config.get("enable_telegram_status"):
        return {'success': False, 'error': 'Telegram status disabled'}
    
    chat_id = config.get("chat_id")
    if not chat_id:
        return {'success': False, 'error': 'No chat_id configured'}
    
    # Compute hash of content to avoid unnecessary edits
    content_hash = hashlib.md5(content.encode()).hexdigest()
    if config.get("last_summary_hash") == content_hash:
        logger.debug("Status unchanged, skipping Telegram update")
        return {'success': True, 'action': 'skipped', 'message_id': config.get("message_id")}
    
    message_id = config.get("message_id")
    
    try:
        if message_id:
            # Edit existing message
            result = subprocess.run(
                ['openclaw', 'message', 'edit', '--to', chat_id, '--message-id', message_id, '--message', content],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                logger.info(f"Telegram message {message_id} updated")
                return {'success': True, 'action': 'edited', 'message_id': message_id}
            else:
                # Message may have been deleted, fall back to send
                logger.warning(f"Edit failed, sending new message: {result.stderr}")
                message_id = None
        
        if not message_id:
            # Send new message
            result = subprocess.run(
                ['openclaw', 'message', 'send', '--to', chat_id, '--message', content],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                # Parse output to get message_id
                output = result.stdout.strip()
                # Expected JSON output: {"ok": true, "messageId": "...", "chatId": "..."}
                try:
                    data = json.loads(output)
                    new_message_id = data.get("messageId")
                    if new_message_id:
                        logger.info(f"Telegram message {new_message_id} created")
                        return {'success': True, 'action': 'sent', 'message_id': new_message_id}
                except:
                    # Fallback: extract from text
                    logger.warning(f"Could not parse messageId from output: {output}")
                    return {'success': True, 'action': 'sent', 'message_id': 'unknown'}
            else:
                logger.error(f"Failed to send Telegram message: {result.stderr}")
                return {'success': False, 'error': result.stderr}
    
    except Exception as e:
        logger.error(f"Telegram communication error: {e}")
        return {'success': False, 'error': str(e)}
    
    return {'success': False, 'error': 'Unexpected state'}