#!/usr/bin/env python3
import sys

with open('bootstrap-agent.sh', 'r') as f:
    content = f.read()

# Find the start index
start = content.find('# 2.6 Workspace script validation\n')
if start == -1:
    sys.exit(1)

# Find the end index: the line before '# ============================================================================'
# We'll search for '\n# ============================================================================\n' after start
end = content.find('\n# ============================================================================', start)
if end == -1:
    sys.exit(1)

old_text = content[start:end]  # up to but not including the newline before separator
print('---OLD TEXT START---')
print(repr(old_text))
print('---OLD TEXT END---')

# Also print length
print(f'Length: {len(old_text)}')
print(f'Lines: {old_text.count(chr(10))}')