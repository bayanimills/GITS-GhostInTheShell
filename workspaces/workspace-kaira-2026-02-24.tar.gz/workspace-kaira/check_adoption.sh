#!/bin/bash
# Natural adoption test checker - run at 18:00 Feb 22 2026
# Compares agent WORKFLOW_AUTO.md files against template

TEMPLATE="/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md"
TEMPLATE_TS="2026-02-22 11:19"
echo "=== NATURAL ADOPTION TEST STATUS ==="
echo "Check time: $(date)"
echo "Template: $TEMPLATE (modified: $TEMPLATE_TS)"
echo ""

echo "Agent Status:"
echo "------------"

for agent in aria shelley donna doc danny kaira; do
    FILE="/home/agent/.openclaw/workspace-$agent/WORKFLOW_AUTO.md"
    if [ -f "$FILE" ]; then
        MOD_TIME=$(stat -c "%y" "$FILE" 2>/dev/null | cut -d'.' -f1)
        SIZE=$(stat -c "%s" "$FILE" 2>/dev/null)
        # Check if modified after template
        if [[ "$MOD_TIME" > "2026-02-22 11:19" ]]; then
            STATUS="✅ UPDATED"
        else
            STATUS="⚠️  OLD"
        fi
        echo "$agent: $STATUS | Size: $SIZE bytes | Modified: $MOD_TIME"
    else
        echo "$agent: ❌ NO FILE"
    fi
done

echo ""
echo "=== CONTENT SAMPLE CHECK ==="
echo "Checking for autonomous tasks framework adoption..."

# Quick grep for key phrases in each file
for agent in aria shelley donna doc; do
    FILE="/home/agent/.openclaw/workspace-$agent/WORKFLOW_AUTO.md"
    if [ -f "$FILE" ]; then
        AUTONOMOUS=$(grep -i "autonomous" "$FILE" | wc -l)
        PRE_COMPACTION=$(grep -i "pre.compaction\|pre-compaction\|pre compaction" "$FILE" | wc -l)
        FRAMEWORK=$(grep -i "framework" "$FILE" | wc -l)
        echo "$agent: autonomous=$AUTONOMOUS pre-compaction=$PRE_COMPACTION framework=$FRAMEWORK"
    fi
done

echo ""
echo "=== RECOMMENDATIONS ==="
echo "1. Files modified after $TEMPLATE_TS likely adopted new template"
echo "2. Files with 'autonomous' or 'pre-compaction' mentions likely updated"
echo "3. No file = will read template during next audit"