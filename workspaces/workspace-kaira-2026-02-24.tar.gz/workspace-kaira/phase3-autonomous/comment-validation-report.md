# Comment Framework Validation Report

Generated: comment-validation.py on Mon Feb 23 14:36:47 AEDT 2026

## SOUL.md
**Missing templates**: FILE Context Header


## Suggestions for SOUL.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
## USER.md
**Missing templates**: FILE Context Header


## Suggestions for USER.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
## IDENTITY.md
**Missing templates**: FILE Context Header


## Suggestions for IDENTITY.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
## WORKFLOW_AUTO.md
**Missing templates**: FILE Context Header, DECISION Documentation


## Suggestions for WORKFLOW_AUTO.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
```markdown
<!-- DECISION [DATE]: [Decision title]
CONTEXT: [Why decision needed]
ALTERNATIVES CONSIDERED:
  [Alternative 1]
  [Alternative 2]  
DECISION: [Chosen approach]
RATIONALE: [Why chosen]
EXPIRES: [When decision should be re-evaluated]
-->
```
## HEARTBEAT.md
**Missing templates**: FILE Context Header


## Suggestions for HEARTBEAT.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
## AGENTS.md
**Missing templates**: FILE Context Header


## Suggestions for AGENTS.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
## TOOLS.md
**Missing templates**: FILE Context Header


## Suggestions for TOOLS.md
```markdown
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->
```
## MEMORY.md
**Missing templates**: AGENT-GUIDANCE Block


## Suggestions for MEMORY.md
```markdown
<!-- AGENT-GUIDANCE: [For whom]
ACTION: [What to do]
CONTEXT: [Why important]
QUALITY CRITERIA: [How to know it's done well]
CONTACT: [Who to ask]
-->
```
## memory/2026-02-23.md
**Missing templates**: AGENT-GUIDANCE Block


## Suggestions for 2026-02-23.md
```markdown
<!-- AGENT-GUIDANCE: [For whom]
ACTION: [What to do]
CONTEXT: [Why important]
QUALITY CRITERIA: [How to know it's done well]
CONTACT: [Who to ask]
-->
```
## phase3-autonomous/DESIGN.md
**Missing templates**: DECISION Documentation


## Suggestions for DESIGN.md
```markdown
<!-- DECISION [DATE]: [Decision title]
CONTEXT: [Why decision needed]
ALTERNATIVES CONSIDERED:
  [Alternative 1]
  [Alternative 2]  
DECISION: [Chosen approach]
RATIONALE: [Why chosen]
EXPIRES: [When decision should be re-evaluated]
-->
```
