<!-- 
FILE: phase3-autonomous/DESIGN.md
PURPOSE: Design document for Phase 3 - Unified Autonomous Workflow System
OWNER: Kaira (Delegation Agent) - Phase 3 Prototype
UPDATE CADENCE: During implementation (daily), then weekly
READ ME WHEN:
  - Understanding Phase 3 architecture
  - Modifying any Phase 3 component
  - Extending autonomous capabilities
LAST REVIEW: 2026-02-23 (Kaira)
NEXT REVIEW: 2026-02-25 (after prototype completion)
-->

# Phase 3: Unified Autonomous Workflow System - Design Document
## Version: 0.1.0 | Created: 2026-02-23 | Status: 🧪 PROTOTYPE DESIGN

<!-- DECISION 2026-02-23: Phase 3 Architecture
CONTEXT: User approved experimental approach in Kaira workspace after discussing consolidation needs
ALTERNATIVES CONSIDERED:
  1. Incremental updates to AWS v2.0 - faster but less comprehensive
  2. Complete redesign from scratch - clean but breaks compatibility
  3. Prototype in Kaira workspace (chosen) - balanced risk/innovation
DECISION: Build Phase 3 as prototype in Kaira workspace, then migrate to central skill
RATIONALE: Experimental approach allows testing new concepts while maintaining production system
EXPIRES: Phase 3 implementation complete (est. 2026-02-25)
-->

## 🎯 Core Objectives

### **Primary Goals**
1. **✅ Unified Task Registry**: Single source of truth for all autonomous tasks
2. **✅ Automated Seed-Detection**: Scan memory/conversations for incomplete work
3. **✅ Cross-Agent Coordination**: Task assignment and conflict avoidance  
4. **✅ Comment Framework**: Standardized guidance for agent-to-agent communication
5. **✅ Enhanced Presence Detection**: Calendar integration + predictive modeling

### **Secondary Goals**
6. **Backward Compatibility**: Maintain NAWS v1.0 + AWS v2.0 functionality
7. **Performance Monitoring**: Track task completion rates, errors, efficiency
8. **Self-Improvement**: System learns from execution patterns

## 📁 System Architecture

### **1. Unified Task Registry (`autonomous-tasks.md`)**
**Location**: `/home/agent/.openclaw/workspace-kaira/phase3-autonomous/autonomous-tasks.md`

**Structure**:
```markdown
# Unified Autonomous Tasks - [DATE]

## Metadata
- **Version**: 3.0.0
- **Last Updated**: [TIMESTAMP]
- **Total Tasks**: X
- **Completed**: Y
- **Pending**: Z
- **Agent Scope**: Kaira (prototype) → Ecosystem-wide (future)

## Task Format
### [PRIORITY] [TASK TITLE]
- **ID**: [UUID or unique identifier]
- **Agent**: [Assigned agent or "any"]
- **Permission Required**: read-only / internal-write / full-autonomy / external-write
- **Time Window**: nighttime-only / daytime-ok / any-time / [specific hours]
- **Estimated Duration**: 5min / 15min / 30min / 60min+
- **Status**: seed / pending / in-progress / completed / blocked
- **Created**: [TIMESTAMP]
- **Started**: [TIMESTAMP] 
- **Completed**: [TIMESTAMP]
- **Description**: [Task description]
- **Context**: [Why this task exists, references]
- **Source**: [Where task originated: memory-scan / manual / conversation]
- **Dependencies**: [Task IDs that must complete first]
- **Tags**: [#priority-high, #skill-audit, #memory-cleanup]
- **Safety Check**: [Verified boundaries]
- **Log Entry**: [Memory file reference after completion]
```

**Key Innovations**:
- **Task IDs**: Unique identifiers for cross-referencing
- **Source Tracking**: Know if task came from memory scan vs manual entry
- **Dependencies**: Tasks can depend on others completing first
- **Agent Assignment**: Can specify which agent should handle

### **2. Seed-Detection Engine (`seed-detection.py`)**
**Purpose**: Scan system for incomplete work, convert to task seeds

**Scan Sources**:
1. **Memory Files**: Look for `#todo`, `#action-item`, incomplete bullet points
2. **Conversation History**: Parse for "we should", "remember to", "need to"
3. **File Modifications**: Recently edited but uncommitted files
4. **Error Logs**: Repeated failures needing attention

**Detection Patterns**:
```python
PATTERNS = {
    "todo": r"#todo\s+(.*?)(?=\n|$)",
    "action_item": r"#action-item\s+(.*?)(?=\n|$)", 
    "incomplete": r"-\s+\[ \]\s+(.*?)(?=\n|$)",  # unchecked boxes
    "user_intent": r"(we should|need to|remember to|let's)\s+(.*?)[.!?]"
}
```

**Output**: Creates task seeds with `status: seed` in registry

### **3. Comment Framework Integration**
**Purpose**: Standardized agent guidance in files

**Template Library**:
```markdown
<!-- FILE CONTEXT TEMPLATE -->
<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->

<!-- DECISION TEMPLATE -->
<!-- DECISION [DATE]: [Decision title]
CONTEXT: [Why decision needed]
ALTERNATIVES CONSIDERED:
  [Alternative 1]
  [Alternative 2]  
DECISION: [Chosen approach]
RATIONALE: [Why chosen]
EXPIRES: [When decision should be re-evaluated]
-->

<!-- AGENT-GUIDANCE TEMPLATE -->
<!-- AGENT-GUIDANCE: [For whom]
ACTION: [What to do]
CONTEXT: [Why important]
QUALITY CRITERIA: [How to know it's done well]
CONTACT: [Who to ask]
-->
```

**Implementation**: 
1. Add to new files automatically
2. Validate existing files have context
3. Use in task execution logs

### **4. Cross-Agent Coordination**
**Initial Prototype Scope**: Within Kaira workspace only
**Future Expansion**: Ecosystem-wide via central registry

**Coordination Patterns**:
1. **Task Assignment Matrix**: Map task types to agent capabilities
2. **Conflict Detection**: Prevent duplicate work on same task
3. **Progress Sharing**: Status updates visible to all agents
4. **Load Balancing**: Distribute tasks based on agent availability

### **5. Enhanced Presence Detection**
**Current Issue**: `openclaw` command not found in path

**Solutions**:
1. **Fix Path Issue**: Add `/home/agent/.local/bin` to PATH in script
2. **Calendar Integration**: Use `gog` skill to check Google Calendar
3. **Predictive Model**: Learn user activity patterns over time

## 🔄 Migration Path

### **Phase 3A: Prototype (Current)**
- **Location**: Kaira workspace `phase3-autonomous/` directory
- **Scope**: Kaira-only tasks
- **Testing**: Manual execution, validate concepts

### **Phase 3B: Integration**
- **Replace** Kaira's `nighttime-activities.md` with unified registry
- **Update** `autonomous-check.py` to read new format
- **Test**: Real execution via existing cron

### **Phase 3C: Ecosystem Rollout**
- **Central Registry**: Move to shared workspace
- **Multi-Agent**: All 7 agents use unified system
- **Seed-Detection**: Active across all workspaces

## 🛠 Implementation Plan

### **Week 1 (Now - 2026-02-25)**
1. **Day 1**: Create unified registry format + parser
2. **Day 1**: Implement seed-detection for memory files
3. **Day 2**: Add comment framework to key files
4. **Day 2**: Fix presence detection issue
5. **Day 3**: Test integration with existing cron

### **Week 2 (2026-02-26 - 2026-03-04)**
1. Cross-agent coordination prototype
2. Calendar integration for presence detection
3. Performance monitoring dashboard
4. Migration scripts for other agents

## 📊 Success Metrics

### **Quantitative**
- **Task Completion Rate**: >80% of scheduled tasks
- **Seed Detection Accuracy**: >70% of detected seeds are valid
- **Presence Detection Accuracy**: >90% correct classification
- **Execution Time**: <30 seconds per task on average

### **Qualitative**
- **User Satisfaction**: Reduced manual task management
- **Agent Coordination**: Less duplicate work, better load distribution
- **System Reliability**: Fewer failed executions, better error handling
- **Documentation Quality**: Files have clear context for future agents

## ⚠️ Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| **Breaking existing NAWS** | High | Maintain backward compatibility, dual-run during transition |
| **Seed detection false positives** | Medium | Manual review of seeds before conversion to tasks |
| **Performance overhead** | Low | Resource monitoring, skip scans during high load |
| **Cross-agent conflicts** | Medium | Central lock file, task assignment algorithm |

## 🎯 Next Steps

1. **Create `autonomous-tasks.md`** with unified format
2. **Write `seed-detection.py`** initial version
3. **Update `autonomous-check.py`** to read new format
4. **Add comment headers** to Phase 3 files
5. **Test** with existing cron job

<!-- AGENT-GUIDANCE: For Phase 3 implementers
ACTION: Follow implementation plan step-by-step
CONTEXT: This is experimental prototype; maintain backward compatibility
QUALITY CRITERIA: Each component works independently before integration
CONTACT: Kaira (delegation agent) for coordination
-->