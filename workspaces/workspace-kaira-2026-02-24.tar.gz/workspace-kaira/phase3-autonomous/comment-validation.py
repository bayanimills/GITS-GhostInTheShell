#!/usr/bin/env python3
"""
Comment Framework Validation Script - Phase 3

Purpose: Validate that files have proper comment headers for agent guidance.
Checks for FILE, DECISION, and AGENT-GUIDANCE templates.

Version: 1.0.0 (Phase 3 prototype)
Author: Kaira (Delegation Agent)
"""

import os
import re
from pathlib import Path
from typing import List, Dict, Tuple
import sys

# Configuration
WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/home/agent/.openclaw/workspace-kaira"))
PHASE3_DIR = WORKSPACE / "phase3-autonomous"

# Files to check (relative to workspace)
FILES_TO_CHECK = [
    "SOUL.md",
    "USER.md", 
    "IDENTITY.md",
    "WORKFLOW_AUTO.md",
    "HEARTBEAT.md",
    "AGENTS.md",
    "TOOLS.md",
    "MEMORY.md",
    "memory/2026-02-23.md",
    "phase3-autonomous/DESIGN.md",
    "phase3-autonomous/autonomous-tasks.md",
    "phase3-autonomous/seed-detection.py",
    "phase3-autonomous/autonomous-check-v3.py",
    "phase3-autonomous/comment-validation.py",  # This file!
]

# Comment template patterns
TEMPLATE_PATTERNS = {
    "file_context": r'(?:<!--\s*\nFILE:.*?\nPURPOSE:.*?\nOWNER:.*?\nUPDATE CADENCE:.*?\nREAD ME WHEN:.*?\nLAST REVIEW:.*?\nNEXT REVIEW:.*?\n-->|#\s*FILE:.*?\n#\s*PURPOSE:.*?\n#\s*OWNER:.*?\n#\s*UPDATE CADENCE:.*?\n#\s*READ ME WHEN:.*?\n#\s*LAST REVIEW:.*?\n#\s*NEXT REVIEW:.*?\n)',
    "decision": r'(?:<!--\s*\nDECISION\s+.*?\nCONTEXT:.*?\nALTERNATIVES CONSIDERED:.*?\nDECISION:.*?\nRATIONALE:.*?\nEXPIRES:.*?\n-->|#\s*DECISION\s+.*?\n#\s*CONTEXT:.*?\n#\s*ALTERNATIVES CONSIDERED:.*?\n#\s*DECISION:.*?\n#\s*RATIONALE:.*?\n#\s*EXPIRES:.*?\n)',
    "agent_guidance": r'(?:<!--\s*\nAGENT-GUIDANCE:.*?\nACTION:.*?\nCONTEXT:.*?\nQUALITY CRITERIA:.*?\nCONTACT:.*?\n-->|#\s*AGENT-GUIDANCE:.*?\n#\s*ACTION:.*?\n#\s*CONTEXT:.*?\n#\s*QUALITY CRITERIA:.*?\n#\s*CONTACT:.*?\n)',
}

# Template names for reporting
TEMPLATE_NAMES = {
    "file_context": "FILE Context Header",
    "decision": "DECISION Documentation", 
    "agent_guidance": "AGENT-GUIDANCE Block"
}

def check_file_for_templates(filepath: Path) -> Dict[str, bool]:
    """Check a file for presence of comment templates."""
    if not filepath.exists():
        return {name: False for name in TEMPLATE_PATTERNS.keys()}
    
    try:
        content = filepath.read_text()
        results = {}
        
        for template_name, pattern in TEMPLATE_PATTERNS.items():
            match = re.search(pattern, content, re.DOTALL | re.IGNORECASE)
            results[template_name] = bool(match)
        
        return results
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return {name: False for name in TEMPLATE_PATTERNS.keys()}

def generate_template_suggestions(filepath: Path, missing_templates: List[str]) -> str:
    """Generate suggested templates to add to a file."""
    suggestions = []
    
    if "file_context" in missing_templates:
        suggestions.append("""<!-- 
FILE: [filename]
PURPOSE: [What this file does]
OWNER: [Which agent/maintainer]
UPDATE CADENCE: [How often updated]
READ ME WHEN: [When to consult this file]
LAST REVIEW: [Date]
NEXT REVIEW: [Date]
-->""")
    
    if "decision" in missing_templates:
        suggestions.append("""<!-- DECISION [DATE]: [Decision title]
CONTEXT: [Why decision needed]
ALTERNATIVES CONSIDERED:
  [Alternative 1]
  [Alternative 2]  
DECISION: [Chosen approach]
RATIONALE: [Why chosen]
EXPIRES: [When decision should be re-evaluated]
-->""")
    
    if "agent_guidance" in missing_templates:
        suggestions.append("""<!-- AGENT-GUIDANCE: [For whom]
ACTION: [What to do]
CONTEXT: [Why important]
QUALITY CRITERIA: [How to know it's done well]
CONTACT: [Who to ask]
-->""")
    
    if not suggestions:
        return ""
    
    header = f"\n## Suggestions for {filepath.name}\n"
    return header + "\n".join([f"```markdown\n{s}\n```" for s in suggestions])

def analyze_file_importance(filepath: Path) -> Tuple[str, List[str]]:
    """Determine which templates are most important for a file type."""
    filename = filepath.name.lower()
    
    # File type categorization
    if filename.endswith(".md"):
        if filename in ["soul.md", "identity.md", "user.md", "agents.md"]:
            # Identity/core files need FILE context
            return "high", ["file_context"]
        elif "workflow" in filename or "design" in filename:
            # Workflow files need FILE context and DECISION blocks
            return "high", ["file_context", "decision"]
        elif "memory" in filename or filename.startswith("2026-"):
            # Memory files benefit from AGENT-GUIDANCE
            return "medium", ["agent_guidance"]
        else:
            # Other markdown files
            return "medium", ["file_context"]
    elif filename.endswith(".py"):
        # Python scripts need FILE context
        return "high", ["file_context"]
    else:
        return "low", []

def main():
    """Main validation function."""
    print("=== Comment Framework Validation ===\n")
    print("Checking files for Phase 3 comment templates...\n")
    
    all_results = []
    files_with_issues = []
    
    for rel_path in FILES_TO_CHECK:
        filepath = WORKSPACE / rel_path
        results = check_file_for_templates(filepath)
        
        # Determine which templates are important for this file
        importance, recommended_templates = analyze_file_importance(filepath)
        
        # Check if recommended templates are missing
        missing_recommended = []
        for template in recommended_templates:
            if not results.get(template, False):
                missing_recommended.append(template)
        
        status = "✅"
        if missing_recommended:
            status = "⚠️"
            files_with_issues.append((filepath, missing_recommended))
        
        # Build result row
        result_row = {
            "file": rel_path,
            "exists": filepath.exists(),
            "status": status,
            "results": results.copy(),
            "missing_recommended": missing_recommended,
            "importance": importance
        }
        all_results.append(result_row)
        
        # Print summary
        if not filepath.exists():
            print(f"❓ {rel_path:50} (file not found)")
        else:
            template_status = []
            for template_name in TEMPLATE_PATTERNS.keys():
                if results.get(template_name):
                    template_status.append("✓")
                else:
                    template_status.append(" ")
            
            status_str = "".join(template_status)
            print(f"{status} {rel_path:50} [{status_str}]")
    
    print("\n" + "="*60)
    print("TEMPLATE KEY: [FILE][DECISION][GUIDANCE]")
    print("="*60)
    
    # Summary statistics
    total_files = len([r for r in all_results if r["exists"]])
    files_with_all = len([r for r in all_results if r["exists"] and all(r["results"].values())])
    files_with_issues_count = len(files_with_issues)
    
    print(f"\nSummary: {files_with_all}/{total_files} files have all templates")
    print(f"Issues found: {files_with_issues_count} files missing recommended templates")
    
    # Generate suggestions report
    if files_with_issues:
        print("\n" + "="*60)
        print("SUGGESTED IMPROVEMENTS")
        print("="*60)
        
        report_path = PHASE3_DIR / "comment-validation-report.md"
        report_content = "# Comment Framework Validation Report\n\n"
        report_content += f"Generated: {Path(__file__).name} on {os.popen('date').read().strip()}\n\n"
        
        for filepath, missing_templates in files_with_issues:
            rel_path = filepath.relative_to(WORKSPACE) if filepath.is_relative_to(WORKSPACE) else filepath
            print(f"\n📄 {rel_path}")
            print(f"   Missing: {', '.join([TEMPLATE_NAMES[t] for t in missing_templates])}")
            
            # Add to report
            report_content += f"## {rel_path}\n"
            report_content += f"**Missing templates**: {', '.join([TEMPLATE_NAMES[t] for t in missing_templates])}\n\n"
            
            suggestions = generate_template_suggestions(filepath, missing_templates)
            if suggestions:
                report_content += suggestions + "\n"
        
        # Save report
        report_path.write_text(report_content)
        print(f"\n📋 Full report saved to: {report_path}")
    
    # Create quick-fix script
    if files_with_issues:
        quick_fix_path = PHASE3_DIR / "add-comment-headers.sh"
        script_content = "#!/bin/bash\n# Quick-fix script to add missing comment headers\n\n"
        script_content += f"# Generated by {Path(__file__).name}\n"
        script_content += f"# Run from workspace: {WORKSPACE}\n\n"
        
        for filepath, missing_templates in files_with_issues:
            if "file_context" in missing_templates:
                rel_path = filepath.relative_to(WORKSPACE) if filepath.is_relative_to(WORKSPACE) else filepath
                script_content += f"# echo 'Adding FILE context to {rel_path}'\n"
                script_content += f"# sed -i '1i <!--\\nFILE: {rel_path}\\nPURPOSE: [TODO]\\nOWNER: [TODO]\\nUPDATE CADENCE: [TODO]\\nREAD ME WHEN: [TODO]\\nLAST REVIEW: [TODO]\\nNEXT REVIEW: [TODO]\\n-->\\n' \"{filepath}\"\n\n"
        
        quick_fix_path.write_text(script_content)
        quick_fix_path.chmod(0o755)
        print(f"\n⚡ Quick-fix script generated: {quick_fix_path}")
        print("   Review and edit before running!")
    
    return 0 if files_with_issues_count == 0 else 1

if __name__ == "__main__":
    sys.exit(main())