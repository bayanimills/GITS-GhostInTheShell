#!/usr/bin/env python3
"""Test presence detection function."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Mock setup_logging for testing
import logging

def setup_logging():
    logger = logging.getLogger(__name__)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger

# Mock the setup_logging in the module before import
import autonomous_check_v3
autonomous_check_v3.setup_logging = setup_logging

# Now import the functions
from autonomous_check_v3 import get_presence_level, get_presence_level_text_fallback

print("Testing presence detection...")
print(f"Result: {get_presence_level()}")

# Test with sample text output
sample_output = """Session store: /home/agent/.openclaw/agents/main/sessions/sessions.json
Sessions listed: 18
Kind   Key                        Age       Model          Tokens (ctx %)       Flags
direct agent:main:teleg...072941  2m ago    deepseek-reasoner 47k/64k (73%)        system id:b5380278-3f77-40de-a2d3-ba5f93eb6f4f
direct agent:main:main            2m ago    deepseek-reasoner 43k/64k (67%)        system id:67125d00-2583-4d66-8b4d-fcc398976521"""

print("\nTesting text fallback...")
print(f"Result: {get_presence_level_text_fallback(sample_output)}")