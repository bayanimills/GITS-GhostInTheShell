#!/usr/bin/env python3
# FILE: autonomous-check-v3.py
# PURPOSE: Execute tasks from unified registry with enhanced presence detection and Phase 3 features
# OWNER: Kaira (Delegation Agent) - Phase 3 prototype
# UPDATE CADENCE: On each execution (every 30 minutes during testing)
# READ ME WHEN:
#   - Modifying task execution logic
#   - Adding new task handlers
#   - Debugging presence detection or permission issues
# LAST REVIEW: 2026-02-23 (Kaira - Phase 3 creation)
# NEXT REVIEW: 2026-02-25 (after prototype testing)

"""
Autonomous Workflow System v3.0 - Phase 3 Prototype
Extended from AWS v2.0 with unified registry and seed detection.

Version: 3.0.0-prototype
Purpose: Execute tasks from unified registry with enhanced presence detection
         and Phase 3 features.

Author: Kaira (Delegation Agent)
Status: 🧪 PROTOTYPE - Testing in Kaira workspace
"""

import sys
import os
import re
import datetime
import subprocess
import json
import time
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

# Configuration
WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/home/agent/.openclaw/workspace-kaira"))
PHASE3_DIR = WORKSPACE / "phase3-autonomous"
TASKS_FILE = PHASE3_DIR / "autonomous-tasks.md"  # Unified registry
MEMORY_DIR = WORKSPACE / "memory"
LOG_DIR = WORKSPACE / "logs"
LOG_DIR.mkdir(exist_ok=True)
CRON_LOG = LOG_DIR / "autonomous-check-v3.log"

# OpenClaw CLI path
OPENCLAW_PATH = "/home/agent/.local/bin/openclaw"

# Time configuration (Sydney time)
NIGHT_START = 23  # 23:00
NIGHT_END = 7     # 07:00 (next day)

# Presence detection configuration (in minutes)
PRESENCE_THRESHOLDS = {
    "ACTIVE": 5,     # User active if message < 5 minutes ago
    "IDLE": 60,      # User idle if message 5-60 minutes ago  
    "ABSENT": 60     # User absent if message > 60 minutes ago
}

# Permission levels mapping
PERMISSION_LEVELS = {
    "ACTIVE": "read-only",      # User actively engaged
    "IDLE": "internal-write",   # User idle but potentially nearby
    "ABSENT": "full-autonomy",  # User absent (nighttime or away)
    "NIGHTTIME": "full-autonomy"  # Nighttime regardless of presence
}

# Manual override file path
OVERRIDE_FILE = Path.home() / ".openclaw-autonomy-pause"

def get_agent_id() -> str:
    """
    Extract agent ID from workspace path.
    Returns 'main' if pattern not found.
    """
    workspace_str = str(WORKSPACE)
    # Pattern: workspace-<agent_name>
    match = re.search(r'workspace-([a-zA-Z0-9]+)$', workspace_str)
    if match:
        return match.group(1)
    # Fallback: try to extract from path components
    parts = workspace_str.split('/')
    for part in parts:
        if part.startswith('workspace-'):
            return part.replace('workspace-', '')
    return 'main'  # default

def get_agent_sessions_path(agent_id: str) -> Path:
    """Return path to agent's sessions.json file."""
    return Path(f"/home/agent/.openclaw/agents/{agent_id}/sessions/sessions.json")

# Resource monitoring thresholds
RESOURCE_THRESHOLDS = {
    "cpu_load_1min": 2.0,      # 1-minute load average per core (skip if >2)
    "cpu_load_5min": 1.5,      # 5-minute load average per core
    "memory_percent": 80.0,    # Memory usage percent (skip if >80%)
    "disk_percent": 90.0,      # Disk usage percent (skip if >90%)
    "network_blocked": False,  # Network connectivity check
}

def setup_logging():
    """Setup basic logging to file and stdout."""
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(CRON_LOG, mode='a'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def check_manual_override() -> bool:
    """Check if autonomy is manually paused via override file."""
    return OVERRIDE_FILE.exists()

def get_presence_level() -> str:
    """
    Determine user presence level based on last activity.
    
    Returns: "ACTIVE", "IDLE", or "ABSENT"
    
    Uses agent-specific sessions.json for per-agent presence detection.
    """
    logger = setup_logging()
    
    # Check manual override first
    if check_manual_override():
        logger.info("Autonomy manually paused via override file")
        return "ABSENT"  # Treat as absent but with special handling
    
    agent_id = get_agent_id()
    logger.info(f"Checking presence for agent: {agent_id}")
    
    # Path to agent's sessions.json
    sessions_path = get_agent_sessions_path(agent_id)
    
    # Try reading sessions.json directly first
    if sessions_path.exists():
        try:
            with open(sessions_path, 'r') as f:
                data = json.load(f)
            
            sessions = data.get('sessions', [])
            if not sessions:
                logger.info(f"No sessions found in {sessions_path}")
                # Fall back to CLI
                return get_presence_level_via_cli(agent_id)
            
            # User's Telegram ID from USER.md
            USER_TELEGRAM_ID = "548072941"
            TELEGRAM_KEY_PATTERN = f"telegram:direct:{USER_TELEGRAM_ID}"
            
            # Find most recent Telegram session for the user within this agent's sessions
            latest_age_ms = None
            
            for session in sessions:
                key = session.get('key', '')
                age_ms = session.get('ageMs')
                
                if not age_ms:
                    continue
                    
                # Check if this is the user's Telegram session for this agent
                if TELEGRAM_KEY_PATTERN in key and f'agent:{agent_id}:' in key:
                    latest_age_ms = age_ms
                    logger.debug(f"Found user Telegram session for agent {agent_id}: age_ms={age_ms}")
                    break
                
                # Fallback: any Telegram session for this agent
                if 'telegram' in key.lower() and f'agent:{agent_id}:' in key and latest_age_ms is None:
                    latest_age_ms = age_ms
                    logger.debug(f"Found general Telegram session for agent {agent_id}: age_ms={age_ms}")
            
            if latest_age_ms is None:
                logger.info(f"No Telegram session found for agent {agent_id}")
                return "ABSENT"
            
            # Convert milliseconds to minutes
            minutes_ago = latest_age_ms / (1000 * 60)
            logger.info(f"Most recent Telegram session for agent {agent_id}: {minutes_ago:.1f} minutes ago")
            
            # Determine presence level
            if minutes_ago < PRESENCE_THRESHOLDS["ACTIVE"]:
                return "ACTIVE"
            elif minutes_ago < PRESENCE_THRESHOLDS["IDLE"]:
                return "IDLE"
            else:
                return "ABSENT"
                
        except (json.JSONDecodeError, IOError) as e:
            logger.warning(f"Failed to read/parse {sessions_path}: {e}, falling back to CLI")
    
    # Fallback to CLI with --store parameter
    return get_presence_level_via_cli(agent_id)


def get_presence_level_via_cli(agent_id: str) -> str:
    """
    Fallback presence detection using OpenClaw CLI with agent-specific store.
    """
    logger = setup_logging()
    logger.info(f"Using CLI fallback for agent {agent_id}")
    
    try:
        # Use --store parameter to target agent's sessions
        store_path = get_agent_sessions_path(agent_id)
        result = subprocess.run(
            [OPENCLAW_PATH, 'sessions', 'list', '--store', str(store_path), '--limit', '20', '--json'],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            logger.warning(f"OpenClaw CLI failed: {result.stderr}")
            return "ABSENT"  # Assume absent if can't check
        
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from OpenClaw: {e}")
            # Fall back to text parsing with agent filtering
            return get_presence_level_text_fallback(result.stdout, agent_id)
        
        sessions = data.get('sessions', [])
        if not sessions:
            logger.info("No sessions found via CLI")
            return "ABSENT"
        
        # User's Telegram ID from USER.md
        USER_TELEGRAM_ID = "548072941"
        TELEGRAM_KEY_PATTERN = f"telegram:direct:{USER_TELEGRAM_ID}"
        
        # Find most recent Telegram session for the user within this agent's sessions
        latest_age_ms = None
        
        for session in sessions:
            key = session.get('key', '')
            age_ms = session.get('ageMs')
            
            if not age_ms:
                continue
                
            # Check if this is the user's Telegram session for this agent
            if TELEGRAM_KEY_PATTERN in key and f'agent:{agent_id}:' in key:
                latest_age_ms = age_ms
                logger.debug(f"Found user Telegram session for agent {agent_id}: age_ms={age_ms}")
                break
            
            # Fallback: any Telegram session for this agent
            if 'telegram' in key.lower() and f'agent:{agent_id}:' in key and latest_age_ms is None:
                latest_age_ms = age_ms
                logger.debug(f"Found general Telegram session for agent {agent_id}: age_ms={age_ms}")
        
        if latest_age_ms is None:
            logger.info(f"No Telegram session found for agent {agent_id} via CLI")
            return "ABSENT"
        
        # Convert milliseconds to minutes
        minutes_ago = latest_age_ms / (1000 * 60)
        logger.info(f"Most recent Telegram session for agent {agent_id}: {minutes_ago:.1f} minutes ago")
        
        # Determine presence level
        if minutes_ago < PRESENCE_THRESHOLDS["ACTIVE"]:
            return "ACTIVE"
        elif minutes_ago < PRESENCE_THRESHOLDS["IDLE"]:
            return "IDLE"
        else:
            return "ABSENT"
            
    except FileNotFoundError:
        logger.error(f"OpenClaw CLI not found at {OPENCLAW_PATH}")
        return "ABSENT"
    except subprocess.TimeoutExpired:
        logger.warning("OpenClaw CLI timeout")
        return "ABSENT"
    except Exception as e:
        logger.error(f"Presence detection error: {e}")
        return "ABSENT"


def get_presence_level_text_fallback(output: str, agent_id: str = 'main') -> str:
    """
    Fallback text parsing if JSON fails, with per-agent filtering.
    """
    logger = setup_logging()
    logger.warning(f"Using text fallback for presence detection (agent: {agent_id})")
    
    lines = output.split('\n')
    latest_minutes = None
    
    agent_pattern = f'agent:{agent_id}'
    
    for line in lines:
        # Look for timestamp patterns in session list, filtered by agent
        if 'telegram' in line.lower() and agent_pattern in line:
            # Extract time ago - handle "Xm ago", "X minutes ago", "Xh ago", "Xs ago"
            import re
            
            # Try minutes pattern
            match = re.search(r'(\d+)\s*(?:minutes?|min|m)\s+ago', line.lower())
            if match:
                minutes_ago = int(match.group(1))
            else:
                # Try hours pattern
                match = re.search(r'(\d+)\s*(?:hours?|h)\s+ago', line.lower())
                if match:
                    minutes_ago = int(match.group(1)) * 60
                else:
                    # Try seconds pattern (treat < 60s as 0 minutes)
                    match = re.search(r'(\d+)\s*(?:seconds?|s)\s+ago', line.lower())
                    if match:
                        seconds_ago = int(match.group(1))
                        minutes_ago = seconds_ago / 60
                    else:
                        continue
            
            if latest_minutes is None or minutes_ago < latest_minutes:
                latest_minutes = minutes_ago
    
    if latest_minutes is None:
        logger.info(f"No recent Telegram session found for agent {agent_id} in text fallback")
        return "ABSENT"
    
    logger.info(f"Text fallback: most recent telegram session for agent {agent_id}: {latest_minutes:.1f} minutes ago")
    
    # Determine presence level
    if latest_minutes < PRESENCE_THRESHOLDS["ACTIVE"]:
        return "ACTIVE"
    elif latest_minutes < PRESENCE_THRESHOLDS["IDLE"]:
        return "IDLE"
    else:
        return "ABSENT"

def get_current_permission() -> str:
    """Get current permission level based on presence and time."""
    presence = get_presence_level()
    
    # Check if it's nighttime
    now = datetime.datetime.now()
    if NIGHT_START <= now.hour or now.hour < NIGHT_END:
        return PERMISSION_LEVELS["NIGHTTIME"]
    
    return PERMISSION_LEVELS.get(presence, "read-only")

def parse_unified_tasks_file() -> Tuple[Dict, List[Dict]]:
    """
    Parse unified autonomous-tasks.md file.
    
    Returns: (metadata_dict, tasks_list)
    """
    logger = setup_logging()
    
    if not TASKS_FILE.exists():
        logger.warning(f"Unified tasks file not found: {TASKS_FILE}")
        return {}, []
    
    content = TASKS_FILE.read_text()
    
    # Parse metadata section
    metadata = {}
    metadata_match = re.search(r'## Metadata\s*\n(.*?)(?=\n##|\n#)', content, re.DOTALL)
    if metadata_match:
        metadata_lines = metadata_match.group(1).strip().split('\n')
        for line in metadata_lines:
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip().strip('-* ')
                metadata[key] = value.strip()
    
    # Parse tasks - look for ### headings
    tasks = []
    task_sections = re.findall(r'### (.*?)\n(.*?)(?=\n### |\n## |\n# |$)', content, re.DOTALL)
    
    for task_header, task_content in task_sections:
        task = {'header': task_header.strip()}
        lines = task_content.strip().split('\n')
        
        for line in lines:
            if ':' in line and '**' in line:
                # Format: - **Field**: value
                line_clean = line.strip().strip('- ')
                if '**' in line_clean:
                    # Extract field name between **
                    field_match = re.search(r'\*\*(.*?)\*\*', line_clean)
                    if field_match:
                        field = field_match.group(1)
                        # Get value after colon
                        value_part = line_clean.split(':', 1)[1] if ':' in line_clean else ''
                        task[field] = value_part.strip()
        
        # Ensure required fields
        if 'Status' not in task:
            task['Status'] = 'pending'
        if 'Permission Required' not in task:
            task['Permission Required'] = 'read-only'
        if 'ID' not in task:
            # Generate ID from header
            task['ID'] = re.sub(r'[^a-zA-Z0-9]', '-', task_header)[:20]
        
        tasks.append(task)
    
    logger.info(f"Parsed {len(tasks)} tasks from unified registry")
    return metadata, tasks

def task_has_permission(task: Dict, current_permission: str) -> bool:
    """Check if task can run with current permission level."""
    required = task.get('Permission Required', 'read-only')
    
    # Permission hierarchy
    hierarchy = {
        'read-only': 0,
        'internal-write': 1,
        'full-autonomy': 2,
        'external-write': 3
    }
    
    req_level = hierarchy.get(required, 0)
    curr_level = hierarchy.get(current_permission, 0)
    
    return curr_level >= req_level

def get_next_pending_task(tasks: List[Dict], current_permission: str) -> Optional[Dict]:
    """Get next task that can run with current permission."""
    eligible_tasks = []
    
    for task in tasks:
        status = task.get('Status', '').lower()
        if status not in ['pending', 'seed', 'in-progress']:
            continue
        
        if task_has_permission(task, current_permission):
            # Calculate priority score
            priority_map = {'high': 3, 'medium': 2, 'low': 1}
            header = task.get('header', '')
            priority = 2  # default medium
            
            if 'high' in header.lower():
                priority = 3
            elif 'low' in header.lower():
                priority = 1
            
            eligible_tasks.append((priority, task))
    
    if not eligible_tasks:
        return None
    
    # Sort by priority (highest first)
    eligible_tasks.sort(key=lambda x: x[0], reverse=True)
    return eligible_tasks[0][1]

def execute_task_safely(task: Dict, current_permission: str) -> Dict:
    """Execute a task with safety checks."""
    logger = setup_logging()
    
    task_id = task.get('ID', 'unknown')
    task_title = task.get('header', 'Unknown task')
    
    logger.info(f"Executing task: {task_title} with permission: {current_permission}")
    
    # Check resource thresholds
    if not check_system_resources():
        logger.warning("System resources exceeded thresholds, skipping task")
        return {'success': False, 'reason': 'resource_thresholds'}
    
    # Task-specific handlers
    result = handle_generic_task(task)
    
    # Update task status in registry
    update_task_status(task_id, 'completed')
    
    # Create memory log entry
    create_memory_log(task, result)
    
    return result

def handle_generic_task(task: Dict) -> Dict:
    """Generic handler for tasks without specific implementation."""
    logger = setup_logging()
    task_title = task.get('header', 'Unknown task')
    
    logger.warning(f"No specific handler for task: {task_title}. Using generic handler.")
    
    # For Phase 3 prototype, just log and simulate success
    time.sleep(1)  # Simulate work
    
    return {
        'success': True,
        'handler': 'generic',
        'timestamp': datetime.datetime.now().isoformat(),
        'note': 'Phase 3 prototype - generic handler'
    }

def check_system_resources() -> bool:
    """Check system resources against thresholds."""
    logger = setup_logging()
    try:
        import psutil
        load1, load5, load15 = psutil.getloadavg()
        cpu_count = os.cpu_count() or 1
        
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        load1_per_core = load1 / cpu_count
        load5_per_core = load5 / cpu_count
        
        logger.info(f"System resources OK: load={load1_per_core:.2f}/{load5_per_core:.2f}, mem={memory.percent:.1f}%, disk={disk.percent:.1f}%")
        
        if load1_per_core > RESOURCE_THRESHOLDS["cpu_load_1min"]:
            logger.warning(f"High CPU load: {load1_per_core:.2f} per core")
            return False
        if memory.percent > RESOURCE_THRESHOLDS["memory_percent"]:
            logger.warning(f"High memory usage: {memory.percent:.1f}%")
            return False
        if disk.percent > RESOURCE_THRESHOLDS["disk_percent"]:
            logger.warning(f"High disk usage: {disk.percent:.1f}%")
            return False
            
        return True
    except ImportError:
        logger.info("psutil not installed, skipping resource checks")
        return True
    except Exception as e:
        logger.error(f"Resource check failed: {e}")
        return True  # Assume OK if can't check

def update_task_status(task_id: str, new_status: str):
    """Update task status in unified registry file."""
    if not TASKS_FILE.exists():
        return
    
    content = TASKS_FILE.read_text()
    
    # Find task by ID in the file
    # This is simplified - real implementation would parse and rebuild
    lines = content.split('\n')
    in_target_task = False
    updated = False
    
    for i, line in enumerate(lines):
        if f"**ID**: {task_id}" in line:
            in_target_task = True
        elif in_target_task and line.startswith('### '):
            in_target_task = False
        
        if in_target_task and '**Status**:' in line:
            lines[i] = f"- **Status**: {new_status}"
            updated = True
            break
    
    if updated:
        TASKS_FILE.write_text('\n'.join(lines))
        logger = setup_logging()
        logger.info(f"Updated task {task_id} status to {new_status}")

def create_memory_log(task: Dict, result: Dict):
    """Create memory log entry for task completion."""
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    memory_file = MEMORY_DIR / f"{today}.md"
    
    if not memory_file.exists():
        memory_file.write_text(f"# {today}\n\n")
    
    log_entry = f"""
## Autonomous Task Completed: {task.get('header', 'Unknown')}
- **Time**: {datetime.datetime.now().isoformat()}
- **Task ID**: {task.get('ID', 'N/A')}
- **Status**: {'Success' if result.get('success') else 'Failed'}
- **Handler**: {result.get('handler', 'generic')}
- **Note**: {result.get('note', '')}
- **Tags**: #autonomous-work #phase3-prototype
"""
    
    with open(memory_file, 'a') as f:
        f.write(log_entry)
    
    logger = setup_logging()
    logger.info(f"Memory log created for task {task.get('ID', 'unknown')}")

def main():
    """Main execution function."""
    logger = setup_logging()
    logger.info("=== Autonomous Workflow System v3.0 (Phase 3 Prototype) ===")
    
    # Check manual override
    if check_manual_override():
        logger.info("Autonomy manually paused. Exiting.")
        return 0
    
    # Get current permission level
    permission = get_current_permission()
    logger.info(f"Current permission level: {permission}")
    
    # Parse unified tasks
    metadata, tasks = parse_unified_tasks_file()
    
    if not tasks:
        logger.info("No tasks in registry")
        return 0
    
    # Get next eligible task
    task = get_next_pending_task(tasks, permission)
    
    if not task:
        logger.info("No eligible tasks with current permission level")
        return 0
    
    logger.info(f"Selected task: {task.get('header')}")
    
    # Execute task
    result = execute_task_safely(task, permission)
    
    if result.get('success'):
        logger.info(f"Task completed successfully: {result}")
    else:
        logger.warning(f"Task failed: {result}")
    
    logger.info("=== Autonomous check-in completed ===")
    return 0

if __name__ == "__main__":
    sys.exit(main())