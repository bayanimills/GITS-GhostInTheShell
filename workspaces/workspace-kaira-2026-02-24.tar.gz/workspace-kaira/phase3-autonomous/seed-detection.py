#!/usr/bin/env python3
# FILE: seed-detection.py
# PURPOSE: Scan system for incomplete work, conversations, and memory patterns to automatically discover tasks
# OWNER: Kaira (Delegation Agent) - Phase 3 prototype
# UPDATE CADENCE: On each autonomous check or when triggered manually
# READ ME WHEN:
#   - Understanding seed detection patterns
#   - Modifying detection algorithms
#   - Adding new source types to scan
# LAST REVIEW: 2026-02-23 (Kaira - Phase 3 creation)
# NEXT REVIEW: 2026-02-25 (after prototype testing)

"""
Seed Detection Engine - Phase 3 Autonomous Workflow System

Purpose: Scan system for incomplete work, conversations, and memory patterns
         to automatically discover tasks that should be added to unified registry.

Version: 1.0.0 (Phase 3 prototype)
Author: Kaira (Delegation Agent)
"""

import os
import re
import sys
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple, Optional
import json

# Configuration
WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/home/agent/.openclaw/workspace-kaira"))
MEMORY_DIR = WORKSPACE / "memory"
TASKS_FILE = WORKSPACE / "phase3-autonomous" / "autonomous-tasks.md"
LOG_DIR = WORKSPACE / "logs"
LOG_DIR.mkdir(exist_ok=True)

# Detection patterns
PATTERNS = {
    "todo_tag": r"#todo\s+(.*?)(?=\n|$)",
    "action_item_tag": r"#action-item\s+(.*?)(?=\n|$)",
    "incomplete_checkbox": r"-\s+\[ \]\s+(.*?)(?=\n|$)",  # unchecked box [ ]
    "completed_checkbox": r"-\s+\[x\]\s+(.*?)(?=\n|$)",   # checked box [x]
    "user_intent": r"(we should|need to|remember to|let's|would be good to)\s+(.*?)[.!?]",
    "question_to_self": r"\?\s*(.*?)(?=\n|$)",  # Questions that might imply action needed
    "incomplete_section": r"##\s*.*?\n(.*?)(?=##|\Z)",  # Sections with few completion markers
}

# Priority mapping keywords
PRIORITY_KEYWORDS = {
    "high": ["urgent", "critical", "important", "must", "need", "required"],
    "medium": ["should", "consider", "recommend", "useful", "helpful"],
    "low": ["nice to have", "optional", "when possible", "low priority"]
}

def setup_logging():
    """Setup basic logging."""
    import logging
    log_file = LOG_DIR / "seed-detection.log"
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, mode='a'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def scan_memory_files() -> List[Dict]:
    """Scan memory directory for seed patterns."""
    logger = setup_logging()
    seeds = []
    
    if not MEMORY_DIR.exists():
        logger.warning(f"Memory directory not found: {MEMORY_DIR}")
        return seeds
    
    memory_files = list(MEMORY_DIR.glob("*.md"))
    logger.info(f"Scanning {len(memory_files)} memory files for seeds")
    
    for mem_file in memory_files:
        try:
            content = mem_file.read_text()
            file_seeds = extract_seeds_from_content(content, str(mem_file))
            seeds.extend(file_seeds)
            if file_seeds:
                logger.info(f"Found {len(file_seeds)} seeds in {mem_file.name}")
        except Exception as e:
            logger.error(f"Error scanning {mem_file}: {e}")
    
    return seeds

def extract_seeds_from_content(content: str, source_file: str) -> List[Dict]:
    """Extract potential task seeds from text content."""
    seeds = []
    
    # Check each pattern
    for pattern_name, pattern in PATTERNS.items():
        matches = re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE)
        for match in matches:
            seed_text = match.group(1).strip() if len(match.groups()) > 0 else match.group(0).strip()
            
            # Skip very short or non-actionable matches
            if len(seed_text) < 10 or seed_text.lower().startswith(("http://", "https://")):
                continue
            
            # Determine priority based on keywords
            priority = "medium"
            text_lower = seed_text.lower()
            for prio, keywords in PRIORITY_KEYWORDS.items():
                if any(keyword in text_lower for keyword in keywords):
                    priority = prio
                    break
            
            # Create seed object
            seed = {
                "id": f"seed-{datetime.now().strftime('%Y%m%d%H%M%S')}-{len(seeds)}",
                "text": seed_text,
                "pattern": pattern_name,
                "source_file": source_file,
                "source_line": get_line_number(content, match.start()),
                "priority": priority,
                "timestamp": datetime.now().isoformat(),
                "status": "seed"  # Not yet converted to task
            }
            seeds.append(seed)
    
    return seeds

def get_line_number(content: str, position: int) -> int:
    """Get line number for a character position in content."""
    return content[:position].count('\n') + 1

def convert_seed_to_task(seed: Dict) -> Dict:
    """Convert a seed object to a task dictionary."""
    # Map pattern to task type
    pattern_to_type = {
        "todo_tag": "general",
        "action_item_tag": "action",
        "incomplete_checkbox": "completion",
        "user_intent": "intent",
        "question_to_self": "clarification"
    }
    
    task_type = pattern_to_type.get(seed["pattern"], "general")
    
    # Estimate duration based on text length and keywords
    text_len = len(seed["text"])
    if text_len < 50:
        duration = "5min"
    elif text_len < 150:
        duration = "15min"
    elif text_len < 300:
        duration = "30min"
    else:
        duration = "60min+"
    
    # Determine permission requirement based on content
    permission = "read-only"
    if any(word in seed["text"].lower() for word in ["write", "edit", "create", "update", "modify"]):
        permission = "internal-write"
    if any(word in seed["text"].lower() for word in ["send", "commit", "push", "post", "publish"]):
        permission = "external-write"
    
    task = {
        "id": f"task-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "title": seed["text"][:100] + ("..." if len(seed["text"]) > 100 else ""),
        "description": seed["text"],
        "priority": seed["priority"],
        "permission_required": permission,
        "time_window": "any-time",  # Default
        "estimated_duration": duration,
        "status": "seed",  # Needs review before becoming pending
        "created": datetime.now().isoformat(),
        "source": f"seed-detection:{seed['pattern']}",
        "source_reference": f"{seed['source_file']}#L{seed['source_line']}",
        "tags": [f"#{seed['priority']}-priority", "#auto-detected", f"#{seed['pattern']}"],
        "safety_check": "needs-review"
    }
    
    return task

def seeds_to_task_markdown(seeds: List[Dict]) -> str:
    """Convert seeds to markdown task entries."""
    if not seeds:
        return "# No seeds detected\n\n"
    
    markdown = "# Auto-Detected Seeds\n"
    markdown += f"## Generated: {datetime.now().isoformat()}\n"
    markdown += f"## Total Seeds: {len(seeds)}\n\n"
    
    for seed in seeds:
        markdown += f"### {seed['priority'].title()}: {seed['text'][:80]}...\n"
        markdown += f"- **Pattern**: {seed['pattern']}\n"
        markdown += f"- **Source**: {seed['source_file']} (line {seed['source_line']})\n"
        markdown += f"- **Detected**: {seed['timestamp']}\n"
        markdown += f"- **Status**: {seed['status']}\n"
        markdown += f"- **Full Text**: {seed['text']}\n\n"
    
    return markdown

def save_seeds_report(seeds: List[Dict]):
    """Save seeds report to file."""
    report_file = WORKSPACE / "phase3-autonomous" / "detected-seeds.md"
    markdown = seeds_to_task_markdown(seeds)
    report_file.write_text(markdown)
    
    logger = setup_logging()
    logger.info(f"Saved {len(seeds)} seeds to {report_file}")
    
    # Also save JSON for machine processing
    json_file = WORKSPACE / "phase3-autonomous" / "detected-seeds.json"
    json_file.write_text(json.dumps(seeds, indent=2))
    
    return report_file, json_file

def main():
    """Main execution function."""
    logger = setup_logging()
    logger.info("=== Seed Detection Engine Started ===")
    
    # Scan for seeds
    seeds = scan_memory_files()
    
    if seeds:
        logger.info(f"Found {len(seeds)} potential task seeds")
        
        # Save report
        report_file, json_file = save_seeds_report(seeds)
        logger.info(f"Reports saved: {report_file}, {json_file}")
        
        # Convert to tasks (for demonstration)
        tasks = [convert_seed_to_task(seed) for seed in seeds[:5]]  # Limit to 5 for now
        
        logger.info(f"Converted {len(tasks)} seeds to task format")
        logger.info("Note: Auto-adding to task registry requires manual review in prototype")
        
        # Show sample
        for i, task in enumerate(tasks[:3]):
            logger.info(f"Sample task {i+1}: {task['title']}")
    else:
        logger.info("No seeds detected in memory files")
    
    logger.info("=== Seed Detection Completed ===")
    return len(seeds)

if __name__ == "__main__":
    sys.exit(main())