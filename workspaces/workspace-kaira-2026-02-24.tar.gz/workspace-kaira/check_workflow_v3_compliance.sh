#!/bin/bash
# WORKFLOW_AUTO.md v3.0.0 Compliance Checker
# Validates v3.0.0 features and reasoning framework integration
# For use during v3 rollout verification (Phase 4)

TEMPLATE_V3="/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md"  # Will be v3.0.0 after update
LOG_FILE="/home/agent/.openclaw/workspace-kaira/memory/workflow_v3_compliance.log"
AGENTS="aria shelley donna doc danny kaira main"

# v3.0.0 Feature Requirements
V3_FEATURES=(
    "Version: 3.0.0"
    "DEFINITIVE_TEMPLATE"
    "reasoning framework"
    "five critical questions"
    "autonomous work philosophy"
    "NAWS"
    "n8n"
    "Rollout to your agent"
    "Agent-specific customization zones"
)

# Reasoning Framework Questions (must all be present)
REASONING_QUESTIONS=(
    "Trigger Verification"
    "Precondition Check"
    "Evidence Requirement"
    "Boundary Analysis"
    "Failure Planning"
)

# Create log directory if needed
mkdir -p "$(dirname "$LOG_FILE")"

echo "=== WORKFLOW_AUTO.md v3.0.0 COMPLIANCE CHECK ===" | tee -a "$LOG_FILE"
echo "Check time: $(date)" | tee -a "$LOG_FILE"
echo "Template: $TEMPLATE_V3" | tee -a "$LOG_FILE"
echo "Agents: $AGENTS" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Check template first (if it exists)
if [ -f "$TEMPLATE_V3" ]; then
    echo "📋 TEMPLATE CHECK ($TEMPLATE_V3):" | tee -a "$LOG_FILE"
    
    TEMPLATE_VERSION=$(grep -i "version:" "$TEMPLATE_V3" | head -1)
    echo "  Version: $TEMPLATE_VERSION" | tee -a "$LOG_FILE"
    
    # Check for v3.0.0 in version
    if echo "$TEMPLATE_VERSION" | grep -q "3.0.0"; then
        echo "  ✅ Version 3.0.0 detected" | tee -a "$LOG_FILE"
    else
        echo "  ❌ Not v3.0.0: $TEMPLATE_VERSION" | tee -a "$LOG_FILE"
    fi
    
    # Check for DEFINITIVE_TEMPLATE status
    if grep -q "DEFINITIVE_TEMPLATE" "$TEMPLATE_V3"; then
        echo "  ✅ DEFINITIVE_TEMPLATE status present" | tee -a "$LOG_FILE"
    else
        echo "  ❌ Missing DEFINITIVE_TEMPLATE designation" | tee -a "$LOG_FILE"
    fi
    
    # Check v3 features
    echo "" | tee -a "$LOG_FILE"
    echo "  🔍 v3 Feature Compliance:" | tee -a "$LOG_FILE"
    for feature in "${V3_FEATURES[@]}"; do
        if grep -q -i "$feature" "$TEMPLATE_V3"; then
            echo "    ✅ $feature" | tee -a "$LOG_FILE"
        else
            echo "    ❌ $feature" | tee -a "$LOG_FILE"
        fi
    done
    
    # Check reasoning framework questions
    echo "" | tee -a "$LOG_FILE"
    echo "  🧠 Reasoning Framework Questions:" | tee -a "$LOG_FILE"
    for question in "${REASONING_QUESTIONS[@]}"; do
        if grep -q "$question" "$TEMPLATE_V3"; then
            echo "    ✅ $question" | tee -a "$LOG_FILE"
        else
            echo "    ❌ $question" | tee -a "$LOG_FILE"
        fi
    done
    
else
    echo "⚠️  Template not found at $TEMPLATE_V3" | tee -a "$LOG_FILE"
    echo "   Assuming v2.0.0 still in place" | tee -a "$LOG_FILE"
fi

echo "" | tee -a "$LOG_FILE"
echo "=== AGENT COMPLIANCE CHECK ===" | tee -a "$LOG_FILE"

# Initialize compliance tracking
COMPLIANT_AGENTS=()
NON_COMPLIANT_AGENTS=()

for agent in $AGENTS; do
    AGENT_FILE="/home/agent/.openclaw/workspace-$agent/WORKFLOW_AUTO.md"
    
    if [ ! -f "$AGENT_FILE" ]; then
        echo "❌ $agent: NO FILE" | tee -a "$LOG_FILE"
        NON_COMPLIANT_AGENTS+=("$agent (missing)")
        continue
    fi
    
    echo "" | tee -a "$LOG_FILE"
    echo "🔍 $agent ($AGENT_FILE):" | tee -a "$LOG_FILE"
    
    # Check version
    AGENT_VERSION=$(grep -i "version:" "$AGENT_FILE" | head -1)
    echo "  Version: $AGENT_VERSION" | tee -a "$LOG_FILE"
    
    # Check for v3.0.0
    if echo "$AGENT_VERSION" | grep -q "3.0.0"; then
        echo "  ✅ v3.0.0 detected" | tee -a "$LOG_FILE"
        V3_VERSION=true
    else
        echo "  ❌ Not v3.0.0" | tee -a "$LOG_FILE"
        V3_VERSION=false
    fi
    
    # Check reasoning framework questions
    REASONING_COUNT=0
    echo "  🧠 Reasoning Framework:" | tee -a "$LOG_FILE"
    for question in "${REASONING_QUESTIONS[@]}"; do
        if grep -q "$question" "$AGENT_FILE"; then
            echo "    ✅ $question" | tee -a "$LOG_FILE"
            REASONING_COUNT=$((REASONING_COUNT + 1))
        else
            echo "    ❌ $question" | tee -a "$LOG_FILE"
        fi
    done
    
    # Check autonomous work philosophy
    if grep -q -i "autonomous work" "$AGENT_FILE"; then
        echo "  ✅ Autonomous work philosophy" | tee -a "$LOG_FILE"
        AUTONOMOUS=true
    else
        echo "  ❌ Missing autonomous work philosophy" | tee -a "$LOG_FILE"
        AUTONOMOUS=false
    fi
    
    # Check NAWS or nighttime work reference
    if grep -q -i "NAWS\|nighttime.*work\|nighttime.*autonomous" "$AGENT_FILE"; then
        echo "  ✅ NAWS/autonomous work reference" | tee -a "$LOG_FILE"
        NAWS_REF=true
    else
        echo "  ❌ Missing NAWS/autonomous work reference" | tee -a "$LOG_FILE"
        NAWS_REF=false
    fi
    
    # Check agent-specific customization markers
    if grep -q "AGENT-SPECIFIC\|AGENT‑SPECIFIC" "$AGENT_FILE"; then
        echo "  ✅ Agent-specific customization markers" | tee -a "$LOG_FILE"
        MARKERS=true
    else
        echo "  ⚠️  Missing agent-specific customization markers (can be added later)" | tee -a "$LOG_FILE"
        MARKERS=true  # Don't fail compliance for this
    fi
    
    # Determine compliance
    if [ "$V3_VERSION" = true ] && [ $REASONING_COUNT -ge 3 ] && [ "$AUTONOMOUS" = true ] && [ "$MARKERS" = true ]; then
        echo "  🎯 COMPLIANCE: ✅ v3.0.0 COMPLIANT" | tee -a "$LOG_FILE"
        COMPLIANT_AGENTS+=("$agent")
    else
        echo "  🎯 COMPLIANCE: ❌ NON-COMPLIANT" | tee -a "$LOG_FILE"
        NON_COMPLIANT_AGENTS+=("$agent")
        
        # List specific compliance issues
        echo "    Issues:" | tee -a "$LOG_FILE"
        [ "$V3_VERSION" = false ] && echo "    - Not v3.0.0 version" | tee -a "$LOG_FILE"
        [ $REASONING_COUNT -lt 3 ] && echo "    - Missing reasoning framework questions ($REASONING_COUNT/5)" | tee -a "$LOG_FILE"
        [ "$AUTONOMOUS" = false ] && echo "    - Missing autonomous work philosophy" | tee -a "$LOG_FILE"
        [ "$NAWS_REF" = false ] && echo "    - Missing NAWS/autonomous work reference" | tee -a "$LOG_FILE"
        [ "$MARKERS" = false ] && echo "    - Missing agent-specific customization markers" | tee -a "$LOG_FILE"
    fi
done

echo "" | tee -a "$LOG_FILE"
echo "=== v3.0.0 COMPLIANCE SUMMARY ===" | tee -a "$LOG_FILE"
echo "Compliant agents: ${#COMPLIANT_AGENTS[@]} (${COMPLIANT_AGENTS[*]})" | tee -a "$LOG_FILE"
echo "Non-compliant agents: ${#NON_COMPLIANT_AGENTS[@]} (${NON_COMPLIANT_AGENTS[*]})" | tee -a "$LOG_FILE"

# Generate system event if non-compliant agents
if [ ${#NON_COMPLIANT_AGENTS[@]} -gt 0 ]; then
    echo "" | tee -a "$LOG_FILE"
    echo "⚠️  v3 COMPLIANCE ALERT: ${#NON_COMPLIANT_AGENTS[@]} agents not v3.0.0 compliant" | tee -a "$LOG_FILE"
    echo "Non-compliant: ${NON_COMPLIANT_AGENTS[*]}" | tee -a "$LOG_FILE"
    
    # Create detailed system event
    SYSTEM_EVENT="[WORKFLOW_V3_COMPLIANCE] ${#NON_COMPLIANT_AGENTS[@]} agents not v3.0.0 compliant: ${NON_COMPLIANT_AGENTS[*]}. Full compliance report: $LOG_FILE"
    echo "SYSTEM_EVENT: $SYSTEM_EVENT" | tee -a "$LOG_FILE"
else
    echo "" | tee -a "$LOG_FILE"
    echo "✅ All agents v3.0.0 compliant!" | tee -a "$LOG_FILE"
fi

echo "" | tee -a "$LOG_FILE"
echo "Check complete. Log saved to $LOG_FILE" | tee -a "$LOG_FILE"

# Calculate and display compliance score
TOTAL_AGENTS=$(echo "$AGENTS" | wc -w)
COMPLIANCE_PERCENTAGE=$(( ${#COMPLIANT_AGENTS[@]} * 100 / $TOTAL_AGENTS ))
echo "" | tee -a "$LOG_FILE"
echo "📊 Compliance Score: $COMPLIANCE_PERCENTAGE% (${#COMPLIANT_AGENTS[@]}/$TOTAL_AGENTS agents)" | tee -a "$LOG_FILE"

# Exit with appropriate code (0 if all compliant, 1 if not)
if [ ${#NON_COMPLIANT_AGENTS[@]} -eq 0 ]; then
    exit 0
else
    exit 1
fi