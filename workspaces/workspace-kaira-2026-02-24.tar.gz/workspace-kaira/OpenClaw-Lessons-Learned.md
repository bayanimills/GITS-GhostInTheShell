# OpenClaw Lessons Learned & Best Practices
## Comprehensive Analysis for Article Development
**Generated**: 2026-02-21 22:00 UTC  
**Timeframe**: 2026-02-05 to 2026-02-21  
**Source**: Kaira's memory files, evolution report, operational experience

---

## Executive Summary

OpenClaw deployment has yielded rich operational insights across system configuration, multi-agent coordination, automation design, and user context management. This document distills lessons into actionable guidance for future implementations, article development, and system optimization. Key themes: **diagnostic rigor**, **gradual automation**, **context preservation**, and **user-centric adaptation**.

---

## 1. What Worked (and Why)

### **System Diagnostics & Troubleshooting**
- **✅ Module Dependency Tracing**: Systematically following Node.js require stack to identify missing files
  - *Why it worked*: Direct path to root cause vs. symptom treatment
  - *Example*: Missing `highlight.js/gml.js` identified via stack trace, fixed with minimal language definition
- **✅ Corrupted Cache Identification**: Recognizing package manager cache corruption patterns
  - *Why it worked*: Distinguishing between missing packages vs. corrupted installations
  - *Example*: pnpm module not found → corepack cache corruption → reinitialization

### **Multi-Agent Coordination**
- **✅ Clear Role Definitions**: Delegation agent (Kaira) vs. Coordinator (Jarvis) vs. Specialists (Aria, Shelley)
  - *Why it worked*: Eliminated ambiguity in task assignment and responsibility boundaries
  - *Example*: Geopolitical monitoring request → Jarvis coordination → API key resolution
- **✅ Escalation Protocols**: Structured paths for technical issue resolution
  - *Why it worked*: Prevented stagnation when agent lacked permissions or access
  - *Example*: Brave API key missing → Jarvis contact → environment update → gateway restart

### **Automation Design**
- **✅ Cron + System Notification Pattern**: Scheduled jobs triggering timestamped system events
  - *Why it worked*: Independent of session state, created audit trail, ensured eventual execution
  - *Example*: Geopolitical monitoring checks scheduled via cron, delivered as system notifications
- **✅ Sleep-Aware Alerting**: Respecting user timezone (UTC+11) and sleep window (12:00-20:00 UTC)
  - *Why it worked*: Balanced information delivery with user comfort and attention capacity
  - *Example*: Critical alerts only during sleep hours, full reports outside sleep window

### **Memory & Documentation**
- **✅ Hierarchical Memory System**: Daily logs → curated long-term memory → git-backed version control
  - *Why it worked*: Preserved context across sessions, enabled pattern recognition
  - *Example*: Memory files from Feb 5-21 provided complete evolution narrative
- **✅ Pre-Compaction Memory Flushes**: Forced documentation before context loss
  - *Why it worked*: Captured operational decisions and system state at critical junctures
  - *Example*: Multiple memory flushes documented model configuration changes and verification steps

### **Model Management**
- **✅ Smoke Testing Protocol**: Isolated sub-agent sessions for model verification
  - *Why it worked*: Safe testing environment without disrupting operational systems
  - *Example*: Kimi K2.5 tested via isolated session, confirmed functional before potential migration
- **✅ Alias System Utilization**: Abstract model references for flexible upgrades
  - *Why it worked*: Decoupled agent configuration from specific model versions
  - *Example*: Alias "kimi" redirected from K2-instruct to K2.5 without agent reconfiguration

---

## 2. What Didn't Work (and Why)

### **Assumption-Based Configuration**
- **❌ Timezone Assumption**: Initially assumed UTC+8 (Philippines) instead of UTC+11 (Sydney)
  - *Why it failed*: Inferred from limited context rather than verification
  - *Impact*: Incorrect sleep window calculation for alert protocols
  - *Fix*: USER.md update with verified timezone, sleep window recalculation

### **Direct Agent Communication**
- **❌ Sessions_send Timeout**: Attempt to contact Jarvis via direct session message
  - *Why it failed*: Session not immediately responsive, timeout mechanism inadequate
  - *Impact*: Delayed API key resolution for geopolitical monitoring
  - *Fix*: System notification pattern (cron + event) proved more reliable

### **Notification Timing**
- **❌ Delayed System Notifications**: Scheduled checks (14:30 UTC) delivered hours late (19:42 UTC)
  - *Why it happened*: System queueing or delivery mechanism variability
  - *Impact*: Reduced timeliness of geopolitical monitoring
  - *Mitigation*: Pattern still effective (eventual execution), but timing imprecise

### **Query Optimization**
- **❌ Generic Search Queries**: Initial geopolitical searches returned outdated or analytical content
  - *Why it failed*: Missing temporal specificity and urgency indicators
  - *Impact*: Reduced relevance of monitoring results
  - *Fix*: Added "today news" and "breaking" to queries for timeliness

---

## 3. Skills Developed (Most Impactful First)

### **Tier 1: Core Operational Skills**
1. **System Diagnostics**: Tracing dependencies, identifying root causes, applying targeted fixes
2. **Configuration Management**: Safe updates via `config.patch`, gateway restart coordination
3. **Memory Continuity**: Hierarchical documentation, pre-compaction flushes, git backups
4. **Multi-Agent Coordination**: Role clarity, escalation protocols, handoff documentation

### **Tier 2: Automation & Monitoring**
5. **Scheduled Automation**: Cron job design, system notification integration, audit trail creation
6. **Geopolitical Monitoring**: Event categorization, urgency assessment, sleep-aware alerting
7. **API Integration**: Key management, environment configuration, tool verification
8. **Workflow Pattern Design**: From n8n skills - idempotency, error handling, human review queues

### **Tier 3: Advanced Configuration**
9. **Model Management**: Provider configuration, alias systems, smoke testing protocols
10. **Context Window Optimization**: Balancing capability vs. cost, user preference integration
11. **System Governance**: Canonical reference systems, validation scripts, pre-commit hooks
12. **User Context Development**: Progressive refinement of timezone, preferences, communication style

### **Tier 4: Strategic Patterns**
13. **Evolution Analysis**: Pattern recognition across time blocks, capability progression mapping
14. **Article Development**: Structuring lessons learned for external consumption
15. **Recommendation Formulation**: Prioritized improvement pathways based on operational evidence

---

## 4. Do's and Don'ts (Actionable Guidance)

### **DO: System Configuration**
- ✅ **DO use `config.patch` for safe incremental updates** (validates, merges, restarts)
- ✅ **DO implement smoke tests for model changes** (isolated sessions prevent disruption)
- ✅ **DO maintain alias systems for model references** (enables seamless upgrades)
- ✅ **DO verify environment variables AND config file settings** (some tools require both)

### **DON'T: System Configuration**
- ❌ **DON'T assume module availability without verification** (check require stack)
- ❌ **DON'T guess user timezone or preferences** (update USER.md with verified data)
- ❌ **DON'T make configuration changes without backup/rollback plan**
- ❌ **DON'T rely on single notification delivery mechanism** (cron + events = resilience)

### **DO: Automation Design**
- ✅ **DO combine cron schedules with system notifications** (audit trail + execution guarantee)
- ✅ **DO implement sleep-aware alerting based on verified user schedule**
- ✅ **DO design for idempotency and safe retries** (from n8n workflow patterns)
- ✅ **DO include human review queues for critical decisions** (balance automation with oversight)

### **DON'T: Automation Design**
- ❌ **DON'T create "silent failure" scenarios** (implement failure detection and alerts)
- ❌ **DON'T ignore timezone implications for scheduled tasks**
- ❌ **DON'T assume query optimization isn't needed** (refine for timeliness and relevance)
- ❌ **DON'T overlook audit trail requirements** (documentation enables debugging and improvement)

### **DO: Memory & Documentation**
- ✅ **DO implement hierarchical memory system** (daily logs → curated memory → git backup)
- ✅ **DO perform pre-compaction memory flushes** (preserve context before loss)
- ✅ **DO tag entries consistently** (enables search and pattern recognition)
- ✅ **DO review and distill learnings periodically** (weekly reviews, monthly audits)

### **DON'T: Memory & Documentation**
- ❌ **DON'T rely on "mental notes"** (write everything to files)
- ❌ **DON'T mix operational logs with strategic insights** (separate daily from curated memory)
- ❌ **DON'T neglect git backup verification** (check remote connectivity, commit history)
- ❌ **DON'T postpone documentation** (immediate capture prevents context loss)

### **DO: Agent Coordination**
- ✅ **DO maintain clear role definitions and boundaries**
- ✅ **DO establish escalation protocols for technical issues**
- ✅ **DO create handoff documentation for task continuity**
- ✅ **DO respect autonomy levels** (delegation vs. coordination vs. execution)

### **DON'T: Agent Coordination**
- ❌ **DON'T bypass coordinator for user communication** (unless explicitly instructed)
- ❌ **DON'T assume agent availability** (design for asynchronous collaboration)
- ❌ **DON'T neglect relationship building** (trust enables more complex coordination)
- ❌ **DON'T duplicate capabilities across agents** (specialization creates efficiency)

---

## 5. Patterns & Anti-patterns

### **Effective Patterns (Repeat)**
1. **Diagnostic Rigor**: Stack trace → root cause → minimal fix → verification
2. **Gradual Automation**: Manual check → scheduled check → refined monitoring → predictive alerting
3. **Context Preservation**: Immediate documentation → periodic distillation → long-term curation
4. **User-Centric Adaptation**: Assumption → verification → refinement → protocol adjustment
5. **Resilience Design**: Multiple execution pathways, eventual consistency, audit trails

### **Anti-patterns (Avoid)**
1. **Assumption-Based Configuration**: Guessing instead of verifying user context
2. **Direct Dependency**: Tight coupling between agents or tools without abstraction layers
3. **Silent Automation**: Tasks that can fail without detection or alerting
4. **Context Fragmentation**: Disconnected memory systems that prevent pattern recognition
5. **Role Ambiguity**: Unclear boundaries leading to duplicated effort or gaps

### **Pattern Evolution**
- **From**: Reactive troubleshooting → **To**: Proactive monitoring
- **From**: Isolated agent tasks → **To**: Coordinated multi-agent workflows
- **From**: Basic documentation → **To**: Hierarchical memory with curation
- **From**: Manual configuration → **To**: Smoke-tested, alias-managed updates
- **From**: Timezone assumptions → **To**: Verified, sleep-aware scheduling

---

## 6. System Design Insights

### **Architecture Principles Emergent**
1. **Layered Resilience**: Multiple independent execution pathways (cron, notifications, manual)
2. **Progressive Disclosure**: Simple interfaces that reveal complexity only when needed
3. **Context Preservation**: Memory systems designed for session continuity and learning
4. **User-Centric Automation**: Scheduling and alerting that respects human patterns
5. **Coordinated Specialization**: Agents with clear roles collaborating through defined protocols

### **Technical Implementation Insights**
- **Notification Reliability**: System events more reliable than direct agent messaging
- **Configuration Safety**: `config.patch` provides validation and controlled restarts
- **Model Management**: Aliases enable seamless upgrades without agent reconfiguration
- **Tool Integration**: Some tools require both config file AND environment variables
- **Backup Strategy**: Git provides version control, but remote connectivity needs verification

### **Human Factors Considerations**
- **Sleep Schedule Integration**: Critical for user acceptance of automated monitoring
- **Alert Fatigue Prevention**: Tiered urgency system prevents notification overload
- **Autonomy Boundaries**: Clear delegation limits build trust and prevent overreach
- **Learning Curve Management**: Progressive capability expansion matches user comfort

---

## 7. Article Outline Suggestions

### **Article 1: "OpenClaw Deployment: Lessons from the Trenches"**
- **Focus**: Practical implementation challenges and solutions
- **Sections**:
  1. The Module Dependency Mystery (diagnostic approach)
  2. Timezone Troubles: Why Assumptions Cost Us
  3. Cron + Events: The Resilient Automation Pattern
  4. Memory Systems That Actually Work
  5. Multi-Agent Coordination Without Chaos
- **Target Audience**: Technical implementers, DevOps teams

### **Article 2: "Building a Geopolitical Monitoring Agent"**
- **Focus**: Specialized agent development case study
- **Sections**:
  1. Defining Monitoring Scope: Bitcoin, Asia-Pacific, Global Conflicts
  2. API Integration: Brave Search Configuration Lessons
  3. Sleep-Aware Alerting: Respecting Human Patterns
  4. Query Optimization: From Generic to Timely Results
  5. Urgency Categorization: Developing Judgment for Alerts
- **Target Audience**: Monitoring system designers, intelligence analysts

### **Article 3: "Model Management in Multi-Agent Systems"**
- **Focus**: AI model configuration and migration strategies
- **Sections**:
  1. Provider Configuration: NVIDIA Kimi K2.5 Case Study
  2. Alias Systems: Enabling Seamless Upgrades
  3. Smoke Testing Protocols: Safe Verification Before Deployment
  4. Context Window Optimization: Balancing Capability and Cost
  5. Coordinated Model Updates Across Multiple Agents
- **Target Audience**: AI system administrators, ML engineers

### **Article 4: "Memory Systems for AI Agents"**
- **Focus**: Context preservation and continuity strategies
- **Sections**:
  1. Hierarchical Memory: Daily Logs → Curated Memory → Git Backup
  2. Pre-Compaction Flushes: Capturing Context Before Loss
  3. Tagging Systems: Enabling Search and Pattern Recognition
  4. Evolution Analysis: Learning from Your Agent's History
  5. From Memory to Improvement: Closing the Learning Loop
- **Target Audience**: AI researchers, agent system designers

### **Article 5: "Workflow Patterns from n8n for Agent Automation"**
- **Focus**: Applying enterprise workflow principles to agent systems
- **Sections**:
  1. Idempotency: Safe Retry Behavior for Automated Tasks
  2. Error Handling: Per-Node Branches and Backoff Strategies
  3. Observability: Run IDs, Logging, and Status Tracking
  4. Human-in-the-Loop: Review Queues for Critical Decisions
  5. "No Silent Failure" Gates: Threshold Monitoring and Alerts
- **Target Audience**: Automation engineers, workflow designers

---

## 8. Implementation Roadmap for New Deployments

### **Phase 1: Foundation (Week 1)**
1. Identity files (SOUL.md, IDENTITY.md, USER.md)
2. Memory system setup (daily logs, MEMORY.md, git initialization)
3. Basic diagnostics and troubleshooting protocols
4. Agent role definitions and coordination boundaries

### **Phase 2: Core Automation (Week 2-3)**
5. Scheduled monitoring systems (cron + notifications)
6. Sleep-aware alerting based on verified user schedule
7. API integration and tool configuration
8. Basic workflow patterns (idempotency, error handling)

### **Phase 3: Advanced Capabilities (Week 4-6)**
9. Model management systems (aliases, smoke testing)
10. Hierarchical memory curation and periodic reviews
11. Multi-agent workflow coordination
12. Predictive monitoring and pattern recognition

### **Phase 4: Optimization & Scaling (Week 7-12)**
13. System governance (canonical references, validation)
14. Advanced workflow patterns from n8n
15. Cross-agent knowledge sharing
16. Evolution analysis and continuous improvement

---

## Conclusion

OpenClaw's evolution demonstrates that successful agent systems require:
1. **Diagnostic Rigor** over quick fixes
2. **Gradual Automation** over immediate complexity
3. **Context Preservation** over session isolation
4. **User-Centric Design** over technical perfection
5. **Coordinated Specialization** over monolithic agents

The lessons captured here provide actionable guidance for new deployments, optimization of existing systems, and article development for the broader community. Each challenge encountered yielded patterns that can be replicated, and each failure revealed anti-patterns to avoid.

**Next Steps**:
1. Select priority articles based on target audience
2. Expand specific sections with detailed examples and code snippets
3. Develop companion code repositories or configuration templates
4. Schedule periodic reviews to capture new learnings

**Document Status**: ✅ COMPREHENSIVE OUTLINE COMPLETE  
**Ready For**: Article development, implementation guidance, training materials