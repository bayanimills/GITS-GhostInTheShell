#!/usr/bin/env python3
import sys

def read_file(path):
    with open(path, 'r') as f:
        return f.read()

def write_file(path, content):
    with open(path, 'w') as f:
        f.write(content)

def main():
    script_path = 'bootstrap-agent.sh'
    new_block_path = 'new_report_block.txt'
    
    content = read_file(script_path)
    new_block = read_file(new_block_path)
    
    # Find start and end indices
    start = content.find('## Configuration Status\n')
    if start == -1:
        print("Start not found")
        sys.exit(1)
    
    # Find the next section
    end = content.find('## Self-Test Results', start)
    if end == -1:
        print("End not found")
        sys.exit(1)
    
    # Replace from start to end (end is start of the line "## Self-Test Results")
    new_content = content[:start] + new_block + content[end:]
    
    write_file(script_path, new_content)
    print("Report block updated")

if __name__ == '__main__':
    main()