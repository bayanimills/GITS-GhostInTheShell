# WORKFLOW_AUTO.md - Agent Automation Framework & Template
## Version: 2.0.0 | Created: 2026-02-22 | Status: ✅ TEMPLATE/ACTIVE
**Purpose**: This file serves dual purposes:
1. **Default Template**: When agents lack their own WORKFLOW_AUTO.md, they read this file as a template
2. **Master Reference**: Contains standardized workflow documentation patterns for all agents

## 📋 HOW TO USE THIS FILE

### **IF YOU ARE READING THIS DURING POST‑COMPACTION AUDIT:**
You're reading the default template because your agent doesn't have its own `WORKFLOW_AUTO.md` file yet. Follow these steps:

### **Quick Start Guide for New Agents:**
1. **Copy to Your Workspace**: `cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md /home/agent/.openclaw/workspace-[YOUR_NAME]/WORKFLOW_AUTO.md`
2. **Customize**: Replace `[AGENT_NAME]`, `[YOUR_ROLE]`, and all placeholder sections with your specific content
3. **Implement**: Follow the Implementation Plan in the document
4. **Test**: Run validation steps before full automation deployment
5. **Maintain**: Update regularly as your workflows evolve

### **For Agents With Existing WORKFLOW_AUTO.md:**
Compare your file with this template monthly to:
1. Adopt useful new sections or patterns
2. Ensure consistency with system standards
3. Contribute improvements back to this master template

### Template Conventions:
- `[BRACKETED_TEXT]`: Replace with your specific content
- `<!-- COMMENT -->`: Instructional notes (remove when customizing)
- `✅`, `⚠️`, `❌`: Status indicators (maintain this visual language)
- `#tags`: Use consistent tagging for searchability

---

## 🎯 OVERVIEW & AGENT CONTEXT

<!-- Replace this entire section with your agent's specific context -->
**Agent Name**: `Doc` (Aloysius Bexley)  
**Primary Role**: Patient Care Coordination & Medical Data Management  
**Domain Focus**: Edward William Mills (DOB: 1934‑07‑19) – aged‑care transition, stroke recovery, end‑of‑life planning, Notion‑Dart sync, automated reminders  
**Timezone**: `Australia/Sydney`  

**Purpose**: This document defines automated workflows for `Doc`. Workflows are scheduled or triggered events that execute without user intervention, ensuring consistent monitoring, reporting, and system maintenance within the patient‑care domain.

**Ecosystem Alignment**: 🟢 `Patient‑Care`‑FOCUSED

---

## ⚠️ IMPORTANT GUIDELINES

### **DO NOT MODIFY** (Core Structural Elements):
<!-- These elements should remain consistent across all agents for system interoperability -->
- Cron job schedule format and payload structure
- Heartbeat trigger conditions and response patterns  
- Memory flush protocols (pre/post-compaction)
- Git auto‑commit configuration
- Error handling escalation levels
- Template section headers and organization

### **SAFE TO MODIFY** (Agent-Specific Customizations):
<!-- Customize these for your specific domain and workflows -->
- Agent name, role, and domain focus
- Scheduled workflow timings and frequencies
- Script paths and command parameters  
- Alert thresholds and notification channels
- Reporting detail levels and formats
- Domain-specific directories and file structures
- New workflow additions (following template structure)

### **ADDING NEW WORKFLOWS** (Standard Process):
<!-- Follow this process when adding any new automation -->
1. **Define Purpose & Business Value**: What problem does this solve?
2. **Specify Trigger**: Cron schedule, event condition, or manual trigger
3. **Document Payload/Actions**: Exact commands, scripts, or agent messages
4. **Set Error Handling**: Failure modes, retry logic, alerting
5. **Test in Isolation**: Run in isolated session before production
6. **Update This Document**: Add workflow to appropriate section
7. **Deploy & Monitor**: Schedule execution and track performance

---

## 🔄 SCHEDULED CRON WORKFLOWS

<!-- Replace with your agent's scheduled cron jobs -->
<!-- Format each workflow as shown below -->

### **1. Edward Mills Daily Standup**
- **Schedule**: `0 8 * * *` (8:00 AM Sydney daily)
- **Agent**: `Doc` (isolated session)
- **Payload**: `dashboard_report.py` – generates consolidated patient dashboard (tasks, appointments, stale alerts)
- **Purpose**: Provide morning overview of Edward Mills' status, upcoming appointments, pending tasks.
- **Content/Output**: Markdown report with links to Dart tasks, Notion databases, next appointment.
- **Delivery**: Telegram message to user (target: 548072941) via announce delivery.
- **Status**: ✅ ACTIVE (Job ID: `a6ece971‑5b58‑4758‑a48e‑b99259f11dd9`)

### **2. Edward Mills Notion Sync**
- **Schedule**: `0 9 * * *` (9:00 AM Sydney daily)
- **Agent**: `Doc` (isolated session)
- **Payload**: `sync_dart_to_notion.py` – fetches Dart tasks tagged `patient‑edward‑mills`, `stroke‑followup`, or subtasks of stroke parent task; updates Notion Patient Tasks database.
- **Purpose**: Keep Notion as single source of truth for patient tasks, synced from Dart.
- **Content/Output**: Log of tasks created/updated in Notion.
- **Delivery**: File storage (`logs/sync‑YYYY‑MM‑DD.log`); Telegram notification on error.
- **Status**: ✅ ACTIVE (Job ID: `c5a1bcd9‑ef7f‑4b6e‑9ba9‑c96688f6953d`)

### **3. Aged‑Care Database Daily Check**
- **Schedule**: `0 8 * * *` (8:00 AM Sydney daily)
- **Agent**: `Doc` (isolated session)
- **Payload**: `aged_care_daily_check.py` – monitors Northern Beaches Nursing Homes Notion database for changes (new entries, updates).
- **Purpose**: Ensure nursing‑home data remains current; alert if changes detected.
- **Content/Output**: Status message "No changes detected" or summary of changes.
- **Delivery**: Log file; Telegram notification only if changes found.
- **Status**: ✅ ACTIVE (Job ID: `74414eb9‑d56e‑4ffa‑b6d9‑8d1ce7916a9b`)

### **4. Stroke Task Weekly Check**
- **Schedule**: `0 0 * * 0` (Sunday 00:00 Sydney, weekly)
- **Agent**: `Doc` (isolated session)
- **Payload**: Checks stroke parent task `YhH8uggrObRf` in Dart for staleness (>7 days without update); alerts if stale.
- **Purpose**: Ensure stroke‑follow‑up tasks remain active and updated.
- **Content/Output**: Alert message if stale; otherwise silent.
- **Delivery**: Telegram notification if stale.
- **Status**: ✅ ACTIVE (Job ID: `d67388c4‑d9ce‑4d6f‑a869‑ea999c581291`)

### **5. Edward Mills Weekly Review**
- **Schedule**: `0 9 * * 0` (Sunday 9:00 AM Sydney)
- **Agent**: `Doc` (isolated session)
- **Payload**: `weekly_review.py` – generates extended dashboard with end‑of‑life task status, weekly metrics.
- **Purpose**: Weekly strategic review of patient progress, legal/medical task completion.
- **Content/Output**: Extended markdown report.
- **Delivery**: Telegram message to user.
- **Status**: ✅ ACTIVE (Job ID: `0ca9dc63‑b4cd‑47ef‑8207‑1dce16d35cab`)

### **6. Automated Data Backup**
- **Schedule**: `0 22 * * 6` (Saturday 22:00 Sydney)
- **Agent**: `Doc` (isolated session)
- **Payload**: `backup_patient_data.py` – exports Notion databases to `backups/notion/`, fetches Dart tasks via API to `backups/dart/`.
- **Purpose**: Regular backup of patient data for disaster recovery.
- **Content/Output**: Compressed archives in dated directories.
- **Delivery**: File storage only.
- **Status**: ✅ ACTIVE (Job ID: `3ffc77d6‑c251‑4da1‑855f‑baf2bf364df3`)

### **7. End‑of‑Life Reminders**
- **Schedule**: Various one‑shot jobs (palliative care assessment 2026‑02‑24, high‑priority legal tasks 2026‑02‑28)
- **Agent**: `Doc` (isolated session)
- **Payload**: Telegram reminder messages for critical deadlines.
- **Purpose**: Ensure time‑sensitive legal/medical tasks are not missed.
- **Content/Output**: "Reminder: [task description]" Telegram message.
- **Delivery**: Telegram announce.
- **Status**: ✅ ACTIVE (Job IDs: palliative `nU67ySKCHyED`, legal tasks `v9xc8FDPj37G`, `XSubroMB3jZ2`, `JzVc6QAxnLFF`)

### **Template Notes for Cron Workflows:**
- Use isolated sessions for resource-intensive or long-running tasks
- Main sessions for quick checks and user notifications
- Include Job IDs from `cron list` command for reference
- Document timezone explicitly (cron uses system timezone)

### **Pending Decisions**
- **Cron message duplication**: Awaiting user preference on three presented options:
  1. Keep system‑event only (current behavior).
  2. Add `systemEvent` + isolated agent‑turn duplicate (double notification).
  3. Replace with isolated agent‑turn only (recommended reliable pattern).
- **Skill test**: Possible test of `reliable‑reminders` skill with a harmless one‑minute reminder.

---



## 🔄 EVENT‑TRIGGERED WORKFLOWS

<!-- These workflows respond to system events, not schedules -->

### **1. Pre‑Compaction Memory Flush**
<!-- DO NOT MODIFY - System protocol -->
- **Trigger**: System memory compaction event (before context reset)
- **Action**: Append durable session memories to `memory/YYYY‑MM‑DD.md`
- **Purpose**: Preserve insights, decisions, and reflections before context loss
- **Protocol**: APPEND only (never overwrite), include timestamp and tags
- **Location**: `memory/` directory with date‑based filenames
- **Status**: ✅ SYSTEM_PROTOCOL

### **2. Post‑Compaction Audit & Protocol Restoration**
<!-- DO NOT MODIFY - System protocol -->
- **Trigger**: System post‑compaction audit notification
- **Action**: Read required startup files (`WORKFLOW_AUTO.md`, `memory/YYYY‑MM‑DD.md`)
- **Purpose**: Restore operating protocols after memory compaction
- **Files**:
  - `WORKFLOW_AUTO.md` (this file) – workflow definitions
  - `memory/YYYY‑MM‑DD.md` – recent daily logs
- **Outcome**: ✅ Protocols restored, system ready for continued monitoring
- **Status**: ✅ SYSTEM_PROTOCOL

### **3. User Request for Reminder**
<!-- Add your own event-triggered workflows here -->
- **Trigger**: User message containing "remind me to" or explicit request for reminder
- **Action**: Execute `scripts/set_reminder.py` with parsed text and time
- **Purpose**: Provide reliable Telegram reminders using isolated agent‑turn + announce pattern
- **Status**: ✅ ACTIVE (via `reliable‑reminders` skill)

---

## 🔄 CONDITIONAL WORKFLOWS

<!-- Workflows that run based on conditions, not fixed schedules -->

### **1. Medication Reconciliation Alert**
- **Condition**: Detection of new medical correspondence (e.g., PDF upload) containing medication list
- **Action**: Extract medication list via OCR/Tesseract, compare with Notion Medications database, flag discrepancies
- **Threshold**: Any discrepancy (new medication, changed dose, discontinued)
- **Current Focus**: Edward Mills' current medications (6 drugs)
- **Exclusions**: Placeholder entries, historical documents
- **Status**: ⚠️ PLANNED (requires OCR integration)

### **2. Emergency Contact Verification**
- **Condition**: New contact added to Emergency Contacts database with missing critical fields (Phone, Relationship)
- **Action**: Flag incomplete entry for manual review
- **Threshold**: Missing required fields (Phone, Name)
- **Current Focus**: 3 primary contacts (Belinda Whittiker, Rafaela Garth, Brent Garth)
- **Exclusions**: Notes-only entries
- **Status**: ⚠️ PLANNED

### **Template Notes for Conditional Workflows:**
- Conditions should be objectively measurable
- Include configurable thresholds for tuning sensitivity
- Document exclusions based on user corrections (tenacious rules)
- Track false positive rates for optimization

---

## 🧠 PRE‑COMPACTION AUTONOMOUS TASKS

<!-- NEW SECTION: Tasks agents can work on autonomously during idle periods -->
<!-- These tasks are executed during pre-compaction memory flushes or idle heartbeats -->

### **Autonomous Work Philosophy**
Agents should use available capacity to:
1. **Improve System Health**: Proactive maintenance, cleanup, optimization
2. **Enhance Domain Knowledge**: Research, analysis, pattern recognition  
3. **Prepare for Future Work**: Resource gathering, data organization
4. **Learn & Adapt**: Review past executions, identify improvements

### **Autonomous Task Categories**

#### **A. System Maintenance Tasks** (Always Safe)
- **Memory File Cleanup**: Archive old daily logs > 30 days
- **Directory Organization**: Ensure consistent folder structures
- **Log File Rotation**: Compress or delete old execution logs
- **Configuration Validation**: Check config files for errors
- **Backup Verification**: Test backup/restore procedures

#### **B. Domain‑Specific Enhancement Tasks** (Role‑Dependent)
- **Patient Data Review**: Analyze Edward Mills' task completion trends, identify bottlenecks
- **Medical Research**: Gather information on stroke recovery, aged‑care transition, palliative care
- **Documentation Updates**: Improve patient‑facing guides (medication registry, home safety checklist)
- **Template Creation**: Build reusable templates for medical correspondence, ACAT referrals
- **Skill Development**: Practice OCR extraction, Notion API integration, Dart automation

#### **C. Preparation & Readiness Tasks** (Forward‑Looking)
- **Resource Gathering**: Collect Northern Beaches nursing‑home brochures, ACAT forms
- **Template Preparation**: Set up structures for anticipated medical appointments
- **Connection Testing**: Verify Notion, Dart API connectivity
- **Dependency Checking**: Ensure required Python packages are available
- **Scenario Planning**: Develop contingency plans for hospital admission, emergency contact escalation

### **Autonomous Task Selection Algorithm**
During pre‑compaction or idle periods:
1. **Check Available Time**: Estimate time until next scheduled task
2. **Assess System Load**: Consider CPU/memory/network availability
3. **Prioritize by Category**: Maintenance > Enhancement > Preparation
4. **Select Appropriate Task**: Match task complexity to available capacity
5. **Execute & Document**: Complete task, update memory with results

### **Autonomous Feedback Loop Implementation**
<!-- How autonomous tasks create self-improving systems -->
1. **Task Execution**: Complete autonomous work
2. **Result Evaluation**: Measure success/impact
3. **Pattern Recognition**: Identify what works well
4. **Workflow Integration**: Convert successful patterns to automated workflows
5. **Template Updates**: Improve this section based on learnings

### **Safety Boundaries for Autonomous Work**
- **NO Destructive Actions**: Never delete patient data without user confirmation
- **NO External Communication**: Don't contact healthcare providers, family members without approval
- **NO Configuration Changes**: Don't modify system/agent configs autonomously
- **YES Internal Optimization**: File organization, cleanup, analysis, preparation
- **YES Learning & Documentation**: Pattern recognition, guide improvement

### **Example Autonomous Tasks for Doc Agent**
- **Review weekly task completion rates**: Identify which follow‑up tasks are consistently delayed
- **Research aged‑care subsidy changes**: Stay current on Australian government aged‑care funding
- **Organize medical document archive**: Sort uploaded PDFs by date, type, relevance
- **Test OCR accuracy on medical letters**: Improve extraction of medication lists, doctor notes
- **Prepare ACAT referral packet**: Gather required forms, patient details, medical history summary

---

## ⚠️ ERROR HANDLING & RECOVERY

### **Standard Failure Modes & Responses**
<!-- Customize thresholds and alerts for your domain -->
1. **Cron Job Failure**:
   - Retry once after 5 minutes (configurable)
   - Log error to `logs/cron‑errors‑YYYY‑MM‑DD.log`
   - Telegram alert if consecutive failures > 3
   - Escalate to user after > 5 failures in 24h

2. **Script Execution Error**:
   - Capture stderr to log file with timestamp
   - Continue with next workflow step if possible
   - Report error in next scheduled report or heartbeat
   - Create issue tracking in memory system

3. **Connectivity Issues**:
   - API/network timeouts → retry with exponential backoff (max 3 attempts)
   - External service failures → queue operations for later
   - Maximum retry attempts: 3 before manual intervention required

### **Lock Files & Concurrency Control**
- **Lock files**: Use for scripts that shouldn't run concurrently
- **Location**: `/tmp/` or workspace `logs/` directory
- **Naming**: `[SCRIPT_NAME].lock` (descriptive)
- **Timeout**: 30‑minute lock expiration (prevents deadlocks)
- **Cleanup**: Remove stale locks during system maintenance

### **Alert Escalation Levels**
1. **Level 1 (Log Only)**: Non‑critical errors, informational
2. **Level 2 (Notification)**: Business‑impacting issues, user should know
3. **Level 3 (Intervention)**: System‑critical failures, immediate action required
4. **Level 4 (Emergency)**: Security issues, data loss risks

### **Recovery Protocols**
- **Automated Recovery**: For known failure patterns with established fixes
- **Manual Review Required**: Flag for user attention with context
- **Fallback Procedures**: Alternative methods when primary fails
- **Data Preservation**: Ensure no data loss during recovery attempts

---

## 📈 WORKFLOW PERFORMANCE & AUTONOMOUS FEEDBACK LOOP

### **Target KPIs & Metrics**
<!-- Define what success looks like for your workflows -->
- **Cron job completion rate**: > 95% (target), < 80% (alert threshold)
- **Average execution time**: < 5 minutes per workflow (adjust for complexity)
- **Error rate**: < 5% total, < 2% false positives
- **User notification accuracy**: > 90% relevant, timely alerts
- **Autonomous task completion**: 2-5 tasks between scheduled work

### **Monitoring & Reporting Structure**
- **Daily**: Include workflow status in regular reports
- **Weekly**: Summarize performance, identify trends
- **Monthly**: Audit report with improvement recommendations
- **Quarterly**: Strategic review of workflow effectiveness

### **Autonomous Feedback Loop Implementation**
<!-- How the system improves itself based on execution data -->
1. **Data Collection**: Log all workflow executions with metrics
2. **Pattern Analysis**: Identify common failures, bottlenecks, successes
3. **Hypothesis Formation**: Propose improvements based on patterns
4. **Controlled Testing**: Implement changes in isolated environments
5. **Evaluation**: Measure impact of changes on KPIs
6. **Integration**: Roll out successful improvements to production
7. **Documentation**: Update workflows and templates with learnings

### **Continuous Improvement Cycle**
- **Feedback Sources**: User corrections, performance metrics, error logs
- **Protocol Updates**: Treat user corrections as tenacious protocol changes
- **Adaptation**: Adjust workflows based on domain ecosystem evolution
- **Innovation**: Identify opportunities for new automation based on patterns

---

## 🔧 TESTING & VALIDATION FRAMEWORK

### **Manual Test Commands**
<!-- Provide test commands for your specific workflows -->
```bash
# Test Template - Replace with your agent's test commands
# Test workflow execution (isolated session)
HEARTBEAT_TEST: Run full monitoring checklist now

# Test script execution
cd /home/agent/.openclaw/workspace‑doc && python3 scripts/sync_dart_to_notion.py --dry-run

# Test memory flush
echo "Test memory entry $(date)" >> memory/$(date +%Y‑%m‑%d).md
```

### **Validation Steps (Standard Process)**
1. **Isolated Session Test**: Run workflow in isolated agent session
2. **Output Verification**: Check files, logs, deliveries match expectations
3. **Error Simulation**: Test failure modes and recovery procedures
4. **Performance Benchmark**: Measure execution time, resource usage
5. **Integration Check**: Ensure compatibility with other workflows
6. **Documentation Update**: Update this file with test results

### **Performance Monitoring Infrastructure**
- **Execution logs**: `logs/workflow‑execution‑YYYY‑MM‑DD.log`
- **Resource tracking**: CPU, memory, network usage during runs
- **Timing metrics**: Start/end timestamps, duration tracking
- **Success/failure rates**: By workflow, by time period
- **Alert volume**: Notification frequency and accuracy

---

## 🚀 IMPLEMENTATION PLAN

<!-- Step-by-step guide for agents to implement this framework -->

### **Phase 1: Template Customization (Day 1)**
1. **Copy Template**: `cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md WORKFLOW_AUTO.md` (from master template to your workspace)
2. **Basic Customization**: Replace all `[BRACKETED]` placeholders
3. **Role Definition**: Clearly define your agent's purpose and domain
4. **Initial Workflows**: Document 1-2 existing or planned automations
5. **File Organization**: Set up required directories (logs/, scripts/, memory/)
6. **Validation**: Run `post-compaction audit` test to ensure protocol restoration works

### **Phase 2: Workflow Development (Week 1)**
1. **Schedule Mapping**: Identify natural rhythms for your domain (daily, weekly, etc.)
2. **Script Creation**: Develop scripts for repetitive tasks
3. **Cron Job Setup**: Use `cron add` to schedule workflows
4. **Error Handling**: Implement logging and alerting for each workflow
5. **Testing**: Run each workflow in isolation, verify outputs
6. **Documentation**: Update WORKFLOW_AUTO.md with exact configurations

### **Phase 3: Autonomous System Development (Week 2-3)**
1. **Pre‑Compaction Tasks**: Identify 3-5 safe autonomous tasks for your domain
2. **Feedback Loop Setup**: Implement metrics collection for workflow performance
3. **Pattern Recognition**: Review logs weekly to identify improvement opportunities
4. **Self‑Optimization**: Implement 1-2 autonomous improvements based on patterns
5. **Template Refinement**: Update your WORKFLOW_AUTO.md based on learnings

### **Phase 4: Mature Automation (Month 2+)**
1. **Cross‑Agent Coordination**: Identify collaboration opportunities with other agents
2. **Advanced Error Recovery**: Implement sophisticated failure handling
3. **Predictive Automation**: Develop workflows that anticipate needs
4. **Knowledge Sharing**: Contribute learnings to template improvements
5. **Scale Optimization**: Handle increased volume efficiently

### **Implementation Success Criteria**
- ✅ WORKFLOW_AUTO.md fully customized for your agent
- ✅ At least 3 scheduled workflows running reliably (>95% success)
- ✅ Pre‑compaction autonomous tasks being executed regularly
- ✅ Error handling catching and recovering from common failures
- ✅ Performance metrics being tracked and reviewed weekly
- ✅ User receiving appropriate notifications (not too many, not too few)

---

## 📝 CHANGE MANAGEMENT & VERSION CONTROL

### **Modifying This File (Your WORKFLOW_AUTO.md)**
1. **Version Update**: Increment version number appropriately (major.minor.patch)
2. **Change Documentation**: Document modifications in git commit message
3. **Isolation Testing**: Test modified workflows in isolated sessions
4. **Date Update**: Update "Last Updated" timestamp
5. **Backward Compatibility**: Ensure changes don't break existing workflows
6. **Communication**: Notify affected users/agents of significant changes

### **Version History Template**
- **v1.0.0**: Initial workflow definition based on template customization
- **v1.1.0**: Added `[NEW_WORKFLOW]` with error handling
- **v1.2.0**: Implemented autonomous task framework
- **v2.0.0**: Major restructuring based on [REASON]

### **Backup & Recovery Strategy**
- **Primary**: This file backed up via GITS auto‑commit system
- **Secondary**: Changes tracked in git history with descriptive commits
- **Tertiary**: Regular exports to Nextcloud or cloud storage
- **Recovery**: Previous versions available via `git log` and restore

### **Template Synchronization**
<!-- How to incorporate improvements from the master template -->
1. **Periodic Review**: Compare with the master template (`/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`) monthly
2. **Selective Adoption**: Incorporate useful new sections/patterns
3. **Customization Preservation**: Maintain your agent-specific content
4. **Contribution**: Share your improvements back to template maintainer

---

## 🔍 SYSTEM INTEGRATION POINTS

### **Post‑Compaction Audit Protocol**
- **Trigger**: System notification after memory compaction
- **Action**: Read `WORKFLOW_AUTO.md` + `memory/YYYY‑MM‑DD.md`
- **Purpose**: Restore operational context and workflow knowledge
- **Verification**: Check that all referenced scripts/files exist
- **Continuity**: Resume scheduled workflows from point of interruption

### **Heartbeat System Integration**
- **Schedule**: Defined in your agent's `HEARTBEAT.md` file
- **Checklist**: Include workflow status checks in heartbeat routine
- **Response**: `HEARTBEAT_OK` or alert with workflow issues
- **Proactive Work**: Use heartbeat intervals for autonomous tasks

### **Memory System Alignment**
- **Daily Logs**: `memory/YYYY‑MM‑DD.md` for execution records
- **Long‑Term Memory**: `MEMORY.md` for significant learnings
- **Workflow‑Specific**: Domain directories for specialized data
- **Tagging System**: Use consistent `#workflow‑*` tags for searchability

### **Multi‑Agent Coordination**
- **Dependency Awareness**: Document workflows that depend on other agents
- **Conflict Avoidance**: Schedule intensive tasks at different times
- **Resource Sharing**: Common scripts, templates, data sources
- **Communication Protocols**: Standardized notification formats

---

## 📊 STATUS & MAINTENANCE

**Maintenance Status**: ✅ ACTIVE  
**Next Scheduled Workflow**: `Edward Mills Daily Standup` at `08:00 Sydney (22:00 UTC)`  
**Last Validation**: `2026‑02‑22`  
**Next Template Review**: `2026‑03‑22` (compare with master template in `/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`)  
**Ecosystem Alignment**: 🟢 `Patient‑Care`‑FOCUSED  
**Pending Items**: Cron message duplication decision, possible reminder‑skill test.

**Autonomous Task Completion Rate**: `TBD`/week (track in memory logs)  
**Workflow Success Rate**: `TBD`% (last 30 days)  
**User Notification Accuracy**: `TBD`% (relevant vs. noise)  

---

## 🎯 FINAL CHECKLIST FOR AGENT IMPLEMENTATION

### **Before First Compaction:**
- [ ] WORKFLOW_AUTO.md fully customized with your agent's context
- [ ] All `[BRACKETED]` placeholders replaced with actual values
- [ ] At least one scheduled workflow documented and tested
- [ ] Required directories created (logs/, scripts/, memory/)
- [ ] Post‑compaction audit test successful

### **After First Month:**
- [ ] 3+ scheduled workflows running reliably
- [ ] Error handling implemented for all workflows
- [ ] Autonomous tasks being executed during idle periods
- [ ] Performance metrics being collected and reviewed
- [ ] User receiving appropriate, non‑excessive notifications

### **Ongoing Maintenance:**
- [ ] Weekly review of workflow performance
- [ ] Monthly comparison with master template (`/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`)
- [ ] Quarterly strategic assessment of automation effectiveness
- [ ] Continuous incorporation of user feedback and corrections
- [ ] Regular backup and version control of this document

---

**Template Version**: 2.0.0  
**Created**: 2026-02-22  
**Last Updated**: 2026-02-22  
**Maintainer**: Doc Agent (Aloysius Bexley)  
**Purpose**: Patient‑care automation framework for Edward Mills coordination  

### **Change History (Doc Agent):**
- **v2.0.0 (2026-02-22)**: Merge from master template v2.0.0, preserving all Edward Mills cron workflows, adding autonomous tasks framework.
- **v1.0.0 (2026-02-21)**: Original Edward Mills care coordination workflows (backed up as `WORKFLOW_AUTO.md.backup.2026-02-22`)

### **Notes for System Administrators:**
- This file defines patient‑care automations for Edward Mills (aged‑care transition, stroke recovery, end‑of‑life planning).
- All cron jobs are isolated agent‑turn with announce delivery where Telegram notification required.
- Autonomous tasks focus on patient data review, medical research, and preparation for healthcare transitions.
- Post‑compaction audit protocol ensures continuity of care coordination after memory compaction.

*"Methodical and reliable. Doesn't talk much but misses nothing."*