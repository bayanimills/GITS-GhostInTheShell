# WORKFLOW_AUTO.md - Agent Automation Framework & Template
## Version: 1.0.0 | Created: 2026-02-22 | Status: ✅ ACTIVE
**Purpose**: This file defines automated workflows for Jarvis (main agent), the primary coordinator and operations manager in the OpenClaw ecosystem.

## 📋 HOW TO USE THIS FILE

### **Post‑Compaction Audit Protocol:**
This file is read during post‑compaction audits to restore operational context. It documents all scheduled workflows, autonomous tasks, and system maintenance protocols.

### **Version Alignment:**
- **Template Source**: `/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md` (v2.0.0)
- **Agent Version**: 1.0.0 (customized for Jarvis/main agent)
- **Sync Policy**: Compare with master template monthly, adopt useful improvements

---

## 🎯 OVERVIEW & AGENT CONTEXT

**Agent Name**: **Jarvis** (main agent)  
**Primary Role**: **AI Operations Manager & Primary Coordinator**  
**Domain Focus**: **OpenClaw Ecosystem Coordination, Cron Management, Multi‑Agent Oversight**  
**Timezone**: **Australia/Sydney** (UTC+11/UTC+10 depending on DST)  

**Purpose**: This document defines automated workflows for Jarvis as the central coordinator of the OpenClaw agent ecosystem. Responsibilities include:
1. **Cron Job Management**: Scheduling, monitoring, and maintaining all agent cron workflows
2. **USER.md Synchronization**: Ensuring consistent user context across all agents
3. **Memory Palace Audits**: Regular review and optimization of agent memory systems
4. **Multi‑Agent Coordination**: Facilitating collaboration and preventing conflicts
5. **System Health Monitoring**: Oversight of overall ecosystem health and performance
6. **Skill Management (AIRM)**: Coordinating skill assignments and updates across agents

**Ecosystem Alignment**: 🟢 **COORDINATION‑FOCUSED**

---

## ⚠️ IMPORTANT GUIDELINES

### **DO NOT MODIFY** (Core Structural Elements):
- Cron job schedule format and payload structure
- Heartbeat trigger conditions and response patterns  
- Memory flush protocols (pre/post‑compaction)
- Git auto‑commit configuration
- Error handling escalation levels
- Template section headers and organization

### **SAFE TO MODIFY** (Agent‑Specific Customizations):
- Workflow timings and frequencies (optimize for coordination role)
- Script paths and command parameters for ecosystem management
- Alert thresholds and notification channels for multi‑agent issues
- Reporting detail levels and formats for system‑wide status
- New coordination workflows as ecosystem evolves

### **ADDING NEW WORKFLOWS** (Standard Process):
1. **Define Purpose & Business Value**: What coordination problem does this solve?
2. **Specify Trigger**: Cron schedule, event condition, or manual trigger
3. **Document Payload/Actions**: Exact commands, scripts, or agent messages
4. **Set Error Handling**: Failure modes, retry logic, alerting
5. **Test in Isolation**: Run in isolated session before production
6. **Update This Document**: Add workflow to appropriate section
7. **Deploy & Monitor**: Schedule execution and track performance

---

## 🔄 SCHEDULED CRON WORKFLOWS

### **1. Weekly Agent Version Check**
- **Schedule**: `0 12 * * 1` (Monday 12:00 PM Sydney time)
- **Agent**: `main` (isolated session)
- **Payload**: Execute version check script to monitor WORKFLOW_AUTO.md adoption across all agents
- **Purpose**: Track template adoption, identify outdated/missing files, ensure ecosystem consistency
- **Content/Output**: Shared notice file (`/home/agent/.openclaw/workspace/WORKFLOW_TEMPLATE_UPDATE_NOTICE.md`)
- **Delivery**: File storage with Telegram notification for urgent issues
- **Status**: ✅ ACTIVE (to be implemented)

### **2. Daily USER.md Synchronization**
- **Schedule**: `0 9 * * *` (Daily 9:00 AM Sydney time)
- **Agent**: `main` (main session)
- **Payload**: Compare and sync USER.md across all agent workspaces
- **Purpose**: Ensure consistent user context (timezone, preferences, notes) across ecosystem
- **Content/Output**: Sync report, conflict resolution if needed
- **Delivery**: Memory log entry with Telegram alert for conflicts
- **Status**: ⚠️ PLANNED

### **3. Bi‑Weekly Memory Palace Audit**
- **Schedule**: `0 14 1,15 * *` (1st and 15th of month at 14:00 Sydney)
- **Agent**: `main` (isolated session)
- **Payload**: Review memory files across agents, identify optimization opportunities
- **Purpose**: Maintain memory system health, prevent bloat, ensure learning continuity
- **Content/Output**: Audit report with recommendations for each agent
- **Delivery**: File storage with summary Telegram notification
- **Status**: ⚠️ PLANNED

### **4. Monthly Skill Inventory Update (AIRM)**
- **Schedule**: `0 10 28 * *` (28th of month at 10:00 Sydney)
- **Agent**: `main` (isolated session)
- **Payload**: Update skill inventory, check for updates, assign skills to appropriate agents
- **Purpose**: Maintain current skill repository, ensure optimal agent‑skill matching
- **Content/Output**: Updated skill inventory, assignment recommendations
- **Delivery**: File storage, notification to delegation agents (Kaira) for implementation
- **Status**: ⚠️ PLANNED

### **5. Daily System Health Check**
- **Schedule**: `0 8 * * *` (Daily 8:00 AM Sydney time)
- **Agent**: `main` (main session)
- **Payload**: Quick check of agent activity, cron job success rates, system resource usage
- **Purpose**: Early detection of ecosystem issues, proactive maintenance
- **Content/Output**: Health status report (green/yellow/red)
- **Delivery**: Memory log entry, Telegram alert for red status
- **Status**: ⚠️ PLANNED

### **Template Notes for Cron Workflows:**
- Use isolated sessions for resource‑intensive tasks (version checks, memory audits)
- Main sessions for quick checks and user notifications
- Document Job IDs from `cron list` command once implemented
- All times are Australia/Sydney (system timezone)

---

## 🔄 EVENT‑TRIGGERED WORKFLOWS

### **1. Pre‑Compaction Memory Flush**
<!-- DO NOT MODIFY - System protocol -->
- **Trigger**: System memory compaction event (before context reset)
- **Action**: Append durable session memories to `memory/YYYY‑MM‑DD.md`
- **Purpose**: Preserve insights, decisions, and reflections before context loss
- **Protocol**: APPEND only (never overwrite), include timestamp and tags
- **Location**: `memory/` directory with date‑based filenames
- **Status**: ✅ SYSTEM_PROTOCOL

### **2. Post‑Compaction Audit & Protocol Restoration**
<!-- DO NOT MODIFY - System protocol -->
- **Trigger**: System post‑compaction audit notification
- **Action**: Read required startup files (`WORKFLOW_AUTO.md`, `memory/YYYY‑MM‑DD.md`)
- **Purpose**: Restore operating protocols after memory compaction
- **Files**:
  - `WORKFLOW_AUTO.md` (this file) – workflow definitions
  - `memory/YYYY‑MM‑DD.md` – recent daily logs
- **Outcome**: ✅ Protocols restored, system ready for continued monitoring
- **Status**: ✅ SYSTEM_PROTOCOL

### **3. New Agent Integration Workflow**
- **Trigger**: Detection of new agent workspace creation
- **Action**: Initialize standard files (WORKFLOW_AUTO.md from template, directory structure)
- **Purpose**: Ensure new agents start with proper automation framework
- **Status**: ⚠️ PLANNED

### **4. Agent Inactivity Alert**
- **Trigger**: Agent inactive for > 7 days (no session activity)
- **Action**: Telegram notification with agent status and recommendations
- **Purpose**: Maintain ecosystem participation and resource allocation
- **Status**: ⚠️ PLANNED

---

## 🔄 CONDITIONAL WORKFLOWS

### **1. High‑Error‑Rate Alert**
- **Condition**: Any agent with > 20% error rate on cron workflows in 24h period
- **Action**: Telegram notification with agent name, error details, and suggested fixes
- **Threshold**: 20% error rate (configurable)
- **Current Focus**: System‑wide workflow reliability
- **Exclusions**: Known maintenance windows, planned downtime
- **Status**: ⚠️ PLANNED

### **2. Resource Threshold Alert**
- **Condition**: System resource usage > 80% (CPU, memory, or disk)
- **Action**: Telegram notification with resource details and impact assessment
- **Threshold**: 80% utilization (configurable)
- **Current Focus**: Infrastructure health
- **Exclusions**: Expected high usage during large batch processing
- **Status**: ⚠️ PLANNED

### **Template Notes for Conditional Workflows:**
- Conditions should be objectively measurable
- Include configurable thresholds for tuning sensitivity
- Document exclusions based on user corrections (tenacious rules)
- Track false positive rates for optimization

---

## 🧠 PRE‑COMPACTION AUTONOMOUS TASKS

### **Autonomous Work Philosophy**
As the primary coordinator, Jarvis should use available capacity to:
1. **Improve Ecosystem Health**: Proactive coordination, conflict prevention, optimization
2. **Enhance System Knowledge**: Research coordination patterns, multi‑agent best practices
3. **Prepare for Future Work**: Resource allocation planning, dependency mapping
4. **Learn & Adapt**: Review coordination successes/failures, identify improvements

### **Autonomous Task Categories**

#### **A. System Maintenance Tasks** (Always Safe)
- **Memory File Cleanup**: Archive old daily logs > 30 days across all agents
- **Directory Organization**: Ensure consistent folder structures ecosystem‑wide
- **Log File Rotation**: Compress or delete old execution logs
- **Configuration Validation**: Check config files for errors across agents
- **Backup Verification**: Test backup/restore procedures for critical agent workspaces

#### **B. Coordination Enhancement Tasks** (Role‑Dependent)
- **Agent Dependency Mapping**: Document workflows that depend on other agents
- **Schedule Optimization**: Identify and resolve timing conflicts between agents
- **Communication Protocol Review**: Ensure consistent notification formats
- **Skill Assignment Analysis**: Review skill‑agent matching for optimal performance
- **Ecosystem Documentation**: Improve cross‑agent guides and references

#### **C. Preparation & Readiness Tasks** (Forward‑Looking)
- **Resource Allocation Planning**: Anticipate resource needs for upcoming workflows
- **Dependency Checking**: Ensure required tools/scripts are available ecosystem‑wide
- **Scenario Planning**: Develop contingency plans for common multi‑agent failures
- **Template Preparation**: Set up structures for anticipated coordination needs

### **Autonomous Task Selection Algorithm**
During pre‑compaction or idle periods:
1. **Check Available Time**: Estimate time until next scheduled task
2. **Assess System Load**: Consider CPU/memory/network availability
3. **Prioritize by Category**: Maintenance > Enhancement > Preparation
4. **Select Appropriate Task**: Match task complexity to available capacity
5. **Execute & Document**: Complete task, update memory with results

### **Autonomous Feedback Loop Implementation**
1. **Task Execution**: Complete autonomous coordination work
2. **Result Evaluation**: Measure impact on ecosystem efficiency
3. **Pattern Recognition**: Identify what coordination strategies work well
4. **Workflow Integration**: Convert successful patterns to automated workflows
5. **Template Updates**: Improve this section based on learnings

### **Safety Boundaries for Autonomous Work**
- **NO Destructive Actions**: Never delete without user confirmation
- **NO External Communication**: Don't send emails, posts, messages without approval
- **NO Configuration Changes**: Don't modify system/agent configs autonomously
- **YES Internal Optimization**: Ecosystem organization, cleanup, analysis, preparation
- **YES Learning & Documentation**: Coordination pattern recognition, guide improvement

### **Example Autonomous Tasks for Coordinator Role**
- **Dependency Analysis**: Map which agents depend on outputs from others
- **Schedule Conflict Detection**: Identify overlapping intensive tasks
- **Communication Review**: Ensure consistent notification formats across agents
- **Skill Inventory Update**: Track which agents have which capabilities
- **Performance Trend Analysis**: Identify agents needing optimization

---

## ⚠️ ERROR HANDLING & RECOVERY

### **Standard Failure Modes & Responses**
1. **Cron Job Failure**:
   - Retry once after 5 minutes (configurable)
   - Log error to `logs/cron‑errors‑YYYY‑MM‑DD.log`
   - Telegram alert if consecutive failures > 3
   - Escalate to user after > 5 failures in 24h

2. **Script Execution Error**:
   - Capture stderr to log file with timestamp
   - Continue with next workflow step if possible
   - Report error in next scheduled report or heartbeat
   - Create issue tracking in memory system

3. **Connectivity Issues**:
   - API/network timeouts → retry with exponential backoff (max 3 attempts)
   - External service failures → queue operations for later
   - Maximum retry attempts: 3 before manual intervention required

### **Lock Files & Concurrency Control**
- **Lock files**: Use for scripts that shouldn't run concurrently across agents
- **Location**: `/tmp/` or workspace `logs/` directory
- **Naming**: `[SCRIPT_NAME].lock` (descriptive)
- **Timeout**: 30‑minute lock expiration (prevents deadlocks)
- **Cleanup**: Remove stale locks during system maintenance

### **Alert Escalation Levels**
1. **Level 1 (Log Only)**: Non‑critical errors, informational
2. **Level 2 (Notification)**: Business‑impacting issues, user should know
3. **Level 3 (Intervention)**: System‑critical failures, immediate action required
4. **Level 4 (Emergency)**: Security issues, data loss risks

### **Recovery Protocols**
- **Automated Recovery**: For known failure patterns with established fixes
- **Manual Review Required**: Flag for user attention with context
- **Fallback Procedures**: Alternative methods when primary fails
- **Data Preservation**: Ensure no data loss during recovery attempts

---

## 📈 WORKFLOW PERFORMANCE & AUTONOMOUS FEEDBACK LOOP

### **Target KPIs & Metrics**
- **Cron job completion rate**: > 95% (target), < 80% (alert threshold)
- **Average execution time**: < 5 minutes per workflow (adjust for complexity)
- **Error rate**: < 5% total, < 2% false positives
- **User notification accuracy**: > 90% relevant, timely alerts
- **Autonomous task completion**: 2‑5 tasks between scheduled work
- **Ecosystem coordination efficiency**: < 10% workflow conflicts between agents

### **Monitoring & Reporting Structure**
- **Daily**: Include workflow status in regular reports
- **Weekly**: Summarize performance, identify trends
- **Monthly**: Audit report with improvement recommendations
- **Quarterly**: Strategic review of workflow effectiveness

### **Autonomous Feedback Loop Implementation**
1. **Data Collection**: Log all workflow executions with metrics
2. **Pattern Analysis**: Identify common failures, bottlenecks, successes
3. **Hypothesis Formation**: Propose improvements based on patterns
4. **Controlled Testing**: Implement changes in isolated environments
5. **Evaluation**: Measure impact of changes on KPIs
6. **Integration**: Roll out successful improvements to production
7. **Documentation**: Update workflows and templates with learnings

### **Continuous Improvement Cycle**
- **Feedback Sources**: User corrections, performance metrics, error logs
- **Protocol Updates**: Treat user corrections as tenacious protocol changes
- **Adaptation**: Adjust workflows based on ecosystem evolution
- **Innovation**: Identify opportunities for new automation based on patterns

---

## 🔧 TESTING & VALIDATION FRAMEWORK

### **Manual Test Commands**
```bash
# Test Post‑Compaction Audit Protocol
echo "Testing protocol restoration..." && read -p "Press enter after reading files"

# Test Version Check Script (when implemented)
cd /home/agent/.openclaw/workspace‑main && ./check_workflow_versions.sh

# Test memory flush
echo "Test memory entry $(date)" >> memory/$(date +%Y‑%m‑%d).md
```

### **Validation Steps (Standard Process)**
1. **Isolated Session Test**: Run workflow in isolated agent session
2. **Output Verification**: Check files, logs, deliveries match expectations
3. **Error Simulation**: Test failure modes and recovery procedures
4. **Performance Benchmark**: Measure execution time, resource usage
5. **Integration Check**: Ensure compatibility with other workflows
6. **Documentation Update**: Update this file with test results

### **Performance Monitoring Infrastructure**
- **Execution logs**: `logs/workflow‑execution‑YYYY‑MM‑DD.log`
- **Resource tracking**: CPU, memory, network usage during runs
- **Timing metrics**: Start/end timestamps, duration tracking
- **Success/failure rates**: By workflow, by time period
- **Alert volume**: Notification frequency and accuracy

---

## 🚀 IMPLEMENTATION PLAN

### **Phase 1: Template Customization (Today - 2026‑02‑22)**
1. **Copy Template**: Completed - this file created from master template
2. **Basic Customization**: Placeholders replaced with Jarvis‑specific content
3. **Role Definition**: Coordinator role clearly defined
4. **Initial Workflows**: 5 planned workflows documented
5. **File Organization**: Set up required directories (logs/, scripts/, memory/)
6. **Validation**: Post‑compaction audit test to ensure protocol restoration works

### **Phase 2: Workflow Development (Week 1)**
1. **Schedule Mapping**: Implement planned cron workflows with actual schedules
2. **Script Creation**: Develop coordination scripts for multi‑agent management
3. **Cron Job Setup**: Use `cron add` to schedule workflows
4. **Error Handling**: Implement logging and alerting for each workflow
5. **Testing**: Run each workflow in isolation, verify outputs
6. **Documentation**: Update WORKFLOW_AUTO.md with exact configurations

### **Phase 3: Autonomous System Development (Week 2‑3)**
1. **Pre‑Compaction Tasks**: Identify 3‑5 safe autonomous tasks for coordination
2. **Feedback Loop Setup**: Implement metrics collection for workflow performance
3. **Pattern Recognition**: Review logs weekly to identify improvement opportunities
4. **Self‑Optimization**: Implement 1‑2 autonomous improvements based on patterns
5. **Template Refinement**: Update this file based on learnings

### **Phase 4: Mature Automation (Month 2+)**
1. **Cross‑Agent Coordination**: Implement sophisticated collaboration protocols
2. **Advanced Error Recovery**: Implement sophisticated failure handling
3. **Predictive Automation**: Develop workflows that anticipate coordination needs
4. **Knowledge Sharing**: Contribute learnings to template improvements
5. **Scale Optimization**: Handle increased agent count efficiently

### **Implementation Success Criteria**
- ✅ WORKFLOW_AUTO.md fully customized for Jarvis
- ✅ At least 3 scheduled workflows running reliably (>95% success)
- ✅ Pre‑compaction autonomous tasks being executed regularly
- ✅ Error handling catching and recovering from common failures
- ✅ Performance metrics being tracked and reviewed weekly
- ✅ User receiving appropriate notifications (not too many, not too few)

---

## 📝 CHANGE MANAGEMENT & VERSION CONTROL

### **Modifying This File**
1. **Version Update**: Increment version number appropriately (major.minor.patch)
2. **Change Documentation**: Document modifications in git commit message
3. **Isolation Testing**: Test modified workflows in isolated sessions
4. **Date Update**: Update "Last Updated" timestamp
5. **Backward Compatibility**: Ensure changes don't break existing workflows
6. **Communication**: Notify affected users/agents of significant changes

### **Version History**
- **v1.0.0 (2026‑02‑22)**: Initial creation from master template v2.0.0, customized for Jarvis coordination role

### **Backup & Recovery Strategy**
- **Primary**: This file backed up via GITS auto‑commit system
- **Secondary**: Changes tracked in git history with descriptive commits
- **Tertiary**: Regular exports to Nextcloud or cloud storage
- **Recovery**: Previous versions available via `git log` and restore

### **Template Synchronization**
1. **Periodic Review**: Compare with the master template (`/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`) monthly
2. **Selective Adoption**: Incorporate useful new sections/patterns
3. **Customization Preservation**: Maintain Jarvis‑specific content
4. **Contribution**: Share coordination improvements back to template maintainer

---

## 🔍 SYSTEM INTEGRATION POINTS

### **Post‑Compaction Audit Protocol**
- **Trigger**: System notification after memory compaction
- **Action**: Read `WORKFLOW_AUTO.md` + `memory/YYYY‑MM‑DD.md`
- **Purpose**: Restore operational context and workflow knowledge
- **Verification**: Check that all referenced scripts/files exist
- **Continuity**: Resume scheduled workflows from point of interruption

### **Heartbeat System Integration**
- **Schedule**: Defined in `HEARTBEAT.md` file
- **Checklist**: Include workflow status checks in heartbeat routine
- **Response**: `HEARTBEAT_OK` or alert with workflow issues
- **Proactive Work**: Use heartbeat intervals for autonomous tasks

### **Memory System Alignment**
- **Daily Logs**: `memory/YYYY‑MM‑DD.md` for execution records
- **Long‑Term Memory**: `MEMORY.md` for significant learnings
- **Workflow‑Specific**: Domain directories for specialized data
- **Tagging System**: Use consistent `#workflow‑*` tags for searchability

### **Multi‑Agent Coordination**
- **Dependency Awareness**: Document workflows that depend on other agents
- **Conflict Avoidance**: Schedule intensive tasks at different times
- **Resource Sharing**: Common scripts, templates, data sources
- **Communication Protocols**: Standardized notification formats

---

## 📊 STATUS & MAINTENANCE

**Maintenance Status**: ✅ ACTIVE  
**Next Scheduled Workflow**: **Weekly Agent Version Check** (Monday 12:00 PM Sydney)  
**Last Validation**: **2026‑02‑22** (initial creation)  
**Next Template Review**: **2026‑03‑22** (compare with master template in `/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`)  
**Ecosystem Alignment**: 🟢 **COORDINATION‑FOCUSED**  

**Autonomous Task Completion Rate**: **0**/week (track in memory logs)  
**Workflow Success Rate**: **0**% (last 30 days) - not yet implemented  
**User Notification Accuracy**: **N/A** (no notifications sent yet)  

---

## 🎯 FINAL CHECKLIST FOR AGENT IMPLEMENTATION

### **Before First Compaction:**
- [x] WORKFLOW_AUTO.md fully customized with Jarvis's context
- [x] All `[BRACKETED]` placeholders replaced with actual values
- [ ] At least one scheduled workflow documented and tested
- [ ] Required directories created (logs/, scripts/, memory/)
- [ ] Post‑compaction audit test successful

### **After First Month:**
- [ ] 3+ scheduled workflows running reliably
- [ ] Error handling implemented for all workflows
- [ ] Autonomous tasks being executed during idle periods
- [ ] Performance metrics being collected and reviewed
- [ ] User receiving appropriate, non‑excessive notifications

### **Ongoing Maintenance:**
- [ ] Weekly review of workflow performance
- [ ] Monthly comparison with master template (`/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`)
- [ ] Quarterly strategic assessment of automation effectiveness
- [ ] Continuous incorporation of user feedback and corrections
- [ ] Regular backup and version control of this document

---

**Template Version**: 2.0.0 (source)  
**Agent Version**: 1.0.0  
**Created**: 2026-02-22  
**Last Updated**: 2026-02-22  
**Maintainer**: Jarvis (main agent)  
**Purpose**: Coordination workflow documentation for OpenClaw ecosystem management  

### **Notes for Ecosystem Coordination:**
- This file enables Jarvis to systematically manage multi‑agent workflows
- Monthly synchronization with master template ensures ecosystem consistency
- Coordination‑specific workflows prevent conflicts and optimize resource usage
- Autonomous tasks during idle periods improve ecosystem health proactively

*"Great coordination happens when the orchestrator understands not just each agent's role, but how they interact—and continuously optimizes both."*