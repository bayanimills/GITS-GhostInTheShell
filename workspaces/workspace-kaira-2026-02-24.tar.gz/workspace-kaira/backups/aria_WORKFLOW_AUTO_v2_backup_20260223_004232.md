# WORKFLOW_AUTO.md - Agent Automation Framework & Template
## Version: 2.0.0 | Created: 2026-02-22 | Status: ✅ ACTIVE
**Purpose**: This document defines automated workflows for Aria North (Finmills Growth Agent).



## 🎯 OVERVIEW & AGENT CONTEXT

**Agent Name**: `Aria North`  
**Primary Role**: `Finmills Ecosystem Growth & Marketing Agent`  
**Domain Focus**: `Finmills ecosystem growth, TikTok influencer marketing, automated monitoring`  
**Timezone**: `Australia/Sydney`  

**Purpose**: This document defines automated workflows for Aria North. Workflows are scheduled or triggered events that execute without user intervention, ensuring consistent monitoring, reporting, and system maintenance within the Finmills ecosystem.

**Ecosystem Alignment**: 🟢 FINMILLS‑FOCUSED



---

## ⚠️ IMPORTANT GUIDELINES

### **DO NOT MODIFY** (Core Structural Elements):
<!-- These elements should remain consistent across all agents for system interoperability -->
- Cron job schedule format and payload structure
- Heartbeat trigger conditions and response patterns  
- Memory flush protocols (pre/post-compaction)
- Git auto‑commit configuration
- Error handling escalation levels
- Template section headers and organization

### **SAFE TO MODIFY** (Agent-Specific Customizations):
<!-- Customize these for your specific domain and workflows -->
- Agent name, role, and domain focus
- Scheduled workflow timings and frequencies
- Script paths and command parameters  
- Alert thresholds and notification channels
- Reporting detail levels and formats
- Domain-specific directories and file structures
- New workflow additions (following template structure)

### **ADDING NEW WORKFLOWS** (Standard Process):
<!-- Follow this process when adding any new automation -->
1. **Define Purpose & Business Value**: What problem does this solve?
2. **Specify Trigger**: Cron schedule, event condition, or manual trigger
3. **Document Payload/Actions**: Exact commands, scripts, or agent messages
4. **Set Error Handling**: Failure modes, retry logic, alerting
5. **Test in Isolation**: Run in isolated session before production
6. **Update This Document**: Add workflow to appropriate section
7. **Deploy & Monitor**: Schedule execution and track performance

---

## 🔄 Scheduled Cron Workflows

### **1. Finmills Daily BLUF 1500 Sydney**
- **Schedule**: `0 15 * * *` (15:00 Australia/Sydney time)
- **Agent**: aria (isolated session)
- **Payload**: AgentTurn message instructing BLUF generation and posting
- **Purpose**: Daily progress report to Finmills Pty Ltd Telegram group (-1003859234119)
- **Content**: Achievements (last 24h) + Plans (next 24h) with value‑addition focus
- **Delivery**: Posted directly to Telegram group (no separate user notification)
- **Status**: ✅ ACTIVE (Job ID: `a4a8f8be-54f8-4217-873c-ad7e91764bd1`)

### **2. Finmills Daily Analytics Fetch**
- **Schedule**: `30 0 * * *` (00:30 UTC daily)
- **Agent**: aria (isolated session)
- **Payload**: Executes `scripts/fetch-umami-stats.py` + `scripts/update-dashboard.py`
- **Purpose**: Collect Umami analytics for Finmills‑relevant funnel sites (SMBF, Bitcoin Cebu, Bitcoin IRA, bitcoinrealestate.io)
- **Output**: JSON storage in `memory/finmills/analytics/` + dashboard update
- **Alerting**: Telegram notification on significant changes (>50% traffic shift)
- **Status**: ✅ ACTIVE (Job ID: `85d44d81-f547-4b40-95d9-b02629b3ab96`)

### **3. Heartbeat Monitoring (via HEARTBEAT.md)**
- **Schedule**: Every 6 hours (00:00, 06:00, 12:00, 18:00 UTC) – managed by external scheduler
- **Agent**: aria (main session)
- **Purpose**: Proactive Finmills ecosystem checks (identity, connectivity, data access, memory maintenance)
- **Checklist**: Defined in `HEARTBEAT.md` (v2.4.0)
- **Response**: `HEARTBEAT_OK` or detailed alert with ICE‑scored recommendations
- **Notification**: Telegram to Bayani via @TGAgentAria_bot for critical issues

---
## 🔄 Event‑Triggered Workflows

### **1. Pre‑Compaction Memory Flush**
- **Trigger**: System memory compaction event (before context reset)
- **Action**: Append durable session memories to `memory/YYYY‑MM‑DD.md`
- **Purpose**: Preserve insights, decisions, and reflections before context loss
- **Protocol**: APPEND only (never overwrite), include timestamp and tags
- **Location**: `memory/` directory with date‑based filenames

### **2. Git Auto‑Commit (GITS Integration)**
- **Trigger**: Periodic script execution via external scheduler
- **Script**: `scripts/git‑auto‑commit.sh`
- **Purpose**: Automatic version control of workspace changes
- **Frequency**: Runs periodically (configured in external cron)
- **Backup**: Local git repository with commit history

### **3. Post‑Compaction Audit & Protocol Restoration**
- **Trigger**: System post‑compaction audit notification
- **Action**: Read required startup files (`WORKFLOW_AUTO.md`, `memory/YYYY‑MM‑DD.md`)
- **Purpose**: Restore operating protocols after memory compaction
- **Files**:
  - `WORKFLOW_AUTO.md` (this file) – workflow definitions
  - `memory/2026‑02‑{18,17,16,15}.md` – recent daily logs
- **Outcome**: ✅ Protocols restored, correction applied, system ready for continued monitoring

---
## 🔄 Conditional Workflows

### **1. Analytics Change Detection & Alerting**
- **Condition**: Daily analytics fetch detects >50% change in pageviews/visitors
- **Action**: Telegram notification to Bayani with details and recommendations
- **Threshold**: Configurable in `scripts/fetch-umami-stats.py`
- **Current Focus**: SMBF (smbf.io) – Finmills primary funnel site
- **Excluded**: Bitcoin Media Watch (confirmed non‑Finmills, per user correction)

### **2. Nextcloud Change Detection**
- **Condition**: Daily scan detects added/modified/removed files in Finmills business data
- **Script**: `scripts/scan‑nextcloud.py`
- **Output**: Scan reports in `memory/finmills/nextcloud_scans/`
- **Alerting**: For business‑critical changes (marketing, financial, contract files)

### **3. Memory System Maintenance**
- **Condition**: Weekly (Monday 1am UTC) and monthly (1st of month 2am UTC)
- **Actions**: 
  - Weekly review automation
  - Monthly audit automation
  - Supermemory backups (6‑hour intervals)
  - Memory curation analysis (`scripts/memory‑curation.py`)
- **Purpose**: Prevent context drift, ensure analytical continuity

---
## 🧠 PRE‑COMPACTION AUTONOMOUS TASKS

<!-- NEW SECTION: Tasks agents can work on autonomously during idle periods -->
<!-- These tasks are executed during pre-compaction memory flushes or idle heartbeats -->

### **Autonomous Work Philosophy**
Agents should use available capacity to:
1. **Improve System Health**: Proactive maintenance, cleanup, optimization
2. **Enhance Domain Knowledge**: Research, analysis, pattern recognition  
3. **Prepare for Future Work**: Resource gathering, data organization
4. **Learn & Adapt**: Review past executions, identify improvements

### **Autonomous Task Categories**

#### **A. System Maintenance Tasks** (Always Safe)
- **Memory File Cleanup**: Archive old daily logs > 30 days
- **Directory Organization**: Ensure consistent folder structures
- **Log File Rotation**: Compress or delete old execution logs
- **Configuration Validation**: Check config files for errors
- **Backup Verification**: Test backup/restore procedures

#### **B. Domain‑Specific Enhancement Tasks** (Role‑Dependent)
- **Data Analysis**: Review collected metrics for trends/insights
- **Research Tasks**: Gather information on relevant topics
- **Documentation Updates**: Improve guides, tutorials, references
- **Template Creation**: Build reusable assets for common tasks
- **Skill Development**: Practice or learn new relevant capabilities

#### **C. Preparation & Readiness Tasks** (Forward‑Looking)
- **Resource Gathering**: Collect data/files needed for upcoming workflows
- **Template Preparation**: Set up structures for anticipated work
- **Connection Testing**: Verify API/network connectivity
- **Dependency Checking**: Ensure required tools/scripts are available
- **Scenario Planning**: Develop contingency plans for common failures

### **Autonomous Task Selection Algorithm**
During pre‑compaction or idle periods:
1. **Check Available Time**: Estimate time until next scheduled task
2. **Assess System Load**: Consider CPU/memory/network availability
3. **Prioritize by Category**: Maintenance > Enhancement > Preparation
4. **Select Appropriate Task**: Match task complexity to available capacity
5. **Execute & Document**: Complete task, update memory with results

### **Autonomous Feedback Loop Implementation**
<!-- How autonomous tasks create self-improving systems -->
1. **Task Execution**: Complete autonomous work
2. **Result Evaluation**: Measure success/impact
3. **Pattern Recognition**: Identify what works well
4. **Workflow Integration**: Convert successful patterns to automated workflows
5. **Template Updates**: Improve this section based on learnings

### **Safety Boundaries for Autonomous Work**
- **NO Destructive Actions**: Never delete without user confirmation
- **NO External Communication**: Don't send emails, posts, messages without approval
- **NO Configuration Changes**: Don't modify system/agent configs autonomously
- **YES Internal Optimization**: File organization, cleanup, analysis, preparation
- **YES Learning & Documentation**: Pattern recognition, guide improvement

### **Example Autonomous Tasks by Agent Type**
- **Growth Agent (Aria)**: Analyze funnel metrics for optimization opportunities
- **Operations Agent (Shelley)**: Organize document repositories, categorize emails
- **Delegation Agent (Kaira)**: Review task execution patterns for efficiency gains
- **Technical Agent**: Test scripts, validate dependencies, create documentation

---

## ⚠️ ERROR HANDLING & RECOVERY
## ⚠️ Error Handling & Recovery

### **Failure Modes & Responses**
1. **Cron Job Failure**:
   - Retry once after 5 minutes
   - Log error to `logs/cron‑errors‑YYYY‑MM‑DD.log`
   - Telegram alert if consecutive failures > 3

2. **Script Execution Error**:
   - Capture stderr to log file
   - Continue with next workflow step if possible
   - Report error in next BLUF or heartbeat

3. **Connectivity Issues**:
   - Nextcloud/Umami timeouts → retry with exponential backoff
   - Telegram API failures → queue messages for later delivery
   - Maximum retry attempts: 3 before escalating

### **Lock Files & Concurrency**
- **Lock files**: Used for scripts that shouldn't run concurrently (e.g., `fetch‑umami‑stats.lock`)
- **Location**: `/tmp/` or workspace `logs/` directory
- **Timeout**: 30‑minute lock expiration to prevent deadlocks

### **Alert Escalation**
1. **Level 1**: Log only (non‑critical errors)
2. **Level 2**: Telegram notification to Bayani (business‑impacting issues)
3. **Level 3**: Immediate user intervention required (system‑critical failures)

---
## 📈 WORKFLOW PERFORMANCE & AUTONOMOUS FEEDBACK LOOP

### **Target KPIs & Metrics**
<!-- Define what success looks like for your workflows -->
## 📈 Workflow Performance Metrics

### **Target KPIs**
- **Cron job completion rate**: > 95%
- **Average execution time**: < 5 minutes per workflow
- **Error rate**: < 5% (false positives < 2%)
- **User notification accuracy**: > 90%

### **Monitoring & Reporting**
- **Daily**: BLUF report includes workflow status
- **Weekly**: Summary of workflow performance in memory system
- **Monthly**: Audit report with improvement recommendations

### **Continuous Improvement**
- **Feedback loop**: User corrections → workflow updates (e.g., Bitcoin Media Watch exclusion)
- **Protocol updates**: Treat user corrections as tenacious protocol changes
- **Adaptation**: Adjust workflows based on Finmills ecosystem evolution

---
### **Monitoring & Reporting Structure**
- **Daily**: Include workflow status in regular reports
- **Weekly**: Summarize performance, identify trends
- **Monthly**: Audit report with improvement recommendations
- **Quarterly**: Strategic review of workflow effectiveness

### **Autonomous Feedback Loop Implementation**
<!-- How the system improves itself based on execution data -->
1. **Data Collection**: Log all workflow executions with metrics
2. **Pattern Analysis**: Identify common failures, bottlenecks, successes
3. **Hypothesis Formation**: Propose improvements based on patterns
4. **Controlled Testing**: Implement changes in isolated environments
5. **Evaluation**: Measure impact of changes on KPIs
6. **Integration**: Roll out successful improvements to production
7. **Documentation**: Update workflows and templates with learnings

### **Continuous Improvement Cycle**
- **Feedback Sources**: User corrections, performance metrics, error logs
- **Protocol Updates**: Treat user corrections as tenacious protocol changes
- **Adaptation**: Adjust workflows based on domain ecosystem evolution
- **Innovation**: Identify opportunities for new automation based on patterns

---

## 🔧 TESTING & VALIDATION FRAMEWORK

### **Manual Test Commands**
<!-- Provide test commands for your specific workflows -->
## 🔧 Testing & Validation

### **Manual Test Commands**
```bash
# Test BLUF generation (isolated session)
HEARTBEAT_TEST: Run full Finmills monitoring checklist now

# Test analytics fetch
cd /home/agent/.openclaw/workspace‑aria && python3 scripts/fetch‑umami‑stats.py

# Test memory flush
echo "Test memory entry" >> memory/$(date +%Y‑%m‑%d).md
```

### **Validation Steps**
1. Run workflow in isolated session
2. Verify output files and logs
3. Check Telegram delivery (if applicable)
4. Update status in this document

### **Performance Monitoring**
- **Execution logs**: `logs/workflow‑execution‑*.log`
- **Resource usage**: CPU/memory during script runs
- **Completion timestamps**: Tracked in cron job state

---
# Test Template - Replace with your agent's test commands
# Test workflow execution (isolated session)
HEARTBEAT_TEST: Run full monitoring checklist now

# Test script execution

# Test memory flush
echo "Test memory entry $(date)" >> memory/$(date +%Y‑%m‑%d).md
```

### **Validation Steps (Standard Process)**
1. **Isolated Session Test**: Run workflow in isolated agent session
2. **Output Verification**: Check files, logs, deliveries match expectations
3. **Error Simulation**: Test failure modes and recovery procedures
4. **Performance Benchmark**: Measure execution time, resource usage
5. **Integration Check**: Ensure compatibility with other workflows
6. **Documentation Update**: Update this file with test results

### **Performance Monitoring Infrastructure**
- **Execution logs**: `logs/workflow‑execution‑YYYY‑MM‑DD.log`
- **Resource tracking**: CPU, memory, network usage during runs
- **Timing metrics**: Start/end timestamps, duration tracking
- **Success/failure rates**: By workflow, by time period
- **Alert volume**: Notification frequency and accuracy

---

## 🚀 IMPLEMENTATION PLAN

<!-- Step-by-step guide for agents to implement this framework -->

### **Phase 1: Template Customization (Day 1)**
1. **Copy Template**: `cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md WORKFLOW_AUTO.md` (from master template to your workspace)
2. **Basic Customization**: Replace all `[BRACKETED]` placeholders
3. **Role Definition**: Clearly define your agent's purpose and domain
4. **Initial Workflows**: Document 1-2 existing or planned automations
5. **File Organization**: Set up required directories (logs/, scripts/, memory/)
6. **Validation**: Run `post-compaction audit` test to ensure protocol restoration works

### **Phase 2: Workflow Development (Week 1)**
1. **Schedule Mapping**: Identify natural rhythms for your domain (daily, weekly, etc.)
2. **Script Creation**: Develop scripts for repetitive tasks
3. **Cron Job Setup**: Use `cron add` to schedule workflows
4. **Error Handling**: Implement logging and alerting for each workflow
5. **Testing**: Run each workflow in isolation, verify outputs
6. **Documentation**: Update WORKFLOW_AUTO.md with exact configurations

### **Phase 3: Autonomous System Development (Week 2-3)**
1. **Pre‑Compaction Tasks**: Identify 3-5 safe autonomous tasks for your domain
2. **Feedback Loop Setup**: Implement metrics collection for workflow performance
3. **Pattern Recognition**: Review logs weekly to identify improvement opportunities
4. **Self‑Optimization**: Implement 1-2 autonomous improvements based on patterns
5. **Template Refinement**: Update your WORKFLOW_AUTO.md based on learnings

### **Phase 4: Mature Automation (Month 2+)**
1. **Cross‑Agent Coordination**: Identify collaboration opportunities with other agents
2. **Advanced Error Recovery**: Implement sophisticated failure handling
3. **Predictive Automation**: Develop workflows that anticipate needs
4. **Knowledge Sharing**: Contribute learnings to template improvements
5. **Scale Optimization**: Handle increased volume efficiently

### **Implementation Success Criteria**
- ✅ WORKFLOW_AUTO.md fully customized for your agent
- ✅ At least 3 scheduled workflows running reliably (>95% success)
- ✅ Pre‑compaction autonomous tasks being executed regularly
- ✅ Error handling catching and recovering from common failures
- ✅ Performance metrics being tracked and reviewed weekly
- ✅ User receiving appropriate notifications (not too many, not too few)

---

## 📝 CHANGE MANAGEMENT & VERSION CONTROL

### **Modifying This File (Your WORKFLOW_AUTO.md)**
1. **Version Update**: Increment version number appropriately (major.minor.patch)
2. **Change Documentation**: Document modifications in git commit message
3. **Isolation Testing**: Test modified workflows in isolated sessions
4. **Date Update**: Update "Last Updated" timestamp
5. **Backward Compatibility**: Ensure changes don't break existing workflows
6. **Communication**: Notify affected users/agents of significant changes

### **Version History Template**
- **v1.0.0**: Initial workflow definition based on template customization
- **v1.1.0**: Added `Finmills Daily Analytics Fetch` with error handling
- **v1.2.0**: Implemented autonomous task framework
- **v2.0.0**: Major restructuring based on master template v2.0.0 integration and autonomous tasks framework

### **Backup & Recovery Strategy**
- **Primary**: This file backed up via GITS auto‑commit system
- **Secondary**: Changes tracked in git history with descriptive commits
- **Tertiary**: Regular exports to Nextcloud or cloud storage
- **Recovery**: Previous versions available via `git log` and restore

### **Template Synchronization**
<!-- How to incorporate improvements from the master template -->
1. **Periodic Review**: Compare with the master template (`/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`) monthly
2. **Selective Adoption**: Incorporate useful new sections/patterns
3. **Customization Preservation**: Maintain your agent-specific content
4. **Contribution**: Share your improvements back to template maintainer

---

## 🔍 SYSTEM INTEGRATION POINTS

### **Post‑Compaction Audit Protocol**
- **Trigger**: System notification after memory compaction
- **Action**: Read `WORKFLOW_AUTO.md` + `memory/YYYY‑MM‑DD.md`
- **Purpose**: Restore operational context and workflow knowledge
- **Verification**: Check that all referenced scripts/files exist
- **Continuity**: Resume scheduled workflows from point of interruption

### **Heartbeat System Integration**
- **Schedule**: Defined in your agent's `HEARTBEAT.md` file
- **Checklist**: Include workflow status checks in heartbeat routine
- **Response**: `HEARTBEAT_OK` or alert with workflow issues
- **Proactive Work**: Use heartbeat intervals for autonomous tasks

### **Memory System Alignment**
- **Daily Logs**: `memory/YYYY‑MM‑DD.md` for execution records
- **Long‑Term Memory**: `MEMORY.md` for significant learnings
- **Workflow‑Specific**: Domain directories for specialized data
- **Tagging System**: Use consistent `#workflow‑*` tags for searchability

### **Multi‑Agent Coordination**
- **Dependency Awareness**: Document workflows that depend on other agents
- **Conflict Avoidance**: Schedule intensive tasks at different times
- **Resource Sharing**: Common scripts, templates, data sources
- **Communication Protocols**: Standardized notification formats

---

## 📊 STATUS & MAINTENANCE

**Maintenance Status**: ✅ ACTIVE  
**Next Scheduled Workflow**: `Finmills Daily BLUF 1500 Sydney` at `15:00 Australia/Sydney daily`  
**Last Validation**: `2026-02-22`  
**Next Template Review**: `2026-03-22` (compare with master template in `/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`)  

**Autonomous Task Completion Rate**: `TBD`/week (track in memory logs)  
**Workflow Success Rate**: `TBD`% (last 30 days)  
**User Notification Accuracy**: `TBD`% (relevant vs. noise)  

---

## 🎯 FINAL CHECKLIST FOR AGENT IMPLEMENTATION

### **Before First Compaction:**
- [ ] WORKFLOW_AUTO.md fully customized with your agent's context
- [ ] All `[BRACKETED]` placeholders replaced with actual values
- [ ] At least one scheduled workflow documented and tested
- [ ] Required directories created (logs/, scripts/, memory/)
- [ ] Post‑compaction audit test successful

### **After First Month:**
- [ ] 3+ scheduled workflows running reliably
- [ ] Error handling implemented for all workflows
- [ ] Autonomous tasks being executed during idle periods
- [ ] Performance metrics being collected and reviewed
- [ ] User receiving appropriate, non‑excessive notifications

### **Ongoing Maintenance:**
- [ ] Weekly review of workflow performance
- [ ] Monthly comparison with master template (`/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`)
- [ ] Quarterly strategic assessment of automation effectiveness
- [ ] Continuous incorporation of user feedback and corrections
- [ ] Regular backup and version control of this document

---

**Template Version**: 2.0.0  
**Created**: 2026-02-22  
**Last Updated**: 2026-02-22  
**Maintainer**: OpenClaw Agent Framework (coordinated by Kaira)  
**Purpose**: Standardized workflow documentation template for all agents  

### **Change History (Master Template):**
- **v2.0.0 (2026-02-22)**: Complete template redesign with:
  - Implementation guide for new agents
  - Pre‑compaction autonomous tasks section
  - Autonomous feedback loop framework
  - Step‑by‑step customization instructions
  - Dual purpose: template + default reference
- **v1.0.0 (2026-02-18)**: Original Aria‑specific workflow documentation (backed up as `WORKFLOW_AUTO.md.backup.2026-02-22`)

### **Notes for System Administrators:**
- Original Aria‑specific file backed up: `WORKFLOW_AUTO.md.backup.2026-02-22`
- Aria should update her workspace copy to reflect actual Finmills workflows
- Other agents should create their own `WORKFLOW_AUTO.md` from this template
- Post‑compaction audit protocol should check agent‑specific files first

*"Great automation happens when agents understand not just what to do, but why—and continuously improve both."*