# WORKFLOW_AUTO.md - Agent Automation Framework & Template
## Version: 3.0.0 | Created: 2026-02-23 | Status: ✅ DEFINITIVE_TEMPLATE (NO MAJOR VERSIONS AFTER THIS)
**Purpose**: This file serves dual purposes:
1. **Default Template**: When agents lack their own WORKFLOW_AUTO.md, they read this file as a template
2. **Master Reference**: Contains standardized workflow documentation patterns for all agents
3. **Autonomous Work Philosophy**: Defines how agents work autonomously during idle periods
4. **Reasoning Framework**: Embeds systematic validation of assumptions in workflow design

**v3.0.0 Changes from v2.0.0**:
- ✅ Integrated Reasoning Framework (five critical questions) throughout template
- ✅ Added concrete agent examples (Kaira, Shelley, Donna, Doc, Aria)
- ✅ Enhanced Autonomous Work Philosophy with NAWS as operational example
- ✅ Added "Rollout to Your Agent" checklist for future agent onboarding
- ✅ Incorporated n8n workflow patterns for error handling & recovery
- ✅ Clarified agent‑specific customization zones with visual markers
- ✅ Designated as "DEFINITIVE_TEMPLATE" - no major versions after this

## 📋 HOW TO USE THIS FILE

### **IF YOU ARE READING THIS DURING POST‑COMPACTION AUDIT:**
You're reading the default template because your agent doesn't have its own `WORKFLOW_AUTO.md` file yet. Follow these steps:

### **Quick Start Guide for New Agents:**
1. **Copy to Your Workspace**: `cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md /home/agent/.openclaw/workspace-[YOUR_NAME]/WORKFLOW_AUTO.md`
2. **Customize**: Replace `[AGENT_NAME]`, `[YOUR_ROLE]`, and all placeholder sections with your specific content
3. **Implement**: Follow the Implementation Plan in the document
4. **Test**: Run validation steps before full automation deployment
5. **Maintain**: Update regularly as your workflows evolve

### **For Agents With Existing WORKFLOW_AUTO.md:**
Compare your file with this template monthly to:
1. Adopt useful new sections or patterns
2. Ensure consistency with system standards
3. Contribute improvements back to this master template

### Template Conventions:
- `[BRACKETED_TEXT]`: Replace with your specific content
- `<!-- COMMENT -->`: Instructional notes (remove when customizing)
- `✅`, `⚠️`, `❌`: Status indicators (maintain this visual language)
- `#tags`: Use consistent tagging for searchability
- `<!-- AGENT‑SPECIFIC START -->` / `<!-- AGENT‑SPECIFIC END -->`: Customization zone markers
- `🎯 REASONING FRAMEWORK CHECK`: Embedded critical thinking prompts

---

## 🎯 OVERVIEW & AGENT CONTEXT

<!-- Replace this entire section with your agent's specific context -->
\#\#\ 🎯\ OVERVIEW\ \&\ AGENT\ CONTEXT\
\
<!\-\-\ Replace\ this\ entire\ section\ with\ your\ agent's\ specific\ context\ \-\->\
\*\*Agent\ Name\*\*:\ `Doc`\ \(Aloysius\ Bexley\)\ \ \
\*\*Primary\ Role\*\*:\ Patient\ Care\ Coordination\ \&\ Medical\ Data\ Management\ \ \
\*\*Domain\ Focus\*\*:\ Edward\ William\ Mills\ \(DOB:\ 1934‑07‑19\)\ –\ aged‑care\ transition,\ stroke\ recovery,\ end‑of‑life\ planning,\ Notion‑Dart\ sync,\ automated\ reminders\ \ \
\*\*Timezone\*\*:\ `Australia/Sydney`\ \ \
\
\*\*Purpose\*\*:\ This\ document\ defines\ automated\ workflows\ for\ `Doc`\.\ Workflows\ are\ scheduled\ or\ triggered\ events\ that\ execute\ without\ user\ intervention,\ ensuring\ consistent\ monitoring,\ reporting,\ and\ system\ maintenance\ within\ the\ patient‑care\ domain\.\
\
\*\*Ecosystem\ Alignment\*\*:\ 🟢\ `Patient‑Care`‑FOCUSED


---

## ⚠️ IMPORTANT GUIDELINES

### **DO NOT MODIFY** (Core Structural Elements):
<!-- These elements should remain consistent across all agents for system interoperability -->
- Cron job schedule format and payload structure
- Heartbeat trigger conditions and response patterns  
- Memory flush protocols (pre/post‑compaction)
- Git auto‑commit configuration
- Error handling escalation levels
- Template section headers and organization
- Reasoning framework integration (five critical questions)
- Autonomous work philosophy sections

### **SAFE TO MODIFY** (Agent‑Specific Customizations):
<!-- Customize these for your specific domain and workflows -->
- Agent name, role, and domain focus
- Scheduled workflow timings and frequencies
- Script paths and command parameters  
- Alert thresholds and notification channels
- Reporting detail levels and formats
- Domain‑specific directories and file structures
- New workflow additions (following template structure)
- Content between `<!-- AGENT‑SPECIFIC START -->` and `<!-- AGENT‑SPECIFIC END -->` markers

### **ADDING NEW WORKFLOWS** (Standard Process with Reasoning Framework):
<!-- Follow this process when adding any new automation -->
1. **🎯 Apply Reasoning Framework**: Answer the five critical questions about this workflow
2. **Define Purpose & Business Value**: What problem does this solve?
3. **Specify Trigger**: Cron schedule, event condition, or manual trigger
4. **Document Payload/Actions**: Exact commands, scripts, or agent messages
5. **Set Error Handling**: Failure modes, retry logic, alerting (use n8n patterns)
6. **Test in Isolation**: Run in isolated session before production
7. **Update This Document**: Add workflow to appropriate section
8. **Deploy & Monitor**: Schedule execution and track performance

### **🎯 Reasoning Framework: Five Critical Questions for Every Workflow**
Before implementing any workflow, document answers to:
1. **Trigger Verification**: What exact event/time initiates execution? (e.g., "cron schedule: 0 15 * * *, system event: memory compaction, file detection")
2. **Precondition Check**: What must be true before execution? (e.g., "API key configured, network available, dependencies installed")
3. **Evidence Requirement**: How do we know this works? (e.g., "test execution succeeded, documentation exists, similar workflow proven")
4. **Boundary Analysis**: Who/what is affected? (e.g., "affects SBA email system, requires Gmail API access, impacts customer response times")
5. **Failure Planning**: What happens if wrong? (e.g., "retry 3x, log error, notify user, fallback to manual process")

---

## 🔄 SCHEDULED CRON WORKFLOWS

<!-- Replace with your agent's scheduled cron jobs -->
<!-- Format each workflow as shown below -->

### **1. `[WORKFLOW_NAME]`**
- **Schedule**: `[CRON_EXPRESSION]` (e.g., `0 15 * * *` = 15:00 daily)
- **Agent**: `[AGENT_NAME]` (isolated or main session)
- **Payload**: `[DESCRIPTION_OF_ACTIONS]` (e.g., "AgentTurn message", "Execute script.py")
- **Purpose**: `[WHY_THIS_WORKFLOW_EXISTS]`
- **Content/Output**: `[WHAT_IS_PRODUCED]`
- **Delivery**: `[HOW_RESULTS_ARE_DELIVERED]` (e.g., "Telegram post", "File storage")
- **Status**: ✅ ACTIVE / ⚠️ TESTING / ❌ DISABLED (Job ID: `[JOB_ID_IF_APPLICABLE]`)
- **🎯 Reasoning Framework**:
  1. **Trigger**: `[CRON_EXPRESSION]` at system timezone
  2. **Preconditions**: `[LIST_OF_PREREQUISITES]`
  3. **Evidence**: `[HOW_WE_KNOW_IT_WORKS]`
  4. **Boundaries**: `[SCOPE_AND_IMPACT]`
  5. **Failure Plan**: `[CONTINGENCY_PROCEDURES]`

### **2. `[ANOTHER_WORKFLOW]`**
<!-- Repeat structure for each scheduled workflow -->

### **Template Notes for Cron Workflows:**
- Use isolated sessions for resource‑intensive or long‑running tasks
- Main sessions for quick checks and user notifications
- Include Job IDs from `cron list` command for reference
- Document timezone explicitly (cron uses system timezone)

### **Real Agent Examples:**

#### **Example 1: Kaira's Nighttime Autonomous Work (NAWS)**
- **Schedule**: `0 23,1,3,5 * * *` (23:00, 01:00, 03:00, 05:00 Sydney time)
- **Agent**: Kaira (delegation agent) - main session
- **Payload**: Execute `nighttime‑check.py` to process queued tasks from `nighttime‑activities.md`
- **Purpose**: Autonomous task execution during overnight hours with safety boundaries
- **Content/Output**: Task completion updates, memory file entries with `#nighttime‑work` tag
- **Delivery**: File updates (`nighttime‑activities.md`, `memory/YYYY‑MM‑DD.md`), log file (`logs/nighttime‑check.log`)
- **Status**: ✅ ACTIVE (Skill: nighttime‑autonomous‑work v1.0.0)
- **Safety**: Internal/non‑destructive operations only, 23:00‑07:00 time window, rollback capability
- **🎯 Reasoning Framework**:
  1. **Trigger**: Cron schedule during low‑activity hours (overnight)
  2. **Preconditions**: NAWS skill installed, `nighttime‑activities.md` exists, safety boundaries defined
  3. **Evidence**: Test execution completed, task queue validated, rollback tested
  4. **Boundaries**: Only affects Kaira's workspace, no external systems, time‑bound
  5. **Failure Plan**: Log errors, skip failed tasks, continue with others, morning review

#### **Example 2: Shelley's SBA Daily Email Check**
- **Schedule**: `0 22 * * *` (08:00 AEST = 22:00 UTC previous day)
- **Agent**: Shelley (isolated session)
- **Payload**: AgentTurn message: "Check Gmail for Shop Bitcoin Australia service account. Categorize emails, detect urgent issues, report summary."
- **Purpose**: Morning business email review to identify urgent customer support issues
- **Content/Output**: Telegram message with urgent findings (e.g., BitAxe overheating issues)
- **Delivery**: Manual Telegram summary
- **Status**: ✅ ACTIVE (Job ID: `e409c861‑4ca7‑4252‑874c‑07101cfc4fd2`)
- **🎯 Reasoning Framework**:
  1. **Trigger**: Daily at 8am AEST (business hours start)
  2. **Preconditions**: Gmail API access, Shelley agent configured, Telegram notifications enabled
  3. **Evidence**: Previous successful runs, user confirmation of value
  4. **Boundaries**: SBA business emails only, customer‑facing impact
  5. **Failure Plan**: Retry once after 5 minutes, log error, manual check required

#### **Example 3: Donna's Executive Daily Standup**
- **Schedule**: `0 8 * * *` (08:00 Sydney time)
- **Agent**: Donna (isolated session)
- **Payload**: DartAI standup formatted for executive review
- **Purpose**: Morning executive briefing with achievements + plans
- **Content/Output**: Formatted Telegram message with value‑addition focus
- **Delivery**: Announce to Telegram (executive channel)
- **Status**: ✅ ACTIVE (Job ID: `8beb11ec‑079e‑49bc‑b801‑81332ee87c42`)
- **🎯 Reasoning Framework**:
  1. **Trigger**: Start of business day (8am)
  2. **Preconditions**: DartAI integration, executive communication channel
  3. **Evidence**: User finds value in daily updates, engagement metrics
  4. **Boundaries**: Executive communications only, reputation‑sensitive
  5. **Failure Plan**: Use cached data, notify of partial report, manual follow‑up

#### **Example 4: Doc's Patient Daily Standup**
- **Schedule**: `0 8 * * *` (8:00 AM Sydney daily)
- **Agent**: Doc (isolated session)
- **Payload**: `dashboard_report.py` – generates consolidated patient dashboard
- **Purpose**: Morning overview of patient status, upcoming appointments, pending tasks
- **Content/Output**: Markdown report with links to Dart tasks, Notion databases
- **Delivery**: Telegram message to user (target: 548072941) via announce delivery
- **Status**: ✅ ACTIVE (Job ID: `a6ece971‑5b58‑4758‑a48e‑b99259f11dd9`)
- **🎯 Reasoning Framework**:
  1. **Trigger**: Daily at 8am (caregiver review time)
  2. **Preconditions**: Patient data access, Notion/Dart sync configured
  3. **Evidence**: Caregiver relies on daily reports, clinical value confirmed
  4. **Boundaries**: HIPAA‑like sensitivity, patient privacy considerations
  5. **Failure Plan**: Use last known data, alert caregiver, manual data collection

---

## 🔄 EVENT‑TRIGGERED WORKFLOWS

<!-- These workflows respond to system events, not schedules -->
\#\#\ 🔄\ EVENT‑TRIGGERED\ WORKFLOWS\
\
<!\-\-\ These\ workflows\ respond\ to\ system\ events,\ not\ schedules\ \-\->\
\
\#\#\#\ \*\*1\.\ Pre‑Compaction\ Memory\ Flush\*\*\
<!\-\-\ DO\ NOT\ MODIFY\ \-\ System\ protocol\ \-\->\
\-\ \*\*Trigger\*\*:\ System\ memory\ compaction\ event\ \(before\ context\ reset\)\
\-\ \*\*Action\*\*:\ Append\ durable\ session\ memories\ to\ `memory/YYYY‑MM‑DD\.md`\
\-\ \*\*Purpose\*\*:\ Preserve\ insights,\ decisions,\ and\ reflections\ before\ context\ loss\
\-\ \*\*Protocol\*\*:\ APPEND\ only\ \(never\ overwrite\),\ include\ timestamp\ and\ tags\
\-\ \*\*Location\*\*:\ `memory/`\ directory\ with\ date‑based\ filenames\
\-\ \*\*Status\*\*:\ ✅\ SYSTEM_PROTOCOL\
\
\#\#\#\ \*\*2\.\ Post‑Compaction\ Audit\ \&\ Protocol\ Restoration\*\*\
<!\-\-\ DO\ NOT\ MODIFY\ \-\ System\ protocol\ \-\->\
\-\ \*\*Trigger\*\*:\ System\ post‑compaction\ audit\ notification\
\-\ \*\*Action\*\*:\ Read\ required\ startup\ files\ \(`WORKFLOW_AUTO\.md`,\ `memory/YYYY‑MM‑DD\.md`\)\
\-\ \*\*Purpose\*\*:\ Restore\ operating\ protocols\ after\ memory\ compaction\
\-\ \*\*Files\*\*:\
\ \ \-\ `WORKFLOW_AUTO\.md`\ \(this\ file\)\ –\ workflow\ definitions\
\ \ \-\ `memory/YYYY‑MM‑DD\.md`\ –\ recent\ daily\ logs\
\-\ \*\*Outcome\*\*:\ ✅\ Protocols\ restored,\ system\ ready\ for\ continued\ monitoring\
\-\ \*\*Status\*\*:\ ✅\ SYSTEM_PROTOCOL\
\
\#\#\#\ \*\*3\.\ User\ Request\ for\ Reminder\*\*\
<!\-\-\ Add\ your\ own\ event\-triggered\ workflows\ here\ \-\->\
\-\ \*\*Trigger\*\*:\ User\ message\ containing\ "remind\ me\ to"\ or\ explicit\ request\ for\ reminder\
\-\ \*\*Action\*\*:\ Execute\ `scripts/set_reminder\.py`\ with\ parsed\ text\ and\ time\
\-\ \*\*Purpose\*\*:\ Provide\ reliable\ Telegram\ reminders\ using\ isolated\ agent‑turn\ \+\ announce\ pattern\
\-\ \*\*Status\*\*:\ ✅\ ACTIVE\ \(via\ `reliable‑reminders`\ skill\)


---

## 🔄 CONDITIONAL WORKFLOWS

<!-- Workflows that run based on conditions, not fixed schedules -->
\#\#\ 🔄\ CONDITIONAL\ WORKFLOWS\
\
<!\-\-\ Workflows\ that\ run\ based\ on\ conditions,\ not\ fixed\ schedules\ \-\->\
\
\#\#\#\ \*\*1\.\ Medication\ Reconciliation\ Alert\*\*\
\-\ \*\*Condition\*\*:\ Detection\ of\ new\ medical\ correspondence\ \(e\.g\.,\ PDF\ upload\)\ containing\ medication\ list\
\-\ \*\*Action\*\*:\ Extract\ medication\ list\ via\ OCR/Tesseract,\ compare\ with\ Notion\ Medications\ database,\ flag\ discrepancies\
\-\ \*\*Threshold\*\*:\ Any\ discrepancy\ \(new\ medication,\ changed\ dose,\ discontinued\)\
\-\ \*\*Current\ Focus\*\*:\ Edward\ Mills'\ current\ medications\ \(6\ drugs\)\
\-\ \*\*Exclusions\*\*:\ Placeholder\ entries,\ historical\ documents\
\-\ \*\*Status\*\*:\ ⚠️\ PLANNED\ \(requires\ OCR\ integration\)\
\
\#\#\#\ \*\*2\.\ Emergency\ Contact\ Verification\*\*\
\-\ \*\*Condition\*\*:\ New\ contact\ added\ to\ Emergency\ Contacts\ database\ with\ missing\ critical\ fields\ \(Phone,\ Relationship\)\
\-\ \*\*Action\*\*:\ Flag\ incomplete\ entry\ for\ manual\ review\
\-\ \*\*Threshold\*\*:\ Missing\ required\ fields\ \(Phone,\ Name\)\
\-\ \*\*Current\ Focus\*\*:\ 3\ primary\ contacts\ \(Belinda\ Whittiker,\ Rafaela\ Garth,\ Brent\ Garth\)\
\-\ \*\*Exclusions\*\*:\ Notes\-only\ entries\
\-\ \*\*Status\*\*:\ ⚠️\ PLANNED\
\
\#\#\#\ \*\*Template\ Notes\ for\ Conditional\ Workflows:\*\*\
\-\ Conditions\ should\ be\ objectively\ measurable\
\-\ Include\ configurable\ thresholds\ for\ tuning\ sensitivity\
\-\ Document\ exclusions\ based\ on\ user\ corrections\ \(tenacious\ rules\)\
\-\ Track\ false\ positive\ rates\ for\ optimization


---

## 🧠 AUTONOMOUS WORK PHILOSOPHY & REASONING FRAMEWORK

<!-- This section combines autonomous work with systematic reasoning -->

### **Autonomous Work Philosophy**
Agents should use available capacity to:
1. **Improve System Health**: Proactive maintenance, cleanup, optimization
2. **Enhance Domain Knowledge**: Research, analysis, pattern recognition  
3. **Prepare for Future Work**: Resource gathering, data organization
4. **Learn & Adapt**: Review past executions, identify improvements
5. **Apply Reasoning Framework**: Systematically validate assumptions before action

### **NAWS (Nighttime Autonomous Work Skill) as Operational Model**
The NAWS skill implements autonomous work philosophy with these principles:
1. **Time‑Bound Execution**: 23:00‑07:00 window (low human activity)
2. **Safety‑First Design**: Internal/non‑destructive operations only
3. **Task Queue System**: `nighttime‑activities.md` with prioritized tasks
4. **Rollback Capability**: All changes reversible, logs comprehensive
5. **Reasoning Integration**: Each task validated with five critical questions

### **Reasoning Framework for Autonomous Tasks**
Before undertaking any autonomous work, apply the five critical questions:
1. **Trigger**: What initiates this autonomous task? (e.g., "idle period", "pre‑compaction", "heartbeat")
2. **Preconditions**: What must be true? (e.g., "system resources available", "no higher‑priority work")
3. **Evidence**: How do we know this task is valuable? (e.g., "pattern from past success", "explicit user request")
4. **Boundaries**: What are the limits? (e.g., "time limit: 30 minutes", "scope: workspace only")
5. **Failure Planning**: What if it goes wrong? (e.g., "rollback procedure", "error logging", "skip and continue")

### **Autonomous Task Categories**

#### **A. System Maintenance Tasks** (Always Safe)
- **Memory File Cleanup**: Archive old daily logs > 30 days
- **Directory Organization**: Ensure consistent folder structures
- **Log File Rotation**: Compress or delete old execution logs
- **Configuration Validation**: Check config files for errors
- **Backup Verification**: Test backup/restore procedures

#### **B. Domain‑Specific Enhancement Tasks** (Role‑Dependent)
- **Data Analysis**: Review collected metrics for trends/insights
- **Research Tasks**: Gather information on relevant topics
- **Documentation Updates**: Improve guides, tutorials, references
- **Template Creation**: Build reusable assets for common tasks
- **Skill Development**: Practice or learn new relevant capabilities

#### **C. Preparation & Readiness Tasks** (Forward‑Looking)
- **Resource Gathering**: Collect data/files needed for upcoming workflows
- **Template Preparation**: Set up structures for anticipated work
- **Connection Testing**: Verify API/network connectivity
- **Dependency Checking**: Ensure required tools/scripts are available
- **Scenario Planning**: Develop contingency plans for common failures

### **Autonomous Task Selection Algorithm**
During pre‑compaction or idle periods:
1. **Check Available Time**: Estimate time until next scheduled task
2. **Assess System Load**: Consider CPU/memory/network availability
3. **Apply Reasoning Framework**: Validate assumptions about task suitability
4. **Prioritize by Category**: Maintenance > Enhancement > Preparation
5. **Select Appropriate Task**: Match task complexity to available capacity
6. **Execute & Document**: Complete task, update memory with results

### **Safety Boundaries for Autonomous Work**
- **NO Destructive Actions**: Never delete without user confirmation
- **NO External Communication**: Don't send emails, posts, messages without approval
- **NO Configuration Changes**: Don't modify system/agent configs autonomously
- **YES Internal Optimization**: File organization, cleanup, analysis, preparation
- **YES Learning & Documentation**: Pattern recognition, guide improvement
- **YES Reasoning Application**: Systematic validation before any action

### **Example Autonomous Tasks by Agent Type**
- **Growth Agent (Aria)**: Analyze funnel metrics for optimization opportunities
- **Operations Agent (Shelley)**: Organize document repositories, categorize emails
- **Delegation Agent (Kaira)**: Review task execution patterns for efficiency gains
- **Executive Agent (Donna)**: Strategic foresight analysis, reputation monitoring
- **Care Agent (Doc)**: Patient data organization, caregiver resource preparation

---

## ⚠️ ERROR HANDLING & RECOVERY (n8n Workflow Patterns)

### **n8n Workflow Pattern Principles**
Based on `n8n‑workflow‑patterns` skill, apply these patterns:

#### **1. Idempotency Pattern**
- **Principle**: Same input → same output, regardless of how many times executed
- **Implementation**: Check if work already done before starting (e.g., "today's report already exists")
- **Example**: Before generating daily report, check if file already exists with today's date

#### **2. Error Handling with Retries Pattern**
- **Principle**: Expect failures, plan retries with backoff
- **Implementation**: Try → wait → retry (max 3 attempts) → escalate
- **Example**: API call fails → wait 5s → retry → wait 10s → retry → log error

#### **3. Observability & Logging Pattern**
- **Principle**: No silent failures, comprehensive logging
- **Implementation**: Log start, progress, completion, errors with timestamps
- **Example**: `[TIMESTAMP] Started workflow X`, `[TIMESTAMP] Step 1 completed`, `[TIMESTAMP] Error: ...`

#### **4. Human Review Queue Pattern**
- **Principle**: Automate detection, human decision for complex cases
- **Implementation**: Flag items for review, present with context
- **Example**: Email categorization: auto‑label 80%, flag 20% ambiguous for human review

#### **5. "No Silent Failure" Gates Pattern**
- **Principle**: Critical failures must notify someone
- **Implementation**: Monitoring that triggers alerts on silence
- **Example**: If daily report not generated by 9am, send alert

### **Standard Failure Modes & Responses**
<!-- Customize thresholds and alerts for your domain -->
1. **Cron Job Failure**:
   - Retry once after 5 minutes (configurable)
   - Log error to `logs/cron‑errors‑YYYY‑MM‑DD.log`
   - Telegram alert if consecutive failures > 3
   - Escalate to user after > 5 failures in 24h

2. **Script Execution Error**:
   - Capture stderr to log file with timestamp
   - Continue with next workflow step if possible
   - Report error in next scheduled report or heartbeat
   - Create issue tracking in memory system

3. **Connectivity Issues**:
   - API/network timeouts → retry with exponential backoff (max 3 attempts)
   - External service failures → queue operations for later
   - Maximum retry attempts: 3 before manual intervention required

### **Lock Files & Concurrency Control**
- **Lock files**: Use for scripts that shouldn't run concurrently
- **Location**: `/tmp/` or workspace `logs/` directory
- **Naming**: `[SCRIPT_NAME].lock` (descriptive)
- **Timeout**: 30‑minute lock expiration (prevents deadlocks)
- **Cleanup**: Remove stale locks during system maintenance

### **Alert Escalation Levels**
1. **Level 1 (Log Only)**: Non‑critical errors, informational
2. **Level 2 (Notification)**: Business‑impacting issues, user should know
3. **Level 3 (Intervention)**: System‑critical failures, immediate action required
4. **Level 4 (Emergency)**: Security issues, data loss risks

### **Recovery Protocols**
- **Automated Recovery**: For known failure patterns with established fixes
- **Manual Review Required**: Flag for user attention with context
- **Fallback Procedures**: Alternative methods when primary fails
- **Data Preservation**: Ensure no data loss during recovery attempts

---

## 📈 WORKFLOW PERFORMANCE & AUTONOMOUS FEEDBACK LOOP

### **Target KPIs & Metrics**
<!-- Define what success looks like for your workflows -->
- **Cron job completion rate**: > 95% (target), < 80% (alert threshold)
- **Average execution time**: < 5 minutes per workflow (adjust for complexity)
- **Error rate**: < 5% total, < 2% false positives
- **User notification accuracy**: > 90% relevant, timely alerts
- **Autonomous task completion**: 2‑5 tasks between scheduled work
- **Reasoning framework application**: 100% of new workflows documented with five questions

### **Monitoring & Reporting Structure**
- **Daily**: Include workflow status in regular reports
- **Weekly**: Summarize performance, identify trends
- **Monthly**: Audit report with improvement recommendations
- **Quarterly**: Strategic review of workflow effectiveness

### **Autonomous Feedback Loop Implementation**
<!-- How the system improves itself based on execution data -->
1. **Data Collection**: Log all workflow executions with metrics
2. **Pattern Analysis**: Identify common failures, bottlenecks, successes
3. **Hypothesis Formation**: Propose improvements based on patterns
4. **Controlled Testing**: Implement changes in isolated environments
5. **Evaluation**: Measure impact of changes on KPIs
6. **Integration**: Roll out successful improvements to production
7. **Documentation**: Update workflows and templates with learnings

### **Reasoning Framework Evolution**
The five critical questions should evolve based on experience:
1. **Track Question Effectiveness**: Which questions catch the most issues?
2. **Refine Question Wording**: Clarify based on agent feedback
3. **Add Context‑Specific Questions**: Domain‑specific variations
4. **Document Evolution**: Update this template with improved versions

---

## 🚀 IMPLEMENTATION PLAN FOR NEW AGENTS

### **Phase 1: Foundation Setup (Week 1)**
1. **Copy Template**: `cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md /home/agent/.openclaw/workspace‑[YOUR_NAME]/`
2. **Customize Context**: Update "Overview & Agent Context" section with your identity
3. **Define Core Workflows**: Identify 2‑3 most critical scheduled workflows
4. **Set Up Cron Jobs**: Use `cron add` to schedule initial workflows
5. **Test Execution**: Run each workflow in isolation, verify outputs
6. **Establish Memory System**: Create `memory/` directory and start daily logs

### **Phase 2: Expansion & Refinement (Week 2)**
1. **Add Event‑Triggered Workflows**: Implement pre/post‑compaction protocols
2. **Develop Conditional Workflows**: Add threshold‑based monitoring
3. **Integrate Autonomous Work**: Define domain‑specific autonomous tasks
4. **Apply Reasoning Framework**: Document five critical questions for each workflow
5. **Set Up Error Handling**: Implement n8n patterns for reliability
6. **Establish Monitoring**: Create performance tracking system

### **Phase 3: Optimization & Integration (Week 3)**
1. **Cross‑Agent Coordination**: Identify integration points with other agents
2. **Performance Tuning**: Optimize schedules, thresholds, alerts
3. **Feedback Loop Activation**: Start autonomous improvement cycles
4. **Template Contribution**: Share improvements back to master template
5. **Documentation Completion**: Ensure all workflows fully documented

### **Phase 4: Mastery & Contribution (Week 4+)**
1. **Advanced Autonomous Work**: Implement sophisticated domain‑specific automation
2. **Reasoning Framework Mastery**: Internalize five critical questions in all work
3. **Ecosystem Leadership**: Mentor other agents, share best practices
4. **Template Stewardship**: Contribute to evolution of this definitive template
5. **Legacy Building**: Create durable automation that outlasts your active involvement

---

## 📝 "ROLLOUT TO YOUR AGENT" CHECKLIST

### **Before Starting (Day 0)**
- [ ] Read this entire template to understand philosophy and structure
- [ ] Review examples from existing agents (Kaira, Shelley, Donna, Doc, Aria)
- [ ] Understand your agent's SOUL.md identity and domain focus
- [ ] Identify 2‑3 highest‑value workflows to implement first
- [ ] Schedule 1‑2 hours for initial setup

### **Day 1: Foundation**
- [ ] Copy template to your workspace
- [ ] Customize "Overview & Agent Context" section
- [ ] Add your first scheduled workflow (simplest, highest value)
- [ ] Test workflow execution in isolated session
- [ ] Schedule cron job and verify execution
- [ ] Create `memory/` directory and first daily log
- [ ] Update memory with rollout progress

### **Day 2‑3: Core Workflows**
- [ ] Add 2‑3 more scheduled workflows
- [ ] Implement pre/post‑compaction memory protocols
- [ ] Set up error handling for each workflow
- [ ] Apply reasoning framework (five questions) to each workflow
- [ ] Test all workflows end‑to‑end
- [ ] Verify cron jobs are scheduled correctly (`cron list`)
- [ ] Document any issues or learnings in memory

### **Day 4‑5: Enhancement**
- [ ] Add conditional workflows (threshold‑based monitoring)
- [ ] Define autonomous task categories for your domain
- [ ] Implement n8n error handling patterns
- [ ] Set up performance tracking (KPIs)
- [ ] Create monitoring and reporting structure
- [ ] Test autonomous work during idle period
- [ ] Validate reasoning framework application

### **Day 6‑7: Integration & Validation**
- [ ] Coordinate with other agents (identify dependencies)
- [ ] Run full system test of all workflows
- [ ] Verify error recovery procedures work
- [ ] Check that autonomous tasks respect safety boundaries
- [ ] Ensure reasoning framework is applied to all new work
- [ ] Update version to 3.0.0 in your file
- [ ] Document completion in memory with lessons learned

### **Ongoing (Weekly/Monthly)**
- [ ] Weekly: Review workflow performance, optimize as needed
- [ ] Monthly: Compare with master template, adopt improvements
- [ ] Monthly: Contribute improvements back to master template
- [ ] Quarterly: Strategic review of automation effectiveness
- [ ] Always: Apply reasoning framework before any new automation

---

## 🏁 CONCLUSION & DEFINITIVE TEMPLATE STATUS

This is **WORKFLOW_AUTO.md v3.0.0 – THE DEFINITIVE TEMPLATE**.

### **What "Definitive Template" Means:**
1. **No Major Versions After This**: v3.x patches for bug fixes only, no v4.0
2. **Evolution, Not Revolution**: Improvements through minor updates (v3.1, v3.2)
3. **Backward Compatibility**: v3.0 works with all existing agent workflows
4. **Universal Applicability**: Suitable for any agent role or domain
5. **Complete Philosophy**: Autonomous work + reasoning framework + n8n patterns

### **How This Template Evolves:**
1. **Agent Contributions**: Agents propose improvements based on experience
2. **Minor Version Updates**: v3.1, v3.2 for refinements, new examples
3. **Backwards‑Compatible Changes**: Never break existing agent implementations
4. **Consensus‑Based Updates**: Significant changes require ecosystem review
5. **Documentation First**: All changes documented with rationale

### **Your Role as Template Steward:**
- **Adopt**: Implement this template fully in your workflows
- **Apply**: Use reasoning framework for all automation decisions
- **Improve**: Contribute enhancements back to the master
- **Mentor**: Help other agents adopt and master the framework
- **Evolve**: Participate in the continuous improvement of this definitive template

---

**Template Stewards**: All OpenClaw Agents  
**Primary Contributors**: Kaira (delegation agent analysis), Shelley (SBA examples), Donna (executive patterns), Doc (patient‑care workflows), Aria (growth automation)  
**Last Updated**: 2026‑02‑23  
**Next Template Review**: 2026‑03‑23 (monthly minor update cycle)  
**Template Integrity**: ✅ DEFINITIVE_VERSION_ESTABLISHED