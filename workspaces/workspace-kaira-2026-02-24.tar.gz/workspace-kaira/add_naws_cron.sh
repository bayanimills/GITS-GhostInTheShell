#!/bin/bash
set -e

add_naws_cron() {
    local agent=$1
    local workspace=$2
    
    # Check if cron entry already exists
    if crontab -l 2>/dev/null | grep -q "nighttime-check.py.*$workspace"; then
        echo "NAWS cron already exists for $agent"
        return 0
    fi
    
    # Create cron entry
    cron_line="0 23,1,3,5 * * * cd '$workspace' && OPENCLAW_WORKSPACE='$workspace' python3 '/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/nighttime-check.py' >> '$workspace/logs/nighttime-check.log' 2>&1"
    
    # Add to crontab
    (crontab -l 2>/dev/null; echo "# NAWS for $agent"; echo "$cron_line") | crontab -
    echo "Added NAWS cron for $agent"
}

echo "Adding NAWS cron jobs for all agents..."

# Add for each agent
add_naws_cron "aria" "/home/agent/.openclaw/workspace-aria"
add_naws_cron "danny" "/home/agent/.openclaw/workspace-danny"
add_naws_cron "doc" "/home/agent/.openclaw/workspace-doc"
add_naws_cron "donna" "/home/agent/.openclaw/workspace-donna"
add_naws_cron "shelley" "/home/agent/.openclaw/workspace-shelley"
add_naws_cron "main" "/home/agent/.openclaw/workspace"
add_naws_cron "kaira" "/home/agent/.openclaw/workspace-kaira"

echo "Done."