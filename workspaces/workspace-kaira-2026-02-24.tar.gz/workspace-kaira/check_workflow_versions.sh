#!/bin/bash
# WORKFLOW_AUTO.md Template Version Checker
# Compares agent-specific files against master template
# Reports outdated files and missing files
# To be run weekly (Monday 1am UTC)

TEMPLATE="/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md"
NOTICE_FILE="/home/agent/.openclaw/workspace/WORKFLOW_TEMPLATE_UPDATE_NOTICE.md"
LOG_FILE="/home/agent/.openclaw/workspace-kaira/memory/workflow_version_check.log"
TEMPLATE_TS="2026-02-22 11:19"  # Template v2.0.0 creation time

# Create log directory if needed
mkdir -p "$(dirname "$LOG_FILE")"

echo "=== WORKFLOW_AUTO.md VERSION CHECK ===" | tee -a "$LOG_FILE"
echo "Check time: $(date)" | tee -a "$LOG_FILE"
echo "Template: $TEMPLATE (v2.0.0, created $TEMPLATE_TS)" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Initialize status arrays
OUTDATED=()
MISSING=()
UP_TO_DATE=()

# Check each agent
for agent in aria shelley donna doc danny kaira main; do
    AGENT_FILE="/home/agent/.openclaw/workspace-$agent/WORKFLOW_AUTO.md"
    
    if [ ! -f "$AGENT_FILE" ]; then
        echo "❌ $agent: NO FILE (will read template during next audit)" | tee -a "$LOG_FILE"
        MISSING+=("$agent")
        continue
    fi
    
    # Get file modification time
    MOD_TIME=$(stat -c "%y" "$AGENT_FILE" 2>/dev/null | cut -d'.' -f1)
    SIZE=$(stat -c "%s" "$AGENT_FILE" 2>/dev/null)
    
    # Check if modified after template creation
    if [[ "$MOD_TIME" > "2026-02-22 11:19" ]]; then
        # Check for template adoption indicators
        HAS_AUTONOMOUS=$(grep -i "autonomous" "$AGENT_FILE" | wc -l)
        HAS_PRECOMPACTION=$(grep -i "pre.compaction\|pre-compaction\|pre compaction" "$AGENT_FILE" | wc -l)
        HAS_FRAMEWORK=$(grep -i "framework" "$AGENT_FILE" | wc -l)
        
        if [ "$HAS_AUTONOMOUS" -gt 0 ] || [ "$HAS_PRECOMPACTION" -gt 0 ] || [ "$HAS_FRAMEWORK" -gt 0 ]; then
            echo "✅ $agent: UPDATED ($SIZE bytes, $MOD_TIME) - Template patterns detected" | tee -a "$LOG_FILE"
            UP_TO_DATE+=("$agent")
        else
            echo "⚠️  $agent: RECENT but lacks template patterns ($SIZE bytes, $MOD_TIME)" | tee -a "$LOG_FILE"
            OUTDATED+=("$agent")
        fi
    else
        echo "⚠️  $agent: OLD VERSION ($SIZE bytes, $MOD_TIME) - Template is newer" | tee -a "$LOG_FILE"
        OUTDATED+=("$agent")
    fi
done

echo "" | tee -a "$LOG_FILE"
echo "=== SUMMARY ===" | tee -a "$LOG_FILE"
echo "Up-to-date: ${#UP_TO_DATE[@]} agents (${UP_TO_DATE[*]})" | tee -a "$LOG_FILE"
echo "Outdated: ${#OUTDATED[@]} agents (${OUTDATED[*]})" | tee -a "$LOG_FILE"
echo "Missing: ${#MISSING[@]} agents (${MISSING[*]})" | tee -a "$LOG_FILE"

# Generate system event if outdated agents found
if [ ${#OUTDATED[@]} -gt 0 ] || [ ${#MISSING[@]} -gt 0 ]; then
    echo "" | tee -a "$LOG_FILE"
    echo "⚠️  SYSTEM ALERT: $(( ${#OUTDATED[@]} + ${#MISSING[@]} )) agents need WORKFLOW_AUTO.md updates" | tee -a "$LOG_FILE"
    echo "Outdated: ${OUTDATED[*]}" | tee -a "$LOG_FILE"
    echo "Missing: ${MISSING[*]}" | tee -a "$LOG_FILE"
    echo "Template: $TEMPLATE" | tee -a "$LOG_FILE"
    echo "Notice file: $NOTICE_FILE" | tee -a "$LOG_FILE"
    
    # Create a system event message (for cron job to inject)
    SYSTEM_EVENT="[WORKFLOW_VERSION_CHECK] $(( ${#OUTDATED[@]} + ${#MISSING[@]} )) agents need WORKFLOW_AUTO.md updates. Outdated: ${OUTDATED[*]}. Missing: ${MISSING[*]}. Template: $TEMPLATE. Full log: $LOG_FILE"
    echo "SYSTEM_EVENT: $SYSTEM_EVENT" | tee -a "$LOG_FILE"
    
    # Update notice file completion tracking
    if [ -f "$NOTICE_FILE" ]; then
        for agent in "${UP_TO_DATE[@]}"; do
            # Update tracking table if agent is listed
            sed -i "s/| $agent | ⏳ PENDING |/| $agent | ✅ COMPLETED | $(date +%Y-%m-%d) |/" "$NOTICE_FILE" 2>/dev/null
        done
        echo "Updated notice file completion tracking" | tee -a "$LOG_FILE"
    fi
else
    echo "" | tee -a "$LOG_FILE"
    echo "✅ All agents have up-to-date WORKFLOW_AUTO.md files" | tee -a "$LOG_FILE"
fi

echo "" | tee -a "$LOG_FILE"
echo "Check complete. Log saved to $LOG_FILE" | tee -a "$LOG_FILE"