#!/bin/bash
# install-aws-with-bootstrap.sh
# Wrapper script for AWS installation with bootstrap verification
# Implements Option 1 + 2: Post-installation hook + AWS task queue entry

set -e

# Determine workspace path
if [ -n "$OPENCLAW_WORKSPACE" ]; then
    WORKSPACE="$OPENCLAW_WORKSPACE"
else
    # Try to detect from current directory
    if [[ "$(pwd)" =~ \.openclaw/workspace-[a-zA-Z]+$ ]]; then
        WORKSPACE="$(pwd)"
    else
        WORKSPACE="$HOME/.openclaw/workspace"
        echo "Warning: OPENCLAW_WORKSPACE not set, defaulting to $WORKSPACE"
    fi
fi

# Determine script locations
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BOOTSTRAP_SCRIPT="$SCRIPT_DIR/bootstrap-agent.sh"
AWS_SKILL_DIR="$HOME/.openclaw/workspace/skills/nighttime-autonomous-work"
AWS_MIGRATE_SCRIPT="$AWS_SKILL_DIR/migrate-to-autonomous.sh"
AWS_SETUP_SCRIPT="$AWS_SKILL_DIR/setup-autonomous-cron.sh"
ACTIVITIES_FILE="$WORKSPACE/aws-task-queue.md"

echo "=== AWS Installation with Bootstrap Verification ==="
echo "Workspace: $WORKSPACE"
echo "Bootstrap script: $BOOTSTRAP_SCRIPT"
echo "AWS skill directory: $AWS_SKILL_DIR"
echo ""

# Step 1: Verify prerequisites
if [ ! -f "$BOOTSTRAP_SCRIPT" ]; then
    echo "❌ Error: Bootstrap script not found at $BOOTSTRAP_SCRIPT"
    echo "Please ensure bootstrap-agent.sh exists in the current directory."
    exit 1
fi

if [ ! -d "$AWS_SKILL_DIR" ]; then
    echo "❌ Error: AWS skill directory not found at $AWS_SKILL_DIR"
    echo "Please install the nighttime-autonomous-work skill first."
    exit 1
fi

if [ ! -f "$AWS_MIGRATE_SCRIPT" ]; then
    echo "❌ Error: AWS migration script not found at $AWS_MIGRATE_SCRIPT"
    exit 1
fi

# Step 2: Run AWS installation
echo "📦 Step 1: Installing AWS (24/7 Autonomous Workflow System)..."
echo ""

if [ -f "$AWS_MIGRATE_SCRIPT" ]; then
    # Use migration script (handles both new install and migration)
    echo "Running: $AWS_MIGRATE_SCRIPT"
    echo ""
    bash "$AWS_MIGRATE_SCRIPT"
else
    # Fallback to setup script
    echo "Running: $AWS_SETUP_SCRIPT"
    echo ""
    bash "$AWS_SETUP_SCRIPT"
fi

echo ""
echo "✅ AWS installation complete"
echo ""

# Step 3: Immediate bootstrap verification (Option 1)
echo "🔍 Step 2: Running immediate bootstrap verification..."
echo ""

if [ -x "$BOOTSTRAP_SCRIPT" ]; then
    echo "Executing: $BOOTSTRAP_SCRIPT"
    echo ""
    cd "$SCRIPT_DIR" && "$BOOTSTRAP_SCRIPT"
    BOOTSTRAP_EXIT_CODE=$?
    
    if [ $BOOTSTRAP_EXIT_CODE -eq 0 ]; then
        echo ""
        echo "✅ Bootstrap verification completed successfully"
        echo ""
        
        # Record bootstrap execution in memory
        BOOTSTRAP_REPORT="$WORKSPACE/memory/bootstrap-report-$(date +%Y-%m-%d).md"
        if [ -f "$BOOTSTRAP_REPORT" ]; then
            echo "📋 Bootstrap report: $BOOTSTRAP_REPORT"
        fi
    else
        echo ""
        echo "⚠️  Bootstrap verification completed with exit code $BOOTSTRAP_EXIT_CODE"
        echo "Please review the output above for any issues."
        echo ""
    fi
else
    echo "⚠️  Bootstrap script not executable: $BOOTSTRAP_SCRIPT"
    echo "Skipping immediate verification (run manually: ./bootstrap-agent.sh)"
    echo ""
fi

# Step 4: Add bootstrap verification to AWS task queue (Option 2)
echo "📋 Step 3: Adding bootstrap verification to AWS task queue..."
echo ""

if [ -f "$ACTIVITIES_FILE" ]; then
    # Check if bootstrap task already exists
    if grep -q "bootstrap verification" "$ACTIVITIES_FILE"; then
        echo "✅ Bootstrap verification task already exists in AWS task queue"
    else
        # Create backup
        BACKUP_FILE="$ACTIVITIES_FILE.backup.$(date +%Y%m%d%H%M%S)"
        cp "$ACTIVITIES_FILE" "$BACKUP_FILE"
        echo "✅ Backup created: $BACKUP_FILE"
        
        # Add bootstrap verification task
        TEMP_FILE="$ACTIVITIES_FILE.tmp"
        
        # Read file and insert task in appropriate section
        awk -v bootstrap_task="### Bootstrap Workspace Verification
- **Status**: pending
- **Created\": $(date +"%Y-%m-%d %H:%M %Z")
- **Started**: 
- **Completed**: 
- **Description**: Run bootstrap verification to ensure workspace configuration integrity
- **Context**: Post-AWS installation verification and periodic health checking
- **Safety check**: internal/non-destructive verified
- **Permission required**: read-only
- **Tags**: #bootstrap #verification #workspace-health #periodic" '
        /^## Tasks/ {
            print $0
            print ""
            print bootstrap_task
            print ""
            next
        }
        { print }' "$ACTIVITIES_FILE" > "$TEMP_FILE"
        
        mv "$TEMP_FILE" "$ACTIVITIES_FILE"
        echo "✅ Added bootstrap verification task to AWS task queue"
    fi
    
    echo "AWS task queue location: $ACTIVITIES_FILE"
else
    echo "⚠️  AWS task queue file not found: $ACTIVITIES_FILE"
    echo "Creating basic task queue file..."
    
    cat > "$ACTIVITIES_FILE" << EOF
# Autonomous Work - $(date +%Y-%m-%d)

## Summary
- **Status**: Active
- **Last check-in**: $(date +"%Y-%m-%d %H:%M %Z")
- **Tasks completed**: 0 of 0
- **Next check-in**: 
- **Current permission level**: 
- **Presence detection**: 

## Tasks

### Bootstrap Workspace Verification
- **Status**: pending
- **Created**: $(date +"%Y-%m-%d %H:%M %Z")
- **Started**: 
- **Completed**: 
- **Description**: Run bootstrap verification to ensure workspace configuration integrity
- **Context**: Post-AWS installation verification and periodic health checking
- **Safety check**: internal/non-destructive verified
- **Permission required**: read-only
- **Tags**: #bootstrap #verification #workspace-health #periodic
EOF
    
    echo "✅ Created AWS task queue file with bootstrap verification task"
fi

echo ""
echo "📝 Step 4: Creating installation summary..."
echo ""

# Create installation summary
INSTALLATION_SUMMARY="$WORKSPACE/memory/aws-installation-summary-$(date +%Y-%m-%d).md"
cat > "$INSTALLATION_SUMMARY" << EOF
# AWS Installation with Bootstrap Verification Summary
**Date**: $(date +"%Y-%m-%d %H:%M %Z")
**Workspace**: $WORKSPACE
**Agent**: $(basename "$WORKSPACE")

## Installation Components
1. **AWS (24/7 Autonomous Workflow System)**: Installed via migrate-to-autonomous.sh
2. **Bootstrap Verification**: Immediate execution post-installation
3. **AWS Task Queue**: Bootstrap verification task added for periodic execution

## Verification Status
- **AWS Installation**: ✅ Complete
- **Bootstrap Execution**: $(if [ $BOOTSTRAP_EXIT_CODE -eq 0 ]; then echo "✅ Success"; else echo "⚠️  Exit code: $BOOTSTRAP_EXIT_CODE"; fi)
- **Task Queue Integration**: ✅ Bootstrap task added

## Next Steps
1. **Review AWS configuration**: Check crontab for autonomous-check schedule
2. **Monitor logs**: tail -f $WORKSPACE/logs/autonomous-check.log
3. **Customize task queue**: Edit $ACTIVITIES_FILE to add agent-specific tasks
4. **Test autonomous operation**: Wait for next scheduled run or trigger manually

## Manual Override
To pause autonomy temporarily:
\`\`\`bash
touch ~/.openclaw-autonomy-pause
\`\`\`

To resume autonomy:
\`\`\`bash
rm ~/.openclaw-autonomy-pause
\`\`\`

## Bootstrap Reports
- **Latest report**: $(ls -t "$WORKSPACE/memory/bootstrap-report-"*.md 2>/dev/null | head -1 || echo "None yet")

## Tags
#aws-installation #bootstrap-verification #workspace-configuration #autonomous-workflow
EOF

echo "✅ Installation summary created: $INSTALLATION_SUMMARY"
echo ""

echo "=== Installation Complete ==="
echo ""
echo "✅ AWS (24/7 Autonomous Workflow System) installed"
echo "✅ Bootstrap verification executed"
echo "✅ Bootstrap task added to AWS task queue for periodic verification"
echo "✅ Installation summary saved to memory"
echo ""
echo "📊 System Status:"
echo "   Workspace: $WORKSPACE"
echo "   AWS Schedule: Every 30 minutes (test mode)"
echo "   Logs: $WORKSPACE/logs/autonomous-check.log"
echo "   Task Queue: $ACTIVITIES_FILE"
echo ""
echo "🔧 Next Actions:"
echo "   1. Review installation summary: $INSTALLATION_SUMMARY"
echo "   2. Check crontab: crontab -l | grep autonomous"
echo "   3. Monitor first autonomous run (within 30 minutes)"
echo "   4. Customize AWS task queue with agent-specific tasks"
echo ""
echo "For troubleshooting, see SKILL.md in the nighttime-autonomous-work skill directory."
echo ""