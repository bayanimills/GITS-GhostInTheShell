# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Bayani
- **What to call them:** Bayani
- **Pronouns:** he/him
- **Timezone:** Australia/Sydney
- **Sleep Window:** 23:00-07:00 local time (12:00-20:00 UTC)
- **Communication style:** not yet set
- **Preferred contact hours:** not yet set
- **Urgency threshold:** not yet set
- **Notes:** Telegram user ID: 548072941, username @bayanimills

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

### Initial Observations (2026-02-15)
- Technical user running OpenClaw ecosystem with multiple agents (aria, shelley, kaira)
- Bitcoin-focused (based on Bitaxe competitor intelligence cron jobs)
- Running OpenClaw on Linux system
- Interested in automation, competitor intelligence, and system reliability
- Has multiple Telegram groups/channels (FinMills Pty Ltd group observed)

### Additional Context (2026-02-17)
- **Geopolitical Monitoring Requested**: User wants advisories on significant geopolitical events
- **Sensitivity Training**: Working on developing judgment for when to raise issues
- **Timezone Consideration**: UTC+11 (Sydney) - avoid disturbing during sleep hours (23:00-07:00 local, 12:00-20:00 UTC)
- **Likely Relevance**: Events affecting Bitcoin/crypto markets, Asia-Pacific stability, major global conflicts

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
## Operational Protocols & Skills

### File‑Editing Protocol
- **Purpose**: Ensure all file edits include explanatory comments and memory entries
- **When to use**: Any file edit (code, config, documentation)
- **Core skill**: `file-editing-protocol` (central workspace)
- **Wrapper tool**: `/home/agent/.openclaw/workspace/scripts/edit-with-context.py`
- **Workflow**:
  1. Before editing, run: `python3 /home/agent/.openclaw/workspace/scripts/edit-with-context.py --file [path] --context "[explanation]"`
  2. Complete the edit in the generated template
  3. Tool creates memory entry and commented edit
- **Rationale**: Prevents "what was this change for?" confusion, creates audit trail

### Reasoning Framework (Pilot Phase)
- **Purpose**: Reduce cognitive errors and "I assumed…" mistakes before taking action
- **When to use**: Before significant file edits, configuration changes, or task delegation
- **Core skill**: `reasoning-framework` (central workspace)
- **5‑Question Protocol**:
  1. **Objective**: What am I trying to achieve?
  2. **Assumptions**: What assumptions am I making?
  3. **Risks**: What could go wrong?
  4. **Alternatives**: What alternatives exist?
  5. **Validation**: How will I know if it worked?
- **Wrapper tool**: `/home/agent/.openclaw/workspace/skills/reasoning-framework/scripts/reason-before-edit.py`
- **Workflow**:
  1. Run: `python3 /home/agent/.openclaw/workspace/skills/reasoning-framework/scripts/reason-before-edit.py --file [path] --context "[explanation]"`
  2. Complete reasoning template (generated automatically)
  3. Re‑run with `--reasoning [template‑path]` to execute edit
- **Pilot metrics**: Tracking reduction in "I assumed…" errors over 2‑week period

### **Delegation-Specific Reasoning Guidance**
*As Kaira (delegation agent), apply reasoning framework to:*

#### **Before delegating any task:**
1. **Objective**: What outcome should the delegated agent achieve?
2. **Assumptions**: What do I assume about the agent's capabilities/availability?
3. **Risks**: What could go wrong with this delegation (misunderstanding, failure, delay)?
4. **Alternatives**: Should I do this myself or delegate differently?
5. **Validation**: How will I verify the delegation succeeded?

#### **Before approving skill rollout (like nighttime-autonomous-work):**
1. **Objective**: Ensure skill is properly versioned and adopted ecosystem-wide
2. **Assumptions**: Skill works as documented, other agents need it, dependencies are met
3. **Risks**: Skill bugs, compatibility issues, adoption resistance
4. **Alternatives**: Different rollout strategy, phased adoption, postpone
5. **Validation**: SPICE audit score > 80%, adoption metrics, zero safety violations

#### **Template for delegation reasoning**:
```markdown
# Delegation Reasoning: [Task Description]
**Delegation to**: [Agent Name]
**Deadline**: [If applicable]
**Success criteria**: [Measurable outcomes]

## 1. Objective
[What should be accomplished?]

## 2. Assumptions  
- [Assumption 1 about agent capabilities]
- [Assumption 2 about task complexity]
- [Assumption 3 about dependencies]

## 3. Risks
- [Risk 1: misunderstanding requirements]
- [Risk 2: agent availability/competence]
- [Risk 3: external dependencies]

## 4. Alternatives
- [Alternative 1: Do it myself]
- [Alternative 2: Delegate to different agent]
- [Alternative 3: Postpone or cancel]

## 5. Validation
- [Metric 1: Task completion verification]
- [Metric 2: Quality assessment]
- [Metric 3: Timeline adherence]
```

### Project Management
- **Purpose**: Manage complex work as structured projects with charters, milestones, risks
- **When to use**: Multi‑step work, cross‑agent coordination, significant system changes
- **Core skill**: `project-management` (central workspace)
- **Templates**: Charter, milestone tracker, risk register, status report
- **Initialization**: `project-init.sh` creates project structure automatically

### Skill Development Routine
- **Purpose**: Systematically audit, improve, and develop skills across ecosystem
- **When to use**: Skill quality reviews, creating new skills, improvement planning
- **Core skill**: `skill-development-routine` (central workspace)
- **Framework**: SPICE assessment (Structure, Purpose, Integration, Completeness, Effectiveness)
- **Audit tool**: `skill-audit.py` generates automated skill quality reports

---

_This file is yours to evolve. As you learn about me, update it._