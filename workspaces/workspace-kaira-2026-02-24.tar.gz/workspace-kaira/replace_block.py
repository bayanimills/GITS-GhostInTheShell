#!/usr/bin/env python3
import sys

def main():
    with open('bootstrap-agent.sh', 'r') as f:
        content = f.read()
    
    # Find the start index
    start = content.find('# 2.6 Workspace script validation\n')
    if start == -1:
        print("Start not found")
        sys.exit(1)
    
    # Find the end index: the line before '# ============================================================================'
    end = content.find('\n# ============================================================================', start)
    if end == -1:
        print("End not found")
        sys.exit(1)
    
    old_text = content[start:end]
    print(f'Old text length: {len(old_text)}')
    
    # New block
    new_text = '''# 2.6 Workspace script validation
log_info "Testing workspace script validation..."
if [ -f "$DEFAULT_WORKSPACE/backup.sh" ]; then
    # Check if backup.sh is executable
    if [ -x "$DEFAULT_WORKSPACE/backup.sh" ]; then
        log_test 0 "Backup script is executable"
    else
        log_warn "Backup script exists but is not executable"
        log_skip "Backup script execution"
    fi
else
    log_skip "Backup script not found (optional)"
fi

# 2.7 Cron job configuration
log_info "Checking cron job configuration..."
if command -v openclaw >/dev/null 2>&1; then
    openclaw cron list 2>/dev/null | grep -q "$AGENT_ID"
    if [ $? -eq 0 ]; then
        log_test 0 "Cron jobs found for agent $AGENT_ID"
    else
        log_warn "No cron jobs found for agent $AGENT_ID (consider setting up autonomous workflows)"
        log_skip "Cron job configuration"
    fi
else
    log_skip "OpenClaw CLI not available for cron check"
fi'''
    
    # Replace
    new_content = content[:start] + new_text + content[end:]
    
    with open('bootstrap-agent.sh', 'w') as f:
        f.write(new_content)
    
    print('Block replaced successfully')

if __name__ == '__main__':
    main()