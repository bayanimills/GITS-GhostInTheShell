#!/bin/bash
# Deploy v3.0.0 WORKFLOW_AUTO.md files to all agents

SCRIPT_DIR="/home/agent/.openclaw/workspace-kaira"
LOG_FILE="$SCRIPT_DIR/memory/v3_deployment_$(date +%Y%m%d_%H%M%S).log"

# Agent list
AGENTS="aria shelley donna doc danny kaira main"

echo "=== WORKFLOW_AUTO.md v3.0.0 DEPLOYMENT ===" | tee -a "$LOG_FILE"
echo "Deployment time: $(date)" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Check if transformed files exist
MISSING_FILES=0
for agent in $AGENTS; do
    TRANSFORMED_FILE="$SCRIPT_DIR/${agent}_WORKFLOW_AUTO_v3_final.md"
    if [ ! -f "$TRANSFORMED_FILE" ]; then
        echo "❌ Missing transformed file for $agent: $TRANSFORMED_FILE" | tee -a "$LOG_FILE"
        MISSING_FILES=$((MISSING_FILES + 1))
    fi
done

if [ $MISSING_FILES -gt 0 ]; then
    echo "❌ $MISSING_FILES transformed files missing. Aborting deployment." | tee -a "$LOG_FILE"
    exit 1
fi

echo "✅ All transformed files present." | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Deploy each agent's file
SUCCESS_COUNT=0
FAILURE_COUNT=0

for agent in $AGENTS; do
    TRANSFORMED_FILE="$SCRIPT_DIR/${agent}_WORKFLOW_AUTO_v3_final.md"
    TARGET_FILE="/home/agent/.openclaw/workspace-$agent/WORKFLOW_AUTO.md"
    BACKUP_FILE="$SCRIPT_DIR/backups/${agent}_WORKFLOW_AUTO_v2_backup_$(date +%Y%m%d_%H%M%S).md"
    
    echo "🔧 Deploying to $agent..." | tee -a "$LOG_FILE"
    echo "  Source: $TRANSFORMED_FILE" | tee -a "$LOG_FILE"
    echo "  Target: $TARGET_FILE" | tee -a "$LOG_FILE"
    
    # Create backup of current file
    if [ -f "$TARGET_FILE" ]; then
        cp "$TARGET_FILE" "$BACKUP_FILE"
        echo "  ✅ Backed up current file to: $BACKUP_FILE" | tee -a "$LOG_FILE"
    else
        echo "  ⚠️  No existing file to backup at $TARGET_FILE" | tee -a "$LOG_FILE"
    fi
    
    # Deploy transformed file
    if cp "$TRANSFORMED_FILE" "$TARGET_FILE"; then
        # Verify deployment
        if [ -f "$TARGET_FILE" ]; then
            FILE_SIZE=$(stat -c "%s" "$TARGET_FILE")
            FILE_VERSION=$(grep -i "version:" "$TARGET_FILE" | head -1)
            echo "  ✅ Deployed successfully ($FILE_SIZE bytes)" | tee -a "$LOG_FILE"
            echo "  Version: $FILE_VERSION" | tee -a "$LOG_FILE"
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        else
            echo "  ❌ Deployment failed - target file not created" | tee -a "$LOG_FILE"
            FAILURE_COUNT=$((FAILURE_COUNT + 1))
        fi
    else
        echo "  ❌ Deployment failed - copy command failed" | tee -a "$LOG_FILE"
        FAILURE_COUNT=$((FAILURE_COUNT + 1))
    fi
    
    echo "" | tee -a "$LOG_FILE"
done

echo "=== DEPLOYMENT SUMMARY ===" | tee -a "$LOG_FILE"
echo "Successful: $SUCCESS_COUNT agents" | tee -a "$LOG_FILE"
echo "Failed: $FAILURE_COUNT agents" | tee -a "$LOG_FILE"

if [ $FAILURE_COUNT -eq 0 ]; then
    echo "🎉 All agents successfully updated to v3.0.0!" | tee -a "$LOG_FILE"
    
    # Run compliance check
    echo "" | tee -a "$LOG_FILE"
    echo "Running v3 compliance check..." | tee -a "$LOG_FILE"
    "$SCRIPT_DIR/check_workflow_v3_compliance.sh" | tee -a "$LOG_FILE"
    
    # Update version checker script
    echo "" | tee -a "$LOG_FILE"
    echo "Updating version checker script..." | tee -a "$LOG_FILE"
    if sed -i 's/EXPECTED_VERSION="2.0.0"/EXPECTED_VERSION="3.0.0"/' "$SCRIPT_DIR/check_workflow_versions.sh"; then
        echo "✅ Updated version checker to expect v3.0.0" | tee -a "$LOG_FILE"
    else
        echo "⚠️  Failed to update version checker" | tee -a "$LOG_FILE"
    fi
else
    echo "❌ Deployment incomplete. $FAILURE_COUNT agents failed." | tee -a "$LOG_FILE"
    echo "Check logs at: $LOG_FILE" | tee -a "$LOG_FILE"
fi

echo "" | tee -a "$LOG_FILE"
echo "Deployment complete. Log saved to: $LOG_FILE" | tee -a "$LOG_FILE"