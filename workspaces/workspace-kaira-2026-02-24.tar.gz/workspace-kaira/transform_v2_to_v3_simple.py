#!/usr/bin/env python3
"""
Simple transformation from v2 to v3 using regex replacements.
"""

import re
import sys

def read_file(path):
    with open(path, 'r') as f:
        return f.read()

def write_file(path, content):
    with open(path, 'w') as f:
        f.write(content)

def extract_section(content, section_header):
    """Extract a section from v2 content."""
    # Find the section
    pattern = rf'({re.escape(section_header)}.*?)(?=\n---|\n## |\Z)'
    match = re.search(pattern, content, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return ""

def add_reasoning_to_workflows(section_text):
    """Add reasoning framework placeholder to each workflow in section."""
    if not section_text:
        return section_text
    
    # Split by workflow headers (### **X.** or ### X.)
    parts = re.split(r'(\n### \*?\*?\d+\. .*?\n)', section_text, flags=re.DOTALL)
    if len(parts) == 1:
        return section_text  # No workflows found
    
    result = []
    for i in range(0, len(parts), 2):
        if i < len(parts):
            result.append(parts[i])  # Text between workflows
        
        if i + 1 < len(parts):
            workflow_header = parts[i + 1]
            result.append(workflow_header)
            
            # Check if next part exists (workflow content)
            if i + 2 < len(parts):
                workflow_content = parts[i + 2]
                result.append(workflow_content)
                
                # Add reasoning framework if not already present
                if '🎯 Reasoning Framework' not in workflow_content:
                    result.append('\n- **🎯 Reasoning Framework**:')
                    result.append('  1. **Trigger**: `[TO BE DOCUMENTED]`')
                    result.append('  2. **Preconditions**: `[TO BE DOCUMENTED]`')
                    result.append('  3. **Evidence**: `[TO BE DOCUMENTED]`')
                    result.append('  4. **Boundaries**: `[TO BE DOCUMENTED]`')
                    result.append('  5. **Failure Plan**: `[TO BE DOCUMENTED]`')
                    result.append('')
    
    return ''.join(result)

def create_v3_for_agent(agent_name, v2_content, v3_template):
    """Create v3 file for agent."""
    # Extract sections from v2
    overview_section = extract_section(v2_content, '## 🎯 OVERVIEW & AGENT CONTEXT')
    scheduled_section = extract_section(v2_content, '## 🔄 SCHEDULED CRON WORKFLOWS')
    event_section = extract_section(v2_content, '## 🔄 EVENT‑TRIGGERED WORKFLOWS')
    conditional_section = extract_section(v2_content, '## 🔄 CONDITIONAL WORKFLOWS')
    
    # Start with v3 template
    v3_content = v3_template
    
    # Replace Overview section
    if overview_section:
        # Remove the template's placeholder overview
        overview_pattern = r'(## 🎯 OVERVIEW & AGENT CONTEXT\n\n<!-- Replace this entire section with your agent\'s specific context -->\n).*?(?=\n---|\n## ⚠️)'
        overview_replacement = r'\1' + re.escape(overview_section) + '\n\n'
        v3_content = re.sub(overview_pattern, overview_replacement, v3_content, flags=re.DOTALL)
    
    # Replace Scheduled Cron Workflows section
    if scheduled_section:
        # Find the scheduled section in v3 (up to Real Agent Examples)
        scheduled_pattern = r'(## 🔄 SCHEDULED CRON WORKFLOWS\n\n<!-- Replace with your agent\'s scheduled cron jobs -->\n<!-- Format each workflow as shown below -->\n).*?(?=\n### \*\*Real Agent Examples\*\*:)'
        
        # Add reasoning framework to workflows
        scheduled_with_rf = add_reasoning_to_workflows(scheduled_section)
        scheduled_replacement = r'\1' + re.escape(scheduled_with_rf) + '\n\n'
        
        v3_content = re.sub(scheduled_pattern, scheduled_replacement, v3_content, flags=re.DOTALL)
    
    # Replace Event-Triggered Workflows section
    if event_section and 'EVENT‑TRIGGERED WORKFLOWS' in event_section:
        event_pattern = r'(## 🔄 EVENT‑TRIGGERED WORKFLOWS\n\n<!-- These workflows respond to system events, not schedules -->\n).*?(?=\n---|\n## 🔄 CONDITIONAL WORKFLOWS)'
        event_replacement = r'\1' + re.escape(event_section) + '\n\n'
        v3_content = re.sub(event_pattern, event_replacement, v3_content, flags=re.DOTALL)
    
    # Replace Conditional Workflows section
    if conditional_section and 'CONDITIONAL WORKFLOWS' in conditional_section:
        conditional_pattern = r'(## 🔄 CONDITIONAL WORKFLOWS\n\n<!-- Workflows that run based on conditions, not fixed schedules -->\n).*?(?=\n---|\n## 🧠 AUTONOMOUS WORK PHILOSOPHY)'
        conditional_replacement = r'\1' + re.escape(conditional_section) + '\n\n'
        v3_content = re.sub(conditional_pattern, conditional_replacement, v3_content, flags=re.DOTALL)
    
    return v3_content

def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <agent_name> <v2_file_path>")
        sys.exit(1)
    
    agent_name = sys.argv[1]
    v2_file_path = sys.argv[2]
    
    # Read files
    v2_content = read_file(v2_file_path)
    v3_template = read_file("/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md")
    
    # Create v3 content
    print(f"Creating v3 for {agent_name}...")
    v3_content = create_v3_for_agent(agent_name, v2_content, v3_template)
    
    # Write output
    output_path = f"/home/agent/.openclaw/workspace-kaira/{agent_name}_WORKFLOW_AUTO_v3_final.md"
    write_file(output_path, v3_content)
    
    print(f"Created: {output_path}")
    print(f"Size: {len(v3_content)} bytes")
    
    # Verify
    print("\nVerifying sections...")
    if '## 🎯 OVERVIEW & AGENT CONTEXT' in v3_content:
        print("✅ Overview section present")
    if '## 🔄 SCHEDULED CRON WORKFLOWS' in v3_content:
        print("✅ Scheduled workflows present")
    if '## 🧠 AUTONOMOUS WORK PHILOSOPHY' in v3_content:
        print("✅ Autonomous work philosophy present")
    if '## ⚠️ ERROR HANDLING & RECOVERY' in v3_content:
        print("✅ Error handling section present")
    if '## 📝 "ROLLOUT TO YOUR AGENT" CHECKLIST' in v3_content:
        print("✅ Rollout checklist present")

if __name__ == "__main__":
    main()