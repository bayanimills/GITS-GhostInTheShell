#!/usr/bin/env python3
import sys

def main():
    # Read original memory file
    with open('memory/2026-02-23.md', 'r') as f:
        original = f.read()
    
    # Read new entry
    with open('memory_flush_entry.md', 'r') as f:
        new_entry = f.read()
    
    # Append with separator
    if not original.endswith('\n'):
        original += '\n'
    
    # Add separator if not already present
    if not original.strip().endswith('---'):
        original += '\n---\n\n'
    
    new_content = original + new_entry
    
    # Write back
    with open('memory/2026-02-23.md', 'w') as f:
        f.write(new_content)
    
    print(f"Appended {len(new_entry)} bytes to memory file")
    print(f"Total length: {len(new_content)} bytes")

if __name__ == '__main__':
    main()