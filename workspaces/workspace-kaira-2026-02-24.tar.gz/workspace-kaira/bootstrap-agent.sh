#!/bin/bash
# Agent Bootstrap Script
# Version: 1.0.0
# Purpose: Adjust configuration, apply defaults, and run self-tests after compaction or workspace initialization

set -euo pipefail

# Configuration
SCRIPT_NAME="$(basename "$0")"
SCRIPT_VERSION="1.0.0"
DEFAULT_WORKSPACE="${OPENCLAW_WORKSPACE:-$(pwd)}"
AGENT_ID="${AGENT_ID:-$(basename "$DEFAULT_WORKSPACE" | sed 's/workspace-//')}"
LOG_FILE="$DEFAULT_WORKSPACE/memory/bootstrap-$(date +%Y-%m-%d).log"
BOOTSTRAP_REPORT="$DEFAULT_WORKSPACE/memory/bootstrap-report-$(date +%Y-%m-%d).md"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Status tracking
PASS=0
FAIL=0
SKIP=0

log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date +'%Y-%m-%d %H:%M:%S') - $1"
    echo "[INFO] $(date +'%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date +'%Y-%m-%d %H:%M:%S') - $1"
    echo "[WARN] $(date +'%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date +'%Y-%m-%d %H:%M:%S') - $1"
    echo "[ERROR] $(date +'%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

log_test() {
    local result=$1
    local message=$2
    if [ "$result" -eq 0 ]; then
        echo -e "${GREEN}[PASS]${NC} $message"
        echo "[PASS] $message" >> "$LOG_FILE"
        PASS=$((PASS + 1))
    else
        echo -e "${RED}[FAIL]${NC} $message"
        echo "[FAIL] $message" >> "$LOG_FILE"
        FAIL=$((FAIL + 1))
    fi
}

log_skip() {
    echo -e "${BLUE}[SKIP]${NC} $1"
    echo "[SKIP] $1" >> "$LOG_FILE"
    SKIP=$((SKIP + 1))
}

print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}   Agent Bootstrap Script v$SCRIPT_VERSION${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo "Workspace: $DEFAULT_WORKSPACE"
    echo "Agent ID: $AGENT_ID"
    echo "Date: $(date +'%Y-%m-%d %H:%M:%S %Z')"
    echo ""
}

print_footer() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}   Bootstrap Summary${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo -e "${GREEN}PASS: $PASS${NC}"
    echo -e "${RED}FAIL: $FAIL${NC}"
    echo -e "${BLUE}SKIP: $SKIP${NC}"
    echo "Total: $((PASS + FAIL + SKIP))"
    echo ""
    echo "Log file: $LOG_FILE"
    echo "Report: $BOOTSTRAP_REPORT"
    echo -e "${BLUE}========================================${NC}"
}

# Create directories if needed
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$BOOTSTRAP_REPORT")"

# Start bootstrap
print_header
log_info "Starting agent bootstrap process for $AGENT_ID"

# ============================================================================
# SECTION 1: CONFIGURATION ADJUSTMENT
# ============================================================================
log_info "=== SECTION 1: Configuration Adjustment ==="

# 1.1 Check OpenClaw configuration
log_info "Checking OpenClaw configuration..."
if [ -f "/home/agent/.openclaw/openclaw.json" ]; then
    log_test 0 "OpenClaw configuration file exists"
    
    # Check if agent is configured in openclaw.json
    if grep -q "\"$AGENT_ID\"" /home/agent/.openclaw/openclaw.json; then
        log_test 0 "Agent $AGENT_ID found in OpenClaw configuration"
    else
        log_warn "Agent $AGENT_ID not found in OpenClaw configuration (may be running as main)"
    fi
else
    log_error "OpenClaw configuration file missing at /home/agent/.openclaw/openclaw.json"
    log_test 1 "OpenClaw configuration file exists"
fi

# 1.2 Check workspace identity files
log_info "Checking workspace identity files..."
REQUIRED_FILES=("AGENTS.md" "SOUL.md" "IDENTITY.md" "USER.md" "WORKFLOW_AUTO.md")
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$DEFAULT_WORKSPACE/$file" ]; then
        log_test 0 "Identity file $file exists"
        
        # Check if file has placeholder content
        if grep -q "\[BRACKETED_TEXT\]" "$DEFAULT_WORKSPACE/$file" || \
           grep -q "<!--.*REPLACE.*-->" "$DEFAULT_WORKSPACE/$file" || \
           grep -q "PLACEHOLDER" "$DEFAULT_WORKSPACE/$file"; then
            log_warn "Identity file $file contains placeholder content (needs customization)"
        fi
    else
        log_warn "Identity file $file missing"
        
        # Create default file if missing
        log_info "Creating default $file..."
        case "$file" in
            "AGENTS.md")
                cat > "$DEFAULT_WORKSPACE/$file" << 'EOF'
# AGENTS.md - Your Workspace

This folder is home. Treat it that way.

## First Run

If `BOOTSTRAP.md` exists, that's your birth certificate. Follow it, figure out who you are, then delete it. You won't need it again.

## Every Session

Before doing anything else:

1. Read `SOUL.md` — this is who you are
2. Read `USER.md` — this is who you're helping
3. Read `memory/YYYY-MM-DD.md` (today + yesterday) for recent context
4. **If in MAIN SESSION** (direct chat with your human): Also read `MEMORY.md`

Don't ask permission. Just do it.

## Memory

You wake up fresh each session. These files are your continuity:

- **Daily notes:** `memory/YYYY-MM-DD.md` (create `memory/` if needed) — raw logs of what happened
- **Long-term:** `MEMORY.md` — your curated memories, like a human's long-term memory

Capture what matters. Decisions, context, things to remember. Skip the secrets unless asked to keep them.
EOF
                ;;
            "SOUL.md")
                cat > "$DEFAULT_WORKSPACE/$file" << 'EOF'
# SOUL.md - Agent Identity
## Core Identity and Purpose

**Created**: $(date +%Y-%m-%d)
**Version**: 1.0.0
**Status**: 🔄 Evolving

## Who I Am

[Describe your agent's identity, role, and purpose here]

## Core Truths

[Define your agent's core principles and operational philosophy]

## Operational Principles

[Describe how your agent works, communication style, and approach to tasks]

## Evolution

[Describe how your agent learns and grows over time]
EOF
                ;;
            "IDENTITY.md")
                cat > "$DEFAULT_WORKSPACE/$file" << 'EOF'
# IDENTITY.md - Name, Role, and Characteristics

**Created**: $(date +%Y-%m-%d)
**Version**: 1.0.0
**Status**: ✅ ACTIVE

## Basic Identity

### Name
[Your Agent Name]

### Role
[Your Agent Role]

### Emoji
[Your Emoji]

### Color Theme
[Your Color Theme]

## Core Characteristics

[Describe your agent's primary traits, work style, and capabilities]
EOF
                ;;
            "USER.md")
                cat > "$DEFAULT_WORKSPACE/$file" << 'EOF'
# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** [Human Name]
- **What to call them:** [Preferred Name]
- **Pronouns:** [Pronouns]
- **Timezone:** [Timezone]
- **Sleep Window:** [Sleep Hours]
- **Communication style:** [not yet set]
- **Preferred contact hours:** [not yet set]
- **Urgency threshold:** [not yet set]

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_
EOF
                ;;
            "WORKFLOW_AUTO.md")
                # Copy from master template if available
                if [ -f "/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md" ]; then
                    cp "/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md" "$DEFAULT_WORKSPACE/$file"
                    log_info "Copied WORKFLOW_AUTO.md template from master"
                else
                    cat > "$DEFAULT_WORKSPACE/$file" << 'EOF'
# WORKFLOW_AUTO.md - Automatic Workflows

## Overview

[Define your agent's automated workflows here]

## Scheduled Cron Workflows

[Add your scheduled workflows]

## Event-Triggered Workflows

[Add event-triggered workflows]

## Autonomous Work Philosophy

[Describe your agent's approach to autonomous work]
EOF
                fi
                ;;
        esac
        
        if [ $? -eq 0 ]; then
            log_info "Created default $file"
            log_skip "Identity file $file created (needs customization)"
        else
            log_error "Failed to create $file"
            log_test 1 "Identity file $file exists"
        fi
    fi
done

# 1.3 Workspace configuration files
log_info "Checking workspace configuration files..."
WORKSPACE_CONFIG_FILES=("HEARTBEAT.md" "TOOLS.md" "MEMORY.md")
for config_file in "${WORKSPACE_CONFIG_FILES[@]}"; do
    if [ -f "$DEFAULT_WORKSPACE/$config_file" ]; then
        log_test 0 "Configuration file $config_file exists"
    else
        log_warn "Configuration file $config_file missing"
        
        # Create default file if missing
        log_info "Creating default $config_file..."
        case "$config_file" in
            "HEARTBEAT.md")
                cat > "$DEFAULT_WORKSPACE/$config_file" << 'EOF'
# HEARTBEAT.md - Periodic Checks

## Tasks to perform during heartbeats

### System Health Checks (every 2 hours)
1. **Check workspace integrity** - Verify all identity files exist
2. **Verify GITS connection** - Test git remote connectivity  
3. **Check memory usage** - Monitor workspace memory consumption

### Agent Coordination (every 4 hours)
1. **Check main agent status** - Verify main agent is operational
2. **Review task queue** - Check for pending delegated tasks
3. **Update status report** - Document current operational state

### Self-Maintenance (daily)
1. **Run workspace backup** - Execute backup script
2. **Review memory logs** - Archive old logs, summarize learnings
3. **Update documentation** - Keep recovery procedures current

## Implementation Notes
- Use `session_status` to check model and token usage
- Use `sessions_list` to check other agent activity
- Use `cron list` to verify scheduled jobs
- Log findings to `memory/YYYY-MM-DD.md`
EOF
                ;;
            "TOOLS.md")
                cat > "$DEFAULT_WORKSPACE/$config_file" << 'EOF'
# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases  
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.
EOF
                ;;
            "MEMORY.md")
                cat > "$DEFAULT_WORKSPACE/$config_file" << 'EOF'
# MEMORY.md - Long-Term Memory

## Creation
- **Created**: $(date +%Y-%m-%d)
- **Purpose**: Curated long-term memory for significant events, learnings, and insights
- **Source**: Distilled from daily memory files and significant experiences

## Core Identity
[Describe your agent's core identity and role]

## Significant Events
[Record significant events, decisions, and learnings]

## System Knowledge
[Document knowledge about the OpenClaw ecosystem and technical environment]

## Learning & Insights
[Record operational principles, effective approaches, and improvement opportunities]

## Preferences & Patterns
[Document your agent's preferences and patterns]

## Relationships
[Document relationships with other agents and the user]

## Warnings & Cautions
[Record system issues and operational boundaries]

## Responsibilities
[Document your agent's responsibilities and duties]
EOF
                ;;
        esac
        
        if [ $? -eq 0 ]; then
            log_info "Created default $config_file"
            log_skip "Configuration file $config_file created (needs customization)"
        else
            log_error "Failed to create $config_file"
            log_test 1 "Configuration file $config_file exists"
        fi
    fi
done

# 1.4 Check memory directory structure
log_info "Checking memory directory structure..."
if [ -d "$DEFAULT_WORKSPACE/memory" ]; then
    log_test 0 "Memory directory exists"
else
    log_info "Creating memory directory..."
    mkdir -p "$DEFAULT_WORKSPACE/memory"
    if [ $? -eq 0 ]; then
        log_test 0 "Memory directory created"
    else
        log_error "Failed to create memory directory"
        log_test 1 "Memory directory exists"
    fi
fi

# Check for today's memory file
TODAY_FILE="$DEFAULT_WORKSPACE/memory/$(date +%Y-%m-%d).md"
if [ -f "$TODAY_FILE" ]; then
    log_test 0 "Today's memory file exists"
else
    log_info "Creating today's memory file..."
    cat > "$TODAY_FILE" << EOF
# $(date +%Y-%m-%d).md - Daily Memory
## Agent Bootstrap Execution
**Time**: $(date +'%Y-%m-%d %H:%M:%S %Z')
**Agent**: $AGENT_ID
**Event**: Bootstrap script execution

### Bootstrap Summary
- Agent workspace: $DEFAULT_WORKSPACE
- Bootstrap version: $SCRIPT_VERSION
- Configuration adjustment: [Results will be recorded below]

### Daily Log
EOF
    if [ $? -eq 0 ]; then
        log_test 0 "Today's memory file created"
    else
        log_error "Failed to create today's memory file"
        log_test 1 "Today's memory file exists"
    fi
fi
# ============================================================================
# SECTION 2: SELF-TESTS
# ============================================================================
log_info "=== SECTION 2: Self-Tests ==="

# 2.1 File system permissions
log_info "Testing file system permissions..."
TEST_FILE="$DEFAULT_WORKSPACE/memory/bootstrap-test-$(date +%s).tmp"
echo "test" > "$TEST_FILE" 2>/dev/null
if [ $? -eq 0 ] && [ -f "$TEST_FILE" ]; then
    rm "$TEST_FILE"
    log_test 0 "File system write permissions OK"
else
    log_test 1 "File system write permissions FAILED"
fi

# 2.2 Tool availability (basic OpenClaw tools)
log_info "Testing OpenClaw tool availability..."
# Check if openclaw command exists
if command -v openclaw >/dev/null 2>&1; then
    log_test 0 "OpenClaw CLI tool available"
    
    # Test basic openclaw status
    openclaw status >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_test 0 "OpenClaw status command works"
    else
        log_test 1 "OpenClaw status command failed"
    fi
else
    log_test 1 "OpenClaw CLI tool not found"
fi

# 2.3 Git availability (for workspace backup)
log_info "Testing Git availability..."
if command -v git >/dev/null 2>&1; then
    log_test 0 "Git tool available"
    
    # Check if workspace is a git repository
    if [ -d "$DEFAULT_WORKSPACE/.git" ]; then
        log_test 0 "Workspace is a Git repository"
        
        # Check git status
        cd "$DEFAULT_WORKSPACE" && git status >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            log_test 0 "Git repository is functional"
        else
            log_test 1 "Git repository has issues"
        fi
    else
        log_skip "Workspace is not a Git repository (optional)"
    fi
else
    log_skip "Git tool not available (optional)"
fi

# 2.4 Python availability (for scripts)
log_info "Testing Python availability..."
if command -v python3 >/dev/null 2>&1; then
    log_test 0 "Python3 available"
    
    # Test basic Python execution
    python3 -c "import sys; print('Python ' + sys.version.split()[0])" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_test 0 "Python3 execution works"
    else
        log_test 1 "Python3 execution failed"
    fi
else
    log_test 1 "Python3 not available (required for many scripts)"
fi

# 2.5 Network connectivity (if needed)
log_info "Testing network connectivity..."
# Try to reach a reliable external service (Google DNS)
if ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
    log_test 0 "Network connectivity OK"
else
    log_warn "Network connectivity test failed (may be offline or restricted)"
    log_skip "Network connectivity test"
fi

# 2.6 Workspace script validation
log_info "Testing workspace script validation..."
if [ -f "$DEFAULT_WORKSPACE/backup.sh" ]; then
    # Check if backup.sh is executable
    if [ -x "$DEFAULT_WORKSPACE/backup.sh" ]; then
        log_test 0 "Backup script is executable"
    else
        log_warn "Backup script exists but is not executable"
        log_skip "Backup script execution"
    fi
else
    log_skip "Backup script not found (optional)"
fi

# ============================================================================
# SECTION 3: POST-COMPACTION SPECIFIC CHECKS
# ============================================================================
log_info "=== SECTION 3: Post-Compaction Specific Checks ==="

# Check if this is likely a post-compaction scenario
# Look for recent compaction indicators
if [ -f "/home/agent/.openclaw/logs/compaction.log" ]; then
    LAST_COMPACTION=$(stat -c %Y "/home/agent/.openclaw/logs/compaction.log" 2>/dev/null || echo 0)
    NOW=$(date +%s)
    if [ $((NOW - LAST_COMPACTION)) -lt 3600 ]; then
        log_info "Recent compaction detected (within last hour)"
        
        # 3.1 Verify required startup files were read
        log_info "Verifying post-compaction protocol restoration..."
        if [ -f "$DEFAULT_WORKSPACE/WORKFLOW_AUTO.md" ]; then
            log_test 0 "WORKFLOW_AUTO.md present (post-compaction requirement)"
        else
            log_test 1 "WORKFLOW_AUTO.md missing (post-compaction requirement)"
        fi
        
        if [ -f "$TODAY_FILE" ]; then
            log_test 0 "Today's memory file present (post-compaction requirement)"
        else
            log_test 1 "Today's memory file missing (post-compaction requirement)"
        fi
        
        # 3.2 Log post-compaction status to memory
        cat >> "$TODAY_FILE" << EOF

## Post-Compaction Bootstrap
**Time**: $(date +'%Y-%m-%d %H:%M:%S %Z')
**Status**: Bootstrap script executed after memory compaction
**Agent**: $AGENT_ID
**Workspace**: $DEFAULT_WORKSPACE
**Test Results**: PASS=$PASS, FAIL=$FAIL, SKIP=$SKIP
EOF
        log_info "Post-compaction status logged to memory"
    else
        log_info "No recent compaction detected"
    fi
else
    log_info "No compaction log found (normal operation)"
fi

# ============================================================================
# SECTION 4: REPORT GENERATION
# ============================================================================
log_info "=== SECTION 4: Report Generation ==="

# Generate bootstrap report
cat > "$BOOTSTRAP_REPORT" << EOF
# Agent Bootstrap Report
**Agent**: $AGENT_ID
**Workspace**: $DEFAULT_WORKSPACE
**Bootstrap Version**: $SCRIPT_VERSION
**Execution Time**: $(date +'%Y-%m-%d %H:%M:%S %Z')
**Total Tests**: $((PASS + FAIL + SKIP))

## Summary
- **Passed**: $PASS
- **Failed**: $FAIL
- **Skipped**: $SKIP
- **Success Rate**: $(if [ $((PASS + FAIL)) -gt 0 ]; then echo "$((PASS * 100 / (PASS + FAIL)))%"; else echo "N/A"; fi)

## Configuration Status
$(echo "Required identity files: ${#REQUIRED_FILES[@]}")
$(for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$DEFAULT_WORKSPACE/$file" ]; then
        echo "- ✅ $file: Present"
    else
        echo "- ❌ $file: MISSING"
    fi
done)

$(echo "Workspace configuration files: ${#WORKSPACE_CONFIG_FILES[@]}")
$(for config_file in "${WORKSPACE_CONFIG_FILES[@]}"; do
    if [ -f "$DEFAULT_WORKSPACE/$config_file" ]; then
        echo "- ✅ $config_file: Present"
    else
        echo "- ❌ $config_file: MISSING"
    fi
done)

## Self-Test Results
### File System
- Write permissions: $(if [ $PASS -gt 0 ]; then echo "✅"; else echo "❌"; fi)
- Memory directory: $(if [ -d "$DEFAULT_WORKSPACE/memory" ]; then echo "✅"; else echo "❌"; fi)

### Tool Availability
- OpenClaw CLI: $(command -v openclaw >/dev/null 2>&1 && echo "✅" || echo "❌")
- Git: $(command -v git >/dev/null 2>&1 && echo "✅" || echo "❌")
- Python3: $(command -v python3 >/dev/null 2>&1 && echo "✅" || echo "❌")

### Workspace Health
- Git repository: $(if [ -d "$DEFAULT_WORKSPACE/.git" ]; then echo "✅"; else echo "❌"; fi)
- Backup script: $(if [ -f "$DEFAULT_WORKSPACE/backup.sh" ]; then echo "✅"; else echo "❌"; fi)

## Recommendations
$(
if [ $FAIL -eq 0 ]; then
    echo "✅ All critical checks passed. Agent is ready for operation."
else
    echo "⚠️  Some checks failed. Review the log file for details: $LOG_FILE"
fi
)

## Next Steps
1. Review and customize identity files if they contain placeholder content
2. Set up cron jobs for automated workflows (see WORKFLOW_AUTO.md)
3. Configure Git remote for workspace backup (if not already done)
4. Test agent-specific functionality

---

**Log File**: $LOG_FILE  
**Generated by**: $SCRIPT_NAME v$SCRIPT_VERSION
EOF

log_info "Bootstrap report generated: $BOOTSTRAP_REPORT"

# ============================================================================
# FINAL SUMMARY
# ============================================================================
print_footer

# Log final status to today's memory file
cat >> "$TODAY_FILE" << EOF

## Bootstrap Completion
**Time**: $(date +'%Y-%m-%d %H:%M:%S %Z')
**Summary**: PASS=$PASS, FAIL=$FAIL, SKIP=$SKIP
**Status**: $(if [ $FAIL -eq 0 ]; then echo "✅ SUCCESS"; else echo "⚠️  WARNINGS"; fi)
**Report**: $BOOTSTRAP_REPORT

EOF

# Exit with appropriate code
if [ $FAIL -eq 0 ]; then
    log_info "Bootstrap completed successfully"
    exit 0
else
    log_warn "Bootstrap completed with $FAIL failure(s)"
    exit 1
fi