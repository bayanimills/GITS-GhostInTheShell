#!/usr/bin/env python3
"""
Transform WORKFLOW_AUTO.md from v2.0.0 to v3.0.0 structure.
Preserves agent-specific content while upgrading template structure.
"""

import re
import sys
from pathlib import Path

def extract_agent_content(v2_content):
    """Extract agent-specific content from v2 file."""
    content = {
        'agent_context': '',
        'scheduled_workflows': '',
        'event_workflows': '',
        'conditional_workflows': '',
        'custom_sections': {}
    }
    
    lines = v2_content.split('\n')
    
    # Extract agent context (Overview & Agent Context section)
    in_context = False
    context_lines = []
    for i, line in enumerate(lines):
        if '## 🎯 OVERVIEW & AGENT CONTEXT' in line:
            in_context = True
            continue
        if in_context and line.startswith('---'):
            break
        if in_context:
            context_lines.append(line)
    
    content['agent_context'] = '\n'.join(context_lines).strip()
    
    # Extract scheduled workflows
    in_scheduled = False
    scheduled_lines = []
    for i, line in enumerate(lines):
        if '## 🔄 SCHEDULED CRON WORKFLOWS' in line:
            in_scheduled = True
            scheduled_lines.append(line)  # Keep the header
            continue
        if in_scheduled and line.startswith('---'):
            break
        if in_scheduled:
            scheduled_lines.append(line)
    
    content['scheduled_workflows'] = '\n'.join(scheduled_lines).strip()
    
    # Extract event-triggered workflows
    in_event = False
    event_lines = []
    for i, line in enumerate(lines):
        if '## 🔄 EVENT‑TRIGGERED WORKFLOWS' in line:
            in_event = True
            event_lines.append(line)
            continue
        if in_event and line.startswith('---'):
            break
        if in_event:
            event_lines.append(line)
    
    content['event_workflows'] = '\n'.join(event_lines).strip()
    
    # Extract conditional workflows
    in_conditional = False
    conditional_lines = []
    for i, line in enumerate(lines):
        if '## 🔄 CONDITIONAL WORKFLOWS' in line:
            in_conditional = True
            conditional_lines.append(line)
            continue
        if in_conditional and line.startswith('---'):
            break
        if in_conditional:
            conditional_lines.append(line)
    
    content['conditional_workflows'] = '\n'.join(conditional_lines).strip()
    
    return content

def add_reasoning_framework_to_workflows(workflows_text):
    """Add reasoning framework placeholder to each workflow."""
    if not workflows_text:
        return workflows_text
    
    # Split into workflow sections
    lines = workflows_text.split('\n')
    result = []
    current_workflow = []
    in_workflow = False
    
    for line in lines:
        # Check for workflow header (starts with ### and has **)
        if line.strip().startswith('### **') or (line.strip().startswith('###') and '`' in line):
            if current_workflow and in_workflow:
                # Add reasoning framework to previous workflow
                result.extend(current_workflow)
                result.append('- **🎯 Reasoning Framework**:')
                result.append('  1. **Trigger**: `[TO BE DOCUMENTED]`')
                result.append('  2. **Preconditions**: `[TO BE DOCUMENTED]`')
                result.append('  3. **Evidence**: `[TO BE DOCUMENTED]`')
                result.append('  4. **Boundaries**: `[TO BE DOCUMENTED]`')
                result.append('  5. **Failure Plan**: `[TO BE DOCUMENTED]`')
                result.append('')
            
            current_workflow = [line]
            in_workflow = True
        elif in_workflow and line.strip().startswith('- **Schedule**:'):
            current_workflow.append(line)
        elif in_workflow and line.strip().startswith('###') and not line.strip().startswith('### **'):
            # Another workflow header at same level
            if current_workflow:
                result.extend(current_workflow)
                result.append('- **🎯 Reasoning Framework**:')
                result.append('  1. **Trigger**: `[TO BE DOCUMENTED]`')
                result.append('  2. **Preconditions**: `[TO BE DOCUMENTED]`')
                result.append('  3. **Evidence**: `[TO BE DOCUMENTED]`')
                result.append('  4. **Boundaries**: `[TO BE DOCUMENTED]`')
                result.append('  5. **Failure Plan**: `[TO BE DOCUMENTED]`')
                result.append('')
            current_workflow = [line]
        else:
            current_workflow.append(line)
    
    # Add reasoning framework to last workflow
    if current_workflow and in_workflow:
        result.extend(current_workflow)
        result.append('- **🎯 Reasoning Framework**:')
        result.append('  1. **Trigger**: `[TO BE DOCUMENTED]`')
        result.append('  2. **Preconditions**: `[TO BE DOCUMENTED]`')
        result.append('  3. **Evidence**: `[TO BE DOCUMENTED]`')
        result.append('  4. **Boundaries**: `[TO BE DOCUMENTED]`')
        result.append('  5. **Failure Plan**: `[TO BE DOCUMENTED]`')
        result.append('')
    
    return '\n'.join(result)

def create_v3_file(agent_name, agent_content, template_v3):
    """Create v3 file for agent with their content."""
    # Replace version
    v3_content = template_v3
    
    # Replace agent context section
    if agent_content['agent_context']:
        # Find the agent context section in template
        lines = v3_content.split('\n')
        result = []
        in_context_section = False
        context_replaced = False
        
        for line in lines:
            if '## 🎯 OVERVIEW & AGENT CONTEXT' in line:
                in_context_section = True
                result.append(line)
                result.append('')
                # Insert agent's context
                result.append(agent_content['agent_context'])
                result.append('')
                context_replaced = True
                continue
            
            if in_context_section and line.startswith('---'):
                in_context_section = False
            
            if not in_context_section or context_replaced:
                result.append(line)
        
        v3_content = '\n'.join(result)
    
    # Replace scheduled workflows section
    if agent_content['scheduled_workflows']:
        # Find scheduled workflows section
        lines = v3_content.split('\n')
        result = []
        in_scheduled_section = False
        scheduled_replaced = False
        skipping_examples = False
        
        for i, line in enumerate(lines):
            if '## 🔄 SCHEDULED CRON WORKFLOWS' in line:
                in_scheduled_section = True
                result.append(line)
                result.append('')
                # Insert agent's scheduled workflows (with reasoning framework)
                workflows_with_rf = add_reasoning_framework_to_workflows(agent_content['scheduled_workflows'])
                result.append(workflows_with_rf)
                result.append('')
                scheduled_replaced = True
                skipping_examples = True
                continue
            
            if in_scheduled_section and line.startswith('### **Real Agent Examples**:'):
                skipping_examples = False
            
            if skipping_examples:
                continue
            
            if in_scheduled_section and line.startswith('---'):
                in_scheduled_section = False
            
            if not in_scheduled_section or scheduled_replaced:
                result.append(line)
        
        v3_content = '\n'.join(result)
    
    # Replace event-triggered workflows section  
    if agent_content['event_workflows'] and 'EVENT‑TRIGGERED WORKFLOWS' in agent_content['event_workflows']:
        lines = v3_content.split('\n')
        result = []
        in_event_section = False
        event_replaced = False
        
        for line in lines:
            if '## 🔄 EVENT‑TRIGGERED WORKFLOWS' in line:
                in_event_section = True
                result.append(line)
                result.append('')
                # Insert agent's event workflows
                result.append(agent_content['event_workflows'])
                result.append('')
                event_replaced = True
                continue
            
            if in_event_section and line.startswith('---'):
                in_event_section = False
            
            if not in_event_section or event_replaced:
                result.append(line)
        
        v3_content = '\n'.join(result)
    
    # Replace conditional workflows section
    if agent_content['conditional_workflows'] and 'CONDITIONAL WORKFLOWS' in agent_content['conditional_workflows']:
        lines = v3_content.split('\n')
        result = []
        in_conditional_section = False
        conditional_replaced = False
        
        for line in lines:
            if '## 🔄 CONDITIONAL WORKFLOWS' in line:
                in_conditional_section = True
                result.append(line)
                result.append('')
                # Insert agent's conditional workflows
                result.append(agent_content['conditional_workflows'])
                result.append('')
                conditional_replaced = True
                continue
            
            if in_conditional_section and line.startswith('---'):
                in_conditional_section = False
            
            if not in_conditional_section or conditional_replaced:
                result.append(line)
        
        v3_content = '\n'.join(result)
    
    return v3_content

def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <agent_name> <v2_file_path>")
        print(f"Example: {sys.argv[0]} kaira /home/agent/.openclaw/workspace-kaira/WORKFLOW_AUTO.md")
        sys.exit(1)
    
    agent_name = sys.argv[1]
    v2_file_path = sys.argv[2]
    
    # Read v2 file
    with open(v2_file_path, 'r') as f:
        v2_content = f.read()
    
    # Read v3 template
    template_path = "/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md"
    with open(template_path, 'r') as f:
        v3_template = f.read()
    
    # Extract agent content
    print(f"Extracting content for {agent_name}...")
    agent_content = extract_agent_content(v2_content)
    
    # Create v3 file
    print(f"Creating v3.0.0 file for {agent_name}...")
    v3_content = create_v3_file(agent_name, agent_content, v3_template)
    
    # Write output
    output_path = f"/home/agent/.openclaw/workspace-kaira/{agent_name}_WORKFLOW_AUTO_v3.md"
    with open(output_path, 'w') as f:
        f.write(v3_content)
    
    print(f"Created v3 file at: {output_path}")
    print(f"Size: {len(v3_content)} bytes")
    
    # Show preview
    print("\n--- Preview (first 20 lines) ---")
    print('\n'.join(v3_content.split('\n')[:20]))

if __name__ == "__main__":
    main()