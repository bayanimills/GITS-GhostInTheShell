#!/usr/bin/env python3
import sys
import os

# Path to autonomous-check.py
aws_skill_dir = "/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work"
source_file = os.path.join(aws_skill_dir, "autonomous-check.py")
backup_file = source_file + ".bak"

# Read the original file
with open(source_file, 'r') as f:
    lines = f.readlines()

# Find the line numbers
# Look for "def main():"
for i, line in enumerate(lines):
    if line.strip() == "def main():":
        main_start = i
        # The line before should be blank or the end of log_to_memory
        # We'll insert before this line
        insert_at = i  # insert before def main
        break

# Ensure we found it
if 'main_start' not in locals():
    print("ERROR: Could not find def main():")
    sys.exit(1)

# Read the functions block
functions_path = "/home/agent/.openclaw/workspace-kaira/telegram_functions.py"
with open(functions_path, 'r') as f:
    functions_block = f.read()

# Insert functions block with a blank line before and after
new_lines = lines[:insert_at] + ['\n', functions_block, '\n'] + lines[insert_at:]

# Write backup
with open(backup_file, 'w') as f:
    f.writelines(lines)

# Write new file
with open(source_file, 'w') as f:
    f.writelines(new_lines)

print(f"Inserted Telegram functions before line {insert_at+1}")
print(f"Backup saved to {backup_file}")