#!/usr/bin/env python3
import sys
import os

aws_skill_dir = "/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work"
source_file = os.path.join(aws_skill_dir, "autonomous-check.py")

with open(source_file, 'r') as f:
    lines = f.readlines()

# Find the line with log_to_memory call
for i, line in enumerate(lines):
    if line.strip() == "log_to_memory(task, result, current_permission)":
        log_line = i
        break
else:
    print("ERROR: Could not find log_to_memory call")
    sys.exit(1)

# Find the next non-empty line after log_line
next_line = log_line + 1
while next_line < len(lines) and lines[next_line].strip() == "":
    next_line += 1

# The line after blank lines is the if statement
# We'll insert after the blank lines, before the if
insert_at = next_line  # insert before the if line

# Build the insertion block
insertion = '''    # Update Telegram status message if enabled
    try:
        config = load_telegram_config()
        if config.get("enable_telegram_status"):
            # Re-parse activities file to get fresh task list
            summary, all_tasks = parse_activities_file()
            completed_tasks = filter_completed_tasks(all_tasks)
            active_subagents = get_active_subagents()
            content = build_status_content(summary, all_tasks, completed_tasks, active_subagents)
            telegram_result = send_or_update_status_message(config, content)
            if telegram_result.get("success") and telegram_result.get("message_id"):
                # Update config with new message_id if needed
                config["message_id"] = telegram_result.get("message_id")
                config["last_updated"] = datetime.datetime.now().isoformat()
                config["last_summary_hash"] = hashlib.md5(content.encode()).hexdigest()
                save_telegram_config(config)
    except Exception as e:
        logger.warning(f"Telegram status update failed: {e}")
    
'''

# Insert with proper indentation (already at 4 spaces)
new_lines = lines[:insert_at] + [insertion] + lines[insert_at:]

# Write backup
backup_file = source_file + ".bak2"
with open(backup_file, 'w') as f:
    f.writelines(lines)

# Write new file
with open(source_file, 'w') as f:
    f.writelines(new_lines)

print(f"Inserted Telegram update call after line {log_line+1}")
print(f"Backup saved to {backup_file}")