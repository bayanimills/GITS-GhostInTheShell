#!/bin/bash
# Backup WORKFLOW_AUTO.md files before v3.0.0 rollout
# Creates timestamped backups for rollback capability

BACKUP_DIR="/home/agent/.openclaw/workspace-kaira/backups/workflow_v2_backup_$(date +%Y%m%d_%H%M%S)"
AGENTS="aria shelley donna doc danny kaira main"
TEMPLATE="/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md"

echo "=== WORKFLOW_AUTO.md BACKUP UTILITY ==="
echo "Backup time: $(date)"
echo "Backup directory: $BACKUP_DIR"
echo ""

# Create backup directory
mkdir -p "$BACKUP_DIR"
if [ $? -ne 0 ]; then
    echo "❌ Failed to create backup directory: $BACKUP_DIR"
    exit 1
fi

echo "✅ Created backup directory: $BACKUP_DIR"
echo ""

# Backup template if exists
if [ -f "$TEMPLATE" ]; then
    TEMPLATE_BACKUP="$BACKUP_DIR/template_WORKFLOW_AUTO.md"
    cp "$TEMPLATE" "$TEMPLATE_BACKUP"
    TEMPLATE_SIZE=$(stat -c "%s" "$TEMPLATE")
    echo "✅ Backed up template: $TEMPLATE ($TEMPLATE_SIZE bytes) → $TEMPLATE_BACKUP"
else
    echo "⚠️  Template not found: $TEMPLATE"
fi

echo ""

# Backup each agent's file
BACKUP_COUNT=0
MISSING_COUNT=0

for agent in $AGENTS; do
    AGENT_FILE="/home/agent/.openclaw/workspace-$agent/WORKFLOW_AUTO.md"
    
    if [ -f "$AGENT_FILE" ]; then
        AGENT_BACKUP="$BACKUP_DIR/${agent}_WORKFLOW_AUTO.md"
        cp "$AGENT_FILE" "$AGENT_BACKUP"
        AGENT_SIZE=$(stat -c "%s" "$AGENT_FILE")
        echo "✅ Backed up $agent: $AGENT_FILE ($AGENT_SIZE bytes) → $AGENT_BACKUP"
        BACKUP_COUNT=$((BACKUP_COUNT + 1))
    else
        echo "⚠️  Agent file not found: $AGENT_FILE"
        MISSING_COUNT=$((MISSING_COUNT + 1))
    fi
done

echo ""
echo "=== BACKUP SUMMARY ==="
echo "Backup directory: $BACKUP_DIR"
echo "Template backed up: $( [ -f "$TEMPLATE" ] && echo "✅ Yes" || echo "❌ No" )"
echo "Agent files backed up: $BACKUP_COUNT/$(echo "$AGENTS" | wc -w)"
echo "Missing files: $MISSING_COUNT"
echo "Total size: $(du -sh "$BACKUP_DIR" | cut -f1)"
echo ""
echo "📋 Backup contents:"
ls -la "$BACKUP_DIR/" | tail -n +2
echo ""
echo "🔒 To restore:"
echo "  cp \"$BACKUP_DIR/template_WORKFLOW_AUTO.md\" \"$TEMPLATE\""
echo "  for agent in $AGENTS; do"
echo "    cp \"$BACKUP_DIR/\${agent}_WORKFLOW_AUTO.md\" \"/home/agent/.openclaw/workspace-\$agent/WORKFLOW_AUTO.md\""
echo "  done"
echo ""
echo "💾 Backup complete. Store this path for rollback: $BACKUP_DIR"