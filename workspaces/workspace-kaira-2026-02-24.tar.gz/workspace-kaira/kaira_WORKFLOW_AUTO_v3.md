# WORKFLOW_AUTO.md - Agent Automation Framework & Template
## Version: 3.0.0 | Created: 2026-02-23 | Status: ✅ DEFINITIVE_TEMPLATE (NO MAJOR VERSIONS AFTER THIS)
**Purpose**: This file serves dual purposes:
1. **Default Template**: When agents lack their own WORKFLOW_AUTO.md, they read this file as a template
2. **Master Reference**: Contains standardized workflow documentation patterns for all agents
3. **Autonomous Work Philosophy**: Defines how agents work autonomously during idle periods
4. **Reasoning Framework**: Embeds systematic validation of assumptions in workflow design

**v3.0.0 Changes from v2.0.0**:
- ✅ Integrated Reasoning Framework (five critical questions) throughout template
- ✅ Added concrete agent examples (Kaira, Shelley, Donna, Doc, Aria)
- ✅ Enhanced Autonomous Work Philosophy with NAWS as operational example
- ✅ Added "Rollout to Your Agent" checklist for future agent onboarding
- ✅ Incorporated n8n workflow patterns for error handling & recovery
- ✅ Clarified agent‑specific customization zones with visual markers
- ✅ Designated as "DEFINITIVE_TEMPLATE" - no major versions after this

## 📋 HOW TO USE THIS FILE

### **IF YOU ARE READING THIS DURING POST‑COMPACTION AUDIT:**
You're reading the default template because your agent doesn't have its own `WORKFLOW_AUTO.md` file yet. Follow these steps:

### **Quick Start Guide for New Agents:**
1. **Copy to Your Workspace**: `cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md /home/agent/.openclaw/workspace-[YOUR_NAME]/WORKFLOW_AUTO.md`
2. **Customize**: Replace `[AGENT_NAME]`, `[YOUR_ROLE]`, and all placeholder sections with your specific content
3. **Implement**: Follow the Implementation Plan in the document
4. **Test**: Run validation steps before full automation deployment
5. **Maintain**: Update regularly as your workflows evolve

### **For Agents With Existing WORKFLOW_AUTO.md:**
Compare your file with this template monthly to:
1. Adopt useful new sections or patterns
2. Ensure consistency with system standards
3. Contribute improvements back to this master template

### Template Conventions:
- `[BRACKETED_TEXT]`: Replace with your specific content
- `<!-- COMMENT -->`: Instructional notes (remove when customizing)
- `✅`, `⚠️`, `❌`: Status indicators (maintain this visual language)
- `#tags`: Use consistent tagging for searchability
- `<!-- AGENT‑SPECIFIC START -->` / `<!-- AGENT‑SPECIFIC END -->`: Customization zone markers
- `🎯 REASONING FRAMEWORK CHECK`: Embedded critical thinking prompts

---

## 🎯 OVERVIEW & AGENT CONTEXT

<!-- Replace this entire section with your agent's specific context -->
**Agent Name**: `Kaira` (Delegation Agent)  
**Primary Role**: `Delegation Agent` (Task execution specialist)  
**Domain Focus**: `Task execution and system reliability` (Delegation agent operations)  
**Timezone**: `Australia/Sydney` (UTC+11)  

**Purpose**: This document defines automated workflows for `Kaira`. Workflows are scheduled or triggered events that execute without user intervention, ensuring consistent monitoring, reporting, and system maintenance within your domain.

**Ecosystem Alignment**: 🟢 `Task execution`-FOCUSED


<!-- Replace this entire section with your agent's specific context -->
**Agent Name**: `[AGENT_NAME]` (e.g., Aria, Shelley, Kaira, etc.)  
**Primary Role**: `[YOUR_ROLE]` (e.g., "Finmills Growth Agent", "Shop Bitcoin Australia Manager", "Delegation Agent")  
**Domain Focus**: `[YOUR_DOMAIN]` (e.g., "Finmills ecosystem growth", "SBA operations", "Task execution")  
**Timezone**: `[YOUR_TIMEZONE]` (e.g., "Australia/Sydney", "UTC")  

**Purpose**: This document defines automated workflows for `[AGENT_NAME]`. Workflows are scheduled or triggered events that execute without user intervention, ensuring consistent monitoring, reporting, and system maintenance within your domain.

**Ecosystem Alignment**: 🟢 `[YOUR_DOMAIN]`‑FOCUSED

**Reasoning Framework Integration**: Before designing any workflow, answer these five critical questions:
1. **Trigger Verification**: What exact event initiates this process?
2. **Precondition Check**: What must be true for this to happen?
3. **Evidence Requirement**: How do we know this works? (documentation/test)
4. **Boundary Analysis**: Who/what is affected by this?
5. **Failure Planning**: What happens if we're wrong?

---

## ⚠️ IMPORTANT GUIDELINES

### **DO NOT MODIFY** (Core Structural Elements):
<!-- These elements should remain consistent across all agents for system interoperability -->
- Cron job schedule format and payload structure
- Heartbeat trigger conditions and response patterns  
- Memory flush protocols (pre/post‑compaction)
- Git auto‑commit configuration
- Error handling escalation levels
- Template section headers and organization
- Reasoning framework integration (five critical questions)
- Autonomous work philosophy sections

### **SAFE TO MODIFY** (Agent‑Specific Customizations):
<!-- Customize these for your specific domain and workflows -->
- Agent name, role, and domain focus
- Scheduled workflow timings and frequencies
- Script paths and command parameters  
- Alert thresholds and notification channels
- Reporting detail levels and formats
- Domain‑specific directories and file structures
- New workflow additions (following template structure)
- Content between `<!-- AGENT‑SPECIFIC START -->` and `<!-- AGENT‑SPECIFIC END -->` markers

### **ADDING NEW WORKFLOWS** (Standard Process with Reasoning Framework):
<!-- Follow this process when adding any new automation -->
1. **🎯 Apply Reasoning Framework**: Answer the five critical questions about this workflow
2. **Define Purpose & Business Value**: What problem does this solve?
3. **Specify Trigger**: Cron schedule, event condition, or manual trigger
4. **Document Payload/Actions**: Exact commands, scripts, or agent messages
5. **Set Error Handling**: Failure modes, retry logic, alerting (use n8n patterns)
6. **Test in Isolation**: Run in isolated session before production
7. **Update This Document**: Add workflow to appropriate section
8. **Deploy & Monitor**: Schedule execution and track performance

### **🎯 Reasoning Framework: Five Critical Questions for Every Workflow**
Before implementing any workflow, document answers to:
1. **Trigger Verification**: What exact event/time initiates execution? (e.g., "cron schedule: 0 15 * * *, system event: memory compaction, file detection")
2. **Precondition Check**: What must be true before execution? (e.g., "API key configured, network available, dependencies installed")
3. **Evidence Requirement**: How do we know this works? (e.g., "test execution succeeded, documentation exists, similar workflow proven")
4. **Boundary Analysis**: Who/what is affected? (e.g., "affects SBA email system, requires Gmail API access, impacts customer response times")
5. **Failure Planning**: What happens if wrong? (e.g., "retry 3x, log error, notify user, fallback to manual process")

---

## 🔄 SCHEDULED CRON WORKFLOWS

### **1. Heartbeat System Health Check**
- **Schedule**: `0 */2 * * *` (every 2 hours at minute 0)
- **Agent**: `Kaira` (main session)
- **Payload**: Execute HEARTBEAT.md checks: workspace integrity, git connectivity, memory usage, Jarvis status
- **Purpose**: Ensure delegation agent operational health and system reliability
- **Content/Output**: Status report in memory logs, alerts for critical issues
- **Delivery**: Memory log entries (`memory/YYYY-MM-DD.md`), Telegram alerts for critical failures
- **Status**: ✅ ACTIVE (Job ID: `heartbeat-system-health`)

- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

### **2. Geopolitical Monitoring Check**
- **Schedule**: `0 */4 * * *` (every 4 hours at minute 0)
- **Agent**: `Kaira` (main session)
- **Payload**: Check major news sources for significant geopolitical events, assess urgency, decide reporting need
- **Purpose**: Provide user advisories on significant geopolitical events affecting Bitcoin/crypto markets
- **Content/Output**: Event analysis with urgency categorization (High/Medium/Low), memory log entries
- **Delivery**: Memory log entries (`memory/YYYY-MM-DD.md`), Telegram alerts for critical events only
- **Status**: ✅ ACTIVE (Job ID: `geopolitical-monitoring`)

- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

### **3. Agent Coordination Check**
- **Schedule**: `30 */4 * * *` (every 4 hours at minute 30)
- **Agent**: `Kaira` (main session)
- **Payload**: Check Jarvis status, review task queue, update status report, verify cron jobs
- **Purpose**: Ensure multi-agent coordination and task delegation flow integrity
- **Content/Output**: Coordination status report, task queue summary, memory log entries
- **Delivery**: Memory log entries (`memory/YYYY-MM-DD.md`), internal agent notifications
- **Status**: ✅ ACTIVE (Job ID: `agent-coordination`)

- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

### **4. Daily Backup Procedures**
- **Schedule**: `0 2 * * *` (daily at 02:00)
- **Agent**: `Kaira` (isolated session)
- **Payload**: Run workspace backup script, commit changes to git, verify backup integrity
- **Purpose**: Ensure delegation agent workspace is version-controlled and recoverable
- **Content/Output**: Git commit hash, backup status report, memory log entries
- **Delivery**: Memory log entries (`memory/YYYY-MM-DD.md`), git remote push notifications
- **Status**: ✅ ACTIVE (Job ID: `daily-backup`)

- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

### **5. Self‑Maintenance Review**
- **Schedule**: `0 3 * * *` (daily at 03:00)
- **Agent**: `Kaira` (main session)
- **Payload**: Review memory logs, update documentation, test recovery scripts, archive old logs
- **Purpose**: Maintain agent operational efficiency and continuous improvement
- **Content/Output**: Maintenance report, documentation updates, memory log summaries
- **Delivery**: Memory log entries (`memory/YYYY-MM-DD.md`), documentation commit notifications
- **Status**: ✅ ACTIVE (Job ID: `self-maintenance`)

- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

### **6. Nighttime Autonomous Work (NAWS)**
- **Schedule**: `0 23,1,3,5 * * *` (23:00, 01:00, 03:00, 05:00 Sydney time)
- **Agent**: `Kaira` (main session)
- **Payload**: Execute `nighttime-check.py` to process queued tasks from `nighttime-activities.md`
- **Purpose**: Autonomous task execution during overnight hours with safety boundaries
- **Content/Output**: Task completion updates, memory file entries with `#nighttime-work` tag
- **Delivery**: File updates (`nighttime-activities.md`, `memory/YYYY‑MM‑DD.md`), log file (`logs/nighttime-check.log`)
- **Status**: ✅ ACTIVE (Skill: `nighttime-autonomous-work v1.0.0`)
- **Safety**: Internal/non‑destructive operations only, 23:00‑07:00 time window, rollback capability

- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

### **Template Notes for Cron Workflows:**
- Use isolated sessions for resource-intensive or long-running tasks
- Main sessions for quick checks and user notifications
- Include Job IDs from `cron list` command for reference
- Document timezone explicitly (cron uses system timezone)
- **🎯 Reasoning Framework**:
  1. **Trigger**: `[TO BE DOCUMENTED]`
  2. **Preconditions**: `[TO BE DOCUMENTED]`
  3. **Evidence**: `[TO BE DOCUMENTED]`
  4. **Boundaries**: `[TO BE DOCUMENTED]`
  5. **Failure Plan**: `[TO BE DOCUMENTED]`

