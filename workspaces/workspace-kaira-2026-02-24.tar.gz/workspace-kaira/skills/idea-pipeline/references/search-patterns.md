# Search Patterns

## Overview

The structured directory layout and consistent naming conventions enable powerful search capabilities. This document provides patterns for finding, analyzing, and working with pipeline artifacts.

## Basic Search Commands

### Find Files by Type
```bash
# Find all task definitions
find log/tasks/ -name "TASK-*.yaml" -type f

# Find all decision records
find log/decisions/ -name "DECISION-*.md" -type f

# Find all experiment files
find log/tasks/ -path "*/experiments/*" -type f

# Find all result summaries
find log/tasks/ -name "summary.md" -type f
```

### Find by Date
```bash
# Find tasks from specific date
find log/tasks/ -name "TASK-2026-02-16-*.yaml"

# Find tasks from date range
find log/tasks/ -name "TASK-2026-02-*.yaml"

# Find recent tasks (last 7 days)
for i in {0..6}; do
  date=$(date -d "$i days ago" +%Y-%m-%d)
  find log/tasks/ -name "TASK-$date-*.yaml" 2>/dev/null
done

# Find decisions made in current month
find log/decisions/ -name "DECISION-$(date +%Y-%m)-*.md"
```

### Find by Content
```bash
# Find tasks containing specific keyword
grep -l "database" log/tasks/*.yaml

# Find decisions about specific topic
grep -r "microservices" log/decisions/ --include="*.md"

# Find experiments with benchmark results
find log/tasks/ -path "*/experiments/*" -name "*benchmark*" -type f

# Find tasks with specific status
grep -l "status: pending" log/tasks/*.yaml
```

## Advanced Search Patterns

### Multi-criteria Search
```bash
# Find pending tasks about database from last 3 days
for i in {0..2}; do
  date=$(date -d "$i days ago" +%Y-%m-%d)
  files=$(find log/tasks/ -name "TASK-$date-*.yaml" 2>/dev/null)
  for file in $files; do
    if grep -q "status: pending" "$file" && grep -q "database" "$file"; then
      echo "$file"
    fi
  done
done
```

### Status Analysis
```bash
# Count tasks by status
grep -h "status:" log/tasks/*.yaml | sort | uniq -c

# Count decisions by status
grep -h "## Status" log/decisions/*.md | sort | uniq -c

# Find tasks stuck in processing
grep -l "status: processing" log/tasks/*.yaml | while read file; do
  created=$(grep "created:" "$file" | head -1)
  echo "$file: $created"
done
```

### Timeline Analysis
```bash
# Find tasks created but not decided
for task_file in log/tasks/TASK-*.yaml; do
  task_id=$(basename "$task_file" .yaml)
  if [ ! -f "log/tasks/$task_id/summary.md" ]; then
    echo "No results for: $task_id"
  fi
done

# Find decisions without related task completion
for decision_file in log/decisions/DECISION-*.md; do
  if ! grep -q "Related Tasks:" "$decision_file"; then
    echo "Decision without task reference: $decision_file"
  fi
done
```

## Search Scripts

### find-tasks.sh
```bash
#!/bin/bash
# Search tasks by multiple criteria

SEARCH_DIR="log/tasks"
STATUS=""
TAG=""
DATE=""
CONTENT=""

while [[ $# -gt 0 ]]; do
  case $1 in
    --status)
      STATUS="$2"
      shift 2
      ;;
    --tag)
      TAG="$2"
      shift 2
      ;;
    --date)
      DATE="$2"
      shift 2
      ;;
    --content)
      CONTENT="$2"
      shift 2
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

find "$SEARCH_DIR" -name "TASK-*.yaml" -type f | while read file; do
  MATCH=true
  
  # Check status
  if [ -n "$STATUS" ]; then
    if ! grep -q "status: $STATUS" "$file"; then
      MATCH=false
    fi
  fi
  
  # Check tag
  if [ -n "$TAG" ]; then
    if ! grep -q "$TAG" "$file"; then
      MATCH=false
    fi
  fi
  
  # Check date
  if [ -n "$DATE" ]; then
    if [[ ! "$file" == *"TASK-$DATE-"* ]]; then
      MATCH=false
    fi
  fi
  
  # Check content
  if [ -n "$CONTENT" ]; then
    if ! grep -q "$CONTENT" "$file"; then
      MATCH=false
    fi
  fi
  
  if [ "$MATCH" = true ]; then
    echo "$file"
  fi
done
```

### analyze-pipeline.py
```python
#!/usr/bin/env python3
"""
Analyze pipeline metrics and statistics
"""

import os
import re
import yaml
from datetime import datetime
from pathlib import Path

class PipelineAnalyzer:
    def __init__(self, log_dir="log"):
        self.log_dir = Path(log_dir)
        
    def count_tasks_by_status(self):
        """Count tasks by status"""
        counts = {}
        for task_file in self.log_dir.glob("tasks/TASK-*.yaml"):
            with open(task_file) as f:
                try:
                    data = yaml.safe_load(f)
                    status = data.get('status', 'unknown')
                    counts[status] = counts.get(status, 0) + 1
                except yaml.YAMLError:
                    continue
        return counts
    
    def average_time_to_decision(self):
        """Calculate average time from task creation to decision"""
        times = []
        for task_file in self.log_dir.glob("tasks/TASK-*.yaml"):
            task_id = task_file.stem
            # Find related decision
            for decision_file in self.log_dir.glob("decisions/DECISION-*.md"):
                with open(decision_file) as f:
                    content = f.read()
                    if task_id in content:
                        # Extract timestamps
                        with open(task_file) as tf:
                            task_data = yaml.safe_load(tf)
                            task_time = datetime.fromisoformat(task_data['created'].replace('Z', '+00:00'))
                        
                        # Extract decision time from filename
                        match = re.search(r'DECISION-(\d{4}-\d{2}-\d{2})', decision_file.name)
                        if match:
                            decision_date = datetime.strptime(match.group(1), '%Y-%m-%d')
                            # Assume decision at 09:00 local time
                            decision_time = decision_date.replace(hour=9, minute=0)
                            time_diff = (decision_time - task_time).total_seconds() / 3600  # hours
                            times.append(time_diff)
                        break
        return sum(times) / len(times) if times else 0
    
    def experiment_type_distribution(self):
        """Distribution of experiment types"""
        types = {}
        for exp_file in self.log_dir.glob("tasks/*/experiments/*"):
            if exp_file.is_file():
                # Extract type from filename
                match = re.search(r'experiment-\d+-(.*?)-', exp_file.name)
                if match:
                    exp_type = match.group(1)
                    types[exp_type] = types.get(exp_type, 0) + 1
        return types
    
    def generate_report(self):
        """Generate comprehensive analysis report"""
        report = []
        report.append("# Pipeline Analysis Report")
        report.append(f"Generated: {datetime.now().isoformat()}")
        report.append("")
        
        # Task statistics
        task_counts = self.count_tasks_by_status()
        report.append("## Task Statistics")
        report.append(f"Total tasks: {sum(task_counts.values())}")
        for status, count in sorted(task_counts.items()):
            report.append(f"- {status}: {count}")
        report.append("")
        
        # Time metrics
        avg_time = self.average_time_to_decision()
        report.append("## Time Metrics")
        report.append(f"Average time to decision: {avg_time:.1f} hours")
        report.append("")
        
        # Experiment analysis
        exp_types = self.experiment_type_distribution()
        report.append("## Experiment Distribution")
        for exp_type, count in sorted(exp_types.items()):
            report.append(f"- {exp_type}: {count}")
        
        return "\n".join(report)

if __name__ == "__main__":
    analyzer = PipelineAnalyzer()
    print(analyzer.generate_report())
```

## Common Search Scenarios

### Morning Review Preparation
```bash
#!/bin/bash
# Prepare morning review materials

TODAY=$(date +%Y-%m-%d)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)

echo "=== Morning Review for $TODAY ==="
echo ""

echo "1. Tasks completed overnight:"
find log/tasks/ -name "TASK-$YESTERDAY-*" -type f | while read file; do
  if grep -q "status: processing" "$file"; then
    task_id=$(basename "$file" .yaml)
    if [ -f "log/tasks/$task_id/summary.md" ]; then
      echo "  ✓ $task_id - Results ready"
    else
      echo "  ⏳ $task_id - Still processing"
    fi
  fi
done

echo ""
echo "2. New tasks from yesterday:"
find log/tasks/ -name "TASK-$YESTERDAY-*" -type f | while read file; do
  if grep -q "status: pending" "$file"; then
    title=$(grep "title:" "$file" | head -1 | cut -d'"' -f2)
    echo "  📝 $(basename "$file" .yaml): $title"
  fi
done

echo ""
echo "3. Decisions needed:"
grep -l "## Status" log/decisions/*.md | while read file; do
  if grep -q "## Status.*Proposed" "$file"; then
    echo "  🤔 $(basename "$file" .md) - Needs review"
  fi
done
```

### Finding Related Artifacts
```bash
#!/bin/bash
# Find all artifacts related to a specific task

TASK_ID="$1"

if [ -z "$TASK_ID" ]; then
  echo "Usage: $0 TASK-YYYY-MM-DD-NNN"
  exit 1
fi

echo "=== Artifacts for $TASK_ID ==="
echo ""

# Task definition
echo "1. Task Definition:"
ls -la "log/tasks/$TASK_ID.yaml" 2>/dev/null || echo "  Not found"

# Task directory
echo ""
echo "2. Task Directory:"
if [ -d "log/tasks/$TASK_ID" ]; then
  find "log/tasks/$TASK_ID" -type f | sort
else
  echo "  Not created yet"
fi

# Related decisions
echo ""
echo "3. Related Decisions:"
grep -r "$TASK_ID" log/decisions/ --include="*.md" | cut -d: -f1 | sort -u

# References in other tasks
echo ""
echo "4. References in Other Tasks:"
grep -r "$TASK_ID" log/tasks/ --include="*.yaml" | grep -v "$TASK_ID.yaml" | cut -d: -f1 | sort -u
```

### Pipeline Health Check
```bash
#!/bin/bash
# Check pipeline health and identify issues

echo "=== Pipeline Health Check ==="
echo ""

# Check directory structure
echo "1. Directory Structure:"
required_dirs=("tasks" "decisions" "templates" "archive")
for dir in "${required_dirs[@]}"; do
  if [ -d "log/$dir" ]; then
    echo "  ✓ log/$dir/"
  else
    echo "  ✗ Missing: log/$dir/"
  fi
done

# Check for orphaned directories
echo ""
echo "2. Orphaned Directories:"
for task_dir in log/tasks/TASK-*/; do
  task_id=$(basename "$task_dir")
  if [ ! -f "log/tasks/$task_id.yaml" ]; then
    echo "  ⚠️  Directory without task file: $task_id"
  fi
done

# Check template freshness
echo ""
echo "3. Template Freshness:"
if [ -f "log/templates/task-template.yaml" ]; then
  template_age=$(( ( $(date +%s) - $(stat -c %Y "log/templates/task-template.yaml") ) / 86400 ))
  if [ $template_age -gt 30 ]; then
    echo "  ⚠️  Templates are $template_age days old - consider updating"
  else
    echo "  ✓ Templates up to date"
  fi
else
  echo "  ✗ Missing templates"
fi

# Check archive growth
echo ""
echo "4. Archive Size:"
archive_count=$(find log/archive/ -type f | wc -l)
if [ $archive_count -gt 100 ]; then
  echo "  ⚠️  Large archive: $archive_count files - consider cleanup"
else
  echo "  ✓ Archive size: $archive_count files"
fi
```

## Integration with Agent Workflows

### Agent Search Functions
```javascript
// Find pending tasks for overnight processing
function findPendingTasks() {
  const cmd = `find log/tasks/ -name "TASK-*.yaml" -exec grep -l "status: pending" {} \\;`;
  const result = exec(cmd);
  return result.stdout.trim().split('\n').filter(Boolean);
}

// Get task details
function getTaskDetails(taskFile) {
  const content = read(taskFile);
  const yaml = parseYaml(content);
  return {
    id: yaml.id,
    title: yaml.title,
    priority: yaml.priority,
    requirements: yaml.requirements,
    suggested_experiments: yaml.suggested_experiments || []
  };
}

// Find similar past decisions
function findSimilarDecisions(task) {
  // Extract keywords from task
  const keywords = extractKeywords(task.title + ' ' + task.description);
  
  // Search for decisions with similar keywords
  const searchCmd = `grep -r -l "${keywords.join('\\|')}" log/decisions/ --include="*.md"`;
  const result = exec(searchCmd);
  return result.stdout.trim().split('\n').filter(Boolean);
}

// Generate search index
function generateSearchIndex() {
  const index = {
    tasks: {},
    decisions: {},
    experiments: {}
  };
  
  // Index tasks
  const taskFiles = exec('find log/tasks/ -name "TASK-*.yaml"').stdout.trim().split('\n');
  taskFiles.forEach(file => {
    const content = read(file);
    const yaml = parseYaml(content);
    index.tasks[yaml.id] = {
      title: yaml.title,
      status: yaml.status,
      tags: yaml.tags || [],
      created: yaml.created
    };
  });
  
  // Index decisions
  const decisionFiles = exec('find log/decisions/ -name "DECISION-*.md"').stdout.trim().split('\n');
  decisionFiles.forEach(file => {
    const content = read(file);
    // Extract title from first line
    const titleMatch = content.match(/^# Decision Record: (.*)$/m);
    if (titleMatch) {
      const id = file.match(/DECISION-[^/]+/)[0];
      index.decisions[id] = {
        title: titleMatch[1],
        status: content.match(/## Status\s*\n(.*)/m)?.[1]?.trim() || 'unknown',
        created: file.match(/DECISION-(\d{4}-\d{2}-\d{2})/)[1]
      };
    }
  });
  
  write('log/search-index.json', JSON.stringify(index, null, 2));
  return index;
}
```

## Performance Tips

### Indexing for Large Pipelines
```bash
# Create search index
find log/tasks/ -name "TASK-*.yaml" -exec echo "TASK: {}" \; > /tmp/pipeline-index.txt
find log/decisions/ -name "DECISION-*.md" -exec echo "DECISION: {}" \; >> /tmp/pipeline-index.txt

# Use ripgrep for faster searches
rg "database" log/ --type yaml --type markdown

# Use fd for faster file finding
fd "TASK-.*\.yaml" log/tasks/
```

### Regular Maintenance
```bash
# Weekly: Rebuild search index
./scripts/generate-search-index.sh

# Monthly: Archive old tasks
find log/tasks/ -name "TASK-*.yaml" -mtime +90 -exec mv {} log/archive/completed-tasks/ \;

# Quarterly: Compress archive
tar -czf log/archive/archive-$(date +%Y-%m).tar.gz log/archive/completed-tasks/
```

## Visualizations

### Generate Pipeline Graph
```python
#!/usr/bin/env python3
"""
Generate visualization of pipeline flow
"""

import graphviz
from pathlib import Path

def generate_pipeline_graph(log_dir="log"):
    dot = graphviz.Digraph('pipeline', comment='Idea Pipeline Flow')
    dot.attr(rankdir='LR')
    
    # Add nodes for each task
    for task_file in Path(log_dir).glob("tasks/TASK-*.yaml"):
        task_id = task_file.stem
        dot.node(task_id, task_id, shape='box')
        
        # Check for related decision
        for decision_file in Path(log_dir).glob("decisions/DECISION-*.md"):
            with open(decision_file) as f:
                if task_id in f.read():
                    decision_id = decision_file.stem
                    dot.node(decision_id, decision_id, shape='ellipse')
                    dot.edge(task_id, decision_id)
                    break
    
    dot.render('pipeline-flow', format='png', cleanup=True)
    print("Generated pipeline-flow.png")
```

This graph shows task-to-decision relationships, helping visualize pipeline throughput and bottlenecks.