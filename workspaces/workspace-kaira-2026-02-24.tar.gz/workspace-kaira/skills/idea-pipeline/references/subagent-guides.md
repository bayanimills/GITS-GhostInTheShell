# Subagent Guides

## Subagent Types & Selection

### Research Agent
**Purpose**: Gather information, analyze existing knowledge, provide literature review
**Best for**: Market research, technology comparisons, best practices, competitive analysis
**Agent IDs**: `scientist`, `researcher`, `analyst` (varies by installation)
**Prompt Patterns**:
```
"Research {{topic}} focusing on {{aspects}}. Provide: 
1. Comprehensive overview
2. Key findings from reputable sources
3. Comparison of options/approaches
4. Recommendations based on evidence"
```

**Example Task**:
```
Research database alternatives for read-heavy workloads.
Focus on: PostgreSQL vs. MySQL vs. CockroachDB.
Include: performance benchmarks, scalability, cost, migration complexity.
```

**Expected Output**:
- Markdown report with citations
- Comparison table
- Recommendation with rationale

### Code Agent
**Purpose**: Write, test, and debug code; create prototypes and scripts
**Best for**: Implementation prototypes, benchmark scripts, automation tools, proof-of-concepts
**Agent IDs**: `coder`, `developer`, `engineer` (varies by installation)
**Prompt Patterns**:
```
"Create {{type of code}} that {{achieves goal}}.
Requirements: {{specific requirements}}.
Deliverables: {{files to create}}.
Include: {{documentation, tests, etc.}}"
```

**Example Task**:
```
Create a benchmark script comparing database performance.
Test: Read-heavy workload with concurrent users.
Output: CSV with latency and throughput metrics.
Include: Docker setup for consistent testing environment.
```

**Expected Output**:
- Working code with documentation
- Setup instructions
- Example output/usage

### Analysis Agent
**Purpose**: Process data, identify patterns, draw insights, make recommendations
**Best for**: Data analysis, performance evaluation, cost analysis, risk assessment
**Agent IDs**: `analyst`, `scientist`, `researcher` (varies by installation)
**Prompt Patterns**:
```
"Analyze {{data/situation}} to {{achieve goal}}.
Methodology: {{approach to take}}.
Output: {{findings format}}.
Focus on: {{key aspects to analyze}}."
```

**Example Task**:
```
Analyze benchmark results from database testing.
Identify: Performance patterns, bottlenecks, optimization opportunities.
Provide: Clear recommendations with data support.
Format: Executive summary plus detailed analysis.
```

**Expected Output**:
- Analysis report with charts/tables
- Key insights and patterns
- Actionable recommendations

### Synthesis Agent
**Purpose**: Combine multiple inputs, create cohesive summaries, generate recommendations
**Best for**: Result aggregation, report generation, decision support
**Agent IDs**: `synthesizer`, `writer`, `strategist` (varies by installation)
**Prompt Patterns**:
```
"Synthesize findings from {{sources}} into {{output format}}.
Focus on: {{key themes, contradictions, consensus}}.
Provide: {{recommendations, next steps, etc.}}"
```

**Example Task**:
```
Synthesize research, code, and analysis results from database evaluation.
Create: Executive summary for morning review.
Highlight: Key findings, trade-offs, clear recommendation.
Format: Decision-ready document.
```

**Expected Output**:
- Cohesive summary document
- Integrated findings from multiple sources
- Clear decision framework

### Prototype Agent
**Purpose**: Create functional prototypes, mockups, or demonstrations
**Best for**: UI prototypes, workflow demonstrations, concept validation
**Agent IDs**: `designer`, `prototyper`, `creator` (varies by installation)
**Prompt Patterns**:
```
"Create a prototype that demonstrates {{concept}}.
Focus on: {{key functionality}}.
Deliverables: {{files, instructions, etc.}}.
Constraints: {{technical or design constraints}}."
```

**Example Task**:
```
Create a dark mode prototype for web application.
Use: CSS custom properties for theming.
Include: Example components (header, cards, buttons).
Provide: Implementation guide for full application.
```

**Expected Output**:
- Prototype files (HTML/CSS/JS)
- Usage instructions
- Extension guide

## Spawning Subagents

### Basic Spawn Pattern
```javascript
sessions_spawn({
  task: "{{clear, specific task description}}",
  label: "{{descriptive-label-TASK-ID}}",
  agentId: "{{appropriate-agent-id}}",
  model: "{{model-if-needed}}",
  cleanup: "keep"  // Keep session for review
});
```

### With Results Collection
```javascript
// Spawn agent with explicit output requirements
sessions_spawn({
  task: `Research {{topic}} and produce:
  1. Markdown report in /log/tasks/{{TASK-ID}}/experiments/experiment-01-research.md
  2. Summary of key findings
  3. Recommendation with rationale
  4. Citations from reputable sources`,
  label: `research-{{TASK-ID}}`,
  agentId: "scientist",
  runTimeoutSeconds: 3600,  // 1 hour
  cleanup: "keep"
});
```

### Multiple Parallel Agents
```javascript
// Spawn multiple agents for different aspects
const experiments = [
  {
    task: "Research aspect 1...",
    label: "research-1-{{TASK-ID}}",
    agentId: "scientist"
  },
  {
    task: "Code aspect 2...",
    label: "code-1-{{TASK-ID}}",
    agentId: "coder"
  },
  {
    task: "Analyze aspect 3...",
    label: "analysis-1-{{TASK-ID}}",
    agentId: "analyst"
  }
];

experiments.forEach(exp => {
  sessions_spawn({
    task: exp.task,
    label: exp.label,
    agentId: exp.agentId,
    cleanup: "keep"
  });
});
```

### Sequential Agents (Dependent Tasks)
```javascript
// First agent produces data for second agent
const researchTask = sessions_spawn({
  task: "Research and produce data...",
  label: "research-{{TASK-ID}}",
  agentId: "scientist",
  cleanup: "keep"
});

// Wait for completion (simplified - in reality need to monitor)
// Then spawn analysis agent
setTimeout(() => {
  sessions_spawn({
    task: "Analyze the research data from previous agent...",
    label: "analysis-{{TASK-ID}}",
    agentId: "analyst",
    cleanup: "keep"
  });
}, 3600000);  // Wait 1 hour (adjust based on expected completion)
```

## Agent Selection Matrix

| Task Type | Primary Agent | Secondary Agent | When to Use |
|-----------|---------------|-----------------|-------------|
| **Technology Research** | Research Agent | Analysis Agent | Comparing options, evaluating technologies |
| **Performance Testing** | Code Agent | Analysis Agent | Benchmarking, load testing |
| **Process Improvement** | Research Agent | Synthesis Agent | Workflow optimization, tool selection |
| **Prototype Creation** | Code Agent | Prototype Agent | Proof of concept, demonstration |
| **Data Analysis** | Analysis Agent | Research Agent | Interpreting results, identifying patterns |
| **Strategic Decision** | Research Agent + Analysis Agent | Synthesis Agent | Business decisions, partnerships |
| **UI/UX Evaluation** | Research Agent | Prototype Agent | Design decisions, user experience |

## Task Decomposition Guide

### Complex Task → Multiple Subagent Tasks

**Original Task**: "Evaluate moving to microservices architecture"

**Decomposed**:
1. **Research Agent**: Microservices patterns, benefits, challenges
2. **Research Agent**: Case studies (successes and failures)
3. **Code Agent**: Create simple microservice prototype
4. **Analysis Agent**: Evaluate current monolith for decomposition
5. **Analysis Agent**: Cost/benefit analysis
6. **Synthesis Agent**: Combine all findings into recommendation

### Simple Task → Single Subagent Task

**Original Task**: "Choose logging library"

**Decomposed**:
1. **Research Agent**: Compare popular logging libraries
   - Features comparison
   - Performance benchmarks
   - Community support
   - Migration effort

## Prompt Engineering for Subagents

### Research Agent Prompts
**Good**:
```
"Research {{topic}} from these perspectives:
1. Current state of the art
2. Popular tools/libraries/frameworks
3. Performance characteristics
4. Community and ecosystem
5. Migration/learning curve

Cite reputable sources (official docs, benchmark studies, etc.).
Present findings in comparison table format.
Provide clear recommendation based on {{criteria}}."
```

**Bad**:
```
"Tell me about {{topic}}."  // Too vague
```

### Code Agent Prompts
**Good**:
```
"Create {{language}} script that {{functionality}}.
Requirements:
- Input: {{input format}}
- Output: {{output format}}
- Dependencies: {{list}}
- Error handling: {{requirements}}
- Performance: {{constraints}}

Deliver:
1. Main script file
2. README with usage instructions
3. Example/test data
4. Performance notes
```

**Bad**:
```
"Write some code for {{thing}}."  // Unclear requirements
```

### Analysis Agent Prompts
**Good**:
```
"Analyze {{data/situation}} using {{methodology}}.
Focus on:
1. Key patterns and trends
2. Anomalies or outliers
3. Implications for {{decision}}
4. Risks and opportunities

Provide:
- Executive summary (1 paragraph)
- Detailed analysis with supporting data
- Visualizations if helpful
- Actionable recommendations
```

**Bad**:
```
"Look at this data and tell me what you think."  // No structure
```

## Monitoring & Quality Control

### Checking Subagent Progress
```javascript
// Check on spawned sessions
sessions_list({
  kinds: ["isolated"],
  activeMinutes: 240  // Last 4 hours
});
```

### Reviewing Subagent Outputs
**Quality Checklist**:
- [ ] Task completed as specified
- [ ] Output format matches requirements
- [ ] Evidence/citations provided (for research)
- [ ] Code runs without errors (for code)
- [ ] Analysis is logically sound
- [ ] Recommendations are actionable

### Handling Poor Results
**If subagent output is low quality**:
1. **Clarify and re-spawn**: Provide more specific instructions
2. **Different agent**: Try different agent ID
3. **Different model**: Request different model if available
4. **Manual intervention**: Complete task manually, note for future

## Agent Configuration

### Model Selection
- **Research/Analysis**: Prefer models with strong reasoning (GPT-4, Claude)
- **Code Generation**: Prefer models with coding expertise (GPT-4, Claude)
- **Synthesis/Writing**: Prefer models with strong language skills

### Timeout Settings
- **Research tasks**: 1-2 hours
- **Code tasks**: 30 minutes - 2 hours (depending on complexity)
- **Analysis tasks**: 30 minutes - 1 hour
- **Quick tasks**: 15-30 minutes

### Resource Allocation
- **CPU/Memory intensive**: Consider node allocation
- **Long-running**: Set appropriate timeouts
- **Parallel tasks**: Monitor system load

## Integration with Pipeline

### Automatic Spawning from Task
```javascript
// Example: Process task and spawn appropriate agents
function processTask(task) {
  const experiments = planExperiments(task);
  
  experiments.forEach(experiment => {
    sessions_spawn({
      task: experiment.instructions,
      label: `${experiment.type}-${task.id}`,
      agentId: getAgentIdForType(experiment.type),
      cleanup: "keep"
    });
  });
}
```

### Results Collection
```javascript
// After agents complete, collect and compile results
function compileResults(taskId) {
  // Find all sessions for this task
  const sessions = sessions_list().filter(s => s.label.includes(taskId));
  
  // Collect outputs from each session
  const outputs = sessions.map(session => {
    const history = sessions_history(session.sessionKey);
    return extractOutput(history);
  });
  
  // Compile into summary
  createSummary(taskId, outputs);
}
```

## Best Practices

### 1. Start Small
- Begin with single-agent tasks
- Gradually increase complexity
- Learn which agents work best for your needs

### 2. Clear Instructions
- Be specific about deliverables
- Define success criteria
- Provide context and constraints

### 3. Monitor and Adjust
- Check agent progress
- Adjust instructions if needed
- Keep notes on what works well

### 4. Quality Over Quantity
- Better to have one good experiment than three poor ones
- Focus on actionable results
- Prioritize tasks that will actually inform decisions

### 5. Learn and Iterate
- Track which agents produce best results
- Refine your task decomposition approach
- Improve templates based on experience