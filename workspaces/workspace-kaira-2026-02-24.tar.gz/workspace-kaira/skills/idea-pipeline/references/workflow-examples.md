# Workflow Examples

## Complete Pipeline Examples

### Example 1: Technical Decision - Database Migration

**Day 1 - Idea Capture**
```
User: "PostgreSQL is slow during reports, maybe we should switch?"
→ Task Created: TASK-2026-02-16-001.yaml
```

**Overnight Processing**
```
Cron job triggers at 02:00
Selects TASK-2026-02-16-001 (priority: medium)
Spawns subagents:
1. Research agent: Database comparison research
2. Code agent: Benchmark script creation
3. Analysis agent: Result analysis
```

**Experiments Created**:
- `experiment-01-research.md`: PostgreSQL vs. MySQL vs. CockroachDB comparison
- `experiment-02-benchmark.py`: Performance benchmarking script
- `experiment-03-analysis.md`: Cost and migration complexity analysis

**Results Compiled**:
- `summary.md`: CockroachDB shows 40% better performance
- `aggregated-findings.md`: Migration feasible within 2 weeks

**Day 2 - Morning Review**
```
User reviews results:
- Performance data clear
- Migration plan reasonable
- Cost increase acceptable
Decision: Proceed with migration
```

**Decision Record Created**:
- `DECISION-2026-02-17-001.md`: Migrate to CockroachDB

**Follow-up Tasks Created**:
- `TASK-2026-02-17-001.yaml`: Implement migration plan
- `TASK-2026-02-17-002.yaml`: Update monitoring for new database

---

### Example 2: Product Decision - Feature Implementation

**Day 1 - Idea Capture**
```
User: "We should add dark mode to our web app"
→ Task Created: TASK-2026-02-16-002.yaml
```

**Overnight Processing**
```
Cron job selects TASK-2026-02-16-002
Spawns subagents:
1. Research agent: Dark mode best practices
2. Code agent: CSS prototype creation
3. Analysis agent: Accessibility impact
```

**Experiments Created**:
- `experiment-01-research.md`: Dark mode UX research
- `experiment-02-prototype.css`: CSS custom properties implementation
- `experiment-03-analysis.md`: Accessibility audit results

**Results Compiled**:
- `summary.md`: Prototype ready, minor accessibility issues
- `aggregated-findings.md`: Implementation estimated at 3 days

**Day 2 - Morning Review**
```
User reviews results:
- Prototype looks good
- Accessibility issues manageable
- Timeline acceptable
Decision: Approve implementation
```

**Decision Record Created**:
- `DECISION-2026-02-17-002.md`: Implement dark mode using CSS custom properties

**Follow-up Tasks Created**:
- `TASK-2026-02-17-003.yaml`: Implement dark mode across components
- `TASK-2026-02-17-004.yaml`: Test accessibility compliance

---

### Example 3: Process Decision - Tool Selection

**Day 1 - Idea Capture**
```
User: "We need a better project management tool"
→ Task Created: TASK-2026-02-16-003.yaml
```

**Overnight Processing**
```
Cron job selects TASK-2026-02-16-003
Spawns subagents:
1. Research agent: Tool comparison (Jira, Linear, Asana)
2. Analysis agent: Team workflow analysis
3. Synthesis agent: Recommendation report
```

**Experiments Created**:
- `experiment-01-research.md`: Tool feature comparison
- `experiment-02-analysis.md`: Team workflow mapping
- `experiment-03-synthesis.md`: Recommendation matrix

**Results Compiled**:
- `summary.md`: Linear best fits team needs
- `aggregated-findings.md`: Migration effort 1 week, cost $XX/month

**Day 2 - Morning Review**
```
User reviews results:
- Clear recommendation
- Migration plan detailed
- Cost within budget
Decision: Adopt Linear
```

**Decision Record Created**:
- `DECISION-2026-02-17-003.md`: Migrate to Linear for project management

**Follow-up Tasks Created**:
- `TASK-2026-02-17-005.yaml`: Set up Linear workspace
- `TASK-2026-02-17-006.yaml`: Migrate existing projects

---

## Partial Pipeline Examples

### Example 4: Research-Only Pipeline

**Task**: `TASK-2026-02-16-004.yaml` - "Research blockchain integration options"

**Overnight Processing**:
- Only research subagent spawned
- Focus: Literature review, technology comparison

**Results**: Research summary only, no code or analysis
**Decision**: More research needed → follow-up task created
**Outcome**: Pipeline continues with more focused research task

### Example 5: Quick Decision Pipeline

**Task**: `TASK-2026-02-16-005.yaml` - "Choose library for date formatting"

**Overnight Processing**:
- Light research only (library comparison)
- Simple analysis (bundle size, API quality)

**Results**: Clear winner (date-fns vs. moment.js)
**Decision**: Made immediately from results
**Outcome**: Quick decision, minimal experimentation

## Edge Cases & Variations

### Multiple Iterations
**Scenario**: Complex decision requiring multiple nights of experimentation
**Pattern**:
1. Night 1: Initial research
2. Morning: More data needed → follow-up task
3. Night 2: Deeper analysis
4. Morning: Decision made

**Example**: Evaluating microservices architecture
- Iteration 1: Research patterns
- Iteration 2: Prototype implementation
- Iteration 3: Performance testing

### Parallel Experiments
**Scenario**: Multiple independent aspects to research
**Pattern**: Spawn multiple subagents simultaneously
**Example**: "Evaluate new frontend framework"
- Experiment 1: React vs. Vue performance
- Experiment 2: Developer experience comparison
- Experiment 3: Ecosystem maturity

### Cancelled Pipeline
**Scenario**: Early results show idea is not viable
**Pattern**: Stop pipeline, archive task with reasoning
**Example**: "Implement feature X"
- Research shows patent issues
- Decision: Cancel, archive with legal notes

## Common Patterns

### Pattern 1: Technical Evaluation
```
Idea → Research → Prototype → Benchmark → Decision
```
**Typical for**: Technology choices, architecture decisions

### Pattern 2: Process Improvement
```
Idea → Current state analysis → Best practices research → Proposal → Decision
```
**Typical for**: Workflow changes, tool selection

### Pattern 3: Product Feature
```
Idea → User research → Design exploration → Implementation plan → Decision
```
**Typical for**: New features, UX improvements

### Pattern 4: Strategic Direction
```
Idea → Market analysis → Competitive research → Risk assessment → Decision
```
**Typical for**: Business decisions, partnerships

## Timing Variations

### Quick Turnaround (Same Day)
- Task created morning
- Experiments run during day (not overnight)
- Decision by end of day
- **Use when**: Urgent decisions, simple questions

### Standard Overnight
- Task created any time
- Experiments overnight
- Decision next morning
- **Use when**: Most cases, balanced pace

### Extended Pipeline (Multiple Days)
- Complex task broken into multiple nights
- Progressive refinement
- Decision after sufficient data
- **Use when**: Major decisions, complex research

## Integration with Other Systems

### With Existing Project Management
```
Idea Pipeline → Decision → Jira/Linear ticket created
```

### With Documentation Systems
```
Decision Record → Confluence/Notion page created
```

### With Code Repositories
```
Experiment Code → GitHub/GitLab repository
Decision Record → ADR in docs/decisions/
```

### With Communication Tools
```
Morning Review → Slack/Teams summary posted
Decision → Announcement to relevant channels
```

## Metrics & Measurement

### Pipeline Health Metrics
- **Task completion rate**: % of tasks that reach decision
- **Time to decision**: Average days from task creation to decision
- **Experiment success rate**: % of experiments yielding useful results
- **Decision quality**: Post-implementation success tracking

### Optimization Opportunities
- **Bottleneck identification**: Which phase takes longest?
- **Experiment effectiveness**: Which experiment types yield best results?
- **Subagent performance**: Which agents produce highest quality outputs?
- **Template improvements**: Which template fields are most/least useful?