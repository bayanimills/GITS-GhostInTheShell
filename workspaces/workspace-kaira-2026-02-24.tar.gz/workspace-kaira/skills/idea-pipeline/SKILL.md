---
name: idea-pipeline
description: Manage an idea-to-decision pipeline with task capture, overnight experimentation, and decision recording. Use when you need to: (1) Capture thoughts and ideas as structured tasks throughout the day, (2) Automatically process tasks overnight via cron jobs and subagent experiments, (3) Review results in the morning and make decisions, (4) Create ADR-style decision records with context and alternatives, or (5) Maintain a searchable log directory with templates and naming conventions for all pipeline artifacts.
---

# Idea Pipeline

## Overview

The Idea Pipeline skill implements a systematic idea-to-decision workflow that captures thoughts as tasks, processes them overnight via automated experiments, and produces structured decision records. This system keeps your OpenClaw instance productively engaged while creating an auditable trail of how ideas evolve into decisions.

## Core Components

### 1. Task Capture
- **Format**: Structured YAML/JSON tasks with metadata (priority, context, requirements)
- **Input**: User messages or direct task creation throughout the day
- **Storage**: Tasks stored in `log/tasks/` with timestamped filenames

### 2. Overnight Processing
- **Cron Jobs**: Scheduled execution of task processing
- **Subagent Experiments**: Spawn specialized agents for exploration, research, or prototyping
- **Experiment Types**: Research, code writing, analysis, benchmarking, etc.

### 3. Morning Review
- **Results Compilation**: Aggregated outputs from overnight experiments
- **Decision Points**: User reviews results and chooses: follow-up tasks, more research, or final decision
- **Action Assignment**: New tasks created based on review outcomes

### 4. Decision Recording
- **ADR-style Records**: Architecture Decision Record format adapted for general decisions
- **Context Preservation**: Problem statement, considered alternatives, pros/cons, final decision
- **Artifact Linking**: References to all related tasks, experiments, and results

## Workflow

### Phase 1: Daily Idea Capture
1. **User identifies interesting idea** during normal work
2. **Skill captures idea as task** using template:
   ```yaml
   id: TASK-2026-02-16-001
   created: 2026-02-16T14:30:00Z
   title: "Evaluate alternative database for performance improvements"
   description: "Current PostgreSQL instance showing latency spikes during peak loads"
   priority: medium
   context: "User noticed 2-3 second query times during daily reports"
   requirements: ["benchmark alternatives", "migration complexity", "cost analysis"]
   status: pending
   assigned_to: overnight-processing
   ```
3. **Task stored** in `log/tasks/TASK-2026-02-16-001.yaml`

### Phase 2: Overnight Processing
1. **Cron job triggers** at designated time (e.g., 02:00 local time)
2. **Task selection**: Picks highest priority pending task
3. **Experiment planning**: Determines appropriate subagents and experiments
4. **Subagent spawning**: Creates specialized agents for each experiment type
5. **Execution**: Subagents run experiments, document results
6. **Results compilation**: All outputs aggregated into task results directory

### Phase 3: Morning Review
1. **User reviews** compiled results in `log/tasks/TASK-XXXX/results/`
2. **Decision making**:
   - **More research needed**: Create follow-up tasks
   - **Sufficient information**: Proceed to decision recording
   - **Invalid idea**: Archive task with reasoning
3. **Action assignment**: Update task status and create next steps

### Phase 4: Decision Recording
1. **Create decision record** using ADR template:
   ```markdown
   # Decision Record: [Short Title]
   
   ## Status
   Proposed | Accepted | Deprecated | Superseded
   
   ## Context
   [What problem are we solving? Why is this decision needed?]
   
   ## Considered Alternatives
   - [Alternative 1]
   - [Alternative 2]
   - [Alternative 3]
   
   ## Decision
   [Chosen alternative and rationale]
   
   ## Consequences
   [What becomes easier/harder? What changes?]
   
   ## References
   - Related tasks: [TASK-IDs]
   - Experiment results: [Paths to results]
   - Additional context: [Links, documents]
   ```
2. **Store decision** in `log/decisions/DECISION-YYYY-MM-DD-NNN.md`
3. **Update task status** to "decided" with decision reference

## Directory Structure & Templates

### Recommended Structure
```
log/
├── tasks/
│   ├── TASK-2026-02-16-001.yaml
│   ├── TASK-2026-02-16-002.yaml
│   └── TASK-2026-02-16-001/
│       ├── experiments/
│       │   ├── experiment-01-research.md
│       │   ├── experiment-02-benchmark.py
│       │   └── experiment-03-analysis.md
│       └── results/
│           ├── summary.md
│           └── aggregated-findings.md
├── decisions/
│   ├── DECISION-2026-02-17-001.md
│   └── DECISION-2026-02-18-001.md
├── templates/
│   ├── task-template.yaml
│   ├── decision-template.md
│   └── experiment-plan.md
└── archive/
    ├── completed-tasks/
    └── superseded-decisions/
```

### File Naming Conventions
- **Tasks**: `TASK-YYYY-MM-DD-NNN.yaml` (NNN = sequential number per day)
- **Decisions**: `DECISION-YYYY-MM-DD-NNN.md`
- **Experiments**: `experiment-NN-[type]-[description].ext`
- **Results**: `results-[date]-[summary].md`

## Cron Job Setup

### Basic Cron Configuration
Create a cron job that triggers the overnight processing:

```bash
# Example: Run daily at 2 AM
0 2 * * * /path/to/openclaw/workspace/scripts/process-pending-tasks.sh
```

### Using OpenClaw Cron Tool
```javascript
// Example cron job using OpenClaw's cron tool
{
  "schedule": { "kind": "cron", "expr": "0 2 * * *", "tz": "UTC" },
  "payload": {
    "kind": "agentTurn",
    "message": "Process pending tasks in idea pipeline. Check log/tasks/ for tasks with status=pending, select highest priority, spawn appropriate experiments."
  },
  "sessionTarget": "isolated",
  "delivery": { "mode": "announce" }
}
```

## Subagent Experimentation

### Experiment Types
1. **Research Agent**: Literature review, competitor analysis, best practices
2. **Code Agent**: Prototype development, script writing, implementation testing
3. **Analysis Agent**: Data processing, benchmarking, performance evaluation
4. **Synthesis Agent**: Result aggregation, report generation, recommendation drafting

### Spawning Subagents
```javascript
// Example: Spawn research subagent
sessions_spawn({
  task: "Research database alternatives for performance comparison. Focus on: 1. PostgreSQL vs. MySQL vs. CockroachDB 2. Benchmark results for read-heavy workloads 3. Migration complexity and tools 4. Cost analysis for our scale.",
  label: "database-research-TASK-2026-02-16-001",
  agentId: "scientist", // Or appropriate research-focused agent
  model: "gpt-4",
  cleanup: "keep"
});
```

## Decision Recording

### ADR Template (Adapted)
See `assets/decision-template.md` for complete template.

### Key Elements
1. **Status Tracking**: Proposed → Accepted → Deprecated → Superseded
2. **Context Preservation**: Why this decision was needed, constraints, goals
3. **Alternatives Considered**: All options evaluated with pros/cons
4. **Decision Rationale**: Why this alternative was chosen
5. **Consequences**: Impact on system, team, processes
6. **References**: Links to tasks, experiments, related decisions

## Search & Querying

### Complex Search Expressions
The structured directory and naming conventions enable powerful searches:

```bash
# Find all tasks related to database performance
find log/tasks/ -name "*.yaml" -exec grep -l "database\|performance\|PostgreSQL" {} \;

# Find decisions made in the last 7 days
find log/decisions/ -name "DECISION-$(date +%Y-%m-%d)*.md" -o -name "DECISION-$(date -d '7 days ago' +%Y-%m-%d)*.md"

# Find experiments with benchmark results
find log/tasks/ -path "*/experiments/*" -name "*benchmark*" -type f

# Aggregate all decisions with status "accepted"
grep -r "Status.*Accepted" log/decisions/ --include="*.md"
```

### Agent Search Patterns
```javascript
// Example: Agent searching for related decisions before making recommendation
const searchQuery = "database migration performance";
const relatedDecisions = exec(`find log/decisions/ -name "*.md" -exec grep -l "${searchQuery}" {} \\;`);
```

## Examples

### Example 1: Database Evaluation
**User idea**: "PostgreSQL is slow during reports, maybe we should switch?"

**Task created**: `TASK-2026-02-16-001.yaml`
**Overnight experiments**:
1. Research agent compares PostgreSQL, MySQL, CockroachDB
2. Code agent writes benchmark script
3. Analysis agent runs benchmarks on sample data

**Morning review**: User sees benchmark results showing CockroachDB 40% faster
**Decision recorded**: `DECISION-2026-02-17-001.md` - Migrate to CockroachDB

### Example 2: Feature Implementation
**User idea**: "Add dark mode to our web app"

**Task created**: `TASK-2026-02-16-002.yaml`
**Overnight experiments**:
1. Research agent finds best practices for dark mode implementation
2. Code agent creates CSS prototype
3. Analysis agent evaluates accessibility impact

**Morning review**: User approves prototype, creates follow-up task for implementation
**Decision recorded**: `DECISION-2026-02-17-002.md` - Implement dark mode using CSS custom properties

## Resources

### assets/
- `task-template.yaml` - Standard template for task creation
- `decision-template.md` - ADR-style decision record template
- `experiment-plan.md` - Template for planning subagent experiments
- `directory-structure.md` - Recommended directory layout

### references/
- `workflow-examples.md` - Detailed examples of complete workflow cycles
- `subagent-guides.md` - Guidance on selecting and spawning appropriate subagents
- `search-patterns.md` - Advanced search expressions for the log directory

### scripts/
- `process-tasks.py` - Python script for automated task processing
- `generate-report.py` - Results aggregation and report generation
- `search-log.py` - Advanced search utility for the pipeline

## Getting Started

1. **Initialize directory structure** using `assets/directory-structure.md` as guide
2. **Set up cron job** for overnight processing (see Cron Job Setup section)
3. **Start capturing ideas** using `task-template.yaml`
4. **Review morning results** and create decisions using `decision-template.md`
5. **Refine workflow** based on your specific needs and patterns

## Notes

- **Flexibility**: Adapt templates and structure to your specific use cases
- **Integration**: Works alongside other skills (research, coding, analysis)
- **Evolution**: The pipeline improves as you refine what types of experiments yield the best results
- **Auditability**: Complete trail from initial idea to final decision with all intermediate work
