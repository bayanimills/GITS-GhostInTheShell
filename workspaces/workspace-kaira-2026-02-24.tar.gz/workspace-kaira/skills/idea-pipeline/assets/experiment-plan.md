# Experiment Plan: {{Experiment Title}}

## Basic Information
**Experiment ID**: EXP-{{task-id}}-{{seq}}
**Related Task**: {{TASK-ID}}
**Experiment Type**: research|code|analysis|synthesis|prototype  <!-- Choose one -->
**Assigned To**: {{subagent type or specific agent}}
**Priority**: high|medium|low
**Estimated Duration**: {{hours}} hours
**Deadline**: {{timestamp}}

## Objective
<!-- What specific question or hypothesis does this experiment address? -->

**Primary Question**: {{What we're trying to learn or prove}}

**Success Criteria**:
- {{Criterion 1}}
- {{Criterion 2}}
- {{Criterion 3}}

## Methodology

### Approach
{{Describe the overall approach: research methodology, coding approach, analysis technique, etc.}}

### Steps
1. {{Step 1}}
2. {{Step 2}}
3. {{Step 3}}
4. {{Step 4}}

### Tools & Resources
- **Primary Tools**: {{Tool 1}}, {{Tool 2}}, {{Tool 3}}
- **Data Sources**: {{Source 1}}, {{Source 2}}
- **Reference Materials**: {{Document 1}}, {{Document 2}}
- **Dependencies**: {{Dependency 1}}, {{Dependency 2}}

## Output Specifications

### Deliverables
- [ ] **Primary Report**: {{Report filename and format}}
- [ ] **Supporting Data**: {{Data files or analysis}}
- [ ] **Code/Artifacts**: {{Code files, prototypes, etc.}}
- [ ] **Recommendations**: {{Actionable recommendations}}

### Format Requirements
- **Report Structure**: Introduction, Methodology, Findings, Conclusions, Recommendations
- **Data Format**: {{CSV, JSON, YAML, etc.}}
- **Code Requirements**: {{Documentation, tests, etc.}}

## Constraints & Limitations

### Known Limitations
- {{Limitation 1}}
- {{Limitation 2}}
- {{Limitation 3}}

### Assumptions
- {{Assumption 1}}
- {{Assumption 2}}
- {{Assumption 3}}

### Risks & Mitigations
| Risk | Probability | Impact | Mitigation Strategy |
|------|-------------|--------|---------------------|
| {{Risk 1}} | Low/Medium/High | Low/Medium/High | {{Mitigation}} |
| {{Risk 2}} | Low/Medium/High | Low/Medium/High | {{Mitigation}} |
| {{Risk 3}} | Low/Medium/High | Low/Medium/High | {{Mitigation}} |

## Evaluation

### How to Evaluate Results
{{What constitutes good vs. bad results? How to interpret findings?}}

### Decision Points
{{What decisions might need to be made based on results?}}

## Notes
{{Any additional notes, context, or special instructions}}

---
# Example Experiment Plan (remove in actual use)

# Experiment Plan: Database Performance Benchmarking

## Basic Information
**Experiment ID**: EXP-TASK-2026-02-16-001-01
**Related Task**: TASK-2026-02-16-001
**Experiment Type**: code
**Assigned To**: code-agent
**Priority**: high
**Estimated Duration**: 4 hours
**Deadline**: 2026-02-17T06:00:00Z

## Objective

**Primary Question**: How do PostgreSQL, MySQL, and CockroachDB perform for our specific read-heavy workload?

**Success Criteria**:
1. Benchmark script successfully runs against all three databases
2. Performance metrics collected for key query patterns
3. Clear comparison data showing relative performance
4. Identified bottlenecks or optimization opportunities

## Methodology

### Approach
Create a reproducible benchmark script that simulates our production query patterns, run it against identical instances of each database, and collect performance metrics.

### Steps
1. Analyze production query patterns to identify representative workload
2. Create benchmark script with 5 key query types
3. Set up identical test instances for each database
4. Run benchmark with increasing concurrent users (1, 10, 50, 100)
5. Collect metrics: query latency, throughput, resource utilization
6. Analyze results and identify performance characteristics

### Tools & Resources
- **Primary Tools**: Python, psycopg2, mysql-connector, sqlalchemy
- **Data Sources**: Production query logs (anonymized)
- **Reference Materials**: Database documentation, previous benchmark studies
- **Dependencies**: Docker for database instances, monitoring tools

## Output Specifications

### Deliverables
- [ ] **Primary Report**: `benchmark-results.md` with analysis and recommendations
- [ ] **Supporting Data**: `benchmark-data.csv` with raw metrics
- [ ] **Code/Artifacts**: `benchmark.py` script, `docker-compose.yml` setup
- [ ] **Recommendations**: Clear guidance on database selection

### Format Requirements
- **Report Structure**: Executive summary, methodology, results, analysis, recommendations
- **Data Format**: CSV with columns: database, query_type, concurrency, latency_p50, latency_p95, throughput
- **Code Requirements**: Well-documented, parameterized, reproducible

## Constraints & Limitations

### Known Limitations
- Test data size smaller than production (10% scale)
- Network latency differences in test environment
- Simplified workload simulation

### Assumptions
- Performance characteristics scale proportionally
- Test environment representative of production
- No database-specific optimizations applied

### Risks & Mitigations
| Risk | Probability | Impact | Mitigation Strategy |
|------|-------------|--------|---------------------|
| Benchmark not representative | Medium | High | Validate with production team, include diverse query patterns |
| Database setup issues | High | Medium | Use containerized setup, document setup steps |
| Insufficient test data | Medium | Medium | Generate synthetic data matching production distribution |

## Evaluation

### How to Evaluate Results
- Good: Clear performance differences (>20%) between databases
- Bad: Inconclusive results (<10% difference) or setup failures
- Concerning: Performance worse than expected across all databases

### Decision Points
- If one database clearly outperforms: recommend migration
- If results inconclusive: recommend additional experiments
- If all perform poorly: recommend architectural changes

## Notes
Focus on read-heavy workload simulation. Include both simple queries (point lookups) and complex queries (joins, aggregations). Ensure benchmark is fair by using equivalent configurations for all databases.