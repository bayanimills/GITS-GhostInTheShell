# Idea Pipeline Directory Structure

## Recommended Layout
```
log/                                   # Root directory for the pipeline
├── tasks/                             # All task definitions
│   ├── TASK-2026-02-16-001.yaml      # Task definition (YAML)
│   ├── TASK-2026-02-16-002.yaml
│   └── TASK-2026-02-16-001/          # Task work directory (created when processing starts)
│       ├── experiments/               # Individual experiment artifacts
│       │   ├── experiment-01-research.md
│       │   ├── experiment-02-benchmark.py
│       │   └── experiment-03-analysis.md
│       └── results/                   # Compiled results
│           ├── summary.md
│           ├── aggregated-findings.md
│           └── data/                  # Supporting data files
│               ├── benchmark-results.csv
│               └── analysis-output.json
├── decisions/                         # All decision records
│   ├── DECISION-2026-02-17-001.md
│   └── DECISION-2026-02-18-001.md
├── templates/                         # Template files (copied from assets)
│   ├── task-template.yaml
│   ├── decision-template.md
│   └── experiment-plan.md
├── archive/                           # Archived/completed items
│   ├── completed-tasks/
│   │   ├── TASK-2026-01-15-001.yaml
│   │   └── TASK-2026-01-15-001/
│   └── superseded-decisions/
│       └── DECISION-2026-01-10-001.md
└── README.md                          # Pipeline documentation
```

## Naming Conventions

### Tasks
- **Definition files**: `TASK-YYYY-MM-DD-NNN.yaml`
  - `YYYY-MM-DD`: Date task was created
  - `NNN`: Sequential number starting at 001 for each day
  - Example: `TASK-2026-02-16-001.yaml`
- **Task directories**: Same name as definition file (without extension)
  - Created when task processing begins
  - Example: `TASK-2026-02-16-001/`

### Decisions
- **Decision records**: `DECISION-YYYY-MM-DD-NNN.md`
  - `YYYY-MM-DD`: Date decision was made
  - `NNN`: Sequential number starting at 001 for each day
  - Example: `DECISION-2026-02-17-001.md`

### Experiments
- **Experiment files**: `experiment-NN-[type]-[description].[ext]`
  - `NN`: Two-digit sequential number (01, 02, 03, etc.)
  - `[type]`: Experiment type (research, code, analysis, synthesis, prototype)
  - `[description]`: Brief descriptive name (kebab-case)
  - `[ext]`: Appropriate file extension
  - Examples:
    - `experiment-01-research.md`
    - `experiment-02-benchmark.py`
    - `experiment-03-analysis.md`

### Results
- **Summary files**: `summary.md` (always this name, in results directory)
- **Aggregated findings**: `aggregated-findings.md`
- **Data files**: Descriptive names in `data/` subdirectory
  - Examples: `benchmark-results.csv`, `user-feedback.json`, `cost-analysis.yaml`

## File Formats

### Task Definitions (YAML)
```yaml
id: TASK-2026-02-16-001
created: 2026-02-16T14:30:00Z
title: "Descriptive title"
description: |
  Multi-line description with context
  and requirements.
priority: medium
status: pending
# ... additional fields
```

### Decision Records (Markdown)
- Markdown with YAML frontmatter optional
- Structured sections: Context, Alternatives, Decision, Consequences
- Include metadata at bottom

### Experiment Files
- Type-appropriate formats:
  - **Research**: Markdown with citations
  - **Code**: Appropriate language (Python, JavaScript, etc.)
  - **Analysis**: Markdown with embedded data or separate data files
  - **Prototypes**: Project-appropriate structure

## Directory Creation Rules

### When Task is Created
1. Create `tasks/TASK-YYYY-MM-DD-NNN.yaml` file
2. Do NOT create task directory yet (wait for processing)

### When Task Processing Begins
1. Create directory `tasks/TASK-YYYY-MM-DD-NNN/`
2. Create subdirectories:
   - `experiments/` for individual experiment artifacts
   - `results/` for compiled outputs

### When Decision is Made
1. Create `decisions/DECISION-YYYY-MM-DD-NNN.md`
2. Update task status to "decided"
3. Move task directory to archive if complete

## Search Optimization

The naming conventions enable powerful search patterns:

```bash
# Find all tasks from specific date
find log/tasks/ -name "TASK-2026-02-16-*.yaml"

# Find all experiments of specific type
find log/tasks/ -path "*/experiments/*" -name "*research*" -type f

# Find decisions related to specific topic
grep -r "database" log/decisions/ --include="*.md"

# Find tasks with specific status
grep -l "status: pending" log/tasks/*.yaml

# Find all files modified in last 7 days
find log/ -type f -mtime -7
```

## Initial Setup Commands

```bash
# Create the directory structure
mkdir -p log/{tasks,decisions,templates,archive/{completed-tasks,superseded-decisions}}

# Copy templates from skill assets
cp /path/to/skill/assets/*.yaml log/templates/
cp /path/to/skill/assets/*.md log/templates/

# Create README
cat > log/README.md << 'EOF'
# Idea Pipeline Log

This directory contains all artifacts for the idea-to-decision pipeline.

## Structure
- `tasks/`: Task definitions and work directories
- `decisions/`: Decision records (ADR format)
- `templates/`: Template files for creating new items
- `archive/`: Completed and superseded items

See directory-structure.md for detailed conventions.
EOF
```

## Maintenance

### Regular Cleanup
- Move completed tasks to `archive/completed-tasks/` after decision
- Move superseded decisions to `archive/superseded-decisions/`
- Compress old archive directories if space is concern

### Backups
- Include `log/` directory in regular backups
- Consider version control for decision history
- Export important decisions to knowledge base

### Statistics Generation
```bash
# Count tasks by status
grep -h "status:" log/tasks/*.yaml | sort | uniq -c

# Count decisions by month
ls log/decisions/DECISION-*.md | cut -d- -f2-3 | sort | uniq -c

# Average time from task creation to decision
# (Requires timestamp parsing script)
```

## Customization Notes

- Adjust naming conventions to match your workflow
- Add additional subdirectories as needed (e.g., `meetings/`, `references/`)
- Integrate with existing project structures
- Consider symlinks for cross-referencing across projects