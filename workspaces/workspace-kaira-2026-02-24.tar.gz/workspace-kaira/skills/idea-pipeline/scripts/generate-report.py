#!/usr/bin/env python3
"""
Generate summary reports for idea pipeline tasks.

This script compiles experiment results into a cohesive summary
for morning review. It:
1. Finds tasks with completed experiments
2. Aggregates findings from all experiment files
3. Generates summary.md and aggregated-findings.md
4. Identifies key insights and recommendations
"""

import os
import sys
import yaml
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

class ReportGenerator:
    def __init__(self, log_dir: str = "log"):
        self.log_dir = Path(log_dir)
        self.tasks_dir = self.log_dir / "tasks"
    
    def find_tasks_with_results(self) -> List[Path]:
        """Find tasks that have experiment results"""
        tasks_with_results = []
        
        for task_dir in self.tasks_dir.glob("TASK-*/"):
            if self.has_experiment_results(task_dir):
                tasks_with_results.append(task_dir)
        
        return tasks_with_results
    
    def has_experiment_results(self, task_dir: Path) -> bool:
        """Check if task has any experiment results"""
        experiments_dir = task_dir / "experiments"
        if not experiments_dir.exists():
            return False
        
        # Check for any markdown files (excluding instruction files)
        for file in experiments_dir.glob("*.md"):
            if not file.name.endswith("-instructions.md"):
                return True
        
        return False
    
    def load_task_definition(self, task_dir: Path) -> Optional[Dict]:
        """Load task definition YAML"""
        task_id = task_dir.name
        task_file = self.tasks_dir / f"{task_id}.yaml"
        
        if not task_file.exists():
            return None
        
        try:
            with open(task_file) as f:
                return yaml.safe_load(f)
        except yaml.YAMLError as e:
            print(f"Error loading task definition {task_file}: {e}")
            return None
    
    def collect_experiment_results(self, task_dir: Path) -> List[Dict]:
        """Collect and parse all experiment results"""
        experiments = []
        experiments_dir = task_dir / "experiments"
        
        if not experiments_dir.exists():
            return experiments
        
        # Pattern to extract experiment metadata from filename
        pattern = r'experiment-(\d+)-([a-zA-Z]+)-(.*?)\.md'
        
        for exp_file in experiments_dir.glob("*.md"):
            if exp_file.name.endswith("-instructions.md"):
                continue
            
            match = re.match(pattern, exp_file.name)
            if match:
                exp_num, exp_type, exp_desc = match.groups()
                exp_desc = exp_desc.replace('-', ' ').title()
            else:
                # Fallback parsing
                exp_num = "01"
                exp_type = "unknown"
                exp_desc = exp_file.stem
            
            try:
                with open(exp_file) as f:
                    content = f.read()
                
                # Extract key sections
                title = self.extract_title(content)
                summary = self.extract_summary(content)
                findings = self.extract_findings(content)
                recommendations = self.extract_recommendations(content)
                
                experiments.append({
                    'file': exp_file,
                    'number': exp_num,
                    'type': exp_type,
                    'description': exp_desc,
                    'title': title,
                    'summary': summary,
                    'findings': findings,
                    'recommendations': recommendations,
                    'content': content
                })
                
            except (FileNotFoundError, UnicodeDecodeError) as e:
                print(f"Error reading experiment file {exp_file}: {e}")
                continue
        
        return experiments
    
    def extract_title(self, content: str) -> str:
        """Extract title from markdown content"""
        # Look for first H1 or H2
        lines = content.split('\n')
        for line in lines:
            if line.startswith('# '):
                return line[2:].strip()
            elif line.startswith('## '):
                return line[3:].strip()
        
        return "Untitled Experiment"
    
    def extract_summary(self, content: str) -> str:
        """Extract summary section"""
        # Look for summary section or first paragraph
        lines = content.split('\n')
        summary_lines = []
        in_summary = False
        
        for i, line in enumerate(lines):
            if line.lower().startswith('# summary') or line.lower().startswith('## summary'):
                in_summary = True
                continue
            elif in_summary and line.startswith('#') and not line.startswith('###'):
                break
            elif in_summary and line.strip():
                summary_lines.append(line)
        
        if summary_lines:
            return '\n'.join(summary_lines)
        
        # Fallback: first paragraph after title
        for i, line in enumerate(lines):
            if line.startswith('#') and i + 1 < len(lines):
                next_line = lines[i + 1]
                if next_line.strip() and not next_line.startswith('#'):
                    return next_line.strip()
        
        return "No summary available"
    
    def extract_findings(self, content: str) -> List[str]:
        """Extract key findings"""
        findings = []
        
        # Look for findings section or bullet points
        lines = content.split('\n')
        in_findings = False
        
        for line in lines:
            if line.lower().startswith('## findings') or line.lower().startswith('### findings'):
                in_findings = True
                continue
            elif in_findings and line.startswith('##') and not line.startswith('###'):
                break
            elif in_findings and line.strip():
                # Extract bullet points
                if line.strip().startswith('- ') or line.strip().startswith('* '):
                    findings.append(line.strip()[2:])
                elif line.strip().startswith('1. '):
                    findings.append(line.strip()[3:])
        
        return findings
    
    def extract_recommendations(self, content: str) -> List[str]:
        """Extract recommendations"""
        recommendations = []
        
        # Look for recommendations section
        lines = content.split('\n')
        in_recommendations = False
        
        for line in lines:
            lower_line = line.lower()
            if 'recommendation' in lower_line and (lower_line.startswith('## ') or lower_line.startswith('### ')):
                in_recommendations = True
                continue
            elif in_recommendations and line.startswith('##') and not line.startswith('###'):
                break
            elif in_recommendations and line.strip():
                if line.strip().startswith('- ') or line.strip().startswith('* '):
                    recommendations.append(line.strip()[2:])
                elif line.strip().startswith('1. '):
                    recommendations.append(line.strip()[3:])
        
        return recommendations
    
    def generate_summary(self, task_data: Dict, experiments: List[Dict]) -> str:
        """Generate executive summary"""
        task_id = task_data['id']
        task_title = task_data['title']
        
        summary = f"# Summary: {task_title}\n\n"
        summary += f"**Task ID**: {task_id}\n"
        summary += f"**Generated**: {datetime.now().isoformat()}\n"
        summary += f"**Experiments Completed**: {len(experiments)}\n\n"
        
        # Executive summary
        summary += "## Executive Summary\n\n"
        
        if experiments:
            # Combine experiment summaries
            combined_summary = ""
            for exp in experiments:
                if exp['summary'] and exp['summary'] != "No summary available":
                    combined_summary += f"- **{exp['description']}**: {exp['summary']}\n"
            
            if combined_summary:
                summary += combined_summary + "\n"
            else:
                summary += "Experiment summaries not available. See detailed findings below.\n\n"
        else:
            summary += "No experiment results available.\n\n"
        
        # Key Findings
        all_findings = []
        for exp in experiments:
            all_findings.extend(exp['findings'])
        
        if all_findings:
            summary += "## Key Findings\n\n"
            for finding in all_findings[:10]:  # Limit to top 10
                summary += f"- {finding}\n"
            summary += "\n"
        
        # Recommendations
        all_recommendations = []
        for exp in experiments:
            all_recommendations.extend(exp['recommendations'])
        
        if all_recommendations:
            summary += "## Recommendations\n\n"
            for i, rec in enumerate(all_recommendations[:5], 1):  # Limit to top 5
                summary += f"{i}. {rec}\n"
            summary += "\n"
        
        # Next Steps
        summary += "## Next Steps\n\n"
        summary += "1. **Review detailed findings** in aggregated-findings.md\n"
        summary += "2. **Make decision** based on evidence\n"
        summary += "3. **Create decision record** if proceeding\n"
        summary += "4. **Create follow-up tasks** as needed\n\n"
        
        # Experiment Status
        summary += "## Experiment Status\n\n"
        for exp in experiments:
            status = "✅ Completed" if exp['content'].strip() else "⏳ In Progress"
            summary += f"- **{exp['description']}** ({exp['type']}): {status}\n"
        
        return summary
    
    def generate_aggregated_findings(self, task_data: Dict, experiments: List[Dict]) -> str:
        """Generate detailed aggregated findings"""
        task_id = task_data['id']
        task_title = task_data['title']
        
        report = f"# Aggregated Findings: {task_title}\n\n"
        report += f"**Task ID**: {task_id}\n"
        report += f"**Generated**: {datetime.now().isoformat()}\n\n"
        
        # Task Context
        report += "## Task Context\n\n"
        report += f"**Title**: {task_title}\n\n"
        report += f"**Description**:\n{task_data.get('description', 'No description')}\n\n"
        
        if task_data.get('requirements'):
            report += "**Requirements**:\n"
            for req in task_data['requirements']:
                report += f"- {req}\n"
            report += "\n"
        
        # Experiment Details
        report += "## Experiment Details\n\n"
        
        for exp in experiments:
            report += f"### Experiment {exp['number']}: {exp['description']}\n\n"
            report += f"**Type**: {exp['type'].title()}\n"
            report += f"**File**: {exp['file'].name}\n\n"
            
            if exp['summary'] and exp['summary'] != "No summary available":
                report += "**Summary**:\n"
                report += f"{exp['summary']}\n\n"
            
            if exp['findings']:
                report += "**Key Findings**:\n"
                for finding in exp['findings']:
                    report += f"- {finding}\n"
                report += "\n"
            
            if exp['recommendations']:
                report += "**Recommendations**:\n"
                for rec in exp['recommendations']:
                    report += f"- {rec}\n"
                report += "\n"
            
            report += "---\n\n"
        
        # Cross-Experiment Analysis
        report += "## Cross-Experiment Analysis\n\n"
        
        # Group findings by theme
        themes = self.identify_themes(experiments)
        if themes:
            for theme, findings in themes.items():
                report += f"### {theme}\n\n"
                for finding in findings:
                    report += f"- {finding}\n"
                report += "\n"
        else:
            report += "No common themes identified across experiments.\n\n"
        
        # Contradictions or Gaps
        contradictions = self.identify_contradictions(experiments)
        if contradictions:
            report += "## Contradictions or Knowledge Gaps\n\n"
            for contradiction in contradictions:
                report += f"- {contradiction}\n"
            report += "\n"
        
        # Overall Assessment
        report += "## Overall Assessment\n\n"
        
        if experiments:
            report += "Based on the available evidence:\n\n"
            
            # Determine confidence level
            total_findings = sum(len(exp['findings']) for exp in experiments)
            if total_findings >= 10:
                report += "**High confidence**: Multiple experiments with substantial findings.\n"
            elif total_findings >= 5:
                report += "**Medium confidence**: Some evidence available but limited.\n"
            else:
                report += "**Low confidence**: Insufficient evidence for strong conclusions.\n"
            
            report += "\n"
            
            # Decision readiness
            if total_findings >= 5 and any(exp['recommendations'] for exp in experiments):
                report += "**Decision Ready**: Sufficient evidence for informed decision.\n"
            else:
                report += "**More Research Needed**: Additional experiments required.\n"
        else:
            report += "No evidence available for assessment.\n"
        
        report += "\n"
        
        # References
        report += "## References\n\n"
        for exp in experiments:
            report += f"- [{exp['file'].name}]({exp['file'].relative_to(self.tasks_dir)})\n"
        
        return report
    
    def identify_themes(self, experiments: List[Dict]) -> Dict[str, List[str]]:
        """Identify common themes across experiments"""
        themes = {}
        
        # Simple keyword-based theme identification
        common_themes = {
            'performance': ['fast', 'slow', 'speed', 'latency', 'throughput', 'benchmark'],
            'cost': ['expensive', 'cheap', 'cost', 'price', 'budget', 'affordable'],
            'complexity': ['simple', 'complex', 'easy', 'hard', 'difficult', 'straightforward'],
            'reliability': ['reliable', 'stable', 'crash', 'error', 'bug', 'robust'],
            'scalability': ['scale', 'grow', 'large', 'small', 'capacity', 'limit']
        }
        
        for exp in experiments:
            content_lower = exp['content'].lower()
            for theme, keywords in common_themes.items():
                if any(keyword in content_lower for keyword in keywords):
                    if theme not in themes:
                        themes[theme] = []
                    themes[theme].extend(exp['findings'])
        
        # Deduplicate findings within themes
        for theme in themes:
            themes[theme] = list(set(themes[theme]))
        
        return themes
    
    def identify_contradictions(self, experiments: List[Dict]) -> List[str]:
        """Identify contradictions between experiments"""
        contradictions = []
        
        if len(experiments) < 2:
            return contradictions
        
        # Simple contradiction detection based on keywords
        # In a real implementation, this would use more sophisticated NLP
        for i, exp1 in enumerate(experiments):
            for exp2 in experiments[i+1:]:
                content1 = exp1['content'].lower()
                content2 = exp2['content'].lower()
                
                # Check for contradictory statements
                contradictory_pairs = [
                    ('fast', 'slow'),
                    ('expensive', 'cheap'),
                    ('easy', 'difficult'),
                    ('reliable', 'unreliable'),
                    ('scalable', 'limited')
                ]
                
                for term1, term2 in contradictory_pairs:
                    if term1 in content1 and term2 in content2:
                        contradictions.append(
                            f"Experiment {exp1['number']} mentions '{term1}' while "
                            f"Experiment {exp2['number']} mentions '{term2}'"
                        )
                    elif term2 in content1 and term1 in content2:
                        contradictions.append(
                            f"Experiment {exp1['number']} mentions '{term2}' while "
                            f"Experiment {exp2['number']} mentions '{term1}'"
                        )
        
        return contradictions
    
    def generate_reports(self, task_dir: Path) -> bool:
        """Generate all reports for a task"""
        task_data = self.load_task_definition(task_dir)
        if not task_data:
            print(f"No task definition found for {task_dir.name}")
            return False
        
        experiments = self.collect_experiment_results(task_dir)
        if not experiments:
            print(f"No experiment results found for {task_dir.name}")
            return False
        
        print(f"Generating reports for {task_dir.name} ({len(experiments)} experiments)")
        
        # Generate summary
        summary_content = self.generate_summary(task_data, experiments)
        summary_file = task_dir / "results" / "summary.md"
        summary_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(summary_file, 'w') as f:
            f.write(summary_content)
        
        print(f"Created summary: {summary_file}")
        
        # Generate aggregated findings
        aggregated_content = self.generate_aggregated_findings(task_data, experiments)
        aggregated_file = task_dir / "results" / "aggregated-findings.md"
        
        with open(aggregated_file, 'w') as f:
            f.write(aggregated_content)
        
        print(f"Created aggregated findings: {aggregated_file}")
        
        return True
    
    def generate_all_reports(self):
        """Generate reports for all tasks with results"""
        tasks = self.find_tasks_with_results()
        
        if not tasks:
            print("No tasks with experiment results found")
            return False
        
        print(f"Found {len(tasks)} tasks with results")
        
        success_count = 0
        for task_dir in tasks:
            if self.generate_reports(task_dir):
                success_count += 1
        
        print(f"Generated reports for {success_count}/{len(tasks)} tasks")
        return success_count > 0

def main():
    """Main entry point"""
    log_dir = os.environ.get('IDEA_PIPELINE_LOG_DIR', 'log')
    
    generator = ReportGenerator(log_dir)
    success = generator.generate_all_reports()
    
    if success:
        print("Report generation completed successfully")
        sys.exit(0)
    else:
        print("Report generation completed with errors or no tasks to process")
        sys.exit(1)

if __name__ == "__main__":
    main()