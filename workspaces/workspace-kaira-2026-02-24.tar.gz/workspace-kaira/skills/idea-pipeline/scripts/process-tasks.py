#!/usr/bin/env python3
"""
Process pending tasks for idea pipeline.

This script is designed to be run by cron jobs for overnight processing.
It:
1. Finds pending tasks in log/tasks/
2. Selects highest priority task
3. Creates task directory and experiment plans
4. Spawns appropriate subagents for experiments
5. Updates task status to 'processing'

Environment variables needed:
- OPENCLAW_SESSION_KEY (if running within OpenClaw)
- Optional: Specific agent IDs for different experiment types
"""

import os
import sys
import yaml
import json
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

# Add parent directory to path for imports if needed
sys.path.insert(0, str(Path(__file__).parent.parent))

class TaskProcessor:
    def __init__(self, log_dir: str = "log"):
        self.log_dir = Path(log_dir)
        self.tasks_dir = self.log_dir / "tasks"
        self.ensure_directories()
    
    def ensure_directories(self):
        """Ensure required directories exist"""
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        (self.log_dir / "decisions").mkdir(parents=True, exist_ok=True)
        (self.log_dir / "templates").mkdir(parents=True, exist_ok=True)
        (self.log_dir / "archive").mkdir(parents=True, exist_ok=True)
    
    def find_pending_tasks(self) -> List[Path]:
        """Find all task files with status: pending"""
        pending_tasks = []
        for task_file in self.tasks_dir.glob("TASK-*.yaml"):
            try:
                with open(task_file) as f:
                    task_data = yaml.safe_load(f)
                    if task_data.get('status') == 'pending':
                        pending_tasks.append(task_file)
            except (yaml.YAMLError, FileNotFoundError) as e:
                print(f"Error reading {task_file}: {e}")
                continue
        return pending_tasks
    
    def select_task(self, tasks: List[Path]) -> Optional[Path]:
        """Select highest priority task from list"""
        if not tasks:
            return None
        
        # Score tasks by priority
        priority_scores = {'high': 3, 'medium': 2, 'low': 1}
        scored_tasks = []
        
        for task_file in tasks:
            try:
                with open(task_file) as f:
                    task_data = yaml.safe_load(f)
                    priority = task_data.get('priority', 'medium')
                    score = priority_scores.get(priority, 2)
                    
                    # Add age factor (older tasks get slight boost)
                    created_str = task_data.get('created', '')
                    if created_str:
                        try:
                            created = datetime.fromisoformat(created_str.replace('Z', '+00:00'))
                            age_days = (datetime.now() - created).days
                            score += min(age_days * 0.1, 1)  # Max 1 point for age
                        except ValueError:
                            pass
                    
                    scored_tasks.append((score, task_file, task_data))
            except (yaml.YAMLError, FileNotFoundError):
                continue
        
        if not scored_tasks:
            return None
        
        # Select highest scoring task
        scored_tasks.sort(key=lambda x: x[0], reverse=True)
        return scored_tasks[0][1]
    
    def create_task_directory(self, task_file: Path, task_data: Dict) -> Path:
        """Create task work directory and subdirectories"""
        task_id = task_file.stem
        task_dir = self.tasks_dir / task_id
        
        if not task_dir.exists():
            task_dir.mkdir(parents=True, exist_ok=True)
            (task_dir / "experiments").mkdir(exist_ok=True)
            (task_dir / "results").mkdir(exist_ok=True)
            (task_dir / "results" / "data").mkdir(exist_ok=True)
            print(f"Created task directory: {task_dir}")
        
        return task_dir
    
    def plan_experiments(self, task_data: Dict) -> List[Dict]:
        """Plan experiments based on task requirements and suggestions"""
        experiments = []
        
        # Use suggested experiments if provided
        suggested = task_data.get('suggested_experiments', [])
        if suggested:
            for i, suggestion in enumerate(suggested, 1):
                exp_type = suggestion.get('type', 'research')
                focus = suggestion.get('focus', 'General research')
                
                experiment = {
                    'id': f"experiment-{i:02d}",
                    'type': exp_type,
                    'focus': focus,
                    'description': f"{exp_type.capitalize()}: {focus}",
                    'agent_id': self.get_agent_for_type(exp_type),
                    'output_file': f"experiment-{i:02d}-{exp_type}.md"
                }
                experiments.append(experiment)
        else:
            # Default experiments based on task description
            requirements = task_data.get('requirements', [])
            if requirements:
                # Create one experiment per requirement
                for i, req in enumerate(requirements, 1):
                    experiment = {
                        'id': f"experiment-{i:02d}",
                        'type': 'research',
                        'focus': req,
                        'description': f"Research: {req}",
                        'agent_id': 'scientist',
                        'output_file': f"experiment-{i:02d}-research.md"
                    }
                    experiments.append(experiment)
            else:
                # Fallback: single research experiment
                experiments.append({
                    'id': 'experiment-01',
                    'type': 'research',
                    'focus': task_data.get('title', 'General research'),
                    'description': f"Research: {task_data.get('title', 'General research')}",
                    'agent_id': 'scientist',
                    'output_file': 'experiment-01-research.md'
                })
        
        return experiments
    
    def get_agent_for_type(self, exp_type: str) -> str:
        """Map experiment type to agent ID"""
        agent_map = {
            'research': 'scientist',
            'code': 'coder',
            'analysis': 'analyst',
            'synthesis': 'writer',
            'prototype': 'designer'
        }
        return agent_map.get(exp_type, 'scientist')
    
    def create_experiment_plan(self, task_dir: Path, task_data: Dict, experiments: List[Dict]):
        """Create experiment plan files"""
        plan_file = task_dir / "experiment-plan.md"
        
        with open(plan_file, 'w') as f:
            f.write(f"# Experiment Plan for {task_data['id']}\n\n")
            f.write(f"**Task**: {task_data['title']}\n\n")
            f.write(f"**Created**: {datetime.now().isoformat()}\n\n")
            f.write("## Planned Experiments\n\n")
            
            for exp in experiments:
                f.write(f"### {exp['id']}: {exp['description']}\n")
                f.write(f"- **Type**: {exp['type']}\n")
                f.write(f"- **Focus**: {exp['focus']}\n")
                f.write(f"- **Agent**: {exp['agent_id']}\n")
                f.write(f"- **Output**: {exp['output_file']}\n\n")
            
            f.write("## Task Context\n")
            f.write(f"{task_data.get('description', '')}\n\n")
            
            if task_data.get('requirements'):
                f.write("## Requirements\n")
                for req in task_data['requirements']:
                    f.write(f"- {req}\n")
                f.write("\n")
        
        print(f"Created experiment plan: {plan_file}")
        
        # Also create individual experiment instruction files
        for exp in experiments:
            exp_file = task_dir / "experiments" / f"{exp['id']}-instructions.md"
            with open(exp_file, 'w') as f:
                f.write(f"# Experiment: {exp['description']}\n\n")
                f.write(f"**Task**: {task_data['title']}\n")
                f.write(f"**Task ID**: {task_data['id']}\n")
                f.write(f"**Experiment ID**: {exp['id']}\n\n")
                f.write("## Objective\n\n")
                f.write(f"{exp['focus']}\n\n")
                f.write("## Instructions\n\n")
                f.write("Research and provide comprehensive analysis on the topic above.\n")
                f.write("Include:\n")
                f.write("- Key findings and insights\n")
                f.write("- Relevant examples or case studies\n")
                f.write("- Recommendations or next steps\n")
                f.write("- Citations from reputable sources\n\n")
                f.write("## Output Format\n\n")
                f.write(f"Save output to: `{exp['output_file']}` in this directory.\n")
                f.write("Use markdown format with clear sections.\n")
    
    def spawn_subagent(self, task_data: Dict, experiment: Dict) -> bool:
        """Spawn subagent for experiment"""
        task_id = task_data['id']
        exp_id = experiment['id']
        
        # Build agent task
        agent_task = f"""
        Task: {task_data['title']}
        Experiment: {experiment['description']}
        
        Context: {task_data.get('description', '')}
        
        Requirements:
        {chr(10).join(f'- {req}' for req in task_data.get('requirements', []))}
        
        Please research and provide comprehensive analysis.
        Save output to: log/tasks/{task_id}/experiments/{experiment['output_file']}
        
        Focus on: {experiment['focus']}
        """
        
        # Simplified spawn command (in reality would use OpenClaw API)
        # This is a placeholder - actual implementation depends on OpenClaw setup
        print(f"Would spawn agent: {experiment['agent_id']} for {exp_id}")
        print(f"Task: {agent_task[:200]}...")
        
        # In a real implementation, you would call OpenClaw's sessions_spawn
        # For now, we'll create a placeholder output file
        output_file = self.tasks_dir / task_id / "experiments" / experiment['output_file']
        if not output_file.exists():
            with open(output_file, 'w') as f:
                f.write(f"# Placeholder Output for {exp_id}\n\n")
                f.write(f"**Task**: {task_data['title']}\n")
                f.write(f"**Experiment**: {experiment['description']}\n\n")
                f.write("This is a placeholder. In actual implementation, ")
                f.write("a subagent would generate this content.\n\n")
                f.write("Generated: " + datetime.now().isoformat() + "\n")
        
        return True
    
    def update_task_status(self, task_file: Path, status: str):
        """Update task status in YAML file"""
        try:
            with open(task_file) as f:
                task_data = yaml.safe_load(f)
            
            task_data['status'] = status
            task_data['last_updated'] = datetime.now().isoformat()
            
            if status == 'processing':
                task_data['processing_started'] = datetime.now().isoformat()
            
            with open(task_file, 'w') as f:
                yaml.dump(task_data, f, default_flow_style=False)
            
            print(f"Updated {task_file.name} status to: {status}")
            return True
        except (yaml.YAMLError, FileNotFoundError) as e:
            print(f"Error updating task status: {e}")
            return False
    
    def process(self) -> bool:
        """Main processing loop"""
        print(f"Starting task processing at {datetime.now().isoformat()}")
        
        # Find pending tasks
        pending_tasks = self.find_pending_tasks()
        print(f"Found {len(pending_tasks)} pending tasks")
        
        if not pending_tasks:
            print("No pending tasks to process")
            return False
        
        # Select task
        selected_task = self.select_task(pending_tasks)
        if not selected_task:
            print("Could not select task")
            return False
        
        print(f"Selected task: {selected_task.name}")
        
        # Load task data
        try:
            with open(selected_task) as f:
                task_data = yaml.safe_load(f)
        except (yaml.YAMLError, FileNotFoundError) as e:
            print(f"Error loading task data: {e}")
            return False
        
        # Create task directory
        task_dir = self.create_task_directory(selected_task, task_data)
        
        # Plan experiments
        experiments = self.plan_experiments(task_data)
        print(f"Planned {len(experiments)} experiments")
        
        # Create experiment plan
        self.create_experiment_plan(task_dir, task_data, experiments)
        
        # Update task status to processing
        self.update_task_status(selected_task, 'processing')
        
        # Spawn subagents (in parallel or sequentially)
        print("Spawning subagents...")
        for experiment in experiments:
            success = self.spawn_subagent(task_data, experiment)
            if not success:
                print(f"Failed to spawn agent for {experiment['id']}")
                # Continue with other experiments
        
        print(f"Task processing initiated for {task_data['id']}")
        print(f"Experiments: {', '.join(exp['id'] for exp in experiments)}")
        print(f"Results will be in: {task_dir}/")
        
        return True

def main():
    """Main entry point"""
    # Determine log directory (can be overridden with env var)
    log_dir = os.environ.get('IDEA_PIPELINE_LOG_DIR', 'log')
    
    processor = TaskProcessor(log_dir)
    success = processor.process()
    
    if success:
        print("Task processing completed successfully")
        sys.exit(0)
    else:
        print("Task processing failed or no tasks to process")
        sys.exit(1)

if __name__ == "__main__":
    main()