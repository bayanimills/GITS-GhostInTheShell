#!/usr/bin/env python3
import sys
import os

def main():
    script_path = 'bootstrap-agent.sh'
    new_section_path = 'new_section.txt'
    
    # Read original script
    with open(script_path, 'r') as f:
        lines = f.readlines()
    
    # Read new section
    with open(new_section_path, 'r') as f:
        new_section = f.read()
    
    # Replace lines 279-321 (1-indexed)
    # Python uses 0-indexed, so lines 278-320
    start = 278  # line 279
    end = 320    # line 321 (inclusive)
    
    # Ensure we have correct lines
    print(f"Original line {start+1}: {lines[start]}")
    print(f"Original line {end+1}: {lines[end]}")
    
    # Replace
    new_lines = lines[:start] + [new_section] + lines[end+1:]
    
    # Write back
    with open(script_path, 'w') as f:
        f.writelines(new_lines)
    
    print(f"Replaced lines {start+1}-{end+1} with new section")
    print(f"Total lines before: {len(lines)}, after: {len(new_lines)}")

if __name__ == '__main__':
    main()