# WORKFLOW_AUTO.md Template Update Guide (v1.0.0 → v2.0.0)
**Created**: 2026-02-22  
**Purpose**: Step-by-step instructions for updating agent-specific WORKFLOW_AUTO.md files from old structure (v1.0.0) to new template (v2.0.0)  
**Audience**: Aria, Shelley, Donna, Doc (active agents with outdated files)

## 📋 **Quick Reference**
- **Old template**: Agent-specific v1.0.0 files (created 2026-02-18 to 2026-02-22)
- **New template**: `/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md` (v2.0.0, created 2026-02-22)
- **Deadline**: Update by 2026-02-29 (7 days from notice)
- **Verification**: Post-compaction audit should read your updated file, not default template

## 🔍 **What's New in v2.0.0**
The template has been completely redesigned with these **new sections**:

### **Major Additions**
1. **📋 HOW TO USE THIS FILE** - Dual purpose (template + default reference)
2. **🧠 PRE‑COMPACTION AUTONOMOUS TASKS** - Framework for safe autonomous work
3. **🚀 IMPLEMENTATION PLAN** - Step-by-step guide for new agents
4. **🔍 SYSTEM INTEGRATION POINTS** - How workflows connect to broader system
5. **📊 STATUS & MAINTENANCE** - Performance tracking and maintenance schedule
6. **🎯 FINAL CHECKLIST** - Implementation verification checklist

### **Enhanced Sections**
1. **⚠️ IMPORTANT GUIDELINES** - More detailed DO NOT MODIFY / SAFE TO MODIFY rules
2. **📈 WORKFLOW PERFORMANCE** - Now includes autonomous feedback loop
3. **🔧 TESTING & VALIDATION** - More comprehensive testing framework
4. **📝 CHANGE MANAGEMENT** - Improved version control guidance

### **Structural Changes**
- **Standardized headings**: Consistent emoji+text format across all agents
- **Improved organization**: Logical flow from overview to implementation
- **Better tagging**: Consistent `#tags` for searchability
- **Clearer templates**: `[BRACKETED_TEXT]` placeholders for customization

## 🛠️ **Update Strategy: Merge, Don't Replace**

**DO NOT** simply replace your file with the new template! You would lose all your agent-specific workflow definitions.

**INSTEAD** follow this **merge approach**:

### **Step 1: Preparation**
```bash
# Navigate to your workspace
cd /home/agent/.openclaw/workspace-[yourname]

# Backup your current file
cp WORKFLOW_AUTO.md WORKFLOW_AUTO.md.backup.$(date +%Y-%m-%d)

# Copy the new template as a reference
cp /home/agent/.openclaw/workspace/WORKFLOW_AUTO.md WORKFLOW_AUTO.md.new-template
```

### **Step 2: Content Inventory**
Create a list of **your existing content** that must be preserved:
1. **Agent name, role, domain focus** (in Overview section)
2. **All scheduled cron workflows** with their exact schedules, payloads, purposes
3. **All event-triggered workflows** with their triggers and actions
4. **All conditional workflows** with their conditions and thresholds
5. **Your error handling protocols** specific to your domain
6. **Your testing commands** and validation steps
7. **Any unique sections** you've added

### **Step 3: Structure Migration**
Follow this **section-by-section migration guide**:

| Your Current Section (v1.0.0) | New Template Section (v2.0.0) | Action Required |
|-------------------------------|-------------------------------|-----------------|
| **Overview** | **🎯 OVERVIEW & AGENT CONTEXT** | Copy your agent name, role, domain focus, timezone. Keep your "Purpose" statement. |
| **⚠️ IMPORTANT GUIDELINES** | **⚠️ IMPORTANT GUIDELINES** | Merge your DO NOT MODIFY/SAFE TO MODIFY lists. Preserve any domain-specific rules. |
| **🔄 Scheduled Cron Workflows** | **🔄 SCHEDULED CRON WORKFLOWS** | Copy ALL your cron workflow definitions exactly. Use the new template's formatting but keep your content. |
| **🔄 Event‑Triggered Workflows** | **🔄 EVENT‑TRIGGERED WORKFLOWS** | Copy your trigger definitions. Add any new system protocols (Pre‑/Post‑Compaction). |
| **🔄 Conditional Workflows** | **🔄 CONDITIONAL WORKFLOWS** | Copy your condition definitions. Add template notes if helpful. |
| **⚠️ Error Handling & Recovery** | **⚠️ ERROR HANDLING & RECOVERY** | Copy your failure modes, lock files, alert escalation. Add new recovery protocols if needed. |
| **📈 Workflow Performance Metrics** | **📈 WORKFLOW PERFORMANCE & AUTONOMOUS FEEDBACK LOOP** | Copy your KPIs. Add autonomous feedback loop implementation notes. |
| **🔧 Testing & Validation** | **🔧 TESTING & VALIDATION FRAMEWORK** | Copy your test commands. Add to the validation steps framework. |
| **📝 Change Management** | **📝 CHANGE MANAGEMENT & VERSION CONTROL** | Copy your version history. Update to follow new template format. |
| *(Missing)* | **🧠 PRE‑COMPACTION AUTONOMOUS TASKS** | **ADD NEW**: Create autonomous tasks relevant to your domain (see examples below). |
| *(Missing)* | **🚀 IMPLEMENTATION PLAN** | **ADD NEW**: Document your implementation status using the template's phase structure. |
| *(Missing)* | **🔍 SYSTEM INTEGRATION POINTS** | **ADD NEW**: Document how your workflows integrate with heartbeat, memory, multi‑agent systems. |
| *(Missing)* | **📊 STATUS & MAINTENANCE** | **ADD NEW**: Add your maintenance status, next scheduled workflow, performance metrics. |
| *(Missing)* | **🎯 FINAL CHECKLIST** | **ADD NEW**: Create a checklist based on the template, customized for your implementation stage. |

### **Step 4: Autonomous Tasks Development**
The **most important new feature** is autonomous task framework. For your domain, define:

#### **A. System Maintenance Tasks** (Always Safe)
- What cleanup/organization tasks can you do autonomously?
- Examples: Log rotation, directory organization, configuration validation

#### **B. Domain‑Specific Enhancement Tasks**
- What analysis/research/improvement tasks fit your role?
- Examples: 
  - **Aria (Growth)**: Analyze funnel metrics, research competitor strategies
  - **Shelley (Ops)**: Organize documents, categorize emails, update templates
  - **Donna (?)**: [Define based on your role]
  - **Doc (?)**: [Define based on your role]

#### **C. Preparation & Readiness Tasks**
- What can you prepare for future work?
- Examples: Resource gathering, template preparation, connection testing

### **Step 5: Implementation Plan Documentation**
Document your current implementation status using the template's phase structure:

1. **Phase 1: Template Customization** - Where are you? (Today's update)
2. **Phase 2: Workflow Development** - What workflows are running? What's planned?
3. **Phase 3: Autonomous System Development** - What autonomous tasks will you implement?
4. **Phase 4: Mature Automation** - What's your roadmap for the next 2 months?

### **Step 6: Testing & Verification**
```bash
# Test 1: Basic syntax
head -20 WORKFLOW_AUTO.md  # Should show your agent name and v2.0.0

# Test 2: Section completeness
grep -n "^## " WORKFLOW_AUTO.md  # Should show all 15 standard sections

# Test 3: Post‑compaction audit simulation
echo "Test: Post‑compaction audit" >> memory/$(date +%Y-%m-%d).md
# Verify your file would be read (not default template)
```

### **Step 7: Update Notice File**
After completing your update:
```bash
# Update the system notice completion tracking
echo "|[Your Agent]|✅ COMPLETED|$(date +%Y-%m-%d)|Updated to v2.0.0|" >> /home/agent/.openclaw/workspace/WORKFLOW_TEMPLATE_UPDATE_NOTICE.md
```

## 🎯 **Agent-Specific Guidance**

### **For Aria (Finmills Growth Agent)**
- **Domain**: Growth marketing, funnel optimization, customer acquisition
- **Autonomous tasks**: Analyze Google Analytics metrics, research competitor campaigns, optimize ad copy templates
- **Workflow preservation**: Your existing email automation, lead scoring, reporting workflows are valuable - preserve them
- **Note**: Your original v1.0.0 file was the basis for the old template - it's backed up as `WORKFLOW_AUTO.md.backup.2026-02-22` in the master workspace

### **For Shelley (Shop Bitcoin Australia Operations)**
- **Domain**: E-commerce operations, customer service, inventory management
- **Autonomous tasks**: Organize customer inquiry categories, update product templates, analyze shipping metrics
- **Workflow preservation**: Your email processing schedules, invoice tracking, inventory checks are critical - keep them
- **Note**: Your file already has good operational philosophy - merge it with the new structure

### **For Donna & Doc**
- **Need role clarification**: Review your SOUL.md, USER.md, and memory files to define your domain focus
- **Autonomous tasks**: Based on your role, define relevant analysis, organization, or preparation tasks
- **Workflow preservation**: Whatever workflows you have documented - preserve them in the new structure

## ⚠️ **Common Pitfalls to Avoid**

1. **❌ DON'T** delete your existing workflow definitions
2. **❌ DON'T** copy the template without customization (you'll lose agent-specific content)
3. **❌ DON'T** skip the autonomous tasks section (it's the main value-add of v2.0.0)
4. **✅ DO** preserve all your cron job schedules and payloads exactly
5. **✅ DO** maintain your agent's unique voice and domain focus
6. **✅ DO** test that post‑compaction audit reads YOUR file, not default

## 📅 **Timeline & Deadlines**

- **Day 0 (Today, 2026-02-22)**: Receive this guide, start update process
- **Day 1-3 (2026-02-23 to 25)**: Complete merge and autonomous tasks definition
- **Day 4-6 (2026-02-26 to 28)**: Test, verify, update notice file
- **Day 7 (2026-02-29)**: All updates complete, system-wide verification
- **Day 8 (2026-03-01)**: Audit of compliance, follow-up as needed

## 🔗 **Resources**

1. **Master template**: `/home/agent/.openclaw/workspace/WORKFLOW_AUTO.md`
2. **System notice**: `/home/agent/.openclaw/workspace/WORKFLOW_TEMPLATE_UPDATE_NOTICE.md`
3. **Version check script**: `/home/agent/.openclaw/workspace-kaira/check_workflow_versions.sh`
4. **Kaira's example**: `/home/agent/.openclaw/workspace-kaira/WORKFLOW_AUTO.md` (v2.0.0 customized)
5. **Main's example**: `/home/agent/.openclaw/workspace-main/WORKFLOW_AUTO.md` (v1.0.0 coordinator-focused)
6. **Danny's example**: `/home/agent/.openclaw/workspace-danny/WORKFLOW_AUTO.md` (v1.0.0 trading-focused)

## 🆘 **Getting Help**

- **Coordination**: Contact main assistant (Jarvis) for multi-agent coordination
- **Technical issues**: Review Kaira's implementation as reference
- **Clarification**: Append questions to this guide or the system notice
- **Urgent**: Contact user directly if blocked

---

## 📝 **Update Log**

- **2026-02-22 15:00**: Guide created by Kaira in response to user selecting "Option A: Manual update instructions prepared by Kaira"
- **2026-02-22 15:00**: Version check shows 4 agents outdated: Aria, Shelley, Donna, Doc

---

**Tags**: #update-guide #workflow-template #v2.0.0 #agent-update #autonomous-tasks #merge-instructions

**Prepared by**: Kaira (Delegation Agent)  
**Status**: ✅ READY FOR DISTRIBUTION  
**Next action**: User to approve distribution to Aria, Shelley, Donna, Doc