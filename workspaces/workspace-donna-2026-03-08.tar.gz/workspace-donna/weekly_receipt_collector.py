#!/usr/bin/env python3
"""
Weekly receipt collector: Find financial emails (receipts, invoices, bills),
classify them as invoice vs receipt, download attachments, upload to Nextcloud.
Run weekly via cron job.
"""
import os
import sys
import json
import re
import tempfile
import subprocess
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import urllib.parse

# Configuration
WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/weekly_receipts_state.json")
LOG_FILE = os.path.join(WORKSPACE, "memory/weekly_receipts.log")
ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"

# Nextcloud configuration
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"

# Label to Nextcloud folder mapping (from process_financial_attachments.py)
LABEL_TO_NEXTCLOUD = {
    # Finance hierarchy (business)
    "Finance/Invoices/Business": "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Invoices/",
    "Finance/Receipts/Business": "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Receipts/",
    "Finance/Statements/Business": "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Statements/",
    # Bayani Enterprises finance labels
    "Finance/Bayani Enterprises": "/_private/businesses/Bayani%20Enterprises/Receipts/",
    # Finance hierarchy (personal)
    "Finance/Invoices/Personal": "/_private/personal/Finances/Invoices/",
    "Finance/Receipts/Personal": "/_private/personal/Finances/Receipts/",
    "Finance/Statements/Personal": "/_private/personal/Finances/Statements/",
    # Legacy receipt labels (to be migrated)
    "Receipt": "/_private/personal/Finances/Receipts/",
    "Consumer/Food Receipts": "/_private/personal/Finances/Receipts/Food/",
    "Crypto/Crypto Receipts": "/_private/personal/Finances/Receipts/Crypto/",
}

# Label to add after successful processing
PROCESSED_LABEL = "Archived-to-Nextcloud"

# Exclude these senders (already handled by other scripts)
EXCLUDED_SENDERS = [
    "stripe.com",
    "emergentagent.com",
    "emergentlabs.com"
]

# Maximum emails to process per run
MAX_EMAILS = 50

# Classifier configuration path
CLASSIFIER_CONFIG = "/home/agent/.openclaw/workspace/skills/gmail-skill/config/label_rules.json"

def run_cmd(cmd, timeout=60):
    """Run shell command and return stdout, stderr, returncode."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124
    except Exception as e:
        return "", str(e), 1

def log_message(message, level="INFO"):
    """Log message to log file and print to stdout."""
    timestamp = datetime.now().isoformat()
    log_entry = f"{timestamp} [{level}] {message}"
    print(f"[{level}] {message}")
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(log_entry + "\n")

def load_state():
    """Load processing state from JSON file."""
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            return {"processed_threads": {}, "last_run": None}
    return {"processed_threads": {}, "last_run": None}

def save_state(state):
    """Save processing state to JSON file."""
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def search_financial_emails(max_results=50, days=30):
    """
    Search for financial emails (receipts, invoices, bills, statements)
    excluding Stripe/Emergent sources.
    """
    # Base query: financial keywords, exclude certain senders
    base_query = f"(receipt OR invoice OR bill OR statement OR payment OR tax) newer_than:{days}d"
    
    # Exclude senders
    for sender in EXCLUDED_SENDERS:
        base_query += f" -from:{sender}"
    
    cmd = [GOG, "gmail", "search", base_query, "--max", str(max_results), "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    
    if rc != 0:
        log_message(f"Search failed: {stderr}", "ERROR")
        return []
    
    try:
        data = json.loads(stdout)
        threads = data.get("threads", [])
        log_message(f"Found {len(threads)} financial threads")
        return threads
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse search results: {e}", "ERROR")
        return []

def get_thread_details(thread_id):
    """Get full thread details including messages and attachments."""
    cmd = [GOG, "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to get thread {thread_id}: {stderr}", "ERROR")
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse thread details for {thread_id}: {e}", "ERROR")
        return None

def extract_attachments(message):
    """Extract attachment info from message."""
    attachments = []
    
    def extract_from_parts(parts):
        for part in parts:
            body = part.get("body", {})
            filename = part.get("filename")
            attachment_id = body.get("attachmentId")
            if filename and attachment_id:
                attachments.append({
                    "id": attachment_id,
                    "filename": filename,
                    "size": body.get("size", 0),
                    "mimeType": part.get("mimeType", "")
                })
            if "parts" in part:
                extract_from_parts(part["parts"])
    
    payload = message.get("payload", {})
    extract_from_parts(payload.get("parts", []))
    return attachments

def download_attachment(message_id, attachment_id, filename):
    """Download attachment to temp file."""
    cmd = [GOG, "gmail", "attachment", message_id, attachment_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)
    if rc != 0:
        log_message(f"Failed to download attachment {attachment_id}: {stderr}", "ERROR")
        return None
    
    temp_dir = tempfile.gettempdir()
    filepath = os.path.join(temp_dir, filename)
    
    try:
        with open(filepath, "wb") as f:
            f.write(stdout.encode('utf-8') if isinstance(stdout, str) else stdout)
        log_message(f"Downloaded {filename} to {filepath}")
        return filepath
    except Exception as e:
        log_message(f"Failed to save attachment {filename}: {e}", "ERROR")
        return None

def ensure_nextcloud_folder(folder_path):
    """Create Nextcloud folder if it doesn't exist."""
    url = f"{NEXTCLOUD_BASE_URL}{folder_path}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        log_message(f"Created folder: {folder_path}")
        return True
    elif "405" in stderr:  # Already exists
        log_message(f"Folder already exists: {folder_path}")
        return True
    else:
        log_message(f"Failed to create folder {folder_path}: {stderr}", "WARNING")
        return False

def get_attachment_folder(filename, classified_label):
    """
    Determine the appropriate Nextcloud folder for an attachment.
    If filename indicates receipt/invoice, override the classified label.
    """
    filename_lower = filename.lower()
    
    # Check for receipt indicators
    receipt_indicators = ["receipt", "payment confirmation", "payment_receipt"]
    if any(indicator in filename_lower for indicator in receipt_indicators):
        if classified_label == "Finance/Invoices/Personal":
            return LABEL_TO_NEXTCLOUD.get("Finance/Receipts/Personal")
        elif classified_label == "Finance/Invoices/Business":
            return LABEL_TO_NEXTCLOUD.get("Finance/Receipts/Business")
    
    # Check for invoice indicators
    invoice_indicators = ["invoice", "bill", "tax invoice"]
    if any(indicator in filename_lower for indicator in invoice_indicators):
        if classified_label == "Finance/Receipts/Personal":
            return LABEL_TO_NEXTCLOUD.get("Finance/Invoices/Personal")
        elif classified_label == "Finance/Receipts/Business":
            return LABEL_TO_NEXTCLOUD.get("Finance/Invoices/Business")
    
    # Default to classified label's folder
    return LABEL_TO_NEXTCLOUD.get(classified_label)


def generate_better_filename(original_filename, subject, sender, date_epoch_ms, label):
    """
    Generate a better filename with format: YYYY-MM-DD_Company_InvoiceNumber_Type.pdf
    """
    # 1. Date
    try:
        date_str = datetime.fromtimestamp(int(date_epoch_ms) / 1000).strftime('%Y-%m-%d')
    except (ValueError, TypeError):
        date_str = datetime.now().strftime('%Y-%m-%d')
    
    # 2. Company name from sender
    company = "Unknown"
    # sender format: "Display Name <email@domain.com>" or just "email@domain.com"
    match = re.search(r'^([^<]+)\s*<', sender)
    if match:
        # Has display name
        company = match.group(1).strip()
    else:
        # No display name, extract domain from email
        match_email = re.search(r'@([^>]+)', sender)
        if match_email:
            domain = match_email.group(1)
            # Remove .com, .co, etc.
            company = domain.split('.')[0].capitalize()
        else:
            company = sender[:30]
    # Clean company name: remove non-alphanumeric, replace spaces with underscore, limit length
    company_clean = re.sub(r'[^\w\s-]', '', company)
    company_clean = re.sub(r'\s+', '_', company_clean.strip())
    company_clean = company_clean[:30]  # limit length
    
    # 3. Invoice number extraction
    invoice_number = None
    invoice_patterns = [
        r'Invoice\s+(?:number\s+)?([A-Z0-9\-]+)',  # Invoice number TNBFQJ1W-0035
        r'Invoice\s+([A-Z0-9\-]+)',                # Invoice TNBFQJ1W-0035
        r'#([A-Z0-9\-]+)',                         # #WH4AQ3XP-0002
        r'([A-Z0-9]{6,}-[0-9]{4,})',               # Generic pattern
    ]
    # Try from original filename first (most specific)
    for pattern in invoice_patterns:
        match = re.search(pattern, original_filename, re.IGNORECASE)
        if match:
            invoice_number = match.group(1)
            break
    # Try from subject if not found in filename
    if not invoice_number:
        for pattern in invoice_patterns:
            match = re.search(pattern, subject, re.IGNORECASE)
            if match:
                invoice_number = match.group(1)
                break
    
    # 4. Type (Invoice/Receipt)
    doc_type = "Document"
    if "invoice" in label.lower() or "invoice" in original_filename.lower():
        doc_type = "Invoice"
    elif "receipt" in label.lower() or "receipt" in original_filename.lower():
        doc_type = "Receipt"
    elif "statement" in label.lower():
        doc_type = "Statement"
    else:
        # Fallback based on classification label
        if "Invoice" in label:
            doc_type = "Invoice"
        elif "Receipt" in label:
            doc_type = "Receipt"
    
    # 5. Assemble filename
    safe_invoice = f"_{invoice_number}" if invoice_number else ""
    base = f"{date_str}_{company_clean}{safe_invoice}_{doc_type}"
    # Ensure .pdf extension
    if not original_filename.lower().endswith('.pdf'):
        ext = os.path.splitext(original_filename)[1] or '.pdf'
    else:
        ext = '.pdf'
    filename = base + ext
    # Sanitize filename further (remove any remaining invalid chars)
    filename = re.sub(r'[^\w\.\-_]', '_', filename)
    # Limit total length
    if len(filename) > 100:
        filename = filename[:100]
    return filename

def upload_to_nextcloud(filepath, folder_path, filename):
    """Upload file to Nextcloud via WebDAV."""
    encoded_filename = urllib.parse.quote(filename)
    dest_url = f"{NEXTCLOUD_BASE_URL}{folder_path}{encoded_filename}"
    
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-T", filepath,
        dest_url
    ]
    
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to upload {filename}: {stderr}", "ERROR")
        return False
    
    log_message(f"Uploaded {filename} to {folder_path}")
    return True

def add_label(thread_id, label):
    """Add label to thread."""
    cmd = [GOG, "gmail", "labels", "modify", "--add", label, thread_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to add label {label}: {stderr}", "WARNING")
        return False
    log_message(f"Added label '{label}' to thread {thread_id}")
    return True

def classify_email(subject: str, sender: str) -> Tuple[Optional[str], Optional[int]]:
    """
    Classify email as invoice vs receipt using classifier.
    Returns (label, archive_delay_seconds).
    """
    try:
        # Import classifier (relative import)
        sys.path.insert(0, WORKSPACE)
        from classifier import EmailClassifier
        classifier = EmailClassifier(CLASSIFIER_CONFIG)
        
        label, archive_delay, metadata = classifier.classify(subject, sender)
        return label, archive_delay
    except ImportError as e:
        log_message(f"Failed to import classifier: {e}, using fallback", "WARNING")
        # Fallback simple classification
        text = (subject + " " + sender).lower()
        
        # Check for invoice keywords
        invoice_keywords = ["invoice", "bill", "tax invoice", "billing document"]
        if any(kw in text for kw in invoice_keywords):
            # Check if business (based on sender/context)
            business_domains = ["xero.com", "quickbooks.com", "myob.com", "stripe.com", "emergentagent.com"]
            if any(domain in sender.lower() for domain in business_domains):
                return "Finance/Invoices/Business", 2592000  # 30 days
            else:
                return "Finance/Invoices/Personal", 2592000
        
        # Check for receipt keywords
        receipt_keywords = ["receipt", "payment confirmation", "order confirmation", "purchase receipt"]
        if any(kw in text for kw in receipt_keywords):
            business_domains = ["stripe.com", "emergentagent.com", "squareup.com"]
            if any(domain in sender.lower() for domain in business_domains):
                return "Finance/Receipts/Business", 7776000  # 90 days
            else:
                return "Finance/Receipts/Personal", 7776000
        
        # Check for statement keywords
        statement_keywords = ["statement", "account summary", "transaction summary"]
        if any(kw in text for kw in statement_keywords):
            return "Finance/Statements/Personal", 15552000  # 180 days
        
        # Default to personal receipt if financial keywords present
        financial_keywords = ["payment", "paid", "amount", "$", "AUD", "USD", "fee", "charge"]
        if any(kw in text for kw in financial_keywords):
            return "Finance/Receipts/Personal", 7776000
        
        return None, None

def process_thread(thread, state, dry_run=False):
    """Process a single thread for financial attachments."""
    thread_id = thread.get("id")
    subject = thread.get("subject", "")
    sender = thread.get("from", "")
    labels = thread.get("labels", [])
    
    log_message(f"Processing thread: {thread_id} - {subject[:50]}...")
    
    # Skip if already processed
    if thread_id in state.get("processed_threads", {}):
        log_message(f"Thread {thread_id} already processed, skipping")
        return {"status": "already_processed", "attachments": 0}
    
    # Skip if already has Archived-to-Nextcloud label
    if PROCESSED_LABEL in labels:
        log_message(f"Thread {thread_id} already has {PROCESSED_LABEL} label, skipping")
        return {"status": "already_archived", "attachments": 0}
    
    # Get thread details
    thread_details = get_thread_details(thread_id)
    if not thread_details:
        return {"status": "failed", "attachments": 0}
    
    # Get first message (usually the only one for receipts)
    messages = thread_details.get("thread", {}).get("messages", [])
    if not messages:
        log_message(f"No messages in thread {thread_id}", "WARNING")
        return {"status": "no_messages", "attachments": 0}
    
    message = messages[0]
    message_id = message.get("id")
    internal_date = message.get('internalDate', '')
    
    # Extract attachments
    attachments = extract_attachments(message)
    if not attachments:
        log_message(f"No attachments in thread {thread_id}")
        # Still classify and maybe add label?
        return {"status": "no_attachments", "attachments": 0}
    
    # Classify email
    label, archive_delay = classify_email(subject, sender)
    if not label:
        log_message(f"Could not classify thread {thread_id}, skipping")
        return {"status": "unclassified", "attachments": len(attachments)}
    
    log_message(f"Classified as: {label} (archive delay: {archive_delay}s)")
    
    # Apply the classified label if missing
    if label not in labels:
        log_message(f"Adding label '{label}' to thread {thread_id}")
        add_label(thread_id, label)
        labels.append(label)  # Update local list
    
    # Get Nextcloud folder for this label
    nextcloud_folder = LABEL_TO_NEXTCLOUD.get(label)
    if not nextcloud_folder:
        log_message(f"No Nextcloud folder mapping for label {label}, skipping", "ERROR")
        return {"status": "no_mapping", "attachments": len(attachments)}
    
    # Dry run mode
    if dry_run:
        log_message(f"DRY RUN: Would process {len(attachments)} attachments for thread {thread_id}")
        for att in attachments:
            log_message(f"  Would upload: {att['filename']} ({att['size']} bytes)")
        return {"status": "dry_run", "attachments": len(attachments), "label": label}
    
    # Ensure Nextcloud folder exists
    if not ensure_nextcloud_folder(nextcloud_folder):
        log_message(f"Failed to ensure Nextcloud folder, skipping upload", "ERROR")
        return {"status": "folder_error", "attachments": len(attachments), "label": label}
    
    # Process each attachment (only PDFs for now)
    successful_uploads = 0
    for att in attachments:
        filename = att["filename"]
        mime_type = att.get("mimeType", "").lower()
        
        # Only process PDFs (or maybe also images)
        if not filename.lower().endswith('.pdf') and 'pdf' not in mime_type:
            log_message(f"Skipping non-PDF attachment: {filename} ({mime_type})")
            continue
        
        # Determine appropriate folder for this attachment
        attachment_folder = get_attachment_folder(filename, label)
        if not attachment_folder:
            log_message(f"No folder mapping for attachment {filename} with label {label}, skipping", "WARNING")
            attachment_folder = nextcloud_folder  # fallback
        
        # Ensure folder exists
        if not ensure_nextcloud_folder(attachment_folder):
            log_message(f"Failed to ensure folder {attachment_folder}, skipping", "WARNING")
            attachment_folder = nextcloud_folder
            ensure_nextcloud_folder(attachment_folder)  # try again
        
        # Download attachment
        temp_file = download_attachment(message_id, att["id"], filename)
        if not temp_file:
            continue
        
        # Generate better filename
        new_filename = generate_better_filename(filename, subject, sender, internal_date, label)
        if new_filename and new_filename != filename:
            log_message(f"Renaming '{filename}' -> '{new_filename}'")
            filename = new_filename
        
        # Upload to Nextcloud
        if upload_to_nextcloud(temp_file, attachment_folder, filename):
            successful_uploads += 1
        
        # Clean up temp file
        try:
            os.remove(temp_file)
        except OSError:
            pass
    
    # Add processed label if successful
    if successful_uploads > 0:
        if add_label(thread_id, PROCESSED_LABEL):
            state["processed_threads"][thread_id] = {
                "processed_at": datetime.now().isoformat(),
                "label": label,
                "attachments_count": successful_uploads,
                "nextcloud_folder": nextcloud_folder
            }
    
    return {
        "status": "success" if successful_uploads > 0 else "upload_failed",
        "attachments": len(attachments),
        "uploaded": successful_uploads,
        "label": label
    }

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Weekly receipt collector")
    parser.add_argument("--dry-run", action="store_true", help="Dry run (don't download/upload)")
    parser.add_argument("--max", type=int, default=MAX_EMAILS, help="Max emails to process")
    parser.add_argument("--days", type=int, default=30, help="Look back N days")
    parser.add_argument("--label", help="Process specific label only (overrides search)")
    args = parser.parse_args()
    
    log_message(f"Starting weekly receipt collector (dry_run={args.dry_run})")
    
    # Load state
    state = load_state()
    
    # Search for financial emails
    threads = search_financial_emails(max_results=args.max, days=args.days)
    
    if not threads:
        log_message("No financial emails found")
        return
    
    log_message(f"Processing {len(threads)} financial threads")
    
    # Process each thread
    results = []
    for thread in threads:
        result = process_thread(thread, state, dry_run=args.dry_run)
        results.append(result)
    
    # Summary
    total_attachments = sum(r["attachments"] for r in results)
    successful = sum(1 for r in results if r.get("status") == "success")
    failed = sum(1 for r in results if r.get("status") in ["failed", "upload_failed"])
    dry_run = sum(1 for r in results if r.get("status") == "dry_run")
    
    log_message(f"\nProcessing complete:")
    log_message(f"  Total threads: {len(threads)}")
    log_message(f"  Successful: {successful}")
    log_message(f"  Failed: {failed}")
    log_message(f"  Dry run: {dry_run}")
    log_message(f"  Total attachments found: {total_attachments}")
    
    # Save state if not dry run
    if not args.dry_run:
        state["last_run"] = datetime.now().isoformat()
        save_state(state)
        log_message(f"State saved to {STATE_FILE}")
    
    log_message("Done.")

if __name__ == "__main__":
    main()