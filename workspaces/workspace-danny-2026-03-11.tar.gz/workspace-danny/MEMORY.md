# MEMORY.md - Quick Reference

## Active Projects
- **Danny workspace setup** – memory framework established, daily logs operational
- **Polymarket trading automation** – AI Divergence Scanner and Mert Sniper deployed (currently disabled)
- **Cron job monitoring** – real-time execution tracking with quiet hours enforcement
- **Counter‑position strategy implementation** – Mert Sniper counter‑bot deployed (underdog ≤40%, $1 positions, A/B test) – currently disabled

## Recent Decisions
- **Quiet hours (23:00‑07:00)** implemented across all trading scripts – suppress non‑trade output
- **AI Divergence Scanner** configured with 10% threshold, 30‑min scans, Telegram announcements
- **Mert Sniper** configured with 65% conviction threshold, 10‑min scans, smart sizing (5% of balance)
- **Log‑first verification** – all cron job updates verified against actual log files before delivery
- **Simmer skill alignment** (2026‑02‑27) – All trading scripts updated with briefing‑check pattern (risk‑alert gate, venue‑specific formatting)
- **Threshold adjustments** (2026‑02‑27) – AI Divergence threshold lowered to 8%, Mert Sniper conviction threshold lowered to 60% for more opportunities
- **Counter‑bot deployment** (2026‑02‑27) – Mert Sniper Counter (underdog ≤40%) scheduled every 10 minutes for A/B testing with $1 position sizes
- **Recommendations implemented** (2026‑02‑27) – Counter‑bot active, original Mert Sniper not scheduled, thresholds lowered (AI Divergence 8%, Mert Sniper 60%), A/B test started
- **Counter‑position strategy validated** – Mathematical proof that betting opposite side of Mert Sniper would be profitable (58% win rate vs 35% required)
- **Agent timeout increased** – `agents.defaults.timeoutSeconds` set to 1800 seconds per user request
- **Systematic reporting framework deployed** – Parser, daily report script, and scheduled 8am/8pm Gateway cron job for automated outcome reporting
- **Max bet increased** (2026‑02‑27) – Counter‑bot max bet raised from $2 to $5 to overcome minimum share constraints
- **Order type updated** (2026‑02‑27) – Changed from FAK to GTC with 0.5% price tolerance to improve fill rate for illiquid underdog markets
- **Daily trade limit reached** (2026‑02‑28) – Simmer daily limit of 50 trades/day hit; counter‑bot paused until reset
- **Reporting cron job fixed** (2026‑02‑28) – Danny Trading Report cron job updated to use explicit message sending (delivery mode "none") after "announce" delivery failures
- **Counter‑bot cron job fixed** (2026‑02‑28) – Updated from systemEvent+announce to isolated agentTurn with explicit trade‑detection and silent‑unless‑trades logic
- **Duplicate notification bug fixed** (2026‑03‑01) – Spam alerts for XRP trade resolved: cron job re‑reading logs and re‑announcing same trade due to "Bought 0.0 NO shares" pattern match; date placeholder "2026‑m‑d" fixed; cron job disabled, payload updated with explicit trade‑detection (shares > 0) and date command. Test run executed three trades with clean notification.
- **Fee‑aware HFT edge validated** (2026‑03‑01) – Analysis confirms FastLoop's fee‑adjusted EV check; with $0.03 divergence, edge remains ~11.6% after 2% fees; HFT viability confirmed with appropriate thresholds.
- **Next viable option selected** (2026‑03‑01) – Mert Sniper Counter (underdogs ≤40%) recommended as next viable option after HFT fast‑markets dead; proven 58% win rate, ready for reactivation.
- **Counter‑bot & AI‑Divergence tuned** (2026‑03‑01) – Mert Sniper Counter re‑enabled (every 10 min); AI‑Divergence threshold lowered to 6%, frequency increased to 10 min.
- **Useless jobs removed** (2026‑03‑01) – FastLoop BTC disabled (zero fast markets), Weather Trader disabled (zero trades), duplicate AI‑Divergence Scanner removed.
- **All bots disabled** (2026‑03‑02) – User requested removal of all bots; FastLoop BTC, Weather Trader, AI Divergence Scanner, Micro‑Arbitrage Scanner, Mert Sniper Counter, Trade Journal Sync, Trading Report, AWS Daily Completion Report all set to enabled: false; no automated trading active. (Weather Trader re‑enabled per user follow‑up "Keep weather trader".)
- **Polymarket FastLoop skill installed** (2026‑03‑06) – User requested "clawhub install polymarket-fast-loop"; skill updated to version 1.3.4. Requires compatibility fix (simmer_sdk.skill import error with v0.8.26) and API keys (SIMMER_API_KEY, WALLET_PRIVATE_KEY) to function.
- **Simmer skill installed** (2026‑03‑06) – User requested "npx clawhub@latest install simmer" with Ethereum address `0x3B6E2A248fc9C4C2e5cdf846173ACa64946bBfFB`; skill updated to version 1.19.0. Provides prediction market interface for AI agents (Polymarket/Kalshi) with self‑custody wallets and safety rails. Requires SIMMER_API_KEY and WALLET_PRIVATE_KEY for live trading.

## User Preferences (Updated 2026‑03‑02)
- **Reporting protocol:** Only notify when trades are executed (positions taken) and their outcomes
- **Do NOT report:** Scheduled reports (8am/8pm overviews), routine scan outcomes, or AI Divergence updates unless they result in a trade
- **Suppress trade alerts:** Between 23:00‑07:00 local time (Australia/Sydney)
- **Weather reports:** Stick to markets that can be traded (US temperature markets only); do not include Sydney or non‑tradable weather updates

## Trading Insights (2026‑02‑23)
- **Weather markets** showed highest divergence (±32%) early morning but dropped below threshold by 09:09
- **Election markets** (Nepal Congress) provided stable medium‑conviction opportunities (+11‑17%)
- **New opportunities emerged:** Elon Musk tweet‑count markets (±20%/13.6%), Netflix show (+20%)
- **Near‑expiry conviction trading** requires ≥65% split – markets remained balanced (46‑54% splits)
- **Order execution issues** encountered: decimal precision errors, liquidity gaps in order books
- **Significant trading activity:** 20 trades executed via other strategies/manual trading
- **Portfolio volatility:** Balance dropped from $162.24 to $82.90 by evening, exposure fluctuated $0‑$108
- **Current status (21:58):** $82.90 balance, $108.29 exposure (9 positions) – high‑risk leveraged state

## Trading Insights (2026‑02‑27)
- **Simmer skill alignment completed**: All trading scripts updated with briefing‑check pattern (risk‑alert gate, venue‑specific formatting)
- **Portfolio clean**: 0 active USDC positions, all 28 trades resolved, $164.91 USDC balance, +$2.78 net PnL
- **API inconsistency identified**: Portfolio endpoint reports `positions_count:5` but returns empty positions array
- **Trade attribution**: All 26 executed trades from Mert Sniper (AI Divergence & FastLoop bots active but zero executions)
- **Mert Sniper performance**: 42% win rate (11/26) on favorites (≥65% price) – below required 65% threshold → losing strategy
- **Counter‑position opportunity**: Betting opposite side (underdogs ≤35%) would yield 58% win rate → profitable edge
- **Active cron jobs for counter‑targeting**: Weather Trader (2‑min), AI Divergence Scanner (30‑min), FastLoop BTC (5‑min)
- **Threshold adjustments implemented**: AI Divergence threshold lowered to 8%, Mert Sniper conviction lowered to 60% (both original and counter‑bot)
- **Expired trades resolved**: Ethereum Feb 22 and Royce O’Neale positions identified as losses (already processed)
- **Counter‑bot deployed**: Mert Sniper Counter (underdog ≤40%) scheduled every 10 minutes with $1 positions for A/B test

## API & SDK Insights (2026‑02‑28)
- **Simmer SDK version 0.8.26** installed; `get_briefing()` method not present – use `_request("/api/sdk/briefing")`.
- **Market objects** use attribute access (`m.id`, `m.question`, `m.current_probability`), not dict keys.
- **Briefing endpoint structure**: `venues.polymarket.balance` (150.06 USDC), `venues.polymarket.positions_count: 0` (inconsistent with portfolio endpoint).
- **Portfolio inconsistency persists**: `GET /portfolio` reports `positions_count: 13` vs `GET /positions` empty array vs `briefing.venues.polymarket.positions_count: 0`.
- **Market scanning**: `get_markets(limit, status='active')` works; `find_markets(query)` returns 0 results.
- **Context endpoint**: `get_market_context(market_id)` returns dict with `redeemable`, `position`, `warnings`, `slippage_estimate`.
- **Trade endpoint**: Not tested with live trade; `dry_run` parameter likely not supported in SDK.
- **Daily rate limits**: Free tier – 6/min briefing, 30/min markets, 60/min trade.
- **Recommendations**: Add pre‑trade context check; log `source` field; use briefing for heartbeat.

## Trading Insights (2026-03-02)
- **Micro‑arbitrage scanner operational**: Successfully detecting 23‑34 opportunities per scan with 3% minimum gap threshold
- **Weather‑based trading signals**: Strong Wind Warning for Sydney coastal areas demonstrates external event impact on market sectors (maritime, tourism, insurance, renewable energy)
- **AI Divergence data anomaly discovered**: "Texans vs. Steelers" market shows 100% AI probability and 100% market probability but -38.1% divergence calculation
  - **Implication**: Divergence calculation may have edge cases when probabilities approach 100%
  - **Action**: Investigate formula and data source when probabilities are extreme
- **User preferences formalized**: Clear reporting protocol established – only notify on positions taken, suppress routine scan alerts, continue 8am/8pm overviews
- **Memory maintenance**: Pre‑compaction flush process working effectively to preserve conversation context

## Action Items
- **All bots disabled** – ✅ **Completed**: User requested removal of all bots; all Danny cron jobs disabled as of 2026‑03‑02 (except Weather Trader re‑enabled per user follow‑up).
- **Counter‑position implementation** – ✅ **Completed**: Mert Sniper counter‑bot built and scheduled (underdog ≤40%, $1 positions, every 10 minutes)
- **Bot threshold tuning** – ✅ **Completed**: AI Divergence threshold lowered to 8%, Mert Sniper conviction lowered to 60% (both original and counter‑bot)
- **API inconsistency investigation** – ✅ **Completed**: Discrepancy due to resolved vs open positions; no action needed
- **Simmer SDK monitoring** – **Ongoing**: Watch for `skill_slug` parameter support in future SDK releases
- **Live A/B test** – **Paused (bots disabled)**: Counter‑bot vs original Mert Sniper with $1 positions, 48‑hour data collection; reporting framework now tracks metrics.
- **Daily trade limit management** – **Constraint**: Simmer 50 trades/day limit reached at 07:26 AEST; counter‑bot paused until reset (11:00 AEST). Recommendation sent to user (options: reduce cron frequency, increase position size, add daily counter).
- **Systematic reporting framework** – ✅ **Completed**: Parser, daily report, scheduled cron jobs for 8am/8pm automated reporting (now disabled per user preference for trade‑only notifications).
- **Duplicate notification bug fix** – ✅ **Completed**: Cron job payload updated to filter out failed trades, date formatting fixed, test verified with three live trades.
- **HFT fee‑aware strategy validation** – **Completed**: Dry‑run confirmed zero active BTC fast markets; FastLoop BTC disabled (dormant).
- **Weather Trader re‑enabled** – **Updated**: Zero trades executed; cron job re‑enabled per user follow‑up; scans US temperature markets (NYC, Chicago, Seattle, Atlanta, Dallas, Miami) per config. Sydney wind alerts discontinued per directive to stick to tradable markets only.
- **Next viable option selection** – **Completed**: Mert Sniper Counter re‑enabled, AI‑Divergence tuned (6% threshold, 10‑min frequency) – currently disabled.
- **Script cleanup** – **Completed**: Archived unused shell scripts, diagnostic Python scripts, and test files to `archive/` directory.
- **Micro‑arbitrage scanner development** – **Completed**: Scanner built and cron job deployed (every 10 min, 3 % min gap) – currently disabled.
- **Cross‑platform arbitrage exploration** – **Pending**: Research Kalshi/PredictIt API setup for cross‑market opportunities
- **Polymarket FastLoop setup** – **In Progress**: Skill installed (v1.3.4) but requires compatibility fix for simmer_sdk v0.8.26 and API keys (SIMMER_API_KEY, WALLET_PRIVATE_KEY) to function.

## Notes
- Created by maintenance review on 2026-02-21.
- Updated with trading operations insights on 2026-02-23.
- 8pm overview delivered late (00:16 AM Feb 24) – portfolio leveraged at $82.90 balance, $108.29 exposure.
- Updated with Simmer alignment and counter‑position analysis on 2026-02-27.
- Updated with micro‑arbitrage, weather signals, and data anomaly insights on 2026-03-02.
- All trading bots disabled per user request on 2026‑03‑02.
