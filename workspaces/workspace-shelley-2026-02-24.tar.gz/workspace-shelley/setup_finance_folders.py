#!/usr/bin/env python3
"""Set up Finance folder structure in Nextcloud."""

import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')

from nextcloud_client import NextcloudClient
import os

client = NextcloudClient()

print("Setting up Finance folder structure...")

# Folders to create
folders = [
    'Finance/Incoming',
    'Finance/Receipts', 
    'Finance/Processed'
]

created_folders = []
existing_folders = []

for folder in folders:
    print(f"\nChecking: {folder}")
    
    if client.file_exists(folder):
        print(f"  ✓ Already exists")
        existing_folders.append(folder)
    else:
        # Create parent directory first if needed
        parent = os.path.dirname(folder)
        if parent and parent != 'Finance' and not client.file_exists(parent):
            print(f"  Creating parent: {parent}")
            client.create_directory(parent)
        
        print(f"  Creating: {folder}")
        if client.create_directory(folder):
            print(f"  ✓ Created successfully")
            created_folders.append(folder)
        else:
            print(f"  ✗ Failed to create")

print(f"\n{'='*50}")
print(f"Summary:")
print(f"  Created: {len(created_folders)} folders")
if created_folders:
    print(f"    • " + "\n    • ".join(created_folders))
    
print(f"  Already existed: {len(existing_folders)} folders")
if existing_folders:
    print(f"    • " + "\n    • ".join(existing_folders))

# Verify by listing Finance directory
print(f"\nVerifying Finance structure...")
if client.file_exists('Finance'):
    finance_items = client.list_directory('Finance')
    print(f"Finance directory contents ({len(finance_items)} items):")
    for item in finance_items:
        icon = '📁' if item['is_dir'] else '📄'
        size = f" ({item['size']} bytes)" if item.get('size') else ''
        print(f"  {icon} {item['name']}{size}")
else:
    print("✗ Finance folder doesn't exist after creation attempt")

print(f"\nSetup complete!")