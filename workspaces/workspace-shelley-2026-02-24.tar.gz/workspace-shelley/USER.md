# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Bayani
- **What to call them:** Bayani
- **Pronouns:** he/him
- **Timezone:** Australia/Sydney
- **Communication style:** not yet set
- **Preferred contact hours:** not yet set
- **Urgency threshold:** not yet set
- **Sleep Window:** 23:00-07:00 local time (12:00-20:00 UTC)
- **Notes:** Manages Shop Bitcoin Australia, prefers Telegram communication

## Context

**Shop Bitcoin Australia Management:**
- Runs "Australia's One Stop Bitcoin Shop"
- Products: Bitaxe Gamma miners, hardware wallets, nodes, accessories, merchandise
- Brand positioning: Bitcoin-only, Australian ecosystem focus
- Community links: OrangeLabel.io, BitcoinAlive 2026, Bitcoin Industry Body

**Social Media Preferences (learned 2026-02-15/16):**
- Prefers manual approval for social media posts (daily at 15:00 AEST)
- Uses Make.com webhook with Buffer integration
- Twitter handle: @ShopBitcoinAus (corrected from @ShopBitcoinAU)
- Content style: No hashtags, line breaks, accurate product specs
- Target audience: Beginners, experienced miners, hardware enthusiasts
- Wants monitoring of @ShopBitcoinAus X feed for engagement
- Twitter API token currently invalid (401 error) - needs fix or manual monitoring

**Communication Style:**
- Concise responses preferred
- Makes corrections when needed (e.g., Twitter handle, product phrasing)
- Uses numbers for options (e.g., "3 skip" for option 3)
- Confirms with short phrases ("Excellent - do it again", "No cancellation required - all clear")

**Technical Setup:**
- OpenClaw agent ecosystem
- Make.com webhook: vumwb8qh0mjdjewqiv9bbw1vndz9qt1z@hook.us2.make.com (active)
- Buffer integration via Make.com scenario
- Daily post automation with cron job (05:00 UTC = 15:00 AEST)

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
---

_This file is yours to evolve. As you learn about me, update it._