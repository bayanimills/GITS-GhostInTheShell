#!/usr/bin/env python3
"""Explore the businesses directory structure."""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

config = {
    'url': 'https://nextcloud.blkstr.io',
    'username': 'jarvis',
    'password': 'agent12345jarvis'
}

auth = HTTPBasicAuth(config['username'], config['password'])

def list_path(path):
    """List contents of a path."""
    url = f"{config['url']}/remote.php/dav/files/{config['username']}{path}"
    headers = {'Depth': '1'}
    
    try:
        response = requests.request('PROPFIND', url, auth=auth, headers=headers, timeout=10)
        if response.status_code == 207:
            return parse_propfind(response.text, path)
        else:
            print(f"  Failed to list {path}: Status {response.status_code}")
            return []
    except Exception as e:
        print(f"  Error listing {path}: {e}")
        return []

def parse_propfind(xml_text, base_path):
    """Parse PROPFIND response."""
    root = ET.fromstring(xml_text)
    namespaces = {'d': 'DAV:'}
    items = []
    
    for response_elem in root.findall('d:response', namespaces):
        href_elem = response_elem.find('d:href', namespaces)
        if href_elem is not None:
            href = href_elem.text
            base = f"/remote.php/dav/files/{config['username']}"
            if href.startswith(base):
                rel_path = href[len(base):]
                if rel_path and rel_path != base_path:
                    # Check if it's a directory
                    propstat = response_elem.find('d:propstat', namespaces)
                    if propstat is not None:
                        prop = propstat.find('d:prop', namespaces)
                        if prop is not None:
                            resource_type = prop.find('d:resourcetype', namespaces)
                            is_dir = resource_type is not None and resource_type.find('d:collection', namespaces) is not None
                            items.append((rel_path, is_dir))
    return items

print("Exploring business directory structure...\n")

# Start from /_private/businesses
base_paths = [
    '/_private/businesses',
    '/_private/businesses/Bayani Enterprises',
    '/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin'
]

for path in base_paths:
    print(f"Checking: {path}")
    items = list_path(path)
    
    if items:
        dirs = [p for p, is_dir in items if is_dir]
        files = [p for p, is_dir in items if not is_dir]
        
        if dirs:
            print(f"  Subdirectories ({len(dirs)}):")
            for d in dirs[:10]:  # Show first 10
                name = d.split('/')[-1]
                print(f"    📁 {name}")
            if len(dirs) > 10:
                print(f"    ... and {len(dirs) - 10} more")
        
        if files:
            print(f"  Files ({len(files)}):")
            for f in files[:5]:  # Show first 5
                name = f.split('/')[-1]
                print(f"    📄 {name}")
            if len(files) > 5:
                print(f"    ... and {len(files) - 5} more")
    else:
        print(f"  (Empty or doesn't exist)")
    
    print()

# Now let's specifically check for the business folders mentioned in memory
print("\n--- Looking for specific business folders ---")
target_path = '/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin'
print(f"Checking: {target_path}")
items = list_path(target_path)

if not items and "404" not in str(items):  # If empty but not error
    print(f"  Path might not exist. Let's create it step by step.")
    
    # Check parent
    parent = '/_private/businesses/Bayani Enterprises'
    print(f"\nChecking parent: {parent}")
    parent_items = list_path(parent)
    if parent_items:
        print(f"  Parent exists with {len(parent_items)} items")
    else:
        print(f"  Parent doesn't exist or is empty")
        
    # Let's check what business entries exist
    print(f"\nChecking what's in /_private/businesses:")
    businesses = list_path('/_private/businesses')
    if businesses:
        print(f"  Found {len(businesses)} business entries:")
        for path, is_dir in businesses:
            name = path.split('/')[-1]
            if name:
                print(f"    • {name}")
                
    # Check if maybe the folders are at a different location
    print(f"\n--- Checking alternative locations ---")
    
    # Check root for business folders
    print(f"Checking root for business folders:")
    root_items = list_path('/')
    business_like = []
    for path, is_dir in root_items:
        name = path.split('/')[-1]
        lower_name = name.lower()
        if any(biz in lower_name for biz in ['collection', 'vendor', 'shipping', 'invoice', 'operational', 'social']):
            business_like.append((name, path))
    
    if business_like:
        print(f"  Found potential business folders at root:")
        for name, path in business_like:
            print(f"    • {name} ({path})")
    else:
        print(f"  No business-like folders found at root")