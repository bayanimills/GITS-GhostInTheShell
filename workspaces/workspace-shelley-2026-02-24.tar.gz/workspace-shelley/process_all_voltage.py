#!/usr/bin/env python3
"""Process all Voltage invoices from Gmail to Nextcloud."""

import sys
import os
import json
import re
import subprocess
import csv
from datetime import datetime
from collections import defaultdict

sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

# Configuration
ACCOUNT = "service@shopbitcoin.com.au"
LABEL_NAME = "Saved in Nextcloud by Shelley"
FINANCE_BASE = "Finance/Incoming"
CSV_PATH = "voltage_invoices_processed.csv"

def run_gog(args, capture_output=True):
    """Run gog command and return parsed JSON if possible."""
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    print(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=capture_output, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error: {result.stderr}")
            return None
        
        if capture_output:
            return json.loads(result.stdout)
        return True
    except Exception as e:
        print(f"Command failed: {e}")
        return None

def get_label_id():
    """Get label ID by name."""
    labels = run_gog(["gmail", "labels", "list"])
    if not labels:
        return None
    
    for label in labels.get("labels", []):
        if label.get("name") == LABEL_NAME:
            return label.get("id")
    return None

def search_voltage_threads():
    """Search for all Voltage email threads."""
    print("Searching for Voltage emails...")
    # Search for voltage emails
    result = run_gog(["gmail", "search", "from:voltage@ OR subject:Voltage"])
    if not result:
        return []
    
    threads = result.get("threads", [])
    print(f"Found {len(threads)} threads")
    return threads

def get_thread_details(thread_id):
    """Get thread details with messages."""
    result = run_gog(["gmail", "thread", "get", thread_id])
    if not result:
        return None
    return result.get("thread")

def extract_invoice_number(subject):
    """Extract invoice number from subject."""
    # Pattern like #448A39E5-0012
    match = re.search(r'#([A-Z0-9\-]+)', subject)
    if match:
        return match.group(1)
    
    # Try other patterns
    match = re.search(r'Invoice[:\s]+([A-Z0-9\-]+)', subject, re.IGNORECASE)
    if match:
        return match.group(1)
    
    return None

def parse_email_metadata(email):
    """Parse metadata from email JSON."""
    subject = email.get("headers", {}).get("subject", "")
    body = email.get("body", "")
    
    invoice_number = extract_invoice_number(subject)
    if not invoice_number:
        print(f"  Could not extract invoice number from: {subject[:50]}...")
        return None
    
    # Extract amount
    amount_match = re.search(r'\$(\d+\.\d{2})', body)
    if not amount_match:
        amount_match = re.search(r'Total due \$(\d+\.\d{2})', body)
    amount = amount_match.group(1) if amount_match else "0.00"
    
    # Vendor
    vendor = "Voltage"
    
    # Date - use email date
    date_str = email.get("headers", {}).get("date", "")
    email_date = None
    if date_str:
        from email.utils import parsedate_to_datetime
        try:
            dt = parsedate_to_datetime(date_str)
            email_date = dt.strftime("%Y-%m-%d")
        except:
            email_date = None
    
    # Find PDF attachment
    attachments = email.get("attachments", [])
    pdf_attachments = [a for a in attachments if a.get("mimeType") == "application/pdf"]
    
    if not pdf_attachments:
        print(f"  No PDF attachment found for invoice {invoice_number}")
        return None
    
    # Use first PDF
    attachment = pdf_attachments[0]
    
    return {
        "invoice_number": invoice_number,
        "amount": amount,
        "vendor": vendor,
        "email_date": email_date,
        "subject": subject,
        "message_id": email.get("message", {}).get("id"),
        "thread_id": email.get("message", {}).get("threadId"),
        "attachment_id": attachment.get("attachmentId"),
        "original_filename": attachment.get("filename"),
        "email_json": email  # Keep for reference
    }

def sanitize_filename(metadata):
    """Create sanitized filename according to convention."""
    # Use email date or today
    date = metadata["email_date"] or datetime.now().strftime("%Y-%m-%d")
    
    # Replace $ with AUD
    amount_str = f"AUD{metadata['amount']}"
    
    # Clean vendor name
    vendor_clean = re.sub(r'[<>:"/\\|?*]', '', metadata["vendor"])
    
    # Build filename
    filename = f"{date} - {vendor_clean} - {metadata['invoice_number']} - {amount_str} - Invoice-{metadata['invoice_number']}.pdf"
    
    # Replace any remaining problematic characters
    filename = re.sub(r'[<>:"/\\|?*$]', '', filename)
    
    return filename

def download_attachment(message_id, attachment_id, local_path):
    """Download attachment to local path."""
    cmd = [
        "gog", "gmail", "attachment", message_id, attachment_id,
        "--account", ACCOUNT,
        "--output", local_path
    ]
    
    print(f"  Downloading to {local_path}...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    
    if result.returncode != 0:
        print(f"  Download failed: {result.stderr[:200]}")
        return False
    
    return os.path.exists(local_path)

def archive_and_label_thread(thread_id, label_id):
    """Archive thread (remove INBOX) and add custom label."""
    # Remove INBOX label
    print(f"  Archiving thread {thread_id}...")
    result = run_gog(["gmail", "thread", "modify", thread_id, "--remove", "INBOX"], capture_output=False)
    if result is None:
        print("  Warning: Failed to remove INBOX label")
    
    # Add custom label
    if label_id:
        print(f"  Adding label {LABEL_NAME}...")
        result = run_gog(["gmail", "thread", "modify", thread_id, "--add", label_id], capture_output=False)
        if result is None:
            print("  Warning: Failed to add custom label")
    
    # Mark as read (remove UNREAD label)
    print(f"  Marking as read...")
    result = run_gog(["gmail", "thread", "modify", thread_id, "--remove", "UNREAD"], capture_output=False)
    
    return True

def log_to_csv(metadata, remote_path):
    """Log processing to CSV file."""
    file_exists = os.path.exists(CSV_PATH)
    
    with open(CSV_PATH, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Date", "Vendor", "Invoice Number", "Amount", "Nextcloud Path", "Processed Timestamp"])
        
        writer.writerow([
            metadata["email_date"] or datetime.now().strftime("%Y-%m-%d"),
            metadata["vendor"],
            metadata["invoice_number"],
            f"${metadata['amount']}",
            remote_path,
            datetime.now().isoformat()
        ])
    
    print(f"  Logged to {CSV_PATH}")

def process_invoice(metadata, nc, label_id):
    """Process a single invoice."""
    invoice_num = metadata["invoice_number"]
    print(f"\nProcessing invoice {invoice_num}...")
    
    # Create sanitized filename
    new_filename = sanitize_filename(metadata)
    print(f"  New filename: {new_filename}")
    
    # Download attachment
    temp_dir = "temp_voltage"
    os.makedirs(temp_dir, exist_ok=True)
    temp_path = os.path.join(temp_dir, f"temp_{invoice_num}.pdf")
    
    if not download_attachment(metadata["message_id"], metadata["attachment_id"], temp_path):
        print(f"  ✗ Failed to download attachment")
        return False
    
    # Upload to Nextcloud
    remote_path = f"{FINANCE_BASE}/{new_filename}"
    print(f"  Uploading to {remote_path}...")
    
    result = nc.upload_file(temp_path, remote_path)
    if not result:
        print(f"  ✗ Upload failed")
        os.remove(temp_path)
        return False
    
    print(f"  ✓ Uploaded to {result}")
    
    # Archive and label thread
    archive_and_label_thread(metadata["thread_id"], label_id)
    
    # Log to CSV
    log_to_csv(metadata, result)
    
    # Clean up
    os.remove(temp_path)
    print(f"  ✓ Cleanup complete")
    
    return True

def main():
    print("=" * 60)
    print("VOLTAGE INVOICE BATCH PROCESSING")
    print("=" * 60)
    
    # Initialize
    print("\n1. Initializing...")
    nc = NextcloudClient()
    label_id = get_label_id()
    if label_id:
        print(f"   Label ID: {label_id}")
    else:
        print("   Warning: Label not found, will skip labeling")
    
    # Search for threads
    threads = search_voltage_threads()
    if not threads:
        print("No Voltage threads found")
        return 1
    
    # Process each thread to extract invoices
    print("\n2. Analyzing threads...")
    invoices = {}  # invoice_number -> metadata (latest email)
    
    for thread in threads:
        thread_id = thread["id"]
        print(f"  Thread {thread_id}: {thread['subject'][:60]}...")
        
        details = get_thread_details(thread_id)
        if not details:
            continue
        
        # Get messages in thread
        messages = details.get("messages", [])
        for msg in messages:
            metadata = parse_email_metadata(msg)
            if not metadata:
                continue
            
            invoice_num = metadata["invoice_number"]
            # Keep the latest email (based on date)
            existing = invoices.get(invoice_num)
            if not existing or (metadata["email_date"] and (
                not existing["email_date"] or metadata["email_date"] > existing["email_date"])):
                invoices[invoice_num] = metadata
    
    print(f"\nFound {len(invoices)} unique invoices:")
    for inv_num, meta in invoices.items():
        print(f"  • {inv_num}: ${meta['amount']} ({meta['email_date']})")
    
    # Process each invoice
    print(f"\n3. Processing {len(invoices)} invoices...")
    processed = 0
    failed = []
    
    for invoice_num, metadata in invoices.items():
        try:
            success = process_invoice(metadata, nc, label_id)
            if success:
                processed += 1
            else:
                failed.append(invoice_num)
        except Exception as e:
            print(f"  Exception processing {invoice_num}: {e}")
            failed.append(invoice_num)
    
    # Summary
    print(f"\n{'='*60}")
    print("PROCESSING COMPLETE")
    print(f"{'='*60}")
    print(f"Total unique invoices: {len(invoices)}")
    print(f"Successfully processed: {processed}")
    print(f"Failed: {len(failed)}")
    if failed:
        print(f"Failed invoices: {', '.join(failed)}")
    
    # Verify uploads
    print(f"\nVerifying uploads in {FINANCE_BASE}...")
    items = nc.list_directory(FINANCE_BASE)
    pdf_files = [i for i in items if i['name'].endswith('.pdf')]
    print(f"Found {len(pdf_files)} PDF files in {FINANCE_BASE}")
    
    if processed > 0:
        print(f"\nCSV log: {os.path.abspath(CSV_PATH)}")
    
    return 0 if len(failed) == 0 else 1

if __name__ == "__main__":
    sys.exit(main())