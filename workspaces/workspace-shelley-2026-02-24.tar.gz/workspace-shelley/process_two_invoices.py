#!/usr/bin/env python3
"""Process two remaining Voltage invoices using proven pilot code."""

import sys
import os
import json
import re
import subprocess
from datetime import datetime

sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

# Configuration
ACCOUNT = "service@shopbitcoin.com.au"
LABEL_NAME = "Saved in Nextcloud by Shelley"
FINANCE_BASE = "Finance/Incoming"

def run_gog(args, capture_output=True):
    """Run gog command and return parsed JSON if possible."""
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    print(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=capture_output, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error: {result.stderr}")
            return None
        
        if capture_output:
            return json.loads(result.stdout)
        return True
    except Exception as e:
        print(f"Command failed: {e}")
        return None

def ensure_label_exists():
    """Ensure label exists, create if not."""
    # List labels
    labels = run_gog(["gmail", "labels", "list"])
    if not labels:
        print("Warning: Could not list labels")
        return None
    
    # Check if label exists
    for label in labels.get("labels", []):
        if label.get("name") == LABEL_NAME:
            return label.get("id")
    
    # Create label
    print(f"Creating label: {LABEL_NAME}")
    result = run_gog(["gmail", "labels", "create", LABEL_NAME])
    if result:
        return result.get("id")
    return None

def parse_invoice_metadata(email_data):
    """Parse metadata from email JSON."""
    subject = email_data.get("headers", {}).get("subject", "")
    body = email_data.get("body", {}).get("text", "") or email_data.get("body", {}).get("html", "")
    
    # Extract invoice number
    match = re.search(r'#([A-Z0-9\-]+)', subject)
    if not match:
        print(f"Could not extract invoice number from: {subject[:50]}...")
        return None
    
    invoice_number = match.group(1)
    
    # Extract amount
    amount_match = re.search(r'\$(\d+\.\d{2})', body)
    if not amount_match:
        # Try other patterns
        amount_match = re.search(r'Total due \$(\d+\.\d{2})', body)
    amount = amount_match.group(1) if amount_match else "0.00"
    
    # Vendor name
    vendor = "Voltage"
    
    # Date - use email date
    date_str = email_data.get("headers", {}).get("date", "")
    if date_str:
        # Parse RFC 2822 date
        from email.utils import parsedate_to_datetime
        try:
            dt = parsedate_to_datetime(date_str)
            date = dt.strftime("%Y-%m-%d")
        except:
            date = datetime.now().strftime("%Y-%m-%d")
    else:
        date = datetime.now().strftime("%Y-%m-%d")
    
    return {
        "invoice_number": invoice_number,
        "amount": amount,
        "vendor": vendor,
        "date": date,
        "original_filename": f"Invoice-{invoice_number}.pdf"
    }

def sanitize_filename(metadata):
    """Create sanitized filename according to convention."""
    # Replace $ with AUD
    amount_str = f"AUD{metadata['amount']}"
    
    # Remove problematic characters from vendor name
    vendor_clean = re.sub(r'[<>:"/\\|?*]', '', metadata['vendor'])
    
    # Build filename
    filename = f"{metadata['date']} - {vendor_clean} - {metadata['invoice_number']} - {amount_str} - Invoice-{metadata['invoice_number']}.pdf"
    
    # Replace any remaining problematic characters
    filename = re.sub(r'[<>:"/\\|?*$]', '', filename)
    
    return filename

def download_attachment(message_id, attachment_id, original_filename):
    """Download attachment to temporary location."""
    temp_dir = "temp_invoices"
    os.makedirs(temp_dir, exist_ok=True)
    
    temp_path = os.path.join(temp_dir, original_filename)
    
    print(f"  Downloading {original_filename}...")
    cmd = ["gog", "gmail", "attachments", "get", message_id, attachment_id,
           "--account", ACCOUNT, "--output", temp_path]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"  Download error: {result.stderr}")
            return None
        
        if os.path.exists(temp_path):
            size = os.path.getsize(temp_path)
            print(f"  ✓ Downloaded {size:,} bytes")
            return temp_path
        else:
            print("  ✗ File not created")
            return None
    except Exception as e:
        print(f"  Download exception: {e}")
        return None

def archive_and_label_message(message_id, label_id):
    """Archive message and add custom label."""
    if not message_id:
        print("  Warning: No message ID, skipping archive/label")
        return False
    
    print(f"  Archiving and labeling message {message_id}...")
    
    # Get thread ID from message
    email_data = run_gog(["gmail", "get", message_id])
    if not email_data:
        print("  Warning: Could not get message to find thread ID")
        return False
    
    thread_id = email_data.get("message", {}).get("threadId")
    if not thread_id:
        print("  Warning: No thread ID found")
        return False
    
    # Remove INBOX label (archive)
    result = run_gog(["gmail", "thread", "remove-labels", thread_id, "INBOX"], capture_output=False)
    if result is None:
        print("  Warning: Failed to remove INBOX label")
    
    # Remove UNREAD label if present
    result = run_gog(["gmail", "thread", "remove-labels", thread_id, "UNREAD"], capture_output=False)
    # Don't fail if UNREAD not present
    
    # Add custom label
    if label_id:
        result = run_gog(["gmail", "thread", "add-labels", thread_id, label_id], capture_output=False)
        if result is None:
            print("  Warning: Failed to add custom label")
    
    return True

def process_invoice(message_id):
    """Process a single invoice by message ID."""
    print(f"\nProcessing invoice from message {message_id}...")
    
    # Get email data
    print("1. Fetching email data...")
    email_data = run_gog(["gmail", "get", message_id])
    if not email_data:
        print("Failed to get email data")
        return False
    
    # Parse metadata
    print("2. Parsing invoice metadata...")
    metadata = parse_invoice_metadata(email_data)
    if not metadata:
        print("Failed to parse invoice metadata")
        return False
    
    print(f"   Invoice #: {metadata['invoice_number']}")
    print(f"   Amount: ${metadata['amount']}")
    print(f"   Vendor: {metadata['vendor']}")
    print(f"   Date: {metadata['date']}")
    
    # Sanitize filename
    new_filename = sanitize_filename(metadata)
    print(f"   New filename: {new_filename}")
    
    # Find PDF attachment
    print("3. Finding PDF attachment...")
    attachments = email_data.get("attachments", [])
    pdf_attachments = [a for a in attachments if a.get("mimeType") == "application/pdf"]
    
    if not pdf_attachments:
        print("No PDF attachments found")
        return False
    
    attachment = pdf_attachments[0]
    original_filename = attachment.get("filename", f"Invoice-{metadata['invoice_number']}.pdf")
    attachment_id = attachment.get("attachmentId")
    
    # Download attachment
    print("4. Downloading PDF attachment...")
    local_path = download_attachment(message_id, attachment_id, original_filename)
    if not local_path:
        print("Failed to download attachment")
        return False
    
    # Initialize Nextcloud client
    print("5. Initializing Nextcloud client...")
    nc = NextcloudClient()
    
    # Upload to Nextcloud
    print("6. Uploading to Nextcloud...")
    remote_path = f"{FINANCE_BASE}/{new_filename}"
    print(f"   Remote path: {remote_path}")
    
    result = nc.upload_file(local_path, remote_path)
    if not result:
        print("   ✗ Upload failed")
        os.remove(local_path)
        return False
    
    print(f"   ✓ Upload successful: {result}")
    
    # Ensure label exists
    print("7. Setting up Gmail label...")
    label_id = ensure_label_exists()
    if not label_id:
        print("Warning: Could not ensure label exists")
    
    # Archive and label email
    print("8. Archiving and labeling email...")
    archive_and_label_message(message_id, label_id)
    print("   ✓ Email archived and labeled")
    
    # Clean up local file
    print("9. Cleaning up...")
    os.remove(local_path)
    print("   ✓ Local file removed")
    
    print(f"\n{'='*60}")
    print(f"INVOICE #{metadata['invoice_number']} PROCESSED SUCCESSFULLY!")
    print(f"File stored at: {result}")
    print(f"{'='*60}")
    
    return True

def main():
    print("=" * 60)
    print("PROCESSING TWO REMAINING VOLTAGE INVOICES")
    print("=" * 60)
    
    # Process each invoice
    invoices = [
        ("448A39E5-0011", "19bb1974670b40a3"),
        ("448A39E5-0010", "19b11f175389aa73"),
    ]
    
    successes = 0
    failures = 0
    
    for invoice_num, message_id in invoices:
        print(f"\n{'#'*60}")
        print(f"PROCESSING INVOICE #{invoice_num}")
        print(f"{'#'*60}")
        
        try:
            success = process_invoice(message_id)
            if success:
                successes += 1
                print(f"\n✓ Invoice #{invoice_num} COMPLETED")
            else:
                failures += 1
                print(f"\n✗ Invoice #{invoice_num} FAILED")
        except Exception as e:
            print(f"\nException processing {invoice_num}: {e}")
            failures += 1
    
    print(f"\n{'='*60}")
    print("BATCH PROCESSING COMPLETE")
    print(f"{'='*60}")
    print(f"Total invoices: {len(invoices)}")
    print(f"Successfully processed: {successes}")
    print(f"Failed: {failures}")
    
    # Verify Nextcloud contents
    print(f"\nVerifying Nextcloud folder {FINANCE_BASE}...")
    nc = NextcloudClient()
    items = nc.list_directory(FINANCE_BASE)
    pdf_files = [i for i in items if i['name'].endswith('.pdf')]
    print(f"Found {len(pdf_files)} PDF files in {FINANCE_BASE}")
    
    return 0 if failures == 0 else 1

if __name__ == "__main__":
    sys.exit(main())