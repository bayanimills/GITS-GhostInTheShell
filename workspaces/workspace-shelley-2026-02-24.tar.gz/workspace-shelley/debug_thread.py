#!/usr/bin/env python3
"""Debug thread structure."""

import subprocess
import json

ACCOUNT = "service@shopbitcoin.com.au"

def run_gog(args):
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return None
    return json.loads(result.stdout)

# Get thread
thread_id = "19bd56a6df3a09b4"
print(f"Getting thread {thread_id}...")
thread = run_gog(["gmail", "thread", "get", thread_id])
if not thread:
    exit(1)

print(f"Thread keys: {thread.keys()}")
if "messages" in thread:
    print(f"Number of messages: {len(thread['messages'])}")
    msg = thread["messages"][0]
    print(f"Message keys: {msg.keys()}")
    print(f"Subject: {msg.get('headers', {}).get('subject')}")
    print(f"Body snippet: {msg.get('body', '')[:200]}...")
    
    # Check attachments
    if "attachments" in msg:
        print(f"Attachments: {len(msg['attachments'])}")
        for att in msg["attachments"]:
            print(f"  - {att.get('filename')} ({att.get('mimeType')})")
    else:
        print("No attachments key")
        
    # Check for invoice pattern
    import re
    subject = msg.get('headers', {}).get('subject', '')
    print(f"Searching for pattern in: {subject}")
    match = re.search(r'#([A-Z0-9\-]+)', subject)
    print(f"Match: {match}")
    if match:
        print(f"Invoice number: {match.group(1)}")