#!/usr/bin/env python3
"""
Process non-Voltage emails in inbox
"""

import subprocess
import json
import sys

def run_gog(args):
    """Run gog command"""
    cmd = ['gog'] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_inbox_emails(account, exclude_from='voltage.cloud'):
    """Get emails currently in inbox, excluding specific senders"""
    query = f"in:inbox -from:{exclude_from}" if exclude_from else "in:inbox"
    args = ['gmail', 'messages', 'search', query, '--max', '50',
            '--account', account, '--json']
    result = run_gog(args)
    
    if not result or result.returncode != 0:
        print(f"Failed to get inbox emails: {result.stderr if result else 'Unknown'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        return data.get('messages', [])
    except:
        return []

def categorize_email(subject, from_email):
    """Simple categorization"""
    subject_lower = subject.lower()
    from_lower = from_email.lower()
    
    # Bankful payments
    if 'bankful' in from_lower or 'payment received' in subject_lower:
        return 'REFERENCE/Accounting/Receipts'
    
    # Customer support - technical
    elif any(keyword in subject_lower for keyword in ['bitaxe', 'overheating', 'technical', 'issue']):
        return 'REFERENCE/Customer Support/Technical'
    
    # Customer support - general
    elif any(keyword in subject_lower for keyword in ['inquiry', 'question', 'general', 'order', 'return', 'refund']):
        return 'REFERENCE/Customer Support/General'
    
    # Orders
    elif 'order' in subject_lower or 'confirmed' in subject_lower:
        return 'REFERENCE/Orders/Pending'
    
    # Security
    elif any(keyword in subject_lower for keyword in ['security', 'login', 'alert', 'verify']):
        return 'REFERENCE/Security/Logins'
    
    # Australia Post / Service Providers
    elif 'australia post' in from_lower or 'auspost' in from_lower or 'australia post' in subject_lower:
        return 'REFERENCE/Service Providers/Australia Post'
    
    # Invoices (non-Voltage)
    elif 'invoice' in subject_lower or 'tax invoice' in subject_lower:
        return 'REFERENCE/Accounting/Invoices'
    
    # Promotional (default)
    else:
        return 'ACTION REQUIRED/FOLLOW UP'

def archive_email(email_id, label, account):
    """Archive email with label"""
    print(f"Archiving {email_id} with label '{label}'...")
    
    cmd = ['gog', 'gmail', 'labels', 'modify', email_id,
           '--add', label, '--remove', 'INBOX', '--account', account]
    
    result = run_gog(cmd)
    
    if result and result.returncode == 0:
        print(f"✅ Success: {email_id}")
        return True
    else:
        print(f"❌ Failed: {email_id} - {result.stderr if result else 'Unknown'}")
        return False

def main():
    account = 'service@shopbitcoin.com.au'
    
    print("=" * 60)
    print("PROCESSING NON-VOLTAGE INBOX EMAILS")
    print("=" * 60)
    
    # Get emails
    emails = get_inbox_emails(account, exclude_from='voltage.cloud')
    print(f"Found {len(emails)} non-Voltage emails in inbox")
    
    if not emails:
        print("No emails to process")
        return
    
    success = 0
    fail = 0
    
    for email in emails:
        email_id = email.get('id', '')
        subject = email.get('subject', '')
        from_email = email.get('from', '')
        
        if not email_id:
            continue
            
        # Determine label
        label = categorize_email(subject, from_email)
        
        # Archive
        if archive_email(email_id, label, account):
            success += 1
        else:
            fail += 1
        
        # Small delay to avoid rate limiting
        import time
        time.sleep(1)
    
    print("=" * 60)
    print(f"PROCESSING COMPLETE")
    print(f"Success: {success}, Failed: {fail}")
    
    # Count remaining Voltage invoices
    args = ['gmail', 'messages', 'search', 'in:inbox from:voltage.cloud', '--max', '10',
            '--account', account, '--json']
    result = run_gog(args)
    if result and result.returncode == 0:
        try:
            data = json.loads(result.stdout)
            voltage_count = len(data.get('messages', []))
            print(f"Voltage invoices remaining in inbox: {voltage_count}")
            for email in data.get('messages', []):
                print(f"  • {email.get('subject', 'No subject')}")
        except:
            pass
    
    print("=" * 60)

if __name__ == "__main__":
    main()