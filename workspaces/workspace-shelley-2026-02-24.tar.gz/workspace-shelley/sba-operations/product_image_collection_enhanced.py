#!/usr/bin/env python3
"""
Enhanced Product Image Collection Script
Implements resume capability and better error handling.

Features:
1. Resume capability: Tracks processed products to avoid duplicates
2. Better error handling: Continues on failure, logs errors separately
3. Configurable batch size
4. Progress reporting
5. Error logging to separate file
6. Rate limiting handling: Exponential backoff retry for Nextcloud API calls
"""

import xml.etree.ElementTree as ET
import requests
import csv
import os
import sys
import time
import json
from datetime import datetime
from urllib.parse import urlparse, quote
from requests.auth import HTTPBasicAuth
import logging

# ===== CONFIGURATION =====
NEXTCLOUD_URL = "https://nextcloud.blkstr.io"
USERNAME = "jarvis"
PASSWORD = "agent12345jarvis"

# WebDAV base URL
WEBDAV_BASE = f"{NEXTCLOUD_URL}/remote.php/dav/files/jarvis"

# Target folder in Nextcloud
NEXTCLOUD_BASE_PATH = "/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Collections"

# Local temporary directory
LOCAL_TEMP_DIR = "/tmp/sba_product_images"
os.makedirs(LOCAL_TEMP_DIR, exist_ok=True)

# Rate limiting configuration
MAX_RETRIES = 5
INITIAL_DELAY = 2  # seconds
MAX_DELAY = 60  # seconds
RATE_LIMIT_DELAY = 5  # seconds between API calls when rate limited
NORMAL_DELAY = 1  # seconds between products

# XML namespaces
NAMESPACES = {
    'sitemap': 'http://www.sitemaps.org/schemas/sitemap/0.9',
    'image': 'http://www.google.com/schemas/sitemap-image/1.1'
}

# Category to Nextcloud folder mapping
CATEGORY_MAPPING = {
    'accessories': 'Accessories',
    'apparel_hats': 'Clothing & Bags',
    'apparel_shirts': 'Clothing & Bags', 
    'apparel_hoodies': 'Clothing & Bags',
    'mining': 'Accessories',
    'seed_management': 'Accessories',
    'hardware_wallets': 'Accessories',
    'nodes_network': 'Accessories',
    'mugs': 'Accessories',
    'bottles': 'Accessories',
    'food_drink': 'Accessories',
    'other': 'Accessories'
}

# Generic description detection terms
GENERIC_TERMS = ['product', 'item', 'goods', 'merchandise', 'buy now', 'for sale']

# State file to track processed products
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "product_collection_state.json")

# Error log file
ERROR_LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "product_collection_errors.log")

# ===== STATE MANAGEMENT =====

def load_state():
    """Load processed products state from file."""
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                state = json.load(f)
                # Ensure backward compatibility
                if 'processed_products' not in state:
                    state['processed_products'] = []
                if 'last_processed_date' not in state:
                    state['last_processed_date'] = None
                return state
        except Exception as e:
            print(f"⚠️  Failed to load state file: {e}")
    
    # Return default state
    return {
        'processed_products': [],
        'last_processed_date': None,
        'created_at': datetime.now().isoformat()
    }

def save_state(state):
    """Save processed products state to file."""
    try:
        state['updated_at'] = datetime.now().isoformat()
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=2)
        return True
    except Exception as e:
        print(f"❌ Failed to save state file: {e}")
        return False

def update_state(state, product_url, success=True, error_msg=""):
    """Update state with processed product."""
    product_entry = {
        'product_url': product_url,
        'processed_at': datetime.now().isoformat(),
        'success': success,
        'error': error_msg if not success else ""
    }
    
    # Remove existing entry for this product if exists (to update)
    state['processed_products'] = [p for p in state['processed_products'] 
                                  if p.get('product_url') != product_url]
    
    state['processed_products'].append(product_entry)
    state['last_processed_date'] = datetime.now().isoformat()
    return state

# ===== ERROR LOGGING =====

def setup_error_logging():
    """Setup error logging to file."""
    logging.basicConfig(
        level=logging.ERROR,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(ERROR_LOG_FILE),
            logging.StreamHandler(sys.stderr)
        ]
    )
    return logging.getLogger(__name__)

# ===== CORE FUNCTIONS =====

def parse_products(xml_file, max_products=None, skip_processed=True):
    """
    Parse sitemap XML and extract product information.
    Returns list of product dictionaries.
    """
    print(f"📄 Parsing sitemap: {xml_file}")
    
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    products = []
    product_count = 0
    
    # Load state to skip processed products
    state = load_state()
    processed_urls = set([p['product_url'] for p in state['processed_products'] 
                         if p.get('success', False)])
    
    # Find all <url> elements
    for url_elem in root.findall('{http://www.sitemaps.org/schemas/sitemap/0.9}url'):
        # Get product URL
        loc_elem = url_elem.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
        if loc_elem is None:
            continue
        
        product_url = loc_elem.text
        if product_url == "https://shopbitcoin.com.au/":
            continue  # Skip homepage
        
        # Skip already processed products if requested
        if skip_processed and product_url in processed_urls:
            print(f"  ⏭️  Skipping already processed: {product_url}")
            continue
        
        # Get image information
        image_elem = url_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}image')
        if image_elem is None:
            continue  # Skip products without images
        
        image_loc = image_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}loc')
        image_title = image_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}title')
        
        if image_loc is None:
            continue
        
        # Extract product slug from URL
        slug = product_url.replace('https://shopbitcoin.com.au/products/', '')
        
        # Get product name (from image title or slug)
        if image_title is not None and image_title.text:
            product_name = image_title.text
        else:
            # Fallback: generate name from slug
            product_name = slug.replace('-', ' ').title()
        
        # Clean up product name
        product_name = product_name.replace('&amp;', '&').replace('&apos;', "'")
        
        # Determine category
        category = categorize_product(slug, product_name)
        
        # Create product record
        product = {
            'date_collected': datetime.now().strftime('%Y-%m-%d'),
            'product_name': product_name,
            'product_url': product_url,
            'product_slug': slug,
            'image_url': image_loc.text,
            'category': category,
            'nextcloud_folder': CATEGORY_MAPPING.get(category, 'Accessories'),
            'local_path': None,
            'nextcloud_path': None,
            'share_url': None,
            'generic_description': False,
            'notes': '',
            'processed': False,
            'error': None
        }
        
        # Check for generic description
        if any(term in product_name.lower() for term in GENERIC_TERMS):
            product['generic_description'] = True
            product['notes'] = 'Generic description detected'
        
        products.append(product)
        product_count += 1
        
        if max_products is not None and product_count >= max_products:
            break
    
    print(f"   Found {len(products)} products for processing (after skipping processed)")
    return products

def categorize_product(slug, name):
    """Categorize product based on slug and name patterns."""
    slug_lower = slug.lower()
    name_lower = name.lower()
    
    # Bitaxe/mining
    if any(term in slug_lower or term in name_lower for term in ['bitaxe', 'miner', 'mining', 'nerdminer', 'lottery']):
        return 'mining'
    
    # SeedSigner/seed
    elif any(term in slug_lower or term in name_lower for term in ['seedsigner', 'seed', 'stamp', 'backup', 'hammer', 'seedsleeve']):
        return 'seed_management'
    
    # Hardware wallets
    elif any(term in slug_lower or term in name_lower for term in ['coldcard', 'signer', 'hardware', 'wallet']):
        return 'hardware_wallets'
    
    # Nodes
    elif any(term in slug_lower or term in name_lower for term in ['node', 'raspberry', 'pi', 'blockclock', 'lnbits']):
        return 'nodes_network'
    
    # Apparel
    elif any(term in slug_lower or term in name_lower for term in ['cap', 'hat', 'beanie', 'visor', 'bucket', 'tee', 'shirt', 'polo', 'adidas', 'hoodie', 'sweatshirt']):
        if 'hoodie' in slug_lower or 'hoodie' in name_lower:
            return 'apparel_hoodies'
        elif any(term in slug_lower or term in name_lower for term in ['cap', 'hat', 'beanie', 'visor', 'bucket']):
            return 'apparel_hats'
        else:
            return 'apparel_shirts'
    
    # Other categories
    elif 'mug' in slug_lower or 'mug' in name_lower:
        return 'mugs'
    elif 'water' in slug_lower or 'bottle' in name_lower:
        return 'bottles'
    elif any(term in slug_lower or term in name_lower for term in ['honey', 'coffee', 'tea']):
        return 'food_drink'
    elif any(term in slug_lower or term in name_lower for term in ['case', 'stand', 'cover', 'sign', 'sticker', 'coaster', 'patch', 'kit']):
        return 'accessories'
    else:
        return 'other'

def download_image(image_url, slug, logger):
    """Download image from URL to local temporary directory with retry logic."""
    # Extract filename
    parsed = urlparse(image_url)
    filename = os.path.basename(parsed.path)
    
    # Clean filename: remove query parameters, use slug as prefix
    clean_name = f"{slug}_{filename.split('?')[0]}"
    # Remove unsafe characters
    clean_name = ''.join(c for c in clean_name if c.isalnum() or c in '._-')
    
    local_path = os.path.join(LOCAL_TEMP_DIR, clean_name)
    
    # Exponential backoff retry logic
    delay = INITIAL_DELAY
    for attempt in range(MAX_RETRIES):
        try:
            print(f"  ⬇️  Downloading image (attempt {attempt+1}/{MAX_RETRIES})...")
            response = requests.get(image_url, timeout=30)
            response.raise_for_status()
            
            with open(local_path, 'wb') as f:
                f.write(response.content)
            
            file_size = os.path.getsize(local_path) / 1024  # KB
            print(f"  ✅ Downloaded: {clean_name} ({file_size:.1f} KB)")
            return local_path
            
        except Exception as e:
            error_msg = f"Download failed for {slug} (attempt {attempt+1}): {e}"
            print(f"  ❌ {error_msg}")
            logger.error(error_msg)
            if attempt == MAX_RETRIES - 1:
                return None
            wait_time = delay * (2 ** attempt)
            if wait_time > MAX_DELAY:
                wait_time = MAX_DELAY
            time.sleep(wait_time)
    
    # All retries exhausted
    error_msg = f"Failed to download {slug} after {MAX_RETRIES} attempts"
    print(f"  ❌ {error_msg}")
    logger.error(error_msg)
    return None

def upload_to_nextcloud(local_path, nextcloud_folder, slug, logger):
    """Upload file to Nextcloud via WebDAV with retry logic."""
    # Prepare filename
    filename = os.path.basename(local_path)
    
    # URL encode the path
    encoded_folder = quote(nextcloud_folder, safe='')
    encoded_filename = quote(filename, safe='')
    
    # WebDAV URL
    upload_url = f"{WEBDAV_BASE}{NEXTCLOUD_BASE_PATH}/{encoded_folder}/{encoded_filename}"
    
    # Read file once
    with open(local_path, 'rb') as f:
        file_data = f.read()
    
    auth = HTTPBasicAuth(USERNAME, PASSWORD)
    headers = {'Content-Type': 'application/octet-stream'}
    
    # Exponential backoff retry logic
    delay = INITIAL_DELAY
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.put(
                upload_url,
                auth=auth,
                headers=headers,
                data=file_data,
                timeout=30
            )
            
            if response.status_code in [200, 201, 204]:
                nextcloud_path = f"{NEXTCLOUD_BASE_PATH}/{nextcloud_folder}/{filename}"
                print(f"  ☁️  Uploaded to Nextcloud: {nextcloud_path}")
                return nextcloud_path
            elif response.status_code == 429:
                # Rate limited
                wait_time = delay * (2 ** attempt)  # Exponential backoff
                if wait_time > MAX_DELAY:
                    wait_time = MAX_DELAY
                
                print(f"  ⚠️  Rate limited (429) on upload for {slug}. Attempt {attempt+1}/{MAX_RETRIES}. Waiting {wait_time}s...")
                time.sleep(wait_time)
                continue
            else:
                error_msg = f"Upload failed for {slug}: {response.status_code} {response.text[:100]}"
                print(f"  ❌ {error_msg}")
                logger.error(error_msg)
                return None
                
        except Exception as e:
            error_msg = f"Upload error for {slug} (attempt {attempt+1}): {e}"
            print(f"  ❌ {error_msg}")
            logger.error(error_msg)
            if attempt == MAX_RETRIES - 1:
                return None
            wait_time = delay * (2 ** attempt)
            time.sleep(wait_time)
    
    # All retries exhausted
    error_msg = f"Failed to upload {slug} after {MAX_RETRIES} attempts"
    print(f"  ❌ {error_msg}")
    logger.error(error_msg)
    return None

def create_share_link(file_path, slug, logger):
    """Create a public share link for a file in Nextcloud with retry logic."""
    share_api = f"{NEXTCLOUD_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares"
    
    headers = {
        'OCS-APIRequest': 'true',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    data = {
        'path': file_path,
        'shareType': 3,  # Public link
        'permissions': 1  # Read only
    }
    
    auth = HTTPBasicAuth(USERNAME, PASSWORD)
    
    # Exponential backoff retry logic
    delay = INITIAL_DELAY
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(share_api, auth=auth, headers=headers, json=data, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                share_url = result['ocs']['data']['url']
                print(f"  🔗 Share created: {share_url}")
                return share_url
            elif response.status_code == 429:
                # Rate limited
                wait_time = delay * (2 ** attempt)  # Exponential backoff
                if wait_time > MAX_DELAY:
                    wait_time = MAX_DELAY
                
                print(f"  ⚠️  Rate limited (429) for {slug}. Attempt {attempt+1}/{MAX_RETRIES}. Waiting {wait_time}s...")
                time.sleep(wait_time)
                continue
            else:
                error_msg = f"Share API failed for {slug}: {response.status_code}"
                print(f"  ⚠️ {error_msg}")
                logger.error(error_msg)
                return None
                
        except Exception as e:
            error_msg = f"Share creation error for {slug} (attempt {attempt+1}): {e}"
            print(f"  ⚠️ {error_msg}")
            logger.error(error_msg)
            if attempt == MAX_RETRIES - 1:
                return None
            wait_time = delay * (2 ** attempt)
            time.sleep(wait_time)
    
    # All retries exhausted
    error_msg = f"Failed to create share for {slug} after {MAX_RETRIES} attempts"
    print(f"  ❌ {error_msg}")
    logger.error(error_msg)
    return None

def generate_csv(products, output_dir):
    """Generate CSV file with all product information."""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_file = os.path.join(output_dir, f"product_images_enhanced_{timestamp}.csv")
    
    fieldnames = [
        'date_collected',
        'product_name',
        'product_url', 
        'image_url',
        'nextcloud_image_path',
        'nextcloud_share_url',
        'category',
        'generic_description_flag',
        'notes',
        'status'
    ]
    
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for product in products:
            status = "SUCCESS" if product['processed'] else "FAILED"
            row = {
                'date_collected': product['date_collected'],
                'product_name': product['product_name'],
                'product_url': product['product_url'],
                'image_url': product['image_url'],
                'nextcloud_image_path': product['nextcloud_path'] or '',
                'nextcloud_share_url': product['share_url'] or '',
                'category': product['category'],
                'generic_description_flag': 'Yes' if product['generic_description'] else 'No',
                'notes': product['notes'],
                'status': status
            }
            writer.writerow(row)
    
    print(f"📊 CSV generated: {csv_file}")
    return csv_file

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Enhanced product image collection with resume capability')
    parser.add_argument('--max-products', type=int, default=10,
                       help='Maximum number of products to process (default: 10)')
    parser.add_argument('--skip-processed', action='store_true', default=True,
                       help='Skip already processed products (default: True)')
    parser.add_argument('--force', action='store_true', default=False,
                       help='Force reprocessing of all products (ignore state)')
    parser.add_argument('--sitemap', type=str, default='sitemap_products.xml',
                       help='Path to sitemap XML file (default: sitemap_products.xml)')
    parser.add_argument('--output-dir', type=str, default=None,
                       help='Output directory for CSV files (default: script directory)')
    parser.add_argument('--max-retries', type=int, default=5,
                       help='Maximum retry attempts for API calls (default: 5)')
    parser.add_argument('--initial-delay', type=float, default=2.0,
                       help='Initial delay between retries in seconds (default: 2.0)')
    parser.add_argument('--max-delay', type=float, default=60.0,
                       help='Maximum delay between retries in seconds (default: 60.0)')
    parser.add_argument('--normal-delay', type=float, default=1.0,
                       help='Normal delay between products in seconds (default: 1.0)')
    
    args = parser.parse_args()
    
    # Update rate limiting configuration from command line
    global MAX_RETRIES, INITIAL_DELAY, MAX_DELAY, NORMAL_DELAY
    MAX_RETRIES = args.max_retries
    INITIAL_DELAY = args.initial_delay
    MAX_DELAY = args.max_delay
    NORMAL_DELAY = args.normal_delay
    
    # Setup
    print("=" * 70)
    print("ENHANCED PRODUCT IMAGE COLLECTION - SHOP BITCOIN AUSTRALIA")
    print("=" * 70)
    
    # Setup error logging
    logger = setup_error_logging()
    
    # Determine output directory
    if args.output_dir:
        output_dir = args.output_dir
        os.makedirs(output_dir, exist_ok=True)
    else:
        output_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load state
    state = load_state()
    print(f"📋 State: {len(state['processed_products'])} products previously processed")
    if state['last_processed_date']:
        print(f"📅 Last processed: {state['last_processed_date']}")
    
    # Step 1: Locate sitemap
    sitemap_path = args.sitemap
    if not os.path.exists(sitemap_path):
        # Try other locations
        alt_paths = [
            "../sitemap_products.xml",
            "/home/agent/.openclaw/workspace-shelley/sba-operations/sitemap_products.xml"
        ]
        for path in alt_paths:
            if os.path.exists(path):
                sitemap_path = path
                break
        else:
            print("❌ Could not find sitemap_products.xml")
            return
    
    print(f"Sitemap: {sitemap_path}")
    print(f"Nextcloud: {NEXTCLOUD_URL}")
    print(f"Local temp: {LOCAL_TEMP_DIR}")
    print(f"Batch size: {args.max_products}")
    print(f"Skip processed: {args.skip_processed}")
    print()
    
    # Step 2: Parse products
    skip_processed = args.skip_processed and not args.force
    products = parse_products(sitemap_path, max_products=args.max_products, 
                            skip_processed=skip_processed)
    
    if not products:
        print("ℹ️  No products found to process (all may already be processed)")
        return
    
    # Step 3: Process each product
    success_count = 0
    failure_count = 0
    
    for i, product in enumerate(products, 1):
        print(f"\n{'='*50}")
        print(f"PRODUCT {i}/{len(products)}: {product['product_name'][:70]}...")
        print(f"{'='*50}")
        
        print(f"📦 Category: {product['category']} → {product['nextcloud_folder']}")
        print(f"🔗 Product URL: {product['product_url']}")
        
        try:
            # Download
            local_path = download_image(product['image_url'], product['product_slug'], logger)
            if not local_path:
                product['error'] = 'Download failed'
                product['notes'] = 'Download failed'
                state = update_state(state, product['product_url'], success=False, error_msg='Download failed')
                failure_count += 1
                continue
            
            product['local_path'] = local_path
            
            # Upload to Nextcloud
            nextcloud_path = upload_to_nextcloud(
                local_path, 
                product['nextcloud_folder'], 
                product['product_slug'],
                logger
            )
            
            if not nextcloud_path:
                product['error'] = 'Upload failed'
                product['notes'] = 'Upload failed'
                state = update_state(state, product['product_url'], success=False, error_msg='Upload failed')
                failure_count += 1
                continue
            
            product['nextcloud_path'] = nextcloud_path
            
            # Create share link
            share_url = create_share_link(nextcloud_path, product['product_slug'], logger)
            product['share_url'] = share_url
            
            # Mark as processed
            product['processed'] = True
            success_count += 1
            
            # Update state with success
            state = update_state(state, product['product_url'], success=True)
            
            # Brief pause between products
            if i < len(products):
                time.sleep(NORMAL_DELAY)
                
        except Exception as e:
            error_msg = f"Unexpected error processing {product['product_slug']}: {e}"
            print(f"  ❌ {error_msg}")
            logger.error(error_msg)
            product['error'] = str(e)
            product['notes'] = f'Unexpected error: {e}'
            state = update_state(state, product['product_url'], success=False, error_msg=error_msg)
            failure_count += 1
    
    # Save state after processing
    save_state(state)
    
    # Step 4: Generate outputs
    print(f"\n{'='*50}")
    print("GENERATING OUTPUTS")
    print(f"{'='*50}")
    
    csv_file = generate_csv(products, output_dir)
    
    # Also save detailed JSON
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    json_file = os.path.join(output_dir, f"product_images_enhanced_{timestamp}.json")
    with open(json_file, 'w') as f:
        json.dump({
            'run_timestamp': datetime.now().isoformat(),
            'total_attempted': len(products),
            'success_count': success_count,
            'failure_count': failure_count,
            'batch_size': args.max_products,
            'products': products
        }, f, indent=2)
    
    print(f"💾 Detailed JSON: {json_file}")
    
    # Step 5: Display summary
    print(f"\n{'='*70}")
    print("ENHANCED RUN SUMMARY")
    print(f"{'='*70}")
    
    print(f"📊 Batch Statistics:")
    print(f"  ✅ Successfully processed: {success_count}")
    print(f"  ❌ Failed: {failure_count}")
    print(f"  ⏭️  Skipped (already processed): {len(state['processed_products']) - success_count - failure_count}")
    print(f"  📋 Total in state: {len(state['processed_products'])} products")
    
    if success_count > 0:
        print(f"\n📋 Successfully processed products:")
        for product in products:
            if product['processed'] and product['share_url']:
                print(f"  ✅ {product['product_name'][:60]}...")
                print(f"     🔗 {product['share_url']}")
    
    if failure_count > 0:
        print(f"\n⚠️ Failed products (see {ERROR_LOG_FILE} for details):")
        for product in products:
            if not product['processed']:
                print(f"  ❌ {product['product_name'][:60]}...")
                if product.get('error'):
                    print(f"     Error: {product['error'][:80]}")
    
    print(f"\n📁 Files created:")
    print(f"  • {csv_file}")
    print(f"  • {json_file}")
    print(f"  • Error log: {ERROR_LOG_FILE}")
    print(f"  • State file: {STATE_FILE}")
    
    print(f"\n🎯 NEXT STEPS:")
    print(f"  1. Review the CSV file")
    print(f"  2. Check Nextcloud for uploaded files")
    print(f"  3. Verify share links work")
    print(f"  4. Run again with larger batch or continue processing")
    if failure_count > 0:
        print(f"  5. Check error log for failed products: {ERROR_LOG_FILE}")
    
    print(f"\n{'='*70}")
    print("ENHANCED PROCESSING COMPLETE")
    print(f"{'='*70}")
    
    # Return success/failure count for scripting
    return success_count, failure_count

if __name__ == "__main__":
    main()