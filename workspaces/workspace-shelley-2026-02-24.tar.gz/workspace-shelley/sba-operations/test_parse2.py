#!/usr/bin/env python3
import xml.etree.ElementTree as ET

# Parse the sitemap
tree = ET.parse('sitemap_products.xml')
root = tree.getroot()

# Define namespace URIs
ns = {
    'sitemap': 'http://www.sitemaps.org/schemas/sitemap/0.9',
    'image': 'http://www.google.com/schemas/sitemap-image/1.1'
}

# Alternative: use full namespace in findall
# ElementTree requires {namespace}tag format

# First, let's see what the root tag is
print(f"Root tag: {root.tag}")

# Let's examine first child
for child in root[:5]:
    print(f"Child tag: {child.tag}")
    for sub in child:
        print(f"  Sub tag: {sub.tag}")
        if 'image' in sub.tag:
            for img_sub in sub:
                print(f"    Image sub tag: {img_sub.tag} -> {img_sub.text[:50] if img_sub.text else ''}")

print("\n--- Trying namespace approach ---")
# Find all url elements
# The default namespace is sitemap, so url elements are in that namespace
for url_elem in root.findall('{http://www.sitemaps.org/schemas/sitemap/0.9}url'):
    loc_elem = url_elem.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
    if loc_elem is None:
        continue
    
    url = loc_elem.text
    if url == "https://shopbitcoin.com.au/":
        continue
    
    # Find image element (in image namespace)
    image_elem = url_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}image')
    if image_elem is None:
        print(f"No image for {url}")
        continue
    
    image_loc = image_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}loc')
    image_title = image_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}title')
    
    print(f"Product: {url}")
    print(f"  Image: {image_loc.text if image_loc is not None else 'None'}")
    print(f"  Title: {image_title.text if image_title is not None else 'None'}")
    print()
    break  # Just first one