# Shop Bitcoin Australia - Product Catalog
## Comprehensive Inventory & Pricing Database

**Created**: 2026-02-15  
**Source**: Website analysis, previous knowledge  
**Status**: 🟡 PARTIAL DATA (needs verification)

---

## 📦 **Product Categories**

### **1. Solo Miners (Bitaxe Series)**
**Category**: `/collections/bitaxes`

| Product | Model | Price (AUD) | Description | Key Features |
|---------|-------|-------------|-------------|--------------|
| Bitaxe Gamma 601 | Complete Kit | $899 | The complete mining setup | Australian power supply, Dark Horse heatsink, FDM stand, tracked shipping |
| Bitaxe Gamma 602 | Core Unit | $295 | The core miner unit | 1.2Th, Australian-made stand, requires power supply & setup |
| NerdQaxe | Complete Kit | $799 | Alternative model | Similar to Gamma 601 with different specifications |

**Notes:**
- Australian power supply included with complete kits
- Local warranty (90 days)
- Australian-made FDM stands
- Tracked shipping included
- Requires network connection and Bitcoin wallet setup for block rewards

### **2. Hardware Wallets & Signers**
**Category**: Signers (assumed)

| Product | Type | Price Range | Notes |
|---------|------|-------------|-------|
| Coldcard | Hardware wallet | $XXX | Bitcoin-only, air-gapped signing |
| BitBox02 | Hardware wallet | $XXX | Swiss-made, Bitcoin-only option |
| Seedsigner | DIY signer | $XXX | Open-source, self-assembly |

**Status**: Need actual product listings and pricing

### **3. Bitcoin Nodes**
**Category**: Nodes (assumed)

| Product | Type | Price Range | Notes |
|---------|------|-------------|-------|
| Raspberry Pi setups | Node hardware | $XXX | Pre-configured Bitcoin nodes |
| Umbrel/Start9 | Node software | $XXX | One-click node deployment |

### **4. Miner Backup Kits**
**Category**: Backup components

| Product | Type | Price Range | Notes |
|---------|------|-------------|-------|
| Power supplies | Replacement/backup | $XXX | Australian-compliant power supplies |
| Heat sinks | Cooling | $XXX | Dark Horse and other brands |
| Network components | Connectivity | $XXX | Cables, adapters, switches |

### **5. Upgrades & Accessories**
**Category**: `/collections/upgrades-accessories`

| Product | Type | Price Range | Notes |
|---------|------|-------------|-------|
| Performance upgrades | Components | $9.95 - $49.95+ | Boost mining performance |
| Cases & stands | Physical accessories | $XXX | Australian-made FDM printed stands |
| Thermal solutions | Cooling | $XXX | Paste, pads, additional cooling |
| Connectivity kits | Network | $XXX | Cables, adapters |

### **6. Merchandise & Apparel**
**Category**: Bitcoin Hats, Shirts, Hoodies

| Product | Type | Price Range | Notes |
|---------|------|-------------|-------|
| Hats | Apparel | $XXX | Bitcoin-branded headwear |
| T-shirts | Apparel | $XXX | Bitcoin-themed clothing |
| Hoodies | Apparel | $XXX | Premium outerwear |
| Stickers & pins | Accessories | $XXX | Brand merchandise |

---

## 💰 **Pricing Analysis**

### **Competitive Positioning**
- **Bitaxe Gamma 602**: $295 AUD
- **Competitor (Solo Satoshi)**: ~$105 USD (~$148 AUD before import costs)
- **Competitor (AliExpress)**: $90-144 USD (~$127-204 AUD)
- **Value Proposition**: Australian support, local warranty, compatibility, community

### **Price Components**
1. **Product Cost**: Hardware components
2. **Australian Compliance**: Power supply certification
3. **Local Manufacturing**: FDM stands, assembly
4. **Warranty & Support**: 90-day local support
5. **Shipping**: Tracked domestic shipping
6. **Community Value**: Ecosystem integration

### **Margin Analysis**
*Need actual cost data for margin calculation*

---

## 📊 **Inventory Management**

### **Stock Levels**
*Need current inventory data*

### **Supplier Information**
*Need supplier contacts and lead times*

### **Reorder Points**
*Need historical sales data for demand forecasting*

---

## 🚚 **Shipping & Fulfillment**

### **Domestic (Australia)**
- **Carrier**: Australia Post (assumed)
- **Service**: Tracked shipping (included in price)
- **Delivery Time**: 2-7 business days (estimated)
- **Cost**: Built into product pricing

### **International**
*Need international shipping policy*

### **Packaging**
- Australian-made stands
- Australian power supplies
- Documentation and guides
- Branded packaging (assumed)

---

## 🛒 **Customer Journey**

### **Product Discovery**
1. Website browsing (`shopbitcoin.com.au`)
2. Category navigation (Bitaxe, Signers, Nodes, etc.)
3. Product comparison
4. Value assessment (Australian vs import)

### **Purchase Process**
1. Add to cart
2. Checkout (payment options unknown)
3. Order confirmation
4. Fulfillment notification
5. Delivery tracking
6. Setup support

### **Post-Purchase Support**
1. Setup assistance (guides, tutorials)
2. Technical support
3. Warranty claims
4. Community integration (events, resources)

---

## 🔍 **Data Gaps & Research Needs**

### **Immediate Information Needs:**
1. **Complete product listings** with actual prices and SKUs
2. **Inventory status** for each product
3. **Supplier details** and lead times
4. **Shipping costs** and carrier contracts
5. **Payment methods** accepted
6. **Customer support** channels and response times

### **Research Methods:**
1. **Website scraping** of all product pages
2. **Inventory API** access (if available)
3. **Supplier communication** (if authorized)
4. **Sales data analysis** (if accessible)
5. **Customer feedback review** (social media, reviews)

### **Automation Opportunities:**
1. **Price monitoring** against competitors
2. **Inventory tracking** and alerting
3. **Sales trend analysis**
4. **Customer segmentation**
5. **Automated reordering**

---

## 📈 **Performance Metrics**

### **Product-Level Metrics:**
- **Sales Volume**: Units sold per time period
- **Revenue Contribution**: Percentage of total revenue
- **Profit Margin**: Gross and net margins
- **Customer Satisfaction**: Reviews and returns
- **Inventory Turnover**: Rate of stock movement

### **Category Performance:**
- **Bitaxe Series**: Primary revenue driver
- **Accessories**: High-margin add-ons
- **Merchandise**: Brand building and community
- **Nodes/Signers**: Ecosystem expansion

---

## 🔄 **Update Schedule**

### **Daily:**
- Check stock levels for low inventory
- Monitor competitor pricing changes
- Track sales performance

### **Weekly:**
- Update pricing based on market analysis
- Review inventory and reorder needs
- Analyze product performance trends

### **Monthly:**
- Comprehensive catalog review
- Supplier performance evaluation
- Strategic pricing adjustments
- New product research and planning

---

**Catalog Status**: 🟡 PARTIAL DATA  
**Next Update**: Complete product data extraction  
**Priority**: High (foundation for autonomous operations)

*This document will be continuously updated as more information becomes available.*