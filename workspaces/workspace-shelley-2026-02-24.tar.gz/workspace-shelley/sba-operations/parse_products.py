#!/usr/bin/env python3
"""
Parse product sitemap XML to extract product information.
"""

import xml.etree.ElementTree as ET
import json
import re
from urllib.parse import urlparse

# Sample XML content from sitemap (truncated in actual response)
# For now, let's manually extract from the text we have

def extract_from_text(text):
    """Extract product information from sitemap text."""
    products = []
    
    # Find all product URLs
    product_urls = re.findall(r'<loc>https://shopbitcoin\.com\.au/products/([^<]+)</loc>', text)
    
    # Find image titles
    image_titles = re.findall(r'<image:title>([^<]+)</image:title>', text)
    
    # Pair them up (simplistic - assumes order matches)
    for i, url in enumerate(product_urls):
        if i < len(image_titles):
            title = image_titles[i]
        else:
            # Extract product name from URL as fallback
            title = url.replace('-', ' ').title()
        
        # Clean up HTML entities
        title = title.replace('&amp;', '&').replace('&apos;', "'")
        
        # Categorize based on URL/name patterns
        category = categorize_product(url, title)
        
        products.append({
            'url': f'https://shopbitcoin.com.au/products/{url}',
            'slug': url,
            'title': title,
            'category': category,
            'id': f'prod_{i+1:03d}'
        })
    
    return products

def categorize_product(url, title):
    """Categorize product based on URL patterns and title."""
    url_lower = url.lower()
    title_lower = title.lower()
    
    # Bitaxe/mining related
    if any(term in url_lower or term in title_lower for term in ['bitaxe', 'miner', 'mining', 'nerdminer', 'lottery']):
        return 'mining'
    
    # SeedSigner/seed related
    elif any(term in url_lower or term in title_lower for term in ['seedsigner', 'seed', 'stamp', 'backup', 'hammer', 'seedsleeve']):
        return 'seed_management'
    
    # Hardware wallets/signers
    elif any(term in url_lower or term in title_lower for term in ['coldcard', 'signer', 'hardware']):
        return 'hardware_wallets'
    
    # Nodes
    elif any(term in url_lower or term in title_lower for term in ['node', 'raspberry', 'pi', 'blockclock', 'lnbits']):
        return 'nodes_network'
    
    # Apparel - hats
    elif any(term in url_lower or term in title_lower for term in ['cap', 'hat', 'beanie', 'visor', 'bucket']):
        return 'apparel_hats'
    
    # Apparel - shirts
    elif any(term in url_lower or term in title_lower for term in ['tee', 'shirt', 'polo', 'adidas', 'hoodie', 'sweatshirt']):
        return 'apparel_shirts'
    
    # Apparel - hoodies
    elif 'hoodie' in url_lower or 'hoodie' in title_lower:
        return 'apparel_hoodies'
    
    # Mugs
    elif 'mug' in url_lower or 'mug' in title_lower:
        return 'mugs'
    
    # Water bottles
    elif 'water' in url_lower or 'bottle' in title_lower:
        return 'bottles'
    
    # Accessories
    elif any(term in url_lower or term in title_lower for term in ['case', 'stand', 'cover', 'sign', 'sticker', 'coaster', 'patch', 'kit']):
        return 'accessories'
    
    # Food/drink
    elif any(term in url_lower or term in title_lower for term in ['honey', 'coffee', 'tea']):
        return 'food_drink'
    
    else:
        return 'other'

def main():
    # Read the sitemap text from file or use provided text
    # For now, we'll assume the text is in a file
    import sys
    
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r') as f:
            text = f.read()
    else:
        # Use a sample (truncated from earlier response)
        print("Please provide sitemap XML file as argument")
        return
    
    products = extract_from_text(text)
    
    # Group by category
    by_category = {}
    for product in products:
        category = product['category']
        if category not in by_category:
            by_category[category] = []
        by_category[category].append(product)
    
    # Print summary
    print(f"📊 Found {len(products)} products in {len(by_category)} categories")
    print("\n📦 Categories:")
    for category, items in sorted(by_category.items()):
        print(f"  {category}: {len(items)} products")
    
    # Save to JSON
    output_file = 'products_extracted.json'
    with open(output_file, 'w') as f:
        json.dump({
            'total_products': len(products),
            'categories': by_category,
            'products': products
        }, f, indent=2)
    
    print(f"\n💾 Saved to {output_file}")
    
    # Generate markdown table for catalog
    print("\n📋 Sample products by category:")
    for category, items in sorted(by_category.items()):
        print(f"\n## {category.replace('_', ' ').title()} ({len(items)})")
        print("| Title | URL Slug |")
        print("|-------|----------|")
        for product in items[:5]:  # First 5 per category
            print(f"| {product['title'][:50]}... | `{product['slug'][:30]}...` |")
        if len(items) > 5:
            print(f"| ... and {len(items)-5} more | ... |")

if __name__ == "__main__":
    main()