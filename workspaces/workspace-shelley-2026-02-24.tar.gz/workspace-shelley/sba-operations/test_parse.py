#!/usr/bin/env python3
import xml.etree.ElementTree as ET

# Parse the sitemap
tree = ET.parse('sitemap_products.xml')
root = tree.getroot()

# Define namespaces
namespaces = {
    'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9',
    'image': 'http://www.google.com/schemas/sitemap-image/1.1'
}

# Register namespaces
for prefix, uri in namespaces.items():
    ET.register_namespace(prefix, uri)

# Test: find first product URL with image
count = 0
for url_elem in root.findall('ns:url', namespaces):
    loc_elem = url_elem.find('ns:loc', namespaces)
    if loc_elem is None:
        continue
    
    url = loc_elem.text
    if url == "https://shopbitcoin.com.au/":
        continue
    
    image_elem = url_elem.find('image:image', namespaces)
    if image_elem is None:
        continue
    
    image_loc = image_elem.find('image:loc', namespaces)
    image_title = image_elem.find('image:title', namespaces)
    
    print(f"Product URL: {url}")
    print(f"Image URL: {image_loc.text if image_loc else 'None'}")
    print(f"Image Title: {image_title.text if image_title else 'None'}")
    print()
    
    count += 1
    if count >= 3:
        break

print(f"Found {count} products with images")