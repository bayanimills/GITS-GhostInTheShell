#!/usr/bin/env python3
import requests
from requests.auth import HTTPBasicAuth
import json

USERNAME = "jarvis"
PASSWORD = "agent12345jarvis"
NEXTCLOUD_URL = "https://nextcloud.blkstr.io"

# Test 1: Check if sharing API is available
print("Testing Nextcloud sharing API...")

# First, let's see what's in the Collections/Accessories folder
webdav_url = f"{NEXTCLOUD_URL}/remote.php/dav/files/jarvis/_private/businesses/Bayani%20Enterprises/SBA%20-%20ShopBitcoin/Collections/Accessories"
auth = HTTPBasicAuth(USERNAME, PASSWORD)

resp = requests.request(
    'PROPFIND',
    webdav_url,
    auth=auth,
    headers={'Depth': '1', 'Content-Type': 'text/xml'},
    timeout=10
)

print(f"WebDAV status: {resp.status_code}")
if resp.status_code == 207:
    print("✅ WebDAV access works")
    
    # Parse response to see files
    import xml.etree.ElementTree as ET
    root = ET.fromstring(resp.content)
    ns = {'d': 'DAV:'}
    files = []
    for response in root.findall('.//d:response', ns):
        href = response.find('.//d:href', ns)
        if href is not None:
            path = href.text
            if path and not path.endswith('/Accessories'):
                files.append(path.split('/')[-1])
    
    print(f"Found {len(files)} files in Accessories folder")
    if files:
        print(f"Sample files: {files[:3]}")
        
        # Test sharing on first file if exists
        test_file = files[0]
        print(f"\nTesting share API for file: {test_file}")
        
        # Need full path relative to user's files
        file_path = f"/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Collections/Accessories/{test_file}"
        
        share_api = f"{NEXTCLOUD_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares"
        headers = {
            'OCS-APIRequest': 'true',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        data = {
            'path': file_path,
            'shareType': 3,  # Public link
            'permissions': 1  # Read only
        }
        
        resp = requests.post(
            share_api,
            auth=auth,
            headers=headers,
            json=data,
            timeout=10
        )
        
        print(f"Share API status: {resp.status_code}")
        print(f"Response: {resp.text[:500]}")
        
        if resp.status_code == 200:
            result = resp.json()
            print(f"Share created: {result}")
        else:
            print("Share API may not be available or requires different authentication")
    else:
        print("No files to test sharing")
else:
    print("❌ WebDAV access failed")