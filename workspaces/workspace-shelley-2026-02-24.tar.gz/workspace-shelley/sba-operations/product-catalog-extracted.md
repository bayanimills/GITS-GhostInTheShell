# Shop Bitcoin Australia - Product Catalog (Extracted)
## Based on Website Sitemap Analysis (2026-02-15)

**Total Products**: 109  
**Categories**: 10  
**Source**: `https://shopbitcoin.com.au/sitemap_products_1.xml`  
**Extraction Date**: 2026-02-15  
**Status**: ✅ COMPLETE LISTING (no pricing data)

---

## 📊 **Category Summary**

| Category | Product Count | Description |
|----------|---------------|-------------|
| **Apparel (Shirts)** | 33 | T-shirts, polos, women's tees, youth tees |
| **Apparel (Hats)** | 18 | Caps, beanies, trucker hats, visors |
| **Seed Management** | 17 | SeedSigner cases, seed stamps, backup kits, SeedHammer |
| **Mugs** | 12 | Bitcoin-themed mugs (various designs) |
| **Nodes & Network** | 10 | Raspberry Pi, displays, LNBits, BlockClock stands |
| **Accessories** | 7 | Signs, stickers, patches, cases, coasters |
| **Bottles** | 5 | Water bottles (various Bitcoin designs) |
| **Mining** | 1 | Lottery Miner - Nerdminer V2 |
| **Food & Drink** | 1 | Honey - 100% Australian |
| **Other** | 5 | Unclassified products |

---

## 🔍 **Key Product Highlights**

### **1. Seed Management (17 products)**
**Core Products:**
- **SeedSigner Cases**: Orange Pill, Open Pill, GoBrrr Rugged Pill
- **Seed Stamps**: Blockmit Jig & Washer sets, 316 SS washer sets
- **SeedHammer**: Machine, plate kits, controller
- **SeedOR**: Safe and backup kits
- **Entropia**: Seed Tablets (Aussie Edition)
- **SeedSleeve**: Seed storage solution

**Importance**: Comprehensive seed backup and security product line.

### **2. Apparel - Shirts (33 products)**
**Categories:**
- **Men's Tees**: Bitcoin Payment Rails, DCA BTC, Print Books Not Money, Cursive, Stack Sats
- **Women's Tees**: Vires In Numeris, Natural BTC, Cursive Bitcoin, Raw Genesis, HODL, Stack Sats
- **Youth Tees**: Satoshi's Little Helper, Hodlnaut
- **Polos**: Adidas HODL Polo, Adidas Bitcoin Polo
- **Sydney-themed**: Bitcoin Sydney Tee, BTCSYD Tee, Bitcoin Sydney Sleeve Tee

**Note**: Extensive apparel line with local (Sydney) and general Bitcoin themes.

### **3. Apparel - Hats (18 products)**
**Types:**
- **Caps**: Est. 2009, Pleb Bitcoin, BullishAF, HODL, Light OpSec, Stack Sats
- **Beanies**: Cursive Waffle, Stack Sats, HODL, Viva La Bitcoin, Bitcoin Zap
- **Trucker Caps**: Pleb, Lightning Zap
- **Specialty**: Bitcoin Bucket Hat, Bitcoin Golf Visor

### **4. Mugs (12 products)**
**Designs**: Bitcoin Genesis, Triple Cat, Hope 21 Stars, Abstract, Monetary Psychopath, Pink Bitcoin, Bitcoin DMS, Twin Lucky Cat, There is no Second Best, #1 In Money, FSC Buy Bitcoin, Wrench Attack, Stacked Bitcoin, Bitcoin Piggy Bank

**Note**: Diverse mug designs covering various Bitcoin memes and themes.

### **5. Nodes & Network (10 products)**
**Components:**
- **Displays**: Lilygo T-Display 1.14, Waveshare Pi Zero LCD Hat
- **POS Systems**: LNBits POS/ATM Case, LNURLPoS with keyboard
- **Node Hardware**: Bitcoin Nodebox, Raspberry Pi Zero
- **Stands**: Blockclock Mini Stand
- **Accessories**: TTGO T-Display

### **6. Bottles (5 products)**
**Designs**: Bitcoin Water bottle, Bitcoin Wordmark, HFSP, POW - Proof of Work, Bitcoin Payments

### **7. Mining (1 product)**
**Product**: Lottery Miner - Nerdminer V2 (S9 Model)

**Note**: Only one mining product found in sitemap. Bitaxe products may be in separate collection or not in sitemap.

---

## 🔗 **Missing from Sitemap (Based on Known Inventory)**

### **Likely Missing Products:**
1. **Bitaxe Gamma Series** (601, 602) - Primary mining products
2. **NerdQaxe** - Alternative miner
3. **Hardware Wallets** (Coldcard, BitBox02) - May be sold but not in sitemap
4. **Complete Node Kits** - Umbrel/Start9 setups
5. **Power Supplies & Accessories** - Miner backup components

### **Possible Reasons:**
- Products in separate sitemap (collections)
- Products not individually listed (sold as variants)
- Products out of stock or removed from sitemap
- Sitemap incomplete (truncated response)

---

## 📈 **Business Insights**

### **Product Mix Analysis:**
- **Apparel Dominance**: 51 products (47% of catalog) - high-margin, brand-building
- **Seed Security Focus**: 17 products (16%) - specialized niche, high value
- **Drinkware**: 17 products (16%) - mugs + bottles, impulse purchase items
- **Nodes/Network**: 10 products (9%) - technical audience, ecosystem building
- **Mining**: Currently minimal (1 product) - potential growth area

### **Australian Focus:**
- **Local Themes**: Sydney-themed apparel, Australian honey
- **Local Manufacturing**: FDM stands (mentioned for Bitaxe)
- **Community Support**: Event promotion (BitcoinAlive 2026)

### **Price Points Needed:**
To complete analysis, need:
1. Actual pricing for all products
2. Inventory levels
3. Sales velocity data
4. Margin calculations

---

## 🛠️ **Data Collection Next Steps**

### **Immediate Actions:**
1. **Scrape Product Pages** for pricing and descriptions
2. **Check Collections Sitemap** for Bitaxe products
3. **API Integration** with Shopify if available
4. **Manual Review** of key product pages

### **Automation Opportunities:**
1. **Price Monitoring** against competitors
2. **Inventory Tracking** alerts
3. **Sales Trend Analysis**
4. **Customer Preference Tracking**

---

## 📝 **Notes for Social Media Content**

### **Product Categories for Promotion:**
1. **Bitaxe Series** (when available) - primary revenue driver
2. **Seed Management** - educational content, security focus
3. **Apparel** - lifestyle content, Australian Bitcoin community
4. **Mugs/Drinkware** - gift ideas, daily use products
5. **Nodes** - technical audience, network support

### **Content Themes:**
- **Security**: Seed backup, hardware wallets
- **Lifestyle**: Wearing Bitcoin, daily use items
- **Technical**: Mining, node operation
- **Community**: Australian events, local businesses
- **Education**: How-to guides, setup tutorials

---

**Catalog Status**: ✅ EXTRACTED (structure complete)  
**Pricing Status**: 🔴 MISSING (critical gap)  
**Next Update**: Scrape product pages for pricing data  
**Priority**: High for autonomous operations