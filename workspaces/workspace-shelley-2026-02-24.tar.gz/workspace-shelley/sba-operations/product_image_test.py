#!/usr/bin/env python3
"""
Product Image Collection Test
Processes 2-3 products to validate the complete workflow:
1. Parse sitemap for product details
2. Download images from Shopify CDN
3. Upload to Nextcloud Collections folder
4. Create shareable links
5. Generate tracking CSV with required fields
"""

import xml.etree.ElementTree as ET
import requests
import csv
import os
import sys
import time
from datetime import datetime
from urllib.parse import urlparse, quote
import json
from requests.auth import HTTPBasicAuth

# ===== CONFIGURATION =====
NEXTCLOUD_URL = "https://nextcloud.blkstr.io"
USERNAME = "jarvis"
PASSWORD = "agent12345jarvis"

# WebDAV base URL
WEBDAV_BASE = f"{NEXTCLOUD_URL}/remote.php/dav/files/jarvis"

# Target folder in Nextcloud
NEXTCLOUD_BASE_PATH = "/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Collections"

# Local temporary directory
LOCAL_TEMP_DIR = "/tmp/sba_product_images_test"
os.makedirs(LOCAL_TEMP_DIR, exist_ok=True)

# XML namespaces
NAMESPACES = {
    'sitemap': 'http://www.sitemaps.org/schemas/sitemap/0.9',
    'image': 'http://www.google.com/schemas/sitemap-image/1.1'
}

# Category to Nextcloud folder mapping
CATEGORY_MAPPING = {
    'accessories': 'Accessories',
    'apparel_hats': 'Clothing & Bags',
    'apparel_shirts': 'Clothing & Bags', 
    'apparel_hoodies': 'Clothing & Bags',
    'mining': 'Accessories',  # Default to Accessories
    'seed_management': 'Accessories',
    'hardware_wallets': 'Accessories',
    'nodes_network': 'Accessories',
    'mugs': 'Accessories',
    'bottles': 'Accessories',
    'food_drink': 'Accessories',
    'other': 'Accessories'
}

# Generic description detection terms
GENERIC_TERMS = ['product', 'item', 'goods', 'merchandise', 'buy now', 'for sale']

# ===== CORE FUNCTIONS =====

def parse_products(xml_file, max_products=3):
    """
    Parse sitemap XML and extract product information.
    Returns list of product dictionaries.
    """
    print(f"📄 Parsing sitemap: {xml_file}")
    
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    products = []
    product_count = 0
    
    # Find all <url> elements
    for url_elem in root.findall('{http://www.sitemaps.org/schemas/sitemap/0.9}url'):
        # Get product URL
        loc_elem = url_elem.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
        if loc_elem is None:
            continue
        
        product_url = loc_elem.text
        if product_url == "https://shopbitcoin.com.au/":
            continue  # Skip homepage
        
        # Get image information
        image_elem = url_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}image')
        if image_elem is None:
            continue  # Skip products without images
        
        image_loc = image_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}loc')
        image_title = image_elem.find('{http://www.google.com/schemas/sitemap-image/1.1}title')
        
        if image_loc is None:
            continue
        
        # Extract product slug from URL
        slug = product_url.replace('https://shopbitcoin.com.au/products/', '')
        
        # Get product name (from image title or slug)
        if image_title is not None and image_title.text:
            product_name = image_title.text
        else:
            # Fallback: generate name from slug
            product_name = slug.replace('-', ' ').title()
        
        # Clean up product name
        product_name = product_name.replace('&amp;', '&').replace('&apos;', "'")
        
        # Determine category
        category = categorize_product(slug, product_name)
        
        # Create product record
        product = {
            'date_collected': datetime.now().strftime('%Y-%m-%d'),
            'product_name': product_name,
            'product_url': product_url,
            'product_slug': slug,
            'image_url': image_loc.text,
            'category': category,
            'nextcloud_folder': CATEGORY_MAPPING.get(category, 'Accessories'),
            'local_path': None,
            'nextcloud_path': None,
            'share_url': None,
            'generic_description': False,
            'notes': '',
            'processed': False
        }
        
        # Check for generic description
        if any(term in product_name.lower() for term in GENERIC_TERMS):
            product['generic_description'] = True
            product['notes'] = 'Generic description detected'
        
        products.append(product)
        product_count += 1
        
        if product_count >= max_products:
            break
    
    print(f"   Found {len(products)} products for processing")
    return products

def categorize_product(slug, name):
    """Categorize product based on slug and name patterns."""
    slug_lower = slug.lower()
    name_lower = name.lower()
    
    # Bitaxe/mining
    if any(term in slug_lower or term in name_lower for term in ['bitaxe', 'miner', 'mining', 'nerdminer', 'lottery']):
        return 'mining'
    
    # SeedSigner/seed
    elif any(term in slug_lower or term in name_lower for term in ['seedsigner', 'seed', 'stamp', 'backup', 'hammer', 'seedsleeve']):
        return 'seed_management'
    
    # Hardware wallets
    elif any(term in slug_lower or term in name_lower for term in ['coldcard', 'signer', 'hardware', 'wallet']):
        return 'hardware_wallets'
    
    # Nodes
    elif any(term in slug_lower or term in name_lower for term in ['node', 'raspberry', 'pi', 'blockclock', 'lnbits']):
        return 'nodes_network'
    
    # Apparel
    elif any(term in slug_lower or term in name_lower for term in ['cap', 'hat', 'beanie', 'visor', 'bucket', 'tee', 'shirt', 'polo', 'adidas', 'hoodie', 'sweatshirt']):
        if 'hoodie' in slug_lower or 'hoodie' in name_lower:
            return 'apparel_hoodies'
        elif any(term in slug_lower or term in name_lower for term in ['cap', 'hat', 'beanie', 'visor', 'bucket']):
            return 'apparel_hats'
        else:
            return 'apparel_shirts'
    
    # Other categories
    elif 'mug' in slug_lower or 'mug' in name_lower:
        return 'mugs'
    elif 'water' in slug_lower or 'bottle' in name_lower:
        return 'bottles'
    elif any(term in slug_lower or term in name_lower for term in ['honey', 'coffee', 'tea']):
        return 'food_drink'
    elif any(term in slug_lower or term in name_lower for term in ['case', 'stand', 'cover', 'sign', 'sticker', 'coaster', 'patch', 'kit']):
        return 'accessories'
    else:
        return 'other'

def download_image(image_url, slug):
    """Download image from URL to local temporary directory."""
    try:
        # Extract filename
        parsed = urlparse(image_url)
        filename = os.path.basename(parsed.path)
        
        # Clean filename: remove query parameters, use slug as prefix
        clean_name = f"{slug}_{filename.split('?')[0]}"
        # Remove unsafe characters
        clean_name = ''.join(c for c in clean_name if c.isalnum() or c in '._-')
        
        local_path = os.path.join(LOCAL_TEMP_DIR, clean_name)
        
        print(f"  ⬇️  Downloading image...")
        response = requests.get(image_url, timeout=30)
        response.raise_for_status()
        
        with open(local_path, 'wb') as f:
            f.write(response.content)
        
        file_size = os.path.getsize(local_path) / 1024  # KB
        print(f"  ✅ Downloaded: {clean_name} ({file_size:.1f} KB)")
        return local_path
        
    except Exception as e:
        print(f"  ❌ Download failed: {e}")
        return None

def upload_to_nextcloud(local_path, nextcloud_folder, slug):
    """Upload file to Nextcloud via WebDAV."""
    try:
        # Prepare filename
        filename = os.path.basename(local_path)
        
        # URL encode the path
        encoded_folder = quote(nextcloud_folder, safe='')
        encoded_filename = quote(filename, safe='')
        
        # WebDAV URL
        upload_url = f"{WEBDAV_BASE}{NEXTCLOUD_BASE_PATH}/{encoded_folder}/{encoded_filename}"
        
        # Read file
        with open(local_path, 'rb') as f:
            file_data = f.read()
        
        # PUT request
        auth = HTTPBasicAuth(USERNAME, PASSWORD)
        headers = {'Content-Type': 'application/octet-stream'}
        
        response = requests.put(
            upload_url,
            auth=auth,
            headers=headers,
            data=file_data,
            timeout=30
        )
        
        if response.status_code in [200, 201, 204]:
            nextcloud_path = f"{NEXTCLOUD_BASE_PATH}/{nextcloud_folder}/{filename}"
            print(f"  ☁️  Uploaded to Nextcloud: {nextcloud_path}")
            return nextcloud_path
        else:
            print(f"  ❌ Upload failed: {response.status_code} {response.text[:100]}")
            return None
            
    except Exception as e:
        print(f"  ❌ Upload error: {e}")
        return None

def create_share_link(file_path):
    """Create a public share link for a file in Nextcloud."""
    try:
        share_api = f"{NEXTCLOUD_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares"
        
        headers = {
            'OCS-APIRequest': 'true',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        data = {
            'path': file_path,
            'shareType': 3,  # Public link
            'permissions': 1  # Read only
        }
        
        auth = HTTPBasicAuth(USERNAME, PASSWORD)
        response = requests.post(share_api, auth=auth, headers=headers, json=data, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            share_url = result['ocs']['data']['url']
            print(f"  🔗 Share created: {share_url}")
            return share_url
        else:
            print(f"  ⚠️ Share API failed: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"  ⚠️ Share creation error: {e}")
        return None

def generate_csv(products, output_dir):
    """Generate CSV file with all product information."""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_file = os.path.join(output_dir, f"product_images_{timestamp}.csv")
    
    fieldnames = [
        'date_collected',
        'product_name',
        'product_url', 
        'image_url',
        'nextcloud_image_path',
        'nextcloud_share_url',
        'category',
        'generic_description_flag',
        'notes'
    ]
    
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for product in products:
            row = {
                'date_collected': product['date_collected'],
                'product_name': product['product_name'],
                'product_url': product['product_url'],
                'image_url': product['image_url'],
                'nextcloud_image_path': product['nextcloud_path'] or '',
                'nextcloud_share_url': product['share_url'] or '',
                'category': product['category'],
                'generic_description_flag': 'Yes' if product['generic_description'] else 'No',
                'notes': product['notes']
            }
            writer.writerow(row)
    
    print(f"📊 CSV generated: {csv_file}")
    
    # Also save detailed JSON
    json_file = os.path.join(output_dir, f"product_images_{timestamp}.json")
    with open(json_file, 'w') as f:
        json.dump({
            'test_timestamp': datetime.now().isoformat(),
            'products_processed': len([p for p in products if p['processed']]),
            'products': products
        }, f, indent=2)
    
    print(f"💾 Detailed JSON: {json_file}")
    return csv_file, json_file

def main():
    print("=" * 60)
    print("SHOP BITCOIN AUSTRALIA - PRODUCT IMAGE COLLECTION TEST")
    print("=" * 60)
    
    # Step 1: Locate sitemap
    sitemap_path = "sitemap_products.xml"
    if not os.path.exists(sitemap_path):
        # Try other locations
        alt_paths = [
            "../sitemap_products.xml",
            "/home/agent/.openclaw/workspace-shelley/sba-operations/sitemap_products.xml"
        ]
        for path in alt_paths:
            if os.path.exists(path):
                sitemap_path = path
                break
        else:
            print("❌ Could not find sitemap_products.xml")
            return
    
    print(f"Sitemap: {sitemap_path}")
    print(f"Nextcloud: {NEXTCLOUD_URL}")
    print(f"Local temp: {LOCAL_TEMP_DIR}")
    print()
    
    # Step 2: Parse products (limit to 2 for test)
    products = parse_products(sitemap_path, max_products=2)
    
    if not products:
        print("❌ No products found with images")
        return
    
    # Step 3: Process each product
    success_count = 0
    for i, product in enumerate(products, 1):
        print(f"\n{'='*40}")
        print(f"PRODUCT {i}: {product['product_name'][:60]}...")
        print(f"{'='*40}")
        
        print(f"📦 Category: {product['category']} → {product['nextcloud_folder']}")
        print(f"🔗 Product URL: {product['product_url']}")
        print(f"🖼️  Image URL: {product['image_url'][:80]}...")
        
        # Download
        local_path = download_image(product['image_url'], product['product_slug'])
        if not local_path:
            product['notes'] = 'Download failed'
            continue
        
        product['local_path'] = local_path
        
        # Upload to Nextcloud
        nextcloud_path = upload_to_nextcloud(
            local_path, 
            product['nextcloud_folder'], 
            product['product_slug']
        )
        
        if not nextcloud_path:
            product['notes'] = 'Upload failed'
            continue
        
        product['nextcloud_path'] = nextcloud_path
        
        # Create share link
        share_url = create_share_link(nextcloud_path)
        product['share_url'] = share_url
        
        # Mark as processed
        product['processed'] = True
        success_count += 1
        
        # Brief pause between products
        if i < len(products):
            time.sleep(1)
    
    # Step 4: Generate outputs
    print(f"\n{'='*40}")
    print("GENERATING OUTPUTS")
    print(f"{'='*40}")
    
    output_dir = os.path.dirname(os.path.abspath(__file__))
    csv_file, json_file = generate_csv(products, output_dir)
    
    # Step 5: Display summary
    print(f"\n{'='*60}")
    print("TEST SUMMARY")
    print(f"{'='*60}")
    print(f"✅ Products attempted: {len(products)}")
    print(f"✅ Successfully processed: {success_count}")
    
    if success_count > 0:
        print(f"\n📋 Processed products:")
        for product in products:
            if product['processed']:
                status = "✅" if product['share_url'] else "⚠️"
                print(f"  {status} {product['product_name'][:50]}...")
                if product['share_url']:
                    print(f"     🔗 {product['share_url']}")
        
        print(f"\n📁 Files created:")
        print(f"  • {csv_file}")
        print(f"  • {json_file}")
        print(f"  • Local images: {LOCAL_TEMP_DIR}/")
        
        print(f"\n🎯 NEXT STEPS:")
        print(f"  1. Review the CSV file")
        print(f"  2. Check Nextcloud for uploaded files")
        print(f"  3. Verify share links work")
        print(f"  4. Scale up to process all products")
    else:
        print(f"\n❌ No products were successfully processed")
        print(f"   Check errors above and fix before scaling up")
    
    print(f"\n{'='*60}")
    print("TEST COMPLETE")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()