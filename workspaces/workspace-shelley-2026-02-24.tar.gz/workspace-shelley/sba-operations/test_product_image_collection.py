#!/usr/bin/env python3
"""
Test script for product image collection process.
Processes 2-3 products to validate the workflow.
"""

import xml.etree.ElementTree as ET
import requests
import csv
import os
import sys
import time
from datetime import datetime
from urllib.parse import urlparse, unquote
import json

# Configuration
NEXTCLOUD_URL = "https://nextcloud.blkstr.io"
WEBDAV_BASE = f"{NEXTCLOUD_URL}/remote.php/dav/files/jarvis"
USERNAME = "jarvis"
PASSWORD = "agent12345jarvis"

# Target folder in Nextcloud
NEXTCLOUD_TARGET_BASE = "/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Collections"

# Local temporary directory for downloads
LOCAL_TEMP_DIR = "/tmp/sba_product_images"
os.makedirs(LOCAL_TEMP_DIR, exist_ok=True)

def parse_sitemap(xml_file, max_products=3):
    """
    Parse sitemap XML to extract product information.
    Returns list of dicts with product details.
    """
    namespaces = {
        'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9',
        'image': 'http://www.google.com/schemas/sitemap-image/1.1'
    }
    
    # Register namespaces for parsing
    for prefix, uri in namespaces.items():
        ET.register_namespace(prefix, uri)
    
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    products = []
    
    # Find all product URLs (skip homepage)
    for url_elem in root.findall('ns:url', namespaces):
        loc_elem = url_elem.find('ns:loc', namespaces)
        if loc_elem is None:
            continue
        
        product_url = loc_elem.text
        # Skip homepage
        if product_url == "https://shopbitcoin.com.au/":
            continue
        
        # Extract product slug from URL
        slug = product_url.replace('https://shopbitcoin.com.au/products/', '')
        
        # Get image information
        image_elem = url_elem.find('image:image', namespaces)
        if image_elem is None:
            print(f"  ⚠️ No image found for {slug}")
            continue
        
        image_loc_elem = image_elem.find('image:loc', namespaces)
        image_title_elem = image_elem.find('image:title', namespaces)
        
        if image_loc_elem is None:
            print(f"  ⚠️ No image URL for {slug}")
            continue
        
        image_url = image_loc_elem.text
        product_name = image_title_elem.text if image_title_elem is not None else slug.replace('-', ' ').title()
        
        # Clean up product name
        product_name = product_name.replace('&amp;', '&').replace('&apos;', "'")
        
        # Determine category from slug/name
        category = categorize_product(slug, product_name)
        
        # Get current date
        current_date = datetime.now().strftime('%Y-%m-%d')
        
        product_data = {
            'date_collected': current_date,
            'product_name': product_name,
            'product_url': product_url,
            'product_slug': slug,
            'image_url': image_url,
            'category': category,
            'local_image_path': None,
            'nextcloud_path': None,
            'nextcloud_share_url': None,
            'generic_description_flag': False,  # Will be determined later
            'notes': ''
        }
        
        products.append(product_data)
        
        # Stop when we have enough products for testing
        if len(products) >= max_products:
            break
    
    return products

def categorize_product(slug, product_name):
    """Categorize product based on slug and name patterns."""
    slug_lower = slug.lower()
    name_lower = product_name.lower()
    
    # Bitaxe/mining related
    if any(term in slug_lower or term in name_lower for term in ['bitaxe', 'miner', 'mining', 'nerdminer', 'lottery']):
        return 'mining'
    
    # SeedSigner/seed related
    elif any(term in slug_lower or term in name_lower for term in ['seedsigner', 'seed', 'stamp', 'backup', 'hammer', 'seedsleeve']):
        return 'seed_management'
    
    # Hardware wallets/signers
    elif any(term in slug_lower or term in name_lower for term in ['coldcard', 'signer', 'hardware']):
        return 'hardware_wallets'
    
    # Nodes
    elif any(term in slug_lower or term in name_lower for term in ['node', 'raspberry', 'pi', 'blockclock', 'lnbits']):
        return 'nodes_network'
    
    # Apparel - hats
    elif any(term in slug_lower or term in name_lower for term in ['cap', 'hat', 'beanie', 'visor', 'bucket']):
        return 'apparel_hats'
    
    # Apparel - shirts
    elif any(term in slug_lower or term in name_lower for term in ['tee', 'shirt', 'polo', 'adidas', 'hoodie', 'sweatshirt']):
        return 'apparel_shirts'
    
    # Mugs
    elif 'mug' in slug_lower or 'mug' in name_lower:
        return 'mugs'
    
    # Water bottles
    elif 'water' in slug_lower or 'bottle' in name_lower:
        return 'bottles'
    
    # Accessories
    elif any(term in slug_lower or term in name_lower for term in ['case', 'stand', 'cover', 'sign', 'sticker', 'coaster', 'patch', 'kit']):
        return 'accessories'
    
    # Food/drink
    elif any(term in slug_lower or term in name_lower for term in ['honey', 'coffee', 'tea']):
        return 'food_drink'
    
    else:
        return 'other'

def download_image(image_url, product_slug):
    """Download image from URL to local temporary directory."""
    try:
        # Extract filename from URL
        parsed_url = urlparse(image_url)
        filename = os.path.basename(parsed_url.path)
        
        # Clean filename
        clean_filename = f"{product_slug}_{filename}"
        clean_filename = clean_filename.replace('?', '_').replace('=', '_').replace('&', '_')
        
        local_path = os.path.join(LOCAL_TEMP_DIR, clean_filename)
        
        print(f"  Downloading: {filename[:50]}...")
        response = requests.get(image_url, timeout=30)
        response.raise_for_status()
        
        with open(local_path, 'wb') as f:
            f.write(response.content)
        
        print(f"  ✅ Saved to: {local_path}")
        return local_path
        
    except Exception as e:
        print(f"  ❌ Download failed: {e}")
        return None

def upload_to_nextcloud(local_path, category, product_slug):
    """Upload file to Nextcloud via WebDAV."""
    try:
        # Determine target folder based on category
        category_folder = category.replace('_', ' ').title()
        
        # Map categories to Nextcloud Collections subfolders
        category_mapping = {
            'accessories': 'Accessories',
            'apparel_hats': 'Clothing & Bags',
            'apparel_shirts': 'Clothing & Bags',
            'apparel_hoodies': 'Clothing & Bags',
            'mining': 'Accessories',  # Placeholder - might need new folder
            'seed_management': 'Accessories',
            'hardware_wallets': 'Accessories',
            'nodes_network': 'Accessories',
            'mugs': 'Accessories',
            'bottles': 'Accessories',
            'food_drink': 'Accessories',
            'other': 'Accessories'
        }
        
        target_folder = category_mapping.get(category, 'Accessories')
        target_path = f"{NEXTCLOUD_TARGET_BASE}/{target_folder}"
        
        # Extract filename
        filename = os.path.basename(local_path)
        
        # Create WebDAV URL
        upload_url = f"{WEBDAV_BASE}{target_path}/{filename}"
        upload_url = upload_url.replace(' ', '%20')  # URL encode spaces
        
        # Read file content
        with open(local_path, 'rb') as f:
            file_content = f.read()
        
        # PUT request to upload
        headers = {
            'Content-Type': 'application/octet-stream'
        }
        
        response = requests.put(
            upload_url,
            auth=(USERNAME, PASSWORD),
            headers=headers,
            data=file_content,
            timeout=30
        )
        
        if response.status_code in [200, 201, 204]:
            print(f"  ✅ Uploaded to Nextcloud: {target_path}/{filename}")
            return f"{target_path}/{filename}"
        else:
            print(f"  ❌ Upload failed: {response.status_code} {response.text[:100]}")
            return None
            
    except Exception as e:
        print(f"  ❌ Upload error: {e}")
        return None

def create_share_link(nextcloud_path):
    """
    Create a share link for a file in Nextcloud.
    Returns public share URL if successful.
    """
    try:
        # Nextcloud OCS Share API
        share_api_url = f"{NEXTCLOUD_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares"
        
        # Extract file path relative to user's files
        # Format: /_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Collections/Accessories/filename.jpg
        # Need: /_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Collections/Accessories/filename.jpg
        
        headers = {
            'OCS-APIRequest': 'true',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        data = {
            'path': nextcloud_path,
            'shareType': 3,  # Public link
            'permissions': 1  # Read-only
        }
        
        response = requests.post(
            share_api_url,
            auth=(USERNAME, PASSWORD),
            headers=headers,
            json=data,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            if 'ocs' in result and 'data' in result['ocs']:
                share_url = result['ocs']['data']['url']
                print(f"  ✅ Share link created: {share_url}")
                return share_url
        
        print(f"  ⚠️ Share API failed: {response.status_code} {response.text[:200]}")
        return None
        
    except Exception as e:
        print(f"  ⚠️ Share creation error (API may not be available): {e}")
        # Fallback: Construct a direct download URL (may require authentication)
        file_id = nextcloud_path.replace('/', '_')
        return f"{NEXTCLOUD_URL}/s/{file_id}"  # This is a guess - actual share URL format may differ

def generate_csv(products, output_file):
    """Generate CSV file with product information."""
    fieldnames = [
        'date_collected',
        'product_name', 
        'product_url',
        'image_url',
        'nextcloud_image_path',
        'nextcloud_share_url',
        'category',
        'generic_description_flag',
        'notes'
    ]
    
    with open(output_file, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for product in products:
            row = {
                'date_collected': product['date_collected'],
                'product_name': product['product_name'],
                'product_url': product['product_url'],
                'image_url': product['image_url'],
                'nextcloud_image_path': product['nextcloud_path'] or '',
                'nextcloud_share_url': product['nextcloud_share_url'] or '',
                'category': product['category'],
                'generic_description_flag': product['generic_description_flag'],
                'notes': product['notes']
            }
            writer.writerow(row)
    
    print(f"📊 CSV generated: {output_file}")
    return output_file

def main():
    print("=== Shop Bitcoin Australia Product Image Collection Test ===\n")
    
    # Step 1: Parse sitemap
    sitemap_file = "sitemap_products.xml"
    print(f"1. Parsing sitemap: {sitemap_file}")
    
    if not os.path.exists(sitemap_file):
        print(f"❌ Sitemap file not found: {sitemap_file}")
        print("   Looking for file in current directory...")
        # Try to find it
        possible_paths = [
            "sitemap_products.xml",
            "../sitemap_products.xml",
            "/home/agent/.openclaw/workspace-shelley/sba-operations/sitemap_products.xml"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                sitemap_file = path
                print(f"   Found at: {sitemap_file}")
                break
        else:
            print("❌ Could not find sitemap file")
            return
    
    products = parse_sitemap(sitemap_file, max_products=3)
    
    if not products:
        print("❌ No products found in sitemap")
        return
    
    print(f"   Found {len(products)} products for testing\n")
    
    # Step 2: Process each product
    for i, product in enumerate(products, 1):
        print(f"\n--- Processing Product {i}: {product['product_name'][:50]}... ---")
        
        # Download image
        local_path = download_image(product['image_url'], product['product_slug'])
        if not local_path:
            product['notes'] = 'Download failed'
            continue
        
        product['local_image_path'] = local_path
        
        # Upload to Nextcloud
        nextcloud_path = upload_to_nextcloud(local_path, product['category'], product['product_slug'])
        product['nextcloud_path'] = nextcloud_path
        
        # Create share link (if upload successful)
        if nextcloud_path:
            share_url = create_share_link(nextcloud_path)
            product['nextcloud_share_url'] = share_url
        
        # Check for generic description
        # Simple heuristic: if description contains generic terms
        generic_terms = ['product', 'item', 'goods', 'merchandise', 'buy now']
        product_name_lower = product['product_name'].lower()
        if any(term in product_name_lower for term in generic_terms):
            product['generic_description_flag'] = True
            product['notes'] = 'Generic description detected - needs review'
        
        # Small delay between products to be respectful
        if i < len(products):
            time.sleep(2)
    
    # Step 3: Generate CSV
    print(f"\n3. Generating output files...")
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_file = f"product_images_test_{timestamp}.csv"
    csv_path = generate_csv(products, csv_file)
    
    # Step 4: Save detailed JSON
    json_file = f"product_images_test_{timestamp}.json"
    with open(json_file, 'w') as f:
        json.dump({
            'test_date': datetime.now().isoformat(),
            'products_processed': len(products),
            'products': products
        }, f, indent=2)
    
    print(f"💾 JSON details saved: {json_file}")
    
    # Step 5: Display summary
    print(f"\n=== Test Complete ===")
    print(f"📦 Products processed: {len(products)}")
    print(f"📊 CSV output: {csv_path}")
    print(f"📁 Local temp files: {LOCAL_TEMP_DIR}")
    
    print(f"\n📋 Sample data from CSV:")
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            print(f"  • {row['product_name'][:40]}... | {row['category']} | Share: {'✅' if row['nextcloud_share_url'] else '❌'}")
    
    print(f"\n✅ Test completed successfully!")
    print(f"   Next steps: Review the CSV, check Nextcloud for uploaded files,")
    print(f"   then scale up to process all products.")

if __name__ == "__main__":
    main()