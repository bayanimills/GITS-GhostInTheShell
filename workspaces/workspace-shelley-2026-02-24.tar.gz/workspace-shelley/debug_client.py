#!/usr/bin/env python3
"""Debug the Nextcloud client URL construction."""

import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')

from nextcloud_client import NextcloudClient

client = NextcloudClient()

print("Client configuration:")
print(f"  url: {client.url}")
print(f"  username: {client.username}")
print(f"  base_path: {client.base_path}")
print(f"  webdav_base: {client.webdav_base}")
print()

# Test _resolve_remote_path
test_paths = [
    '/',
    '',
    '/test',
    'test',
    client.base_path,
    'Finance/Incoming/test.pdf'
]

print("Testing _resolve_remote_path:")
for path in test_paths:
    resolved = client._resolve_remote_path(path)
    print(f"  '{path}' -> '{resolved}'")

print()
print("Testing _make_webdav_url:")
for path in test_paths:
    # First resolve
    resolved = client._resolve_remote_path(path)
    url = client._make_webdav_url(resolved)
    print(f"  '{path}' -> '{url}'")
    
    # Check for encoded slashes
    if '%2F' in url and url.count('%2F') > 1:
        print(f"    ⚠️ Has encoded slashes")

print()
print("Now testing actual connection...")

# Test accessing base_path
import requests
from requests.auth import HTTPBasicAuth

auth = HTTPBasicAuth(client.username, client.password)

# Manually construct URL
resolved = client._resolve_remote_path(client.base_path)
url = client._make_webdav_url(resolved)
print(f"Manual URL for base_path: {url}")

# Try PROPFIND
headers = {'Depth': '1'}
response = requests.request('PROPFIND', url, auth=auth, headers=headers, timeout=10)
print(f"PROPFIND response: {response.status_code}")

if response.status_code == 207:
    print("✓ Success!")
elif response.status_code == 404:
    print("✗ Not found")
    # Try alternative URL construction
    print("\nTrying alternative URL construction...")
    
    # Try without encoding
    simple_url = f"https://nextcloud.blkstr.io/remote.php/dav/files/jarvis/_private/businesses/Bayani%20Enterprises/SBA%20-%20ShopBitcoin"
    print(f"Simple URL: {simple_url}")
    response2 = requests.request('PROPFIND', simple_url, auth=auth, headers=headers, timeout=10)
    print(f"Simple URL response: {response2.status_code}")
    
    # Try listing root
    root_url = f"https://nextcloud.blkstr.io/remote.php/dav/files/jarvis/"
    print(f"\nRoot URL: {root_url}")
    response3 = requests.request('PROPFIND', root_url, auth=auth, headers=headers, timeout=10)
    print(f"Root response: {response3.status_code}")