# Email Management System for Shop Bitcoin Australia

## Overview
Systematic email checking system for SBA business operations. Checks two email accounts daily at 8am and 1pm AEST.

## Accounts Monitored
1. **service@shopbitcoin.com.au** - Primary customer support & business email
2. **bayanimills@gmail.com** - Personal/business management email

## Folder Structure
```
email-management/
├── config/
│   └── email_accounts.json      # Account configurations
├── scripts/
│   ├── check_emails.py          # Python email checker
│   └── daily_email_check.sh     # Shell script for cron
├── templates/                   # Email response templates
├── logs/                        # Daily check logs
└── README.md                    # This file
```

## Scheduled Checks
- **8:00 AM AEST** - Morning email check
- **1:00 PM AEST** - Afternoon email check

## What Gets Checked
### service@shopbitcoin.com.au
- Unread emails (priority: high)
- Urgent keywords: `overheating`, `issue`, `problem`, `urgent`, `emergency`
- Customer support inquiries
- Order notifications
- Technical support requests

### bayanimills@gmail.com
- Unread emails (priority: medium)
- Business keywords: `shopify`, `shopbitcoin`, `sba`, `business`
- Shopify billing (labeled "Bayani Enterprises")
- Business communications

## Alert System
- **Urgent emails** trigger immediate alerts
- **Daily logs** stored with timestamp
- **Summary reports** generated after each check

## Cron Jobs
Two isolated agent sessions run daily:
1. `Daily 8am Email Check` - Runs at 8:00 AM AEST
2. `Daily 1pm Email Check` - Runs at 1:00 PM AEST

## Response Workflow
When urgent emails are found:
1. Log details in timestamped file
2. Generate alert summary
3. Await instructions for drafting responses
4. Follow up based on priority

## Maintenance
- Logs auto-rotate (keep 30 days)
- Config updates via `email_accounts.json`
- Script updates in `scripts/` directory

## Next Steps
1. Create email response templates
2. Implement auto-categorization
3. Add sentiment analysis for urgent detection
4. Integrate with Shopify API for order context