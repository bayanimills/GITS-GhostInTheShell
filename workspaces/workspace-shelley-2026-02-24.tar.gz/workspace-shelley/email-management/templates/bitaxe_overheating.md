# BitAxe Overheating Response Template

**Subject:** Re: BitAxe Overheating Issue

**Body:**

Hi [Customer Name],

Thank you for reaching out about your BitAxe overheating issue. I'm here to help you troubleshoot this.

**First, let's gather some details:**

1. **Which BitAxe model do you have?** (BitAxe Ultra, BitAxe Pro, etc.)
2. **What power supply are you using?** (Make/model and wattage)
3. **What's the ambient temperature** where the miner is located?
4. **Are there any error messages** on the display or in the logs?
5. **How long does it run** before overheating occurs?

**Common troubleshooting steps:**

1. **Check airflow** - Ensure the BitAxe has at least 6 inches of clearance on all sides
2. **Verify power supply** - Use only the recommended power supply (check specifications)
3. **Monitor temperature** - Use the BitAxe dashboard to check actual temperature readings
4. **Firmware update** - Ensure you're running the latest firmware
5. **Environmental factors** - Avoid placing near heat sources or in enclosed spaces

**Immediate steps you can take:**
- Turn off the BitAxe and let it cool completely
- Clean any dust from the fans and vents
- Move to a cooler location if possible

**Next steps:**
Once you provide the details above, I can offer more specific guidance. If the issue persists after basic troubleshooting, we can discuss warranty options or repair services.

Please reply with the requested information, and I'll help you get your BitAxe running optimally.

Best regards,

Shop Bitcoin Australia Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

---
*Response drafted by Shelley, Shop Bitcoin Australia Manager*