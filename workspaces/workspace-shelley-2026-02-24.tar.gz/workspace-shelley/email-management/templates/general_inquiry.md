# General Inquiry Response Template

**Subject:** Re: Your Inquiry

**Body:**

Hi [Customer Name],

Thank you for contacting Shop Bitcoin Australia. I'd be happy to help with your inquiry.

**To provide you with the most accurate information, could you please share:**

1. **What specific question or topic** would you like assistance with?
2. **Are you interested in** a particular product, service, or general information?
3. **Do you have any preferences** regarding shipping, pricing, or specifications?

**Common topics we can help with:**
- Product specifications and compatibility
- Order status and shipping inquiries
- Technical support for Bitcoin hardware
- Mining equipment setup and optimization
- Bitcoin education and resources

**About Shop Bitcoin Australia:**
We're Australia's one-stop Bitcoin shop, specializing in:
- BitAxe miners and mining hardware
- Hardware wallets and security devices
- Bitcoin nodes and network infrastructure
- Educational resources and community support

Please provide more details about your specific needs, and I'll ensure you get the information or assistance you're looking for.

Best regards,

Shop Bitcoin Australia Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

---
*Response drafted by Shelley, Shop Bitcoin Australia Manager*