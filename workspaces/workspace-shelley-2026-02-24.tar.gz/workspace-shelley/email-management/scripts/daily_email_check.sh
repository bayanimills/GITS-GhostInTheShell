#!/bin/bash
# Daily Email Check Script for Shop Bitcoin Australia
# Runs at 8am and 1pm AEST

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/../logs"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
CHECK_TIME=$(date '+%Y-%m-%d %H:%M:%S')

# Create log directory
mkdir -p "$LOG_DIR"

echo "============================================================"
echo "Daily Email Check - $CHECK_TIME"
echo "============================================================"

# Check service@shopbitcoin.com.au
echo "Checking service@shopbitcoin.com.au..."
SERVICE_OUTPUT=$(gog gmail search "in:inbox is:unread" --max 20 --account service@shopbitcoin.com.au 2>&1)

if [[ $? -eq 0 ]]; then
    echo "$SERVICE_OUTPUT" > "$LOG_DIR/service_unread_${TIMESTAMP}.txt"
    SERVICE_COUNT=$(echo "$SERVICE_OUTPUT" | grep -c "^19")
    echo "Found $SERVICE_COUNT unread emails in service@shopbitcoin.com.au"
    
    # Check for urgent keywords
    URGENT_COUNT=$(echo "$SERVICE_OUTPUT" | grep -i -c "overheating\|issue\|problem\|urgent\|emergency")
    if [[ $URGENT_COUNT -gt 0 ]]; then
        echo "⚠️  Found $URGENT_COUNT urgent emails in service@shopbitcoin.com.au"
    fi
else
    echo "ERROR checking service@shopbitcoin.com.au"
fi

# Check bayanimills@gmail.com
echo ""
echo "Checking bayanimills@gmail.com..."
BAYANI_OUTPUT=$(gog gmail search "in:inbox is:unread" --max 10 --account bayanimills@gmail.com 2>&1)

if [[ $? -eq 0 ]]; then
    echo "$BAYANI_OUTPUT" > "$LOG_DIR/bayani_unread_${TIMESTAMP}.txt"
    BAYANI_COUNT=$(echo "$BAYANI_OUTPUT" | grep -c "^19")
    echo "Found $BAYANI_COUNT unread emails in bayanimills@gmail.com"
    
    # Check for Shopify/business emails
    BUSINESS_COUNT=$(echo "$BAYANI_OUTPUT" | grep -i -c "shopify\|shopbitcoin\|sba\|business")
    if [[ $BUSINESS_COUNT -gt 0 ]]; then
        echo "📊 Found $BUSINESS_COUNT business-related emails"
    fi
else
    echo "ERROR checking bayanimills@gmail.com"
fi

# Generate summary
echo ""
echo "============================================================"
echo "SUMMARY"
echo "============================================================"
echo "Total unread in service@shopbitcoin.com.au: $SERVICE_COUNT"
echo "Total unread in bayanimills@gmail.com: $BAYANI_COUNT"
echo "Urgent emails found: $URGENT_COUNT"
echo "Business emails found: $BUSINESS_COUNT"
echo ""
echo "Logs saved to: $LOG_DIR/"
echo "============================================================"

# If urgent emails found, create alert file
if [[ $URGENT_COUNT -gt 0 ]]; then
    echo "URGENT_ALERT: $URGENT_COUNT urgent emails found at $CHECK_TIME" > "$LOG_DIR/urgent_alert_${TIMESTAMP}.txt"
    echo "$SERVICE_OUTPUT" >> "$LOG_DIR/urgent_alert_${TIMESTAMP}.txt"
fi