#!/usr/bin/env python3
"""
Simple email categorization script for service@shopbitcoin.com.au
Categorizes unread emails based on rules and suggests labels
"""

import subprocess
import json
import re
from datetime import datetime

def run_gog_search(query, max_results=20):
    """Run gog search and return parsed results"""
    try:
        cmd = ['gog', 'gmail', 'messages', 'search', query, '--max', str(max_results), 
               '--account', 'service@shopbitcoin.com.au', '--json']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return json.loads(result.stdout)
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def categorize_email(subject, from_email, body):
    """Categorize email based on content"""
    subject_lower = subject.lower()
    body_lower = body.lower() if body else ""
    from_lower = from_email.lower()
    
    # Customer Support - Technical
    if any(keyword in subject_lower or keyword in body_lower 
           for keyword in ['bitaxe', 'overheating', 'faulty', 'module', 'lan', 'technical', 'issue', 'problem']):
        return "REFERENCE/Customer Support/Technical"
    
    # Customer Support - General
    elif any(keyword in subject_lower or keyword in body_lower 
             for keyword in ['inquiry', 'question', 'general', 'ask', 'help']):
        return "REFERENCE/Customer Support/General"
    
    # Orders
    elif any(keyword in subject_lower 
             for keyword in ['order', 'payment', 'receipt', 'refund', 'ship', 'dispatch']):
        return "REFERENCE/Orders/Pending"
    
    # Accounting - Invoices
    elif 'voltage' in from_lower or 'invoice' in subject_lower:
        return "REFERENCE/Accounting/Invoices"
    
    # Accounting - Receipts
    elif 'bankful' in from_lower or 'payment received' in subject_lower:
        return "REFERENCE/Accounting/Receipts"
    
    # Security
    elif any(keyword in subject_lower 
             for keyword in ['login', 'security', 'alert', 'verify']):
        return "REFERENCE/Security/Logins"
    
    # Urgent (needs immediate attention)
    elif any(keyword in subject_lower 
             for keyword in ['urgent', 'emergency', 'critical', 'asap']):
        return "ACTION REQUIRED/URGENT"
    
    # This Week (needs attention within 7 days)
    elif 'past due' in subject_lower or 'due in' in subject_lower:
        return "ACTION REQUIRED/THIS WEEK"
    
    else:
        return "ACTION REQUIRED/FOLLOW UP"

def main():
    print("=" * 60)
    print("EMAIL CATEGORIZATION - service@shopbitcoin.com.au")
    print("=" * 60)
    
    # Get unread emails
    data = run_gog_search("in:inbox is:unread", max_results=20)
    
    if not data or 'messages' not in data:
        print("No unread emails found or error fetching emails")
        return
    
    emails = data.get('messages', [])
    print(f"Found {len(emails)} unread emails\n")
    
    # Categorize each email
    categories = {}
    for email in emails:
        email_id = email.get('id', '')
        subject = email.get('subject', '')
        from_email = email.get('from', '')
        body = email.get('body', '')
        
        category = categorize_email(subject, from_email, body)
        
        if category not in categories:
            categories[category] = []
        categories[category].append({
            'id': email_id,
            'subject': subject[:50] + "..." if len(subject) > 50 else subject,
            'from': from_email
        })
    
    # Print categorization results
    print("CATEGORIZATION RESULTS:")
    print("-" * 40)
    
    for category, emails_list in categories.items():
        print(f"\n{category}: {len(emails_list)} emails")
        for email in emails_list:
            print(f"  • {email['subject']}")
            print(f"    From: {email['from']}")
    
    # Generate action plan
    print("\n" + "=" * 60)
    print("RECOMMENDED ACTIONS:")
    print("=" * 60)
    
    if "ACTION REQUIRED/URGENT" in categories:
        print("\n🚨 URGENT ACTION NEEDED (24h):")
        for email in categories["ACTION REQUIRED/URGENT"]:
            print(f"  • {email['subject']}")
    
    if "ACTION REQUIRED/THIS WEEK" in categories:
        print("\n📅 THIS WEEK ACTION (7 days):")
        for email in categories["ACTION REQUIRED/THIS WEEK"]:
            print(f"  • {email['subject']}")
    
    if "REFERENCE/Accounting/Invoices" in categories:
        print("\n💰 INVOICES TO PROCESS:")
        for email in categories["REFERENCE/Accounting/Invoices"]:
            print(f"  • {email['subject']}")
    
    if "REFERENCE/Customer Support/Technical" in categories:
        print("\n🔧 TECHNICAL SUPPORT NEEDED:")
        for email in categories["REFERENCE/Customer Support/Technical"]:
            print(f"  • {email['subject']}")
    
    print(f"\nTotal emails to process: {len(emails)}")
    print(f"Categories created: {len(categories)}")

if __name__ == "__main__":
    main()