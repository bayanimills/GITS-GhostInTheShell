#!/bin/bash
# Email Processing Script for service@shopbitcoin.com.au
# Can be run manually or scheduled via cron

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/../logs"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')

echo "============================================================"
echo "EMAIL PROCESSING - service@shopbitcoin.com.au"
echo "Date: $(date)"
echo "============================================================"

# Step 1: Run categorization
echo "Step 1: Categorizing unread emails..."
python3 "$SCRIPT_DIR/categorize_emails.py" > "$LOG_DIR/categorization_${TIMESTAMP}.txt"

# Step 2: Check for urgent items
echo -e "\nStep 2: Checking for urgent items..."
URGENT_COUNT=$(grep -c "URGENT ACTION NEEDED" "$LOG_DIR/categorization_${TIMESTAMP}.txt" 2>/dev/null || echo "0")

if [ "$URGENT_COUNT" -gt "0" ]; then
    echo "🚨 Found $URGENT_COUNT urgent emails requiring immediate attention"
    grep -A5 "URGENT ACTION NEEDED" "$LOG_DIR/categorization_${TIMESTAMP}.txt"
else
    echo "✅ No urgent emails found"
fi

# Step 3: Check invoices
echo -e "\nStep 3: Checking invoices..."
INVOICE_COUNT=$(grep -c "INVOICES TO PROCESS" "$LOG_DIR/categorization_${TIMESTAMP}.txt" 2>/dev/null || echo "0")

if [ "$INVOICE_COUNT" -gt "0" ]; then
    echo "💰 Found $INVOICE_COUNT invoices needing processing"
    grep -A5 "INVOICES TO PROCESS" "$LOG_DIR/categorization_${TIMESTAMP}.txt"
fi

# Step 4: Generate summary report
echo -e "\nStep 4: Generating summary report..."

TOTAL_EMAILS=$(grep -o "Found [0-9]* unread emails" "$LOG_DIR/categorization_${TIMESTAMP}.txt" | grep -o "[0-9]*" || echo "0")
CATEGORIES=$(grep -o "Categories created: [0-9]*" "$LOG_DIR/categorization_${TIMESTAMP}.txt" | grep -o "[0-9]*" || echo "0")

echo "SUMMARY:"
echo "  Total unread emails: $TOTAL_EMAILS"
echo "  Categories identified: $CATEGORIES"
echo "  Urgent items: $URGENT_COUNT"
echo "  Invoices: $INVOICE_COUNT"

# Step 5: Create action items file
echo -e "\nStep 5: Creating action items..."
ACTION_FILE="$LOG_DIR/action_items_${TIMESTAMP}.txt"

cat > "$ACTION_FILE" << EOF
EMAIL PROCESSING ACTION ITEMS
Generated: $(date)

STATUS:
- Total unread emails: $TOTAL_EMAILS
- Urgent items: $URGENT_COUNT
- Invoices needing attention: $INVOICE_COUNT

RECOMMENDED ACTIONS:
1. Review categorization report: $LOG_DIR/categorization_${TIMESTAMP}.txt
2. Process urgent items first (if any)
3. Handle invoices (payment/verification)
4. Archive or respond to customer emails
5. Clean up promotional emails

NEXT STEPS:
- Run this script daily (8am & 1pm)
- Review action items after each run
- Update email responses as needed
EOF

echo "✅ Action items saved to: $ACTION_FILE"
echo -e "\n============================================================"
echo "PROCESSING COMPLETE"
echo "============================================================"
echo "Reports saved to: $LOG_DIR/"
echo "  - categorization_${TIMESTAMP}.txt"
echo "  - action_items_${TIMESTAMP}.txt"
echo -e "\nRun 'cat $ACTION_FILE' to see action items"