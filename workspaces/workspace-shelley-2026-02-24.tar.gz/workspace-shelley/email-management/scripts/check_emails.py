#!/usr/bin/env python3
"""
Email Check Script for Shop Bitcoin Australia
Runs at 8am and 1pm daily to check service@shopbitcoin.com.au
"""

import json
import subprocess
import sys
from datetime import datetime
import os

# Paths
CONFIG_PATH = os.path.join(os.path.dirname(__file__), '../config/email_accounts.json')
LOG_DIR = os.path.join(os.path.dirname(__file__), '../logs')

def run_gog_command(account, query, max_results=20):
    """Run gog command and return output"""
    try:
        cmd = ['gog', 'gmail', 'search', query, '--max', str(max_results), '--account', account]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "ERROR: Command timed out"
    except Exception as e:
        return f"ERROR: {str(e)}"

def categorize_email(subject, body, categories):
    """Categorize email based on keywords"""
    subject_lower = subject.lower()
    body_lower = body.lower()
    
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword.lower() in subject_lower or keyword.lower() in body_lower:
                return category
    return "uncategorized"

def check_account(account_config, check_time):
    """Check a single email account"""
    email = account_config['email']
    label = account_config['label']
    categories = account_config.get('categories', {})
    
    print(f"\n{'='*60}")
    print(f"Checking: {label} ({email})")
    print(f"Time: {check_time}")
    print(f"{'='*60}")
    
    # Check unread emails
    unread_output = run_gog_command(email, 'in:inbox is:unread')
    
    if unread_output.startswith("ERROR"):
        print(f"Error checking {email}: {unread_output}")
        return []
    
    # Parse output (simplified - in real implementation would parse gog output properly)
    lines = unread_output.split('\n')
    unread_count = 0
    categorized_emails = []
    
    for line in lines:
        if line.startswith('19'):  # Email ID lines
            parts = line.split()
            if len(parts) >= 5:
                email_id = parts[0]
                date = parts[1]
                from_field = ' '.join(parts[2:-2])
                subject = parts[-2]
                
                # Try to get more details
                # For now, just categorize based on subject
                category = categorize_email(subject, "", categories)
                
                categorized_emails.append({
                    'id': email_id,
                    'date': date,
                    'from': from_field,
                    'subject': subject,
                    'category': category,
                    'priority': account_config.get('priority', 'medium')
                })
                unread_count += 1
    
    print(f"Found {unread_count} unread emails")
    
    # Log results
    log_file = os.path.join(LOG_DIR, f"email_check_{datetime.now().strftime('%Y%m%d_%H%M')}.json")
    with open(log_file, 'w') as f:
        json.dump({
            'timestamp': check_time,
            'account': email,
            'unread_count': unread_count,
            'emails': categorized_emails
        }, f, indent=2)
    
    return categorized_emails

def main():
    # Create log directory if it doesn't exist
    os.makedirs(LOG_DIR, exist_ok=True)
    
    # Load config
    try:
        with open(CONFIG_PATH, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Config file not found: {CONFIG_PATH}")
        return 1
    
    check_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    all_emails = []
    
    # Check each account
    for account in config['accounts']:
        emails = check_account(account, check_time)
        all_emails.extend(emails)
    
    # Generate summary
    print(f"\n{'='*60}")
    print("EMAIL CHECK SUMMARY")
    print(f"{'='*60}")
    
    categories = {}
    for email in all_emails:
        cat = email['category']
        categories[cat] = categories.get(cat, 0) + 1
    
    for cat, count in categories.items():
        print(f"{cat}: {count}")
    
    # Check for urgent emails
    urgent_keywords = ['overheating', 'issue', 'problem', 'urgent', 'emergency']
    urgent_emails = []
    for email in all_emails:
        subject_lower = email['subject'].lower()
        if any(keyword in subject_lower for keyword in urgent_keywords):
            urgent_emails.append(email)
    
    if urgent_emails:
        print(f"\n⚠️  URGENT EMAILS FOUND: {len(urgent_emails)}")
        for email in urgent_emails:
            print(f"  - {email['subject']} (from: {email['from']})")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())