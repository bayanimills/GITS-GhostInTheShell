**To:** Caleb <auscaleb@gmail.com>
**Subject:** Re: BitAxe Overheating
**Account:** service@shopbitcoin.com.au

Hi Caleb,

Thank you for reaching out about your BitAxe overheating issue. I understand this can be frustrating, and I'm here to help you troubleshoot it.

**Based on your description (overheating + "power supply issues" error), here's what to check first:**

### 1. **Power Supply Verification**
- **Check the power supply rating:** Ensure you're using a **12V power supply** with **adequate amperage** (minimum 5A for most BitAxe models)
- **Verify connections:** Check all power connections are secure
- **Try a different power supply:** If possible, test with a known-good power supply

### 2. **Cooling System Check**
- **Clean the heatsink/fans:** Dust buildup is a common cause of overheating
- **Verify fan operation:** Ensure all fans are spinning properly
- **Check thermal paste:** If you're comfortable, verify the thermal paste application

### 3. **Environmental Factors**
- **Ambient temperature:** Ensure the BitAxe is in a well-ventilated, cool area
- **Clearance:** Provide at least 6 inches of clearance on all sides
- **Avoid heat sources:** Keep away from other heat-generating equipment

### 4. **Next Steps**
1. **Check the attached image** - I'll review it once you send it (Gmail may have stripped it from your original email)
2. **Let me know:** 
   - Which BitAxe model you have
   - Power supply specifications (make/model/wattage)
   - Current ambient temperature
   - Any other error messages

### 5. **Immediate Actions**
- **Turn off** the BitAxe and let it cool completely
- **Clean** any dust from vents and fans
- **Verify** power supply meets specifications

**Once you provide these details, I can offer more specific guidance.** If the issue persists after basic troubleshooting, we can discuss warranty options or repair services.

Please reply with the requested information and resend the image if possible.

Best regards,

Shop Bitcoin Australia Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

---
*Response drafted autonomously by Shelley, Shop Bitcoin Australia Manager*