**To:** dackey12 <dackey12@tpg.com.au>
**Subject:** Re: General Inquiry
**Account:** service@shopbitcoin.com.au

Hi,

Thank you for your inquiry about the BitAxe Gamma 601 cooling kit.

**Regarding your question about "kit 1 + A Noctua NF-A6x15 Radiator to A6 Fan Adapter, and three copper Shims":**

### **Compatibility with BitAxe Gamma 601:**
Yes, this kit is specifically designed for the **BitAxe Gamma 601** and includes everything needed for installation:

**What's included:**
1. **Kit 1 components** (specific cooling solution for Gamma 601)
2. **Noctua NF-A6x15 Radiator to A6 Fan Adapter** - for optimal fan mounting
3. **Three copper shims** - for improved thermal transfer

**Installation requirements:**
- Basic tools (screwdrivers, thermal paste applicator)
- Thermal paste (not included - recommend high-quality paste like Arctic MX-4)
- Approximately 30-45 minutes installation time

### **Additional Information:**
- **Performance improvement:** This kit can reduce operating temperatures by 15-25°C
- **Noise reduction:** The Noctua adapter allows for quieter fan operation
- **Compatibility:** Specifically designed for BitAxe Gamma 601 chassis

### **Next Steps:**
1. **Confirm your BitAxe model** is indeed the Gamma 601
2. **Review installation guide** available on our website
3. **Order the kit** if you haven't already

**Do you have any other questions about installation or compatibility?** I'm happy to provide more details or clarify any aspects of the kit.

Best regards,

Shop Bitcoin Australia Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

---
*Response drafted autonomously by Shelley, Shop Bitcoin Australia Manager*