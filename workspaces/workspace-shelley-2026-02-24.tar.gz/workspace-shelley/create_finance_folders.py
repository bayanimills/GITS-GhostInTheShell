#!/usr/bin/env python3
"""Create Finance folder structure with proper parent-first approach."""

import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')

from nextcloud_client import NextcloudClient

client = NextcloudClient()

print("Creating Finance folder structure with proper hierarchy...")

# Folders to create in order (parents first)
folders_in_order = [
    'Finance',
    'Finance/Incoming',
    'Finance/Receipts', 
    'Finance/Processed'
]

created = []
existing = []
failed = []

for folder in folders_in_order:
    print(f"\nChecking: {folder}")
    
    if client.file_exists(folder):
        print(f"  ✓ Already exists")
        existing.append(folder)
        continue
    
    # Check if parent exists (for debugging)
    import os
    parent = os.path.dirname(folder)
    if parent and parent != folder:
        parent_exists = client.file_exists(parent)
        print(f"  Parent '{parent}' exists: {parent_exists}")
    
    print(f"  Creating...")
    if client.create_directory(folder):
        print(f"  ✓ Created successfully")
        created.append(folder)
    else:
        print(f"  ✗ Failed to create")
        failed.append(folder)
        # Stop if parent creation fails
        if folder == 'Finance':
            print("  ⚠️ Cannot create Finance folder - stopping")
            break

print(f"\n{'='*50}")
print(f"Summary:")
print(f"  Created: {len(created)} folders")
if created:
    for f in created:
        print(f"    • {f}")
    
print(f"  Already existed: {len(existing)} folders")
if existing:
    for f in existing:
        print(f"    • {f}")
        
print(f"  Failed: {len(failed)} folders")
if failed:
    for f in failed:
        print(f"    • {f}")

# Verify final structure
print(f"\nVerifying Finance structure...")
if client.file_exists('Finance'):
    finance_items = client.list_directory('Finance')
    print(f"Finance directory contents ({len(finance_items)} items):")
    for item in finance_items:
        icon = '📁' if item['is_dir'] else '📄'
        size = f" ({item['size']} bytes)" if item.get('size') else ''
        print(f"  {icon} {item['name']}{size}")
else:
    print("✗ Finance folder doesn't exist")

print(f"\nSetup complete!")