#!/usr/bin/env python3
"""List root directory contents with proper XML parsing."""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

config = {
    'url': 'https://nextcloud.blkstr.io',
    'username': 'jarvis',
    'password': 'agent12345jarvis'
}

auth = HTTPBasicAuth(config['username'], config['password'])

url = f"{config['url']}/remote.php/dav/files/{config['username']}/"
headers = {'Depth': '1'}

print(f"Listing root directory at: {url}")
response = requests.request('PROPFIND', url, auth=auth, headers=headers, timeout=10)

if response.status_code == 207:
    print(f"Success! Status: {response.status_code}")
    
    # Parse XML
    root = ET.fromstring(response.text)
    
    # Define namespaces
    namespaces = {
        'd': 'DAV:',
        'oc': 'http://owncloud.org/ns',
        'nc': 'http://nextcloud.org/ns'
    }
    
    print("\nDirectory contents:")
    count = 0
    for response_elem in root.findall('d:response', namespaces):
        href_elem = response_elem.find('d:href', namespaces)
        if href_elem is not None:
            href = href_elem.text
            # Extract relative path
            base = f"/remote.php/dav/files/{config['username']}"
            if href.startswith(base):
                rel_path = href[len(base):]
                if rel_path and rel_path != '/':
                    # Get display name
                    propstat = response_elem.find('d:propstat', namespaces)
                    if propstat is not None:
                        prop = propstat.find('d:prop', namespaces)
                        if prop is not None:
                            # Check if it's a collection
                            resource_type = prop.find('d:resourcetype', namespaces)
                            is_dir = resource_type is not None and resource_type.find('d:collection', namespaces) is not None
                            
                            displayname_elem = prop.find('d:displayname', namespaces)
                            displayname = displayname_elem.text if displayname_elem is not None else rel_path.split('/')[-1]
                            
                            icon = '📁' if is_dir else '📄'
                            print(f"  {icon} {displayname} ({rel_path})")
                            count += 1
    
    print(f"\nTotal items: {count}")
    
    # Now let's try to find any business-related folders
    print("\n--- Searching for business folders ---")
    
    # Common business folder names to look for
    business_folders = [
        'Collections', 'Vendors', 'shipping', 'bill-invoices-incoming',
        'invoices-outgoing', '_Operational', 'socials', 'IG',
        'business', 'Business', 'shop', 'Shop', 'SBA', 'shopbitcoin',
        'finance', 'Finance', 'accounting', 'Accounting'
    ]
    
    found_folders = []
    for folder in business_folders:
        test_url = f"{config['url']}/remote.php/dav/files/{config['username']}/{folder}/"
        test_response = requests.request('PROPFIND', test_url, auth=auth, headers={'Depth': '0'}, timeout=5)
        if test_response.status_code == 207:
            print(f"  ✓ Found: {folder}/")
            found_folders.append(folder)
        elif test_response.status_code == 404:
            pass  # Not found, don't print
        else:
            print(f"  ? {folder}: Status {test_response.status_code}")
    
    if found_folders:
        print(f"\nFound business folders: {', '.join(found_folders)}")
    else:
        print("\nNo business folders found at root level.")
        
else:
    print(f"Failed! Status: {response.status_code}")
    print(f"Response: {response.text[:500]}")