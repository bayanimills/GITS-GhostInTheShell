#!/usr/bin/env python3
"""Test URL construction for Nextcloud WebDAV."""

from urllib.parse import quote

# Current _make_webdav_url logic
def make_webdav_url_current(webdav_base, remote_path):
    """Current implementation."""
    # Ensure path starts with /
    if not remote_path.startswith('/'):
        remote_path = '/' + remote_path
    
    # URL encode path segments
    encoded_path = quote(remote_path, safe='')
    return f"{webdav_base}{encoded_path}"

# Fixed implementation
def make_webdav_url_fixed(webdav_base, remote_path):
    """Fixed implementation."""
    # Remove leading slash if present
    if remote_path.startswith('/'):
        remote_path = remote_path[1:]
    
    # URL encode path segments
    encoded_path = quote(remote_path, safe='')
    return f"{webdav_base}/{encoded_path}"

# Test cases
test_cases = [
    '/',
    '',
    '/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin',
    '_private/businesses/Bayani Enterprises/SBA - ShopBitcoin',
    'Finance/Incoming/test.pdf',
    '/Finance/Incoming/test.pdf'
]

webdav_base = 'https://nextcloud.blkstr.io/remote.php/dav/files/jarvis'

print("Testing URL construction:")
print(f"WebDAV base: {webdav_base}")
print()

for path in test_cases:
    print(f"Input path: '{path}'")
    current = make_webdav_url_current(webdav_base, path)
    fixed = make_webdav_url_fixed(webdav_base, path)
    
    print(f"  Current: {current}")
    print(f"  Fixed:   {fixed}")
    
    # Check which one looks correct
    # Correct should be: .../files/jarvis/_private/businesses/...
    # Not: .../files/jarvis/%2Fprivate%2Fbusinesses/...
    
    if '%2F' in current and current.count('%2F') > 1:
        print(f"  ⚠️ Current has encoded slashes (wrong)")
    
    print()