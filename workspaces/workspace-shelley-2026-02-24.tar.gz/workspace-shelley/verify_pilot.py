#!/usr/bin/env python3
"""Verify pilot upload."""

import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

nc = NextcloudClient()

print("Verifying pilot upload...")

# List Finance/Incoming
items = nc.list_directory("Finance/Incoming")
print(f"Found {len(items)} items in Finance/Incoming:")
for item in items:
    icon = '📁' if item['is_dir'] else '📄'
    size = f" ({item['size']} bytes)" if item.get('size') else ''
    print(f"  {icon} {item['name']}{size}")
    
    # Check if it's our file
    if "448A39E5-0012" in item['name']:
        print(f"    ✓ PILOT FILE FOUND!")
        print(f"    Path: {item['path']}")
        print(f"    Size: {item.get('size', 'N/A')} bytes")
        
        # Verify we can download it
        print("    Testing download...")
        temp_path = "/tmp/test_download.pdf"
        if nc.download_file(item['path'], temp_path):
            import os
            size = os.path.getsize(temp_path)
            print(f"    ✓ Download successful ({size} bytes)")
            os.remove(temp_path)
        else:
            print("    ✗ Download failed")

print("\nChecking Finance folder structure...")
folders = ["Finance", "Finance/Incoming", "Finance/Receipts", "Finance/Processed"]
for folder in folders:
    exists = nc.file_exists(folder)
    print(f"{folder}: {'✓' if exists else '✗'}")