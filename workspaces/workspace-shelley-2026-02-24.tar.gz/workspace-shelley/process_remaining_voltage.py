#!/usr/bin/env python3
"""Process remaining Voltage invoices (#448A39E5-0011 and #448A39E5-0010)."""

import sys
import os
import json
import re
import subprocess
from datetime import datetime

sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

# Configuration
ACCOUNT = "service@shopbitcoin.com.au"
LABEL_NAME = "Saved in Nextcloud by Shelley"
FINANCE_BASE = "Finance/Incoming"
CSV_PATH = "voltage_invoices_processed.csv"

def run_gog(args, capture_output=True):
    """Run gog command and return parsed JSON if possible."""
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    print(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=capture_output, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error: {result.stderr}")
            return None
        
        if capture_output:
            return json.loads(result.stdout)
        return True
    except Exception as e:
        print(f"Command failed: {e}")
        return None

def ensure_label_exists():
    """Ensure label exists, create if not."""
    labels = run_gog(["gmail", "labels", "list"])
    if not labels:
        print("Warning: Could not list labels")
        return None
    
    for label in labels.get("labels", []):
        if label.get("name") == LABEL_NAME:
            return label.get("id")
    
    # Create label
    print(f"Creating label: {LABEL_NAME}")
    result = run_gog(["gmail", "labels", "create", LABEL_NAME])
    if result:
        return result.get("id")
    return None

def parse_invoice_metadata(email_data):
    """Parse metadata from email JSON (from gog gmail get)."""
    subject = email_data.get("headers", {}).get("subject", "")
    body = email_data.get("body", {}).get("text", "") or email_data.get("body", {}).get("html", "")
    
    # Extract invoice number
    match = re.search(r'#([A-Z0-9\-]+)', subject)
    if not match:
        print(f"Could not extract invoice number from: {subject[:50]}...")
        return None
    
    invoice_number = match.group(1)
    
    # Extract amount
    amount_match = re.search(r'\$(\d+\.\d{2})', body)
    if not amount_match:
        amount_match = re.search(r'Total due \$(\d+\.\d{2})', body)
    amount = amount_match.group(1) if amount_match else "0.00"
    
    # Vendor
    vendor = "Voltage"
    
    # Date - use email date
    date_str = email_data.get("headers", {}).get("date", "")
    if date_str:
        from email.utils import parsedate_to_datetime
        try:
            dt = parsedate_to_datetime(date_str)
            date = dt.strftime("%Y-%m-%d")
        except:
            date = datetime.now().strftime("%Y-%m-%d")
    else:
        date = datetime.now().strftime("%Y-%m-%d")
    
    # Find PDF attachment
    attachments = email_data.get("attachments", [])
    pdf_attachments = [a for a in attachments if a.get("mimeType") == "application/pdf"]
    
    if not pdf_attachments:
        print(f"No PDF attachment found for invoice {invoice_number}")
        return None
    
    # Use first PDF
    attachment = pdf_attachments[0]
    
    return {
        "invoice_number": invoice_number,
        "amount": amount,
        "vendor": vendor,
        "date": date,
        "subject": subject,
        "message_id": email_data.get("message", {}).get("id"),
        "thread_id": email_data.get("message", {}).get("threadId"),
        "attachment_id": attachment.get("attachmentId"),
        "original_filename": attachment.get("filename", f"Invoice-{invoice_number}.pdf")
    }

def sanitize_filename(metadata):
    """Create sanitized filename according to convention."""
    # Replace $ with AUD
    amount_str = f"AUD{metadata['amount']}"
    
    # Remove problematic characters from vendor name
    vendor_clean = re.sub(r'[<>:"/\\|?*]', '', metadata['vendor'])
    
    # Build filename
    filename = f"{metadata['date']} - {vendor_clean} - {metadata['invoice_number']} - {amount_str} - Invoice-{metadata['invoice_number']}.pdf"
    
    # Replace any remaining problematic characters
    filename = re.sub(r'[<>:"/\\|?*$]', '', filename)
    
    return filename

def download_attachment(message_id, attachment_id, local_path):
    """Download attachment to temporary location."""
    print(f"  Downloading attachment {attachment_id}...")
    
    cmd = ["gog", "gmail", "attachments", "get", message_id, attachment_id, 
           "--account", ACCOUNT, "--output", local_path]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"  Download error: {result.stderr}")
            return False
        
        if os.path.exists(local_path):
            size = os.path.getsize(local_path)
            print(f"  ✓ Downloaded {size:,} bytes to {local_path}")
            return True
        else:
            print("  ✗ File not created after download")
            return False
    except Exception as e:
        print(f"  Download exception: {e}")
        return False

def archive_and_label_thread(thread_id, label_id):
    """Archive thread and add custom label."""
    if not thread_id:
        print("  Warning: No thread ID, skipping archive/label")
        return False
    
    print(f"  Archiving and labeling thread {thread_id}...")
    
    # Remove INBOX and UNREAD labels, add custom label
    success = True
    
    # Remove INBOX label (archive)
    result = run_gog(["gmail", "thread", "remove-labels", thread_id, "INBOX"], capture_output=False)
    if result is None:
        print("  Warning: Failed to remove INBOX label")
        success = False
    
    # Remove UNREAD label if present
    result = run_gog(["gmail", "thread", "remove-labels", thread_id, "UNREAD"], capture_output=False)
    # Don't fail if UNREAD not present
    
    # Add custom label
    if label_id:
        result = run_gog(["gmail", "thread", "add-labels", thread_id, label_id], capture_output=False)
        if result is None:
            print("  Warning: Failed to add custom label")
            success = False
    
    return success

def log_to_csv(metadata, remote_path):
    """Log processing to CSV file."""
    import csv
    file_exists = os.path.exists(CSV_PATH)
    
    with open(CSV_PATH, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["date", "vendor", "invoice_number", "amount", "remote_path", "processed_at"])
        
        processed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        writer.writerow([
            metadata["date"],
            metadata["vendor"],
            metadata["invoice_number"],
            metadata["amount"],
            remote_path,
            processed_at
        ])
    
    print(f"  ✓ Logged to {CSV_PATH}")

def process_invoice(message_id, nc, label_id):
    """Process a single invoice by message ID."""
    print(f"\nProcessing message {message_id}...")
    
    # Get email data
    email_data = run_gog(["gmail", "get", message_id])
    if not email_data:
        print(f"  Failed to get email data")
        return False
    
    # Parse metadata
    metadata = parse_invoice_metadata(email_data)
    if not metadata:
        print(f"  Failed to parse invoice metadata")
        return False
    
    print(f"  Invoice #: {metadata['invoice_number']}")
    print(f"  Amount: ${metadata['amount']}")
    print(f"  Date: {metadata['date']}")
    
    # Create sanitized filename
    new_filename = sanitize_filename(metadata)
    print(f"  New filename: {new_filename}")
    
    # Download attachment
    temp_dir = "temp_voltage"
    os.makedirs(temp_dir, exist_ok=True)
    temp_path = os.path.join(temp_dir, f"temp_{metadata['invoice_number']}.pdf")
    
    if not download_attachment(message_id, metadata["attachment_id"], temp_path):
        print(f"  ✗ Failed to download attachment")
        return False
    
    # Upload to Nextcloud
    remote_path = f"{FINANCE_BASE}/{new_filename}"
    print(f"  Uploading to {remote_path}...")
    
    result = nc.upload_file(temp_path, remote_path)
    if not result:
        print(f"  ✗ Upload failed")
        os.remove(temp_path)
        return False
    
    print(f"  ✓ Uploaded to {result}")
    
    # Archive and label thread
    archive_and_label_thread(metadata["thread_id"], label_id)
    
    # Log to CSV
    log_to_csv(metadata, result)
    
    # Clean up
    os.remove(temp_path)
    print(f"  ✓ Cleanup complete")
    
    return True

def main():
    print("=" * 60)
    print("PROCESSING REMAINING VOLTAGE INVOICES")
    print("=" * 60)
    
    # Initialize Nextcloud client
    print("\n1. Initializing Nextcloud client...")
    nc = NextcloudClient()
    
    # Ensure label exists
    print("\n2. Setting up Gmail label...")
    label_id = ensure_label_exists()
    if not label_id:
        print("Warning: Could not ensure label exists")
    
    # Process specific invoices (new invoice messages)
    invoices_to_process = [
        ("448A39E5-0011", "19bb1974670b40a3"),  # New invoice for 0011
        ("448A39E5-0010", "19b11f175389aa73"),  # New invoice for 0010
    ]
    
    print(f"\n3. Processing {len(invoices_to_process)} invoices...")
    processed = 0
    failed = []
    
    for invoice_num, message_id in invoices_to_process:
        print(f"\n{'='*40}")
        print(f"Processing invoice #{invoice_num}")
        print(f"{'='*40}")
        
        try:
            success = process_invoice(message_id, nc, label_id)
            if success:
                processed += 1
                print(f"\n✓ Invoice #{invoice_num} processed successfully")
            else:
                failed.append(invoice_num)
                print(f"\n✗ Invoice #{invoice_num} failed")
        except Exception as e:
            print(f"\nException processing {invoice_num}: {e}")
            failed.append(invoice_num)
    
    # Summary
    print(f"\n{'='*60}")
    print("PROCESSING COMPLETE")
    print(f"{'='*60}")
    print(f"Total invoices: {len(invoices_to_process)}")
    print(f"Successfully processed: {processed}")
    print(f"Failed: {len(failed)}")
    if failed:
        print(f"Failed invoices: {', '.join(failed)}")
    
    # Verify uploads
    print(f"\nVerifying uploads in {FINANCE_BASE}...")
    items = nc.list_directory(FINANCE_BASE)
    pdf_files = [i for i in items if i['name'].endswith('.pdf')]
    print(f"Found {len(pdf_files)} PDF files in {FINANCE_BASE}")
    
    if processed > 0:
        print(f"\nCSV log: {os.path.abspath(CSV_PATH)}")
    
    return 0 if len(failed) == 0 else 1

if __name__ == "__main__":
    sys.exit(main())