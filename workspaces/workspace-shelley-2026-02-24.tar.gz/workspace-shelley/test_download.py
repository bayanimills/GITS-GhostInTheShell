#!/usr/bin/env python3
"""Test download of uploaded file."""

import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient
import requests
from requests.auth import HTTPBasicAuth

nc = NextcloudClient()

# Path from upload success
exact_path = "/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/Finance/Incoming/2026-02-19 - Voltage - 448A39E5-0012 - AUD25.00 - Invoice-448A39E5-0012.pdf"

print(f"Testing download of: {exact_path}")
print()

# Method 1: Using client download_file
print("1. Using client.download_file...")
temp = "/tmp/test1.pdf"
success = nc.download_file(exact_path, temp)
print(f"   Result: {success}")
if success:
    import os
    print(f"   Size: {os.path.getsize(temp)} bytes")
    os.remove(temp)

print()

# Method 2: Manual WebDAV request
print("2. Manual WebDAV request...")
# Construct URL manually
from urllib.parse import quote
# Remove leading slash for WebDAV
if exact_path.startswith('/'):
    path = exact_path[1:]
else:
    path = exact_path

encoded = quote(path)
url = f"https://nextcloud.blkstr.io/remote.php/dav/files/jarvis/{encoded}"
print(f"   URL: {url}")

auth = HTTPBasicAuth("jarvis", nc.password)
response = requests.get(url, auth=auth, timeout=10)
print(f"   Status: {response.status_code}")
print(f"   Content-Length: {len(response.content)}")
if response.status_code == 200:
    with open("/tmp/test2.pdf", "wb") as f:
        f.write(response.content)
    print("   ✓ Download successful")
else:
    print(f"   Response: {response.text[:200]}")

print()

# Method 3: Using relative path
print("3. Using relative path 'Finance/Incoming/...'")
relative = "Finance/Incoming/2026-02-19 - Voltage - 448A39E5-0012 - AUD25.00 - Invoice-448A39E5-0012.pdf"
success = nc.download_file(relative, "/tmp/test3.pdf")
print(f"   Result: {success}")

print()

# List directory with raw output
print("4. Raw directory listing...")
items = nc.list_directory("Finance/Incoming")
for item in items:
    print(f"   Name: {item['name']}")
    print(f"   Path: {item['path']}")
    print(f"   Raw: {item}")