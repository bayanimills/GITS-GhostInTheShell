#!/usr/bin/env python3
"""Find and process invoice #448A39E5-0011."""

import sys
import os
import json
import re
import subprocess
from datetime import datetime

sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

ACCOUNT = "service@shopbitcoin.com.au"
LABEL_NAME = "Saved in Nextcloud by Shelley"
LABEL_ID = "Label_18"  # From earlier
INVOICE_NUMBER = "448A39E5-0011"

# Thread IDs for this invoice (from search)
THREAD_IDS = [
    "19bf97651424f281",  # 7 days past due
    "19bd56a6df3a09b4",  # 0 days past due
    "19bcb1d3c232fc84",  # due in 7 days
    "19bb1974670b40a3",  # New invoice
]

def run_gog(args):
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    print(f"  Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        print(f"  Error: {result.stderr[:200]}")
        return None
    return json.loads(result.stdout)

def find_pdf_in_thread(thread_id):
    """Return (attachment, message) if PDF found."""
    thread = run_gog(["gmail", "thread", "get", thread_id])
    if not thread:
        return None, None
    
    messages = thread.get("thread", {}).get("messages", [])
    for msg in messages:
        attachments = msg.get("attachments", [])
        for att in attachments:
            if att.get("mimeType") == "application/pdf":
                return att, msg
    return None, None

def extract_metadata(msg, attachment):
    subject = msg.get("headers", {}).get("subject", "")
    body = msg.get("body", "")
    date_str = msg.get("headers", {}).get("date", "")
    
    # Amount
    amount_match = re.search(r'\$(\d+\.\d{2})', body)
    if not amount_match:
        amount_match = re.search(r'Total due \$(\d+\.\d{2})', body)
    amount = amount_match.group(1) if amount_match else "0.00"
    
    # Date
    email_date = None
    if date_str:
        from email.utils import parsedate_to_datetime
        try:
            dt = parsedate_to_datetime(date_str)
            email_date = dt.strftime("%Y-%m-%d")
        except:
            pass
    
    return {
        "invoice_number": INVOICE_NUMBER,
        "amount": amount,
        "vendor": "Voltage",
        "email_date": email_date,
        "subject": subject,
        "message_id": msg.get("message", {}).get("id"),
        "thread_id": msg.get("message", {}).get("threadId"),
        "attachment_id": attachment.get("attachmentId"),
        "original_filename": attachment.get("filename"),
    }

def download_attachment(message_id, attachment_id, local_path):
    cmd = [
        "gog", "gmail", "attachment", message_id, attachment_id,
        "--account", ACCOUNT,
        "--output", local_path
    ]
    print(f"  Downloading...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    return result.returncode == 0 and os.path.exists(local_path)

def archive_and_label_thread(thread_id):
    # Remove INBOX and UNREAD labels
    subprocess.run(["gog", "gmail", "thread", "modify", thread_id, "--remove", "INBOX", "--account", ACCOUNT], capture_output=True)
    subprocess.run(["gog", "gmail", "thread", "modify", thread_id, "--remove", "UNREAD", "--account", ACCOUNT], capture_output=True)
    subprocess.run(["gog", "gmail", "thread", "modify", thread_id, "--add", LABEL_ID, "--account", ACCOUNT], capture_output=True)
    print(f"  Thread {thread_id} archived and labeled")

def main():
    print(f"Processing invoice {INVOICE_NUMBER}")
    print("=" * 50)
    
    # Initialize Nextcloud
    nc = NextcloudClient()
    
    # Check if already processed
    items = nc.list_directory("Finance/Incoming")
    for item in items:
        if INVOICE_NUMBER in item["name"] and item["name"].endswith(".pdf"):
            print(f"✓ Invoice already processed: {item['name']}")
            return 0
    
    # Search for PDF in threads
    attachment = None
    metadata = None
    source_thread = None
    
    for thread_id in THREAD_IDS:
        print(f"\nChecking thread {thread_id}...")
        att, msg = find_pdf_in_thread(thread_id)
        if att:
            print(f"  Found PDF: {att.get('filename')}")
            attachment = att
            metadata = extract_metadata(msg, att)
            source_thread = thread_id
            break
    
    if not attachment:
        print("✗ No PDF attachment found in any thread")
        return 1
    
    print(f"\nInvoice details:")
    print(f"  Amount: ${metadata['amount']}")
    print(f"  Date: {metadata['email_date']}")
    
    # Create filename
    date = metadata["email_date"] or datetime.now().strftime("%Y-%m-%d")
    amount_str = f"AUD{metadata['amount']}"
    filename = f"{date} - Voltage - {INVOICE_NUMBER} - {amount_str} - Invoice-{INVOICE_NUMBER}.pdf"
    filename = re.sub(r'[<>:"/\\|?*$]', '', filename)
    print(f"  Filename: {filename}")
    
    # Download
    temp_path = f"temp_{INVOICE_NUMBER}.pdf"
    if not download_attachment(metadata["message_id"], metadata["attachment_id"], temp_path):
        print("✗ Download failed")
        return 1
    
    # Upload
    remote_path = f"Finance/Incoming/{filename}"
    print(f"  Uploading to {remote_path}...")
    result = nc.upload_file(temp_path, remote_path)
    if not result:
        print("✗ Upload failed")
        os.remove(temp_path)
        return 1
    
    print(f"✓ Uploaded to {result}")
    
    # Archive and label ALL threads for this invoice
    print(f"\nArchiving and labeling all threads for invoice {INVOICE_NUMBER}...")
    for thread_id in THREAD_IDS:
        archive_and_label_thread(thread_id)
    
    # Log to CSV
    csv_line = f"{date},Voltage,{INVOICE_NUMBER},${metadata['amount']},{result},{datetime.now().isoformat()}"
    with open("voltage_invoices_processed.csv", "a") as f:
        f.write(csv_line + "\n")
    print(f"✓ Logged to CSV")
    
    # Clean up
    os.remove(temp_path)
    
    print(f"\n{'='*50}")
    print(f"INVOICE {INVOICE_NUMBER} PROCESSED SUCCESSFULLY")
    print(f"File: {result}")
    print(f"{'='*50}")
    return 0

if __name__ == "__main__":
    sys.exit(main())