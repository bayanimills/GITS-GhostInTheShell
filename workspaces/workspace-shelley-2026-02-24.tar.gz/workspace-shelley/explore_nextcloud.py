#!/usr/bin/env python3
"""Explore Nextcloud directory structure to find business folders."""

import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import quote
import xml.etree.ElementTree as ET

config = {
    'url': 'https://nextcloud.blkstr.io',
    'username': 'jarvis',
    'password': 'agent12345jarvis'
}

auth = HTTPBasicAuth(config['username'], config['password'])

def list_directory(path):
    """List contents of a WebDAV directory."""
    encoded_path = quote(path, safe='')
    webdav_url = f"{config['url']}/remote.php/dav/files/{config['username']}{encoded_path}"
    
    try:
        headers = {'Depth': '1'}
        response = requests.request('PROPFIND', webdav_url, auth=auth, headers=headers, timeout=10)
        if response.status_code == 207:
            root = ET.fromstring(response.text)
            namespaces = {'d': 'DAV:'}
            items = []
            for response_elem in root.findall('d:response', namespaces):
                href_elem = response_elem.find('d:href', namespaces)
                if href_elem is not None:
                    # Extract relative path
                    full_path = href_elem.text
                    rel_path = full_path.replace(f'/remote.php/dav/files/{config['username']}', '')
                    if rel_path and rel_path != path:
                        # Check if it's a directory
                        propstat = response_elem.find('d:propstat', namespaces)
                        if propstat is not None:
                            prop = propstat.find('d:prop', namespaces)
                            if prop is not None:
                                resource_type = prop.find('d:resourcetype', namespaces)
                                is_dir = resource_type is not None and resource_type.find('d:collection', namespaces) is not None
                                items.append((rel_path, is_dir))
            return items
        else:
            print(f"  Failed to list {path}: Status {response.status_code}")
            return []
    except Exception as e:
        print(f"  Error listing {path}: {e}")
        return []

def explore_recursive(path, depth=0, max_depth=3):
    """Recursively explore directory structure."""
    if depth > max_depth:
        return
    
    prefix = "  " * depth
    items = list_directory(path)
    
    if not items:
        return
    
    dirs = [(p, is_dir) for p, is_dir in items if is_dir]
    files = [(p, is_dir) for p, is_dir in items if not is_dir]
    
    # Print directories
    for rel_path, is_dir in dirs:
        name = rel_path.split('/')[-1] if rel_path.split('/')[-1] else rel_path
        print(f"{prefix}📁 {name}")
        # Recurse into directory
        explore_recursive(rel_path, depth + 1, max_depth)
    
    # Print files (limited)
    if files and depth <= 2:  # Only show files at shallow depth
        file_count = len(files)
        if file_count > 5:
            print(f"{prefix}📄 ({file_count} files)")
        else:
            for rel_path, is_dir in files:
                name = rel_path.split('/')[-1]
                print(f"{prefix}📄 {name}")

print("Exploring Nextcloud directory structure...")
print("Starting from root:")
explore_recursive('/', depth=0, max_depth=4)

# Also check /_private specifically
print("\n\nSpecifically exploring /_private:")
explore_recursive('/_private/', depth=0, max_depth=5)