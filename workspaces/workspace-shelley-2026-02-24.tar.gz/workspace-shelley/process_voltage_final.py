#!/usr/bin/env python3
"""Process all Voltage invoices - final version."""

import sys
import os
import json
import re
import subprocess
import csv
from datetime import datetime
from collections import defaultdict

sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

# Configuration
ACCOUNT = "service@shopbitcoin.com.au"
LABEL_NAME = "Saved in Nextcloud by Shelley"
FINANCE_BASE = "Finance/Incoming"
CSV_PATH = "voltage_invoices_processed.csv"
TEMP_DIR = "temp_voltage"

def run_gog(args, capture_output=True):
    """Run gog command and return parsed JSON if possible."""
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    print(f"  Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=capture_output, text=True, timeout=30)
        if result.returncode != 0:
            print(f"  Error: {result.stderr[:200]}")
            return None
        
        if capture_output:
            return json.loads(result.stdout)
        return True
    except Exception as e:
        print(f"  Command failed: {e}")
        return None

def get_label_id():
    """Get label ID by name."""
    labels = run_gog(["gmail", "labels", "list"])
    if not labels:
        return None
    
    for label in labels.get("labels", []):
        if label.get("name") == LABEL_NAME:
            return label.get("id")
    return None

def extract_invoice_number(subject):
    """Extract invoice number from subject."""
    # Pattern like #448A39E5-0012
    match = re.search(r'#([A-Z0-9\-]+)', subject)
    if match:
        return match.group(1)
    return None

def get_thread_messages(thread_id):
    """Get messages from a thread."""
    result = run_gog(["gmail", "thread", "get", thread_id])
    if not result:
        return None
    
    # Thread structure: {"downloaded":..., "thread": {"messages": [...]}}
    thread_obj = result.get("thread", {})
    return thread_obj.get("messages", [])

def find_pdf_attachment(messages):
    """Find PDF attachment in messages (prefer later messages)."""
    for msg in reversed(messages):  # Start with latest
        attachments = msg.get("attachments", [])
        pdfs = [a for a in attachments if a.get("mimeType") == "application/pdf"]
        if pdfs:
            return pdfs[0], msg
    return None, None

def parse_email_metadata(msg, attachment):
    """Parse metadata from email message."""
    subject = msg.get("headers", {}).get("subject", "")
    body = msg.get("body", "")
    date_str = msg.get("headers", {}).get("date", "")
    
    invoice_number = extract_invoice_number(subject)
    if not invoice_number:
        return None
    
    # Extract amount
    amount_match = re.search(r'\$(\d+\.\d{2})', body)
    if not amount_match:
        amount_match = re.search(r'Total due \$(\d+\.\d{2})', body)
    amount = amount_match.group(1) if amount_match else "0.00"
    
    # Parse date
    email_date = None
    if date_str:
        from email.utils import parsedate_to_datetime
        try:
            dt = parsedate_to_datetime(date_str)
            email_date = dt.strftime("%Y-%m-%d")
        except:
            pass
    
    return {
        "invoice_number": invoice_number,
        "amount": amount,
        "vendor": "Voltage",
        "email_date": email_date,
        "subject": subject,
        "message_id": msg.get("message", {}).get("id"),
        "thread_id": msg.get("message", {}).get("threadId"),
        "attachment_id": attachment.get("attachmentId"),
        "original_filename": attachment.get("filename"),
    }

def sanitize_filename(metadata):
    """Create sanitized filename according to convention."""
    date = metadata["email_date"] or datetime.now().strftime("%Y-%m-%d")
    amount_str = f"AUD{metadata['amount']}"
    vendor_clean = re.sub(r'[<>:"/\\|?*]', '', metadata["vendor"])
    
    filename = f"{date} - {vendor_clean} - {metadata['invoice_number']} - {amount_str} - Invoice-{metadata['invoice_number']}.pdf"
    filename = re.sub(r'[<>:"/\\|?*$]', '', filename)
    return filename

def download_attachment(message_id, attachment_id, local_path):
    """Download attachment to local path."""
    cmd = [
        "gog", "gmail", "attachment", message_id, attachment_id,
        "--account", ACCOUNT,
        "--output", local_path
    ]
    
    print(f"  Downloading attachment...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    
    if result.returncode != 0:
        print(f"  Download failed: {result.stderr[:200]}")
        return False
    
    return os.path.exists(local_path)

def archive_and_label_thread(thread_id, label_id):
    """Archive thread and add custom label."""
    # Remove INBOX label
    run_gog(["gmail", "thread", "modify", thread_id, "--remove", "INBOX"], capture_output=False)
    # Remove UNREAD label
    run_gog(["gmail", "thread", "modify", thread_id, "--remove", "UNREAD"], capture_output=False)
    # Add custom label
    if label_id:
        run_gog(["gmail", "thread", "modify", thread_id, "--add", label_id], capture_output=False)
    return True

def log_to_csv(metadata, remote_path):
    """Log processing to CSV file."""
    file_exists = os.path.exists(CSV_PATH)
    
    with open(CSV_PATH, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Date", "Vendor", "Invoice Number", "Amount", "Nextcloud Path", "Processed Timestamp"])
        
        writer.writerow([
            metadata["email_date"] or datetime.now().strftime("%Y-%m-%d"),
            metadata["vendor"],
            metadata["invoice_number"],
            f"${metadata['amount']}",
            remote_path,
            datetime.now().isoformat()
        ])

def invoice_already_processed(nc, invoice_number):
    """Check if invoice already exists in Nextcloud."""
    items = nc.list_directory(FINANCE_BASE)
    for item in items:
        if invoice_number in item["name"] and item["name"].endswith(".pdf"):
            return True
    return False

def main():
    print("=" * 60)
    print("VOLTAGE INVOICE PROCESSING (FINAL)")
    print("=" * 60)
    
    # Setup
    os.makedirs(TEMP_DIR, exist_ok=True)
    nc = NextcloudClient()
    label_id = get_label_id()
    
    # Search for Voltage threads
    print("\n1. Searching for Voltage emails...")
    search_result = run_gog(["gmail", "search", "from:voltage@ OR subject:Voltage"])
    if not search_result:
        print("No search results")
        return 1
    
    threads = search_result.get("threads", [])
    print(f"Found {len(threads)} threads")
    
    # Group by invoice number
    invoice_map = defaultdict(list)  # invoice -> list of (thread_id, date, subject)
    for thread in threads:
        subject = thread.get("subject", "")
        invoice = extract_invoice_number(subject)
        if invoice:
            invoice_map[invoice].append({
                "thread_id": thread["id"],
                "date": thread.get("date", ""),
                "subject": subject
            })
    
    print(f"\n2. Found {len(invoice_map)} unique invoices:")
    for inv, items in invoice_map.items():
        print(f"  • {inv}: {len(items)} reminders")
    
    # Process each invoice
    print(f"\n3. Processing invoices...")
    processed = 0
    skipped = 0
    failed = []
    
    for invoice_number, items in invoice_map.items():
        print(f"\n{'─'*40}")
        print(f"Invoice: {invoice_number}")
        
        # Skip if already processed
        if invoice_already_processed(nc, invoice_number):
            print(f"  ✓ Already processed (file exists in Nextcloud)")
            skipped += 1
            continue
        
        # Pick latest thread (by date)
        latest = max(items, key=lambda x: x["date"])
        thread_id = latest["thread_id"]
        print(f"  Using thread: {thread_id} ({latest['date']})")
        
        # Get thread messages
        messages = get_thread_messages(thread_id)
        if not messages:
            print(f"  ✗ No messages in thread")
            failed.append(invoice_number)
            continue
        
        # Find PDF attachment
        attachment, msg = find_pdf_attachment(messages)
        if not attachment:
            print(f"  ✗ No PDF attachment found")
            failed.append(invoice_number)
            continue
        
        # Parse metadata
        metadata = parse_email_metadata(msg, attachment)
        if not metadata:
            print(f"  ✗ Could not parse metadata")
            failed.append(invoice_number)
            continue
        
        print(f"  Amount: ${metadata['amount']}")
        print(f"  Date: {metadata['email_date']}")
        
        # Create filename
        new_filename = sanitize_filename(metadata)
        print(f"  New filename: {new_filename}")
        
        # Download
        temp_path = os.path.join(TEMP_DIR, f"{invoice_number}.pdf")
        if not download_attachment(metadata["message_id"], metadata["attachment_id"], temp_path):
            print(f"  ✗ Download failed")
            failed.append(invoice_number)
            continue
        
        # Upload
        remote_path = f"{FINANCE_BASE}/{new_filename}"
        print(f"  Uploading to {remote_path}...")
        result = nc.upload_file(temp_path, remote_path)
        if not result:
            print(f"  ✗ Upload failed")
            os.remove(temp_path)
            failed.append(invoice_number)
            continue
        
        print(f"  ✓ Uploaded to {result}")
        
        # Archive and label
        archive_and_label_thread(thread_id, label_id)
        print(f"  ✓ Email archived and labeled")
        
        # Log to CSV
        log_to_csv(metadata, result)
        print(f"  ✓ Logged to CSV")
        
        # Clean up
        os.remove(temp_path)
        
        processed += 1
    
    # Summary
    print(f"\n{'='*60}")
    print("PROCESSING SUMMARY")
    print(f"{'='*60}")
    print(f"Unique invoices found: {len(invoice_map)}")
    print(f"Successfully processed: {processed}")
    print(f"Skipped (already processed): {skipped}")
    print(f"Failed: {len(failed)}")
    if failed:
        print(f"Failed invoices: {', '.join(failed)}")
    
    # Verify files in Nextcloud
    print(f"\nVerifying Nextcloud contents...")
    items = nc.list_directory(FINANCE_BASE)
    pdfs = [i for i in items if i['name'].endswith('.pdf')]
    print(f"Total PDFs in {FINANCE_BASE}: {len(pdfs)}")
    for pdf in pdfs:
        print(f"  • {pdf['name']}")
    
    # Clean up temp directory
    if os.path.exists(TEMP_DIR):
        import shutil
        shutil.rmtree(TEMP_DIR)
        print(f"\nCleaned up temp directory")
    
    print(f"\nCSV log: {os.path.abspath(CSV_PATH)}")
    
    return 0 if len(failed) == 0 else 1

if __name__ == "__main__":
    sys.exit(main())