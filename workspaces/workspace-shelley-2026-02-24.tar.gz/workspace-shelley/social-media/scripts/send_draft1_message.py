#!/usr/bin/env python3
"""
Send Draft 1 with 'message' field format as requested by user.
Payload format: message field containing post details.
"""

import json
import requests
from datetime import datetime, timezone
from pathlib import Path

# Configuration
WEBHOOK_URL = "https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z"
USER_AGENT = "ShopBitcoinAus/1.0"

def load_draft(draft_id="draft_1"):
    """Load draft from buffer-drafts-batch-1.json."""
    script_dir = Path(__file__).parent
    draft_file = script_dir.parent / "buffer-drafts-batch-1.json"
    
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        
        for draft in data.get('drafts', []):
            if draft.get('id') == draft_id:
                return draft
        return None
    except Exception as e:
        print(f"Error loading draft: {e}")
        return None

def create_message_payload(draft):
    """
    Create payload with 'message' field as requested.
    Format based on user instruction: "Your payload should include the post details in 'message'."
    """
    # Option 1: Simple message field (just text)
    payload = {
        "message": draft["text"],
        "action": "post_tweet",  # or "schedule_tweet"
        "platform": "twitter",
        "account": draft.get("target_account", "@ShopBitcoinAus"),
        "schedule": "now",  # immediate posting
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "test": False,
        "metadata": {
            "draft_id": draft["id"],
            "content_style": draft["content_style"],
            "batch_id": "sba_batch_1_20260215"
        }
    }
    return payload

def send_payload(payload):
    """Send payload to Make.com webhook."""
    print("📤 Sending Draft 1 with 'message' field format:")
    print(json.dumps(payload, indent=2))
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT
    }
    
    try:
        response = requests.post(
            WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"\n📥 Response - Status: {response.status_code}")
        print(f"Response text: {response.text[:500]}")
        
        # Log result
        result = {
            "sent_at": datetime.now(timezone.utc).isoformat(),
            "draft_id": "draft_1",
            "status_code": response.status_code,
            "response": response.text,
            "webhook": WEBHOOK_URL,
            "payload": payload
        }
        
        result_file = Path(__file__).parent.parent / "draft1_message_result.json"
        with open(result_file, 'w') as f:
            json.dump(result, f, indent=2)
        
        print(f"\n💾 Result saved to: {result_file}")
        
        return response.status_code == 200 or response.status_code == 202
        
    except Exception as e:
        print(f"❌ Error sending payload: {e}")
        return False

def main():
    print("🚀 Sending Draft 1 with 'message' field format")
    print("=" * 60)
    
    # Load draft
    draft = load_draft()
    if not draft:
        print("❌ Could not load draft_1")
        return 1
    
    print(f"✅ Loaded draft: {draft['content_style']}")
    print(f"Text preview: {draft['text'][:100]}...")
    
    # Create payload with message field
    payload = create_message_payload(draft)
    
    # Send payload
    success = send_payload(payload)
    
    print("\n" + "=" * 60)
    if success:
        print("✅ Payload sent successfully (200/202 status)")
        print("Next steps:")
        print("  1. Check Make.com scenario execution logs")
        print("  2. Monitor Twitter @ShopBitcoinAus for publication")
        print("  3. Verify Buffer dashboard for scheduled posts")
    else:
        print("❌ Payload sending failed or rejected")
        print("Check webhook configuration and Make.com scenario activation")
    
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())