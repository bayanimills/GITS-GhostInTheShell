#!/usr/bin/env python3
"""
Test Twitter API App-Only (Bearer Token) connectivity - SAFE version (no POST).
"""

import urllib.parse
import requests
import json
import sys

# Bearer Token from config (URL-encoded)
ENCODED_BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAAB%2BoxwEAAAAAtYHZ4xoyvmWrI3xg9oVvlg3FukE%3Dlntc2haZOYZbLfzSjeFxeGEKkGpy2hmmOkpicDJilb37mAb5t9"

def decode_token(encoded_token):
    """Decode URL-encoded Bearer Token."""
    return urllib.parse.unquote(encoded_token)

def test_app_only_endpoints(bearer_token):
    """Test endpoints that work with App-Only authentication."""
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "User-Agent": "OpenClaw-Shelley/1.0"
    }
    
    endpoints = [
        {
            "name": "Recent Search",
            "url": "https://api.twitter.com/2/tweets/search/recent",
            "params": {"query": "bitcoin", "max_results": 5},
            "method": "GET"
        },
        {
            "name": "Tweet Lookup (single)",
            "url": "https://api.twitter.com/2/tweets/20",  # Example tweet ID
            "params": {},
            "method": "GET"
        },
        {
            "name": "User Lookup by ID",
            "url": "https://api.twitter.com/2/users/44196397",  # @elonmusk
            "params": {"user.fields": "created_at,description"},
            "method": "GET"
        },
        {
            "name": "Rate Limits",
            "url": "https://api.twitter.com/2/application/rate_limit_status",
            "params": {"resources": "tweets,users"},
            "method": "GET"
        }
    ]
    
    results = []
    
    for endpoint in endpoints:
        print(f"\n🔍 Testing: {endpoint['name']}")
        print(f"   URL: {endpoint['url']}")
        
        try:
            if endpoint['method'] == 'GET':
                response = requests.get(
                    endpoint['url'],
                    headers=headers,
                    params=endpoint['params'],
                    timeout=10
                )
            else:
                continue
            
            print(f"   Status: {response.status_code}")
            
            # Check rate limit headers
            rate_limit = {
                'limit': response.headers.get('x-rate-limit-limit'),
                'remaining': response.headers.get('x-rate-limit-remaining'),
                'reset': response.headers.get('x-rate-limit-reset')
            }
            if any(rate_limit.values()):
                print(f"   Rate Limit: {rate_limit['remaining']}/{rate_limit['limit']} (resets {rate_limit['reset']})")
            
            if response.status_code == 200:
                data = response.json()
                print(f"   ✅ Success")
                
                # Show sample data
                if endpoint['name'] == 'Recent Search':
                    if 'data' in data:
                        tweets = data['data']
                        print(f"   Found {len(tweets)} tweets")
                        for tweet in tweets[:2]:
                            text_preview = tweet['text'][:80] + "..." if len(tweet['text']) > 80 else tweet['text']
                            print(f"     - {text_preview}")
                
                results.append((endpoint['name'], True, response.status_code))
            else:
                print(f"   ❌ Error: {response.status_code}")
                if response.text:
                    try:
                        error_data = json.loads(response.text)
                        print(f"   Message: {error_data.get('title', 'Unknown error')}")
                        print(f"   Detail: {error_data.get('detail', 'No details')}")
                    except:
                        print(f"   Response: {response.text[:200]}")
                results.append((endpoint['name'], False, response.status_code))
                
        except requests.exceptions.RequestException as e:
            print(f"   ❌ Request failed: {e}")
            results.append((endpoint['name'], False, str(e)))
        except Exception as e:
            print(f"   ❌ Unexpected error: {e}")
            results.append((endpoint['name'], False, str(e)))
    
    return results

def check_write_permissions(bearer_token):
    """Check if token might have write permissions (safe check)."""
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "User-Agent": "OpenClaw-Shelley/1.0"
    }
    
    print(f"\n🔍 Checking write permissions (safe check)...")
    
    # Check rate limit status for write endpoints
    try:
        # This endpoint might reveal available resources
        response = requests.get(
            "https://api.twitter.com/2/application/rate_limit_status",
            headers=headers,
            params={"resources": "tweets,users"},
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            resources = data.get('resources', {})
            
            print(f"   Available rate limit resources:")
            for resource_type, endpoints in resources.items():
                for endpoint, limit_info in endpoints.items():
                    if '/2/tweets' in endpoint and 'POST' in limit_info.get('methods', ''):
                        print(f"     - {endpoint}: {limit_info.get('limit')} requests")
                        print(f"       ➤ Write permissions may be available")
                        return True
            
            print(f"   No write endpoint rate limits found")
            return False
        else:
            print(f"   Could not check rate limits: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"   Error checking write permissions: {e}")
        return False

def main():
    print("🔧 Twitter API App-Only Connectivity Test (SAFE)")
    print("=" * 60)
    
    # Decode token
    bearer_token = decode_token(ENCODED_BEARER_TOKEN)
    print(f"Token: {bearer_token[:30]}... (length: {len(bearer_token)})")
    
    # Test app-only endpoints
    print("\n📊 Testing App-Only Endpoints:")
    results = test_app_only_endpoints(bearer_token)
    
    # Check write permissions safely
    has_write = check_write_permissions(bearer_token)
    
    # Summary
    print("\n" + "=" * 60)
    print("📈 Test Summary:")
    
    success_count = sum(1 for _, success, _ in results if success)
    total_count = len(results)
    
    for name, success, code in results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"  {status} {name} (Code: {code})")
    
    print(f"\n  Success rate: {success_count}/{total_count}")
    
    # Determine capabilities
    if success_count > 0:
        print("\n🎯 Detected Capabilities:")
        print("  - Read public tweets: ✅" if any("Search" in name and success for name, success, _ in results) else "  - Read public tweets: ❌")
        print("  - Read user profiles: ✅" if any("User Lookup" in name and success for name, success, _ in results) else "  - Read user profiles: ❌")
        print("  - Check rate limits: ✅" if any("Rate Limits" in name and success for name, success, _ in results) else "  - Check rate limits: ❌")
        print(f"  - Write tweets: {'✅ Possibly' if has_write else '❌ Unlikely (or not tested)'}")
    
    # Final assessment
    print("\n" + "=" * 60)
    if success_count >= 1:
        print("✅ Twitter API App-Only access CONFIRMED")
        print("\n📝 Next steps:")
        print("  1. This token can read public Twitter data")
        print("  2. Write capability needs further testing (use Buffer for safety)")
        print("  3. For engagement tracking, read access is sufficient")
        return 0
    else:
        print("❌ Twitter API access FAILED")
        print("\n🔧 Troubleshooting:")
        print("  1. Token may be expired or revoked")
        print("  2. Token may have restricted permissions")
        print("  3. Check Twitter Developer Portal for app settings")
        return 1

if __name__ == "__main__":
    sys.exit(main())