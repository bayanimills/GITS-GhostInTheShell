#!/usr/bin/env python3
"""
Switch between Make.com webhook configurations.
"""

import json
import sys
from pathlib import Path

WEBHOOKS = {
    "old": {
        "id": "5y3lugj7v4mo6fixu7ugbe2xsv31lvvt",
        "url": "https://hook.us2.make.com/5y3lugj7v4mo6fixu7ugbe2xsv31lvvt",
        "description": "Original webhook (currently active)"
    },
    "new": {
        "id": "vumwb8qh0mjdjewqiv9bbw1vndz9qt1z",
        "url": "https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z",
        "description": "New webhook (currently inactive - 410 error)"
    }
}

def list_webhooks():
    print("📋 Available Webhooks:")
    for key, info in WEBHOOKS.items():
        status = "✅ ACTIVE" if key == "old" else "❌ INACTIVE"
        print(f"  [{key}] {info['description']}")
        print(f"      URL: {info['url']}")
        print(f"      Status: {status}")
        print()

def switch_webhook(choice):
    if choice not in WEBHOOKS:
        print(f"❌ Unknown webhook: {choice}")
        return False
    
    info = WEBHOOKS[choice]
    config = {
        "webhook_url": info["url"],
        "webhook_id": info["id"],
        "updated_at": "2026-02-15T22:20:00Z",
        "note": f"Switched to {choice} webhook via switch_webhook.py",
        "description": info["description"]
    }
    
    config_path = Path(__file__).parent.parent / "webhook_config.json"
    
    try:
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        print(f"✅ Switched to {choice} webhook:")
        print(f"   URL: {info['url']}")
        print(f"   Config saved to: {config_path}")
        
        # Test the webhook
        import requests
        try:
            response = requests.post(
                info["url"],
                json={"test": True, "message": "Webhook switch test"},
                timeout=10
            )
            print(f"   Test response: {response.status_code} - {response.text[:50]}")
        except Exception as e:
            print(f"   Test error: {e}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error saving config: {e}")
        return False

def main():
    if len(sys.argv) != 2:
        list_webhooks()
        print("Usage: python3 switch_webhook.py <old|new>")
        print("\nExample: python3 switch_webhook.py old")
        return 1
    
    choice = sys.argv[1].lower()
    success = switch_webhook(choice)
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())