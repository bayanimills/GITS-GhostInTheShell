#!/usr/bin/env python3
"""
Add scheduled draft entries to engagement tracking CSV.
"""

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

def load_drafts():
    """Load drafts from JSON file."""
    script_dir = Path(__file__).parent
    draft_file = script_dir.parent / "buffer-drafts-batch-1.json"
    
    with open(draft_file, 'r') as f:
        data = json.load(f)
    return data.get('drafts', [])

def load_schedule_times():
    """Load schedule times from scheduling_results.json."""
    script_dir = Path(__file__).parent
    schedule_file = script_dir.parent / "scheduling_results.json"
    
    with open(schedule_file, 'r') as f:
        data = json.load(f)
    
    # Map draft_id to schedule_utc
    schedule_map = {}
    for result in data.get('results', []):
        schedule_map[result['draft_id']] = result['schedule_utc']
    return schedule_map

def main():
    csv_file = Path(__file__).parent.parent / "engagement_data.csv"
    
    drafts = load_drafts()
    schedule_map = load_schedule_times()
    
    new_rows = []
    for draft in drafts:
        draft_id = draft['id']
        if draft_id not in schedule_map:
            print(f"⚠️ No schedule time for {draft_id}, skipping")
            continue
        
        schedule_utc = schedule_map[draft_id]
        now = datetime.now(timezone.utc)
        
        row = {
            'timestamp': now.isoformat(),
            'post_id': f'{draft_id}_scheduled_{int(now.timestamp())}',
            'draft_id': draft_id,
            'content_style': draft['content_style'],
            'scheduled_time': schedule_utc,
            'published_time': '',
            'likes': '',
            'retweets': '',
            'replies': '',
            'impressions': '',
            'profile_visits': '',
            'link_clicks': '',
            'notes': f'Scheduled via Make.com webhook with formal Buffer API payload'
        }
        new_rows.append(row)
        print(f"✅ Added {draft_id} scheduled for {schedule_utc}")
    
    # Write to CSV
    fieldnames = [
        'timestamp', 'post_id', 'draft_id', 'content_style', 'scheduled_time',
        'published_time', 'likes', 'retweets', 'replies', 'impressions',
        'profile_visits', 'link_clicks', 'notes'
    ]
    
    file_exists = csv_file.exists()
    
    with open(csv_file, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        for row in new_rows:
            writer.writerow(row)
    
    print(f"\n💾 Added {len(new_rows)} scheduled entries to {csv_file}")

if __name__ == "__main__":
    main()