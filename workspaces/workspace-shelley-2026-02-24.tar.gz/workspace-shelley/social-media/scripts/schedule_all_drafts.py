#!/usr/bin/env python3
"""
Schedule all 5 drafts via Make.com webhook at optimal AEST times.
"""

import json
import requests
import sys
import os
from datetime import datetime, timezone, timedelta
import config
import payload_formatter

MAKE_WEBHOOK_URL = config.get_webhook_url()

def load_drafts():
    """Load all drafts from JSON file using payload_formatter."""
    return payload_formatter.load_all_drafts()

def aest_to_utc(aest_time_str, base_date_utc):
    """
    Convert AEST time string (HH:MM AEST) to UTC datetime.
    AEST = UTC+10
    """
    # Parse time string like "09:00 AEST"
    time_part = aest_time_str.split(' ')[0]  # "09:00"
    hours, minutes = map(int, time_part.split(':'))
    
    # Create datetime in UTC+10, then convert to UTC
    # Base date is in UTC, we need to create a datetime in AEST (UTC+10)
    # Add 10 hours to get AEST, then subtract 10 to get UTC? Better: create naive datetime with base date, treat as AEST, then subtract 10h
    aest_dt = datetime(
        base_date_utc.year,
        base_date_utc.month,
        base_date_utc.day,
        hours,
        minutes,
        tzinfo=timezone(timedelta(hours=10))  # AEST = UTC+10
    )
    utc_dt = aest_dt.astimezone(timezone.utc)
    return utc_dt

def create_schedule_times():
    """Create schedule times for all 5 drafts."""
    # Base date is tomorrow (Feb 16, 2026)
    base_date = datetime(2026, 2, 16, tzinfo=timezone.utc)
    
    # Optimal times from drafts
    optimal_times = [
        "09:00 AEST",  # draft_1
        "12:00 AEST",  # draft_2
        "15:00 AEST",  # draft_3
        "18:00 AEST",  # draft_4
        "21:00 AEST",  # draft_5
    ]
    
    schedule_times = []
    for time_str in optimal_times:
        utc_time = aest_to_utc(time_str, base_date)
        schedule_times.append(utc_time.isoformat())
    
    return schedule_times

def send_draft(draft, schedule_utc_iso, attempt=1):
    """Send a single draft to Make.com webhook using formal Buffer API format."""
    # Create formal Buffer API payload
    payload = payload_formatter.create_buffer_payload(draft, schedule_utc_iso)
    
    # Validate payload
    is_valid, error_message = payload_formatter.validate_payload(payload)
    if not is_valid:
        print(f"   ❌ Payload validation failed: {error_message}")
        return False, error_message
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    print(f"📤 Sending {draft['id']} ({draft['content_style']})...")
    print(f"   Schedule: {schedule_utc_iso}")
    print(f"   Text preview: {draft['text'][:80]}...")
    print(f"   Payload format: Buffer API (validated)")
    
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.text[:100]}")
        
        if response.status_code in [200, 201, 202]:
            print(f"   ✅ Accepted")
            return True, response.text
        else:
            print(f"   ⚠️ Unexpected status")
            return False, response.text
            
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False, str(e)

def main():
    print("📅 Schedule All Drafts")
    print("=" * 60)
    print(f"Webhook: {MAKE_WEBHOOK_URL}")
    print("=" * 60)
    
    # Load drafts
    drafts = load_drafts()
    if not drafts:
        print("❌ No drafts loaded")
        return 1
    
    print(f"Loaded {len(drafts)} drafts")
    
    # Create schedule times
    schedule_times = create_schedule_times()
    print("\n📅 Schedule Times (UTC):")
    for i, (draft, schedule) in enumerate(zip(drafts, schedule_times)):
        print(f"  {draft['id']}: {schedule} (original: {draft.get('optimal_time', 'N/A')})")
    
    # Confirm with user (in automated mode, we'll proceed)
    print("\n" + "=" * 60)
    print("🚀 Proceeding to schedule all 5 drafts...")
    
    results = []
    for draft, schedule in zip(drafts, schedule_times):
        success, response = send_draft(draft, schedule)
        results.append({
            "draft_id": draft["id"],
            "content_style": draft["content_style"],
            "schedule_utc": schedule,
            "success": success,
            "response": response[:200]
        })
        print()  # Blank line between drafts
    
    print("=" * 60)
    print("📊 Scheduling Results:")
    success_count = sum(1 for r in results if r["success"])
    print(f"   Successfully scheduled: {success_count}/{len(results)}")
    
    for result in results:
        status = "✅" if result["success"] else "❌"
        print(f"  {status} {result['draft_id']} ({result['content_style']})")
        print(f"     Schedule: {result['schedule_utc']}")
        if not result["success"]:
            print(f"     Error: {result['response']}")
    
    print("\n" + "=" * 60)
    print("🎯 Next Steps:")
    print("  1. Check Make.com scenario execution logs")
    print("  2. Verify Buffer dashboard for scheduled posts")
    print("  3. Monitor Twitter for publications at scheduled times")
    print("  4. Begin engagement tracking after posts go live")
    
    # Save results to file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    results_file = os.path.join(script_dir, "..", "scheduling_results.json")
    with open(results_file, 'w') as f:
        json.dump({
            "scheduled_at": datetime.now(timezone.utc).isoformat(),
            "webhook_url": MAKE_WEBHOOK_URL,
            "results": results
        }, f, indent=2)
    
    print(f"\n💾 Results saved to: scheduling_results.json")
    
    return 0 if success_count == len(results) else 1

if __name__ == "__main__":
    sys.exit(main())