#!/usr/bin/env python3
"""
Template for sending drafts to Buffer webhook.
Configure with your webhook URL before use.
"""

import json
import requests
import sys
import os

# CONFIGURATION - UPDATE THESE VALUES
BUFFER_WEBHOOK_URL = "https://api.bufferapp.com/1/updates/create.json"  # EXAMPLE - REPLACE
BUFFER_ACCESS_TOKEN = "YOUR_BUFFER_ACCESS_TOKEN"  # EXAMPLE - REPLACE OR USE HEADERS
BUFFER_PROFILE_IDS = ["YOUR_TWITTER_PROFILE_ID"]  # EXAMPLE - REPLACE

# Headers configuration
HEADERS = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {BUFFER_ACCESS_TOKEN}" if BUFFER_ACCESS_TOKEN else None
}

def load_drafts(draft_file):
    """Load drafts from JSON file."""
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        return data
    except Exception as e:
        print(f"Error loading drafts: {e}")
        return None

def create_buffer_payload(draft, schedule_time=None):
    """Create Buffer API payload from draft."""
    payload = {
        "profile_ids": BUFFER_PROFILE_IDS,
        "text": draft["text"],
        "shorten": False,
        "now": False if schedule_time else True,
        "top": False,
        "media": {
            "photo": draft.get("suggested_image", ""),
            "thumbnail": "",
            "description": f"Shop Bitcoin Australia: {draft['content_style']}"
        } if draft.get("suggested_image") else None
    }
    
    if schedule_time and not payload["now"]:
        payload["scheduled_at"] = schedule_time
    
    # Remove None values
    payload = {k: v for k, v in payload.items() if v is not None}
    
    return payload

def send_to_buffer(payload, dry_run=True):
    """Send payload to Buffer webhook."""
    if dry_run:
        print("🔧 DRY RUN - Would send payload:")
        print(json.dumps(payload, indent=2))
        print(f"📤 Would POST to: {BUFFER_WEBHOOK_URL}")
        return True
    
    try:
        response = requests.post(
            BUFFER_WEBHOOK_URL,
            headers={k: v for k, v in HEADERS.items() if v is not None},
            json=payload,
            timeout=30
        )
        
        print(f"📤 Sent to Buffer - Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Success! Update ID: {data.get('id')}")
            print(f"   Scheduled for: {data.get('scheduled_at')}")
            print(f"   Status: {data.get('status')}")
            return True
        else:
            print(f"❌ Error: {response.status_code}")
            print(f"Response: {response.text[:500]}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
        return False

def main():
    print("📤 Buffer Webhook Sender Template")
    print("=" * 60)
    
    # Check configuration
    if BUFFER_WEBHOOK_URL.startswith("https://example") or "YOUR_" in BUFFER_WEBHOOK_URL:
        print("❌ Configuration required!")
        print("\nPlease update the following in the script:")
        print(f"  1. BUFFER_WEBHOOK_URL: {BUFFER_WEBHOOK_URL}")
        print(f"  2. BUFFER_ACCESS_TOKEN: {'Set' if BUFFER_ACCESS_TOKEN else 'Not set'}")
        print(f"  3. BUFFER_PROFILE_IDS: {BUFFER_PROFILE_IDS}")
        print("\nUsage: Edit script with your Buffer credentials")
        return 1
    
    # Load drafts
    script_dir = os.path.dirname(os.path.abspath(__file__))
    draft_file = os.path.join(script_dir, "..", "buffer-drafts-batch-1.json")
    
    drafts_data = load_drafts(draft_file)
    if not drafts_data:
        return 1
    
    print(f"📝 Loaded {len(drafts_data.get('drafts', []))} drafts")
    
    # Interactive mode
    print("\n🎯 Select mode:")
    print("  1. Dry run (test without sending)")
    print("  2. Send single draft")
    print("  3. Schedule all drafts")
    
    try:
        choice = input("\nEnter choice (1-3): ").strip()
    except EOFError:
        choice = "1"  # Default to dry run
    
    dry_run = choice == "1"
    
    if choice == "1":
        print("\n🔧 DRY RUN MODE - No posts will be sent")
        
        # Test first draft
        if drafts_data['drafts']:
            draft = drafts_data['drafts'][0]
            payload = create_buffer_payload(draft)
            send_to_buffer(payload, dry_run=True)
            
    elif choice == "2":
        # Send single draft
        print("\n📤 Send single draft")
        for i, draft in enumerate(drafts_data['drafts']):
            print(f"  {i+1}. {draft['content_style']} ({len(draft['text'])} chars)")
        
        try:
            draft_idx = int(input("\nSelect draft (1-5): ")) - 1
            if 0 <= draft_idx < len(drafts_data['drafts']):
                draft = drafts_data['drafts'][draft_idx]
                payload = create_buffer_payload(draft)
                send_to_buffer(payload, dry_run=False)
            else:
                print("Invalid selection")
        except (ValueError, EOFError):
            print("Invalid input")
            
    elif choice == "3":
        print("\n📅 Schedule all drafts")
        print("WARNING: This will schedule all 5 drafts!")
        confirm = input("Type 'yes' to confirm: ")
        if confirm.lower() == 'yes':
            # Schedule with staggered times (every 3 hours)
            import datetime
            base_time = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)
            
            for i, draft in enumerate(drafts_data['drafts']):
                schedule_time = base_time + datetime.timedelta(hours=i*3)
                schedule_iso = schedule_time.isoformat()
                
                print(f"\n📤 Draft {i+1}: {draft['content_style']}")
                print(f"   Scheduled: {schedule_iso}")
                
                payload = create_buffer_payload(draft, schedule_time=schedule_iso)
                success = send_to_buffer(payload, dry_run=False)
                
                if not success:
                    print(f"⚠️ Failed to schedule draft {i+1}")
                    break
        else:
            print("Cancelled")
    else:
        print("Invalid choice")
    
    print("\n" + "=" * 60)
    print("📝 Next steps:")
    print("  1. Check Buffer dashboard for scheduled posts")
    print("  2. Monitor Twitter for publication")
    print("  3. Run engagement tracking after posts go live")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())