#!/usr/bin/env python3
"""
Manual engagement tracker for Shop Bitcoin Australia social media.
Use when Twitter API token is invalid.
"""

import csv
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# File paths
SCRIPT_DIR = Path(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = SCRIPT_DIR.parent
ENGAGEMENT_FILE = DATA_DIR / "engagement_data.csv"
DRAFTS_FILE = DATA_DIR / "buffer-drafts-batch-1.json"

def setup_tracking():
    """Create CSV file with proper headers if it doesn't exist."""
    if ENGAGEMENT_FILE.exists():
        print(f"📁 Engagement file already exists: {ENGAGEMENT_FILE}")
        return True
    
    headers = [
        "timestamp",
        "post_id",
        "draft_id",
        "content_style",
        "scheduled_time",
        "published_time",
        "likes",
        "retweets",
        "replies",
        "impressions",
        "profile_visits",
        "link_clicks",
        "notes"
    ]
    
    with open(ENGAGEMENT_FILE, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
    
    print(f"✅ Created engagement tracking file: {ENGAGEMENT_FILE}")
    print(f"   Headers: {', '.join(headers)}")
    return True

def load_drafts():
    """Load drafts to map draft IDs to content."""
    if not DRAFTS_FILE.exists():
        print(f"⚠️ Drafts file not found: {DRAFTS_FILE}")
        return {}
    
    try:
        with open(DRAFTS_FILE, 'r') as f:
            data = json.load(f)
        
        drafts = {}
        for draft in data.get('drafts', []):
            drafts[draft['id']] = draft
        
        print(f"📝 Loaded {len(drafts)} drafts")
        return drafts
    except Exception as e:
        print(f"❌ Error loading drafts: {e}")
        return {}

def record_engagement():
    """Manually record engagement metrics for a post."""
    drafts = load_drafts()
    
    print("\n📊 Record Engagement Metrics")
    print("=" * 60)
    
    # Show available drafts
    if drafts:
        print("Available drafts:")
        for draft_id, draft in drafts.items():
            print(f"  {draft_id}: {draft['content_style']}")
            print(f"     Preview: {draft['text'][:80]}...")
    else:
        print("No drafts loaded. You can still enter draft ID manually.")
    
    # Get post information
    print("\nEnter post details:")
    
    post_id = input("Twitter Post ID (or URL): ").strip()
    draft_id = input("Draft ID (e.g., draft_1): ").strip()
    
    # Get draft info if available
    content_style = "unknown"
    if draft_id in drafts:
        content_style = drafts[draft_id]['content_style']
        print(f"   Content style: {content_style}")
    
    # Get times
    published_time = input("Published time (YYYY-MM-DD HH:MM, or leave for now): ").strip()
    if not published_time:
        published_time = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
        print(f"   Using current time: {published_time}")
    
    # Get metrics
    print("\nEnter engagement metrics (leave blank for 0):")
    likes = input("Likes: ").strip() or "0"
    retweets = input("Retweets: ").strip() or "0"
    replies = input("Replies: ").strip() or "0"
    impressions = input("Impressions: ").strip() or "0"
    profile_visits = input("Profile visits: ").strip() or "0"
    link_clicks = input("Link clicks: ").strip() or "0"
    
    notes = input("Notes (optional): ").strip()
    
    # Prepare record
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "post_id": post_id,
        "draft_id": draft_id,
        "content_style": content_style,
        "published_time": published_time,
        "likes": likes,
        "retweets": retweets,
        "replies": replies,
        "impressions": impressions,
        "profile_visits": profile_visits,
        "link_clicks": link_clicks,
        "notes": notes
    }
    
    # Write to CSV
    file_exists = ENGAGEMENT_FILE.exists()
    with open(ENGAGEMENT_FILE, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=record.keys())
        if not file_exists:
            writer.writeheader()
        writer.writerow(record)
    
    print(f"\n✅ Recorded engagement data for {draft_id}")
    print(f"   Saved to: {ENGAGEMENT_FILE}")
    return True

def view_data():
    """View engagement data."""
    if not ENGAGEMENT_FILE.exists():
        print("❌ No engagement data file found. Run setup first.")
        return False
    
    with open(ENGAGEMENT_FILE, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        print("📭 No engagement records yet.")
        return True
    
    print(f"\n📊 Engagement Data ({len(rows)} records)")
    print("=" * 60)
    
    for i, row in enumerate(rows, 1):
        print(f"\nRecord {i}:")
        print(f"  Draft: {row.get('draft_id', 'N/A')} ({row.get('content_style', 'N/A')})")
        print(f"  Published: {row.get('published_time', 'N/A')}")
        print(f"  Metrics: 👍 {row.get('likes', '0')} | 🔁 {row.get('retweets', '0')} | 💬 {row.get('replies', '0')}")
        print(f"  Impressions: {row.get('impressions', '0')}")
        if row.get('notes'):
            print(f"  Notes: {row['notes']}")
    
    return True

def generate_report():
    """Generate simple engagement report."""
    if not ENGAGEMENT_FILE.exists():
        print("❌ No engagement data file found.")
        return False
    
    with open(ENGAGEMENT_FILE, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        print("📭 No engagement records yet.")
        return True
    
    # Calculate totals
    total_likes = sum(int(row.get('likes', 0)) for row in rows)
    total_retweets = sum(int(row.get('retweets', 0)) for row in rows)
    total_replies = sum(int(row.get('replies', 0)) for row in rows)
    total_impressions = sum(int(row.get('impressions', 0)) for row in rows)
    
    # Group by content style
    style_stats = {}
    for row in rows:
        style = row.get('content_style', 'unknown')
        if style not in style_stats:
            style_stats[style] = {
                'count': 0,
                'likes': 0,
                'retweets': 0,
                'replies': 0,
                'impressions': 0
            }
        
        stats = style_stats[style]
        stats['count'] += 1
        stats['likes'] += int(row.get('likes', 0))
        stats['retweets'] += int(row.get('retweets', 0))
        stats['replies'] += int(row.get('replies', 0))
        stats['impressions'] += int(row.get('impressions', 0))
    
    print("\n📈 Engagement Report")
    print("=" * 60)
    print(f"Total Posts: {len(rows)}")
    print(f"Total Likes: {total_likes}")
    print(f"Total Retweets: {total_retweets}")
    print(f"Total Replies: {total_replies}")
    print(f"Total Impressions: {total_impressions}")
    
    if len(rows) > 0:
        avg_engagement = (total_likes + total_retweets * 2 + total_replies * 3) / len(rows)
        print(f"Avg Engagement Score: {avg_engagement:.2f}")
    
    print("\n📊 Performance by Content Style:")
    for style, stats in style_stats.items():
        print(f"\n  {style}:")
        print(f"    Posts: {stats['count']}")
        print(f"    Likes: {stats['likes']} (avg: {stats['likes']/stats['count']:.1f})")
        print(f"    Retweets: {stats['retweets']} (avg: {stats['retweets']/stats['count']:.1f})")
        print(f"    Impressions: {stats['impressions']} (avg: {stats['impressions']/stats['count']:.0f})")
    
    # Save report
    report_file = DATA_DIR / "engagement_report.md"
    with open(report_file, 'w') as f:
        f.write(f"# Engagement Report - {datetime.now(timezone.utc).strftime('%Y-%m-%d')}\n\n")
        f.write(f"- **Total Posts**: {len(rows)}\n")
        f.write(f"- **Total Likes**: {total_likes}\n")
        f.write(f"- **Total Retweets**: {total_retweets}\n")
        f.write(f"- **Total Replies**: {total_replies}\n")
        f.write(f"- **Total Impressions**: {total_impressions}\n\n")
        
        f.write("## Performance by Content Style\n\n")
        for style, stats in style_stats.items():
            f.write(f"### {style}\n")
            f.write(f"- Posts: {stats['count']}\n")
            f.write(f"- Likes: {stats['likes']}\n")
            f.write(f"- Retweets: {stats['retweets']}\n")
            f.write(f"- Replies: {stats['replies']}\n")
            f.write(f"- Impressions: {stats['impressions']}\n\n")
    
    print(f"\n💾 Report saved to: {report_file}")
    return True

def main():
    print("📊 Manual Engagement Tracker")
    print("=" * 60)
    print(f"Data directory: {DATA_DIR}")
    
    # Ensure data directory exists
    DATA_DIR.mkdir(exist_ok=True)
    
    # Menu
    print("\n🎯 Select action:")
    print("  1. Setup tracking system (create CSV)")
    print("  2. Record engagement metrics")
    print("  3. View existing data")
    print("  4. Generate report")
    print("  5. Exit")
    
    try:
        choice = input("\nEnter choice (1-5): ").strip()
    except EOFError:
        choice = "5"
    
    if choice == "1":
        setup_tracking()
    elif choice == "2":
        record_engagement()
    elif choice == "3":
        view_data()
    elif choice == "4":
        generate_report()
    elif choice == "5":
        print("👋 Exiting")
        return 0
    else:
        print("❌ Invalid choice")
        return 1
    
    # Ask to continue
    print("\n" + "=" * 60)
    cont = input("Return to menu? (y/n): ").strip().lower()
    if cont == 'y':
        return main()
    else:
        print("👋 Goodbye")
        return 0

if __name__ == "__main__":
    sys.exit(main())