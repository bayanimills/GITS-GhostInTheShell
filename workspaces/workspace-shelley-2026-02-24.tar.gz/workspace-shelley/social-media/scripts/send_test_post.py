#!/usr/bin/env python3
"""
Send a test post to Make.com webhook for immediate verification.
Schedule for 10 minutes from now to allow monitoring.
"""

import json
import requests
import sys
import os
from datetime import datetime, timezone, timedelta
import config

MAKE_WEBHOOK_URL = config.get_webhook_url()

def load_draft(draft_id):
    """Load a specific draft from the JSON file."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    draft_file = os.path.join(script_dir, "..", "buffer-drafts-batch-1.json")
    
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        
        for draft in data.get('drafts', []):
            if draft.get('id') == draft_id:
                return draft
        return None
    except Exception as e:
        print(f"Error loading draft: {e}")
        return None

def send_test_post():
    """Send draft_1 as test post scheduled for 10 minutes from now."""
    draft = load_draft("draft_1")
    if not draft:
        print("❌ Could not load draft_1")
        return False
    
    # Schedule for 10 minutes from now
    schedule_time = datetime.now(timezone.utc) + timedelta(minutes=10)
    schedule_iso = schedule_time.isoformat()
    
    print("📤 Sending Test Post")
    print("=" * 60)
    print(f"Webhook: {MAKE_WEBHOOK_URL}")
    print(f"Draft: {draft['id']} ({draft['content_style']})")
    print(f"Scheduled: {schedule_iso}")
    print(f"Text preview: {draft['text'][:80]}...")
    
    # Simple payload format (tested and accepted)
    payload = {
        "text": draft["text"],
        "platform": "twitter",
        "account": "ShopBitcoinAus",
        "schedule": schedule_iso,
        "test": False,
        "metadata": {
            "test_post": True,
            "purpose": "verify_buffer_integration",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    }
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    print("\n📤 Payload:")
    print(json.dumps(payload, indent=2))
    
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"\n📥 Response - Status: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code in [200, 201, 202]:
            print("\n✅ Test post accepted by Make.com!")
            print("   Check Buffer dashboard for scheduled post")
            print(f"   Expected publication: {schedule_iso}")
            return True, response.text
        else:
            print(f"\n⚠️ Unexpected response status: {response.status_code}")
            return False, response.text
            
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return False, str(e)

def main():
    success, response = send_test_post()
    
    print("\n" + "=" * 60)
    print("🎯 Next Steps:")
    print("  1. Check Make.com scenario execution logs")
    print("  2. Verify Buffer dashboard for scheduled test post")
    print("  3. Monitor Twitter for publication in ~10 minutes")
    print("  4. Use manual engagement tracker to record results")
    
    # Save test result
    script_dir = os.path.dirname(os.path.abspath(__file__))
    result_file = os.path.join(script_dir, "..", "test_post_result.json")
    with open(result_file, 'w') as f:
        json.dump({
            "sent_at": datetime.now(timezone.utc).isoformat(),
            "success": success,
            "response": response[:500],
            "webhook": MAKE_WEBHOOK_URL,
            "purpose": "test_post_verification"
        }, f, indent=2)
    
    print(f"\n💾 Test result saved to: test_post_result.json")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())