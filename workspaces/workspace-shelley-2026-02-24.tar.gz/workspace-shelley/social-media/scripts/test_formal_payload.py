#!/usr/bin/env python3
"""
Test formal payload with immediate posting to verify Make.com processing.
"""

import json
import requests
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import payload_formatter
import config

MAKE_WEBHOOK_URL = config.get_webhook_url()

def test_formal_payload(draft_id="draft_3"):
    """Test formal payload with immediate posting."""
    print("🧪 Testing Formal Payload Processing")
    print("=" * 60)
    print(f"Webhook: {MAKE_WEBHOOK_URL}")
    print(f"Draft: {draft_id}")
    print("=" * 60)
    
    # Load draft
    draft = payload_formatter.load_draft(draft_id)
    if not draft:
        print(f"❌ Could not load draft {draft_id}")
        return False
    
    print(f"✅ Loaded draft: {draft['content_style']}")
    print(f"Text preview: {draft['text'][:80]}...")
    
    # Create formal immediate payload
    payload = payload_formatter.create_buffer_payload(draft, schedule_utc=None)
    print(f"\n📤 Formal Payload (immediate):")
    print(json.dumps(payload, indent=2)[:500])
    
    # Validate payload
    is_valid, error_message = payload_formatter.validate_payload(payload)
    if not is_valid:
        print(f"❌ Payload validation failed: {error_message}")
        return False
    print("✅ Payload validation passed")
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    print("\n🚀 Sending to Make.com...")
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"📥 Response - Status: {response.status_code}")
        print(f"Response: {response.text[:200]}")
        
        if response.status_code in [200, 201, 202]:
            print("✅ Payload accepted by Make.com")
            print("\n🎯 Next Steps:")
            print("   1. Check Make.com scenario execution logs")
            print("   2. Verify Buffer dashboard for immediate post")
            print("   3. Monitor Twitter @ShopBitcoinAus for publication")
            return True
        else:
            print(f"⚠️ Unexpected status {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == "__main__":
    success = test_formal_payload()
    sys.exit(0 if success else 1)