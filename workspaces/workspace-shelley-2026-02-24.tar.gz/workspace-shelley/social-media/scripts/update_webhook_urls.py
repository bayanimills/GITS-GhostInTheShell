#!/usr/bin/env python3
"""
Update all occurrences of old Make.com webhook URL to new one.
"""

import os
import re
import sys
from pathlib import Path

OLD_WEBHOOK_ID = "vumwb8qh0mjdjewqiv9bbw1vndz9qt1z"
NEW_WEBHOOK_ID = "vumwb8qh0mjdjewqiv9bbw1vndz9qt1z"

OLD_WEBHOOK_URL = f"https://hook.us2.make.com/{OLD_WEBHOOK_ID}"
NEW_WEBHOOK_URL = f"https://hook.us2.make.com/{NEW_WEBHOOK_ID}"

# Patterns to replace
REPLACEMENTS = [
    (OLD_WEBHOOK_URL, NEW_WEBHOOK_URL),
    (OLD_WEBHOOK_ID, NEW_WEBHOOK_ID),
]

def update_file(filepath):
    """Update webhook URLs in a single file."""
    try:
        with open(filepath, 'r') as f:
            content = f.read()
        
        original = content
        for old, new in REPLACEMENTS:
            content = content.replace(old, new)
        
        if content != original:
            with open(filepath, 'w') as f:
                f.write(content)
            return True, f"Updated {filepath}"
        else:
            return False, f"No changes needed in {filepath}"
            
    except Exception as e:
        return False, f"Error updating {filepath}: {e}"

def main():
    print("🔄 Updating Make.com webhook URLs")
    print("=" * 60)
    print(f"Old: {OLD_WEBHOOK_URL}")
    print(f"New: {NEW_WEBHOOK_URL}")
    
    # Find all relevant files
    script_dir = Path(__file__).parent
    workspace_dir = script_dir.parent
    
    files_to_update = []
    
    # Python files
    for py_file in workspace_dir.rglob("*.py"):
        files_to_update.append(py_file)
    
    # Markdown files
    for md_file in workspace_dir.rglob("*.md"):
        files_to_update.append(md_file)
    
    # JSON files (except test results)
    for json_file in workspace_dir.rglob("*.json"):
        if "test_post_result" not in str(json_file) and "new_webhook_test" not in str(json_file):
            files_to_update.append(json_file)
    
    updated_count = 0
    error_count = 0
    
    for filepath in files_to_update:
        relative = filepath.relative_to(workspace_dir)
        print(f"\n📄 Checking: {relative}")
        
        changed, message = update_file(filepath)
        if changed:
            print(f"   ✅ {message}")
            updated_count += 1
        elif "Error" in message:
            print(f"   ❌ {message}")
            error_count += 1
        else:
            print(f"   ⏭️ {message}")
    
    print("\n" + "=" * 60)
    print("📊 Update Summary:")
    print(f"   Files checked: {len(files_to_update)}")
    print(f"   Files updated: {updated_count}")
    print(f"   Errors: {error_count}")
    
    # Create configuration file with new webhook
    config_file = workspace_dir / "webhook_config.json"
    config = {
        "webhook_url": NEW_WEBHOOK_URL,
        "webhook_id": NEW_WEBHOOK_ID,
        "updated_at": "2026-02-15T22:10:00Z",
        "note": "Updated per user request"
    }
    
    with open(config_file, 'w') as f:
        import json
        json.dump(config, f, indent=2)
    
    print(f"\n💾 Configuration saved to: {config_file.relative_to(workspace_dir)}")
    
    return 0 if error_count == 0 else 1

if __name__ == "__main__":
    sys.exit(main())