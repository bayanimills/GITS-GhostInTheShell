#!/usr/bin/env python3
"""
Test Twitter API connectivity using Bearer Token from OpenClaw config.
"""

import urllib.parse
import requests
import json
import sys

# Bearer Token from config (URL-encoded)
ENCODED_BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAAB%2BoxwEAAAAAtYHZ4xoyvmWrI3xg9oVvlg3FukE%3Dlntc2haZOYZbLfzSjeFxeGEKkGpy2hmmOkpicDJilb37mAb5t9"

def decode_token(encoded_token):
    """Decode URL-encoded Bearer Token."""
    return urllib.parse.unquote(encoded_token)

def test_api_connectivity(bearer_token):
    """Test Twitter API v2 connectivity."""
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "User-Agent": "OpenClaw-Shelley/1.0"
    }
    
    # Test endpoint: Get authenticated user (if token has user context)
    # Or use a public endpoint if app-only
    test_url = "https://api.twitter.com/2/users/me"
    
    try:
        print(f"Testing Twitter API connectivity...")
        print(f"Token length: {len(bearer_token)} chars")
        print(f"Token preview: {bearer_token[:20]}...")
        
        response = requests.get(test_url, headers=headers, timeout=10)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Success! API Response:")
            print(json.dumps(data, indent=2))
            
            # Extract user info if available
            if "data" in data:
                user = data["data"]
                print(f"\n📊 Authenticated User:")
                print(f"  ID: {user.get('id')}")
                print(f"  Username: @{user.get('username')}")
                print(f"  Name: {user.get('name')}")
            return True
        else:
            print(f"❌ API Error: {response.status_code}")
            print(f"Response: {response.text[:500]}")
            
            # Try a different endpoint - public tweet lookup
            print(f"\nTrying public endpoint...")
            public_url = "https://api.twitter.com/2/tweets/20"  # Example tweet ID
            response2 = requests.get(public_url, headers=headers, timeout=10)
            print(f"Public endpoint status: {response2.status_code}")
            if response2.status_code == 200:
                print(f"✅ Public API access works!")
                return True
            else:
                print(f"Public endpoint error: {response2.text[:500]}")
                return False
                
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
        return False
    except json.JSONDecodeError as e:
        print(f"❌ JSON decode error: {e}")
        print(f"Response text: {response.text[:500]}")
        return False

def test_rate_limits(bearer_token):
    """Check rate limit headers."""
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "User-Agent": "OpenClaw-Shelley/1.0"
    }
    
    test_url = "https://api.twitter.com/2/users/me"
    
    try:
        response = requests.get(test_url, headers=headers, timeout=10)
        
        print(f"\n📊 Rate Limit Info:")
        for key, value in response.headers.items():
            if 'rate-limit' in key.lower():
                print(f"  {key}: {value}")
        
        # If no rate limit headers, try to get from error
        if 'x-rate-limit-limit' not in response.headers:
            print(f"  No rate limit headers found (may be app-only token)")
            
    except Exception as e:
        print(f"Rate limit check error: {e}")

def main():
    print("🔧 Twitter API Connectivity Test")
    print("=" * 50)
    
    # Decode token
    bearer_token = decode_token(ENCODED_BEARER_TOKEN)
    print(f"Decoded token length: {len(bearer_token)} chars")
    
    # Test connectivity
    success = test_api_connectivity(bearer_token)
    
    # Check rate limits
    if success:
        test_rate_limits(bearer_token)
    
    print("\n" + "=" * 50)
    if success:
        print("✅ Twitter API connectivity test PASSED")
        return 0
    else:
        print("❌ Twitter API connectivity test FAILED")
        return 1

if __name__ == "__main__":
    sys.exit(main())