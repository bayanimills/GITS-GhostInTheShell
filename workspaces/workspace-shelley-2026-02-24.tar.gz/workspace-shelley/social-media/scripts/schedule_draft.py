#!/usr/bin/env python3
"""
Schedule a single draft with specific time to Make.com webhook.
"""

import json
import requests
import sys
import os
from datetime import datetime, timezone, timedelta
import config
import payload_formatter

MAKE_WEBHOOK_URL = config.get_webhook_url()

def load_draft(draft_id):
    """Load a specific draft from the JSON file."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    draft_file = os.path.join(script_dir, "..", "buffer-drafts-batch-1.json")
    
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        
        for draft in data.get('drafts', []):
            if draft.get('id') == draft_id:
                return draft
        return None
    except Exception as e:
        print(f"Error loading draft: {e}")
        return None

def schedule_draft(draft_id, schedule_utc):
    """Schedule a draft for specific UTC time using formal Buffer API format."""
    draft = payload_formatter.load_draft(draft_id)
    if not draft:
        print(f"❌ Could not load draft {draft_id}")
        return False
    
    print(f"📝 Draft: {draft['content_style']}")
    print(f"   Original optimal time: {draft.get('optimal_time', 'N/A')}")
    print(f"   Schedule for: {schedule_utc} (UTC)")
    
    # Create formal Buffer API payload
    payload = payload_formatter.create_buffer_payload(draft, schedule_utc)
    
    # Validate payload
    is_valid, error_message = payload_formatter.validate_payload(payload)
    if not is_valid:
        print(f"❌ Payload validation failed: {error_message}")
        return False
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    print(f"\n📤 Sending {draft_id} with formal Buffer API format...")
    print(f"   Payload validated successfully")
    
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.text[:100]}")
        
        if response.status_code in [200, 201, 202]:
            print(f"   ✅ Accepted by Make.com")
            return True
        else:
            print(f"   ⚠️ Unexpected status")
            return False
            
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def main():
    print("📅 Schedule Draft Test")
    print("=" * 60)
    
    # Schedule draft 2 (technical) for 2 hours from now (test)
    now_utc = datetime.now(timezone.utc)
    schedule_time = now_utc + timedelta(hours=2)
    schedule_iso = schedule_time.isoformat()
    
    print(f"Current UTC: {now_utc.isoformat()}")
    print(f"Schedule UTC: {schedule_iso}")
    
    success = schedule_draft("draft_2", schedule_iso)
    
    if success:
        print("\n✅ Schedule test completed successfully")
        print("   Check Make.com logs and Buffer dashboard")
    else:
        print("\n⚠️ Schedule test may have issues")
        print("   Check Make.com scenario configuration")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())