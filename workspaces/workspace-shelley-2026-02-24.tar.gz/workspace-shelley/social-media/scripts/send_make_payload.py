#!/usr/bin/env python3
"""
Send payload to Make.com webhook for Shop Bitcoin Australia.
Test different payload formats to determine correct structure.
"""

import json
import requests
import sys
import os
from datetime import datetime, timezone
import config
import payload_formatter

MAKE_WEBHOOK_URL = config.get_webhook_url()

def load_draft(draft_id):
    """Load a specific draft from the JSON file using payload_formatter."""
    return payload_formatter.load_draft(draft_id)

def create_payloads(draft):
    """Create different payload formats for testing."""
    
    # Format 1: Simple format (accepted in earlier test)
    simple = {
        "text": draft["text"],
        "platform": "twitter",
        "account": "ShopBitcoinAus",
        "schedule": "now",
        "test": False  # Actually schedule
    }
    
    # Format 2: Minimal format
    minimal = {
        "message": draft["text"],
        "action": "schedule_tweet"
    }
    
    # Format 3: Buffer API-like format (what Buffer expects)
    buffer_format = {
        "profile_ids": ["twitter_shopbitcoinaus"],  # Make.com might map this
        "text": draft["text"],
        "shorten": False,
        "now": True,
        "top": False,
        "media": {
            "photo": draft.get("suggested_image", ""),
            "description": f"Shop Bitcoin Australia: {draft['content_style']}"
        } if draft.get("suggested_image") else None
    }
    # Remove None values
    buffer_format = {k: v for k, v in buffer_format.items() if v is not None}
    
    # Format 4: Make.com webhook typical format (generic)
    make_format = {
        "event": "schedule_tweet",
        "data": {
            "text": draft["text"],
            "platform": "twitter",
            "schedule_at": datetime.now(timezone.utc).isoformat(),
            "metadata": {
                "draft_id": draft["id"],
                "content_style": draft["content_style"],
                "batch_id": "sba_batch_1_20260215"
            }
        }
    }
    
    # Format 5: Formal Buffer API format (validated)
    formal_immediate = payload_formatter.create_buffer_payload(draft)
    
    return {
        "simple": simple,
        "minimal": minimal,
        "buffer": buffer_format,
        "make": make_format,
        "formal_immediate": formal_immediate
    }

def send_payload(payload, name):
    """Send payload to Make.com webhook."""
    print(f"\n📤 Sending {name} payload:")
    print(json.dumps(payload, indent=2)[:500] + ("..." if len(json.dumps(payload)) > 500 else ""))
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"\n📥 Response - Status: {response.status_code}")
        
        if response.headers.get('Content-Type', '').startswith('application/json'):
            try:
                response_json = response.json()
                print("Response JSON:")
                print(json.dumps(response_json, indent=2)[:1000])
            except:
                print(f"Response text: {response.text[:500]}")
        else:
            print(f"Response: {response.text[:500]}")
        
        if response.status_code in [200, 201, 202]:
            print(f"✅ {name} payload accepted!")
            return True, response.text
        else:
            print(f"⚠️ {name} payload returned status {response.status_code}")
            return False, response.text
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
        return False, str(e)

def main():
    print("📤 Make.com Payload Sender")
    print("=" * 60)
    print(f"Webhook: {MAKE_WEBHOOK_URL}")
    print("=" * 60)
    
    # Load draft 1 (educational beginner)
    draft = load_draft("draft_1")
    if not draft:
        print("❌ Could not load draft_1")
        return 1
    
    print(f"Loaded draft: {draft['content_style']}")
    print(f"Text preview: {draft['text'][:100]}...")
    
    # Create payloads
    payloads = create_payloads(draft)
    
    # Test each payload
    results = {}
    for name, payload in payloads.items():
        success, response = send_payload(payload, name)
        results[name] = {"success": success, "response_preview": response[:200]}
    
    print("\n" + "=" * 60)
    print("📊 Results Summary:")
    for name, result in results.items():
        status = "✅ Accepted" if result["success"] else "❌ Failed/Rejected"
        print(f"  {name}: {status}")
        print(f"     Response: {result['response_preview']}")
    
    print("\n" + "=" * 60)
    print("🎯 Recommendations:")
    print("  1. Check Make.com scenario execution logs")
    print("  2. Verify Buffer dashboard for scheduled posts")
    print("  3. Monitor Twitter for test posts")
    print("  4. Based on results, use the successful payload format")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())