#!/usr/bin/env python3
"""
Test different webhook URL variations.
"""

import requests
import json
import config

def test_url(url, payload):
    """Test a URL with a payload."""
    print(f"\n🔍 Testing: {url}")
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    try:
        # First try HEAD
        try:
            head_resp = requests.head(url, timeout=5)
            print(f"  HEAD status: {head_resp.status_code}")
        except:
            print("  HEAD failed (expected for some webhooks)")
        
        # Then POST
        resp = requests.post(url, headers=headers, json=payload, timeout=10)
        print(f"  POST status: {resp.status_code}")
        if resp.text:
            print(f"  Response: {resp.text[:200]}")
        return resp.status_code, resp.text
    except Exception as e:
        print(f"  Error: {e}")
        return None, str(e)

def main():
    base_id = config.get_webhook_id()
    test_payload = {"test": True, "message": "Webhook format test"}
    
    url_variations = [
        # Standard Make.com format
        f"https://hook.us2.make.com/{base_id}",
        
        # Alternative with @ in path (unlikely but trying)
        f"https://hook.us2.make.com/{base_id}@hook.us2.make.com",
        
        # Subdomain format
        f"https://{base_id}.hook.us2.make.com",
        
        # With workspace prefix (common pattern)
        f"https://hook.us2.make.com/workspace/{base_id}",
        
        # Different Make.com regions
        f"https://hook.us1.make.com/{base_id}",
        f"https://hook.eu1.make.com/{base_id}",
        
        # HTTP instead of HTTPS
        f"http://hook.us2.make.com/{base_id}",
    ]
    
    print("🛠️ Testing webhook URL variations")
    print("=" * 60)
    
    results = []
    for url in url_variations:
        status, response = test_url(url, test_payload)
        results.append({
            "url": url,
            "status": status,
            "response": response[:100] if response else None
        })
    
    print("\n" + "=" * 60)
    print("📊 Results Summary:")
    for result in results:
        status = result["status"]
        if status == 200:
            print(f"✅ {result['url']} - Status: {status}")
        elif status:
            print(f"⚠️ {result['url']} - Status: {status}")
        else:
            print(f"❌ {result['url']} - Error")

if __name__ == "__main__":
    main()