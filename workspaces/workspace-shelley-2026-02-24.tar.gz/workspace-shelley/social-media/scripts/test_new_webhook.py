#!/usr/bin/env python3
"""
Test the new Make.com webhook URL provided by user.
"""

import json
import requests
import sys
from datetime import datetime, timezone

NEW_WEBHOOK_URL = "https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z"
OLD_WEBHOOK_URL = "https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z"

def test_webhook(url, label):
    """Test webhook with simple payload."""
    print(f"\n🔍 Testing {label}: {url}")
    
    payload = {
        "text": "Test webhook connection",
        "platform": "twitter",
        "account": "ShopBitcoinAus",
        "test": True,
        "metadata": {
            "test": True,
            "purpose": "webhook_validation",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    }
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    try:
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.text[:100]}")
        
        return response.status_code, response.text
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return None, str(e)

def main():
    print("🔄 Testing Make.com Webhooks")
    print("=" * 60)
    
    # Test old webhook first
    old_status, old_response = test_webhook(OLD_WEBHOOK_URL, "OLD webhook")
    
    # Test new webhook
    new_status, new_response = test_webhook(NEW_WEBHOOK_URL, "NEW webhook")
    
    print("\n" + "=" * 60)
    print("📋 Summary:")
    
    if old_status in [200, 201, 202]:
        print("✅ OLD webhook: ACTIVE")
    else:
        print("⚠️ OLD webhook: INACTIVE or ERROR")
    
    if new_status in [200, 201, 202]:
        print("✅ NEW webhook: ACTIVE")
    else:
        print("❌ NEW webhook: INACTIVE or ERROR")
    
    print("\n🎯 Recommendations:")
    if new_status in [200, 201, 202]:
        print("  1. Update all scripts to use NEW webhook")
        print("  2. Consider if OLD webhook posts need cancellation")
        print("  3. Send test post to NEW webhook for verification")
    else:
        print("  1. NEW webhook may need activation in Make.com")
        print("  2. Continue using OLD webhook if functional")
        print("  3. Contact user for clarification")
    
    # Save test results
    result_file = "/home/agent/.openclaw/workspace-shelley/social-media/new_webhook_test.json"
    with open(result_file, 'w') as f:
        json.dump({
            "tested_at": datetime.now(timezone.utc).isoformat(),
            "old_webhook": {
                "url": OLD_WEBHOOK_URL,
                "status": old_status,
                "response": old_response[:500] if old_response else None
            },
            "new_webhook": {
                "url": NEW_WEBHOOK_URL,
                "status": new_status,
                "response": new_response[:500] if new_response else None
            }
        }, f, indent=2)
    
    print(f"\n💾 Test results saved to: new_webhook_test.json")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())