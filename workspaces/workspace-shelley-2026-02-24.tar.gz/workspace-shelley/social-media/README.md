# Shop Bitcoin Australia - Social Media Management

**Directory**: `/home/agent/.openclaw/workspace-shelley/social-media/`  
**Created**: 2026-02-15  
**Purpose**: Manage social media content creation, scheduling, and engagement tracking for Shop Bitcoin Australia

## 📁 File Structure

### **Content Creation**
- `drafts-batch-1.md` - 5 social media drafts with metadata and testing strategy (uses "The Bitaxe Gamma" phrasing)
- `buffer-drafts-batch-1.json` - Drafts formatted for Buffer API via Make.com webhook integration

### **System Design**
- `engagement-tracking-system.md` - Complete architecture for tracking post performance
- `content-strategy.md` - Long-term content planning based on product analysis
- `NEXT_STEPS.md` - Implementation roadmap and blocker resolution

### **Scripts (`scripts/`)**
- `test_twitter_api.py` - Twitter API connectivity test (initial)
- `test_twitter_app_only_safe.py` - Safe Twitter API test (app-only endpoints)
- `send_to_buffer_template.py` - Template for sending drafts to Buffer webhook
- `test_make_webhook.py` - Test Make.com webhook connectivity and payloads
- `test_webhook_variations.py` - Test different webhook URL formats
- `test_twitter_app_only.py` - Original app-only test (contains risky POST test - avoid)

### **Documentation**
- `README.md` - This file

## 🎯 Current Status

### ✅ **Ready:**
- 5 social media drafts (educational, technical, community, event, product styles) with "The Bitaxe Gamma" phrasing
- Engagement tracking system design
- Buffer integration payload format (ready for Make.com webhook)
- Testing scripts for API connectivity
- **Webhook configured** to NEW webhook (`vumwb8qh0mjdjewqiv9bbw1vndz9qt1z@hook.us2.make.com`) - ✅ **ACTIVE & OPERATIONAL** (draft_2 sent successfully)
- **Test post sent** (draft_1 scheduled for 22:11 UTC via old webhook)

### ⚠️ **Blockers:**
1. **Twitter API Token Invalid** - Bearer Token returns 401 Unauthorized (token appears to be mock)
2. **Twitter Skill Mock** - Installed `x-twitter` skill is mock implementation
3. **Make.com Webhook Configuration** - ✅ **RESOLVED** - NEW webhook active, draft_2 sent successfully, awaiting publication verification

### 🔄 **Pending Actions:**
1. Validate/fix Twitter API credentials (or accept manual tracking)
2. **Verify test post publication** (scheduled for 22:11 UTC)
3. Schedule remaining 4 drafts once test confirmed
4. Monitor engagement using manual tracking system

## 🚀 Quick Start

### **1. Test Twitter API**
```bash
cd scripts
python3 test_twitter_app_only_safe.py
```

### **2. Send Drafts to Buffer** (once webhook configured)
```bash
cd scripts
# Edit send_to_buffer_template.py with webhook details
python3 send_to_buffer_template.py
```

### **3. Monitor Engagement**
```bash
# Requires valid Twitter API token
python3 scripts/twitter_engagement_tracker.py --token YOUR_TOKEN
```

## 📊 Content Styles Tested

| Draft | Style | Target Audience | Testing Focus |
|-------|-------|----------------|---------------|
| 1 | Educational/Beginner | Bitcoin beginners | Beginner conversion |
| 2 | Technical/Network Support | Experienced miners | Technical engagement |
| 3 | Community Awareness | All Bitcoiners | Ecosystem engagement |
| 4 | Event Promotion | Community participants | Event awareness |
| 5 | Product Setup Realistic | Practical buyers | Setup transparency |

## 🔧 Technical Integration

### **Twitter API**
- **Endpoint**: v2 (app-only Bearer Token)
- **Required**: Valid Bearer Token with read permissions
- **Capabilities**: Post engagement tracking, tweet lookup, user lookup

### **Buffer Integration (via Make.com)**
- **Method**: Make.com webhook to Buffer
- **Payload**: JSON with text, media, scheduling options
- **Authentication**: Depends on Make.com webhook configuration

### **Engagement Tracking**
- **Metrics**: Likes, retweets, replies, impressions, clicks
- **Frequency**: Hourly checks for 48 hours post-publication
- **Storage**: Local JSON database for performance analysis

## 📝 Best Practices

### **Content Creation:**
- No hashtags (per brand guidance)
- Use line breaks for readability
- Australian-focused messaging
- Product photos preferred

### **Scheduling:**
- Multiple posts daily via Buffer (through Make.com)
- Full Australian day coverage (AEST timezone)
- Stagger posts for optimal engagement

### **Testing:**
- A/B test different content styles
- Track sales correlation
- Adjust strategy based on performance data

## 🔒 Security Notes

- **API Tokens**: Store in OpenClaw config, not in scripts
- **Credentials**: Never commit to version control
- **Data Privacy**: No PII collection; business intelligence only
- **Rate Limits**: Respect Twitter API rate limits (450 requests/15min)

## 📞 Support

### **Immediate Assistance Needed:**
1. Twitter API token validation
2. Buffer webhook configuration
3. Image asset coordination

### **Progress Updates:**
- Daily performance reports when tracking active
- Alert for technical issues
- Weekly optimization recommendations

---

**Last Updated**: 2026-02-16  
**Next Review**: When blockers resolved  
**Owner**: Shelley (Shop Bitcoin Australia Manager)