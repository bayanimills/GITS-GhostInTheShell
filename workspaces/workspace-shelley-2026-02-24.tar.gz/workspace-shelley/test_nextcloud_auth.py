#!/usr/bin/env python3
"""Test Nextcloud authentication and WebDAV access."""

import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import quote
import sys

# Configuration from nextcloud_client.py
config = {
    'url': 'https://nextcloud.blkstr.io',
    'username': 'jarvis',
    'password': 'agent12345jarvis',
    'base_path': '/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin'
}

def test_auth():
    """Test basic authentication."""
    print(f"Testing Nextcloud connection to: {config['url']}")
    print(f"Username: {config['username']}")
    print(f"Base path: {config['base_path']}")
    print()
    
    auth = HTTPBasicAuth(config['username'], config['password'])
    
    # Test 1: Basic server connection
    print("1. Testing server connection...")
    try:
        response = requests.get(config['url'], auth=auth, timeout=10)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            print("   ✓ Server accessible")
        else:
            print(f"   ✗ Unexpected status: {response.status_code}")
    except Exception as e:
        print(f"   ✗ Connection failed: {e}")
    
    # Test 2: WebDAV PROPFIND on root
    print("\n2. Testing WebDAV PROPFIND on root...")
    webdav_root = f"{config['url']}/remote.php/dav/files/{config['username']}/"
    try:
        headers = {'Depth': '1'}
        response = requests.request('PROPFIND', webdav_root, auth=auth, headers=headers, timeout=10)
        print(f"   Status: {response.status_code}")
        print(f"   Response length: {len(response.text)} chars")
        if response.status_code == 207:
            print("   ✓ WebDAV access successful")
            # Parse XML response
            import xml.etree.ElementTree as ET
            root = ET.fromstring(response.text)
            namespaces = {'d': 'DAV:'}
            for response_elem in root.findall('d:response', namespaces):
                href_elem = response_elem.find('d:href', namespaces)
                if href_elem is not None:
                    print(f"     Found: {href_elem.text}")
        elif response.status_code == 401:
            print("   ✗ Authentication failed (401)")
        elif response.status_code == 404:
            print("   ✗ Not found (404) - check username or path")
        else:
            print(f"   ✗ Unexpected status: {response.status_code}")
    except Exception as e:
        print(f"   ✗ WebDAV test failed: {e}")
    
    # Test 3: Test specific base path
    print(f"\n3. Testing base path: {config['base_path']}")
    encoded_path = quote(config['base_path'], safe='')
    webdav_path = f"{config['url']}/remote.php/dav/files/{config['username']}{encoded_path}"
    try:
        headers = {'Depth': '1'}
        response = requests.request('PROPFIND', webdav_path, auth=auth, headers=headers, timeout=10)
        print(f"   Status: {response.status_code}")
        if response.status_code == 207:
            print("   ✓ Base path accessible")
        elif response.status_code == 404:
            print("   ✗ Base path not found (404)")
            print("   Note: This might mean the folder doesn't exist yet")
        else:
            print(f"   ✗ Unexpected status: {response.status_code}")
    except Exception as e:
        print(f"   ✗ Base path test failed: {e}")
    
    # Test 4: List what's actually in the root
    print("\n4. Listing actual root directory contents...")
    webdav_root = f"{config['url']}/remote.php/dav/files/{config['username']}/"
    try:
        headers = {'Depth': '1'}
        response = requests.request('PROPFIND', webdav_root, auth=auth, headers=headers, timeout=10)
        if response.status_code == 207:
            import xml.etree.ElementTree as ET
            root = ET.fromstring(response.text)
            namespaces = {'d': 'DAV:'}
            print("   Contents of root directory:")
            count = 0
            for response_elem in root.findall('d:response', namespaces):
                href_elem = response_elem.find('d:href', namespaces)
                if href_elem is not None and href_elem.text != f'/remote.php/dav/files/{config['username']}/':
                    path = href_elem.text.replace(f'/remote.php/dav/files/{config['username']}', '')
                    if path:
                        print(f"     • {path}")
                        count += 1
            if count == 0:
                print("     (Empty or no subdirectories)")
        else:
            print(f"   Could not list contents (status: {response.status_code})")
    except Exception as e:
        print(f"   ✗ Listing failed: {e}")
    
    print("\n" + "="*50)
    print("Summary: Check if base path exists or needs to be created")
    return True

if __name__ == '__main__':
    test_auth()