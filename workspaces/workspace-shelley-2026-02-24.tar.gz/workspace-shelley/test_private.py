#!/usr/bin/env python3
"""Test accessing /_private directory."""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

config = {
    'url': 'https://nextcloud.blkstr.io',
    'username': 'jarvis',
    'password': 'agent12345jarvis'
}

auth = HTTPBasicAuth(config['username'], config['password'])

# Test 1: Access /_private without encoding leading slash
# The WebDAV base is: /remote.php/dav/files/jarvis
# To access /_private, we need: /remote.php/dav/files/jarvis/_private

url = f"{config['url']}/remote.php/dav/files/{config['username']}/_private"
print(f"Testing URL: {url}")

headers = {'Depth': '1'}
response = requests.request('PROPFIND', url, auth=auth, headers=headers, timeout=10)

if response.status_code == 207:
    print(f"Success! Status: {response.status_code}")
    
    # Parse XML
    root = ET.fromstring(response.text)
    namespaces = {'d': 'DAV:'}
    
    print("\nContents of /_private:")
    for response_elem in root.findall('d:response', namespaces):
        href_elem = response_elem.find('d:href', namespaces)
        if href_elem is not None:
            href = href_elem.text
            base = f"/remote.php/dav/files/{config['username']}"
            if href.startswith(base):
                rel_path = href[len(base):]
                if rel_path and rel_path != '/_private':
                    # Check if it's a directory
                    propstat = response_elem.find('d:propstat', namespaces)
                    if propstat is not None:
                        prop = propstat.find('d:prop', namespaces)
                        if prop is not None:
                            resource_type = prop.find('d:resourcetype', namespaces)
                            is_dir = resource_type is not None and resource_type.find('d:collection', namespaces) is not None
                            
                            displayname_elem = prop.find('d:displayname', namespaces)
                            displayname = displayname_elem.text if displayname_elem is not None else rel_path.split('/')[-1]
                            
                            icon = '📁' if is_dir else '📄'
                            print(f"  {icon} {displayname} ({rel_path})")
    
    # Now test for businesses folder
    print("\n--- Testing for businesses folder ---")
    url2 = f"{config['url']}/remote.php/dav/files/{config['username']}/_private/businesses"
    response2 = requests.request('PROPFIND', url2, auth=auth, headers={'Depth': '0'}, timeout=5)
    print(f"  /_private/businesses: Status {response2.status_code}")
    
    if response2.status_code == 207:
        print("  ✓ businesses folder exists")
        # List its contents
        response3 = requests.request('PROPFIND', url2, auth=auth, headers={'Depth': '1'}, timeout=5)
        if response3.status_code == 207:
            root3 = ET.fromstring(response3.text)
            print("  Contents:")
            for response_elem in root3.findall('d:response', namespaces):
                href_elem = response_elem.find('d:href', namespaces)
                if href_elem is not None:
                    href = href_elem.text
                    if '/businesses/' in href:
                        name = href.split('/')[-1]
                        if name:
                            print(f"    • {name}")
    elif response2.status_code == 404:
        print("  ✗ businesses folder doesn't exist")
    else:
        print(f"  ? Unexpected status: {response2.status_code}")
        
else:
    print(f"Failed! Status: {response.status_code}")
    if response.status_code == 404:
        print("  /_private not found - directory doesn't exist or permissions issue")
    print(f"Response: {response.text[:500]}")