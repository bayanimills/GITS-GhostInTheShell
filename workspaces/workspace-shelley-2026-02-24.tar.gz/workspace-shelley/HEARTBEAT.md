# HEARTBEAT.md - Shelley's Periodic Checks

## Tasks to perform during heartbeats

### System Health Checks (every 2 hours)
1. **Check workspace integrity** - Verify all identity files exist
2. **Verify connectivity** - Test essential service connections
3. **Check memory usage** - Monitor workspace memory consumption
4. **Check cron jobs** - Verify daily post cron job status (if enabled)

### Agent Coordination (every 4 hours)
1. **Check agent ecosystem** - Verify other agents are operational
2. **Review task queue** - Check for pending tasks
3. **Update status report** - Document current operational state

### Daily Social Media Tasks
1. **Check for daily post approval** - If cron triggered and user hasn't responded, follow up
2. **Monitor engagement tracking** - Review recent posts in engagement_data.csv
3. **Check webhook status** - Verify Make.com webhook still responsive
4. **Update rotation state** - Ensure daily_post_state.json is current
5. **⚠️ Twitter feed monitoring** - User requested monitoring @ShopBitcoinAus X feed (API token invalid - manual monitoring needed)

### Self-Maintenance (daily)
1. **Run workspace maintenance** - Clean up temporary files
2. **Review memory logs** - Archive old logs, summarize learnings
3. **Update documentation** - Keep procedures current

## Implementation Notes
- Use `session_status` to check model and token usage
- Use `sessions_list` to check other agent activity
- Use `cron list` to verify scheduled jobs
- Log findings to `memory/YYYY-MM-DD.md`

## Alert Thresholds
- **Critical**: Identity files missing, essential services unreachable > 24h
- **Warning**: High memory usage (>80%), other agents offline > 2h
- **Info**: Routine checks completed, no issues found