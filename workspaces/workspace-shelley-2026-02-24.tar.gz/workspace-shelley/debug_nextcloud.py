#!/usr/bin/env python3
"""Debug Nextcloud WebDAV URL construction."""

import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import quote

config = {
    'url': 'https://nextcloud.blkstr.io',
    'username': 'jarvis',
    'password': 'agent12345jarvis'
}

auth = HTTPBasicAuth(config['username'], config['password'])

# Test different URL constructions
test_paths = [
    '/',
    '',
    '/_private/',
    '/_private',
    '//',  # Double slash
]

for path in test_paths:
    # Method 1: Manual encoding
    if path == '/':
        encoded = ''
    else:
        encoded = quote(path, safe='')
    
    url1 = f"{config['url']}/remote.php/dav/files/{config['username']}{encoded}"
    
    # Method 2: With trailing slash
    url2 = f"{config['url']}/remote.php/dav/files/{config['username']}{encoded}/"
    
    print(f"\nTesting path: '{path}'")
    print(f"  URL1: {url1}")
    print(f"  URL2: {url2}")
    
    for url in [url1, url2]:
        try:
            headers = {'Depth': '0'}
            response = requests.request('PROPFIND', url, auth=auth, headers=headers, timeout=5)
            print(f"  {url}: Status {response.status_code}")
            if response.status_code == 207:
                print(f"    ✓ Success")
            elif response.status_code == 404:
                print(f"    ✗ Not found")
            elif response.status_code == 401:
                print(f"    ✗ Unauthorized")
        except Exception as e:
            print(f"  {url}: Error - {e}")