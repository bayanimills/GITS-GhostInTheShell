#!/usr/bin/env python3
"""Explore SBA directory structure."""

import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')

from nextcloud_client import NextcloudClient

client = NextcloudClient()

print("Exploring SBA directory...")
items = client.list_directory('/')
print(f"Root has {len(items)} items")

# List them
for item in items[:20]:
    icon = '📁' if item['is_dir'] else '📄'
    print(f"  {icon} {item['name']} ({item['path']})")
    if item['is_dir'] and item['name'] in ['Collections', 'Vendors', 'shipping', 'bill-invoices-incoming', 'invoices-outgoing', '_Operational', 'socials', 'IG', 'Finance']:
        print(f"    -> Business folder found!")

print("\n--- Checking for Finance folder ---")
finance_exists = client.file_exists('Finance')
print(f"Finance folder exists: {finance_exists}")

if finance_exists:
    finance_items = client.list_directory('Finance')
    print(f"Finance folder has {len(finance_items)} items")
    for item in finance_items:
        icon = '📁' if item['is_dir'] else '📄'
        print(f"  {icon} {item['name']}")
else:
    print("Finance folder doesn't exist yet. Will create it.")
    
print("\n--- Checking existing folder structure ---")
common_folders = ['Collections', 'Vendors', 'shipping', 'bill-invoices-incoming', 'invoices-outgoing', '_Operational', 'socials', 'IG']

for folder in common_folders:
    exists = client.file_exists(folder)
    print(f"{folder}: {'✓' if exists else '✗'}")