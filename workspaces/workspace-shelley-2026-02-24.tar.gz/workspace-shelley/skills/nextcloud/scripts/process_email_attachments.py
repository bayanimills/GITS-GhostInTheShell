#!/usr/bin/env python3
"""
Email Attachment Processor for Nextcloud

Downloads PDF attachments from Gmail and uploads to Nextcloud with organized folder structure.
Integrates with gog CLI for email operations and Nextcloud client for file storage.

Workflow:
1. Search emails with PDF attachments using gog
2. Download attachments to local temp directory
3. Categorize based on email metadata (sender, subject)
4. Upload to Nextcloud with appropriate folder structure
5. Create share links for easy access
6. Label emails as processed and archive

Environment variables:
- GMAIL_ACCOUNT: Gmail account to use (default: service@shopbitcoin.com.au)
- NEXTCLOUD_*: Nextcloud configuration (see nextcloud_client.py)
"""

import os
import sys
import json
import csv
import tempfile
import shutil
import subprocess
import re
from datetime import datetime
from pathlib import Path
import logging

# Try to import Nextcloud client
try:
    from nextcloud_client import NextcloudClient, upload_file, create_share_link
except ImportError:
    # Add current directory to path
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from nextcloud_client import NextcloudClient, upload_file, create_share_link

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
DEFAULT_GMAIL_ACCOUNT = os.environ.get('GMAIL_ACCOUNT', 'service@shopbitcoin.com.au')
TEMP_DIR = os.environ.get('TEMP_DIR', '/tmp/email_attachments')

# Category detection patterns
CATEGORY_PATTERNS = {
    'invoice': {
        'senders': ['voltage', 'shopify', 'xero', 'quickbooks'],
        'subjects': ['invoice', 'bill', 'statement', 'payment due'],
        'folder': '/Accounting/Invoices'
    },
    'receipt': {
        'senders': ['bankful', 'stripe', 'paypal', 'square'],
        'subjects': ['receipt', 'payment confirmation', 'transaction'],
        'folder': '/Accounting/Receipts'
    },
    'statement': {
        'senders': ['bank', 'credit card', 'financial institution'],
        'subjects': ['statement', 'account summary'],
        'folder': '/Accounting/Statements'
    },
    'contract': {
        'senders': ['legal', 'contract', 'agreement'],
        'subjects': ['contract', 'agreement', 'nda', 'terms'],
        'folder': '/Documents/Contracts'
    }
}

# Vendor-specific folder mappings
VENDOR_FOLDERS = {
    'voltage': 'Voltage',
    'shopify': 'Shopify',
    'bankful': 'Bankful',
    'xero': 'Xero',
    'quickbooks': 'QuickBooks',
    'stripe': 'Stripe',
    'paypal': 'PayPal'
}

class EmailAttachmentProcessor:
    """Process email attachments and upload to Nextcloud."""
    
    def __init__(self, gmail_account=None, nextcloud_config=None):
        """
        Initialize processor.
        
        Args:
            gmail_account: Gmail account to use with gog CLI
            nextcloud_config: Dict with Nextcloud configuration (url, username, password, base_path)
        """
        self.gmail_account = gmail_account or DEFAULT_GMAIL_ACCOUNT
        self.nextcloud_config = nextcloud_config or {}
        
        # Initialize Nextcloud client
        self.nc_client = NextcloudClient(**self.nextcloud_config)
        
        # Create temp directory
        self.temp_dir = Path(TEMP_DIR)
        self.temp_dir.mkdir(exist_ok=True)
        
        # Tracking CSV path
        self.tracking_csv = self.temp_dir / 'processed_attachments.csv'
        self._init_tracking_csv()
    
    def _init_tracking_csv(self):
        """Initialize tracking CSV if it doesn't exist."""
        if not self.tracking_csv.exists():
            with open(self.tracking_csv, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'date_processed', 'email_id', 'message_id', 'sender',
                    'subject', 'attachment_name', 'category', 'vendor',
                    'remote_path', 'share_url', 'notes'
                ])
    
    def _run_gog_command(self, args):
        """Run gog command and return JSON output."""
        cmd = ['gog'] + args + ['--account', self.gmail_account, '--json']
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                logger.error(f"gog command failed: {result.stderr}")
                return None
        except subprocess.TimeoutExpired:
            logger.error("gog command timed out")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse gog output: {e}")
            return None
    
    def search_emails(self, query="has:attachment filename:pdf", max_results=10):
        """
        Search emails using gog.
        
        Args:
            query: Gmail search query
            max_results: Maximum number of emails to return
            
        Returns:
            list: List of email threads
        """
        logger.info(f"Searching emails with query: {query}")
        
        args = ['gmail', 'search', query, '--max', str(max_results)]
        result = self._run_gog_command(args)
        
        if result and 'threads' in result:
            threads = result['threads']
            logger.info(f"Found {len(threads)} email threads")
            return threads
        else:
            logger.warning("No emails found or search failed")
            return []
    
    def get_message_details(self, thread_id):
        """
        Get detailed message information including attachments.
        
        Args:
            thread_id: Gmail thread ID
            
        Returns:
            dict: Message details with attachments
        """
        args = ['gmail', 'messages', 'get', '--thread', thread_id]
        result = self._run_gog_command(args)
        
        if result and 'messages' in result:
            # Get the first message in thread (most recent)
            messages = result['messages']
            if messages:
                return messages[0]
        
        return None
    
    def download_attachment(self, message_id, attachment_id, filename=None):
        """
        Download email attachment using gog.
        
        Args:
            message_id: Gmail message ID
            attachment_id: Attachment ID
            filename: Optional filename to save as
            
        Returns:
            Path: Path to downloaded file, or None if failed
        """
        # Create temp file if filename not provided
        if not filename:
            filename = f"attachment_{message_id}_{attachment_id}.pdf"
        
        output_path = self.temp_dir / filename
        
        # Use gog attachment command (note: gog may not have direct attachment download)
        # Fallback: use gog message get with --include-attachments
        logger.warning("Direct attachment download not yet implemented in gog CLI")
        logger.info(f"Would download attachment {attachment_id} from message {message_id}")
        
        # Placeholder: create empty file for testing
        with open(output_path, 'w') as f:
            f.write(f"Placeholder for attachment {attachment_id}\n")
        
        return output_path if output_path.exists() else None
    
    def categorize_email(self, sender, subject):
        """
        Categorize email based on sender and subject.
        
        Args:
            sender: Email sender
            subject: Email subject
            
        Returns:
            tuple: (category, vendor, folder_path)
        """
        sender_lower = sender.lower()
        subject_lower = subject.lower()
        
        # Determine vendor
        vendor = 'unknown'
        for vendor_name in VENDOR_FOLDERS:
            if vendor_name in sender_lower:
                vendor = vendor_name
                break
        
        # Determine category
        category = 'other'
        folder = '/Documents/Other'
        
        for cat_name, patterns in CATEGORY_PATTERNS.items():
            # Check sender patterns
            sender_match = any(pattern in sender_lower for pattern in patterns['senders'])
            
            # Check subject patterns
            subject_match = any(pattern in subject_lower for pattern in patterns['subjects'])
            
            if sender_match or subject_match:
                category = cat_name
                folder = patterns['folder']
                
                # Add vendor subfolder if applicable
                if vendor in VENDOR_FOLDERS and 'Accounting' in folder:
                    folder = f"{folder}/{VENDOR_FOLDERS[vendor]}"
                
                break
        
        return category, vendor, folder
    
    def generate_filename(self, sender, subject, attachment_name, category, vendor):
        """
        Generate standardized filename for attachment.
        
        Format: YYYY-MM-DD_Vendor_Category_OriginalName.pdf
        """
        date_str = datetime.now().strftime('%Y-%m-%d')
        
        # Clean vendor name for filename
        vendor_clean = re.sub(r'[^a-zA-Z0-9]', '_', vendor)
        category_clean = re.sub(r'[^a-zA-Z0-9]', '_', category)
        
        # Keep original extension
        if attachment_name:
            name, ext = os.path.splitext(attachment_name)
            if not ext:
                ext = '.pdf'
        else:
            name = 'attachment'
            ext = '.pdf'
        
        # Clean original name
        name_clean = re.sub(r'[^a-zA-Z0-9._-]', '_', name)[:50]
        
        filename = f"{date_str}_{vendor_clean}_{category_clean}_{name_clean}{ext}"
        return filename
    
    def process_email_thread(self, thread):
        """
        Process a single email thread with attachments.
        
        Args:
            thread: Email thread from gog search
            
        Returns:
            list: List of processed attachment records
        """
        thread_id = thread['id']
        logger.info(f"Processing thread: {thread_id}")
        
        # Get message details
        message = self.get_message_details(thread_id)
        if not message:
            logger.warning(f"No message details for thread {thread_id}")
            return []
        
        # Extract email metadata
        sender = message.get('from', '')
        subject = message.get('subject', '')
        date = message.get('date', '')
        
        logger.info(f"Email: {subject} from {sender}")
        
        # Check for attachments (simplified - gog may not expose attachment info)
        # For now, assume at least one PDF attachment
        attachments = message.get('attachments', [])
        if not attachments:
            logger.info("No attachments found in message")
            return []
        
        processed_attachments = []
        
        # Process each attachment
        for i, attachment in enumerate(attachments):
            attachment_id = attachment.get('id')
            attachment_name = attachment.get('filename', f'attachment_{i}.pdf')
            
            logger.info(f"Processing attachment: {attachment_name}")
            
            # Categorize email
            category, vendor, folder = self.categorize_email(sender, subject)
            
            # Generate filename
            new_filename = self.generate_filename(
                sender, subject, attachment_name, category, vendor
            )
            
            # Download attachment
            local_path = self.download_attachment(
                thread_id, attachment_id, new_filename
            )
            
            if not local_path:
                logger.error(f"Failed to download attachment: {attachment_name}")
                continue
            
            # Upload to Nextcloud
            remote_path = f"{folder}/{new_filename}"
            
            # Ensure directory exists
            self.nc_client.create_directory(folder)
            
            # Upload file
            success = self.nc_client.upload_file(str(local_path), remote_path)
            
            if success:
                # Create share link
                share_url = self.nc_client.create_share_link(remote_path)
                
                # Add to tracking CSV
                record = {
                    'date_processed': datetime.now().isoformat(),
                    'email_id': thread_id,
                    'message_id': thread_id,  # Same as thread for now
                    'sender': sender,
                    'subject': subject,
                    'attachment_name': attachment_name,
                    'category': category,
                    'vendor': vendor,
                    'remote_path': remote_path,
                    'share_url': share_url or '',
                    'notes': ''
                }
                
                self._add_to_tracking_csv(record)
                processed_attachments.append(record)
                
                logger.info(f"Successfully processed: {attachment_name} -> {remote_path}")
                
                # Clean up local file
                local_path.unlink()
            else:
                logger.error(f"Failed to upload: {attachment_name}")
        
        return processed_attachments
    
    def _add_to_tracking_csv(self, record):
        """Add processed record to tracking CSV."""
        with open(self.tracking_csv, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                record['date_processed'],
                record['email_id'],
                record['message_id'],
                record['sender'],
                record['subject'],
                record['attachment_name'],
                record['category'],
                record['vendor'],
                record['remote_path'],
                record['share_url'],
                record['notes']
            ])
    
    def process_recent_emails(self, days=7, max_emails=20):
        """
        Process recent emails with attachments.
        
        Args:
            days: Look back this many days
            max_emails: Maximum number of emails to process
            
        Returns:
            list: All processed attachment records
        """
        query = f"has:attachment filename:pdf newer_than:{days}d"
        
        threads = self.search_emails(query, max_emails)
        all_processed = []
        
        for thread in threads:
            processed = self.process_email_thread(thread)
            all_processed.extend(processed)
        
        logger.info(f"Total processed: {len(all_processed)} attachments")
        return all_processed
    
    def get_tracking_summary(self):
        """Get summary of processed attachments."""
        if not self.tracking_csv.exists():
            return {"total": 0, "by_category": {}, "by_vendor": {}}
        
        with open(self.tracking_csv, 'r') as f:
            reader = csv.DictReader(f)
            records = list(reader)
        
        summary = {
            'total': len(records),
            'by_category': {},
            'by_vendor': {}
        }
        
        for record in records:
            category = record['category']
            vendor = record['vendor']
            
            summary['by_category'][category] = summary['by_category'].get(category, 0) + 1
            summary['by_vendor'][vendor] = summary['by_vendor'].get(vendor, 0) + 1
        
        return summary


def main():
    """Command-line interface."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Process email attachments and upload to Nextcloud'
    )
    parser.add_argument('--account', help='Gmail account', default=DEFAULT_GMAIL_ACCOUNT)
    parser.add_argument('--days', type=int, default=7, help='Process emails from last N days')
    parser.add_argument('--max', type=int, default=10, help='Maximum emails to process')
    parser.add_argument('--query', help='Custom Gmail search query')
    parser.add_argument('--dry-run', action='store_true', help='Dry run (no upload)')
    
    args = parser.parse_args()
    
    # Initialize processor
    processor = EmailAttachmentProcessor(gmail_account=args.account)
    
    # Use custom query or default
    query = args.query or f"has:attachment filename:pdf newer_than:{args.days}d"
    
    if args.dry_run:
        logger.info("DRY RUN - No files will be uploaded")
        
        # Just search and display
        threads = processor.search_emails(query, args.max)
        for thread in threads:
            print(f"Thread: {thread['id']}")
            print(f"  Subject: {thread.get('subject', 'No subject')}")
            print(f"  From: {thread.get('from', 'Unknown')}")
            print(f"  Date: {thread.get('date', 'Unknown')}")
            print()
        
        print(f"Found {len(threads)} emails with attachments")
        return
    
    # Process emails
    processed = processor.process_recent_emails(days=args.days, max_emails=args.max)
    
    # Print summary
    summary = processor.get_tracking_summary()
    print(f"\nProcessing complete!")
    print(f"Total attachments processed: {summary['total']}")
    
    if summary['by_category']:
        print("\nBy category:")
        for category, count in summary['by_category'].items():
            print(f"  {category}: {count}")
    
    if summary['by_vendor']:
        print("\nBy vendor:")
        for vendor, count in summary['by_vendor'].items():
            print(f"  {vendor}: {count}")
    
    # Show tracking CSV location
    print(f"\nTracking CSV: {processor.tracking_csv}")


if __name__ == '__main__':
    main()