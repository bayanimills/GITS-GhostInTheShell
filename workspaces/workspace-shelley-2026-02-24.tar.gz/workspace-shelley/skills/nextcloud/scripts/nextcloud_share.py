#!/usr/bin/env python3
"""
Nextcloud Share Tool - Create public share links for files.

Usage:
    python nextcloud_share.py --remote "/Business/Invoices/invoice.pdf"
    python nextcloud_share.py --list
    python nextcloud_share.py --delete <share_id>
"""

import os
import sys
import argparse
from nextcloud_client import NextcloudClient

def main():
    parser = argparse.ArgumentParser(description='Nextcloud Share Tool')
    parser.add_argument('--url', help='Nextcloud URL')
    parser.add_argument('--username', help='Username')
    parser.add_argument('--password', help='Password')
    parser.add_argument('--base-path', help='Base path')
    
    subparsers = parser.add_subparsers(dest='action', help='Action')
    
    # Create share
    create_parser = subparsers.add_parser('create', help='Create share link')
    create_parser.add_argument('--remote', required=True, help='Remote file path')
    create_parser.add_argument('--type', type=int, default=3, help='Share type (3=public link)')
    create_parser.add_argument('--perms', type=int, default=1, help='Permissions (1=read)')
    
    # List shares
    list_parser = subparsers.add_parser('list', help='List all shares')
    
    # Delete share
    delete_parser = subparsers.add_parser('delete', help='Delete share')
    delete_parser.add_argument('share_id', help='Share ID to delete')
    
    args = parser.parse_args()
    
    # Build client config
    config = {}
    if args.url: config['url'] = args.url
    if args.username: config['username'] = args.username
    if args.password: config['password'] = args.password
    if args.base_path: config['base_path'] = args.base_path
    
    client = NextcloudClient(**config)
    
    if args.action == 'create':
        share_url = client.create_share_link(args.remote, args.type, args.perms)
        if share_url:
            print(f"Share URL: {share_url}")
        else:
            print("Failed to create share", file=sys.stderr)
            sys.exit(1)
    
    elif args.action == 'list':
        shares = client.list_shares()
        if not shares:
            print("No shares found")
        else:
            print(f"Found {len(shares)} shares:")
            for share in shares:
                share_type = {
                    0: 'user',
                    1: 'group',
                    3: 'public link',
                    4: 'email',
                    6: 'federated'
                }.get(share.get('share_type', 3), 'unknown')
                
                print(f"\nID: {share.get('id')}")
                print(f"  Path: {share.get('path')}")
                print(f"  Type: {share_type}")
                print(f"  URL: {share.get('url', 'N/A')}")
                print(f"  Token: {share.get('token', 'N/A')}")
    
    elif args.action == 'delete':
        success = client.delete_share(args.share_id)
        if success:
            print(f"Share {args.share_id} deleted")
        else:
            print(f"Failed to delete share {args.share_id}", file=sys.stderr)
            sys.exit(1)
    
    else:
        parser.print_help()

if __name__ == '__main__':
    main()