#!/usr/bin/env python3
"""
Nextcloud Client Library for OpenClaw Skills

Provides WebDAV and OCS API operations for Nextcloud file management.
Handles authentication, file upload/download, sharing, and directory operations.

Environment variables:
- NEXTCLOUD_URL: Nextcloud server URL (default: https://nextcloud.blkstr.io)
- NEXTCLOUD_USERNAME: Username (default: jarvis)
- NEXTCLOUD_PASSWORD: Password (default: agent12345jarvis)
- NEXTCLOUD_BASE_PATH: Base path for operations (default: /_private/businesses/Bayani Enterprises/SBA - ShopBitcoin)
"""

import os
import sys
import json
import logging
from urllib.parse import quote, urljoin
import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

# Default configuration
DEFAULT_CONFIG = {
    'url': os.environ.get('NEXTCLOUD_URL', 'https://nextcloud.blkstr.io'),
    'username': os.environ.get('NEXTCLOUD_USERNAME', 'jarvis'),
    'password': os.environ.get('NEXTCLOUD_PASSWORD', 'agent12345jarvis'),
    'base_path': os.environ.get('NEXTCLOUD_BASE_PATH', '/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin'),
}

class NextcloudClient:
    """Client for Nextcloud WebDAV and OCS API operations."""
    
    def __init__(self, url=None, username=None, password=None, base_path=None):
        """Initialize Nextcloud client with credentials."""
        self.url = url or DEFAULT_CONFIG['url']
        self.username = username or DEFAULT_CONFIG['username']
        self.password = password or DEFAULT_CONFIG['password']
        self.base_path = base_path or DEFAULT_CONFIG['base_path']
        self.auth = HTTPBasicAuth(self.username, self.password)
        
        # WebDAV base URL
        self.webdav_base = f"{self.url}/remote.php/dav/files/{self.username}"
        
        # OCS API base URL
        self.ocs_base = f"{self.url}/ocs/v2.php/apps/files_sharing/api/v1"
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
    
    def _make_webdav_url(self, remote_path):
        """Create WebDAV URL for a remote path."""
        # Handle empty path (root)
        if not remote_path or remote_path == '/':
            return f"{self.webdav_base}/"
        
        # Remove leading slash if present
        if remote_path.startswith('/'):
            remote_path = remote_path[1:]
        
        # URL encode path segments (don't encode '/')
        encoded_path = quote(remote_path)
        return f"{self.webdav_base}/{encoded_path}"
    
    def _resolve_remote_path(self, remote_path):
        """
        Resolve remote path relative to base_path.
        
        Args:
            remote_path: Path (absolute or relative)
            
        Returns:
            str: Absolute path from user root
        """
        if remote_path.startswith('/'):
            # Absolute path
            return remote_path
        else:
            # Relative to base_path
            # Ensure base_path ends with /
            base = self.base_path.rstrip('/') + '/'
            return base + remote_path
    
    def upload_file(self, local_path, remote_path):
        """
        Upload a file to Nextcloud via WebDAV PUT.
        
        Args:
            local_path: Path to local file
            remote_path: Destination path in Nextcloud (relative to base_path or absolute)
            
        Returns:
            str: Full Nextcloud path if successful, None otherwise
        """
        try:
            # Resolve remote path
            resolved_path = self._resolve_remote_path(remote_path)
            
            # Read local file
            with open(local_path, 'rb') as f:
                file_data = f.read()
            
            # Create WebDAV URL
            webdav_url = self._make_webdav_url(resolved_path)
            
            # PUT request
            headers = {'Content-Type': 'application/octet-stream'}
            response = requests.put(
                webdav_url,
                auth=self.auth,
                headers=headers,
                data=file_data,
                timeout=30
            )
            
            if response.status_code in [200, 201, 204]:
                self.logger.info(f"Upload successful: {resolved_path}")
                return resolved_path
            else:
                self.logger.error(f"Upload failed: {response.status_code} - {response.text[:200]}")
                return None
                
        except Exception as e:
            self.logger.error(f"Upload error: {e}")
            return None
    
    def download_file(self, remote_path, local_path):
        """
        Download a file from Nextcloud via WebDAV GET.
        
        Args:
            remote_path: Source path in Nextcloud
            local_path: Destination local path
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Resolve remote path
            resolved_path = self._resolve_remote_path(remote_path)
            
            webdav_url = self._make_webdav_url(resolved_path)
            response = requests.get(webdav_url, auth=self.auth, timeout=30)
            
            if response.status_code == 200:
                with open(local_path, 'wb') as f:
                    f.write(response.content)
                self.logger.info(f"Download successful: {resolved_path} -> {local_path}")
                return True
            else:
                self.logger.error(f"Download failed: {response.status_code} - {response.text[:200]}")
                return False
                
        except Exception as e:
            self.logger.error(f"Download error: {e}")
            return False
    
    def list_directory(self, remote_path):
        """
        List contents of a directory via WebDAV PROPFIND.
        
        Args:
            remote_path: Directory path in Nextcloud
            
        Returns:
            list: List of dicts with name, path, is_dir, size
        """
        try:
            # Resolve remote path
            resolved_path = self._resolve_remote_path(remote_path)
            
            webdav_url = self._make_webdav_url(resolved_path)
            
            # PROPFIND request
            headers = {
                'Depth': '1',
                'Content-Type': 'text/xml'
            }
            body = '''<?xml version="1.0"?>
<d:propfind xmlns:d="DAV:">
  <d:prop>
    <d:displayname/>
    <d:resourcetype/>
    <d:getcontentlength/>
  </d:prop>
</d:propfind>'''
            
            response = requests.request(
                'PROPFIND',
                webdav_url,
                auth=self.auth,
                headers=headers,
                data=body,
                timeout=30
            )
            
            if response.status_code == 207:
                return self._parse_propfind_response(response.content, resolved_path)
            else:
                self.logger.error(f"PROPFIND failed: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"List directory error: {e}")
            return []
    
    def _parse_propfind_response(self, xml_content, base_path):
        """Parse WebDAV PROPFIND response XML."""
        items = []
        namespaces = {'d': 'DAV:'}
        
        try:
            root = ET.fromstring(xml_content)
            
            for response_elem in root.findall('.//d:response', namespaces):
                href_elem = response_elem.find('.//d:href', namespaces)
                if href_elem is None:
                    continue
                
                href = href_elem.text
                # Skip the base directory itself
                if href.endswith(base_path) or href == f"/remote.php/dav/files/{self.username}{base_path}":
                    continue
                
                # Extract name from href
                name = href.rstrip('/').split('/')[-1]
                
                # Check if it's a directory
                resourcetype_elem = response_elem.find('.//d:propstat/d:prop/d:resourcetype/d:collection', namespaces)
                is_dir = resourcetype_elem is not None
                
                # Get file size
                size_elem = response_elem.find('.//d:propstat/d:prop/d:getcontentlength', namespaces)
                size = int(size_elem.text) if size_elem is not None and size_elem.text else 0
                
                items.append({
                    'name': name,
                    'path': href.replace(f"/remote.php/dav/files/{self.username}", ""),
                    'is_dir': is_dir,
                    'size': size
                })
                
        except Exception as e:
            self.logger.error(f"Parse XML error: {e}")
        
        return items
    
    def create_directory(self, remote_path):
        """
        Create a directory via WebDAV MKCOL.
        
        Args:
            remote_path: Directory path to create
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Resolve remote path
            resolved_path = self._resolve_remote_path(remote_path)
            
            webdav_url = self._make_webdav_url(resolved_path)
            response = requests.request('MKCOL', webdav_url, auth=self.auth, timeout=30)
            
            if response.status_code in [200, 201, 204]:
                self.logger.info(f"Directory created: {resolved_path}")
                return True
            else:
                self.logger.error(f"MKCOL failed: {response.status_code} - {response.text[:200]}")
                return False
                
        except Exception as e:
            self.logger.error(f"Create directory error: {e}")
            return False
    
    def create_share_link(self, remote_path, share_type=3, permissions=1):
        """
        Create a public share link for a file.
        
        Args:
            remote_path: Path to file in Nextcloud
            share_type: 3 = public link, 0 = user, 1 = group, 4 = email
            permissions: 1 = read, 15 = all
            
        Returns:
            str: Share URL if successful, None otherwise
        """
        try:
            share_url = f"{self.ocs_base}/shares"
            
            headers = {
                'OCS-APIRequest': 'true',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            data = {
                'path': remote_path,
                'shareType': share_type,
                'permissions': permissions
            }
            
            response = requests.post(
                share_url,
                auth=self.auth,
                headers=headers,
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                share_data = result['ocs']['data']
                self.logger.info(f"Share created: {share_data.get('url', 'No URL returned')}")
                return share_data.get('url')
            else:
                self.logger.error(f"Share API failed: {response.status_code} - {response.text[:200]}")
                return None
                
        except Exception as e:
            self.logger.error(f"Create share error: {e}")
            return None
    
    def list_shares(self):
        """
        List all shares for the user.
        
        Returns:
            list: List of share objects
        """
        try:
            shares_url = f"{self.ocs_base}/shares"
            headers = {'OCS-APIRequest': 'true', 'Accept': 'application/json'}
            
            response = requests.get(shares_url, auth=self.auth, headers=headers, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                return result['ocs']['data']
            else:
                self.logger.error(f"List shares failed: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"List shares error: {e}")
            return []
    
    def delete_share(self, share_id):
        """
        Delete a share by ID.
        
        Args:
            share_id: ID of share to delete
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            delete_url = f"{self.ocs_base}/shares/{share_id}"
            headers = {'OCS-APIRequest': 'true'}
            
            response = requests.delete(delete_url, auth=self.auth, headers=headers, timeout=30)
            
            if response.status_code == 200:
                self.logger.info(f"Share deleted: {share_id}")
                return True
            else:
                self.logger.error(f"Delete share failed: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Delete share error: {e}")
            return False
    
    def file_exists(self, remote_path):
        """
        Check if a file or directory exists.
        
        Args:
            remote_path: Path to check
            
        Returns:
            bool: True if exists, False otherwise
        """
        try:
            # Resolve remote path
            resolved_path = self._resolve_remote_path(remote_path)
            
            webdav_url = self._make_webdav_url(resolved_path)
            response = requests.head(webdav_url, auth=self.auth, timeout=10)
            
            return response.status_code == 200
        except:
            return False


# Convenience functions for common operations
def upload_file(local_path, remote_path, **kwargs):
    """Convenience function for uploading a file."""
    client = NextcloudClient(**kwargs)
    return client.upload_file(local_path, remote_path)

def download_file(remote_path, local_path, **kwargs):
    """Convenience function for downloading a file."""
    client = NextcloudClient(**kwargs)
    return client.download_file(remote_path, local_path)

def create_share_link(remote_path, **kwargs):
    """Convenience function for creating a share link."""
    client = NextcloudClient(**kwargs)
    return client.create_share_link(remote_path)

def list_directory(remote_path, **kwargs):
    """Convenience function for listing directory contents."""
    client = NextcloudClient(**kwargs)
    return client.list_directory(remote_path)


if __name__ == '__main__':
    # Simple CLI for testing
    import argparse
    
    parser = argparse.ArgumentParser(description='Nextcloud Client CLI')
    parser.add_argument('--url', help='Nextcloud URL')
    parser.add_argument('--username', help='Username')
    parser.add_argument('--password', help='Password')
    parser.add_argument('--base-path', help='Base path')
    
    subparsers = parser.add_subparsers(dest='command', help='Command')
    
    # Upload command
    upload_parser = subparsers.add_parser('upload', help='Upload file')
    upload_parser.add_argument('local', help='Local file path')
    upload_parser.add_argument('remote', help='Remote file path')
    
    # Download command
    download_parser = subparsers.add_parser('download', help='Download file')
    download_parser.add_argument('remote', help='Remote file path')
    download_parser.add_argument('local', help='Local file path')
    
    # Share command
    share_parser = subparsers.add_parser('share', help='Create share link')
    share_parser.add_argument('remote', help='Remote file path')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List directory')
    list_parser.add_argument('remote', help='Remote directory path')
    
    args = parser.parse_args()
    
    # Create client
    client_kwargs = {}
    if args.url: client_kwargs['url'] = args.url
    if args.username: client_kwargs['username'] = args.username
    if args.password: client_kwargs['password'] = args.password
    if args.base_path: client_kwargs['base_path'] = args.base_path
    
    client = NextcloudClient(**client_kwargs)
    
    # Execute command
    if args.command == 'upload':
        result = client.upload_file(args.local, args.remote)
        print(f"Upload {'successful' if result else 'failed'}")
        
    elif args.command == 'download':
        result = client.download_file(args.remote, args.local)
        print(f"Download {'successful' if result else 'failed'}")
        
    elif args.command == 'share':
        share_url = client.create_share_link(args.remote)
        if share_url:
            print(f"Share URL: {share_url}")
        else:
            print("Failed to create share")
            
    elif args.command == 'list':
        items = client.list_directory(args.remote)
        for item in items:
            type_icon = '📁' if item['is_dir'] else '📄'
            size_str = f" ({item['size']} bytes)" if not item['is_dir'] else ''
            print(f"{type_icon} {item['name']}{size_str}")
            
    else:
        parser.print_help()