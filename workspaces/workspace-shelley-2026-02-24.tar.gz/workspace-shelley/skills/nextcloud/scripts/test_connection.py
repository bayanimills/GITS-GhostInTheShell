#!/usr/bin/env python3
"""Test Nextcloud connection and basic operations."""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nextcloud_client import NextcloudClient

def test_connection():
    """Test basic Nextcloud connectivity."""
    print("Testing Nextcloud connection...")
    
    try:
        # Initialize client with default credentials
        client = NextcloudClient()
        
        # Test 1: Check if root directory exists
        print("1. Checking root directory access...")
        root_exists = client.file_exists('/')
        print(f"   Root access: {'✓' if root_exists else '✗'}")
        
        # Test 2: List a directory (use base path)
        print("2. Listing base directory...")
        items = client.list_directory(client.base_path)
        if items is not None:
            print(f"   Found {len(items)} items in {client.base_path}")
            for item in items[:3]:  # Show first 3
                type_icon = '📁' if item['is_dir'] else '📄'
                print(f"     {type_icon} {item['name']}")
            if len(items) > 3:
                print(f"     ... and {len(items) - 3} more")
        else:
            print("   ✗ Failed to list directory")
        
        # Test 3: Create a test directory (in temp area)
        print("3. Testing directory creation...")
        test_dir = f"{client.base_path}/_test_connection"
        created = client.create_directory(test_dir)
        print(f"   Test directory creation: {'✓' if created else '✗'}")
        
        # Test 4: Clean up test directory
        if created:
            # We could delete it, but leave it for now
            print(f"   Test directory created at: {test_dir}")
            print("   Note: Test directory not deleted for verification")
        
        print("\nConnection test completed!")
        return True
        
    except Exception as e:
        print(f"✗ Connection test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = test_connection()
    sys.exit(0 if success else 1)