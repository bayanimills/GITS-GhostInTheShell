#!/usr/bin/env python3
"""
Nextcloud Folder Synchronization

Sync local folder with Nextcloud directory:
- Uploads new/changed files from local to remote
- Downloads missing files from remote to local
- Maintains folder structure and permissions

Usage:
    python folder_sync.py --local ./documents --remote "/Business/Documents"
    python folder_sync.py --local ./documents --remote "/Business/Documents" --dry-run
"""

import os
import sys
import hashlib
import argparse
from pathlib import Path
from datetime import datetime
from nextcloud_client import NextcloudClient

def calculate_file_hash(file_path):
    """Calculate MD5 hash of file."""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

class FolderSync:
    """Synchronize local folder with Nextcloud directory."""
    
    def __init__(self, local_path, remote_path, client):
        self.local_path = Path(local_path)
        self.remote_path = remote_path
        self.client = client
        
        # Ensure local path exists
        self.local_path.mkdir(parents=True, exist_ok=True)
        
        # State tracking
        self.stats = {
            'uploaded': 0,
            'downloaded': 0,
            'skipped': 0,
            'errors': 0
        }
    
    def sync(self, dry_run=False):
        """Perform bidirectional sync."""
        print(f"Syncing {self.local_path} ↔ {self.remote_path}")
        if dry_run:
            print("DRY RUN - No changes will be made")
        
        # Get local files
        local_files = self._get_local_files()
        
        # Get remote files
        remote_files = self._get_remote_files()
        
        # Upload new/changed local files
        self._upload_new_files(local_files, remote_files, dry_run)
        
        # Download missing remote files
        self._download_missing_files(local_files, remote_files, dry_run)
        
        # Print stats
        self._print_stats(dry_run)
    
    def _get_local_files(self):
        """Scan local directory recursively."""
        local_files = {}
        
        for file_path in self.local_path.rglob('*'):
            if file_path.is_file():
                # Calculate relative path
                rel_path = file_path.relative_to(self.local_path)
                
                # Get file info
                stat = file_path.stat()
                file_hash = calculate_file_hash(file_path)
                
                local_files[str(rel_path)] = {
                    'path': file_path,
                    'size': stat.st_size,
                    'mtime': stat.st_mtime,
                    'hash': file_hash
                }
        
        print(f"Found {len(local_files)} local files")
        return local_files
    
    def _get_remote_files(self):
        """List remote directory recursively."""
        remote_files = {}
        
        def scan_remote_directory(current_remote_path, current_local_prefix=''):
            items = self.client.list_directory(current_remote_path)
            
            for item in items:
                item_name = item['name']
                item_path = f"{current_remote_path}/{item_name}" if current_remote_path != '/' else f"/{item_name}"
                local_rel_path = f"{current_local_prefix}/{item_name}" if current_local_prefix else item_name
                
                if item['is_dir']:
                    # Recursively scan subdirectory
                    scan_remote_directory(item_path, local_rel_path)
                else:
                    remote_files[local_rel_path] = {
                        'remote_path': item_path,
                        'size': item['size'],
                        # Note: Nextcloud doesn't expose file hash via WebDAV
                        # We'll use size + mtime for change detection
                    }
        
        scan_remote_directory(self.remote_path)
        print(f"Found {len(remote_files)} remote files")
        return remote_files
    
    def _upload_new_files(self, local_files, remote_files, dry_run):
        """Upload files that are new or changed."""
        for rel_path, local_info in local_files.items():
            remote_info = remote_files.get(rel_path)
            
            if not remote_info:
                # File doesn't exist remotely - upload
                remote_path = f"{self.remote_path}/{rel_path}"
                print(f"  + Upload new: {rel_path}")
                
                if not dry_run:
                    # Ensure parent directory exists
                    self._ensure_remote_parent_dir(remote_path)
                    
                    # Upload file
                    success = self.client.upload_file(
                        str(local_info['path']),
                        remote_path
                    )
                    
                    if success:
                        self.stats['uploaded'] += 1
                    else:
                        self.stats['errors'] += 1
                else:
                    self.stats['uploaded'] += 1
                    
            else:
                # File exists - check if changed (simplified: compare sizes)
                if local_info['size'] != remote_info['size']:
                    print(f"  ↑ Update changed: {rel_path} (size diff)")
                    
                    if not dry_run:
                        success = self.client.upload_file(
                            str(local_info['path']),
                            remote_info['remote_path']
                        )
                        
                        if success:
                            self.stats['uploaded'] += 1
                        else:
                            self.stats['errors'] += 1
                    else:
                        self.stats['uploaded'] += 1
                else:
                    self.stats['skipped'] += 1
    
    def _download_missing_files(self, local_files, remote_files, dry_run):
        """Download files that are missing locally."""
        for rel_path, remote_info in remote_files.items():
            local_info = local_files.get(rel_path)
            
            if not local_info:
                # File doesn't exist locally - download
                local_file_path = self.local_path / rel_path
                print(f"  - Download missing: {rel_path}")
                
                if not dry_run:
                    # Ensure parent directory exists locally
                    local_file_path.parent.mkdir(parents=True, exist_ok=True)
                    
                    # Download file
                    success = self.client.download_file(
                        remote_info['remote_path'],
                        str(local_file_path)
                    )
                    
                    if success:
                        self.stats['downloaded'] += 1
                    else:
                        self.stats['errors'] += 1
                else:
                    self.stats['downloaded'] += 1
            else:
                # File exists locally - already handled in upload phase
                pass
    
    def _ensure_remote_parent_dir(self, remote_path):
        """Ensure parent directory exists in Nextcloud."""
        # Extract directory path
        dir_path = os.path.dirname(remote_path)
        
        if dir_path and dir_path != '/':
            # Check if directory exists
            if not self.client.file_exists(dir_path):
                # Create directory
                self.client.create_directory(dir_path)
    
    def _print_stats(self, dry_run):
        """Print synchronization statistics."""
        print("\n" + "="*50)
        if dry_run:
            print("DRY RUN RESULTS - No changes were made")
        print("Synchronization complete!")
        print(f"  Uploaded: {self.stats['uploaded']} files")
        print(f"  Downloaded: {self.stats['downloaded']} files")
        print(f"  Skipped (unchanged): {self.stats['skipped']} files")
        print(f"  Errors: {self.stats['errors']} files")
        print("="*50)

def main():
    parser = argparse.ArgumentParser(description='Sync local folder with Nextcloud')
    parser.add_argument('--local', required=True, help='Local folder path')
    parser.add_argument('--remote', required=True, help='Remote folder path in Nextcloud')
    parser.add_argument('--url', help='Nextcloud URL')
    parser.add_argument('--username', help='Username')
    parser.add_argument('--password', help='Password')
    parser.add_argument('--base-path', help='Base path')
    parser.add_argument('--dry-run', action='store_true', help='Dry run (no changes)')
    
    args = parser.parse_args()
    
    # Build client config
    config = {}
    if args.url: config['url'] = args.url
    if args.username: config['username'] = args.username
    if args.password: config['password'] = args.password
    if args.base_path: config['base_path'] = args.base_path
    
    # Initialize client and sync
    client = NextcloudClient(**config)
    sync = FolderSync(args.local, args.remote, client)
    sync.sync(dry_run=args.dry_run)

if __name__ == '__main__':
    main()