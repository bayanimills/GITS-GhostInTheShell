---
name: nextcloud
description: Nextcloud file management and sharing operations for business workflows. Use when: (1) Uploading/downloading files to/from Nextcloud storage, (2) Creating public share links for files, (3) Managing receipt/invoice workflows with PDF attachments from emails, (4) Organizing business documents in folder structures, (5) Integrating with email systems for attachment processing. Combines WebDAV file operations, OCS sharing API, and email attachment workflows.
---

# Nextcloud

## Overview

Nextcloud skill provides comprehensive file management capabilities for business operations, with a focus on receipt/invoice workflows, document organization, and integration with email systems. It enables secure file storage, public sharing, and automated processing of business documents.

## Quick Start

### Authentication Setup

Nextcloud credentials are stored in environment variables or configuration files:
- **URL**: `https://nextcloud.blkstr.io`
- **Username**: `jarvis` (team account)
- **Password**: `agent12345jarvis`

```python
import os
from nextcloud_client import NextcloudClient

client = NextcloudClient(
    url="https://nextcloud.blkstr.io",
    username="jarvis",
    password="agent12345jarvis"
)
```

### Core Operations

1. **Upload file**: `nextcloud_upload.py --local /path/to/file.pdf --remote "/Business/Invoices/"`
2. **Download file**: `nextcloud_download.py --remote "/Business/Invoices/invoice.pdf" --local ./`
3. **Create share link**: `nextcloud_share.py --remote "/Business/Invoices/invoice.pdf"`
4. **List directory**: `nextcloud_list.py --remote "/Business/"`

## Core Capabilities

### 1. File Operations (WebDAV)

**WebDAV URLs:**
- Base: `https://nextcloud.blkstr.io/remote.php/dav/files/jarvis`
- File path: Append the remote path (URL-encoded)

**Common operations:**
- `PUT` to upload
- `GET` to download  
- `PROPFIND` to list directory
- `DELETE` to remove
- `MKCOL` to create directory

**Use when:** Direct file transfer is needed without sharing links.

### 2. Sharing Operations (OCS API)

**Sharing API:**
- Endpoint: `https://nextcloud.blkstr.io/ocs/v2.php/apps/files_sharing/api/v1/shares`
- Header: `OCS-APIRequest: true`
- Share types: `3` = public link, `0` = user share, `1` = group share
- Permissions: `1` = read, `15` = all (read+write+share+delete)

**Use when:** Creating public links for sharing files externally.

### 3. Email Attachment Workflows

**Integration with gog CLI:**
1. Search for emails with PDF attachments
2. Download attachments using `gog gmail attachment`
3. Upload to Nextcloud with organized folder structure
4. Create share links for reference
5. Archive/label emails as processed

**Use when:** Processing receipt/invoice emails automatically.

### 4. Receipt/Invoice Management

**Recommended folder structure:**
```
/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/
├── Accounting/
│   ├── Invoices/
│   │   ├── Voltage/
│   │   ├── Shopify/
│   │   └── Service Providers/
│   └── Receipts/
│       ├── Bankful/
│       ├── Expenses/
│       └── Tax/
└── Documents/
    ├── Contracts/
    └── Legal/
```

**Use when:** Organizing financial documents for accounting and tax purposes.

### 5. Integration with Other Skills

**nano-pdf skill:** For PDF editing, text extraction, form filling
**gog skill:** For email search and attachment download
**SBA Email Manager skill:** For email categorization and workflow integration

## Workflows

### Workflow 1: Process Email Attachments

```
1. Search for emails with PDF attachments: `gog gmail search "has:attachment filename:pdf"`
2. For each email:
   a. Get message details and attachment IDs
   b. Download each attachment: `gog gmail attachment <messageId> <attachmentId>`
   c. Determine category (invoice, receipt, statement)
   d. Upload to Nextcloud in appropriate folder
   e. Create share link for reference
   f. Label email as processed (e.g., "REFERENCE/Accounting/Processed")
   g. Archive email (remove INBOX label)
```

### Workflow 2: Share Business Document

```
1. Locate file in Nextcloud: `nextcloud_list.py --remote "/Business/Documents/"`
2. Create public share: `nextcloud_share.py --remote "/Business/Documents/contract.pdf"`
3. Copy share link to clipboard or embed in email
4. Track share in spreadsheet if needed
```

### Workflow 3: Organize Existing Documents

```
1. Scan local folders for PDF documents
2. Categorize by filename and content
3. Upload to Nextcloud with standardized naming
4. Create index CSV with metadata (filename, category, date, share link)
5. Verify all files accessible via share links
```

## Scripts Reference

### `nextcloud_client.py` - Core Client Library

Provides reusable Python functions for:
- WebDAV operations (upload, download, list, mkdir)
- Sharing API (create, list, delete shares)
- Error handling and retry logic

### `process_email_attachments.py` - Email Attachment Processor

Downloads attachments from Gmail and uploads to Nextcloud:
- Searches emails with criteria (date, sender, subject)
- Downloads all attachments
- Categorizes based on email metadata
- Uploads to organized folder structure
- Creates share links and tracking CSV

### `nextcloud_share.py` - Command-line Sharing Tool

Creates public share links for files:
```bash
python nextcloud_share.py --remote "/Business/Invoices/invoice.pdf"
# Output: https://nextcloud.blkstr.io/s/ABC123DEF456
```

### `folder_sync.py` - Folder Synchronization

Syncs local folder with Nextcloud directory:
- Uploads new/changed files
- Downloads missing files
- Maintains folder structure

## Configuration

### Environment Variables
```bash
export NEXTCLOUD_URL="https://nextcloud.blkstr.io"
export NEXTCLOUD_USERNAME="jarvis"
export NEXTCLOUD_PASSWORD="agent12345jarvis"
export NEXTCLOUD_BASE_PATH="/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin"
```

### Configuration File
Create `~/.nextcloud/config.json`:
```json
{
  "url": "https://nextcloud.blkstr.io",
  "username": "jarvis",
  "password": "agent12345jarvis",
  "base_path": "/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin",
  "default_folders": {
    "invoices": "/Accounting/Invoices",
    "receipts": "/Accounting/Receipts",
    "documents": "/Documents"
  }
}
```

## Error Handling

**Common errors and solutions:**
- `401 Unauthorized`: Check credentials
- `404 Not Found`: Verify file path exists
- `507 Insufficient Storage`: Clean up old files
- `OCS API errors`: Verify `OCS-APIRequest: true` header

**Retry logic:** Implement exponential backoff for network errors.

## Security Considerations

1. **Credential storage:** Use environment variables or encrypted config files
2. **Share link permissions:** Default to read-only for public links
3. **Access logs:** Review Nextcloud audit logs periodically
4. **Data retention:** Implement archival policies for old documents

## Integration Examples

### With SBA Email Manager Skill
```python
# After categorizing email as "REFERENCE/Accounting/Invoices"
# Automatically download attachments and upload to Nextcloud
from nextcloud_client import upload_invoice

invoice_path = download_email_attachments(email_id)
share_link = upload_invoice(invoice_path, vendor="Voltage")
update_tracking_csv(email_id, share_link)
```

### With nano-pdf Skill
```python
# Extract text from PDF for OCR or data extraction
from nano_pdf import extract_text
from nextcloud_client import download_file

pdf_content = download_file("/Accounting/Invoices/invoice.pdf")
text = extract_text(pdf_content)
amount = extract_invoice_amount(text)
```

## Best Practices

1. **Folder organization:** Use consistent naming and hierarchical structure
2. **File naming:** Include date, vendor, and document type: `YYYY-MM-DD_Vendor_Invoice.pdf`
3. **Metadata tracking:** Maintain CSV with share links, dates, categories
4. **Regular cleanup:** Archive old documents to cold storage
5. **Backup strategy:** Implement regular backups of critical documents

## Resources

### scripts/
- `nextcloud_client.py` - Core client library
- `process_email_attachments.py` - Email attachment processor
- `nextcloud_share.py` - Command-line sharing tool
- `folder_sync.py` - Folder synchronization

### references/
- `api_reference.md` - Detailed API documentation
- `folder_structure.md` - Recommended folder hierarchies
- `email_workflows.md` - Step-by-step email attachment processing

---

**Skill Status:** ✅ Active  
**Last Updated:** 2026-02-21  
**Compatibility:** Nextcloud 25+
