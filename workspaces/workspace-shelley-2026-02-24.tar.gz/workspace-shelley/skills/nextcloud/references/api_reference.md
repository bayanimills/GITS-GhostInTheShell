# Nextcloud API Reference

This document provides detailed API reference for Nextcloud WebDAV and OCS APIs used in the skill.

## Authentication

Nextcloud uses HTTP Basic Authentication for both WebDAV and OCS APIs:

```http
Authorization: Basic base64(username:password)
```

## WebDAV API

### Base URL
```
https://nextcloud.blkstr.io/remote.php/dav/files/{username}
```

### Operations

#### 1. Upload File (PUT)
**Request:**
```http
PUT /remote.php/dav/files/jarvis/remote/path/file.pdf
Authorization: Basic base64(username:password)
Content-Type: application/octet-stream

[file binary data]
```

**Response:**
- `201 Created`: File created successfully
- `204 No Content`: File updated successfully
- `401 Unauthorized`: Authentication failed
- `404 Not Found`: Parent directory doesn't exist
- `507 Insufficient Storage`: Storage quota exceeded

#### 2. Download File (GET)
**Request:**
```http
GET /remote.php/dav/files/jarvis/remote/path/file.pdf
Authorization: Basic base64(username:password)
```

**Response:**
- `200 OK`: File content returned
- `404 Not Found`: File doesn't exist

#### 3. List Directory (PROPFIND)
**Request:**
```http
PROPFIND /remote.php/dav/files/jarvis/remote/path
Authorization: Basic base64(username:password)
Depth: 1
Content-Type: text/xml

<?xml version="1.0"?>
<d:propfind xmlns:d="DAV:">
  <d:prop>
    <d:displayname/>
    <d:resourcetype/>
    <d:getcontentlength/>
    <d:getlastmodified/>
  </d:prop>
</d:propfind>
```

**Response:** `207 Multi-Status` with XML listing directory contents.

#### 4. Create Directory (MKCOL)
**Request:**
```http
MKCOL /remote.php/dav/files/jarvis/remote/path/newfolder
Authorization: Basic base64(username:password)
```

**Response:**
- `201 Created`: Directory created
- `405 Method Not Allowed`: Directory already exists

#### 5. Delete Resource (DELETE)
**Request:**
```http
DELETE /remote.php/dav/files/jarvis/remote/path/file.pdf
Authorization: Basic base64(username:password)
```

**Response:**
- `204 No Content`: Successfully deleted
- `404 Not Found`: Resource doesn't exist

## OCS Sharing API

### Base URL
```
https://nextcloud.blkstr.io/ocs/v2.php/apps/files_sharing/api/v1
```

### Required Header
All OCS API requests require:
```http
OCS-APIRequest: true
```

### Operations

#### 1. Create Share
**Endpoint:** `POST /shares`

**Request Body (JSON):**
```json
{
  "path": "/remote/path/file.pdf",
  "shareType": 3,
  "permissions": 1
}
```

**Share Types:**
- `0`: User share
- `1`: Group share  
- `3`: Public link (most common)
- `4`: Email share
- `6`: Federated cloud share

**Permissions:**
- `1`: Read only
- `15`: All permissions (read, write, share, delete)
- `19`: Read & write (no share, no delete)

**Response (200 OK):**
```json
{
  "ocs": {
    "meta": {
      "status": "ok",
      "statuscode": 200,
      "message": "OK"
    },
    "data": {
      "id": 123,
      "url": "https://nextcloud.blkstr.io/s/ABC123DEF456",
      "token": "ABC123DEF456",
      "file_target": "/file.pdf",
      "permissions": 1,
      "share_type": 3
    }
  }
}
```

#### 2. List Shares
**Endpoint:** `GET /shares`

**Response:** List of all shares for the authenticated user.

#### 3. Delete Share
**Endpoint:** `DELETE /shares/{share_id}`

**Response:** `200 OK` on success.

## Email Integration

### gog CLI Commands for Email Attachment Processing

#### 1. Search for Emails with Attachments
```bash
gog gmail search "has:attachment filename:pdf newer_than:7d" \
  --account service@shopbitcoin.com.au \
  --max 10 \
  --json
```

#### 2. Get Message Details
```bash
gog gmail messages get --thread 19c1b44d344a4286 \
  --account service@shopbitcoin.com.au \
  --json
```

**Note:** Current gog CLI (v0.1.0) may not expose attachment details directly. Alternative approaches:
- Use Gmail API directly via `google-api-python-client`
- Download raw message and parse for attachments
- Use IMAP protocol for attachment access

#### 3. Download Attachment (if supported)
```bash
gog gmail attachment <message_id> <attachment_id> \
  --output ./attachment.pdf \
  --account service@shopbitcoin.com.au
```

## Error Codes

### WebDAV Errors
- `401 Unauthorized`: Invalid credentials
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource doesn't exist
- `409 Conflict`: Resource conflict (e.g., parent doesn't exist)
- `507 Insufficient Storage`: User quota exceeded

### OCS API Errors
- `400 Bad Request`: Invalid parameters
- `403 Forbidden`: Sharing not allowed
- `404 Not Found`: File not found
- `409 Conflict`: Share already exists

## Rate Limits

Nextcloud doesn't enforce strict rate limits by default, but:
- WebDAV: ~100 requests/minute recommended
- OCS API: ~60 requests/minute recommended

Implement exponential backoff for retries.

## File Size Limits

Default Nextcloud limits:
- **Maximum upload size**: 512MB (configurable)
- **Maximum file name length**: 255 characters
- **Maximum path depth**: ~1000 characters

## Best Practices

1. **Path encoding**: Always URL-encode path segments
2. **Error handling**: Check status codes and implement retries
3. **Batch operations**: Process files in batches to avoid rate limiting
4. **Cleanup**: Remove temporary files after processing
5. **Logging**: Log all operations for debugging and audit

## Testing

### Test Nextcloud Connection
```bash
curl -u jarvis:agent12345jarvis \
  https://nextcloud.blkstr.io/remote.php/dav/files/jarvis/
```

### Test Share Creation
```bash
curl -u jarvis:agent12345jarvis \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{"path":"/test.txt","shareType":3,"permissions":1}' \
  https://nextcloud.blkstr.io/ocs/v2.php/apps/files_sharing/api/v1/shares
```

## Security Considerations

1. **Credential storage**: Store credentials in environment variables, not in code
2. **Share permissions**: Default to read-only for public links
3. **Access logs**: Review Nextcloud access logs regularly
4. **Token rotation**: Regularly update passwords and API tokens
5. **Data encryption**: Enable SSL/TLS for all connections