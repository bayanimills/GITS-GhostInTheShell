# Nextcloud Folder Structure Recommendations

Recommended folder hierarchies for business document organization in Nextcloud.

## Base Structure

```
/_private/businesses/Bayani Enterprises/SBA - ShopBitcoin/
├── Accounting/
│   ├── Invoices/
│   │   ├── Voltage/
│   │   ├── Shopify/
│   │   ├── Service Providers/
│   │   ├── Utilities/
│   │   └── 2026/
│   ├── Receipts/
│   │   ├── Bankful/
│   │   ├── Expenses/
│   │   ├── Tax/
│   │   └── 2026/
│   ├── Statements/
│   │   ├── Bank/
│   │   ├── Credit Card/
│   │   └── 2026/
│   └── Payroll/
│       ├── Employees/
│       └── 2026/
├── Operations/
│   ├── Inventory/
│   │   ├── Product Images/
│   │   ├── Supplier Catalogs/
│   │   └── Stock Reports/
│   ├── Shipping/
│   │   ├── Australia Post/
│   │   ├── DHL/
│   │   └── Labels/
│   └── Maintenance/
│       ├── Equipment/
│       └── Licenses/
├── Marketing/
│   ├── Social Media/
│   │   ├── Instagram/
│   │   ├── Twitter/
│   │   └── Facebook/
│   ├── Advertising/
│   │   ├── Campaigns/
│   │   └── Assets/
│   └── Content/
│       ├── Blog Posts/
│       └── Product Descriptions/
├── Sales/
│   ├── Orders/
│   │   ├── 2026/
│   │   ├── Pending/
│   │   └── Completed/
│   ├── Customers/
│   │   ├── Support Tickets/
│   │   └── Communications/
│   └── Reports/
│       ├── Monthly/
│       └── Quarterly/
├── Legal/
│   ├── Contracts/
│   ├── Compliance/
│   └── Trademarks/
└── Archive/
    ├── 2025/
    ├── 2024/
    └── Old Business/
```

## Accounting Folder Details

### Invoices
- **Naming convention**: `YYYY-MM-DD_Vendor_InvoiceNumber.pdf`
- **Examples**:
  - `2026-02-21_Voltage_448A39E5-0012.pdf`
  - `2026-02-20_Shopify_INV-12345.pdf`
- **Subfolders by vendor**: Helps with vendor-specific reporting
- **Year subfolders**: For archive organization

### Receipts
- **Naming convention**: `YYYY-MM-DD_Vendor_Amount_Description.pdf`
- **Examples**:
  - `2026-02-21_Bankful_25.00_Voltage-Payment.pdf`
  - `2026-02-20_Officeworks_45.99_Supplies.pdf`
- **Expense categories**: Office, Travel, Equipment, Software, etc.

### Statements
- **Naming convention**: `YYYY-MM_Vendor_Statement.pdf`
- **Examples**:
  - `2026-02_CommBank_Statement.pdf`
  - `2026-02_AmericanExpress_Statement.pdf`
- **Monthly organization**: One folder per month

## Operations Folder Details

### Product Images
- **Structure from existing workflow**: Already implemented
- **Categories**: Accessories, Clothing & Bags, Mining Equipment, etc.
- **Naming**: Use product SKU or slug for consistency

### Shipping
- **Carrier-specific folders**: Australia Post, DHL, FedEx, etc.
- **Label storage**: PDF shipping labels with order numbers
- **Tracking documents**: Customs forms, insurance certificates

## Email Attachment Workflow Folders

### Automated Processing Structure
When processing email attachments automatically, use this mapping:

```
Email Category → Nextcloud Folder
─────────────────────────────────────
Invoice (Voltage)      → /Accounting/Invoices/Voltage/
Invoice (Shopify)      → /Accounting/Invoices/Shopify/
Receipt (Bankful)      → /Accounting/Receipts/Bankful/
Bank Statement         → /Accounting/Statements/Bank/
Shipping (Aus Post)    → /Operations/Shipping/Australia Post/
Contract               → /Legal/Contracts/
Customer Support       → /Sales/Customers/Support Tickets/
```

### Filename Templates

**Invoices:**
```
{date}_{vendor}_{invoice_number}.pdf
2026-02-21_Voltage_448A39E5-0012.pdf
```

**Receipts:**
```
{date}_{vendor}_{amount}_{purpose}.pdf
2026-02-21_Bankful_25.00_Voltage-Payment.pdf
```

**Statements:**
```
{year}-{month}_{vendor}_Statement.pdf
2026-02_CommBank_Statement.pdf
```

## Archive Strategy

### Active vs. Archived
- **Active**: Current financial year + previous 3 months
- **Archive**: Everything older than 15 months

### Archive Process
1. **Monthly**: Move completed month to yearly folder
2. **Yearly**: Compress and move to Archive/{year}/
3. **Retention**: Keep for 7 years (tax requirements)

### Archive Folder Structure
```
/Archive/
├── 2026/ (active year)
├── 2025/ (previous year)
├── 2024/
├── 2023/
└── Old Business/ (pre-2023)
```

## Permission Model

### Folder Permissions
- **Accounting**: Read/write for owners, read-only for accountants
- **Operations**: Read/write for operations team
- **Marketing**: Read/write for marketing team
- **Sales**: Read/write for sales team, read-only for customer service

### Share Links
- **Internal shares**: User/group shares with appropriate permissions
- **External shares**: Public links with expiration dates
- **Vendor shares**: Specific folders with vendor-specific access

## Implementation Notes

### Automated Folder Creation
Scripts should check and create folders as needed:

```python
def ensure_folder_structure(client, base_path):
    folders = [
        "/Accounting/Invoices/Voltage",
        "/Accounting/Invoices/Shopify",
        "/Accounting/Receipts/Bankful",
        "/Operations/Shipping/Australia Post",
        # ... etc
    ]
    
    for folder in folders:
        full_path = f"{base_path}{folder}"
        if not client.file_exists(full_path):
            client.create_directory(full_path)
```

### Migration from Existing Structure
If migrating from existing files:
1. Inventory existing files
2. Map to new structure
3. Move files in batches
4. Update any references/links

### Backup Strategy
- **Daily**: Incremental backup of changed files
- **Weekly**: Full backup of entire structure  
- **Monthly**: Archive backup to external storage
- **Test restoration**: Quarterly restoration tests