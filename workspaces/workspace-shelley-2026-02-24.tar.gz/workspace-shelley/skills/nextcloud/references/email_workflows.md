# Email Attachment Workflows

Step-by-step workflows for processing email attachments and managing them in Nextcloud.

## Overview

This document outlines systematic approaches to handle email attachments, particularly for receipt and invoice management in business operations.

## Workflow 1: Daily Receipt/Invoice Processing

### Trigger
- Daily at 8:00 AM AEST
- Manual trigger when needed

### Steps

#### 1. Search for New Attachments
```bash
# Search for emails with PDF attachments from last 24 hours
gog gmail search "has:attachment filename:pdf newer_than:1d" \
  --account service@shopbitcoin.com.au \
  --max 50 \
  --json > /tmp/new_attachments.json
```

**Search queries for specific types:**
- Invoices: `"invoice OR bill OR statement has:attachment filename:pdf"`
- Receipts: `"receipt OR payment confirmation has:attachment filename:pdf"`
- Bank: `"statement OR account summary has:attachment filename:pdf"`

#### 2. Categorize Emails
For each email thread:
- Extract sender, subject, date
- Determine category based on patterns:
  - **Voltage invoices**: Sender contains "voltage", subject contains "invoice"
  - **Shopify invoices**: Sender contains "shopify", subject contains "invoice"
  - **Bankful receipts**: Sender contains "bankful", subject contains "receipt"
  - **Bank statements**: Sender contains bank domain, subject contains "statement"
  - **Shipping notifications**: Sender contains "auspost" or "dhl"

#### 3. Download Attachments
For each attachment in categorized emails:
```python
# Pseudo-code for attachment download
def download_attachment(message_id, attachment_id, filename):
    # Note: gog CLI may not have direct attachment download yet
    # Fallback: Use Gmail API or IMAP
    pass
```

**Temporary storage structure:**
```
/tmp/email_attachments/{date}/{category}/
├── voltage_invoice_001.pdf
├── bankful_receipt_001.pdf
└── bank_statement_001.pdf
```

#### 4. Upload to Nextcloud
For each downloaded file:
- Determine destination folder based on category
- Generate standardized filename
- Upload via WebDAV
- Verify upload success

**Example mapping:**
```python
category_to_folder = {
    'voltage_invoice': '/Accounting/Invoices/Voltage',
    'shopify_invoice': '/Accounting/Invoices/Shopify', 
    'bankful_receipt': '/Accounting/Receipts/Bankful',
    'bank_statement': '/Accounting/Statements/Bank',
    'auspost_shipping': '/Operations/Shipping/Australia Post'
}
```

#### 5. Create Share Links
For important documents:
- Create public share link (read-only)
- Store link in tracking database
- Optional: Email link to accounting team

#### 6. Update Email Labels
After successful processing:
- Apply label: `REFERENCE/Accounting/Processed`
- Remove INBOX label (archive)
- For receipts: Also remove UNREAD label

#### 7. Update Tracking
Add record to tracking CSV:
```csv
date_processed,email_id,category,vendor,filename,remote_path,share_url
2026-02-21,19c1b44d344a4286,invoice,Voltage,2026-02-21_Voltage_448A39E5-0012.pdf,/Accounting/Invoices/Voltage/2026-02-21_Voltage_448A39E5-0012.pdf,https://nextcloud.blkstr.io/s/ABC123
```

### Error Handling
- **Failed downloads**: Retry once, then skip and log
- **Failed uploads**: Move to error folder for manual review
- **Network issues**: Exponential backoff retry
- **Storage full**: Alert and pause processing

## Workflow 2: Weekly Statement Consolidation

### Trigger
- Every Monday at 9:00 AM AEST

### Steps

#### 1. Collect All Statements
Search for bank/credit card statements:
```bash
gog gmail search "statement has:attachment filename:pdf newer_than:30d"
```

#### 2. Organize by Institution
- Group by bank/institution
- Sort by date
- Ensure no duplicates

#### 3. Upload to Nextcloud
- Create folder: `/Accounting/Statements/{Bank}/{Year}-{Month}/`
- Upload PDFs
- Create index file with list of statements

#### 4. Archive Old Emails
- Statements older than 3 months: Apply label `REFERENCE/Accounting/Statements/Archived`
- Remove from INBOX

## Workflow 3: Monthly Invoice Reconciliation

### Trigger
- Last business day of month at 10:00 AM AEST

### Steps

#### 1. Collect All Invoices for Month
```bash
# Search for invoices from current month
MONTH="2026-02"
gog gmail search "invoice has:attachment filename:pdf after:${MONTH}-01 before:${MONTH}-28"
```

#### 2. Verify Against Accounting System
- Extract invoice numbers and amounts from PDFs
- Cross-reference with accounting records
- Flag discrepancies

#### 3. Create Monthly Report
- Generate CSV with all invoices
- Calculate totals by vendor
- Create summary PDF report

#### 4. Archive Month
- Move all processed invoices to `/Accounting/Invoices/2026/02/`
- Update tracking database with archive location

## Workflow 4: Emergency Invoice Processing

### Trigger
- Manual when urgent invoice arrives

### Steps

#### 1. Immediate Notification
- Detect email with "urgent", "past due", "final notice"
- Send alert to appropriate person

#### 2. Priority Processing
- Skip batch queue
- Process immediately
- Generate share link
- Send link to accounts payable

#### 3. Follow-up Tracking
- Mark for follow-up in 24 hours
- Check if payment confirmed

## Integration with SBA Email Manager Skill

### Label Mapping
SBA Email Manager labels map to Nextcloud folders:

```
Email Label → Nextcloud Folder
─────────────────────────────────────────────
REFERENCE/Accounting/Invoices → /Accounting/Invoices/
REFERENCE/Accounting/Receipts → /Accounting/Receipts/
REFERENCE/Service Providers/Australia Post → /Operations/Shipping/Australia Post/
ACTION REQUIRED/FOLLOW UP → /Accounting/Action Required/
```

### Combined Workflow
1. **SBA Email Manager** categorizes and labels emails
2. **Nextcloud skill** processes attachments from labeled emails
3. **Both skills** update tracking and status

### Example Integration Script
```python
# Process emails with specific label
def process_labeled_emails(label):
    # Search emails with label
    emails = gog_search(f"label:{label} has:attachment")
    
    for email in emails:
        # Download attachments
        attachments = download_attachments(email)
        
        # Upload to Nextcloud based on label
        folder = map_label_to_folder(label)
        upload_to_nextcloud(attachments, folder)
        
        # Update email status
        mark_as_processed(email)
```

## Advanced Features

### OCR and Data Extraction
For invoices without machine-readable text:
- Use OCR to extract text from scanned PDFs
- Parse invoice number, date, amount, vendor
- Store extracted data in JSON alongside PDF

### Duplicate Detection
- Check file hash against previously processed files
- Skip duplicates to avoid re-processing
- Alert if same invoice appears multiple times

### Automated Accounting Integration
- Extract data from invoices
- Format for import into accounting software (Xero, QuickBooks)
- Create import files ready for upload

## Monitoring and Reporting

### Daily Report
```text
Daily Attachment Processing Report
Date: 2026-02-21
────────────────────────────────────
Emails processed: 15
Attachments processed: 18
By category:
  - Invoices: 5
  - Receipts: 8
  - Statements: 3
  - Other: 2
Errors: 0
Storage used: 45.2 MB
```

### Weekly Summary
- Total processed by category
- Storage growth
- Processing time trends
- Error rate analysis

### Monthly Audit
- Verify all invoices accounted for
- Check storage usage against quota
- Review error logs
- Archive old tracking records

## Troubleshooting

### Common Issues

#### 1. Attachment Download Fails
- **Cause**: gog CLI limitation, network issue
- **Solution**: Use Gmail API directly, implement retry logic

#### 2. Nextcloud Upload Fails
- **Cause**: Authentication error, storage full, network timeout
- **Solution**: Check credentials, clear space, increase timeout

#### 3. Duplicate Processing
- **Cause**: Email re-sent, multiple threads
- **Solution**: Implement hash-based duplicate detection

#### 4. Incorrect Categorization
- **Cause**: Unrecognized sender or subject pattern
- **Solution**: Update pattern matching, add manual review step

### Debug Mode
Enable debug logging:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Manual Override
For problematic emails:
- Move to manual processing folder
- Process individually with verification
- Update patterns based on manual categorization