#!/usr/bin/env python3
"""
Update documentation to include Australia Post categorization
"""

import re

# Update email_categories.md
with open('references/email_categories.md', 'r') as f:
    content = f.read()

# Find where to insert Australia Post category
# Look for the end of REFERENCE/Security/Logins section
# We'll insert after that section but before "## Categorization Logic"

# Pattern to find Security/Logins section end
# We'll find "### REFERENCE/Security/Logins" and then find the next "###" or "##"
# Actually simpler: insert before "## Categorization Logic"

if '### REFERENCE/Service Providers/Australia Post' not in content:
    # Find the position of "## Categorization Logic"
    pos = content.find('## Categorization Logic')
    if pos != -1:
        # Insert new category before it
        new_category = """
### REFERENCE/Service Providers/Australia Post
**Senders:** `auspost.com.au`, `notifications.auspost.com.au`, `customerservice@auspost.com.au`
**Keywords:** `australia post`, `auspost`, `delivery`, `parcel`, `shipment`
**Examples:**
- Delivery notifications and tracking updates
- Australia Post customer service cases
- Delivery experience surveys
- Parcel delay notifications

"""
        content = content[:pos] + new_category + content[pos:]
        
        with open('references/email_categories.md', 'w') as f:
            f.write(content)
        print("Updated email_categories.md")
    else:
        print("Could not find '## Categorization Logic' in email_categories.md")
else:
    print("Australia Post category already exists in email_categories.md")

# Update SKILL.md label structure
with open('SKILL.md', 'r') as f:
    skill_content = f.read()

# Find the label structure diagram and add Australia Post
# Look for the REFERENCE section in the diagram
if 'REFERENCE/Service Providers/Australia Post' not in skill_content:
    # Find REFERENCE section in the diagram
    # It's in a code block with ```
    # We'll add under REFERENCE
    pattern = r'(📁 REFERENCE/\s*\n(?:   [^\n]*\n)*)'
    match = re.search(pattern, skill_content)
    if match:
        ref_section = match.group(1)
        # Add Australia Post under REFERENCE
        updated_ref = ref_section.rstrip() + '\n   ├── 📮 Service Providers/\n   │   └── Australia Post\n'
        skill_content = skill_content.replace(ref_section, updated_ref)
        
        with open('SKILL.md', 'w') as f:
            f.write(skill_content)
        print("Updated SKILL.md label structure")
    else:
        print("Could not find REFERENCE section in SKILL.md diagram")
else:
    print("Australia Post already in SKILL.md")

print("Documentation update complete")