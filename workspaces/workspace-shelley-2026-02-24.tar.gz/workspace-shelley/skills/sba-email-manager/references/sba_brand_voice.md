# Shop Bitcoin Australia Brand Voice

## Brand Identity

### Core Values
1. **Bitcoin-only focus**: No altcoins, no compromises
2. **Australian first**: Local support, local community
3. **Educational approach**: Empowering through knowledge
4. **Quality assurance**: Reliable hardware, trusted advice
5. **Community building**: Growing Bitcoin adoption in Australia

### Brand Personality
- **Expert but approachable**: Deep knowledge, clear explanations
- **Professional yet friendly**: Business standards with warmth
- **Innovative but practical**: Cutting-edge with real-world application
- **Community-focused**: Building together, not just selling
- **Security-conscious**: Priority on safety and reliability

## Communication Style

### Tone Guidelines

**Formal Situations:**
- Business partnerships
- Invoice communications
- Legal matters
- Formal complaints

**Standard Customer Communications:**
- Product inquiries
- Technical support
- Order updates
- General questions

**Community/Educational:**
- Bitcoin education
- Event announcements
- Social media
- Newsletter content

### Language Preferences

**Use:**
- Australian spelling (colour, centre, organise)
- Local references (AEST time, Australian locations)
- Bitcoin terminology (sats, hashrate, nodes)
- Clear, simple explanations
- Positive, solution-focused language

**Avoid:**
- American spellings
- Cryptocurrency jargon (except Bitcoin-specific)
- Negative or defensive language
- Overly technical terms without explanation
- Financial advice or predictions

### Voice Examples

**Too formal (avoid):**
"Pursuant to your inquiry regarding the BitAxe Gamma 601 unit, please be advised that the operational parameters necessitate verification of power supply specifications."

**Too casual (avoid):**
"Hey mate, your BitAxe is cooked! Probably need a new PSU, yeah?"

**Brand voice (use):**
"Thanks for reaching out about your BitAxe Gamma 601. Based on the overheating issue you described, let's first check your power supply meets the 12V 5A minimum requirement. This is often the cause of similar issues."

## Key Messaging

### About Shop Bitcoin Australia
- "Australia's one-stop Bitcoin shop"
- "Bitcoin-only hardware and education"
- "Supporting Australian Bitcoin adoption since [year]"
- "Local support for global technology"

### Product Philosophy
- "Quality Bitcoin mining hardware"
- "Secure storage solutions"
- "Educational resources for all levels"
- "Community-focused support"

### Customer Commitment
- "Australian-based support"
- "Expert Bitcoin guidance"
- "Quality you can trust"
- "Community-driven growth"

## Communication Templates

### Email Signatures
**Standard:**
```
Best regards,

Shop Bitcoin Australia Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

Australia's One-Stop Bitcoin Shop
```

**Technical Support:**
```
Happy Hashing!

Shop Bitcoin Australia Technical Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

Need urgent help? Call [emergency number]
```

### Common Phrases

**Opening:**
- "Thanks for reaching out to Shop Bitcoin Australia"
- "Great to hear from you"
- "Thanks for your interest in [product]"
- "Appreciate you contacting us about [issue]"

**Closing:**
- "Happy Hashing!" (for mining-related)
- "Stack sats safely!" (for storage/security)
- "Thanks for supporting Australian Bitcoin"
- "See you in the mempool!"

**Problem Solving:**
- "Let's work through this together"
- "Here's what I recommend"
- "Based on similar cases"
- "To ensure your safety and success"

**Educational:**
- "Here's how Bitcoin works"
- "Think of it like this"
- "The key concept is"
- "This matters because"

## Visual Language References

### Terminology Hierarchy

**Primary (use frequently):**
- Bitcoin
- Sats (satoshis)
- Hashrate
- Node
- Wallet
- Mining
- Security

**Secondary (use when needed):**
- Difficulty adjustment
- Mempool
- UTXO
- Lightning Network
- Taproot
- Multisig

**Tertiary (explain if used):**
- Script
- OP_CODE
- Merkle root
- SegWit
- Coinjoin

### Australian Context
- Reference AEST/AEDT time zones
- Mention Australian cities/regions
- Use local examples and analogies
- Reference Australian Bitcoin community
- Align with local regulations and standards

### Bitcoin Philosophy Integration
- Emphasize sovereignty and self-custody
- Reference Bitcoin principles (decentralization, censorship resistance)
- Align with Bitcoin-only philosophy
- Promote education and understanding
- Support open source and verifiability

## Social Media Voice

### Twitter (@ShopBitcoinAus)
- Concise, educational tweets
- Bitcoin news with Australian angle
- Product highlights with benefits
- Community engagement
- No hashtags (per user preference)

### Educational Content
- "Did you know?" facts
- Bitcoin basics explained simply
- Hardware setup guides
- Security best practices
- Australian Bitcoin ecosystem updates

### Community Engagement
- Respond to all mentions
- Share customer successes (with permission)
- Highlight Australian Bitcoin projects
- Participate in Bitcoin conversations
- Build, don't just broadcast

## Crisis Communication

### Technical Issues
1. **Acknowledge**: "We're aware of the issue"
2. **Explain**: "Here's what's happening"
3. **Action**: "Here's what we're doing"
4. **Timeline**: "We expect resolution by"
5. **Support**: "Contact us here for help"

### Customer Complaints
1. **Listen**: "Thanks for sharing your experience"
2. **Empathize**: "I understand why you're frustrated"
3. **Solve**: "Here's how we'll make this right"
4. **Compensate**: "As a gesture of goodwill"
5. **Improve**: "We'll use this to get better"

### Industry Events
1. **Context**: "Here's what this means"
2. **Position**: "Our approach remains"
3. **Guidance**: "What we recommend"
4. **Support**: "How we can help"
5. **Future**: "Looking ahead"

## Consistency Checks

### Before Sending
- [ ] Aligns with Bitcoin-only philosophy
- [ ] Uses Australian context appropriately
- [ ] Maintains professional yet friendly tone
- [ ] Provides clear, accurate information
- [ ] Supports educational approach
- [ ] Reflects community focus
- [ ] Emphasizes security and reliability

### Brand Alignment Questions
1. Does this communication help grow Bitcoin understanding?
2. Does it support Australian Bitcoin adoption?
3. Does it maintain our quality standards?
4. Does it build community trust?
5. Does it reflect our Bitcoin-only commitment?

## Training Examples

### Good Examples
**Customer Inquiry:**
"Hi there! I'm new to Bitcoin mining and looking at the BitAxe Gamma 601. What else would I need to get started?"

**Brand Response:**
"Great question! The BitAxe Gamma 601 is an excellent starting point for Australian miners. You'll also need a 12V 5A power supply, an Ethernet connection, and a basic understanding of pool mining. We have a complete starter guide on our website that walks through each step. Welcome to the world of Bitcoin mining!"

### Areas for Improvement
**Original:**
"Your order is delayed because of supplier issues."

**Improved (brand voice):**
"Thanks for your patience with order #2289. We're working closely with our Australian supplier to resolve a temporary stock issue and will have your BitAxe shipped as soon as possible. We'll update you by tomorrow with a revised delivery timeline."