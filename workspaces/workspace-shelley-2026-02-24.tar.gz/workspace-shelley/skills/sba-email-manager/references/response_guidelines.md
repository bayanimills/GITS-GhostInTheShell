# Customer Response Guidelines

## Core Principles

### Professional Tone
- **Formal but friendly**: Professional yet approachable
- **Clear communication**: Avoid jargon, explain technical terms
- **Australian English**: Use local spelling and terminology
- **Brand consistency**: Maintain SBA voice across all communications

### Response Time Standards
- **URGENT**: <24 hours (BitAxe issues, payment failures)
- **THIS WEEK**: <48 hours (general inquiries, order questions)
- **FOLLOW UP**: <7 days (non-urgent business)
- **Automated**: Immediate (payment receipts, order confirmations)

### Approval Required
**Always draft for approval before sending:**
- Customer support responses
- Technical troubleshooting advice
- Refund/return communications
- Business partnership inquiries
- Any email leaving the organization

**Can send automatically:**
- Internal system notifications
- Automated reports
- Scheduled check-ins

## Response Templates

### Technical Support (BitAxe Issues)
**Structure:**
1. Acknowledge the issue
2. Request specific details (model, symptoms, troubleshooting attempted)
3. Provide step-by-step guidance
4. Offer escalation path if unresolved
5. Set expectations for follow-up

**Key Details to Request:**
- BitAxe model (Gamma 601, Ultra, etc.)
- Power supply specifications
- Error messages displayed
- Photos/videos of issue
- What troubleshooting has been attempted

### General Inquiries
**Structure:**
1. Thank for contacting SBA
2. Answer specific question clearly
3. Provide additional helpful information
4. Invite further questions
5. Include relevant links/resources

**Common Topics:**
- Product specifications and compatibility
- Shipping times and costs
- Order status inquiries
- Business hours and contact information
- Bitcoin education resources

### Order Management
**Structure:**
1. Confirm order details
2. Provide current status
3. Set clear expectations
4. Include next steps
5. Offer assistance for questions

**Status Updates:**
- Order received
- Payment processed
- Item shipped (with tracking)
- Delivery expected
- Issue identified (with resolution plan)

### Invoice/Payment Communications
**Structure:**
1. Clear subject line with invoice/order number
2. Polite payment reminder
3. Easy payment instructions
4. Contact for questions
5. Thank for business

**Payment Terms:**
- Net 7 days for regular invoices
- Immediate for overdue accounts
- Multiple payment options (Bank transfer, Bitcoin)
- Receipt provided upon payment

## Brand Voice Guidelines

### Tone
- **Knowledgeable**: Demonstrate Bitcoin expertise
- **Helpful**: Go above and beyond to assist
- **Professional**: Maintain business standards
- **Australian**: Local references and terminology
- **Bitcoin-focused**: Align with Bitcoin principles

### Language Style
- **Avoid**: Jargon, technical terms without explanation
- **Use**: Clear explanations, analogies for complex concepts
- **Include**: Australian references where appropriate
- **Emphasize**: Security, reliability, customer satisfaction

### Signature Block
**Standard Format:**
```
Best regards,

Shop Bitcoin Australia Support
service@shopbitcoin.com.au
https://shopbitcoin.com.au

---
Response drafted by [Agent Name], Shop Bitcoin Australia Manager
```

**Optional Additions:**
- Business hours (9am-5pm AEST, Mon-Fri)
- Emergency contact for urgent issues
- Social media links (@ShopBitcoinAus)
- Physical address (if relevant)

## Escalation Procedures

### When to Escalate
1. **Technical issues** unresolved after basic troubleshooting
2. **Customer dissatisfaction** with initial response
3. **Legal or compliance** concerns
4. **Financial disputes** over $500+
5. **Security incidents** or data breaches

### Escalation Path
1. **Level 1**: Standard support (email responses)
2. **Level 2**: Technical specialist (complex issues)
3. **Level 3**: Management (disputes, complaints)
4. **Level 4**: Executive (legal, major incidents)

### Documentation Requirements
- **Record**: All customer interactions
- **Track**: Issue resolution progress
- **Document**: Solutions for knowledge base
- **Follow up**: Ensure customer satisfaction

## Quality Assurance

### Response Checklist
- [ ] Correct greeting using customer name
- [ ] Clear answer to all questions
- [ ] Appropriate technical level
- [ ] Helpful additional information
- [ ] Correct contact details
- [ ] Professional signature
- [ ] No spelling/grammar errors
- [ ] Appropriate tone for situation

### Review Process
1. **Draft**: Create response using template
2. **Check**: Verify accuracy and completeness
3. **Approve**: Get authorization before sending
4. **Send**: Dispatch to customer
5. **Follow up**: Check if issue resolved
6. **Archive**: Store in appropriate category

### Continuous Improvement
- **Collect feedback**: Customer satisfaction surveys
- **Analyze patterns**: Common issues and solutions
- **Update templates**: Based on effective responses
- **Train regularly**: New products and procedures
- **Monitor metrics**: Response times, resolution rates

## Special Scenarios

### Bitcoin Technical Questions
- **Accuracy first**: Verify all technical information
- **Educational approach**: Explain concepts clearly
- **Security emphasis**: Highlight proper practices
- **Community resources**: Point to reputable sources
- **No financial advice**: Disclaim investment guidance

### Hardware Issues
- **Safety first**: Address any safety concerns immediately
- **Detailed troubleshooting**: Step-by-step guidance
- **Warranty information**: Clear policy explanation
- **Repair options**: Available services and costs
- **Replacement process**: If applicable

### Order Problems
- **Empathy**: Acknowledge inconvenience
- **Transparency**: Explain what happened
- **Solution-focused**: Offer clear resolution
- **Compensation**: If appropriate (discount, upgrade)
- **Prevention**: Steps to avoid recurrence

### Positive Feedback
- **Gratitude**: Thank for kind words
- **Acknowledgment**: Share with team
- **Encouragement**: Invite to share experience
- **Relationship building**: Offer future assistance
- **Social proof**: Request permission to share (if appropriate)