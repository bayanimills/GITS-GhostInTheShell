# Email Categorization Rules

## Category Definitions

### ACTION REQUIRED/URGENT (24h response)
**Keywords:** `urgent`, `emergency`, `critical`, `asap`, `immediate`
**Examples:**
- BitAxe overheating issues
- Payment processing failures
- Security breaches
- Legal notices
- System outages affecting customers

### ACTION REQUIRED/THIS WEEK (7 days)
**Keywords:** `past due`, `due in`, `deadline`, `follow up`, `reminder`
**Examples:**
- Invoice payments (Voltage, Shopify)
- Order fulfillment deadlines
- Customer support follow-ups
- Partnership inquiries
- Event registrations

### ACTION REQUIRED/FOLLOW UP (30 days)
**Keywords:** (catch-all for non-urgent)
**Examples:**
- General business inquiries
- Marketing opportunities
- Newsletter subscriptions
- Conference invitations
- Product feedback

### REFERENCE/Accounting/Invoices
**Senders:** `voltage.cloud`, `shopify.com`, `billing@`
**Keywords:** `invoice`, `bill`, `payment due`, `statement`
**Examples:**
- Voltage hosting invoices
- Shopify subscription bills
- Service provider invoices

### REFERENCE/Accounting/Receipts
**Senders:** `bankful.com`, `payments@`
**Keywords:** `payment received`, `receipt`, `transaction`, `confirmation`
**Examples:**
- Customer payment confirmations
- Supplier payment receipts
- Refund confirmations

### REFERENCE/Orders/Pending
**Keywords:** `order`, `shipment`, `dispatch`, `tracking`, `delivery`
**Examples:**
- New customer orders
- Shipping notifications
- Order status inquiries
- Return requests

### REFERENCE/Customer Support/Technical
**Keywords:** `bitaxe`, `overheating`, `faulty`, `module`, `technical`, `issue`, `problem`, `error`, `not working`
**Examples:**
- BitAxe hardware issues
- Mining setup problems
- Firmware errors
- Compatibility questions
- Performance troubleshooting

### REFERENCE/Customer Support/General
**Keywords:** `inquiry`, `question`, `general`, `ask`, `help`, `information`, `advice`
**Examples:**
- Product information requests
- Pricing inquiries
- Shipping time questions
- Business hours
- Return policies

### REFERENCE/Security/Logins
**Senders:** `verify@x.com`, `no-reply@accounts.google.com`, `security@`
**Keywords:** `login`, `security`, `alert`, `verify`, `unauthorized`, `new device`
**Examples:**
- X (Twitter) login notifications
- Google security alerts
- Account verification requests
- Two-factor authentication codes


### REFERENCE/Service Providers/Australia Post
**Senders:** `auspost.com.au`, `notifications.auspost.com.au`, `customerservice@auspost.com.au`
**Keywords:** `australia post`, `auspost`, `delivery`, `parcel`, `shipment`
**Examples:**
- Delivery notifications and tracking updates
- Australia Post customer service cases
- Delivery experience surveys
- Parcel delay notifications

## Categorization Logic

### Priority Order
1. **URGENT** - Immediate danger or critical business impact
2. **THIS WEEK** - Time-sensitive business operations
3. **Customer Support** - Direct customer communication
4. **Accounting** - Financial transactions
5. **Orders** - Business fulfillment
6. **Security** - Account protection
7. **FOLLOW UP** - Everything else

### Keyword Matching Rules
- Check subject line first
- Check sender domain/address
- Check body for technical terms
- Prefer specific over general categories
- When in doubt, use more specific category

### Special Cases

**BitAxe Issues:**
- Always categorize as `REFERENCE/Customer Support/Technical`
- Flag as `ACTION REQUIRED/URGENT` if contains `overheating`, `fire`, `smoke`, `danger`
- Include model information if available (Gamma 601, Ultra, etc.)

**Voltage Invoices:**
- Always `REFERENCE/Accounting/Invoices`
- Flag as `ACTION REQUIRED/THIS WEEK` if `past due` or `due in [1-3] days`
- Archive after payment confirmation

**Bankful Payments:**
- Always `REFERENCE/Accounting/Receipts`
- Cross-reference with order numbers
- Archive after 30 days

**Order Threads:**
- Start as `REFERENCE/Orders/Pending`
- Move to appropriate category when resolved
- Archive completed threads quarterly

## Automation Rules

### Suggested Filters
1. `from:voltage.cloud` → `REFERENCE/Accounting/Invoices`
2. `from:bankful.com` → `REFERENCE/Accounting/Receipts`
3. `subject:bitaxe OR subject:overheating` → `REFERENCE/Customer Support/Technical`
4. `from:verify@x.com OR subject:login` → `REFERENCE/Security/Logins`
5. `subject:"order" OR subject:"payment"` → `REFERENCE/Orders/Pending`

### Processing Workflow
1. **Daily**: Run categorization script
2. **Urgent**: Process within 24 hours
3. **This Week**: Process within 7 days
4. **Reference**: Label and archive periodically (daily at 11pm via automated script)
5. **Weekly**: Review all pending items
6. **Monthly**: Clean up old categories
7. **Quarterly**: Archive completed threads
## Automation Tracking Labels

### Shelley-Processed
**Purpose:** Tracks emails that have been processed and archived by Shelley automation
**When applied:** Automatically added after periodic archiving script runs
**Behavior:** Prevents duplicate processing of already-archived emails

### Saved in Nextcloud by Shelley
**Purpose:** Marks invoices where PDFs have been downloaded and stored in Nextcloud
**When applied:** After successful Voltage invoice processing workflow
**Behavior:** Indicates document has been archived to Nextcloud Finance folder

