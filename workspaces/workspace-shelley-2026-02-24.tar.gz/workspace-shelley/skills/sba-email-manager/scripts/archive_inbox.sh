#!/bin/bash
# Archive inbox emails script - Wrapper for common use cases

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/../logs"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
ACCOUNT="service@shopbitcoin.com.au"

echo "============================================================"
echo "SBA EMAIL ARCHIVING TOOL"
echo "Date: $(date)"
echo "Account: $ACCOUNT"
echo "============================================================"

usage() {
    echo "Usage: $0 [OPTION]"
    echo ""
    echo "Options:"
    echo "  all              Archive all emails in inbox (except held items)"
    echo "  promotional      Archive promotional emails only"
    echo "  payments         Archive payment receipts only"
    echo "  security         Archive security alerts only"
    echo "  custom QUERY     Archive emails matching custom Gmail query"
    echo "  dry-run          Show what would be archived without doing it"
    echo "  help             Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 all           # Archive all inbox emails"
    echo "  $0 promotional   # Archive promotional emails"
    echo "  $0 dry-run       # Show what would be archived"
    echo "  $0 custom \"from:bankful.com\"  # Archive Bankful payments"
}

case "$1" in
    all)
        echo "Archiving all emails in inbox..."
        python3 "$SCRIPT_DIR/batch_archive.py" --account "$ACCOUNT" --query "in:inbox" --max 50
        ;;
        
    promotional)
        echo "Archiving promotional emails..."
        python3 "$SCRIPT_DIR/batch_archive.py" --account "$ACCOUNT" \
            --query "in:inbox category:promotions" --label "ACTION REQUIRED/FOLLOW UP"
        ;;
        
    payments)
        echo "Archiving payment receipts..."
        python3 "$SCRIPT_DIR/batch_archive.py" --account "$ACCOUNT" \
            --query "in:inbox from:bankful.com" --label "REFERENCE/Accounting/Receipts"
        ;;
        
    security)
        echo "Archiving security alerts..."
        python3 "$SCRIPT_DIR/batch_archive.py" --account "$ACCOUNT" \
            --query "in:inbox (subject:login OR subject:security OR subject:alert)" \
            --label "REFERENCE/Security/Logins"
        ;;
        
    custom)
        if [ -z "$2" ]; then
            echo "Error: Custom query required"
            usage
            exit 1
        fi
        echo "Archiving with custom query: $2"
        python3 "$SCRIPT_DIR/batch_archive.py" --account "$ACCOUNT" --query "$2"
        ;;
        
    dry-run)
        echo "DRY RUN - Showing what would be archived..."
        python3 "$SCRIPT_DIR/batch_archive.py" --account "$ACCOUNT" --query "in:inbox" --max 20 --dry-run
        ;;
        
    help|--help|-h)
        usage
        ;;
        
    *)
        echo "Error: Unknown option '$1'"
        usage
        exit 1
        ;;
esac

# Save log
if [ -d "$LOG_DIR" ]; then
    echo "Log saved to: $LOG_DIR/archive_${TIMESTAMP}.log"
fi

echo "============================================================"
echo "ARCHIVING COMPLETE"
echo "============================================================"