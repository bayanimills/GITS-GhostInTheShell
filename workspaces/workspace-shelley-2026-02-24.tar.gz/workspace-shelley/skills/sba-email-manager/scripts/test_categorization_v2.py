#!/usr/bin/env python3
"""
Test email categorization logic with Australia Post updates
"""

def categorize_email(subject, from_email, body):
    """Categorize email based on content"""
    subject_lower = subject.lower()
    from_lower = from_email.lower()
    
    # Voltage invoices
    if 'voltage' in from_lower or 'invoice' in subject_lower:
        return 'REFERENCE/Accounting/Invoices'
    
    # Bankful payments
    elif 'bankful' in from_lower or 'payment received' in subject_lower:
        return 'REFERENCE/Accounting/Receipts'
    
    # Customer support - technical
    elif any(keyword in subject_lower for keyword in ['bitaxe', 'overheating', 'technical', 'issue']):
        return 'REFERENCE/Customer Support/Technical'
    
    # Customer support - general
    elif any(keyword in subject_lower for keyword in ['inquiry', 'question', 'general', 'order', 'return', 'refund']):
        return 'REFERENCE/Customer Support/General'
    
    # Orders
    elif 'order' in subject_lower or 'confirmed' in subject_lower or 'shipment' in subject_lower:
        return 'REFERENCE/Orders/Pending'
    
    # Security
    elif any(keyword in subject_lower for keyword in ['security', 'login', 'alert', 'verify']):
        return 'REFERENCE/Security/Logins'
    
    # Shopify/business
    elif 'shopify' in from_lower or 'shopify' in subject_lower:
        return 'REFERENCE/Business/Shopify'
    
    # Australia Post / Service Providers
    elif 'australia post' in from_lower or 'auspost' in from_lower or 'australia post' in subject_lower:
        return 'REFERENCE/Service Providers/Australia Post'
    
    # Promotional (default)
    else:
        return 'ACTION REQUIRED/FOLLOW UP'

# Test with comprehensive examples
test_cases = [
    # Voltage invoices
    ("Reminder: Your invoice from Voltage #448A39E5-0012 is 0 days past due", "Voltage <invoice+statements@voltage.cloud>", "", "REFERENCE/Accounting/Invoices"),
    
    # Bankful payments
    ("Payment received for amount A$610.00 from Trevor Watkins", "no-reply@bankful.com", "", "REFERENCE/Accounting/Receipts"),
    
    # Customer support - technical
    ("BitAxe overheated...", "carpet-king@bigpond.com", "", "REFERENCE/Customer Support/Technical"),
    
    # Customer support - general
    ("Refund or Replacement Request", "Owen Kahler <Owen.Kahler@kahlerfamilytrust.onmicrosoft.com>", "", "REFERENCE/Customer Support/General"),
    
    # Orders
    ("Re: A shipment from order #2289 is on the way", "Robert Schot <sunnyfnq@gmail.com>", "", "REFERENCE/Customer Support/General"),
    
    # Invoices (non-Voltage)
    ("Bitaxe Invoice", "Dan Randall <dansran@gmail.com>", "", "REFERENCE/Accounting/Invoices"),
    
    # Shopify/business
    ("Updates to Partner Terms and Conditions", "Shopify <email@email.shopify.com>", "", "REFERENCE/Business/Shopify"),
    
    # Australia Post - delivery notifications
    ("Sba, how was your recent delivery?", "Australia Post <noreply@notifications.auspost.com.au>", "", "REFERENCE/Service Providers/Australia Post"),
    
    # Australia Post - delivery tracking
    ("Your delivery is on its way", "Australia Post <noreply@notifications.auspost.com.au>", "", "REFERENCE/Service Providers/Australia Post"),
    
    # Australia Post - customer service
    ("Australia Post - Case: 68942450", "Australia Post <customerservice@auspost.com.au>", "", "REFERENCE/Service Providers/Australia Post"),
    
    # Australia Post - in subject only
    ("Issue with Australia Post delivery", "customer@gmail.com", "", "REFERENCE/Service Providers/Australia Post"),
    
    # Auspost in from address
    ("Your parcel has been delivered", "noreply@auspost.com.au", "", "REFERENCE/Service Providers/Australia Post"),
    
    # Promotional
    ("Special offer just for you", "promo@example.com", "", "ACTION REQUIRED/FOLLOW UP"),
    
    # Default
    ("test subject", "Bayani Mills <bayanimills@gmail.com>", "", "ACTION REQUIRED/FOLLOW UP"),
]

print("=" * 70)
print("COMPREHENSIVE CATEGORIZATION TEST")
print("Includes Australia Post / Service Provider updates")
print("=" * 70)

passed = 0
failed = 0

for subject, from_email, body, expected in test_cases:
    actual = categorize_email(subject, from_email, body)
    status = "✅" if actual == expected else "❌"
    
    if actual == expected:
        passed += 1
    else:
        failed += 1
    
    print(f"{status} Subject: {subject[:50]}...")
    print(f"   From: {from_email[:40]}...")
    print(f"   Expected: {expected}")
    print(f"   Actual: {actual}")
    if actual != expected:
        print(f"   MISMATCH!")
    print("-" * 50)

print("=" * 70)
print(f"RESULTS: {passed} passed, {failed} failed")
print("=" * 70)

if failed > 0:
    exit(1)
else:
    exit(0)