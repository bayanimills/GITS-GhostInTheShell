#!/usr/bin/env python3
"""
Test email categorization logic
"""

def categorize_email(subject, from_email, body):
    """Categorize email based on content"""
    subject_lower = subject.lower()
    from_lower = from_email.lower()
    
    # Voltage invoices
    if 'voltage' in from_lower or 'invoice' in subject_lower:
        return 'REFERENCE/Accounting/Invoices'
    
    # Bankful payments
    elif 'bankful' in from_lower or 'payment received' in subject_lower:
        return 'REFERENCE/Accounting/Receipts'
    
    # Customer support - technical
    elif any(keyword in subject_lower for keyword in ['bitaxe', 'overheating', 'technical', 'issue']):
        return 'REFERENCE/Customer Support/Technical'
    
    # Customer support - general
    elif any(keyword in subject_lower for keyword in ['inquiry', 'question', 'general', 'order', 'return', 'refund']):
        return 'REFERENCE/Customer Support/General'
    
    # Orders
    elif 'order' in subject_lower or 'confirmed' in subject_lower or 'shipment' in subject_lower:
        return 'REFERENCE/Orders/Pending'
    
    # Security
    elif any(keyword in subject_lower for keyword in ['security', 'login', 'alert', 'verify']):
        return 'REFERENCE/Security/Logins'
    
    # Shopify/business
    elif 'shopify' in from_lower or 'shopify' in subject_lower:
        return 'REFERENCE/Business/Shopify'
    
    # Australia Post / Service Providers
    elif 'australia post' in from_lower or 'auspost' in from_lower or 'australia post' in subject_lower:
        return 'REFERENCE/Service Providers/Australia Post'
    
    # Promotional (default)
    else:
        return 'ACTION REQUIRED/FOLLOW UP'

# Test with some examples from the inbox
test_cases = [
    ("Reminder: Your invoice from Voltage #448A39E5-0012 is 0 days past due", "Voltage <invoice+statements@voltage.cloud>", ""),
    ("Payment received for amount A$610.00 from Trevor Watkins", "no-reply@bankful.com", ""),
    ("BitAxe overheated...", "carpet-king@bigpond.com", ""),
    ("Refund or Replacement Request", "Owen Kahler <Owen.Kahler@kahlerfamilytrust.onmicrosoft.com>", ""),
    ("Re: A shipment from order #2289 is on the way", "Robert Schot <sunnyfnq@gmail.com>", ""),
    ("Bitaxe Invoice", "Dan Randall <dansran@gmail.com>", ""),
    ("Updates to Partner Terms and Conditions", "Shopify <email@email.shopify.com>", ""),
    ("test subject", "Bayani Mills <bayanimills@gmail.com>", ""),
]

print("=" * 60)
print("CATEGORIZATION TEST")
print("=" * 60)

for subject, from_email, body in test_cases:
    category = categorize_email(subject, from_email, body)
    print(f"Subject: {subject[:50]}...")
    print(f"From: {from_email[:40]}...")
    print(f"Category: {category}")
    print("-" * 40)

print("=" * 60)