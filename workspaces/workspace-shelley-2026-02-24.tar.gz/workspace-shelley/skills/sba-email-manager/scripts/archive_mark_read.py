#!/usr/bin/env python3
"""
Archive and mark as read script - Enhanced version that marks archived emails as read
"""

import subprocess
import json
import sys
import time

def run_gog(args):
    """Run gog command"""
    cmd = ['gog'] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_inbox_emails(account, max_results=30):
    """Get emails currently in inbox"""
    args = ['gmail', 'messages', 'search', 'in:inbox', '--max', str(max_results),
            '--account', account, '--json']
    result = run_gog(args)
    
    if not result or result.returncode != 0:
        print(f"Failed to get inbox emails: {result.stderr if result else 'Unknown'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        return data.get('messages', [])
    except:
        return []

def categorize_email(subject, from_email):
    """Categorize email based on content"""
    subject_lower = subject.lower()
    from_lower = from_email.lower()
    
    # Voltage invoices (keep in inbox per instruction)
    if 'voltage' in from_lower:
        return None  # Don't archive - keep in inbox
    
    # Bankful payments
    elif 'bankful' in from_lower or 'payment received' in subject_lower:
        return 'REFERENCE/Accounting/Receipts'
    
    # Customer support - technical
    elif any(keyword in subject_lower for keyword in ['bitaxe', 'overheating', 'technical', 'issue']):
        return 'REFERENCE/Customer Support/Technical'
    
    # Customer support - general
    elif any(keyword in subject_lower for keyword in ['inquiry', 'question', 'general', 'order', 'return', 'refund']):
        return 'REFERENCE/Customer Support/General'
    
    # Orders
    elif 'order' in subject_lower or 'confirmed' in subject_lower or 'shipment' in subject_lower:
        return 'REFERENCE/Orders/Pending'
    
    # Security
    elif any(keyword in subject_lower for keyword in ['security', 'login', 'alert', 'verify']):
        return 'REFERENCE/Security/Logins'
    
    # Shopify/business
    elif 'shopify' in from_lower or 'shopify' in subject_lower:
        return 'REFERENCE/Business/Shopify'
    
    # Australia Post / Service Providers
    elif 'australia post' in from_lower or 'auspost' in from_lower or 'australia post' in subject_lower:
        return 'REFERENCE/Service Providers/Australia Post'
    
    # Invoices (non-Voltage)
    elif 'invoice' in subject_lower or 'tax invoice' in subject_lower:
        return 'REFERENCE/Accounting/Invoices'
    
    # Promotional (default)
    else:
        return 'ACTION REQUIRED/FOLLOW UP'

def process_email(thread_id, label, account, mark_read=True):
    """Process email: add label, archive, and optionally mark as read"""
    # Build remove list
    remove_labels = ['INBOX']  # Always archive
    if mark_read:
        remove_labels.append('UNREAD')
    
    remove_str = ','.join(remove_labels)
    
    args = ['gmail', 'labels', 'modify', thread_id, '--add', label,
            '--remove', remove_str, '--account', account]
    result = run_gog(args)
    
    return result and result.returncode == 0

def main():
    account = 'service@shopbitcoin.com.au'
    
    print("=" * 70)
    print("ARCHIVE & MARK AS READ PROCESSOR")
    print(f"Account: {account}")
    print("Note: Voltage invoices remain in inbox per instruction")
    print("=" * 70)
    
    # Get inbox emails
    emails = get_inbox_emails(account, max_results=40)
    if not emails:
        print("No emails found in inbox")
        return 0
    
    print(f"Found {len(emails)} emails in inbox")
    print("Processing (archiving + marking as read)...\n")
    
    # Process emails
    processed = 0
    voltage_held = 0
    failed = 0
    
    for i, email in enumerate(emails, 1):
        thread_id = email.get('threadId', '')
        subject = email.get('subject', 'Unknown')[:60]
        from_email = email.get('from', '')
        current_labels = email.get('labels', [])
        
        print(f"[{i}/{len(emails)}] {subject}...")
        print(f"  From: {from_email[:40]}...")
        
        # Check current status
        is_unread = 'UNREAD' in current_labels
        is_in_inbox = 'INBOX' in current_labels
        
        # Categorize
        label = categorize_email(subject, from_email)
        
        if label is None:
            # Voltage invoice - keep in inbox
            print(f"  ⚡ Voltage invoice - keeping in inbox (per instruction)")
            if is_unread:
                print(f"  ⚠️  Note: Still UNREAD - consider marking as read manually")
            voltage_held += 1
        else:
            # Process email
            print(f"  📍 Label: {label}")
            print(f"  📊 Status: {'UNREAD' if is_unread else 'read'}, {'in INBOX' if is_in_inbox else 'archived'}")
            
            if process_email(thread_id, label, account, mark_read=True):
                print(f"  ✅ Archived and marked as read")
                processed += 1
            else:
                print(f"  ❌ Failed to process")
                failed += 1
        
        print()
        time.sleep(0.3)
    
    # Summary
    print("=" * 70)
    print("PROCESSING SUMMARY")
    print("=" * 70)
    print(f"Total emails in inbox: {len(emails)}")
    print(f"Successfully processed: {processed}")
    print(f"  - Archived with labels")
    print(f"  - Marked as read")
    print(f"Voltage invoices held: {voltage_held}")
    print(f"Failed: {failed}")
    print(f"Remaining in inbox: {voltage_held}")
    print("=" * 70)
    
    if voltage_held > 0:
        print("\n⚠️  ACTION REQUIRED - Voltage invoices in inbox:")
        print("   - Invoice #448A39E5-0012: A$25.00 (0 days past due)")
        print("   - Consider: Payment, follow-up, or marking as read")
        print("=" * 70)
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())