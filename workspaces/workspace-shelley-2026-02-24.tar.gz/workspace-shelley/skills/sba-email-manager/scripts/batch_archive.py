#!/usr/bin/env python3
"""
Batch email archiving script for Shop Bitcoin Australia email management.
Processes multiple emails, applies labels, and archives them (removes INBOX label).
"""

import subprocess
import json
import sys
import time
from datetime import datetime

def run_gog_command(args, capture_output=True):
    """Run gog command and return result"""
    try:
        cmd = ['gog'] + args
        result = subprocess.run(cmd, capture_output=capture_output, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"❌ Command error: {e}")
        return None

def get_email_info(thread_id, account):
    """Get email information including current labels"""
    args = ['gmail', 'messages', 'search', f'thread:{thread_id}', '--max', '1', 
            '--account', account, '--json']
    result = run_gog_command(args)
    
    if not result or result.returncode != 0:
        return None
    
    try:
        data = json.loads(result.stdout)
        if data.get('messages'):
            return data['messages'][0]
    except:
        pass
    return None

def categorize_email(subject, from_email, body):
    """Categorize email based on content (simplified version)"""
    subject_lower = subject.lower()
    from_lower = from_email.lower()
    
    # Voltage invoices
    if 'voltage' in from_lower or 'invoice' in subject_lower:
        return 'REFERENCE/Accounting/Invoices'
    
    # Bankful payments
    elif 'bankful' in from_lower or 'payment received' in subject_lower:
        return 'REFERENCE/Accounting/Receipts'
    
    # Customer support - technical
    elif any(keyword in subject_lower for keyword in ['bitaxe', 'overheating', 'technical', 'issue']):
        return 'REFERENCE/Customer Support/Technical'
    
    # Customer support - general
    elif any(keyword in subject_lower for keyword in ['inquiry', 'question', 'general', 'order', 'return']):
        return 'REFERENCE/Customer Support/General'
    
    # Orders
    elif 'order' in subject_lower or 'confirmed' in subject_lower:
        return 'REFERENCE/Orders/Pending'
    
    # Security
    elif any(keyword in subject_lower for keyword in ['security', 'login', 'alert', 'verify']):
        return 'REFERENCE/Security/Logins'
    
    # Australia Post / Service Providers
    elif 'australia post' in from_lower or 'auspost' in from_lower or 'australia post' in subject_lower:
        return 'REFERENCE/Service Providers/Australia Post'
    
    # Promotional (default)
    else:
        return 'ACTION REQUIRED/FOLLOW UP'

def archive_email(thread_id, label, account):
    """Archive email by applying label and removing INBOX"""
    print(f"  Processing thread: {thread_id}")
    
    # Check current status
    email_info = get_email_info(thread_id, account)
    if not email_info:
        print(f"    ⚠️  Could not retrieve email info")
        return False
    
    current_labels = email_info.get('labels', [])
    subject = email_info.get('subject', 'Unknown')[:50]
    
    # Check if already archived
    if 'INBOX' not in current_labels:
        print(f"    ⚠️  Already archived: {subject}...")
        return True
    
    # Apply label and archive
    args = ['gmail', 'labels', 'modify', thread_id, '--add', label, 
            '--remove', 'INBOX', '--account', account]
    result = run_gog_command(args, capture_output=False)
    
    if result and result.returncode == 0:
        print(f"    ✅ Archived with label '{label}': {subject}...")
        return True
    else:
        print(f"    ❌ Failed to archive: {subject}...")
        if result:
            print(f"      Error: {result.stderr.strip()}")
        return False

def process_email_list(thread_ids, account, auto_categorize=True, default_label=None):
    """Process list of email thread IDs"""
    print("=" * 60)
    print(f"BATCH EMAIL ARCHIVING")
    print(f"Account: {account}")
    print(f"Emails to process: {len(thread_ids)}")
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    success_count = 0
    fail_count = 0
    skip_count = 0
    
    for i, thread_id in enumerate(thread_ids, 1):
        print(f"\n[{i}/{len(thread_ids)}] ", end="")
        
        # Get email info for categorization
        email_info = get_email_info(thread_id, account)
        if not email_info:
            print(f"❌ Could not retrieve email {thread_id}")
            fail_count += 1
            continue
        
        # Determine label
        if auto_categorize:
            subject = email_info.get('subject', '')
            from_email = email_info.get('from', '')
            body = email_info.get('body', '')
            label = categorize_email(subject, from_email, body)
        else:
            label = default_label or 'ACTION REQUIRED/FOLLOW UP'
        
        # Archive email
        if archive_email(thread_id, label, account):
            success_count += 1
        else:
            fail_count += 1
        
        # Small delay to avoid rate limiting
        time.sleep(0.5)
    
    # Summary
    print("\n" + "=" * 60)
    print("PROCESSING SUMMARY")
    print("=" * 60)
    print(f"Total emails: {len(thread_ids)}")
    print(f"Successfully archived: {success_count}")
    print(f"Failed: {fail_count}")
    print(f"Skipped (already archived): {skip_count}")
    
    return success_count, fail_count, skip_count

def get_threads_from_search(query, account, max_results=20):
    """Get thread IDs from search query"""
    print(f"Searching for: {query}")
    
    args = ['gmail', 'messages', 'search', query, '--max', str(max_results),
            '--account', account, '--json']
    result = run_gog_command(args)
    
    if not result or result.returncode != 0:
        print(f"❌ Search failed: {result.stderr if result else 'Unknown error'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        threads = []
        for msg in data.get('messages', []):
            thread_id = msg.get('threadId')
            if thread_id and thread_id not in threads:
                threads.append(thread_id)
        return threads
    except:
        return []

def main():
    """Main function with command line interface"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Batch archive emails for SBA')
    parser.add_argument('--account', default='service@shopbitcoin.com.au',
                       help='Email account to process')
    parser.add_argument('--query', 
                       help='Gmail search query to find emails')
    parser.add_argument('--threads', nargs='+',
                       help='List of thread IDs to process')
    parser.add_argument('--label',
                       help='Specific label to apply (overrides auto-categorization)')
    parser.add_argument('--max', type=int, default=20,
                       help='Maximum number of emails to process')
    parser.add_argument('--dry-run', action='store_true',
                       help='Show what would be done without actually doing it')
    
    args = parser.parse_args()
    
    # Get thread IDs
    thread_ids = []
    if args.threads:
        thread_ids = args.threads
    elif args.query:
        thread_ids = get_threads_from_search(args.query, args.account, args.max)
    else:
        print("❌ Please provide either --query or --threads")
        return 1
    
    if not thread_ids:
        print("❌ No emails found to process")
        return 1
    
    if args.dry_run:
        print("\nDRY RUN - Would process these threads:")
        for thread_id in thread_ids:
            email_info = get_email_info(thread_id, args.account)
            if email_info:
                subject = email_info.get('subject', 'Unknown')[:60]
                labels = email_info.get('labels', [])
                status = "IN INBOX" if 'INBOX' in labels else "ALREADY ARCHIVED"
                label = args.label or categorize_email(
                    email_info.get('subject', ''),
                    email_info.get('from', ''),
                    email_info.get('body', '')
                )
                print(f"  {thread_id}: {subject}...")
                print(f"    Status: {status}")
                print(f"    Label: {label}")
        return 0
    
    # Process emails
    auto_categorize = not args.label
    success, fail, skip = process_email_list(
        thread_ids, 
        args.account, 
        auto_categorize=auto_categorize,
        default_label=args.label
    )
    
    return 0 if fail == 0 else 1

if __name__ == "__main__":
    sys.exit(main())