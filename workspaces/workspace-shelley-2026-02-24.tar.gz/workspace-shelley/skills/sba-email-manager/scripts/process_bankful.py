#!/usr/bin/env python3
"""
Process Bankful payment emails - Archive and mark as read
"""

import subprocess
import json
import sys

def run_gog(args):
    """Run gog command"""
    cmd = ['gog'] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_bankful_emails(account):
    """Get Bankful payment emails from inbox"""
    args = ['gmail', 'messages', 'search', 'in:inbox from:no-reply@bankful.com',
            '--max', '20', '--account', account, '--json']
    result = run_gog(args)
    
    if not result or result.returncode != 0:
        print(f"Failed to get Bankful emails: {result.stderr if result else 'Unknown'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        return data.get('messages', [])
    except:
        return []

def process_bankful_email(thread_id, account):
    """Process a Bankful email: label, archive, and mark as read"""
    # Add receipt label, remove INBOX and UNREAD
    args = ['gmail', 'labels', 'modify', thread_id,
            '--add', 'REFERENCE/Accounting/Receipts',
            '--remove', 'INBOX,UNREAD',
            '--account', account]
    result = run_gog(args)
    return result and result.returncode == 0

def main():
    account = 'service@shopbitcoin.com.au'
    
    print("=" * 60)
    print("PROCESSING BANKFUL PAYMENT EMAILS")
    print(f"Account: {account}")
    print("Action: Archive + Mark as read")
    print("=" * 60)
    
    # Get Bankful emails
    emails = get_bankful_emails(account)
    if not emails:
        print("No Bankful payment emails found in inbox")
        return 0
    
    print(f"Found {len(emails)} Bankful payment emails in inbox")
    print("\nProcessing...")
    
    # Process each email
    processed = 0
    failed = 0
    
    for i, email in enumerate(emails, 1):
        thread_id = email.get('threadId', '')
        subject = email.get('subject', 'Unknown')[:70]
        
        print(f"\n[{i}/{len(emails)}] {subject}")
        
        if process_bankful_email(thread_id, account):
            print(f"  ✅ Archived and marked as read")
            processed += 1
        else:
            print(f"  ❌ Failed to process")
            failed += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Bankful emails found: {len(emails)}")
    print(f"Successfully processed: {processed}")
    print(f"Failed: {failed}")
    
    if processed > 0:
        print(f"\n✅ {processed} payment receipts archived and marked as read")
        print("   - Accessible via label: REFERENCE/Accounting/Receipts")
        print("   - Removed from INBOX (archived)")
        print("   - Marked as read (UNREAD label removed)")
    
    print("=" * 60)
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())