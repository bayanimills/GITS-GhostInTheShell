#!/usr/bin/env python3
"""
Update Australia Post emails to use new hierarchical label
"""

import subprocess
import json
import sys

def run_gog(args):
    """Run gog command"""
    cmd = ['gog'] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_australia_post_emails(account):
    """Get all Australia Post emails"""
    args = ['gmail', 'messages', 'search', 'from:australia post OR from:auspost OR subject:"Australia Post"',
            '--max', '50', '--account', account, '--json']
    result = run_gog(args)
    
    if not result or result.returncode != 0:
        print(f"Failed to get Australia Post emails: {result.stderr if result else 'Unknown'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        return data.get('messages', [])
    except:
        return []

def update_email_labels(thread_id, account):
    """Update labels for an Australia Post email"""
    # Add new hierarchical label, remove old flat label
    args = ['gmail', 'labels', 'modify', thread_id,
            '--add', 'REFERENCE/Service Providers/Australia Post',
            '--remove', 'Australia Post',  # Remove old flat label if exists
            '--account', account]
    result = run_gog(args)
    return result and result.returncode == 0

def main():
    account = 'service@shopbitcoin.com.au'
    
    print("=" * 60)
    print("AUSTRALIA POST LABEL MIGRATION")
    print(f"Account: {account}")
    print("Action: Apply hierarchical label, remove old flat label")
    print("=" * 60)
    
    # Get Australia Post emails
    emails = get_australia_post_emails(account)
    if not emails:
        print("No Australia Post emails found")
        return 0
    
    print(f"Found {len(emails)} Australia Post emails")
    print("\nProcessing...")
    
    # Process each email
    processed = 0
    failed = 0
    
    for i, email in enumerate(emails, 1):
        thread_id = email.get('threadId', '')
        subject = email.get('subject', 'Unknown')[:70]
        current_labels = email.get('labels', [])
        
        print(f"\n[{i}/{len(emails)}] {subject}")
        print(f"  Current labels: {current_labels}")
        
        # Check if already has new label
        if 'REFERENCE/Service Providers/Australia Post' in current_labels:
            print(f"  ✅ Already has new hierarchical label")
            # Still check if old label exists and remove it
            if 'Australia Post' in current_labels:
                print(f"  ⚠️  Has old label - removing...")
                args = ['gmail', 'labels', 'modify', thread_id,
                        '--remove', 'Australia Post',
                        '--account', account]
                result = run_gog(args)
                if result and result.returncode == 0:
                    print(f"  ✅ Removed old label")
                else:
                    print(f"  ❌ Failed to remove old label")
            processed += 1
        else:
            # Apply new label, remove old
            if update_email_labels(thread_id, account):
                print(f"  ✅ Applied new label, removed old label")
                processed += 1
            else:
                print(f"  ❌ Failed to update labels")
                failed += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Australia Post emails found: {len(emails)}")
    print(f"Successfully processed: {processed}")
    print(f"Failed: {failed}")
    
    if processed > 0:
        print(f"\n✅ {processed} emails now labeled: REFERENCE/Service Providers/Australia Post")
        print("   - Old 'Australia Post' label removed where present")
        print("   - Emails remain in current location (INBOX/archived)")
        print("\nNote: Delivery notifications can be archived.")
        print("      Customer service cases may need attention.")
    
    print("=" * 60)
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())