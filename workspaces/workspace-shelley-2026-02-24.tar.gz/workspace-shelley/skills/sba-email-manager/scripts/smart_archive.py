#!/usr/bin/env python3
"""
Smart archive script - Processes inbox emails with intelligent categorization
"""

import subprocess
import json
import sys
import time

def run_gog(args):
    """Run gog command"""
    cmd = ['gog'] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_inbox_emails(account, max_results=20):
    """Get emails currently in inbox"""
    args = ['gmail', 'messages', 'search', 'in:inbox', '--max', str(max_results),
            '--account', account, '--json']
    result = run_gog(args)
    
    if not result or result.returncode != 0:
        print(f"Failed to get inbox emails: {result.stderr if result else 'Unknown'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        return data.get('messages', [])
    except:
        return []

def categorize_email(subject, from_email, body):
    """Categorize email based on content"""
    subject_lower = subject.lower()
    from_lower = from_email.lower()
    
    # Voltage invoices (keep in inbox per instruction)
    if 'voltage' in from_lower:
        return None  # Don't archive - keep in inbox
    
    # Bankful payments
    elif 'bankful' in from_lower or 'payment received' in subject_lower:
        return 'REFERENCE/Accounting/Receipts'
    
    # Customer support - technical
    elif any(keyword in subject_lower for keyword in ['bitaxe', 'overheating', 'technical', 'issue']):
        return 'REFERENCE/Customer Support/Technical'
    
    # Customer support - general
    elif any(keyword in subject_lower for keyword in ['inquiry', 'question', 'general', 'order', 'return', 'refund']):
        return 'REFERENCE/Customer Support/General'
    
    # Orders
    elif 'order' in subject_lower or 'confirmed' in subject_lower or 'shipment' in subject_lower:
        return 'REFERENCE/Orders/Pending'
    
    # Security
    elif any(keyword in subject_lower for keyword in ['security', 'login', 'alert', 'verify']):
        return 'REFERENCE/Security/Logins'
    
    # Shopify/business
    elif 'shopify' in from_lower or 'shopify' in subject_lower:
        return 'REFERENCE/Business/Shopify'
    
    # Australia Post / Service Providers
    elif 'australia post' in from_lower or 'auspost' in from_lower or 'australia post' in subject_lower:
        return 'REFERENCE/Service Providers/Australia Post'
    
    # Invoices (non-Voltage)
    elif 'invoice' in subject_lower or 'tax invoice' in subject_lower:
        return 'REFERENCE/Accounting/Invoices'
    
    # Promotional (default)
    else:
        return 'ACTION REQUIRED/FOLLOW UP'

def archive_email(thread_id, label, account):
    """Archive email by applying label and removing INBOX"""
    args = ['gmail', 'labels', 'modify', thread_id, '--add', label,
            '--remove', 'INBOX', '--account', account]
    result = run_gog(args)
    
    if result and result.returncode == 0:
        return True
    return False

def main():
    account = 'service@shopbitcoin.com.au'
    
    print("=" * 60)
    print("SMART INBOX ARCHIVING")
    print(f"Account: {account}")
    print("=" * 60)
    
    # Get inbox emails
    emails = get_inbox_emails(account, max_results=30)
    if not emails:
        print("No emails found in inbox")
        return 0
    
    print(f"Found {len(emails)} emails in inbox")
    print("Processing...\n")
    
    # Categorize and process
    processed = 0
    skipped = 0
    failed = 0
    voltage_held = 0
    
    for i, email in enumerate(emails, 1):
        thread_id = email.get('threadId', '')
        subject = email.get('subject', 'Unknown')[:60]
        from_email = email.get('from', '')
        
        print(f"[{i}/{len(emails)}] {subject}...")
        
        # Categorize
        label = categorize_email(subject, from_email, "")
        
        if label is None:
            # Voltage invoice - keep in inbox
            print(f"  ⚡ Voltage invoice - keeping in inbox (per instruction)")
            voltage_held += 1
            skipped += 1
        else:
            # Archive with label
            print(f"  📍 Label: {label}")
            if archive_email(thread_id, label, account):
                print(f"  ✅ Archived")
                processed += 1
            else:
                print(f"  ❌ Failed to archive")
                failed += 1
        
        # Small delay
        time.sleep(0.3)
        print()
    
    # Summary
    print("=" * 60)
    print("PROCESSING SUMMARY")
    print("=" * 60)
    print(f"Total emails in inbox: {len(emails)}")
    print(f"Successfully archived: {processed}")
    print(f"Voltage invoices held: {voltage_held}")
    print(f"Skipped/failed: {skipped - voltage_held + failed}")
    print(f"Remaining in inbox: {voltage_held}")
    print("=" * 60)
    
    if voltage_held > 0:
        print("\n⚠️  Voltage invoices remain in inbox (per instruction):")
        print("   - Invoice #448A39E5-0012: A$25.00 (0 days past due)")
        print("   - Action required: Payment or follow-up needed")
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())