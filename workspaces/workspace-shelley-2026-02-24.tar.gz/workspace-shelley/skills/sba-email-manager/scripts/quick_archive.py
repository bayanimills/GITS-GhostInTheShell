#!/usr/bin/env python3
"""
Quick archive script - Simple version that works with message/thread IDs from gog output
"""

import subprocess
import sys

def archive_email(email_id, label, account):
    """Archive a single email by ID"""
    print(f"Archiving {email_id} with label '{label}'...")
    
    cmd = ['gog', 'gmail', 'labels', 'modify', email_id, 
           '--add', label, '--remove', 'INBOX', '--account', account]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode == 0:
        print(f"✅ Success: {email_id}")
        return True
    else:
        print(f"❌ Failed: {email_id} - {result.stderr.strip()}")
        return False

def main():
    # Remaining emails in inbox (excluding Voltage invoices)
    emails_to_archive = [
        # Format: (email_id, label)
        ('19c3ee3af4f7d5af', 'ACTION REQUIRED/FOLLOW UP'),  # EVT Stays promotional
        ('19c3cab9461da10a', 'REFERENCE/Accounting/Receipts'),  # Bankful payment
        ('19c36e7c97fd5ce7', 'ACTION REQUIRED/FOLLOW UP'),  # Google Business Profile
        ('19c35af4d4b5db8e', 'ACTION REQUIRED/FOLLOW UP'),  # Jamo Lea promotional
        ('19c357d00a961d2f', 'ACTION REQUIRED/FOLLOW UP'),  # Australia Post survey
        ('19c32d83d6b7efd6', 'REFERENCE/Accounting/Receipts'),  # Bankful payment
        ('19c32c900dcf861c', 'REFERENCE/Accounting/Receipts'),  # Bankful payment
    ]
    
    account = 'service@shopbitcoin.com.au'
    
    print("=" * 60)
    print("QUICK ARCHIVE - Remaining Inbox Emails")
    print("=" * 60)
    print(f"Emails to archive: {len(emails_to_archive)}")
    print("Voltage invoices (3) will remain in inbox per instruction")
    print("=" * 60)
    
    success = 0
    fail = 0
    
    for email_id, label in emails_to_archive:
        if archive_email(email_id, label, account):
            success += 1
        else:
            fail += 1
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Successfully archived: {success}")
    print(f"Failed: {fail}")
    print(f"Remaining in inbox: 3 (Voltage invoices)")
    print("=" * 60)
    
    return 0 if fail == 0 else 1

if __name__ == "__main__":
    sys.exit(main())