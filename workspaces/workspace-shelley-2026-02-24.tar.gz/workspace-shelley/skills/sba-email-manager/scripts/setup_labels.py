#!/usr/bin/env python3
"""
Setup email labels for Shop Bitcoin Australia email management.
Run this once to create the label structure.
"""

import subprocess
import sys

def run_gog_command(args):
    """Run gog command and return success status"""
    try:
        cmd = ['gog', 'gmail', 'labels', 'create', args, '--account', 'service@shopbitcoin.com.au']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            print(f"✅ Created: {args}")
            return True
        else:
            # Label might already exist
            if "already exists" in result.stderr.lower():
                print(f"⚠️  Already exists: {args}")
                return True
            else:
                print(f"❌ Failed: {args} - {result.stderr.strip()}")
                return False
    except Exception as e:
        print(f"❌ Error: {args} - {str(e)}")
        return False

def main():
    print("=" * 60)
    print("SBA Email Manager - Label Setup")
    print("=" * 60)
    
    labels = [
        # ACTION REQUIRED hierarchy
        "ACTION REQUIRED",
        "ACTION REQUIRED/URGENT",
        "ACTION REQUIRED/THIS WEEK",
        "ACTION REQUIRED/FOLLOW UP",
        
        # REFERENCE hierarchy
        "REFERENCE",
        "REFERENCE/Accounting",
        "REFERENCE/Accounting/Invoices",
        "REFERENCE/Accounting/Receipts",
        "REFERENCE/Orders",
        "REFERENCE/Orders/Pending",
        "REFERENCE/Customer Support",
        "REFERENCE/Customer Support/Technical",
        "REFERENCE/Customer Support/General",
        "REFERENCE/Security",
        "REFERENCE/Security/Logins",
        
        # Automation tracking
        "Shelley-Processed",
    ]
    
    success_count = 0
    total_count = len(labels)
    
    print(f"\nCreating {total_count} labels...\n")
    
    for label in labels:
        if run_gog_command(label):
            success_count += 1
    
    print(f"\n" + "=" * 60)
    print(f"Setup Complete: {success_count}/{total_count} labels created")
    
    if success_count == total_count:
        print("✅ All labels created successfully!")
    else:
        print(f"⚠️  {total_count - success_count} labels failed to create")
        print("Some labels may already exist or there may be authentication issues.")
    
    print("\nNext steps:")
    print("1. Run 'python3 scripts/categorize_emails.py' to test categorization")
    print("2. Run './scripts/process_emails.sh' for complete workflow")
    print("3. Set up cron jobs for 8am and 1pm checks")
    
    return 0 if success_count > 0 else 1

if __name__ == "__main__":
    sys.exit(main())