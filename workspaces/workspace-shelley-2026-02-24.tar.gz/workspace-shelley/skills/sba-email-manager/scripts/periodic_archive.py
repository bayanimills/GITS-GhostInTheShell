#!/usr/bin/env python3
"""
Periodic archiving script for Shop Bitcoin Australia email management.
Archives emails with REFERENCE labels that are still in INBOX.
Adds "Shelley-Processed" label to track archived emails.
"""

import subprocess
import json
import sys
import time
from datetime import datetime

def run_gog(args):
    """Run gog command"""
    cmd = ['gog'] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_inbox_emails_with_labels(account, max_results=50):
    """Get emails in INBOX with their current labels"""
    args = ['gmail', 'messages', 'search', 'in:inbox', '--max', str(max_results),
            '--account', account, '--json']
    result = run_gog(args)
    
    if not result or result.returncode != 0:
        print(f"Failed to get inbox emails: {result.stderr if result else 'Unknown'}")
        return []
    
    try:
        data = json.loads(result.stdout)
        emails = data.get('messages', [])
        
        # Get label info for each email
        for email in emails:
            thread_id = email.get('threadId')
            if thread_id:
                # Get thread labels
                label_args = ['gmail', 'thread', 'get', thread_id, 
                             '--account', account, '--json']
                label_result = run_gog(label_args)
                if label_result and label_result.returncode == 0:
                    try:
                        thread_data = json.loads(label_result.stdout)
                        email['labels'] = thread_data.get('labels', [])
                    except:
                        email['labels'] = []
        return emails
    except Exception as e:
        print(f"Error parsing email data: {e}")
        return []

def should_archive_email(labels):
    """Determine if email should be archived based on labels"""
    if not labels:
        return False
    
    # Check if already has Shelley-Processed label
    if any('Shelley-Processed' in label.get('name', '') for label in labels):
        return False
    
    # Check for REFERENCE labels that should be archived
    ref_labels_to_archive = [
        'REFERENCE/Accounting/Receipts',
        'REFERENCE/Service Providers/Australia Post',
        'REFERENCE/Customer Support/Technical',
        'REFERENCE/Customer Support/General',
        'REFERENCE/Security/Logins'
    ]
    
    # Check if email has any REFERENCE label
    for label in labels:
        label_name = label.get('name', '')
        
        # Archive emails with "Saved in Nextcloud by Shelley" label
        if 'Saved in Nextcloud by Shelley' in label_name:
            return True
            
        if label_name in ref_labels_to_archive:
            return True
        # Also check partial matches for hierarchical labels
        if label_name.startswith('REFERENCE/') and 'Invoices' not in label_name:
            # Archive REFERENCE emails except Invoices (which need payment decisions)
            return True
    
    return False

def archive_thread(thread_id, account):
    """Archive thread by removing INBOX label and adding Shelley-Processed"""
    print(f"  Archiving thread: {thread_id}")
    
    # Remove INBOX label (archive)
    archive_args = ['gmail', 'messages', 'modify', thread_id,
                   '--remove-label', 'INBOX',
                   '--account', account]
    archive_result = run_gog(archive_args)
    
    if not archive_result or archive_result.returncode != 0:
        print(f"    ❌ Failed to archive: {archive_result.stderr if archive_result else 'Unknown'}")
        return False
    
    # Add Shelley-Processed label
    label_args = ['gmail', 'messages', 'modify', thread_id,
                 '--add-label', 'Shelley-Processed',
                 '--account', account]
    label_result = run_gog(label_args)
    
    if not label_result or label_result.returncode != 0:
        print(f"    ⚠️  Archived but failed to add Shelley-Processed label: {label_result.stderr if label_result else 'Unknown'}")
        return True  # Still consider it a success
    
    print(f"    ✅ Successfully archived and labeled")
    return True

def main():
    account = "service@shopbitcoin.com.au"
    max_emails = 100  # Process up to 100 emails per run
    
    print("=" * 60)
    print("SBA EMAIL PERIODIC ARCHIVING")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Account: {account}")
    print("=" * 60)
    
    # Get emails in INBOX
    print(f"\nFetching emails from INBOX (max {max_emails})...")
    emails = get_inbox_emails_with_labels(account, max_emails)
    
    if not emails:
        print("No emails found in INBOX.")
        return 0
    
    print(f"Found {len(emails)} emails in INBOX.")
    
    # Filter emails that should be archived
    to_archive = []
    for email in emails:
        thread_id = email.get('threadId')
        labels = email.get('labels', [])
        
        if should_archive_email(labels):
            to_archive.append({
                'thread_id': thread_id,
                'subject': email.get('subject', 'No subject'),
                'from': email.get('from', 'Unknown'),
                'labels': [l.get('name', '') for l in labels]
            })
    
    if not to_archive:
        print("\nNo emails eligible for archiving.")
        print("Eligibility criteria:")
        print("- Has REFERENCE label (except Invoices)")
        print("- Does NOT have Shelley-Processed label")
        print("- Does NOT have ACTION REQUIRED label (kept in INBOX)")
        return 0
    
    print(f"\n{len(to_archive)} emails eligible for archiving:")
    for i, email in enumerate(to_archive, 1):
        print(f"  {i}. {email['subject'][:60]}...")
        print(f"     From: {email['from']}")
        print(f"     Labels: {', '.join(email['labels'])}")
    
    print(f"\nProceeding with archiving...")
    
    success_count = 0
    fail_count = 0
    
    for email in to_archive:
        if archive_thread(email['thread_id'], account):
            success_count += 1
        else:
            fail_count += 1
        time.sleep(0.5)  # Rate limiting
    
    print(f"\n" + "=" * 60)
    print(f"ARCHIVING COMPLETE")
    print(f"  Successfully archived: {success_count}")
    print(f"  Failed: {fail_count}")
    
    if success_count > 0:
        print(f"\nSummary:")
        print(f"- Emails archived and removed from INBOX")
        print(f"- 'Shelley-Processed' label added for tracking")
        print(f"- REFERENCE emails preserved via labels for searching")
        print(f"- ACTION REQUIRED emails remain in INBOX for attention")
    
    return 0 if fail_count == 0 else 1

if __name__ == "__main__":
    sys.exit(main())