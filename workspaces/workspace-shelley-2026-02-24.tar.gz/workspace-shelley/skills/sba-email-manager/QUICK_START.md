# SBA Email Manager - Quick Start

## Installation
1. Ensure `gog` CLI is installed and authenticated for `service@shopbitcoin.com.au`
2. Copy skill folder to OpenClaw skills directory
3. Skill will auto-trigger when email management tasks are detected

## First-Time Setup
```bash
# Make scripts executable
chmod +x scripts/*.sh

# Create email labels
python3 scripts/setup_labels.py

# Test categorization
python3 scripts/categorize_emails.py

# Run complete workflow
./scripts/process_emails.sh
```

## Daily Use
### Morning Check (8am AEST)
```bash
./scripts/process_emails.sh
```
- Reviews overnight emails
- Flags urgent items
- Generates action report

### Afternoon Check (1pm AEST)
```bash
./scripts/process_emails.sh
```
- Checks for new urgent emails
- Follows up on morning items
- Updates categorization

## Common Tasks
### Check Urgent Emails
```bash
gog gmail search "overheating OR urgent OR emergency OR \"past due\"" --account service@shopbitcoin.com.au
```

### Categorize Specific Email
```bash
python3 scripts/categorize_emails.py
```

### View Current Categories
Check latest log file in `logs/` directory

## Cron Job Setup
Create cron jobs for automated checks:
- 8:00 AM AEST: Morning email review
- 1:00 PM AEST: Afternoon follow-up

## Troubleshooting
### Authentication Issues
```bash
gog auth list
# Should show service@shopbitcoin.com.au with gmail access
```

### Label Creation Errors
Run setup script again:
```bash
python3 scripts/setup_labels.py
```

### Script Permission Issues
```bash
chmod +x scripts/*.sh
```

## Skill Integration
The skill automatically triggers when:
- User mentions "email check" or "inbox zero"
- Task involves `service@shopbitcoin.com.au`
- Customer support email management needed
- Urgent email processing required

## Support
- Refer to SKILL.md for detailed instructions
- Check references/ for guidelines and templates
- Use assets/ for response templates
- Contact: Shelley (SBA Manager)