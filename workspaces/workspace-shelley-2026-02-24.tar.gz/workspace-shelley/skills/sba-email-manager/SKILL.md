---
name: sba-email-manager
description: Manage Shop Bitcoin Australia email operations for service@shopbitcoin.com.au. Use when checking, categorizing, or processing business emails; setting up email automation and filters; drafting customer support responses; achieving Inbox Zero for SBA business email; monitoring urgent customer issues like BitAxe overheating, technical support, or orders. Requires gog CLI with OAuth access to service@shopbitcoin.com.au.
---

# SBA Email Manager Skill

Comprehensive email management system for Shop Bitcoin Australia business operations. Provides automated email checking, categorization, processing workflows, and customer support response drafting.

## Quick Start

### Prerequisites
- gog CLI installed and authenticated for `service@shopbitcoin.com.au`
- OAuth access with Gmail permissions

### Basic Commands

**Check unread emails:**
```bash
gog gmail search "in:inbox is:unread" --account service@shopbitcoin.com.au --max 20
```

**Categorize emails:**
```bash
python3 scripts/categorize_emails.py
```

**Process emails (full workflow):**
```bash
./scripts/process_emails.sh
```

## Email Label Structure

The skill uses a standardized label hierarchy:

```
📁 ACTION REQUIRED/
   ├── ⚠️ URGENT (24h response)
   ├── ⏰ THIS WEEK (7 days)
   └── 📅 FOLLOW UP (30 days)

📁 REFERENCE/
   ├── 💰 Accounting/
   │   ├── Invoices (Voltage, Shopify)
   │   └── Receipts (Bankful payments)
   ├── 🛒 Orders/
   │   └── Pending
   ├── 🤝 Customer Support/
   │   ├── Technical (BitAxe, miners)
   │   └── General (inquiries)
   └── 🔐 Security/
       └── Logins
   ├── 📮 Service Providers/
   │   └── Australia Post
```

Labels are automatically created on first run.

## Workflows

### Daily Email Check (8am & 1pm AEST)
1. Run `process_emails.sh` to categorize and generate reports
2. Review action items in generated logs
3. Process urgent items first (invoices, customer support)
4. Archive or respond to categorized emails

### Customer Support Response
1. Identify customer issue type (technical, general, order)
2. Use appropriate template from `templates/`
3. Draft response for approval (do not send automatically)
4. Apply appropriate label after response

### Inbox Zero Maintenance
1. Process all unread emails daily
2. Apply correct labels immediately
3. Archive completed threads quarterly
4. Review and optimize filters monthly

## Scripts

### `scripts/categorize_emails.py`
Automatically categorizes unread emails based on content analysis. Looks for keywords:
- **Technical support**: `bitaxe`, `overheating`, `faulty`, `module`, `technical`, `issue`
- **General inquiries**: `inquiry`, `question`, `general`, `ask`, `help`
- **Orders**: `order`, `payment`, `receipt`, `refund`, `ship`
- **Invoices**: `voltage`, `invoice`, `past due`
- **Security**: `login`, `security`, `alert`, `verify`

### `scripts/process_emails.sh`
Complete email processing workflow:
1. Categorizes all unread emails
2. Checks for urgent items
3. Generates action items report
4. Saves timestamped logs

### `scripts/daily_email_check.sh`
Simplified check for cron jobs. Returns counts and urgent status.

## Templates

Response templates are stored in `templates/`:

- `bitaxe_overheating.md` - Technical support for BitAxe issues
- `general_inquiry.md` - General customer questions
- `order_confirmation.md` - Order status updates
- `invoice_payment.md` - Billing inquiries

**Important:** Always draft responses for approval before sending.

## Configuration

### Email Accounts
The skill focuses exclusively on `service@shopbitcoin.com.au`. Do not modify `bayanimills@gmail.com` labels or folders. Forward relevant emails from personal account when necessary.

### Automated Scheduling
Set up cron jobs for:
- **8:00 AM AEST** - Morning email check
- **1:00 PM AEST** - Afternoon email check

Example cron job:
```json
{
  "name": "Daily 8am Email Check",
  "schedule": {"kind": "cron", "expr": "0 8 * * *", "tz": "Australia/Sydney"},
  "payload": {"kind": "agentTurn", "message": "Run SBA email check and report urgent issues."},
  "sessionTarget": "isolated",
  "delivery": {"mode": "announce"}
}
```

### Periodic Archiving System (New)
Implements **periodic archiving** per user preference (not immediate). Daily at 11:00 PM AEST, emails with REFERENCE labels are archived automatically.

**Key features:**
  - **Archives**: REFERENCE emails (except Invoices needing payment decisions)
  - **Preserves**: ACTION REQUIRED emails remain in INBOX for attention
  - **Tracks**: Adds "Shelley-Processed" label after archiving
  - **Respects**: "Saved in Nextcloud by Shelley" emails also archived

**Script:** `scripts/periodic_archive.py`

**Cron job:** Daily at 23:00 AEST
```json
{
  "name": "SBA Email Periodic Archiving",
  "schedule": {"kind": "cron", "expr": "0 23 * * *", "tz": "Australia/Sydney"},
  "payload": {"kind": "agentTurn", "message": "Run SBA email periodic archiving script"},
  "sessionTarget": "isolated",
  "delivery": {"mode": "announce"}
}
```

**Workflow:**
1. **Daily 8am/1pm checks**: Categorize and label emails
2. **Daily 11pm archiving**: Archive REFERENCE-labeled emails
3. **Weekly review**: Check for missed items or exceptions

## Common Tasks

### 1. Check for Urgent Emails
```bash
# Look for urgent keywords
gog gmail search "overheating OR urgent OR emergency OR \"past due\"" --account service@shopbitcoin.com.au
```

### 2. Process Customer Support
1. Identify issue type (technical/general)
2. Draft response using appropriate template
3. Wait for approval before sending
4. Apply `REFERENCE/Customer Support/[Technical|General]` label

### 3. Handle Invoices
1. Check for Voltage invoices (`from:voltage.cloud`)
2. Process payment or verification
3. Apply `REFERENCE/Accounting/Invoices` label
4. Archive after payment

### 4. Monitor Orders
1. Check Bankful payments (`from:bankful.com`)
2. Verify order fulfillment
3. Apply `REFERENCE/Orders/Pending` label
4. Update to completed when shipped

## Best Practices

### Email Hygiene
- **Process daily**: Don't let emails accumulate
- **Label immediately**: Apply correct labels during first read
- **Archive quarterly**: Move old emails to yearly folders
- **Unsubscribe**: Remove from promotional lists

### Customer Support
- **Response time**: Aim for <24h for urgent, <48h for general
- **Professional tone**: Maintain SBA brand voice
- **Technical accuracy**: Verify product details before responding
- **Follow up**: Check if issues are resolved

### Security
- **Monitor logins**: Check `REFERENCE/Security/Logins` regularly
- **Verify alerts**: Investigate security notifications promptly
- **No auto-send**: Always get approval for sensitive responses

## Troubleshooting

### gog Authentication Issues
```bash
# Check auth status
gog auth list

# Add account if missing
gog auth add service@shopbitcoin.com.au --services gmail
```

### Label Creation Errors
Labels are created automatically. If missing, run:
```bash
# Create core labels
gog gmail labels create "ACTION REQUIRED" --account service@shopbitcoin.com.au
gog gmail labels create "REFERENCE" --account service@shopbitcoin.com.au
```

### Script Permission Issues
```bash
# Make scripts executable
chmod +x scripts/*.sh
```

## References

See `references/` directory for:
- `email_categories.md` - Detailed categorization rules
- `response_guidelines.md` - Customer support standards
- `sba_brand_voice.md` - Brand communication guidelines

## Notes

- **Autonomy level**: Technical processing allowed, customer responses require approval
- **Focus account**: `service@shopbitcoin.com.au` only
- **Personal account**: Forward relevant emails, do not modify labels
- **Urgent flags**: `overheating`, `emergency`, `past due`, `security alert`
- **Daily routine**: 8am & 1pm checks minimum