---
name: sba-social-media
description: 'Comprehensive social media automation for Shop Bitcoin Australia. Use when: (1) Managing daily social media posts for @ShopBitcoinAus, (2) Scheduling content via Make.com/Buffer integration, (3) Implementing approval workflows for content review, (4) Tracking engagement metrics, (5) Managing content rotation across 5 categories (educational, technical, community, event, product), (6) Configuring webhook integrations with Make.com, (7) Monitoring Twitter feed engagement, (8) Creating and managing draft content library. Specifically for Shop Bitcoin Australia brand voice: Bitcoin-only, Australian ecosystem focus, beginner-friendly yet technically accurate.'
---

# Shop Bitcoin Australia Social Media Automation

## Overview

This skill provides complete social media management automation for Shop Bitcoin Australia, including daily post rotation, Make.com/Buffer integration, approval workflows, engagement tracking, and content management. The system operates with a daily approval model: present draft at 15:00 AEST, get user approval/changes, then schedule via webhook.

## Core Capabilities

### 1. Daily Post Rotation System
- **5 Content Categories:** Educational, Technical, Community, Event, Product
- **Automatic Rotation:** Cycles through categories daily (`daily_post_state.json`)
- **State Management:** Tracks current position, resumes after interruptions
- **Draft Library:** 5 pre-written drafts for immediate use

### 2. Make.com/Buffer Integration
- **Webhook Configuration:** Single webhook URL for all scheduling
- **Payload Format:** Buffer-compatible format (`profile_ids`, `text`, `scheduled_at`)
- **Reliable Delivery:** Proven "message" field format for Make.com scenarios
- **Testing Utilities:** Webhook validation and troubleshooting scripts

### 3. Approval Workflow
- **Daily Schedule:** 15:00 AEST (05:00 UTC) trigger for draft presentation
- **User Interaction:** Present draft, request approval or changes
- **Flexible Handling:** Skip, modify, or approve with customizations
- **Execution:** Send approved post via webhook with proper scheduling

### 4. Engagement Tracking
- **CSV Logging:** Records all posts with timestamps, categories, engagement data
- **Performance Monitoring:** Tracks likes, retweets, replies (manual entry)
- **Analytics Ready:** Structured format for performance analysis

### 5. Content Management
- **Brand Guidelines:** Bitcoin-only, Australian focus, technical accuracy
- **Style Preferences:** No hashtags, clean line breaks, accurate product specs
- **Audience Targeting:** Beginners, experienced miners, hardware enthusiasts
- **Community Links:** OrangeLabel.io, BitcoinAlive 2026, Bitcoin Industry Body

## Quick Start Workflow

### Daily Post Execution
1. **Check Rotation State:** Read `daily_post_state.json` for next draft index
2. **Load Draft:** Use `load_draft_by_index(index)` from `payload_formatter.py`
3. **Present to User:** Show draft at 15:00 AEST with approval request
4. **Process Response:**
   - **Approve:** Send via webhook with `send_daily_post()`
   - **Modify:** Update text, then send
   - **Skip:** Advance rotation, no post today
5. **Update State:** Increment rotation, log to engagement tracking CSV
6. **Verify Delivery:** Check webhook response (200 OK = accepted)

### Configuration Management
- **Webhook URL:** Store in `webhook_config.json` or environment variable
- **Buffer Profile IDs:** Configure for @ShopBitcoinAus (Twitter/X)
- **Timezone Handling:** AEST to UTC conversion for scheduling
- **Error Handling:** Rate limiting, retry logic, failure logging

## Script Reference

### Primary Scripts (copy to `scripts/` directory)

**`send_daily_post.py`** - Main workflow execution
- **Purpose:** Send daily post with rotation management
- **Usage:** `send_daily_post(draft_index=None, draft_id=None, schedule_utc=None, approval_required=False)`
- **Dependencies:** `config.py`, `payload_formatter.py`
- **Output:** Updates rotation state, logs to engagement CSV

**`payload_formatter.py`** - Content and payload management
- **Purpose:** Load drafts, format Buffer-compatible payloads
- **Key Functions:**
  - `load_draft_by_index(index)` - Get draft by rotation position (0-4)
  - `format_buffer_payload(text, profile_ids, scheduled_at=None)` - Create webhook payload
  - `update_draft_text(draft_id, new_text)` - Modify draft content
- **Draft Storage:** JSON structure with category, text, metadata

**`config.py`** - Configuration management
- **Purpose:** Centralized configuration for webhook URLs and settings
- **Key Function:** `get_webhook_url()` - Retrieve active webhook URL
- **Environment Support:** Falls back to default if not configured

**`schedule_with_approval.py`** - Approval workflow implementation
- **Purpose:** Complete approval flow with user interaction
- **Usage:** Interactive script for daily post approval process
- **Integration:** Works with OpenClaw message system for approval requests

### Utility Scripts (optional for troubleshooting)

**`test_make_webhook.py`** - Webhook testing and validation
**`switch_webhook.py`** - Switch between webhook URLs
**`update_webhook_urls.py`** - Update configuration files
**`manual_engagement_tracker.py`** - Manual engagement data entry

## Reference Documentation

### Webhook Integration Details
See `references/make_com_integration.md` for:
- Make.com scenario configuration
- Buffer API payload format specification
- Webhook URL management and security
- Error handling and retry patterns

### Content Strategy Guidelines
See `references/content_guidelines.md` for:
- Shop Bitcoin Australia brand voice
- Product specification accuracy requirements
- Community engagement best practices
- Hashtag policy (no hashtags preference)

### Engagement Tracking System
See `references/engagement_tracking.md` for:
- CSV schema and field definitions
- Manual data entry procedures
- Performance analysis methodologies
- Reporting formats

## Configuration Files

### `webhook_config.json`
```json
{
  "make_webhook_url": "https://hook.us2.make.com/...",
  "buffer_profile_ids": ["profile_id_for_twitter"],
  "default_schedule_aest": "15:00"
}
```

### `daily_post_state.json`
```json
{
  "last_post_date": "2026-02-18",
  "next_draft_index": 1,
  "rotation_cycle": 1,
  "total_posts_sent": 1
}
```

### `engagement_data.csv`
- Columns: `date`, `draft_id`, `category`, `post_text`, `scheduled_time`, `webhook_response`, `likes`, `retweets`, `replies`, `notes`

## Common Tasks & Examples

### Task 1: Execute Daily Post Workflow
```python
# In OpenClaw agent context
# 1. Check if it's 15:00 AEST (cron-triggered)
# 2. Read rotation state
# 3. Load appropriate draft
# 4. Present to user: "Daily post draft: [text]. Approve? (1) Approve as-is (2) Edit (3) Skip"
# 5. Based on response:
#    - 1: send_daily_post(draft_index=current_index, schedule_utc=converted_time)
#    - 2: Update text, then send
#    - 3: Update rotation state, no send
# 6. Log result to engagement CSV
```

### Task 2: Manual Post Scheduling
```python
# For ad-hoc posts outside daily schedule
from scripts import send_daily_post
success, draft_id, index, response = send_daily_post.send_daily_post(
    draft_index=2,  # Technical category
    schedule_utc="2026-02-23T05:00:00Z"  # 15:00 AEST next day
)
```

### Task 3: Troubleshoot Webhook Issues
1. Run `test_make_webhook.py` to verify connectivity
2. Check `webhook_config.json` for correct URL
3. Validate Make.com scenario is active (410 vs 200 error)
4. Test with simple payload using `send_test_post.py`

## Error Handling & Recovery

### Common Issues
- **Webhook 410 Error:** Make.com scenario not active - activate in dashboard
- **Invalid Profile ID:** Buffer profile ID incorrect - verify in Buffer settings
- **Timezone Mismatch:** AEST to UTC conversion error - use `utc_from_aest()` in payload_formatter
- **Rotation State Corruption:** Reset `daily_post_state.json` to `{"next_draft_index": 0, "last_post_date": null}`

### Recovery Procedures
1. **Failed Send:** Log error, retry with exponential backoff (max 3 attempts)
2. **User No Response:** After 30 minutes, skip post for today, advance rotation
3. **Configuration Lost:** Restore from backup `webhook_config.json.bak`
4. **Script Errors:** Check Python dependencies (`requests`, `python-dateutil`)

## Integration Points

### OpenClaw Cron Jobs
- **Daily 05:00 UTC (15:00 AEST):** Trigger daily post approval workflow
- **Configuration:** Isolated session with `agentTurn` payload
- **Delivery Mode:** `announce` to Telegram for user interaction

### Email System Coordination
- **Product Launches:** Coordinate social media with product image collection
- **Event Promotion:** Sync with BitcoinAlive 2026 email campaigns
- **Customer Support:** Monitor @ShopBitcoinAus mentions for support issues

### Product Management System
- **Image Assets:** Use product images from Nextcloud collections
- **Specification Accuracy:** Verify product details before posting
- **Inventory Updates:** Mention new stock arrivals

---

**Skill Status:** ✅ ACTIVE  
**Version:** 1.0.0  
**Last Updated:** 2026-02-22  
**Maintainer:** Shelley (Shop Bitcoin Australia Manager)
