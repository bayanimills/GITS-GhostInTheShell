# Shop Bitcoin Australia - Social Media Engagement Tracking System

**Created**: 2026-02-15  
**Version**: 1.0.0  
**Status**: 🟡 IN DEVELOPMENT  
**Purpose**: Track and analyze social media post performance to optimize content strategy

## 🎯 **System Overview**

### **Objectives:**
1. Track engagement metrics for all social media posts
2. Correlate content styles with sales performance  
3. Identify optimal posting times for Australian audience
4. Develop data-driven content strategy
5. Enable continuous improvement through A/B testing

### **Data Sources:**
1. **Twitter API** (via Bearer Token) - Post metrics
2. **Website Analytics** - Traffic and conversion data
3. **Buffer API** - Scheduling and publication data
4. **Manual Input** - Sales correlation data

### **Tracking Scope:**
- **Platform**: Twitter (primary), potentially expandable
- **Metrics**: Likes, retweets, replies, impressions, clicks
- **Timeframe**: 48-hour post-publication window
- **Frequency**: Hourly checks for active posts

## 📊 **Data Structure**

### **Post Tracking Record:**
```json
{
  "post_id": "twitter_post_id_123",
  "batch_id": "batch_1",
  "draft_id": "draft_1",
  "content_style": "educational_beginner",
  "content_category": "product_introduction",
  "target_audience": ["beginners", "first_time_miners"],
  "post_content": "Thinking about Bitcoin mining...",
  "scheduled_time": "2026-02-16T09:00:00+10:00",
  "published_time": "2026-02-16T09:00:05+10:00",
  "media_attached": true,
  "media_type": "product_photo",
  
  "engagement_metrics": {
    "hour_1": {"likes": 5, "retweets": 2, "replies": 1, "impressions": 150},
    "hour_2": {"likes": 8, "retweets": 3, "replies": 2, "impressions": 320},
    "hour_24": {"likes": 42, "retweets": 12, "replies": 5, "impressions": 1850}
  },
  
  "calculated_metrics": {
    "total_engagement": 59,
    "engagement_rate": 3.19,
    "click_through_rate": 1.2,
    "reply_sentiment": "positive",
    "peak_engagement_hour": 2
  },
  
  "sales_correlation": {
    "website_traffic_increase": 15,
    "product_page_views": 28,
    "checkout_initiations": 3,
    "confirmed_sales": 1,
    "attribution_confidence": "medium"
  },
  
  "analysis_notes": "Strong beginner engagement, good educational value",
  "optimization_suggestions": ["More visual setup guides", "FAQ thread follow-up"]
}
```

### **Batch Performance Summary:**
```json
{
  "batch_id": "batch_1",
  "batch_date": "2026-02-16",
  "total_posts": 5,
  "performance_summary": {
    "avg_engagement_rate": 2.8,
    "best_performing_style": "educational_beginner",
    "worst_performing_style": "technical_network",
    "optimal_post_time": "09:00 AEST",
    "total_impressions": 8500,
    "total_engagement": 238
  },
  "style_comparison": {
    "educational_beginner": {"engagement_rate": 3.5, "audience_reach": "broad"},
    "technical_network": {"engagement_rate": 1.8, "audience_reach": "niche"},
    "community_awareness": {"engagement_rate": 2.9, "audience_reach": "community"},
    "event_promotion": {"engagement_rate": 3.1, "audience_reach": "event_focused"},
    "product_setup": {"engagement_rate": 2.7, "audience_reach": "practical"}
  }
}
```

## 🔧 **Implementation Components**

### **1. Twitter API Integration**
```bash
# Authentication
BEARER_TOKEN="config_x_bearer_token"

# Get post metrics
curl -X GET "https://api.twitter.com/2/tweets/{post_id}?tweet.fields=public_metrics" \
  -H "Authorization: Bearer $BEARER_TOKEN"

# Get user tweets for monitoring
curl -X GET "https://api.twitter.com/2/users/{user_id}/tweets" \
  -H "Authorization: Bearer $BEARER_TOKEN"
```

### **2. Data Collection Script**
```python
# Pseudocode for engagement tracking
def collect_post_metrics(post_id, hours_since_post):
    # Call Twitter API for current metrics
    # Calculate engagement rate
    # Store in tracking database
    # Check for performance thresholds
    # Generate alerts if needed
    pass

def analyze_batch_performance(batch_id):
    # Aggregate metrics across batch
    # Compare content styles
    # Identify patterns and insights
    # Generate optimization recommendations
    pass
```

### **3. Buffer Webhook Handler**
```python
# Receive Buffer publication notifications
def handle_buffer_webhook(data):
    # Extract post details
    # Create tracking record
    # Schedule metric collection
    # Log publication event
    pass
```

### **4. Dashboard & Reporting**
- **Real-time metrics** for active posts
- **Comparative analysis** between content styles  
- **Time-based performance** heatmaps
- **Sales correlation** visualizations
- **Optimization recommendations**

## 📈 **Metrics & KPIs**

### **Primary Engagement Metrics:**
1. **Engagement Rate**: (Likes + RTs + Replies) / Impressions × 100
2. **Audience Growth**: New followers per post
3. **Content Reach**: Unique accounts reached
4. **Interaction Quality**: Meaningful conversations vs simple likes

### **Sales Correlation Metrics:**
1. **Attributed Traffic**: Website visitors from Twitter
2. **Conversion Rate**: Visitors to customers
3. **Revenue Per Post**: Estimated sales value
4. **Customer Acquisition Cost**: Marketing efficiency

### **Content Performance Metrics:**
1. **Style Effectiveness**: Engagement by content category
2. **Audience Resonance**: Response by target segment
3. **Time Optimization**: Performance by posting hour
4. **Message Clarity**: Reply sentiment analysis

## 🚀 **Deployment Phases**

### **Phase 1: Basic Tracking (Week 1)**
- [ ] Twitter API authentication testing
- [ ] Manual post ID logging system
- [ ] Hourly metric collection (cron job)
- [ ] Simple JSON database setup
- [ ] Basic performance reporting

### **Phase 2: Automated Integration (Week 2)**
- [ ] Buffer webhook integration
- [ ] Automated post ID capture
- [ ] Real-time dashboard
- [ ] Alert system for high-performing content
- [ ] Style comparison analytics

### **Phase 3: Advanced Analytics (Week 3)**
- [ ] Sales correlation tracking
- [ ] Predictive performance modeling
- [ ] Content optimization recommendations
- [ ] Audience segmentation analysis
- [ ] ROI calculation system

### **Phase 4: Full Automation (Week 4+)**
- [ ] Automated content scheduling optimization
- [ ] Dynamic content generation based on performance
- [ ] Cross-platform integration
- [ ] Machine learning for pattern recognition
- [ ] Strategic planning recommendations

## 🔒 **Security & Privacy**

### **Data Protection:**
- **API Tokens**: Securely stored in OpenClaw config
- **Customer Data**: No PII collection or storage
- **Analytics Only**: Business intelligence focus
- **Access Control**: Restricted to authorized systems

### **Compliance:**
- **Twitter Developer Policy**: Adherence to API terms
- **Data Retention**: 90-day rolling window for detailed metrics
- **Transparency**: Clear data usage documentation
- **Opt-out Capability**: System can be disabled if needed

## 📋 **Immediate Next Actions**

### **Today (2026-02-15):**
1. [ ] Test Twitter API connectivity with Bearer Token
2. [ ] Create post tracking JSON structure
3. [ ] Develop basic metric collection script
4. [ ] Set up cron job for hourly checks
5. [ ] Prepare Buffer webhook documentation

### **Tomorrow (2026-02-16):**
1. [ ] Deploy tracking for Batch 1 posts
2. [ ] Create real-time monitoring dashboard
3. [ ] Implement alert system for engagement spikes
4. [ ] Begin style comparison analysis
5. [ ] Prepare Batch 2 optimization recommendations

## 📝 **Usage Notes**

### **Starting the System:**
```bash
# 1. Verify API access
./scripts/test_twitter_api.sh

# 2. Initialize tracking database
./scripts/init_tracking_db.py

# 3. Start monitoring service
./scripts/start_monitoring.py

# 4. Check dashboard
open dashboard/index.html
```

### **Adding New Posts:**
1. Add post to `data/posts/` directory with metadata
2. System automatically detects and begins tracking
3. Metrics collected hourly for 48 hours
4. Results added to performance database

### **Generating Reports:**
```bash
# Daily performance summary
./reports/daily_summary.py

# Weekly optimization recommendations  
./reports/weekly_optimization.py

# Monthly strategy review
./reports/monthly_strategy.py
```

---

**System Status**: 🟡 DEVELOPMENT IN PROGRESS  
**Next Update**: Twitter API connectivity test  
**Deployment Target**: Batch 1 post tracking  
**Success Criteria**: Accurate engagement data collection within 24 hours