# Make.com & Buffer Integration Guide

## Overview

This document details the integration between Shop Bitcoin Australia social media automation and Make.com (formerly Integromat) with Buffer API. The system uses a single webhook to schedule posts to Buffer, which then publishes to Twitter/X (@ShopBitcoinAus).

## Architecture

```
OpenClaw Agent → Make.com Webhook → Buffer API → Twitter/X (@ShopBitcoinAus)
```

## Webhook Configuration

### Active Webhook URL
```
https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z
```

### Webhook Management
- **URL Storage:** `webhook_config.json` with metadata and history
- **Status Tracking:** Active/inactive, last success, error logs
- **Fallback Support:** Old webhook retention for rollback capability
- **Testing Utilities:** Scripts to validate connectivity and payload format

### Make.com Scenario Requirements
1. **Active Scenario:** Webhook scenario must be "Active" in Make.com dashboard
2. **HTTP Response:** Returns `200 OK` with "Accepted" body when successful
3. **Error States:**
   - `410 Gone`: Scenario not active (activate in dashboard)
   - `400 Bad Request`: Invalid payload format
   - `500 Internal Server Error`: Buffer API or Make.com issue

## Payload Formats

### Primary Format: "message" Field (Recommended)
```json
{
  "message": "Full post text here",
  "profile_ids": ["twitter_shopbitcoinaus"],
  "scheduled_at": "2026-02-23T05:00:00Z"
}
```

**Advantages:**
- Consistent processing by Make.com
- Simple structure, fewer parsing errors
- Confirmed working across multiple tests
- Easy debugging and logging

### Secondary Format: Buffer API Native
```json
{
  "profile_ids": ["twitter_shopbitcoinaus"],
  "text": "Full post text here",
  "shorten": false,
  "top": false,
  "scheduled_at": "2026-02-23T05:00:00Z",
  "media": {}
}
```

**Notes:**
- Buffer's native API format
- More complex but fully compatible
- Used as fallback if "message" field issues occur

## Configuration File (`webhook_config.json`)

### Key Fields
```json
{
  "webhook_url": "https://hook.us2.make.com/...",
  "webhook_id": "...",
  "status": "active_operational",
  "payload_format": "message_field",
  "profile_ids": ["twitter_shopbitcoinaus"],
  "daily_post_workflow": {
    "active": true,
    "time_aest": "15:00",
    "time_utc": "05:00",
    "cron_expr": "0 5 * * *",
    "approval_required": true,
    "draft_rotation": true
  }
}
```

### Status Tracking
- `active_operational`: Webhook working, last success < 24h
- `active_untested`: Configured but not recently tested
- `inactive_410`: Scenario not active (requires dashboard activation)
- `error_4xx`: Client error (check payload format)
- `error_5xx`: Server error (Buffer or Make.com issue)

## Daily Workflow Integration

### Cron Schedule
- **Trigger:** Daily at 05:00 UTC (15:00 AEST)
- **Action:** `send_daily_post.py` with rotation management
- **Approval:** User interaction required before sending
- **State Management:** `daily_post_state.json` tracks rotation position

### Sequence
1. **05:00 UTC:** Cron triggers OpenClaw isolated session
2. **Load Draft:** Next draft in rotation (0-4 index)
3. **User Approval:** Present draft via Telegram, request approval
4. **Processing:**
   - Approve: Send via webhook with scheduled time
   - Modify: Update text, then send
   - Skip: Advance rotation, no send today
5. **State Update:** Increment rotation, log to engagement CSV
6. **Verification:** Check webhook response (200 OK = accepted)

## Error Handling & Recovery

### Common Issues & Solutions

#### Issue 1: Webhook 410 Error (Scenario Not Active)
**Symptoms:** HTTP 410 response, "Gone" message
**Solution:**
1. Log into Make.com dashboard
2. Navigate to scenario containing the webhook
3. Ensure scenario is "Active" (not "Inactive" or "Paused")
4. Reactivate if needed
5. Test with `test_make_webhook.py`

#### Issue 2: Invalid Payload Format
**Symptoms:** HTTP 400 response, parsing errors
**Solution:**
1. Validate payload with `payload_formatter.validate_payload()`
2. Ensure required fields: `profile_ids`, `text` or `message`
3. Check JSON structure is valid
4. Test with simple payload using `send_test_post.py`

#### Issue 3: Buffer Profile ID Invalid
**Symptoms:** Buffer API rejects post, 400/401 error
**Solution:**
1. Verify Buffer profile ID for @ShopBitcoinAus
2. Check Buffer connection in Make.com scenario
3. Test Buffer API directly (if credentials available)

#### Issue 4: Timezone Conversion Errors
**Symptoms:** Posts scheduled at wrong time
**Solution:**
1. Use `utc_from_aest()` function in `payload_formatter.py`
2. Verify AEST to UTC conversion (AEST = UTC+10)
3. Test with explicit UTC timestamps

## Testing Procedures

### 1. Basic Connectivity Test
```bash
python3 scripts/test_make_webhook.py --url https://hook.us2.make.com/...
```

### 2. Payload Format Test
```bash
python3 scripts/test_make_webhook.py --format message_field
python3 scripts/test_make_webhook.py --format buffer_api
```

### 3. End-to-End Test
```bash
python3 scripts/send_test_post.py --immediate --text "Test post from automation system"
```

### 4. Scheduled Post Test
```bash
python3 scripts/send_test_post.py --schedule "2026-02-23T05:00:00Z" --text "Future scheduled test"
```

## Monitoring & Alerting

### Success Indicators
- **HTTP 200:** Webhook accepted payload
- **Response Body:** "Accepted" or Buffer API success message
- **Make.com Logs:** Scenario execution shows success
- **Buffer Queue:** Post appears in Buffer scheduled queue

### Failure Alerts
- **HTTP 4xx:** Client error - check payload and configuration
- **HTTP 5xx:** Server error - Buffer or Make.com issue
- **Timeout:** Network connectivity problem
- **No Response:** Webhook not reachable

### Logging Requirements
- **All Attempts:** Timestamp, payload, response, status code
- **Error Details:** Full error message, stack trace for debugging
- **User Actions:** Approval decisions, modifications, skips
- **Performance Metrics:** Response time, success rate

## Security Considerations

### Webhook URL Security
- **Confidentiality:** Treat webhook URL as secret (contains ID)
- **Access Control:** Limit who can view/modify webhook configuration
- **Rotation:** Generate new webhook if compromised
- **Monitoring:** Alert on unexpected usage patterns

### Payload Validation
- **Input Sanitization:** Remove malicious characters from post text
- **Size Limits:** Enforce Twitter/X character limits (280 chars)
- **URL Safety:** Validate URLs before inclusion
- **Content Review:** User approval provides human oversight

### API Key Protection
- **Buffer Tokens:** Stored securely in Make.com, not in code
- **Minimal Permissions:** Use least privilege principle
- **Regular Review:** Audit access permissions quarterly

## Maintenance Schedule

### Daily
- Verify webhook connectivity (heartbeat check)
- Check Make.com scenario status
- Monitor Buffer scheduled queue

### Weekly
- Test full workflow end-to-end
- Review error logs and failure patterns
- Update engagement tracking reports

### Monthly
- Review webhook security settings
- Test backup/restore procedures
- Update documentation based on learnings

### Quarterly
- Rotate webhook URL (optional, if security concern)
- Audit Buffer API permissions
- Review integration architecture for improvements

---

**Last Updated:** 2026-02-22  
**Integration Status:** ✅ ACTIVE  
**Test Coverage:** Comprehensive  
**Reliability:** High (proven in production)