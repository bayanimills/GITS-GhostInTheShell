#!/usr/bin/env python3
"""
Formal payload formatter for Make.com webhook integration.
Ensures consistent payload formatting for Buffer API integration.
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path

def create_buffer_payload(draft, schedule_utc=None):
    """
    Create a consistent Buffer API format payload for Make.com webhook.
    
    Args:
        draft (dict): Draft dictionary from buffer-drafts-batch-1.json
        schedule_utc (str or None): ISO 8601 UTC timestamp for scheduled posts.
                                   If None, post immediately ("now": True).
    
    Returns:
        dict: Formatted payload for Buffer API integration.
    """
    # Base payload structure
    payload = {
        "profile_ids": ["twitter_shopbitcoinaus"],  # Buffer profile ID for @ShopBitcoinAus
        "text": draft["text"],
        "shorten": False,
        "top": False
    }
    
    # Schedule handling
    if schedule_utc is None:
        # Immediate posting
        payload["now"] = True
    else:
        # Scheduled posting
        payload["scheduled_at"] = schedule_utc
        # Do NOT include "now": False - Buffer API expects either "now" or "scheduled_at"
    
    # Media handling (optional)
    suggested_image = draft.get("suggested_image")
    if suggested_image:
        payload["media"] = {
            "photo": suggested_image,
            "description": f"Shop Bitcoin Australia: {draft['content_style']}"
        }
    
    # Remove None values
    payload = {k: v for k, v in payload.items() if v is not None}
    
    return payload

def create_message_payload(draft, schedule_utc=None, approval_required=False):
    """
    Create payload with 'message' field for Make.com webhook integration.
    Based on user instruction: "Your payload should include the post details in 'message'."
    
    Args:
        draft (dict): Draft dictionary from buffer-drafts-batch-1.json
        schedule_utc (str or None): ISO 8601 UTC timestamp for scheduled posts.
                                   If None, post immediately ("schedule": "now").
        approval_required (bool): If True, adds field to indicate approval needed.
    
    Returns:
        dict: Formatted payload with 'message' field.
    """
    from datetime import datetime, timezone
    
    payload = {
        "message": draft["text"],
        "action": "post_tweet" if schedule_utc is None else "schedule_tweet",
        "platform": "twitter",
        "account": draft.get("target_account", "@ShopBitcoinAus"),
        "schedule": "now" if schedule_utc is None else schedule_utc,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "test": False,
        "metadata": {
            "draft_id": draft["id"],
            "content_style": draft["content_style"],
            "batch_id": "sba_batch_1_20260215"
        }
    }
    
    if approval_required:
        payload["approval_required"] = True
        payload["auto_post"] = False
    
    return payload

def create_metadata(draft, schedule_utc=None):
    """
    Create metadata object for tracking and logging.
    """
    metadata = {
        "draft_id": draft.get("id"),
        "content_style": draft.get("content_style"),
        "content_category": draft.get("content_category"),
        "target_audience": draft.get("target_audience", []),
        "batch_id": "sba_batch_1_20260215",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "schedule_utc": schedule_utc,
        "immediate": schedule_utc is None
    }
    
    return metadata

def validate_payload(payload):
    """
    Validate payload structure before sending.
    Returns (is_valid, error_message).
    """
    required_fields = ["profile_ids", "text"]
    
    for field in required_fields:
        if field not in payload:
            return False, f"Missing required field: {field}"
    
    if not isinstance(payload["profile_ids"], list):
        return False, "profile_ids must be a list"
    
    if not payload["profile_ids"]:
        return False, "profile_ids list cannot be empty"
    
    if not isinstance(payload["text"], str):
        return False, "text must be a string"
    
    if len(payload["text"].strip()) == 0:
        return False, "text cannot be empty"
    
    # Check schedule fields
    if "now" in payload and "scheduled_at" in payload:
        return False, "Cannot have both 'now' and 'scheduled_at' fields"
    
    if "now" in payload and not isinstance(payload["now"], bool):
        return False, "'now' must be boolean"
    
    if "scheduled_at" in payload and not isinstance(payload["scheduled_at"], str):
        return False, "'scheduled_at' must be string (ISO timestamp)"
    
    return True, "Payload valid"

def load_draft(draft_id):
    """
    Load a specific draft from buffer-drafts-batch-1.json.
    """
    script_dir = Path(__file__).parent
    draft_file = script_dir.parent / "buffer-drafts-batch-1.json"
    
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        
        for draft in data.get('drafts', []):
            if draft.get('id') == draft_id:
                return draft
        return None
    except Exception as e:
        print(f"Error loading draft: {e}")
        return None

def load_all_drafts():
    """
    Load all drafts from buffer-drafts-batch-1.json.
    """
    script_dir = Path(__file__).parent
    draft_file = script_dir.parent / "buffer-drafts-batch-1.json"
    
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        return data.get('drafts', [])
    except Exception as e:
        print(f"Error loading drafts: {e}")
        return []

def load_draft_by_index(index):
    """
    Load draft by index (0-based).
    """
    drafts = load_all_drafts()
    if 0 <= index < len(drafts):
        return drafts[index]
    return None

def get_next_draft_index():
    """
    Get next draft index from rotation state.
    Updates state file with next index.
    Returns (draft_index, draft).
    """
    script_dir = Path(__file__).parent
    state_file = script_dir.parent / "daily_post_state.json"
    
    try:
        with open(state_file, 'r') as f:
            state = json.load(f)
    except FileNotFoundError:
        # Initialize state
        state = {
            "next_index": 0,
            "last_used_index": None,
            "last_post_date": None,
            "rotation_order": list(range(5)),
            "total_drafts": 5,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
    
    next_idx = state.get("next_index", 0)
    drafts = load_all_drafts()
    total = len(drafts)
    
    if total == 0:
        return None, None
    
    # Ensure index is within bounds
    if next_idx >= total:
        next_idx = 0
    
    # Update state for next time
    state["last_used_index"] = next_idx
    state["last_post_date"] = datetime.now(timezone.utc).isoformat()
    state["next_index"] = (next_idx + 1) % total
    
    # Save state
    with open(state_file, 'w') as f:
        json.dump(state, f, indent=2)
    
    return next_idx, drafts[next_idx]

def get_draft_for_daily_post():
    """
    Get the next draft for daily post rotation.
    Returns (draft_id, draft_text, draft_index, draft_dict).
    """
    index, draft = get_next_draft_index()
    if draft is None:
        return None, None, None, None
    
    return draft["id"], draft["text"], index, draft

if __name__ == "__main__":
    # Test the payload formatter
    print("🧪 Testing Payload Formatter")
    print("=" * 60)
    
    # Load a test draft
    draft = load_draft("draft_1")
    if draft:
        print(f"✅ Loaded draft: {draft['content_style']}")
        
        # Test immediate payload
        immediate_payload = create_buffer_payload(draft)
        is_valid, message = validate_payload(immediate_payload)
        print(f"\n📤 Immediate Payload (valid: {is_valid}):")
        print(json.dumps(immediate_payload, indent=2))
        print(f"Validation: {message}")
        
        # Test scheduled payload
        schedule_time = datetime(2026, 2, 16, 2, 0, 0, tzinfo=timezone.utc).isoformat()
        scheduled_payload = create_buffer_payload(draft, schedule_time)
        is_valid, message = validate_payload(scheduled_payload)
        print(f"\n📅 Scheduled Payload (valid: {is_valid}):")
        print(json.dumps(scheduled_payload, indent=2))
        print(f"Validation: {message}")
        
        # Test metadata
        metadata = create_metadata(draft, schedule_time)
        print(f"\n📊 Metadata:")
        print(json.dumps(metadata, indent=2))
    else:
        print("❌ Could not load draft_1")