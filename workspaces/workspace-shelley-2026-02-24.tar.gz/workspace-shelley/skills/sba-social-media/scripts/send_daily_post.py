#!/usr/bin/env python3
"""
Send daily post via Make.com webhook using 'message' field format.
Updates engagement tracking CSV and rotation state.
"""

import json
import requests
import sys
import os
from datetime import datetime, timezone
import csv
from pathlib import Path
import config
import payload_formatter

MAKE_WEBHOOK_URL = config.get_webhook_url()

def load_draft_by_index(index):
    """Load draft by index."""
    return payload_formatter.load_draft_by_index(index)

def send_daily_post(draft_index=None, draft_id=None, schedule_utc=None, approval_required=False):
    """
    Send daily post with rotation.
    
    Args:
        draft_index (int): Index of draft (0-4). If None, uses next from rotation.
        draft_id (str): Specific draft ID. Overrides index.
        schedule_utc (str): ISO UTC timestamp for scheduling. None for immediate.
        approval_required (bool): Whether to include approval flag.
    
    Returns:
        tuple: (success(bool), draft_id, draft_index, response_text)
    """
    script_dir = Path(__file__).parent
    workspace_dir = script_dir.parent
    
    # Load draft
    if draft_id:
        draft = payload_formatter.load_draft(draft_id)
        if draft is None:
            return False, draft_id, None, f"Draft {draft_id} not found"
        draft_idx = None  # Not needed for rotation update
    elif draft_index is not None:
        draft = load_draft_by_index(draft_index)
        if draft is None:
            return False, None, draft_index, f"Draft index {draft_index} not found"
        draft_idx = draft_index
    else:
        # Get next from rotation
        draft_id, draft_text, draft_idx, draft = payload_formatter.get_draft_for_daily_post()
        if draft is None:
            return False, None, None, "No drafts available"
    
    # Create payload
    payload = payload_formatter.create_message_payload(
        draft, 
        schedule_utc=schedule_utc,
        approval_required=approval_required
    )
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    print(f"📤 Sending {draft['id']} ({draft['content_style']})...")
    print(f"   Immediate: {schedule_utc is None}")
    if schedule_utc:
        print(f"   Schedule: {schedule_utc}")
    print(f"   Approval required: {approval_required}")
    print(f"   Text preview: {draft['text'][:80]}...")
    
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.text[:100]}")
        
        success = response.status_code in [200, 201, 202]
        
        # Update engagement tracking
        if success and schedule_utc is None:  # Only track immediate posts
            update_engagement_tracking(draft, response)
        
        return success, draft["id"], draft_idx, response.text
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False, draft["id"] if draft else None, draft_idx, str(e)

def update_engagement_tracking(draft, response):
    """Add entry to engagement tracking CSV."""
    script_dir = Path(__file__).parent
    csv_file = script_dir.parent / "engagement_data.csv"
    
    # Create file if doesn't exist
    if not csv_file.exists():
        with open(csv_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                "timestamp_utc",
                "draft_id",
                "content_style",
                "platform",
                "account",
                "scheduled",
                "schedule_time",
                "webhook_response",
                "likes",
                "retweets",
                "replies",
                "impressions",
                "clicks",
                "notes"
            ])
    
    # Add entry
    with open(csv_file, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            datetime.now(timezone.utc).isoformat(),
            draft["id"],
            draft["content_style"],
            "twitter",
            draft.get("target_account", "@ShopBitcoinAus"),
            False,  # scheduled (false for immediate)
            None,   # schedule_time
            response.text[:200],  # webhook response
            "", "", "", "", "", "",  # engagement metrics (empty initially)
            "Daily post via send_daily_post.py"
        ])
    
    print(f"   💾 Engagement tracking updated: {csv_file}")

def main():
    """Command line interface."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Send daily post via Make.com webhook")
    parser.add_argument("--draft-index", type=int, help="Draft index (0-4)")
    parser.add_argument("--draft-id", help="Draft ID (e.g., draft_1)")
    parser.add_argument("--schedule", help="Schedule time (ISO UTC)")
    parser.add_argument("--approval", action="store_true", help="Require approval")
    parser.add_argument("--list", action="store_true", help="List available drafts")
    
    args = parser.parse_args()
    
    if args.list:
        drafts = payload_formatter.load_all_drafts()
        print("Available drafts:")
        for i, d in enumerate(drafts):
            print(f"  {i}: {d['id']} ({d['content_style']})")
            print(f"     {d['text'][:80]}...")
            print()
        return 0
    
    success, draft_id, draft_idx, response = send_daily_post(
        draft_index=args.draft_index,
        draft_id=args.draft_id,
        schedule_utc=args.schedule,
        approval_required=args.approval
    )
    
    if success:
        print(f"✅ Successfully sent {draft_id}")
        return 0
    else:
        print(f"❌ Failed to send {draft_id}: {response}")
        return 1

if __name__ == "__main__":
    sys.exit(main())