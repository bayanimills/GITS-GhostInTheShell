#!/usr/bin/env python3
"""
Test Make.com webhook for Buffer integration.
Webhook endpoint: vumwb8qh0mjdjewqiv9bbw1vndz9qt1z@hook.us2.make.com
Likely URL: https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z
"""

import json
import requests
import sys
import os
from datetime import datetime, timezone, timedelta
import config

# Webhook configuration
MAKE_WEBHOOK_URL = config.get_webhook_url()

def test_webhook_connectivity():
    """Test if webhook endpoint is reachable."""
    print(f"🔍 Testing webhook connectivity: {MAKE_WEBHOOK_URL}")
    
    try:
        # Simple HEAD request to check if endpoint exists
        response = requests.head(MAKE_WEBHOOK_URL, timeout=10)
        print(f"   HEAD request - Status: {response.status_code}")
        
        if response.status_code == 200:
            print("   ✅ Webhook endpoint is reachable")
            return True
        else:
            print(f"   ⚠️ Unexpected status: {response.status_code}")
            print("   ℹ️ Some webhooks may not respond to HEAD requests")
            return True  # Still continue, as POST might work
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Connection error: {e}")
        print("   ℹ️ Webhook may require specific payload or headers")
        return False

def load_draft(draft_id):
    """Load a specific draft from the JSON file."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    draft_file = os.path.join(script_dir, "..", "buffer-drafts-batch-1.json")
    
    try:
        with open(draft_file, 'r') as f:
            data = json.load(f)
        
        for draft in data.get('drafts', []):
            if draft.get('id') == draft_id:
                return draft
        return None
    except Exception as e:
        print(f"Error loading draft: {e}")
        return None

def create_test_payload(draft=None):
    """
    Create a test payload for Make.com webhook.
    Unknown payload format - trying different possibilities.
    """
    
    if draft:
        # Option 1: Direct Buffer API format (what Buffer expects)
        buffer_payload = {
            "profile_ids": ["twitter_shopbitcoinaus"],  # Placeholder - Make.com might handle this
            "text": draft["text"],
            "shorten": False,
            "now": True,  # Post immediately for test
            "top": False,
            "media": {
                "photo": draft.get("suggested_image", ""),
                "description": f"Shop Bitcoin Australia: {draft['content_style']}"
            } if draft.get("suggested_image") else None
        }
        
        # Option 2: Simple text payload (Make.com might extract fields)
        simple_payload = {
            "text": draft["text"],
            "platform": "twitter",
            "account": "ShopBitcoinAus",
            "schedule": "now",
            "test": True
        }
        
        # Option 3: Minimal payload
        minimal_payload = {
            "message": draft["text"],
            "action": "schedule_tweet"
        }
        
        return {
            "buffer_format": buffer_payload,
            "simple_format": simple_payload,
            "minimal_format": minimal_payload
        }
    else:
        # Test payload without draft
        return {
            "test": True,
            "message": "Test webhook connectivity from Shop Bitcoin Australia",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": "test_connection"
        }

def send_test_payload(payload, payload_name="test"):
    """Send a test payload to the webhook."""
    print(f"\n📤 Sending {payload_name} payload:")
    print(json.dumps(payload, indent=2)[:500] + ("..." if len(json.dumps(payload)) > 500 else ""))
    
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ShopBitcoinAU/1.0"
    }
    
    try:
        response = requests.post(
            MAKE_WEBHOOK_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        print(f"\n📥 Response - Status: {response.status_code}")
        
        if response.headers.get('Content-Type', '').startswith('application/json'):
            try:
                response_json = response.json()
                print("Response JSON:")
                print(json.dumps(response_json, indent=2)[:1000])
            except:
                print(f"Response text: {response.text[:500]}")
        else:
            print(f"Response: {response.text[:500]}")
        
        if response.status_code in [200, 201, 202]:
            print(f"✅ {payload_name} payload accepted!")
            return True
        else:
            print(f"⚠️ {payload_name} payload returned status {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
        return False

def main():
    print("🛠️ Make.com Webhook Tester")
    print("=" * 60)
    print(f"Webhook: {MAKE_WEBHOOK_URL}")
    print("=" * 60)
    
    # Test connectivity first
    if not test_webhook_connectivity():
        print("\n⚠️ Webhook connectivity test failed.")
        print("ℹ️ Trying POST request anyway (some webhooks block HEAD)...")
    
    print("\n🎯 Select test mode:")
    print("  1. Simple connection test (minimal payload)")
    print("  2. Test with Draft 1 (Educational/Beginner)")
    print("  3. Test with Draft 2 (Technical)")
    print("  4. Test all payload formats with Draft 1")
    
    try:
        choice = input("\nEnter choice (1-4): ").strip()
    except EOFError:
        choice = "1"  # Default to simple test
    
    if choice == "1":
        print("\n🔧 Simple connection test")
        test_payload = create_test_payload()
        success = send_test_payload(test_payload, "simple_connection")
        
    elif choice == "2":
        print("\n📝 Testing with Draft 1 (Educational/Beginner)")
        draft = load_draft("draft_1")
        if draft:
            print(f"Loaded draft: {draft['content_style']}")
            print(f"Text: {draft['text'][:100]}...")
            
            # Try simple format first
            payloads = create_test_payload(draft)
            success = send_test_payload(payloads['simple_format'], "simple_format")
            
            if not success:
                print("\n🔄 Trying minimal format...")
                send_test_payload(payloads['minimal_format'], "minimal_format")
        else:
            print("❌ Could not load draft_1")
            
    elif choice == "3":
        print("\n📝 Testing with Draft 2 (Technical)")
        draft = load_draft("draft_2")
        if draft:
            print(f"Loaded draft: {draft['content_style']}")
            print(f"Text: {draft['text'][:100]}...")
            
            # Try simple format first
            payloads = create_test_payload(draft)
            success = send_test_payload(payloads['simple_format'], "simple_format")
        else:
            print("❌ Could not load draft_2")
            
    elif choice == "4":
        print("\n🔄 Testing all payload formats with Draft 1")
        draft = load_draft("draft_1")
        if draft:
            print(f"Testing draft: {draft['content_style']}")
            payloads = create_test_payload(draft)
            
            print("\n1. Testing simple format:")
            send_test_payload(payloads['simple_format'], "simple_format")
            
            print("\n2. Testing minimal format:")
            send_test_payload(payloads['minimal_format'], "minimal_format")
            
            print("\n3. Testing Buffer format (may need adjustment):")
            send_test_payload(payloads['buffer_format'], "buffer_format")
        else:
            print("❌ Could not load draft_1")
    else:
        print("Invalid choice")
        return 1
    
    print("\n" + "=" * 60)
    print("📝 Next steps:")
    print("  1. Check Make.com scenario for webhook execution")
    print("  2. Verify Buffer received the test")
    print("  3. Check Twitter for test post (if scheduled)")
    print("  4. Update payload format based on results")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())