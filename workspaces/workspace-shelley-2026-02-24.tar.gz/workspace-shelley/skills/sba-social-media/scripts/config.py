#!/usr/bin/env python3
"""
Configuration loader for Shop Bitcoin Australia social media scripts.
"""

import json
import os
from pathlib import Path

# Default webhook (will be overridden by config file)
DEFAULT_WEBHOOK_URL = "https://hook.us2.make.com/vumwb8qh0mjdjewqiv9bbw1vndz9qt1z"

def load_webhook_config():
    """
    Load webhook configuration from webhook_config.json.
    Returns dict with 'webhook_url' and 'webhook_id'.
    """
    config_path = Path(__file__).parent.parent / "webhook_config.json"
    
    if not config_path.exists():
        return {
            "webhook_url": DEFAULT_WEBHOOK_URL,
            "webhook_id": "vumwb8qh0mjdjewqiv9bbw1vndz9qt1z",
            "source": "default"
        }
    
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Ensure required fields
        if "webhook_url" not in config:
            config["webhook_url"] = DEFAULT_WEBHOOK_URL
        
        if "webhook_id" not in config:
            # Extract ID from URL
            import re
            match = re.search(r'https://hook\.us2\.make\.com/([a-z0-9]+)', config["webhook_url"])
            if match:
                config["webhook_id"] = match.group(1)
            else:
                config["webhook_id"] = "unknown"
        
        config["source"] = "file"
        return config
        
    except Exception as e:
        print(f"⚠️ Error loading webhook config: {e}")
        return {
            "webhook_url": DEFAULT_WEBHOOK_URL,
            "webhook_id": "vumwb8qh0mjdjewqiv9bbw1vndz9qt1z",
            "source": "error_fallback"
        }

def get_webhook_url():
    """Get the current webhook URL."""
    config = load_webhook_config()
    return config["webhook_url"]

def get_webhook_id():
    """Get the current webhook ID."""
    config = load_webhook_config()
    return config["webhook_id"]

# For backward compatibility
MAKE_WEBHOOK_URL = get_webhook_url()
MAKE_WEBHOOK_ID = get_webhook_id()

if __name__ == "__main__":
    config = load_webhook_config()
    print("🔧 Current Webhook Configuration:")
    print(f"   URL: {config['webhook_url']}")
    print(f"   ID: {config['webhook_id']}")
    print(f"   Source: {config.get('source', 'unknown')}")