#!/usr/bin/env python3
"""Process Voltage invoice pilot (#448A39E5-0012)"""

import sys
import os
import json
import re
import subprocess
from datetime import datetime

sys.path.insert(0, '/home/agent/.openclaw/workspace-shelley/skills/nextcloud/scripts')
from nextcloud_client import NextcloudClient

# Configuration
ACCOUNT = "service@shopbitcoin.com.au"
LABEL_NAME = "Saved in Nextcloud by Shelley"
FINANCE_BASE = "Finance/Incoming"

def run_gog(args, capture_output=True):
    """Run gog command and return parsed JSON if possible."""
    cmd = ["gog"] + args + ["--account", ACCOUNT, "--json"]
    print(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=capture_output, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error: {result.stderr}")
            return None
        
        if capture_output:
            return json.loads(result.stdout)
        return True
    except Exception as e:
        print(f"Command failed: {e}")
        return None

def ensure_label_exists():
    """Ensure label exists, create if not."""
    # List labels
    labels = run_gog(["gmail", "labels", "list"])
    if not labels:
        return None
    
    for label in labels.get("labels", []):
        if label.get("name") == LABEL_NAME:
            print(f"Label '{LABEL_NAME}' exists (ID: {label.get('id')})")
            return label.get("id")
    
    # Create label
    print(f"Creating label '{LABEL_NAME}'...")
    result = run_gog(["gmail", "labels", "create", LABEL_NAME])
    if result and "id" in result:
        print(f"Created label with ID: {result['id']}")
        return result["id"]
    
    return None

def parse_invoice_metadata(email_data):
    """Parse invoice metadata from email JSON."""
    subject = email_data.get("headers", {}).get("subject", "")
    body = email_data.get("body", "")
    
    # Extract invoice number
    invoice_match = re.search(r'#([A-Z0-9\-]+)', subject)
    invoice_number = invoice_match.group(1) if invoice_match else "UNKNOWN"
    
    # Extract amount
    amount_match = re.search(r'\$(\d+\.\d{2})', body)
    if not amount_match:
        # Try other patterns
        amount_match = re.search(r'Total due \$(\d+\.\d{2})', body)
    amount = amount_match.group(1) if amount_match else "0.00"
    
    # Vendor name
    vendor = "Voltage"
    
    # Date - use email date
    date_str = email_data.get("headers", {}).get("date", "")
    if date_str:
        # Parse RFC 2822 date
        from email.utils import parsedate_to_datetime
        try:
            dt = parsedate_to_datetime(date_str)
            date = dt.strftime("%Y-%m-%d")
        except:
            date = datetime.now().strftime("%Y-%m-%d")
    else:
        date = datetime.now().strftime("%Y-%m-%d")
    
    return {
        "invoice_number": invoice_number,
        "amount": amount,
        "vendor": vendor,
        "date": date,
        "original_filename": f"Invoice-{invoice_number}.pdf"
    }

def sanitize_filename(metadata):
    """Create sanitized filename according to convention."""
    # Replace $ with AUD
    amount_str = f"AUD{metadata['amount']}"
    
    # Remove problematic characters from vendor name
    vendor_clean = re.sub(r'[<>:"/\\|?*]', '', metadata['vendor'])
    
    # Build filename
    filename = f"{metadata['date']} - {vendor_clean} - {metadata['invoice_number']} - {amount_str} - Invoice-{metadata['invoice_number']}.pdf"
    
    # Replace any remaining problematic characters
    filename = re.sub(r'[<>:"/\\|?*$]', '', filename)
    
    return filename

def download_attachment(message_id, attachment_id, original_filename):
    """Download attachment to temporary location."""
    temp_dir = "temp_invoices"
    os.makedirs(temp_dir, exist_ok=True)
    
    temp_path = os.path.join(temp_dir, original_filename)
    
    # Download using gog
    cmd = [
        "gog", "gmail", "attachment", message_id, attachment_id,
        "--account", ACCOUNT,
        "--output", temp_path
    ]
    
    print(f"Downloading attachment to {temp_path}...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    
    if result.returncode != 0:
        print(f"Download failed: {result.stderr}")
        return None
    
    if os.path.exists(temp_path):
        print(f"Downloaded {os.path.getsize(temp_path)} bytes")
        return temp_path
    else:
        print("Downloaded file not found")
        return None

def archive_and_label_message(message_id, label_id):
    """Archive message (remove INBOX label) and add custom label."""
    # Remove INBOX label
    print(f"Archiving message {message_id}...")
    result = run_gog(["gmail", "thread", "remove-labels", message_id, "INBOX"], capture_output=False)
    if result is None:
        print("Warning: Failed to remove INBOX label")
    
    # Add custom label
    if label_id:
        print(f"Adding label {LABEL_NAME}...")
        result = run_gog(["gmail", "thread", "add-labels", message_id, label_id], capture_output=False)
        if result is None:
            print("Warning: Failed to add custom label")
    
    return True

def main():
    print("=" * 60)
    print("VOLTAGE INVOICE PILOT PROCESSING")
    print("=" * 60)
    
    # Initialize Nextcloud client
    print("\n1. Initializing Nextcloud client...")
    nc = NextcloudClient()
    
    # Ensure label exists
    print("\n2. Setting up Gmail label...")
    label_id = ensure_label_exists()
    if not label_id:
        print("Warning: Could not ensure label exists")
    
    # Get pilot email data
    print("\n3. Fetching pilot email data...")
    email_data = run_gog(["gmail", "get", "19bb1974670b40a3"])
    if not email_data:
        print("Failed to get email data")
        return 1
    
    # Parse metadata
    print("\n4. Parsing invoice metadata...")
    metadata = parse_invoice_metadata(email_data)
    print(f"   Invoice #: {metadata['invoice_number']}")
    print(f"   Amount: ${metadata['amount']}")
    print(f"   Vendor: {metadata['vendor']}")
    print(f"   Date: {metadata['date']}")
    
    # Sanitize filename
    new_filename = sanitize_filename(metadata)
    print(f"   New filename: {new_filename}")
    
    # Download attachment
    print("\n5. Downloading PDF attachment...")
    attachments = email_data.get("attachments", [])
    if not attachments:
        print("No attachments found")
        return 1
    
    attachment = attachments[0]
    original_filename = attachment["filename"]
    attachment_id = attachment["attachmentId"]
    
    local_path = download_attachment("19bb1974670b40a3", attachment_id, original_filename)
    if not local_path:
        print("Failed to download attachment")
        return 1
    
    # Upload to Nextcloud
    print("\n6. Uploading to Nextcloud...")
    remote_path = f"{FINANCE_BASE}/{new_filename}"
    print(f"   Remote path: {remote_path}")
    
    result = nc.upload_file(local_path, remote_path)
    if result:
        print(f"   ✓ Upload successful: {result}")
        
        # Archive and label email
        print("\n7. Archiving and labeling email...")
        archive_and_label_message("19bb1974670b40a3", label_id)
        print("   ✓ Email archived and labeled")
        
        # Clean up local file
        print("\n8. Cleaning up...")
        os.remove(local_path)
        print("   ✓ Local file removed")
        
        print(f"\n{'='*60}")
        print("PILOT COMPLETED SUCCESSFULLY!")
        print(f"File stored at: {result}")
        print(f"{'='*60}")
        
        # Log to CSV
        csv_line = f"{metadata['date']},{metadata['vendor']},{metadata['invoice_number']},${metadata['amount']},{result}"
        print(f"\nCSV log entry: {csv_line}")
        
        return 0
    else:
        print("   ✗ Upload failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())