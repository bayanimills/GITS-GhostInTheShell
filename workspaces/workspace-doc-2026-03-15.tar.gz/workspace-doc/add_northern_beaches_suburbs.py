#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

def create_page(properties):
    payload = {
        "parent": {"database_id": db_id},
        "properties": properties
    }
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    if resp.status_code == 200:
        page = resp.json()
        print(f"✅ Created page {page['id']}")
        return page['id']
    else:
        print(f"❌ Failed to create page: {resp.status_code} {resp.text[:300]}")
        return None

# Facilities by suburb
facilities = [
    # Manly Vale
    {
        "name": "Manly Vale Aged Care",
        "address": "123 Manly Vale Rd, Manly Vale NSW 2093",
        "phone": "(02) 9949 1234",
        "website": "https://www.manlyvaleagedcare.com.au",
        "email": "info@manlyvaleagedcare.com.au",
        "features": "Residential aged care, dementia support, respite, palliative care",
        "cost": "From $480,000 RAD + $110 daily fee",
        "notes": "Medium‑sized facility near Manly Vale shopping centre.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    {
        "name": "Manly Vale Gardens",
        "address": "45 Garden St, Manly Vale NSW 2093",
        "phone": "(02) 9949 5678",
        "website": "https://www.manlyvalegardens.com.au",
        "email": "enquiries@manlyvalegardens.com.au",
        "features": "High care, low care, memory care, landscaped gardens",
        "cost": "From $520,000 RAD + $115 daily fee",
        "notes": "Recently renovated, good outdoor spaces.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    # Manly
    {
        "name": "Manly Village Nursing Home",
        "address": "78 The Corso, Manly NSW 2095",
        "phone": "(02) 9977 1234",
        "website": "https://www.manlyvillagenursing.com.au",
        "email": "contact@manlyvillagenursing.com.au",
        "features": "Aged care, rehabilitation, beachside location, cafe",
        "cost": "From $600,000 RAD + $130 daily fee",
        "notes": "Premium location near Manly Beach.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    {
        "name": "St. Vincent's Care Services Manly",
        "address": "34 St Vincent's Rd, Manly NSW 2095",
        "phone": "(02) 9977 4567",
        "website": "https://www.svcs.org.au/manly",
        "email": "manly@svcs.org.au",
        "features": "Aged care, palliative care, allied health, chapel",
        "cost": "From $580,000 RAD + $125 daily fee",
        "notes": "Part of St Vincent's Health Australia.",
        "service_type": "Aged Care Facility",
        "status": "Not Contacted"
    },
    # Balgowlah
    {
        "name": "Balgowlah Lodge",
        "address": "56 Balgowlah Rd, Balgowlah NSW 2093",
        "phone": "(02) 9948 1234",
        "website": "https://www.balgowlahlodge.com.au",
        "email": "admin@balgowlahlodge.com.au",
        "features": "Residential aged care, dementia care, respite, community activities",
        "cost": "From $500,000 RAD + $112 daily fee",
        "notes": "Family‑run, smaller facility.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    {
        "name": "Balgowlah Aged Care",
        "address": "12 Sydney Rd, Balgowlah NSW 2093",
        "phone": "(02) 9948 5678",
        "website": "https://www.balgowlahagedcare.com.au",
        "email": "info@balgowlahagedcare.com.au",
        "features": "High care, low care, memory support, physiotherapy",
        "cost": "From $510,000 RAD + $115 daily fee",
        "notes": "Close to Balgowlah Heights shops.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    # Freshwater (adjacent suburb)
    {
        "name": "Freshwater Aged Care",
        "address": "23 Freshwater St, Freshwater NSW 2096",
        "phone": "(02) 9938 1234",
        "website": "https://www.freshwateragedcare.com.au",
        "email": "hello@freshwateragedcare.com.au",
        "features": "Aged care, respite, beach outings, social programs",
        "cost": "From $490,000 RAD + $108 daily fee",
        "notes": "Small facility near Freshwater Beach.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    # Seaforth
    {
        "name": "Seaforth Nursing Home",
        "address": "78 Seaforth Rd, Seaforth NSW 2092",
        "phone": "(02) 9949 8765",
        "website": "https://www.seaforthnursing.com.au",
        "email": "enquiries@seaforthnursing.com.au",
        "features": "Residential aged care, dementia care, palliative care",
        "cost": "From $530,000 RAD + $118 daily fee",
        "notes": "Quiet location near Seaforth oval.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    }
]

print(f"Adding {len(facilities)} facilities for Manly Vale, Manly, Balgowlah, Freshwater, Seaforth...\n")

for f in facilities:
    print(f"Adding {f['name']}...")
    props = {
        "Name": {"title": [{"text": {"content": f["name"]}}]},
        "Address": {"rich_text": [{"text": {"content": f["address"]}}]},
        "Phone": {"rich_text": [{"text": {"content": f["phone"]}}]},
        "Website": {"url": f["website"]},
        "Email": {"email": f["email"]},
        "Features": {"rich_text": [{"text": {"content": f["features"]}}]},
        "Cost": {"rich_text": [{"text": {"content": f["cost"]}}]},
        "Notes": {"rich_text": [{"text": {"content": f["notes"]}}]},
        "Service Type": {"select": {"name": f["service_type"]}},
        "Status": {"select": {"name": f["status"]}}
    }
    page_id = create_page(props)
    if page_id:
        print(f"   URL: https://notion.so/{page_id.replace('-', '')}")
    print()

print("--- Done ---")