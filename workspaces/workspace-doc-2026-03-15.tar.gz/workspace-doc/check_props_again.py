import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def get_props(data_source_id):
    url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
    resp = requests.get(url, headers=HEADERS)
    if resp.status_code == 200:
        ds = resp.json()
        return list(ds.get('properties', {}).keys())
    else:
        print(f'Error: {resp.status_code}')
        return []

print('End-of-Life Planning properties:', get_props('562af9af-f953-4bdb-92d7-ebb0c3020f4c'))
print('After-Death Checklist properties:', get_props('7343ed8d-de9a-42ae-a787-c18f686dac1e'))