#!/usr/bin/env python3
import os
import requests
import json
import sys

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

PAGE_ID = "30dd323b-89ec-8064-ba6e-c5ca7689ed67"

def get_child_databases():
    """Return list of child database blocks on the page."""
    url = f"https://api.notion.com/v1/blocks/{PAGE_ID}/children"
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    data = resp.json()
    dbs = []
    for block in data.get("results", []):
        if block.get("type") == "child_database":
            title = block.get("child_database", {}).get("title", "")
            dbs.append({"id": block["id"], "title": title})
    return dbs

def create_medications_database():
    """Create Medications database."""
    payload = {
        "parent": {"type": "page_id", "page_id": PAGE_ID},
        "title": [{"text": {"content": "Medications"}}],
        "is_inline": True,
        "properties": {
            "Medication Name": {"title": {}},
            "Dose": {"rich_text": {}},
            "Frequency": {
                "select": {
                    "options": [
                        {"name": "daily", "color": "blue"},
                        {"name": "twice daily", "color": "green"},
                        {"name": "at night", "color": "purple"},
                        {"name": "as needed", "color": "orange"},
                        {"name": "weekly", "color": "pink"},
                        {"name": "monthly", "color": "brown"}
                    ]
                }
            },
            "Prescribing Doctor": {"rich_text": {}},
            "Start Date": {"date": {}},
            "End Date": {"date": {}},
            "Status": {
                "select": {
                    "options": [
                        {"name": "Active", "color": "green"},
                        {"name": "Discontinued", "color": "red"},
                        {"name": "On hold", "color": "yellow"}
                    ]
                }
            },
            "Notes": {"rich_text": {}}
        }
    }
    url = "https://api.notion.com/v1/databases"
    resp = requests.post(url, headers=headers, json=payload)
    resp.raise_for_status()
    db = resp.json()
    return db

def add_medication(db_id, med):
    """Add a medication entry to the database."""
    url = "https://api.notion.com/v1/pages"
    props = {
        "Medication Name": {"title": [{"text": {"content": med["name"]}}]},
        "Dose": {"rich_text": [{"text": {"content": med["dose"]}}]},
        "Frequency": {"select": {"name": med["frequency"]}},
        "Prescribing Doctor": {"rich_text": [{"text": {"content": med["doctor"]}}]},
        "Status": {"select": {"name": "Active"}}
    }
    if "start_date" in med:
        props["Start Date"] = {"date": {"start": med["start_date"]}}
    if "notes" in med:
        props["Notes"] = {"rich_text": [{"text": {"content": med["notes"]}}]}
    payload = {
        "parent": {"database_id": db_id},
        "properties": props
    }
    resp = requests.post(url, headers=headers, json=payload)
    try:
        resp.raise_for_status()
    except Exception as e:
        print(f"Response error: {resp.text}")
        raise
    return resp.json()

def main():
    # Check if Medications database already exists
    dbs = get_child_databases()
    medications_db = None
    for db in dbs:
        if db["title"] == "Medications":
            medications_db = db
            print(f"Medications database already exists: {db['id']}")
            break
    if not medications_db:
        print("Creating Medications database...")
        db = create_medications_database()
        medications_db = {"id": db["id"], "title": db["title"][0]["text"]["content"]}
        print(f"Created database: {medications_db['id']}")
    else:
        # Fetch existing entries to avoid duplicates (simplistic)
        pass
    
    # Real medication data from medical letter (extracted 2026-02-20)
    medications = [
        {
            "name": "Amlodipine",
            "dose": "5 mg",
            "frequency": "daily",
            "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
            "notes": "For hypertension"
        },
        {
            "name": "Perindopril",
            "dose": "5 mg",
            "frequency": "daily",
            "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
            "notes": "For hypertension"
        },
        {
            "name": "Apixaban",
            "dose": "5 mg",
            "frequency": "twice daily",
            "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
            "notes": "For atrial fibrillation (anticoagulant)"
        },
        {
            "name": "Aspirin",
            "dose": "100 mg",
            "frequency": "daily",
            "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
            "notes": "Antiplatelet"
        },
        {
            "name": "Atorvastatin",
            "dose": "20 mg",
            "frequency": "at night",
            "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
            "notes": "For hypercholesterolaemia"
        },
        {
            "name": "Metoprolol",
            "dose": "25 mg",
            "frequency": "twice daily",
            "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
            "notes": "Rate control"
        }
    ]
    
    # Add each medication if not already present
    for med in medications:
        try:
            add_medication(medications_db["id"], med)
            print(f"Added {med['name']}")
        except Exception as e:
            print(f"Error adding {med['name']}: {e}")
    
    print("Done.")

if __name__ == "__main__":
    main()