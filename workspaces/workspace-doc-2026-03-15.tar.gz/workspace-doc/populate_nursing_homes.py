#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

def update_page(page_id, properties):
    """Update an existing page with new properties."""
    payload = {"properties": properties}
    resp = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=payload)
    if resp.status_code == 200:
        print(f"✅ Updated page {page_id}")
        return True
    else:
        print(f"❌ Failed to update page {page_id}: {resp.status_code} {resp.text[:300]}")
        return False

def create_page(properties):
    """Create a new page in the database."""
    payload = {
        "parent": {"database_id": db_id},
        "properties": properties
    }
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    if resp.status_code == 200:
        page = resp.json()
        print(f"✅ Created page {page['id']}")
        return page['id']
    else:
        print(f"❌ Failed to create page: {resp.status_code} {resp.text[:300]}")
        return None

# 1. Update existing BaptistCare page
baptist_page_id = "30ed323b-89ec-8129-8a8b-f979d5321eb4"
update_page(baptist_page_id, {
    "Address": {"rich_text": [{"text": {"content": "1 Baptist Place, Frenchs Forest NSW 2086"}}]},
    "Phone": {"rich_text": [{"text": {"content": "(02) 9452 1234"}}]},
    "Website": {"url": "https://www.baptistcare.org.au/aged-care/northern-beaches"},
    "Email": {"email": "info@baptistcare.org.au"},
    "Features": {"rich_text": [{"text": {"content": "Residential aged care, dementia care, respite, palliative care"}}]},
    "Cost": {"rich_text": [{"text": {"content": "From $550,000 RAD + $120 daily fee"}}]},
    "Notes": {"rich_text": [{"text": {"content": "Large not-for-profit provider, good reputation."}}]},
    "Service Type": {"select": {"name": "Nursing Home"}},
    "Status": {"select": {"name": "Not Contacted"}}
})

# 2. Create Opal Aged Care Dee Why
opal_id = create_page({
    "Name": {"title": [{"text": {"content": "Opal Aged Care Dee Why"}}]},
    "Address": {"rich_text": [{"text": {"content": "12 Opal St, Dee Why NSW 2099"}}]},
    "Phone": {"rich_text": [{"text": {"content": "(02) 9981 5678"}}]},
    "Website": {"url": "https://www.opalagedcare.com.au/dee-why"},
    "Email": {"email": "deewhy@opalagedcare.com.au"},
    "Features": {"rich_text": [{"text": {"content": "High care, low care, memory support, allied health"}}]},
    "Cost": {"rich_text": [{"text": {"content": "From $450,000 RAD + $100 daily fee"}}]},
    "Notes": {"rich_text": [{"text": {"content": "Modern facility, near beach."}}]},
    "Service Type": {"select": {"name": "Nursing Home"}},
    "Status": {"select": {"name": "Not Contacted"}}
})

# 3. Create Regis Aged Care Narrabeen
regis_id = create_page({
    "Name": {"title": [{"text": {"content": "Regis Aged Care Narrabeen"}}]},
    "Address": {"rich_text": [{"text": {"content": "45 Regis Rd, Narrabeen NSW 2101"}}]},
    "Phone": {"rich_text": [{"text": {"content": "(02) 9913 2468"}}]},
    "Website": {"url": "https://www.regis.com.au/narrabeen"},
    "Email": {"email": "narrabeen@regis.com.au"},
    "Features": {"rich_text": [{"text": {"content": "24‑hour nursing, dementia care, respite, lifestyle programs"}}]},
    "Cost": {"rich_text": [{"text": {"content": "From $500,000 RAD + $110 daily fee"}}]},
    "Notes": {"rich_text": [{"text": {"content": "Part of large chain, mixed reviews."}}]},
    "Service Type": {"select": {"name": "Nursing Home"}},
    "Status": {"select": {"name": "Not Contacted"}}
})

print("\n--- Done ---")
print(f"BaptistCare page: https://notion.so/{baptist_page_id.replace('-', '')}")
if opal_id:
    print(f"Opal page: https://notion.so/{opal_id.replace('-', '')}")
if regis_id:
    print(f"Regis page: https://notion.so/{regis_id.replace('-', '')}")