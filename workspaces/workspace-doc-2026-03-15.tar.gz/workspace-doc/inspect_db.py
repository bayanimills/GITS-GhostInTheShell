#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
}

resp = requests.get(f"https://api.notion.com/v1/databases/{db_id}", headers=headers)
if resp.status_code == 200:
    db = resp.json()
    print(json.dumps(db, indent=2, default=str))
else:
    print(f"Error {resp.status_code}: {resp.text}")