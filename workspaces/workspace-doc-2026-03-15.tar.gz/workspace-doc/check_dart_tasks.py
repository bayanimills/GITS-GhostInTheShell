#!/usr/bin/env python3
import sys
sys.path.append('/home/agent/.openclaw/workspace-doc')
from scripts.dart_client import DartClient

client = DartClient()
task_ids = [
    'v9xc8FDPj37G',  # Update Will
    'XSubroMB3jZ2',  # Advance Care Directive
    'JzVc6QAxnLFF',  # Power of Attorney
    'nU67ySKCHyED',  # Palliative care assessment
]
for tid in task_ids:
    try:
        task = client.get_task(tid)
        print(f"{task.get('name', 'Unknown')}")
        print(f"  ID: {tid}")
        print(f"  Status: {task.get('status', {}).get('name', 'Unknown')}")
        print(f"  Tags: {task.get('tags', [])}")
        print(f"  Updated: {task.get('updatedAt', 'Unknown')}")
        print()
    except Exception as e:
        print(f"Error fetching {tid}: {e}")
        print()