#!/usr/bin/env python3
import os
import requests
import json

api_key_path = os.path.expanduser("~/.config/notion/api_key")
with open(api_key_path) as f:
    api_key = f.read().strip()

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Search for all databases (use filter value "data_source"?)
resp = requests.post("https://api.notion.com/v1/search",
                     headers=headers,
                     json={"query": "", "filter": {"property": "object", "value": "data_source"}})
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Found {len(results)} data sources")
    for obj in results:
        obj_id = obj.get('id')
        obj_type = obj.get('object')
        title = "Untitled"
        if obj_type == 'database':
            title = obj.get('title', [{}])[0].get('text', {}).get('content', 'Untitled')
        elif obj_type == 'page':
            title = obj.get('properties', {}).get('title', {}).get('title', [{}])[0].get('text', {}).get('content', 'Untitled')
        print(f"  - {obj_type}: {title} ({obj_id})")
        if "Northern" in title or "Beaches" in title:
            print(f"     *** Possible match ***")
            # Print properties if database
            if obj_type == 'database':
                props = obj.get('properties', {})
                print(f"     Properties: {list(props.keys())}")
else:
    print(resp.text[:500])

# Also search for pages with "Northern Beaches"
print("\n--- Searching for pages with 'Northern Beaches' ---")
resp = requests.post("https://api.notion.com/v1/search",
                     headers=headers,
                     json={"query": "Northern Beaches", "filter": {"property": "object", "value": "page"}})
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Found {len(results)} pages")
    for obj in results:
        obj_id = obj.get('id')
        # get page properties
        props = obj.get('properties', {})
        # try to find title
        title = props.get('Name', props.get('Title', props.get('title', {})))
        if isinstance(title, dict) and 'title' in title:
            title_text = title['title'][0].get('text', {}).get('content', 'No title')
        else:
            title_text = 'No title'
        print(f"  - Page: {title_text} ({obj_id})")
        # check if parent database
        parent = obj.get('parent', {})
        if parent.get('type') == 'database_id':
            print(f"    Parent database: {parent.get('database_id')}")