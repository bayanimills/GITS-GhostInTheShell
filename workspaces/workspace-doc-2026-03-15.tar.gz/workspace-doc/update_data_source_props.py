#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

data_source_id = "e15f5b65-1def-4d95-83e0-066e18b08ac2"

payload = {
    "properties": {
        "Dose": {"rich_text": {}},
        "Frequency": {
            "select": {
                "options": [
                    {"name": "daily", "color": "blue"},
                    {"name": "twice daily", "color": "green"},
                    {"name": "at night", "color": "purple"},
                    {"name": "as needed", "color": "orange"},
                    {"name": "weekly", "color": "pink"},
                    {"name": "monthly", "color": "brown"}
                ]
            }
        },
        "Prescribing Doctor": {"rich_text": {}},
        "Start Date": {"date": {}},
        "End Date": {"date": {}},
        "Status": {
            "select": {
                "options": [
                    {"name": "Active", "color": "green"},
                    {"name": "Discontinued", "color": "red"},
                    {"name": "On hold", "color": "yellow"}
                ]
            }
        },
        "Notes": {"rich_text": {}}
    }
}

resp = requests.patch(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers, json=payload)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    ds = resp.json()
    print("Updated data source")
    if 'properties' in ds:
        print("Properties:")
        for key, val in ds['properties'].items():
            print(f"  {key}: {val}")
else:
    print(resp.text)