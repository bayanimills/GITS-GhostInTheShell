#!/usr/bin/env python3
import os
import requests
import json

# API key from file
api_key_path = os.path.expanduser("~/.config/notion/api_key")
with open(api_key_path) as f:
    api_key = f.read().strip()

print(f"API key starts with: {api_key[:10]}...")

# Database ID from memory
database_id = "e44b8f80-c9a1-4c09-a5e7-a14c03e2f8d3"
print(f"Database ID: {database_id}")

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# 1. Retrieve database metadata
print("\n1. Fetching database...")
try:
    resp = requests.get(f"https://api.notion.com/v1/databases/{database_id}", headers=headers)
    if resp.status_code == 200:
        db = resp.json()
        print(f"   Title: {db.get('title', [{}])[0].get('text', {}).get('content', 'Untitled')}")
        print(f"   Created: {db.get('created_time', '?')}")
        print(f"   Properties: {list(db.get('properties', {}).keys())}")
    else:
        print(f"   Error {resp.status_code}: {resp.text[:200]}")
except Exception as e:
    print(f"   Exception: {e}")

# 2. Query pages
print("\n2. Querying pages...")
try:
    resp = requests.post(f"https://api.notion.com/v1/databases/{database_id}/query", 
                         headers=headers, json={})
    if resp.status_code == 200:
        data = resp.json()
        results = data.get('results', [])
        print(f"   Total pages: {len(results)}")
        for i, page in enumerate(results):
            props = page.get('properties', {})
            name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', 'No name')
            address = props.get('Address', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
            service_type = props.get('Service Type', {}).get('select', {}).get('name', '')
            print(f"   {i+1}. {name}")
            if address:
                print(f"      Address: {address[:60]}...")
            if service_type:
                print(f"      Service Type: {service_type}")
            print()
    else:
        print(f"   Error {resp.status_code}: {resp.text[:200]}")
except Exception as e:
    print(f"   Exception: {e}")

# 3. If zero pages, maybe the ID is wrong; search for databases with "Northern Beaches"
print("\n3. Searching for databases with 'Northern Beaches'...")
try:
    resp = requests.post("https://api.notion.com/v1/search",
                         headers=headers,
                         json={"query": "Northern Beaches", "filter": {"property": "object", "value": "database"}})
    if resp.status_code == 200:
        data = resp.json()
        dbs = data.get('results', [])
        print(f"   Found {len(dbs)} databases")
        for db in dbs:
            title = db.get('title', [{}])[0].get('text', {}).get('content', 'Untitled')
            db_id = db.get('id')
            print(f"   - {title} ({db_id})")
    else:
        print(f"   Error {resp.status_code}: {resp.text[:200]}")
except Exception as e:
    print(f"   Exception: {e}")