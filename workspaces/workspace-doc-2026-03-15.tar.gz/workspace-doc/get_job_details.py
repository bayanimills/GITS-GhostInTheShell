#!/usr/bin/env python3
import json
import sys

with open('/tmp/cron.json', 'r') as f:
    data = json.load(f)

targets = ['Gmail Skill hourly digest', 'Cron Manager Hourly Sync']
for job in data.get('jobs', []):
    name = job.get('name')
    if name in targets:
        print(f"\n{name}")
        print(f"  agent: {job.get('agentId')}")
        print(f"  schedule: {job.get('schedule')}")
        payload = job.get('payload', {})
        if payload.get('kind') == 'agentTurn':
            msg = payload.get('message')
            print(f"  message:\n{msg}")
        print()