import os
import json
import requests
from typing import Dict, Any, List

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}
PARENT_PAGE_ID = '30dd323b-89ec-8064-ba6e-c5ca7689ed67'

# ----------------------------------------------------------------------
# Database creation
# ----------------------------------------------------------------------

def create_database(parent_page_id: str, title: str, properties: Dict[str, Any]) -> Dict:
    """Create a Notion database."""
    url = 'https://api.notion.com/v1/databases'
    payload = {
        'parent': {'type': 'page_id', 'page_id': parent_page_id},
        'title': [{'text': {'content': title}}],
        'properties': properties,
        'is_inline': True
    }
    resp = requests.post(url, headers=HEADERS, json=payload)
    resp.raise_for_status()
    db = resp.json()
    print(f'✓ Created database: {title} ({db["id"]})')
    # Extract data_source_id for later queries
    data_source_id = db.get('data_sources', [{}])[0].get('id') if db.get('data_sources') else None
    return {'database_id': db['id'], 'data_source_id': data_source_id, 'raw': db}

# End-of-Life Planning properties
eol_properties = {
    'Task': {'title': {}},
    'Category': {
        'select': {
            'options': [
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Medical', 'color': 'red'},
                {'name': 'Financial', 'color': 'green'},
                {'name': 'Personal', 'color': 'purple'},
                {'name': 'Digital', 'color': 'orange'},
                {'name': 'Funeral', 'color': 'brown'}
            ]
        }
    },
    'Status': {
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'On Hold', 'color': 'orange'}
            ]
        }
    },
    'Priority': {
        'select': {
            'options': [
                {'name': 'High', 'color': 'red'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'blue'}
            ]
        }
    },
    'Due Date': {'date': {}},
    'Assigned To': {'rich_text': {}},
    'Notes': {'rich_text': {}},
    'Completed Date': {'date': {}},
    'Documents': {'files': {}},
    'Dart Task ID': {'rich_text': {}},
    'Related Person': {'rich_text': {}}
}

# After-Death Checklist properties
after_death_properties = {
    'Task': {'title': {}},
    'Category': {
        'select': {
            'options': [
                {'name': 'Immediate (24h)', 'color': 'red'},
                {'name': 'Within Week', 'color': 'orange'},
                {'name': 'Within Month', 'color': 'yellow'},
                {'name': 'Long-term', 'color': 'green'},
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Financial', 'color': 'purple'},
                {'name': 'Administrative', 'color': 'pink'}
            ]
        }
    },
    'Status': {
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'Delegated', 'color': 'blue'}
            ]
        }
    },
    'Priority': {
        'select': {
            'options': [
                {'name': 'Critical', 'color': 'red'},
                {'name': 'High', 'color': 'orange'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'green'}
            ]
        }
    },
    'Due Date': {'date': {}},
    'Assigned To': {'rich_text': {}},
    'Notes': {'rich_text': {}},
    'Completed Date': {'date': {}},
    'Contact Info': {'rich_text': {}},
    'Documents': {'files': {}},
    'Dart Task ID': {'rich_text': {}}
}

# ----------------------------------------------------------------------
# Add sample tasks
# ----------------------------------------------------------------------

def add_page_to_database(database_id: str, properties: Dict[str, Any]) -> Dict:
    """Add a page (row) to a Notion database."""
    url = 'https://api.notion.com/v1/pages'
    payload = {
        'parent': {'database_id': database_id},
        'properties': properties
    }
    resp = requests.post(url, headers=HEADERS, json=payload)
    resp.raise_for_status()
    return resp.json()

# Pre-death sample tasks
eol_sample_tasks = [
    {
        'Task': 'Update Will',
        'Category': 'Legal',
        'Status': 'Not Started',
        'Priority': 'High',
        'Notes': 'Ensure will reflects current wishes, executor appointed.',
        'Due Date': '2026-03-01'
    },
    {
        'Task': 'Create Advance Care Directive',
        'Category': 'Medical',
        'Status': 'Not Started',
        'Priority': 'High',
        'Notes': 'Document preferences for medical treatment, DNR if desired.',
        'Due Date': '2026-03-01'
    },
    {
        'Task': 'Organise Power of Attorney',
        'Category': 'Legal',
        'Status': 'Not Started',
        'Priority': 'High',
        'Notes': 'Both financial and medical POA.',
        'Due Date': '2026-03-01'
    },
    {
        'Task': 'List all financial accounts',
        'Category': 'Financial',
        'Status': 'Not Started',
        'Priority': 'Medium',
        'Notes': 'Bank accounts, investments, insurance policies, superannuation.',
        'Due Date': '2026-03-07'
    },
    {
        'Task': 'Compile digital passwords',
        'Category': 'Digital',
        'Status': 'Not Started',
        'Priority': 'Medium',
        'Notes': 'Secure password manager or encrypted list.',
        'Due Date': '2026-03-07'
    },
    {
        'Task': 'Discuss funeral wishes',
        'Category': 'Funeral',
        'Status': 'Not Started',
        'Priority': 'Medium',
        'Notes': 'Burial/cremation, service details, music, readings.',
        'Due Date': '2026-03-07'
    },
    {
        'Task': 'Notify family of location of important documents',
        'Category': 'Personal',
        'Status': 'Not Started',
        'Priority': 'Low',
        'Notes': 'Will, insurance, property titles, etc.',
        'Due Date': '2026-03-14'
    },
]

# Post-death sample tasks
after_death_sample_tasks = [
    {
        'Task': 'Obtain Medical Certificate of Cause of Death',
        'Category': 'Immediate (24h)',
        'Status': 'Not Started',
        'Priority': 'Critical',
        'Notes': 'From attending doctor or hospital.',
        'Due Date': ''
    },
    {
        'Task': 'Contact funeral home',
        'Category': 'Immediate (24h)',
        'Status': 'Not Started',
        'Priority': 'Critical',
        'Notes': 'Arrange collection of body and discuss funeral arrangements.',
        'Due Date': ''
    },
    {
        'Task': 'Notify immediate family and close friends',
        'Category': 'Immediate (24h)',
        'Status': 'Not Started',
        'Priority': 'High',
        'Notes': 'Phone calls, then formal notifications.',
        'Due Date': ''
    },
    {
        'Task': 'Register death',
        'Category': 'Within Week',
        'Status': 'Not Started',
        'Priority': 'High',
        'Notes': 'At local registry, need medical certificate.',
        'Due Date': ''
    },
    {
        'Task': 'Arrange funeral service',
        'Category': 'Within Week',
        'Status': 'Not Started',
        'Priority': 'High',
        'Notes': 'Coordinate with funeral home, set date/time.',
        'Due Date': ''
    },
    {
        'Task': 'Notify bank and financial institutions',
        'Category': 'Within Week',
        'Status': 'Not Started',
        'Priority': 'Medium',
        'Notes': 'Provide death certificate, freeze accounts.',
        'Due Date': ''
    },
    {
        'Task': 'Cancel utilities, subscriptions',
        'Category': 'Within Month',
        'Status': 'Not Started',
        'Priority': 'Medium',
        'Notes': 'Electricity, phone, streaming services.',
        'Due Date': ''
    },
    {
        'Task': 'Apply for probate',
        'Category': 'Long-term',
        'Status': 'Not Started',
        'Priority': 'Medium',
        'Notes': 'If estate value exceeds threshold.',
        'Due Date': ''
    },
    {
        'Task': 'Distribute assets according to will',
        'Category': 'Long-term',
        'Status': 'Not Started',
        'Priority': 'Low',
        'Notes': 'After probate granted.',
        'Due Date': ''
    },
]

def property_map(task: Dict, db_type: str) -> Dict[str, Any]:
    """Convert task dict to Notion property format."""
    props = {}
    for key, value in task.items():
        if key == 'Task':
            props['Task'] = {'title': [{'text': {'content': value}}]}
        elif key == 'Category':
            props['Category'] = {'select': {'name': value}}
        elif key == 'Status':
            props['Status'] = {'select': {'name': value}}
        elif key == 'Priority':
            props['Priority'] = {'select': {'name': value}}
        elif key == 'Due Date' and value:
            props['Due Date'] = {'date': {'start': value}}
        elif key == 'Notes':
            props['Notes'] = {'rich_text': [{'text': {'content': value}}]}
    # Add empty required properties
    if 'Assigned To' not in props:
        props['Assigned To'] = {'rich_text': []}
    if 'Completed Date' not in props:
        props['Completed Date'] = {'date': None}
    if 'Documents' not in props:
        props['Documents'] = {'files': []}
    if 'Dart Task ID' not in props:
        props['Dart Task ID'] = {'rich_text': []}
    if db_type == 'eol' and 'Related Person' not in props:
        props['Related Person'] = {'rich_text': []}
    if db_type == 'after_death' and 'Contact Info' not in props:
        props['Contact Info'] = {'rich_text': []}
    return props

# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main():
    print('Setting up End-of-Life Planning and After-Death Checklist...')
    
    # 1. Create databases
    try:
        eol_db = create_database(PARENT_PAGE_ID, 'End-of-Life Planning', eol_properties)
    except Exception as e:
        print(f'Failed to create End-of-Life Planning: {e}')
        return
    
    try:
        ad_db = create_database(PARENT_PAGE_ID, 'After-Death Checklist', after_death_properties)
    except Exception as e:
        print(f'Failed to create After-Death Checklist: {e}')
        return
    
    # 2. Add sample tasks
    print('\nAdding sample tasks to End-of-Life Planning...')
    for task in eol_sample_tasks:
        try:
            props = property_map(task, 'eol')
            add_page_to_database(eol_db['database_id'], props)
            print(f'  ✓ {task["Task"]}')
        except Exception as e:
            print(f'  ✗ {task["Task"]}: {e}')
    
    print('\nAdding sample tasks to After-Death Checklist...')
    for task in after_death_sample_tasks:
        try:
            props = property_map(task, 'after_death')
            add_page_to_database(ad_db['database_id'], props)
            print(f'  ✓ {task["Task"]}')
        except Exception as e:
            print(f'  ✗ {task["Task"]}: {e}')
    
    # 3. Save IDs for reference
    ids = {
        'end_of_life': eol_db,
        'after_death': ad_db
    }
    with open('eol_database_ids.json', 'w') as f:
        json.dump(ids, f, indent=2)
    print('\n✅ Setup complete.')
    print(f'End-of-Life Planning database ID: {eol_db["database_id"]}')
    print(f'After-Death Checklist database ID: {ad_db["database_id"]}')
    print('IDs saved to eol_database_ids.json')

if __name__ == '__main__':
    main()