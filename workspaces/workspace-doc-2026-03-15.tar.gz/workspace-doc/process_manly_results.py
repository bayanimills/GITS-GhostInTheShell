#!/usr/bin/env python3
import os
import requests
import json
import re

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Data extracted from browser
extracted = [
    {
        "name": "HyeCare",
        "location": " RETIREMENT LIVING\\nHyeCare\\nWilloughby, NSW 2068",
        "provider": "Hyegrove",
        "url": "https://www.agedcareguide.com.au/hyecare"
    },
    {
        "name": "Elizabeth Jenkins Place Aged Care Centre",
        "location": "AGED CARE HOME\\nElizabeth Jenkins Place Aged Care Centre\\nCollaroy, NSW 2097",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/elizabeth-jenkins-place-aged-care-centre"
    },
    {
        "name": "Woodport Aged Care Centre",
        "location": " SUPPORT AT HOME PROGRAM\\nWoodport Aged Care Centre\\nErina, NSW 2250",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/woodport-aged-care-centre"
    },
    {
        "name": "Macquarie Lodge Aged Care Centre",
        "location": " IN HOME CARE\\nMacquarie Lodge Aged Care Centre\\nArncliffe, NSW 2205",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/macquarie-lodge-aged-care-centre"
    },
    {
        "name": "Willowood Centre",
        "location": "AGED CARE HOME\\nWillowood Centre\\nChatswood, NSW 2067",
        "provider": "Columbia Aged Care Services",
        "url": "https://www.agedcareguide.com.au/willowood-centre"
    },
    {
        "name": "Manly Vale Aged Care",
        "location": "AGED CARE HOME\\nManly Vale Aged Care\\nManly Vale, NSW 2093",
        "provider": "Hardi Aged Care",
        "url": "https://www.agedcareguide.com.au/manly-vale-aged-care"
    },
    {
        "name": "Uniting Wesley Heights Manly",
        "location": "AGED CARE HOME\\nUniting Wesley Heights Manly\\nManly, NSW 2095",
        "provider": "Uniting Residential Care",
        "url": "https://www.agedcareguide.com.au/uniting-wesley-heights-manly"
    },
    {
        "name": "Narraweena Grove Care Community",
        "location": "AGED CARE HOME\\nNarraweena Grove Care Community\\nNarraweena, NSW 2099",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/narraweena-grove-care-community"
    },
    {
        "name": "Manly Hillside Care Community",
        "location": "AGED CARE HOME\\nManly Hillside Care Community\\nNorth Manly, NSW 2100",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/manly-hillside-care-community"
    },
    {
        "name": "Bupa Mosman",
        "location": "AGED CARE HOME\\nBupa Mosman\\nMosman, NSW 2088",
        "provider": "Bupa Aged Care",
        "url": "https://www.agedcareguide.com.au/bupa-mosman"
    },
    {
        "name": "Uniting The Garrison Mosman",
        "location": "AGED CARE HOME\\nUniting The Garrison Mosman\\nMosman, NSW 2088",
        "provider": "Uniting Residential Care",
        "url": "https://www.agedcareguide.com.au/uniting-the-garrison-mosman"
    },
    {
        "name": "Bupa Seaforth",
        "location": "AGED CARE HOME\\nBupa Seaforth\\nSeaforth, NSW 2092",
        "provider": "Bupa Aged Care",
        "url": "https://www.agedcareguide.com.au/bupa-seaforth"
    },
    {
        "name": "JMV North Sydney",
        "location": " RETIREMENT LIVING\\nJMV North Sydney\\nNorth Sydney, NSW 2060",
        "provider": "James Milson Village",
        "url": "https://www.agedcareguide.com.au/jmv-north-sydney"
    },
    {
        "name": "Lansdowne Gardens",
        "location": "AGED CARE HOME\\nLansdowne Gardens\\nNeutral Bay, NSW 2089",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/lansdowne-gardens"
    },
    {
        "name": "Bupa Willoughby",
        "location": "AGED CARE HOME\\nBupa Willoughby\\nWilloughby, NSW 2068",
        "provider": "Bupa Aged Care",
        "url": "https://www.agedcareguide.com.au/bupa-willoughby"
    }
]

# Northern Beaches suburbs (postcodes 2084-2109, but we'll use list)
northern_beaches_suburbs = {
    "Manly Vale", "Manly", "Narraweena", "North Manly", "Seaforth",
    "Frenchs Forest", "Dee Why", "Narrabeen", "Allambie Heights",
    "Balgowlah", "Freshwater", "Curl Curl", "Collaroy", "Mona Vale",
    "Warriewood", "Newport", "Avalon", "Palm Beach", "Clareville",
    "North Narrabeen", "Elanora Heights", "Ingleside", "Terrey Hills",
    "Belrose", "Davidson", "Forestville", "Killarney Heights",
    "Brookvale", "Cromer", "North Curl Curl", "North Manly",
    "Oxford Falls", "Queenscliff", "Fairlight", "Clontarf",
    "North Balgowlah", "Balgowlah Heights", "Collaroy Plateau",
    "Narraweena", "Wheeler Heights", "Beacon Hill", "Cottage Point",
    "Church Point", "Bayview", "Scotland Island", "Great Mackerel Beach",
    "Coasters Retreat", "Lovett Bay", "Elvina Bay", "Morning Bay",
    "Bilgola", "Bilgola Plateau", "Whale Beach"
}

def extract_suburb_postcode(location):
    """Extract suburb and postcode from location string."""
    lines = location.split('\\n')
    for line in lines:
        match = re.search(r'([A-Za-z\s]+),\s*NSW\s+(\d{4})', line)
        if match:
            suburb = match.group(1).strip()
            postcode = match.group(2).strip()
            return suburb, postcode
    return None, None

# Filter Northern Beaches facilities
filtered = []
for item in extracted:
    suburb, postcode = extract_suburb_postcode(item['location'])
    if suburb and postcode and suburb in northern_beaches_suburbs:
        filtered.append({
            'name': item['name'],
            'suburb': suburb,
            'postcode': postcode,
            'provider': item['provider'],
            'url': item['url']
        })

print(f"Found {len(filtered)} Northern Beaches facilities:")
for f in filtered:
    print(f"  {f['name']} - {f['suburb']} {f['postcode']}")

# Fetch existing pages to avoid duplicates
print("\nFetching existing pages from Notion...")
resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
                     headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Error fetching existing pages: {resp.text}")
    exit(1)

existing_names = set()
for page in resp.json().get('results', []):
    props = page.get('properties', {})
    name_obj = props.get('Name', {}).get('title', [])
    if name_obj:
        existing_names.add(name_obj[0].get('text', {}).get('content', '').strip())

print(f"Existing entries: {len(existing_names)}")

# Add new pages
added = 0
for facility in filtered:
    if facility['name'] in existing_names:
        print(f"Skipping duplicate: {facility['name']}")
        continue
    
    payload = {
        "parent": {"database_id": "6088ea51-fa49-4102-a6fb-250eccc9f1ad"},
        "properties": {
            "Name": {
                "title": [{"type": "text", "text": {"content": facility['name']}}]
            },
            "Address": {
                "rich_text": [{"type": "text", "text": {"content": f"{facility['suburb']}, NSW {facility['postcode']}"}}]
            },
            "Website": {
                "url": facility['url']
            },
            "Service Type": {
                "select": {"name": "Nursing Home"}
            },
            "Status": {
                "select": {"name": "Not Contacted"}
            },
            "Suburb": {
                "rich_text": [{"type": "text", "text": {"content": facility['suburb']}}]
            },
            "Postcode": {
                "rich_text": [{"type": "text", "text": {"content": facility['postcode']}}]
            },
            "Notes": {
                "rich_text": [{"type": "text", "text": {"content": f"Provider: {facility['provider']}. Source: agedcareguide.com.au"}}]
            }
        }
    }
    
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    if resp.status_code == 200:
        added += 1
        print(f"Added: {facility['name']}")
    else:
        print(f"Failed to add {facility['name']}: {resp.status_code} {resp.text[:200]}")

print(f"\nTotal added: {added}")