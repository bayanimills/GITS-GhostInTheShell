import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

data_source_id = '562af9af-f953-4bdb-92d7-ebb0c3020f4c'

# 1. Get current data source
url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
resp = requests.get(url, headers=HEADERS)
if resp.status_code != 200:
    print('Failed to get data source:', resp.text)
    exit()
ds = resp.json()
print('Current properties:', list(ds.get('properties', {}).keys()))

# 2. Prepare updated properties (merge)
properties = ds.get('properties', {})

# Add new properties
new_props = {
    'Task': {'name': 'Task', 'type': 'title', 'title': {}},  # rename Name to Task? Actually title property must be 'Name'? We'll keep Name as title.
    'Category': {
        'name': 'Category',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Medical', 'color': 'red'},
                {'name': 'Financial', 'color': 'green'},
                {'name': 'Personal', 'color': 'purple'},
                {'name': 'Digital', 'color': 'orange'},
                {'name': 'Funeral', 'color': 'brown'}
            ]
        }
    },
    'Status': {
        'name': 'Status',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'On Hold', 'color': 'orange'}
            ]
        }
    },
    'Priority': {
        'name': 'Priority',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'High', 'color': 'red'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'blue'}
            ]
        }
    },
    'Due Date': {'name': 'Due Date', 'type': 'date', 'date': {}},
    'Assigned To': {'name': 'Assigned To', 'type': 'rich_text', 'rich_text': {}},
    'Notes': {'name': 'Notes', 'type': 'rich_text', 'rich_text': {}},
    'Completed Date': {'name': 'Completed Date', 'type': 'date', 'date': {}},
    'Documents': {'name': 'Documents', 'type': 'files', 'files': {}},
    'Dart Task ID': {'name': 'Dart Task ID', 'type': 'rich_text', 'rich_text': {}},
    'Related Person': {'name': 'Related Person', 'type': 'rich_text', 'rich_text': {}}
}

# Replace existing 'Name' with 'Task'? Let's rename 'Name' to 'Task' for consistency.
# We'll keep 'Name' as title property but rename its display name.
if 'Name' in properties:
    properties['Name']['name'] = 'Task'  # change display name
    # Also change key? Not needed.

# Merge new properties, skipping duplicates
for key, prop in new_props.items():
    if key not in properties:
        properties[key] = prop
    else:
        print(f'Property {key} already exists')

print('Updated properties count:', len(properties))

# 3. Update data source
update_payload = {'properties': properties}
print('Payload:', json.dumps(update_payload, indent=2))
patch_url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
patch_resp = requests.patch(patch_url, headers=HEADERS, json=update_payload)
print(f'PATCH status: {patch_resp.status_code}')
print(f'Response: {patch_resp.text}')
if patch_resp.status_code != 200:
    print('Update failed')
else:
    print('Update successful')