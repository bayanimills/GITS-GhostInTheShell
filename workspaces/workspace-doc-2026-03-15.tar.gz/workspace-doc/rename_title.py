import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def rename_title_property(data_source_id, new_name='Task'):
    url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
    resp = requests.get(url, headers=HEADERS)
    if resp.status_code != 200:
        print(f'Failed to get data source: {resp.text}')
        return
    ds = resp.json()
    props = ds.get('properties', {})
    if 'Name' not in props:
        print('Name property not found')
        return
    props['Name']['name'] = new_name
    patch_payload = {'properties': props}
    patch_resp = requests.patch(url, headers=HEADERS, json=patch_payload)
    print(f'PATCH status: {patch_resp.status_code}')
    if patch_resp.status_code == 200:
        print(f'Renamed Name to {new_name}')
    else:
        print(f'Error: {patch_resp.text}')

print('Renaming End-of-Life Planning title property...')
rename_title_property('562af9af-f953-4bdb-92d7-ebb0c3020f4c', 'Task')
print('\nRenaming After-Death Checklist title property...')
rename_title_property('7343ed8d-de9a-42ae-a787-c18f686dac1e', 'Task')