#!/usr/bin/env python3
import os
import requests
import json

DART_API_TOKEN = os.environ.get('DART_API_TOKEN', 'dsa_a7b1005833763314be91a023ad521d628e98f9413932f6a0a3e6fdd52f807ae3')
BASE_URL = 'https://app.dartai.com/api/v0/public'

headers = {
    'Authorization': f'Bearer {DART_API_TOKEN}',
    'Content-Type': 'application/json'
}

task_ids = [
    'v9xc8FDPj37G',  # Update Will
    'XSubroMB3jZ2',  # Advance Care Directive
    'JzVc6QAxnLFF',  # Power of Attorney
    'nU67ySKCHyED',  # Palliative care assessment
]

for tid in task_ids:
    try:
        response = requests.get(f'{BASE_URL}/tasks/{tid}', headers=headers)
        if response.status_code == 200:
            task = response.json()
            print(f"{task.get('name', 'Unknown')}")
            print(f"  ID: {tid}")
            print(f"  Status: {task.get('status', {}).get('name', 'Unknown')}")
            print(f"  Tags: {task.get('tags', [])}")
            print(f"  Updated: {task.get('updatedAt', 'Unknown')}")
            print()
        else:
            print(f"Error fetching {tid}: {response.status_code} {response.text}")
    except Exception as e:
        print(f"Exception: {e}")
        print()