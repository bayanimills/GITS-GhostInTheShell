#!/usr/bin/env python3
import os
import requests
import json

NOTION_KEY = open("/home/agent/.config/notion/api_key").read().strip()
DATASOURCE_ID = "eec8bbe9-0cbe-4abe-8b82-04124bebe030"
HEADERS = {
    "Authorization": f"Bearer {NOTION_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json"
}

def get_data_source():
    url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}"
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        print(f"Failed to get data source: {response.status_code} {response.text}")
        return None
    return response.json()

def update_data_source(new_properties):
    url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}"
    payload = {"properties": new_properties}
    response = requests.patch(url, headers=HEADERS, json=payload)
    if response.status_code == 200:
        print("Data source updated successfully")
        return response.json()
    else:
        print(f"Update failed: {response.status_code} {response.text}")
        return None

def query_database():
    url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}/query"
    response = requests.post(url, headers=HEADERS, json={})
    if response.status_code != 200:
        print(f"Query failed: {response.status_code} {response.text}")
        return []
    return response.json().get("results", [])

def update_page(page_id, properties):
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    response = requests.patch(url, headers=HEADERS, json=payload)
    if response.status_code == 200:
        print(f"Updated page {page_id}")
        return True
    else:
        print(f"Update failed: {response.status_code} {response.text}")
        return False

def main():
    # 1. Get current options
    data = get_data_source()
    if not data:
        return
    props = data["properties"]
    rel_prop = props["Relationship"]
    options = rel_prop["select"]["options"]
    # Check if "Sister-in-Law's Husband" exists
    target_name = "Sister‑in‑Law’s Husband"
    exists = any(opt["name"] == target_name for opt in options)
    if not exists:
        # Add new option
        new_options = options.copy()
        new_options.append({"name": target_name, "color": "brown"})
        new_props = {"Relationship": {"select": {"options": new_options}}}
        update_data_source(new_props)
        print(f"Added new option '{target_name}'")
    else:
        print(f"Option '{target_name}' already exists")
    
    # 2. Find Brent Garth page
    pages = query_database()
    brent_page = None
    for page in pages:
        props = page.get("properties", {})
        name_obj = props.get("Name", {}).get("title", [])
        if name_obj and "Brent" in name_obj[0].get("plain_text", ""):
            brent_page = page
            break
    if not brent_page:
        print("Brent Garth page not found")
        return
    # 3. Update Brent's relationship
    success = update_page(brent_page["id"], {
        "Relationship": {"select": {"name": target_name}}
    })
    if success:
        print(f"Updated Brent Garth to '{target_name}'")
    else:
        print("Failed to update Brent")

if __name__ == "__main__":
    main()