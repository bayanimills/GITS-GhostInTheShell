#!/usr/bin/env python3
"""
Create Patient Tasks database in Edward Mills Notion workspace.
"""
import os
import requests
import json
import sys

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Parent page ID (Edward Mills workspace)
parent_page_id = "30dd323b-89ec-8064-ba6e-c5ca7689ed67"

payload = {
    "parent": {"type": "page_id", "page_id": parent_page_id},
    "title": [{"text": {"content": "Patient Tasks"}}],
    "is_inline": True,
    "properties": {
        "Name": {"title": {}},
        "Status": {
            "select": {
                "options": [
                    {"name": "To-do", "color": "red"},
                    {"name": "Doing", "color": "blue"},
                    {"name": "Done", "color": "green"}
                ]
            }
        },
        "Due Date": {"date": {}},
        "Priority": {
            "select": {
                "options": [
                    {"name": "Low", "color": "gray"},
                    {"name": "Medium", "color": "yellow"},
                    {"name": "High", "color": "red"}
                ]
            }
        },
        "Tags": {"multi_select": {}},
        "Phase": {
            "select": {
                "options": [
                    {"name": "Phase 1: Assessment & Planning", "color": "blue"},
                    {"name": "Phase 2: Facility Search", "color": "green"},
                    {"name": "Phase 3: Application & Approval", "color": "orange"},
                    {"name": "Phase 4: Financial & Legal", "color": "purple"},
                    {"name": "Phase 5: Move‑in", "color": "pink"},
                    {"name": "Phase 6: Post‑move", "color": "brown"}
                ]
            }
        },
        "Dart Task ID": {"rich_text": {}},
        "Last Synced": {"date": {}},
        "Notes": {"rich_text": {}}
    }
}

resp = requests.post("https://api.notion.com/v1/databases", headers=headers, json=payload)
if resp.status_code == 200:
    db = resp.json()
    print(f"Created database:")
    print(f"Database ID: {db['id']}")
    print("Keys:", db.keys())
    if 'data_source_id' in db:
        print(f"Data Source ID: {db['data_source_id']}")
    else:
        # maybe nested under something else
        print(json.dumps(db, indent=2))
    # Save to file for reference
    with open('patient_tasks_db.json', 'w') as f:
        json.dump(db, f, indent=2)
    print("Saved to patient_tasks_db.json")
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)