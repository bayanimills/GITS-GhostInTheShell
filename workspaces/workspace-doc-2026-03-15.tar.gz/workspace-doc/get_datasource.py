import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

data_source_id = 'f48b7e7b-cd23-45c5-9dcb-f1ad60af3e51'
url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
resp = requests.get(url, headers=HEADERS)
print(f'Status: {resp.status_code}')
if resp.status_code == 200:
    ds = resp.json()
    print('Properties:')
    for key, prop in ds.get('properties', {}).items():
        print(f'  {key}: {prop.get("type")}')
    print('\nFull:')
    print(json.dumps(ds, indent=2))
else:
    print(resp.text)