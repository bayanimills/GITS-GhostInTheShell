import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

data_source_id = 'f38f43f7-b2c8-4477-ae3d-7d17fa724891'
url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
resp = requests.get(url, headers=HEADERS)
print(f'Status: {resp.status_code}')
if resp.status_code == 200:
    ds = resp.json()
    print('Properties:')
    for key, prop in ds.get('properties', {}).items():
        print(f'  {key}: {prop.get("type")}')
    print('\nFull properties:')
    print(json.dumps(ds.get('properties', {}), indent=2))
else:
    print(resp.text)