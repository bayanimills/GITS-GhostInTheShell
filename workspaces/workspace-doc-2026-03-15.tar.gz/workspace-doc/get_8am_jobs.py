#!/usr/bin/env python3
import json

with open('/tmp/cron.json', 'r') as f:
    data = json.load(f)

for job in data.get('jobs', []):
    sched = job.get('schedule', {})
    if sched.get('kind') == 'cron' and sched.get('expr') == '0 8 * * *':
        name = job.get('name')
        agent = job.get('agentId')
        payload = job.get('payload', {})
        msg = payload.get('message', '') if payload.get('kind') == 'agentTurn' else ''
        print(f"{name} (agent: {agent})")
        if msg:
            print(f"  message: {msg[:200]}...")
        print()