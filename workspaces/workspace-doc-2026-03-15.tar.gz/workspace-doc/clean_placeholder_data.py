#!/usr/bin/env python3
import os
import requests
import json
import time

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

print("Fetching all pages...")
resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
                     headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Error fetching pages: {resp.text}")
    exit(1)

pages = resp.json().get('results', [])
print(f"Total pages: {len(pages)}")

real = []
placeholder = []

for page in pages:
    page_id = page['id']
    props = page.get('properties', {})
    name_obj = props.get('Name', {}).get('title', [])
    name = name_obj[0].get('text', {}).get('content', '').strip() if name_obj else 'Unknown'
    notes_obj = props.get('Notes', {}).get('rich_text', [])
    notes = notes_obj[0].get('text', {}).get('content', '') if notes_obj else ''
    website = props.get('Website', {}).get('url', '')
    
    # Real entries have either agedcareguide URL in Website or notes mention source
    is_real = ('agedcareguide.com.au' in website) or ('Source: agedcareguide.com.au' in notes)
    
    if is_real:
        real.append((page_id, name))
    else:
        placeholder.append((page_id, name))

print(f"\nReal entries ({len(real)}):")
for pid, name in real:
    print(f"  - {name}")

print(f"\nPlaceholder entries ({len(placeholder)}):")
for pid, name in placeholder:
    print(f"  - {name}")

if not placeholder:
    print("\nNo placeholder entries to delete.")
    exit(0)

print(f"\nDeleting {len(placeholder)} placeholder entries...")
deleted = 0
for pid, name in placeholder:
    print(f"  Deleting {name} ({pid})...")
    resp = requests.delete(f"https://api.notion.com/v1/pages/{pid}", headers=headers)
    if resp.status_code == 200:
        deleted += 1
        print(f"    Deleted")
    else:
        print(f"    Failed: {resp.status_code} {resp.text[:200]}")
    time.sleep(0.3)  # avoid rate limit

print(f"\nDeleted {deleted} placeholder entries.")
print(f"Remaining real entries: {len(real)}")