#!/usr/bin/env python3
import os
import requests
import json
import re

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Fetch all pages
print("Fetching existing pages...")
resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
                     headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Error fetching pages: {resp.text}")
    exit(1)

pages = resp.json().get('results', [])
print(f"Found {len(pages)} pages")

# Map name to page ID and existing properties
name_to_page = {}
for page in pages:
    props = page.get('properties', {})
    name_obj = props.get('Name', {}).get('title', [])
    if name_obj:
        name = name_obj[0].get('text', {}).get('content', '').strip()
        name_to_page[name] = page

# Update Manly Vale Aged Care with real provider and website
if 'Manly Vale Aged Care' in name_to_page:
    page_id = name_to_page['Manly Vale Aged Care']['id']
    # Current properties
    props = name_to_page['Manly Vale Aged Care']['properties']
    # Check if Website already filled
    website_obj = props.get('Website', {}).get('url', '')
    if not website_obj:
        print("Updating Manly Vale Aged Care with real data...")
        payload = {
            "properties": {
                "Website": {"url": "https://www.agedcareguide.com.au/manly-vale-aged-care"},
                "Notes": {
                    "rich_text": [{"type": "text", "text": {"content": "Provider: Hardi Aged Care. Source: agedcareguide.com.au"}}]
                }
            }
        }
        resp = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=payload)
        if resp.status_code == 200:
            print("  Updated")
        else:
            print(f"  Failed: {resp.status_code} {resp.text[:200]}")
    else:
        print("Manly Vale Aged Care already has website.")

# Add new facilities
new_facilities = [
    {
        "name": "Pacific Lodge Aged Care Centre",
        "suburb": "Collaroy",
        "postcode": "2097",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/pacific-lodge-aged-care-centre"
    },
    {
        "name": "Uniting Wesley Gardens Belrose",
        "suburb": "Belrose",
        "postcode": "2085",
        "provider": "Uniting Residential Care",
        "url": "https://www.agedcareguide.com.au/uniting-wesley-gardens-belrose"
    }
]

added = 0
for facility in new_facilities:
    if facility['name'] in name_to_page:
        print(f"Skipping duplicate: {facility['name']}")
        continue
    
    payload = {
        "parent": {"database_id": "6088ea51-fa49-4102-a6fb-250eccc9f1ad"},
        "properties": {
            "Name": {
                "title": [{"type": "text", "text": {"content": facility['name']}}]
            },
            "Address": {
                "rich_text": [{"type": "text", "text": {"content": f"{facility['suburb']}, NSW {facility['postcode']}"}}]
            },
            "Website": {
                "url": facility['url']
            },
            "Service Type": {
                "select": {"name": "Nursing Home"}
            },
            "Status": {
                "select": {"name": "Not Contacted"}
            },
            "Suburb": {
                "rich_text": [{"type": "text", "text": {"content": facility['suburb']}}]
            },
            "Postcode": {
                "rich_text": [{"type": "text", "text": {"content": facility['postcode']}}]
            },
            "Notes": {
                "rich_text": [{"type": "text", "text": {"content": f"Provider: {facility['provider']}. Source: agedcareguide.com.au"}}]
            }
        }
    }
    
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    if resp.status_code == 200:
        added += 1
        print(f"Added: {facility['name']}")
    else:
        print(f"Failed to add {facility['name']}: {resp.status_code} {resp.text[:200]}")

print(f"\nTotal new facilities added: {added}")

# Update placeholder entries with Service Type and Status if missing
print("\nUpdating placeholder entries with Service Type and Status...")
updated = 0
for name, page in name_to_page.items():
    props = page['properties']
    service_type = props.get('Service Type', {}).get('select', {}).get('name', '')
    status = props.get('Status', {}).get('select', {}).get('name', '')
    if not service_type or not status:
        payload = {}
        if not service_type:
            payload['Service Type'] = {"select": {"name": "Nursing Home"}}
        if not status:
            payload['Status'] = {"select": {"name": "Not Contacted"}}
        if payload:
            resp = requests.patch(f"https://api.notion.com/v1/pages/{page['id']}", headers=headers, json={'properties': payload})
            if resp.status_code == 200:
                updated += 1
                print(f"  Updated {name}")
            else:
                print(f"  Failed to update {name}: {resp.status_code}")

print(f"Updated {updated} placeholder entries.")