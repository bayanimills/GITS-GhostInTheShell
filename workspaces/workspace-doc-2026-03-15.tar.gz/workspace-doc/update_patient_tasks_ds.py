#!/usr/bin/env python3
import os
import requests
import json
import sys

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

patient_tasks_db = "37691f15-655f-4a54-a3eb-915692442433"

# Get database to find data source
resp = requests.get(f"https://api.notion.com/v1/databases/{patient_tasks_db}", headers=headers)
if resp.status_code != 200:
    print(f"Error fetching database: {resp.text}")
    sys.exit(1)
db = resp.json()
data_source_id = db["data_sources"][0]["id"]
print(f"Data source ID: {data_source_id}")

# Get current data source properties
resp = requests.get(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers)
if resp.status_code != 200:
    print(f"Error fetching data source: {resp.text}")
    sys.exit(1)
ds = resp.json()
print("Current properties:")
for key, val in ds.get("properties", {}).items():
    print(f"  {key}: {val}")

# Define the properties we want
new_properties = {
    "Status": {
        "select": {
            "options": [
                {"name": "To-do", "color": "red"},
                {"name": "Doing", "color": "blue"},
                {"name": "Done", "color": "green"}
            ]
        }
    },
    "Due Date": {"date": {}},
    "Priority": {
        "select": {
            "options": [
                {"name": "Low", "color": "gray"},
                {"name": "Medium", "color": "yellow"},
                {"name": "High", "color": "red"}
            ]
        }
    },
    "Tags": {"multi_select": {}},
    "Phase": {
        "select": {
            "options": [
                {"name": "Phase 1: Assessment & Planning", "color": "blue"},
                {"name": "Phase 2: Facility Search", "color": "green"},
                {"name": "Phase 3: Application & Approval", "color": "orange"},
                {"name": "Phase 4: Financial & Legal", "color": "purple"},
                {"name": "Phase 5: Move‑in", "color": "pink"},
                {"name": "Phase 6: Post‑move", "color": "brown"}
            ]
        }
    },
    "Dart Task ID": {"rich_text": {}},
    "Last Synced": {"date": {}},
    "Notes": {"rich_text": {}}
}

# Update data source with new properties
payload = {
    "properties": new_properties
}
resp = requests.patch(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers, json=payload)
print(f"\nUpdate status: {resp.status_code}")
if resp.status_code == 200:
    ds = resp.json()
    print("Updated data source properties:")
    for key, val in ds.get("properties", {}).items():
        print(f"  {key}: {val}")
else:
    print(resp.text)