#!/usr/bin/env python3
import json

with open('/tmp/cron.json', 'r') as f:
    data = json.load(f)

for job in data.get('jobs', []):
    delivery = job.get('delivery', {})
    if delivery.get('mode') == 'announce':
        print(f"{job.get('id')} | {job.get('name')}")
        print(f"  delivery: {json.dumps(delivery, indent=4)}")
        print(f"  lastStatus: {job.get('state', {}).get('lastStatus')}")
        print()