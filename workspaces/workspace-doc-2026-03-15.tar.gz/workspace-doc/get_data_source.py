#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

data_source_id = "e15f5b65-1def-4d95-83e0-066e18b08ac2"
resp = requests.get(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    ds = resp.json()
    print(json.dumps(ds, indent=2))
else:
    print(resp.text)