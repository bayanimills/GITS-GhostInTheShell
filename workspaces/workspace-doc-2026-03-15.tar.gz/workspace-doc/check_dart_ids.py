#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

def get_prop(page, prop_name, prop_type):
    prop = page.get('properties', {}).get(prop_name, {})
    if prop.get('type') != prop_type:
        return None
    if prop_type == 'title':
        titles = prop.get('title', [])
        if titles:
            return titles[0].get('plain_text', '')
        return ''
    elif prop_type == 'select':
        select = prop.get('select', {})
        if select is None:
            return None
        return select.get('name')
    elif prop_type == 'date':
        date = prop.get('date')
        if date is None:
            return None
        return date.get('start')
    elif prop_type == 'rich_text':
        rich_text = prop.get('rich_text', [])
        if rich_text:
            return rich_text[0].get('plain_text', '')
        return ''
    else:
        return None

response = requests.post(
    f'https://api.notion.com/v1/databases/{DATABASE_ID}/query',
    headers=headers,
    json={}
)
if response.status_code != 200:
    print(f"Error: {response.status_code} {response.text}")
    exit(1)

pages = response.json().get('results', [])
print(f"Total pages: {len(pages)}")
print()
for page in pages:
    task = get_prop(page, 'Task', 'title')
    status = get_prop(page, 'Status', 'select')
    dart_id = get_prop(page, 'Dart Task ID', 'rich_text')
    if dart_id:
        print(f"{task} | {status} | Dart ID: {dart_id}")
    else:
        print(f"{task} | {status} | No Dart ID")