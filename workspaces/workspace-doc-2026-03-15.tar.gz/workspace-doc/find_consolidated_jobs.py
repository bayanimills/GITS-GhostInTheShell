#!/usr/bin/env python3
import json

with open('/tmp/cron.json', 'r') as f:
    data = json.load(f)

for job in data.get('jobs', []):
    name = job.get('name', '')
    if 'Consolidated' in name or 'consolidated' in name.lower():
        print(f"{job.get('id')} | {name} | agent: {job.get('agentId')}")
        print(f"  schedule: {job.get('schedule', {})}")
        print(f"  delivery: {job.get('delivery', {})}")
        print()