import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json
import requests

# Notion
NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}
EOL_DATA_SOURCE_ID = '562af9af-f953-4bdb-92d7-ebb0c3020f4c'

# Create Dart task
client = DartClient()
task = client.create_task(
    title='Arrange palliative care assessment – Edward Mills',
    description='Given Edward’s current decline (unable to sit up, lift limbs, requires feeding), refer to palliative care team for symptom management and advance care planning.',
    dartboard='Edward Mills/Tasks',
    tags=['patient-edward-mills', 'medical', 'palliative'],
    dueAt='2026-02-25'
)
dart_id = task.get('id')
print(f'Dart task created: {dart_id}')

# Find Notion page for palliative task
url = f'https://api.notion.com/v1/data_sources/{EOL_DATA_SOURCE_ID}/query'
resp = requests.post(url, headers=HEADERS, json={})
if resp.status_code != 200:
    print(f'Query failed: {resp.text}')
    sys.exit(1)
results = resp.json().get('results', [])
target_page = None
for page in results:
    props = page.get('properties', {})
    for key, prop in props.items():
        if prop.get('type') == 'title':
            title_content = prop.get('title', [{}])[0].get('text', {}).get('content', '')
            if title_content == 'Arrange palliative care assessment':
                target_page = page
                break
    if target_page:
        break

if not target_page:
    print('Notion page not found')
    sys.exit(1)

page_id = target_page['id']
update_url = f'https://api.notion.com/v1/pages/{page_id}'
payload = {
    'properties': {
        'Dart Task ID': {'rich_text': [{'text': {'content': dart_id}}]}
    }
}
update_resp = requests.patch(update_url, headers=HEADERS, json=payload)
if update_resp.status_code == 200:
    print('Notion updated with Dart ID')
else:
    print(f'Notion update failed: {update_resp.text}')