# HEARTBEAT.md

# Keep this file empty (or with only comments) to skip heartbeat API calls.

# Add tasks below when you want the agent to check something periodically.

Do not include medication count in heartbeat responses.
Do not read patient_edward_william_mills_MEDICATIONS.json during heartbeats.
