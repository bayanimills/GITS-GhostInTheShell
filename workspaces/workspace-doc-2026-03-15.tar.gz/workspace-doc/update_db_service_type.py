#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
database_id = "e44b8f80-c9a1-4c09-a5e7-a14c03e2f8d3"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

payload = {
    "properties": {
        "Service Type": {
            "select": {
                "options": [
                    {"name": "Nursing Home", "color": "blue"},
                    {"name": "Retirement Village with Aged Care", "color": "green"},
                    {"name": "Aged Care Facility", "color": "purple"}
                ]
            }
        }
    }
}

resp = requests.patch(f"https://api.notion.com/v1/databases/{database_id}", headers=headers, json=payload)
if resp.status_code == 200:
    print("✅ Database updated with Service Type property.")
    db = resp.json()
    props = db.get('properties', {})
    if "Service Type" in props:
        print("   Property added successfully.")
else:
    print(f"❌ Error: {resp.status_code}")
    print(resp.text)