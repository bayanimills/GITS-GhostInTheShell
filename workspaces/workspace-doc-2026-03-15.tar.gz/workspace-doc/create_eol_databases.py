import os
import json
import requests
from typing import Dict, Any

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

# Parent page ID for Edward Mills workspace (from MEMORY.md)
PARENT_PAGE_ID = '30dd323b-89ec-8064-ba6e-c5ca7689ed67'

def create_data_source(parent_page_id: str, title: str, properties: Dict[str, Any]) -> Dict:
    """Create a Notion data source (database)."""
    url = 'https://api.notion.com/v1/data_sources'
    payload = {
        'parent': {'page_id': parent_page_id},
        'title': [{'text': {'content': title}}],
        'properties': properties,
        'is_inline': True
    }
    resp = requests.post(url, headers=HEADERS, json=payload)
    resp.raise_for_status()
    return resp.json()

# Define properties for End-of-Life Planning database
eol_properties = {
    'Task': {'title': {}},
    'Category': {
        'select': {
            'options': [
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Medical', 'color': 'red'},
                {'name': 'Financial', 'color': 'green'},
                {'name': 'Personal', 'color': 'purple'},
                {'name': 'Digital', 'color': 'orange'},
                {'name': 'Funeral', 'color': 'brown'}
            ]
        }
    },
    'Status': {
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'On Hold', 'color': 'orange'}
            ]
        }
    },
    'Priority': {
        'select': {
            'options': [
                {'name': 'High', 'color': 'red'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'blue'}
            ]
        }
    },
    'Due Date': {'date': {}},
    'Assigned To': {'rich_text': {}},
    'Notes': {'rich_text': {}},
    'Completed Date': {'date': {}},
    'Documents': {'files': {}},
    'Dart Task ID': {'rich_text': {}},
    'Related Person': {'rich_text': {}}
}

# Define properties for After-Death Checklist database
after_death_properties = {
    'Task': {'title': {}},
    'Category': {
        'select': {
            'options': [
                {'name': 'Immediate (24h)', 'color': 'red'},
                {'name': 'Within Week', 'color': 'orange'},
                {'name': 'Within Month', 'color': 'yellow'},
                {'name': 'Long-term', 'color': 'green'},
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Financial', 'color': 'purple'},
                {'name': 'Administrative', 'color': 'pink'}
            ]
        }
    },
    'Status': {
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'Delegated', 'color': 'blue'}
            ]
        }
    },
    'Priority': {
        'select': {
            'options': [
                {'name': 'Critical', 'color': 'red'},
                {'name': 'High', 'color': 'orange'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'green'}
            ]
        }
    },
    'Due Date': {'date': {}},
    'Assigned To': {'rich_text': {}},
    'Notes': {'rich_text': {}},
    'Completed Date': {'date': {}},
    'Contact Info': {'rich_text': {}},
    'Documents': {'files': {}},
    'Dart Task ID': {'rich_text': {}}
}

def main():
    print('Creating End-of-Life Planning database...')
    try:
        eol_db = create_data_source(PARENT_PAGE_ID, 'End-of-Life Planning', eol_properties)
        print(f'Created: {eol_db["id"]}')
        print(f'Data Source ID: {eol_db.get("data_source_id")}')
        print(f'Database ID: {eol_db.get("database_id")}')
        print(f'URL: https://notion.so/{eol_db["id"].replace("-", "")}')
    except Exception as e:
        print(f'Error creating End-of-Life Planning: {e}')
        return

    print('\nCreating After-Death Checklist database...')
    try:
        ad_db = create_data_source(PARENT_PAGE_ID, 'After-Death Checklist', after_death_properties)
        print(f'Created: {ad_db["id"]}')
        print(f'Data Source ID: {ad_db.get("data_source_id")}')
        print(f'Database ID: {ad_db.get("database_id")}')
        print(f'URL: https://notion.so/{ad_db["id"].replace("-", "")}')
    except Exception as e:
        print(f'Error creating After-Death Checklist: {e}')
        return

    # Save IDs to a file for reference
    ids = {
        'end_of_life': {
            'id': eol_db['id'],
            'data_source_id': eol_db.get('data_source_id'),
            'database_id': eol_db.get('database_id')
        },
        'after_death': {
            'id': ad_db['id'],
            'data_source_id': ad_db.get('data_source_id'),
            'database_id': ad_db.get('database_id')
        }
    }
    with open('eol_database_ids.json', 'w') as f:
        json.dump(ids, f, indent=2)
    print('\nDatabase IDs saved to eol_database_ids.json')

if __name__ == '__main__':
    main()