#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
database_id = "e44b8f80-c9a1-4c09-a5e7-a14c03e2f8d3"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/databases/{database_id}/query", headers=headers, json={})
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Total entries: {len(results)}")
    for r in results:
        props = r.get('properties', {})
        name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', 'No name')
        print(f"  - {name}")
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)