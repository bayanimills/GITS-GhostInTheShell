#!/usr/bin/env python3
import sys

with open('memory/2026-02-21.md', 'r') as f:
    content = f.read()

new_section = """
## 13:15 UTC – Removal of Placeholder Data

**Request:** User stated “I don't want placeholder data.”

**Actions taken:**

1. **Identified placeholder entries** (16 entries lacking “Source: agedcareguide.com.au” in Notes).
2. **Archived all placeholder entries** via Notion API (archived pages are moved to trash, no longer appear in database views).
3. **Database now contains only 12 real entries** scraped from agedcareguide.com.au, each with verified provider details, website URLs, suburb/postcode.

**Outcome:**
- Northern Beaches Nursing Homes database now contains exclusively real data.
- Placeholder entries archived; database size reduced to 12 verified facilities.
- Ready for care‑planning use without any placeholder content.

**Tags:** #notion #cleanup #real-data #no-placeholder
"""

with open('memory/2026-02-21.md', 'w') as f:
    f.write(content.rstrip() + '\n' + new_section)

print("Appended cleanup section.")