#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query", headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Failed: {resp.text}")
    exit(1)

pages = resp.json().get('results', [])
pairs = {}
for page in pages:
    props = page.get('properties', {})
    suburb_obj = props.get('Suburb', {}).get('rich_text', [])
    postcode_obj = props.get('Postcode', {}).get('rich_text', [])
    if suburb_obj and postcode_obj:
        suburb = suburb_obj[0].get('text', {}).get('content', '').strip()
        postcode = postcode_obj[0].get('text', {}).get('content', '').strip()
        if suburb and postcode:
            pairs[suburb] = postcode

print("Current suburb–postcode pairs in database:")
for sub, pc in sorted(pairs.items()):
    print(f"  {sub}: {pc}")

print(f"\nTotal unique suburbs: {len(pairs)}")

# Add known Northern Beaches suburbs not yet in database
known = {
    "Allambie Heights": "2100",
    "Avalon": "2107",
    "Balgowlah Heights": "2093",
    "Bayview": "2104",
    "Beacon Hill": "2100",
    "Belrose": "2085",
    "Bilgola": "2107",
    "Bilgola Plateau": "2107",
    "Brookvale": "2100",
    "Church Point": "2105",
    "Clareville": "2109",
    "Clontarf": "2093",
    "Coasters Retreat": "2108",
    "Collaroy": "2097",
    "Collaroy Plateau": "2097",
    "Cottage Point": "2084",
    "Cromer": "2099",
    "Curl Curl": "2096",
    "Davidson": "2085",
    "Duffys Forest": "2084",
    "Elanora Heights": "2101",
    "Elvina Bay": "2105",
    "Fairlight": "2094",
    "Forestville": "2087",
    "Great Mackerel Beach": "2108",
    "Ingleside": "2101",
    "Killarney Heights": "2087",
    "Lovett Bay": "2105",
    "Mona Vale": "2103",
    "Morning Bay": "2108",
    "Narraweena": "2099",
    "North Balgowlah": "2093",
    "North Curl Curl": "2099",
    "North Manly": "2095",
    "North Narrabeen": "2101",
    "Oxford Falls": "2100",
    "Palm Beach": "2108",
    "Queenscliff": "2096",
    "Scotland Island": "2105",
    "Terrey Hills": "2084",
    "Wheeler Heights": "2097",
    "Whale Beach": "2108",
    "Warriewood": "2102",
    "Newport": "2106",
    "Avalon": "2107",
    "Palm Beach": "2108",
    "Clareville": "2109",
    "Collaroy": "2097",
    "Curl Curl": "2096",
    "Freshwater": "2096",
    "Manly": "2095",
    "Manly Vale": "2093",
    "Seaforth": "2092",
    "Frenchs Forest": "2086",
    "Dee Why": "2099",
    "Narrabeen": "2101",
}

print("\nAll known Northern Beaches suburbs (including not in DB):")
all_subs = {**pairs, **known}
for sub, pc in sorted(all_subs.items()):
    print(f"  {sub}: {pc}")

print(f"\nTotal unique suburbs: {len(all_subs)}")

# Save to file for future reference
with open("northern_beaches_suburbs_postcodes.json", "w") as f:
    json.dump(all_subs, f, indent=2)
print("Saved mapping to northern_beaches_suburbs_postcodes.json")