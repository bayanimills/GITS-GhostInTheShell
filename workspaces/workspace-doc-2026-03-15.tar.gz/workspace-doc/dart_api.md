# Dart Public API Integration

## Overview
This workspace now includes a client for the Dart Public API, enabling task, document, comment, and project management directly from OpenClaw.

## Authentication
1. Obtain a Bearer token from Dart (Settings → API Tokens).
2. Set environment variable:
   ```bash
   export DART_API_TOKEN="your_token_here"
   ```
3. Alternatively, store token in `~/.openclaw/openclaw.json` under `skills.entries.dart.apiKey`.

## Client Usage

### Python Client
```python
from scripts.dart_client import DartClient

client = DartClient()  # uses DART_API_TOKEN env var

# List tasks
tasks = client.list_tasks(limit=10)

# Create a task
task = client.create_task("Buy milk", folder="folder_id")

# Add a comment
comment = client.create_comment(task["id"], "Remember organic!")

# Attach a URL
client.attach_url_to_task(task["id"], "https://example.com")

# Log time
client.track_time(task["id"], minutes=30, note="Research")
```

### Command Line
```bash
# Set token first
export DART_API_TOKEN="your_token"

# Check connectivity
python3 scripts/dart_client.py health

# List tasks (JSON output)
python3 scripts/dart_client.py list-tasks

# Create a task
python3 scripts/dart_client.py create-task "New task title"

# Get a task
python3 scripts/dart_client.py get-task <task_id>
```

## API Endpoints Covered
- **Tasks:** create, retrieve, update, list, move, attach URL, time tracking
- **Documents:** create, retrieve, update, list
- **Comments:** create, list
- **Folders:** retrieve, update
- **Views:** retrieve, update
- **Health check:** `/config`

## Integration Ideas
- **Email to Task:** Use `gog` skill to scan emails, create Dart tasks.
- **Calendar to Task:** Create tasks from upcoming events.
- **GitHub Issues Sync:** Mirror GitHub issues as Dart tasks.
- **Notion Sync:** Sync Dart tasks with Notion databases.
- **Daily Standup:** Generate summary of yesterday's tasks/comments.

## Next Steps
1. **Provide token** to enable API calls.
2. **Test connectivity** with `health` command.
3. **Explore existing data** by listing tasks/docs.
4. **Automate a workflow** (e.g., create task from this conversation).

## Files
- `dart_openapi.yaml` – Full OpenAPI spec
- `scripts/dart_client.py` – Python client
- `memory/2026-02-20.md` – Discovery notes
- `MEMORY.md` – Quick reference

## Notes
- The API supports OAuth2 but the client currently uses Bearer token for simplicity.
- All endpoints require authentication; 401 indicates invalid/missing token.
- Pagination parameters (`limit`, `offset`) are available on list endpoints.

## Tags
#dart #api #automation #task-management