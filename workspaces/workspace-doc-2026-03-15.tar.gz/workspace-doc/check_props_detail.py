import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def get_props_detail(data_source_id):
    url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
    resp = requests.get(url, headers=HEADERS)
    if resp.status_code == 200:
        ds = resp.json()
        props = ds.get('properties', {})
        for key, prop in props.items():
            print(f'  {key}: {prop.get("type")}')
    else:
        print(f'Error: {resp.status_code}')

print('End-of-Life Planning:')
get_props_detail('562af9af-f953-4bdb-92d7-ebb0c3020f4c')
print('\nAfter-Death Checklist:')
get_props_detail('7343ed8d-de9a-42ae-a787-c18f686dac1e')