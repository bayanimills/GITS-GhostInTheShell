#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

response = requests.post(
    f'https://api.notion.com/v1/databases/{DATABASE_ID}/query',
    headers=headers,
    json={}
)

if response.status_code != 200:
    print(f"Error querying database: {response.status_code} {response.text}")
    exit(1)

data = response.json()
results = data.get('results', [])

def get_prop(page, prop_name, prop_type):
    prop = page.get('properties', {}).get(prop_name, {})
    if prop.get('type') != prop_type:
        return None
    if prop_type == 'title':
        titles = prop.get('title', [])
        if titles:
            return titles[0].get('plain_text', '')
        return ''
    elif prop_type == 'select':
        select = prop.get('select', {})
        if select is None:
            return None
        return select.get('name')
    elif prop_type == 'date':
        date = prop.get('date')
        if date is None:
            return None
        return date.get('start')
    elif prop_type == 'rich_text':
        rich_text = prop.get('rich_text', [])
        if rich_text:
            return rich_text[0].get('plain_text', '')
        return ''
    else:
        return None

print(f"Found {len(results)} tasks in End-of-Life Planning database")
print()

keywords = ['will', 'advance care directive', 'funeral', 'advance directive']
matched = []
for page in results:
    task_name = get_prop(page, 'Task', 'title')
    if not task_name:
        continue
    for kw in keywords:
        if kw in task_name.lower():
            status = get_prop(page, 'Status', 'select') or 'No status'
            due_date = get_prop(page, 'Due Date', 'date') or 'No due date'
            completed = get_prop(page, 'Completed Date', 'date') or ''
            priority = get_prop(page, 'Priority', 'select') or ''
            matched.append((task_name, status, due_date, completed, priority))
            break

if matched:
    print("Matching tasks:")
    for task_name, status, due_date, completed, priority in matched:
        print(f"• {task_name}")
        print(f"  Status: {status}")
        print(f"  Due Date: {due_date}")
        print(f"  Priority: {priority}")
        if completed:
            print(f"  Completed: {completed}")
        print()
else:
    print("No tasks matched keywords.")