#!/usr/bin/env python3
"""
Wrapper script for Edward Mills Weekly Consolidated cron job.
Runs dashboard_report.py and check_stroke_task.py, captures output,
and sends via openclaw message send if there's any content.
"""
import subprocess
import sys
import os

def run_script(script_path, args=None):
    """Run a Python script and return (stdout, stderr, returncode)."""
    if not os.path.exists(script_path):
        return f"Script not found: {script_path}", "", 1
    cmd = [sys.executable, script_path]
    if args:
        cmd.extend(args)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", f"Timeout running {script_path}", 124
    except Exception as e:
        return "", f"Error running {script_path}: {e}", 1

def send_telegram(message):
    """Send message via openclaw CLI."""
    if not message or message.strip() == "":
        return False
    # Truncate if too long (Telegram limit ~4096 chars)
    if len(message) > 4000:
        message = message[:3997] + "..."
    cmd = ["openclaw", "message", "send", "--channel", "telegram", "--target", "548072941", "--message", message]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            print(f"Failed to send Telegram: {result.stderr}", file=sys.stderr)
            return False
        return True
    except Exception as e:
        print(f"Error sending Telegram: {e}", file=sys.stderr)
        return False

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    outputs = []
    
    # Run dashboard_report.py
    dashboard_path = os.path.join(script_dir, "dashboard_report.py")
    stdout1, stderr1, rc1 = run_script(dashboard_path)
    if stdout1:
        outputs.append(stdout1)
    if stderr1:
        outputs.append(f"Stderr from dashboard_report.py:\n{stderr1}")
    
    # Run check_stroke_task.py
    stroke_path = os.path.join(script_dir, "check_stroke_task.py")
    stdout2, stderr2, rc2 = run_script(stroke_path)
    if stdout2:
        outputs.append(stdout2)
    if stderr2:
        outputs.append(f"Stderr from check_stroke_task.py:\n{stderr2}")
    
    combined = "\n\n".join(outputs)
    
    # If there's any output, send via Telegram
    if combined.strip():
        success = send_telegram(combined)
        if not success:
            print("Failed to send Telegram message.", file=sys.stderr)
            sys.exit(1)
        else:
            print("Telegram message sent successfully.")
    else:
        print("No output to send.")
    
    # Determine overall exit code (non-zero if any script failed)
    if rc1 != 0 or rc2 != 0:
        sys.exit(1)
    sys.exit(0)

if __name__ == "__main__":
    main()