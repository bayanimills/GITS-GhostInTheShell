#!/usr/bin/env python3
"""
Consolidated morning daily tasks for Doc workspace.
Runs:
1. Edward Mills Daily Standup (dashboard_report.py)
2. Aged Care Database Daily Check (cron_check_updates.py)
Outputs combined results.
"""
import subprocess
import sys
import os

def run_script(script_path, args=None, cwd=None):
    """Run a Python script and capture its stdout/stderr."""
    cmd = [sys.executable, script_path]
    if args:
        cmd.extend(args)
    env = os.environ.copy()
    if cwd:
        env['OPENCLAW_WORKSPACE'] = cwd
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
            cwd=cwd,
            env=env
        )
        output = []
        if result.stdout.strip():
            output.append(result.stdout.strip())
        if result.stderr.strip():
            output.append(f"Stderr: {result.stderr.strip()}")
        return "\n".join(output), result.returncode
    except subprocess.TimeoutExpired:
        return "Timeout expired", 1
    except Exception as e:
        return f"Exception: {e}", 1

def main():
    workspace = "/home/agent/.openclaw/workspace-doc"
    outputs = []
    
    # 1. Dashboard report
    out1, code1 = run_script("scripts/dashboard_report.py", cwd=workspace)
    if code1 == 0:
        outputs.append("=== Edward Mills Daily Standup ===")
        outputs.append(out1 if out1 else "No output")
    else:
        outputs.append("=== Edward Mills Daily Standup FAILED ===")
        outputs.append(out1)
    
    # 2. Aged care check
    out2, code2 = run_script("skills/aged-care-transition/enhancements/cron_check_updates.py", cwd=workspace)
    if code2 == 0:
        outputs.append("\n=== Aged Care Database Daily Check ===")
        outputs.append(out2 if out2 else "No changes")
    else:
        outputs.append("\n=== Aged Care Database Daily Check FAILED ===")
        outputs.append(out2)
    
    combined = "\n".join(outputs)
    # If combined is empty or only separators, output NO_REPLY
    if combined.strip() and not combined.strip().startswith("==="):
        print(combined)
    else:
        # If no real content, output NO_REPLY to avoid spamming
        # but we need to output something for cron delivery? 
        # The cron job will capture stdout; if empty, it will send nothing.
        # We'll output a small status.
        print("Morning tasks completed. No new updates.")

if __name__ == "__main__":
    main()