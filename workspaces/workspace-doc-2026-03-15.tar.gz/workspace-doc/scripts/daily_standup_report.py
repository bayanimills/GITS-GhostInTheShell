#!/usr/bin/env python3
"""
Daily standup report for Edward Mills tasks.
Lists all tasks in Edward Mills/Tasks dartboard, their status, age, and flags stale tasks.
"""
import os
import sys
import json
from datetime import datetime, timezone, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dart_client import DartClient

def iso_to_datetime(iso_str: str) -> datetime:
    """Parse Dart's ISO timestamp (may end with Z or offset)."""
    iso_str = iso_str.replace('Z', '+00:00')
    return datetime.fromisoformat(iso_str)

def main():
    client = DartClient()
    tasks_resp = client.list_tasks()
    results = tasks_resp.get('results', [])
    edward_tasks = [t for t in results if t.get('dartboard', '').startswith('Edward Mills/')]
    
    now = datetime.now(timezone.utc)
    stale_threshold_days = 7
    report_lines = []
    
    for task in edward_tasks:
        task_id = task.get('id')
        title = task.get('title', 'Untitled')
        status = task.get('status', 'Unknown')
        updated_at_str = task.get('updatedAt')
        updated_at = iso_to_datetime(updated_at_str)
        age = now - updated_at
        age_days = age.days + age.seconds / 86400
        is_stale = age > timedelta(days=stale_threshold_days)
        url = task.get('htmlUrl', f'https://app.dartai.com/t/{task_id}')
        
        line = f"• [{title}]({url}) – {status}"
        line += f" – updated {age_days:.1f} days ago"
        if is_stale:
            line += " ⚠️ STALE"
        report_lines.append((age_days, line))
    
    # Sort by age descending
    report_lines.sort(key=lambda x: x[0], reverse=True)
    
    # Output
    print(f"📋 **Edward Mills Standup** – {now.date()}")
    print(f"Total tasks: {len(edward_tasks)}")
    for _, line in report_lines:
        print(line)
    # Check if any stale
    stale_count = sum(1 for task in edward_tasks 
                      if iso_to_datetime(task.get('updatedAt')) < now - timedelta(days=stale_threshold_days))
    if stale_count:
        print(f"\n🚨 {stale_count} task(s) stale (> {stale_threshold_days} days).")
    else:
        print(f"\n✅ All tasks updated within {stale_threshold_days} days.")

if __name__ == "__main__":
    main()