#!/usr/bin/env python3
"""
Consolidated Hourly Digest.
Runs the hourly digest tasks for donna (Gmail Skill) and main (Cron Manager).
"""
import os
import subprocess
import sys

TASKS = [
    {
        'name': 'Gmail Skill hourly digest',
        'workspace': '/home/agent/.openclaw/workspace-donna',
        'script': '/home/agent/.openclaw/workspace/skills/gmail-skill/scripts/monitor_gmail_enhanced.py',
        'cwd': '/home/agent/.openclaw/workspace/skills/gmail-skill',
    },
    {
        'name': 'Cron Manager Hourly Sync',
        'workspace': '/home/agent/.openclaw/workspace-main',
        'script': '/home/agent/.openclaw/workspace/skills/cron-manager/quick_monitor.py',
        'cwd': '/home/agent/.openclaw/workspace/skills/cron-manager',
    },
]

def run_task(task):
    """Run a single digest task."""
    env = os.environ.copy()
    env['OPENCLAW_WORKSPACE'] = task['workspace']
    try:
        result = subprocess.run(
            [sys.executable, task['script']],
            env=env,
            cwd=task['cwd'],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            output = result.stdout.strip()
            if output and output != "NO_REPLY":
                print(f"[{task['name']}] {output}")
            else:
                print(f"[{task['name']}] No output (NO_REPLY)")
        else:
            print(f"[{task['name']}] Error (code {result.returncode}): {result.stderr[:200]}")
    except subprocess.TimeoutExpired:
        print(f"[{task['name']}] Timeout after 5 minutes")
    except Exception as e:
        print(f"[{task['name']}] Exception: {e}")

def main():
    for task in TASKS:
        if os.path.isdir(task['workspace']) and os.path.isfile(task['script']):
            run_task(task)
        else:
            print(f"[{task['name']}] Missing workspace or script")
    # If no output printed, we still want the cron job to know it ran.
    # We'll print a minimal status line.
    print("Hourly digest consolidation completed.")
    sys.exit(0)

if __name__ == "__main__":
    main()