#!/usr/bin/env python3
"""
Send an email via AgentMail.
"""
import sys
import os

venv_path = "/home/agent/.openclaw/workspace-aria/venv/lib/python3.12/site-packages"
sys.path.insert(0, venv_path)

from agentmail import AgentMail

API_KEY = os.getenv("AGENTMAIL_API_KEY")
if not API_KEY:
    print("AGENTMAIL_API_KEY not set")
    sys.exit(1)

def send_email(to, subject, body, html_body=None):
    """
    Send an email via AgentMail.
    Returns message ID on success.
    """
    client = AgentMail(api_key=API_KEY)
    message = client.messages.create(
        to=to,
        subject=subject,
        body=body,
        html_body=html_body
    )
    return message.message_id

if __name__ == "__main__":
    # Example usage: python send_agentmail.py to subject body
    if len(sys.argv) < 4:
        print(f"Usage: {sys.argv[0]} <to> <subject> <body> [html_body]")
        sys.exit(1)
    to = sys.argv[1]
    subject = sys.argv[2]
    body = sys.argv[3]
    html_body = sys.argv[4] if len(sys.argv) > 4 else None
    try:
        msg_id = send_email(to, subject, body, html_body)
        print(f"✅ Email sent, message ID: {msg_id}")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        sys.exit(1)