#!/usr/bin/env python3
"""
Monitor ewm-contact@agentmail.to for new emails.
State is stored in workspace-doc/state/agentmail_last_seen.txt (stores last seen message ID).
"""
import sys
import os
import json
from datetime import datetime, timezone
from pathlib import Path

# Add workspace-aria venv site-packages
venv_path = "/home/agent/.openclaw/workspace-aria/venv/lib/python3.12/site-packages"
sys.path.insert(0, venv_path)

from agentmail import AgentMail

API_KEY = os.getenv("AGENTMAIL_API_KEY")
if not API_KEY:
    print("AGENTMAIL_API_KEY not set")
    sys.exit(1)

INBOX_ID = "ewm-contact@agentmail.to"
STATE_DIR = Path(__file__).parent.parent / "state"
STATE_FILE = STATE_DIR / "agentmail_last_seen.txt"
STATE_DIR.mkdir(exist_ok=True)

def load_last_seen():
    """Return last seen message ID, or None if not found."""
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return f.read().strip()
    return None

def save_last_seen(message_id):
    """Store last seen message ID."""
    with open(STATE_FILE, 'w') as f:
        f.write(message_id)

def main():
    client = AgentMail(api_key=API_KEY)
    last_seen_id = load_last_seen()
    
    try:
        messages = client.inboxes.messages.list(inbox_id=INBOX_ID, limit=20)
    except Exception as e:
        print(f"Failed to fetch messages: {e}")
        sys.exit(1)
    
    # Sort by created_at descending (newest first)
    recent = sorted(messages.messages, key=lambda m: m.created_at, reverse=True)
    new_messages = []
    
    if not recent:
        # No messages at all
        if last_seen_id is None:
            # First run, nothing to report
            print("NO_REPLY")
        else:
            # Inbox empty (maybe messages deleted) – reset state
            save_last_seen("")
            print("NO_REPLY")
        sys.exit(0)
    
    newest_id = recent[0].message_id
    if last_seen_id is None:
        # First run: store newest ID, don't report old messages
        save_last_seen(newest_id)
        print("NO_REPLY")
        sys.exit(0)
    
    # Find messages newer than last seen
    for msg in recent:
        if msg.message_id == last_seen_id:
            break
        new_messages.append(msg)
    
    # Report new messages (oldest first)
    for msg in reversed(new_messages):
        # Format notification
        print(f"📨 New email to {INBOX_ID}")
        print(f"   From: {msg.from_}")
        print(f"   Subject: {msg.subject}")
        print(f"   Date: {msg.created_at}")
        print(f"   ID: {msg.message_id}")
        # Optional: snippet of body? Not available in list endpoint.
        print()
    
    # Update last seen if there were new messages
    if new_messages:
        save_last_seen(newest_id)
    else:
        print("NO_REPLY")

if __name__ == "__main__":
    main()