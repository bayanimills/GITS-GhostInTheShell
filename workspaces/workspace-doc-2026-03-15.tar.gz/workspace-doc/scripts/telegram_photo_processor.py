#!/usr/bin/env python3
import os,sys,time,requests,json,subprocess
TOKEN='8129327749:AAEX0RQclQmtYhmc-dC0hx3R4xp-gSqYt64'
OFFSET_FILE='/home/agent/.openclaw/workspace-doc/scripts/processor_offset.json'
UPLOAD_DIR='/home/agent/.openclaw/workspace-doc/uploads'
OCR_TEXT_DIR='/home/agent/.openclaw/workspace-doc/memory/ocr_text'
PARSED_DIR='/home/agent/.openclaw/workspace-doc/memory/ocr_parsed'
os.makedirs(UPLOAD_DIR,exist_ok=True)
os.makedirs(OCR_TEXT_DIR,exist_ok=True)
os.makedirs(PARSED_DIR,exist_ok=True)
last=0
if os.path.exists(OFFSET_FILE):
    try:
        last=int(json.load(open(OFFSET_FILE)).get('offset',0))
    except:
        last=0
print('photo processor starting, last offset',last)

def send_message(chat_id, text, parse_mode='Markdown'):
    url=f'https://api.telegram.org/bot{TOKEN}/sendMessage'
    requests.post(url, data={'chat_id':chat_id,'text':text,'parse_mode':parse_mode}, timeout=15)

while True:
    try:
        url=f'https://api.telegram.org/bot{TOKEN}/getUpdates?timeout=20&offset={last+1}'
        r=requests.get(url,timeout=30)
        data=r.json()
        if not data.get('ok'):
            time.sleep(1); continue
        for upd in data.get('result',[]):
            last=upd['update_id']
            json.dump({'offset':last},open(OFFSET_FILE,'w'))
            msg=upd.get('message') or upd.get('edited_message')
            if not msg: continue
            chat_id=msg['chat']['id']
            # handle photos
            if 'photo' in msg:
                # pick largest
                photo=msg['photo'][-1]
                file_id=photo['file_id']
                # get file path
                r2=requests.get(f'https://api.telegram.org/bot{TOKEN}/getFile?file_id={file_id}',timeout=15).json()
                if not r2.get('ok'):
                    send_message(chat_id,'Failed to retrieve file metadata'); continue
                file_path=r2['result']['file_path']
                dl_url=f'https://api.telegram.org/file/bot{TOKEN}/{file_path}'
                fn=os.path.basename(file_path)
                save_path=os.path.join(UPLOAD_DIR,f"{int(time.time())}_{fn}")
                with requests.get(dl_url,stream=True,timeout=60) as resp:
                    resp.raise_for_status()
                    with open(save_path,'wb') as fh:
                        for chunk in resp.iter_content(8192):
                            fh.write(chunk)
                # run OCR (tesseract) to text
                txt_out=os.path.join(OCR_TEXT_DIR,os.path.basename(save_path)+'.txt')
                try:
                    subprocess.run(['tesseract',save_path,txt_out[:-4]],check=True,timeout=60)
                    with open(txt_out,'r',errors='ignore') as f: txt=f.read()
                except Exception as e:
                    txt=f'(OCR failed: {e})'
                    open(txt_out,'w').write(txt)
                # simple parser: extract lines containing numbers or mg
                lines=[l.strip() for l in txt.splitlines() if l.strip()]
                meds=[]
                for l in lines:
                    if any(token in l.lower() for token in ['mg','mcg','tablet','tab','ml']):
                        meds.append(l)
                parsed={'file':save_path,'text_sample':'\n'.join(lines[:10]),'med_candidates':meds,'full_text_len':len(txt)}
                json.dump(parsed,open(os.path.join(PARSED_DIR,os.path.basename(save_path)+'.json'),'w'),indent=2)
                # send ack with overview
                overview=f"Uploaded {os.path.basename(save_path)}\nCaptured {len(lines)} text lines. Found {len(meds)} medication-like candidates."
                details='\n'.join(meds[:10])
                send_message(chat_id, f"Acknowledged. Overview:\n{overview}\n\nDetails:\n{details}" )
            elif 'document' in msg:
                # similar flow for documents
                file_id=msg['document']['file_id']
                r2=requests.get(f'https://api.telegram.org/bot{TOKEN}/getFile?file_id={file_id}',timeout=15).json()
                if not r2.get('ok'):
                    send_message(chat_id,'Failed to retrieve file metadata'); continue
                file_path=r2['result']['file_path']
                fn=os.path.basename(file_path)
                save_path=os.path.join(UPLOAD_DIR,f"{int(time.time())}_{fn}")
                with requests.get(f'https://api.telegram.org/file/bot{TOKEN}/{file_path}',stream=True,timeout=60) as resp:
                    resp.raise_for_status()
                    with open(save_path,'wb') as fh:
                        for chunk in resp.iter_content(8192): fh.write(chunk)
                send_message(chat_id,f"Document saved: {os.path.basename(save_path)}. I will process when OCR configured.")
        time.sleep(0.2)
    except Exception as e:
        print('loop error',e)
        time.sleep(2)
