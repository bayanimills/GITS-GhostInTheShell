#!/usr/bin/env python3
import os
import requests
import json
import sys

NOTION_API_KEY = open('/home/agent/.config/notion/api_key').read().strip()
DATA_SOURCE_ID = 'e15f5b65-1def-4d95-83e0-066e18b08ac2'
HEADERS = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def query_medications():
    url = f'https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query'
    resp = requests.post(url, headers=HEADERS, json={})
    resp.raise_for_status()
    return resp.json()

def get_medications():
    data = query_medications()
    meds = []
    for page in data.get('results', []):
        props = page.get('properties', {})
        name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', 'Unknown')
        dose = props.get('Dose', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
        frequency = props.get('Frequency', {}).get('select', {}).get('name', '')
        meds.append({
            'name': name,
            'dose': dose,
            'frequency': frequency.lower()
        })
    return meds

def morning_meds(meds):
    # include daily, twice daily (morning), exclude 'at night'
    include = []
    for m in meds:
        freq = m['frequency']
        if 'daily' in freq and 'twice' not in freq:
            include.append(m)
        elif 'twice daily' in freq:
            include.append(m)
        # 'at night' excluded
    return include

def evening_meds(meds):
    # include twice daily (evening), at night
    include = []
    for m in meds:
        freq = m['frequency']
        if 'twice daily' in freq:
            include.append(m)
        elif 'at night' in freq:
            include.append(m)
    return include

def main():
    if len(sys.argv) < 2:
        print('Usage: medication_reminder.py [morning|evening]')
        sys.exit(1)
    time_arg = sys.argv[1].lower()
    meds = get_medications()
    if time_arg == 'morning':
        target = morning_meds(meds)
        time_label = 'Morning'
    elif time_arg == 'evening':
        target = evening_meds(meds)
        time_label = 'Evening'
    else:
        print('Invalid time argument')
        sys.exit(1)
    
    if not target:
        print(f'No medications scheduled for {time_label.lower()}.')
        return
    
    lines = [f'💊 **{time_label} Medications Reminder**']
    for m in target:
        lines.append(f'• {m["name"]} {m["dose"]} ({m["frequency"]})')
    lines.append('')
    lines.append('_Please ensure Edward takes these medications._')
    output = '\n'.join(lines)
    print(output)

if __name__ == '__main__':
    main()