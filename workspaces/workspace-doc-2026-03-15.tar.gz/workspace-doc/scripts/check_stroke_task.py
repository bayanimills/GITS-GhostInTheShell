#!/usr/bin/env python3
"""
Check if the stroke task has been updated within the last N days.
If not, send a reminder.
Designed to be run as a cron job.
"""
import os
import sys
import json
from datetime import datetime, timezone, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dart_client import DartClient

def main():
    task_id = "YhH8uggrObRf"
    max_days_no_update = 7
    
    client = DartClient()
    task = client.get_task(task_id)
    updated_at_str = task.get("updatedAt")
    # Parse ISO timestamp
    updated_at = datetime.fromisoformat(updated_at_str.replace('Z', '+00:00'))
    now = datetime.now(timezone.utc)
    age = now - updated_at
    if age > timedelta(days=max_days_no_update):
        # Generate reminder
        print(f"Reminder: Stroke task last updated {age.days} days ago.")
        print(f"Task: {task.get('title')}")
        print(f"URL: {task.get('htmlUrl')}")
        # This output will be captured by cron and sent as announcement
        # We'll rely on cron's delivery mode "announce"
        sys.exit(0)  # success with output
    else:
        print(f"Task updated {age.days} days ago, within threshold.")
        sys.exit(0)  # success, no reminder needed

if __name__ == "__main__":
    main()