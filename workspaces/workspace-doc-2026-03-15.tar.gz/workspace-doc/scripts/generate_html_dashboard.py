#!/usr/bin/env python3
"""
Generate HTML dashboard from dashboard_report.py output.
"""
import subprocess
import sys
import os
from datetime import datetime

def markdown_to_html(markdown_text):
    """Convert markdown to simple HTML."""
    # Very basic conversion: headers, bold, links, lists
    html = []
    lines = markdown_text.strip().split('\n')
    for line in lines:
        if line.startswith('🏥'):
            # Title
            html.append(f'<h1>{line}</h1>')
        elif line.startswith('**') and line.endswith('**'):
            # Bold header
            html.append(f'<h2>{line.strip("*")}</h2>')
        elif line.startswith('•'):
            # List item with link detection
            line = line[1:].strip()
            # Simple link detection: [text](url)
            import re
            line = re.sub(r'\[(.*?)\]\((.*?)\)', r'<a href="\2">\1</a>', line)
            html.append(f'<li>{line}</li>')
        elif line.strip() == '':
            html.append('<br>')
        else:
            # Paragraph
            html.append(f'<p>{line}</p>')
    # Wrap list items
    result = []
    in_list = False
    for line in html:
        if line.startswith('<li>'):
            if not in_list:
                result.append('<ul>')
                in_list = True
            result.append(line)
        else:
            if in_list:
                result.append('</ul>')
                in_list = False
            result.append(line)
    if in_list:
        result.append('</ul>')
    return '\n'.join(result)

def main():
    # Run dashboard_report.py
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cmd = [sys.executable, os.path.join(script_dir, 'dashboard_report.py')]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        markdown = result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Error running dashboard_report: {e}", file=sys.stderr)
        sys.exit(1)
    
    html_content = markdown_to_html(markdown)
    
    # Wrap in full HTML
    now = datetime.now().isoformat()
    full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edward Mills Dashboard</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
                line-height: 1.6; margin: 2em; max-width: 800px; }}
        h1 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 0.3em; }}
        h2 {{ color: #34495e; margin-top: 1.5em; }}
        ul {{ padding-left: 1.5em; }}
        li {{ margin-bottom: 0.5em; }}
        a {{ color: #2980b9; text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        .footer {{ margin-top: 3em; font-size: 0.9em; color: #7f8c8d; }}
    </style>
</head>
<body>
    {html_content}
    <div class="footer">
        <hr>
        <p>Generated {now} by Doc Agent (Aloysius Bexley)</p>
    </div>
</body>
</html>"""
    
    # Write to file
    output_path = os.path.join(script_dir, '..', 'dashboard.html')
    with open(output_path, 'w') as f:
        f.write(full_html)
    print(f"HTML dashboard written to {output_path}", file=sys.stderr)

if __name__ == '__main__':
    main()