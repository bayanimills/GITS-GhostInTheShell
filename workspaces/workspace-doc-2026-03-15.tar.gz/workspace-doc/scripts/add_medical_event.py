#!/usr/bin/env python3
"""
Add a medical event to Notion Medical Events database.
Usage: python3 add_medical_event.py "Event Name" "Event Type" "Date" "Hospital" "Status" "Notes"
"""
import os
import sys
import requests
import json
from datetime import datetime

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Medical Events database ID (from memory)
MEDICAL_EVENTS_DATABASE_ID = "30dd323b-89ec-8152-99a3-c4d72376bdeb"

def create_medical_event(name, event_type, date, hospital, status, notes=""):
    """Create a new page in Medical Events database."""
    url = "https://api.notion.com/v1/pages"
    payload = {
        "parent": {"database_id": MEDICAL_EVENTS_DATABASE_ID},
        "properties": {
            "Name": {
                "title": [{"text": {"content": name}}]
            },
            "Event Type": {
                "select": {"name": event_type}
            },
            "Date": {
                "date": {"start": date}
            },
            "Hospital": {
                "rich_text": [{"text": {"content": hospital}}]
            },
            "Status": {
                "select": {"name": status}
            },
            "Notes": {
                "rich_text": [{"text": {"content": notes}}]
            }
        }
    }
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=10)
    resp.raise_for_status()
    return resp.json()

if __name__ == "__main__":
    if len(sys.argv) < 6:
        print("Usage: python3 add_medical_event.py \"Event Name\" \"Event Type\" \"YYYY-MM-DD\" \"Hospital\" \"Status\" [notes]")
        sys.exit(1)
    name = sys.argv[1]
    event_type = sys.argv[2]
    date = sys.argv[3]
    hospital = sys.argv[4]
    status = sys.argv[5]
    notes = sys.argv[6] if len(sys.argv) > 6 else ""
    try:
        result = create_medical_event(name, event_type, date, hospital, status, notes)
        print(f"Created medical event: {result['id']}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)