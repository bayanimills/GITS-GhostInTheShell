#!/usr/bin/env python3
"""
Check whether a cron job has announce delivery and whether its last run succeeded.
Returns:
- 'NO_REPLY' if job has announce delivery and last run status is 'ok'
- 'CONVERT' otherwise (no announce delivery or status error)
"""

import subprocess
import json
import sys

def get_job_info(job_name: str):
    """Fetch cron list and find job by name."""
    try:
        result = subprocess.run(
            ['openclaw', 'cron', 'list', '--json'],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode != 0:
            print(f"Error running openclaw cron list: {result.stderr}", file=sys.stderr)
            return None
        data = json.loads(result.stdout)
        for job in data.get('jobs', []):
            if job.get('name') == job_name:
                return job
        return None
    except Exception as e:
        print(f"Exception: {e}", file=sys.stderr)
        return None

def main():
    if len(sys.argv) < 2:
        print("Usage: check_cron_delivery.py <job_name>")
        sys.exit(1)
    job_name = sys.argv[1]
    job = get_job_info(job_name)
    if not job:
        # Job not found – conservative: convert
        print("CONVERT")
        return
    
    delivery = job.get('delivery', {})
    mode = delivery.get('mode')
    state = job.get('state', {})
    last_status = state.get('lastStatus')
    # If delivery mode is 'announce' and last run status is 'ok', no reply
    if mode == 'announce' and last_status == 'ok':
        print("NO_REPLY")
    else:
        print("CONVERT")

if __name__ == '__main__':
    main()