#!/usr/bin/env python3
"""
Consolidated AWS 12h Completion Report.
Runs the aws-completion-report.py for each workspace.
"""
import os
import subprocess
import sys

# Workspaces to process (from existing AWS report jobs)
WORKSPACES = [
    "/home/agent/.openclaw/workspace-kaira",
    "/home/agent/.openclaw/workspace-aria",
    "/home/agent/.openclaw/workspace-danny",
    "/home/agent/.openclaw/workspace-doc",
    "/home/agent/.openclaw/workspace-donna",
    "/home/agent/.openclaw/workspace-shelley",
    "/home/agent/.openclaw/workspace-main",
    "/home/agent/.openclaw/workspace-rescue",
]

SCRIPT_PATH = "/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/aws-completion-report.py"

def run_for_workspace(workspace):
    """Run the report for a single workspace."""
    env = os.environ.copy()
    env["OPENCLAW_WORKSPACE"] = workspace
    try:
        result = subprocess.run(
            [sys.executable, SCRIPT_PATH],
            env=env,
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            output = result.stdout.strip()
            if output and output != "NO_REPLY":
                print(f"[{workspace.split('-')[-1]}] {output}")
            else:
                print(f"[{workspace.split('-')[-1]}] No output (NO_REPLY)")
        else:
            print(f"[{workspace.split('-')[-1]}] Error: {result.stderr[:200]}")
    except subprocess.TimeoutExpired:
        print(f"[{workspace.split('-')[-1]}] Timeout")
    except Exception as e:
        print(f"[{workspace.split('-')[-1]}] Exception: {e}")

def main():
    for ws in WORKSPACES:
        if os.path.isdir(ws):
            run_for_workspace(ws)
        else:
            print(f"Workspace not found: {ws}")
    # Output NO_REPLY to avoid extra messages
    # The cron job will deliver the printed output
    # If nothing printed, we can output NO_REPLY
    # but we already printed summaries.
    # We'll output NO_REPLY to keep silent if no output.
    # However we want the consolidated output to be sent.
    # Let's just exit; the agentTurn will capture stdout.
    sys.exit(0)

if __name__ == "__main__":
    main()