#!/usr/bin/env python3
import os
import sys
import subprocess
import json
from datetime import datetime, timedelta, timezone

def load_env():
    env = os.environ.copy()
    env_path = '/home/agent/.openclaw/workspace-doc/.env'
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    try:
                        k, v = line.split('=', 1)
                        env[k] = v
                    except:
                        pass
    env['GOG_ACCOUNT'] = 'bayanimills@gmail.com'
    return env

def fetch_events():
    env = load_env()
    # calculate start (now) and end (24h from now)
    now = datetime.now(timezone.utc)
    start = now.isoformat(timespec='seconds')
    end = (now + timedelta(hours=24)).isoformat(timespec='seconds')
    
    cmd = [
        'gog', 'calendar', 'events', 'primary',
        '--from', start,
        '--to', end,
        '--json',
        '--account', 'bayanimills@gmail.com'
    ]
    try:
        result = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f'Error fetching events: {result.stderr}')
            return []
        data = json.loads(result.stdout)
        return data.get('events', [])
    except Exception as e:
        print(f'Exception: {e}')
        return []

def main():
    events = fetch_events()
    if not events:
        print('No appointments in the next 24 hours.')
        return
    
    lines = ['📅 **Appointment Reminders (next 24h)**']
    for ev in events:
        summary = ev.get('summary', 'No title')
        start = ev.get('start', {}).get('dateTime') or ev.get('start', {}).get('date')
        end = ev.get('end', {}).get('dateTime') or ev.get('end', {}).get('date')
        attendees = ev.get('attendees', [])
        # filter out Edward's own email?
        lines.append(f'• **{summary}**')
        lines.append(f'  🕐 {start} – {end}')
        if attendees:
            attendees_str = ', '.join([a.get('email', '') for a in attendees[:2]])
            if len(attendees) > 2:
                attendees_str += f' (+{len(attendees)-2} more)'
            lines.append(f'  👥 {attendees_str}')
        lines.append('')
    
    output = '\n'.join(lines)
    print(output)

if __name__ == '__main__':
    main()