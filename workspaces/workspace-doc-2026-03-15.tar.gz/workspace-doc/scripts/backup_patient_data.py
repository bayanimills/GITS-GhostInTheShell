#!/usr/bin/env python3
import os
import json
import requests
from datetime import datetime
import sys

NOTION_API_KEY = open('/home/agent/.config/notion/api_key').read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

# Data source IDs for Edward Mills related databases
DATA_SOURCES = {
    'End-of-Life Planning': '562af9af-f953-4bdb-92d7-ebb0c3020f4c',
    'After-Death Checklist': '7343ed8d-de9a-42ae-a787-c18f686dac1e',
    'Patient Tasks': 'f38f43f7-b2c8-4477-ae3d-7d17fa724891',
    'Considerations': 'ecf02617-25e5-4f11-92af-2f111f4af5f6',
    'Medications': 'e15f5b65-1def-4d95-83e0-066e18b08ac2',
    'Northern Beaches Nursing Homes': '00214de4-4ab4-4421-9eba-f05a66043aab',
    'Medical Events': '30dd323b-89ec-81b7-a294-000b99a37429',
    'Edward\'s Timeline': 'd1672bf5-71db-45c3-a6e0-306c12d872d8',
}

def query_data_source(data_source_id):
    url = f'https://api.notion.com/v1/data_sources/{data_source_id}/query'
    resp = requests.post(url, headers=HEADERS, json={})
    resp.raise_for_status()
    return resp.json()

def backup_notion():
    backup_dir = '/home/agent/.openclaw/workspace-doc/backups/notion'
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    for name, ds_id in DATA_SOURCES.items():
        try:
            data = query_data_source(ds_id)
            filename = f'{backup_dir}/{timestamp}_{name.replace(" ", "_")}.json'
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            print(f'✓ {name}: {len(data.get("results", []))} entries')
        except Exception as e:
            print(f'✗ {name}: {e}')
    return timestamp

def backup_dart():
    """Backup Dart tasks for Edward Mills."""
    try:
        from dart_client import DartClient
    except ImportError:
        print("✗ Dart client not available (skipping)")
        return
    try:
        client = DartClient()
        response = client.list_tasks()
        # response is dict with 'results' list
        tasks = response.get('results', [])
        # optionally handle pagination (next) if needed
        backup_dir = '/home/agent/.openclaw/workspace-doc/backups/dart'
        os.makedirs(backup_dir, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'{backup_dir}/{timestamp}_dart_tasks.json'
        with open(filename, 'w') as f:
            json.dump({'meta': response.get('meta', {}), 'tasks': tasks}, f, indent=2)
        print(f'✓ Dart tasks: {len(tasks)} entries')
    except Exception as e:
        print(f'✗ Dart backup failed: {e}')

def main():
    print('Starting patient data backup...')
    ts = backup_notion()
    backup_dart()
    print(f'Backup completed at {ts}')

if __name__ == '__main__':
    main()