#!/usr/bin/env python3
"""
Create Patient Dashboard page in Edward Mills Notion workspace.
"""
import os
import requests
import json
from datetime import datetime

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

parent_page_id = "30dd323b-89ec-8064-ba6e-c5ca7689ed67"

# Create the page
payload = {
    "parent": {"type": "page_id", "page_id": parent_page_id},
    "properties": {
        "title": {
            "title": [
                {"text": {"content": "Patient Dashboard – Edward Mills"}}
            ]
        }
    },
    "children": [
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Overview"}}]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {"text": {"content": "This dashboard centralises all information about Edward Mills' care journey."}}
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Tasks"}}]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {"text": {"content": "Active tasks synced from Dart:"}}
                ]
            }
        },
        {
            "object": "block",
            "type": "link_to_database",
            "link_to_database": {
                "database_id": "37691f15-655f-4a54-a3eb-915692442433"
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Medical Events"}}]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {"text": {"content": "Timeline of medical events (stroke, appointments, etc.):"}}
                ]
            }
        },
        {
            "object": "block",
            "type": "link_to_database",
            "link_to_database": {
                "database_id": "30dd323b-89ec-8152-99a3-c4d72376bdeb"
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Timeline"}}]
            }
        },
        {
            "object": "block",
            "type": "link_to_database",
            "link_to_database": {
                "database_id": "09952de0-76e4-4399-8d07-5b7fe0813733"
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Checklist"}}]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {"text": {"content": "Aged care transition checklist:"}},
                    {"text": {"content": " https://www.notion.so/checklist", "link": {"url": "https://www.notion.so/checklist"}}}
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Notes"}}]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {"text": {"content": "All data is synced automatically with Dart and other tools. Last updated "}},
                    {"text": {"content": datetime.now().strftime("%Y-%m-%d"), "annotations": {"bold": True}}}
                ]
            }
        }
    ]
}

resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
if resp.status_code == 200:
    page = resp.json()
    print(f"Created dashboard page:")
    print(f"Page ID: {page['id']}")
    print(f"URL: {page.get('url')}")
    print(json.dumps(page, indent=2))
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)