#!/usr/bin/env python3
import os
import requests
import json

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28'
}

# Get database schema
response = requests.get(
    f'https://api.notion.com/v1/databases/{DATABASE_ID}',
    headers=headers
)

if response.status_code != 200:
    print(f"Error: {response.status_code} {response.text}")
    exit(1)

db = response.json()
print("Database title:", db.get('title', []))
print("\nProperties:")
for prop_name, prop in db.get('properties', {}).items():
    print(f"\n{prop_name} ({prop.get('type')}):")
    if prop.get('type') == 'select':
        options = prop.get('select', {}).get('options', [])
        print(f"  Options: {[opt['name'] for opt in options]}")
    elif prop.get('type') == 'status':
        options = prop.get('status', {}).get('options', [])
        print(f"  Options: {[opt['name'] for opt in options]}")
    else:
        print(f"  Config: {prop}")