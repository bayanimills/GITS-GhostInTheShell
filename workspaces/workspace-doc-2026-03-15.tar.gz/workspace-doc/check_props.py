import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

data_source_id = '562af9af-f953-4bdb-92d7-ebb0c3020f4c'
url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
resp = requests.get(url, headers=HEADERS)
if resp.status_code == 200:
    ds = resp.json()
    print('Property keys:', list(ds.get('properties', {}).keys()))
    print('\nProperties:')
    for key, prop in ds.get('properties', {}).items():
        print(f'  {key}: {prop.get("type")}')
else:
    print(resp.text)