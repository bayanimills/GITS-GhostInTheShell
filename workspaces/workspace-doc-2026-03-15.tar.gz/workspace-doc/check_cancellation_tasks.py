#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient

client = DartClient()
response = client.list_tasks(limit=200)
all_tasks = response.get("results", []) if isinstance(response, dict) else response

cris_id = "q4opiLJMS5fu"
paul_id = "iPfZ65RkHhjW"

for t in all_tasks:
    if t.get("id") in [cris_id, paul_id]:
        print(f"{t.get('id')}: {t.get('title')}")
        print(f"  Status: {t.get('status')}")
        print(f"  Updated: {t.get('updatedAt')}")
        print(f"  Due: {t.get('dueAt')}")
        print()