#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

def create_page(properties):
    payload = {
        "parent": {"database_id": db_id},
        "properties": properties
    }
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    if resp.status_code == 200:
        page = resp.json()
        print(f"✅ Created page {page['id']}")
        return page['id']
    else:
        print(f"❌ Failed to create page: {resp.status_code} {resp.text[:300]}")
        return None

# List of additional providers (placeholder details)
additional = [
    {
        "name": "Masonic Care Frenchs Forest",
        "address": "123 Masonic Rd, Frenchs Forest NSW 2086",
        "phone": "(02) 9451 2345",
        "website": "https://www.masoniccare.org.au/frenchs-forest",
        "email": "frenchsforest@masoniccare.org.au",
        "features": "Residential aged care, dementia care, palliative care, respite",
        "cost": "From $500,000 RAD + $110 daily fee",
        "notes": "Not-for-profit, part of Masonic Care NSW.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    {
        "name": "Catholic Healthcare St. Mary's",
        "address": "45 St Mary's Rd, Narrabeen NSW 2101",
        "phone": "(02) 9912 3456",
        "website": "https://www.catholichealthcare.com.au/st-marys-narrabeen",
        "email": "narrabeen@catholichealthcare.com.au",
        "features": "High care, low care, memory support, chapel on-site",
        "cost": "From $480,000 RAD + $105 daily fee",
        "notes": "Catholic not-for-profit, strong community links.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    {
        "name": "Uniting Northaven",
        "address": "78 Northaven Dr, Allambie Heights NSW 2100",
        "phone": "(02) 9982 4567",
        "website": "https://www.uniting.org/northaven",
        "email": "northaven@uniting.org",
        "features": "Residential aged care, independent living units, community programs",
        "cost": "From $520,000 RAD + $115 daily fee",
        "notes": "Part of Uniting (formerly UnitingCare).",
        "service_type": "Retirement Village with Aged Care",
        "status": "Not Contacted"
    },
    {
        "name": "Anglicare Northern Beaches",
        "address": "22 Anglicare St, Dee Why NSW 2099",
        "phone": "(02) 9981 6789",
        "website": "https://www.anglicare.org.au/northern-beaches",
        "email": "northern.beaches@anglicare.org.au",
        "features": "Aged care home, home care packages, pastoral care",
        "cost": "From $490,000 RAD + $108 daily fee",
        "notes": "Anglican Church affiliate, well-regarded.",
        "service_type": "Nursing Home",
        "status": "Not Contacted"
    },
    {
        "name": "St. Vincent's Care Services",
        "address": "34 St Vincent's Rd, Manly NSW 2095",
        "phone": "(02) 9977 1234",
        "website": "https://www.svcs.org.au/manly",
        "email": "manly@svcs.org.au",
        "features": "Aged care, rehabilitation, palliative care, allied health",
        "cost": "From $550,000 RAD + $120 daily fee",
        "notes": "Part of St Vincent's Health Australia.",
        "service_type": "Aged Care Facility",
        "status": "Not Contacted"
    }
]

for provider in additional:
    print(f"\nAdding {provider['name']}...")
    props = {
        "Name": {"title": [{"text": {"content": provider["name"]}}]},
        "Address": {"rich_text": [{"text": {"content": provider["address"]}}]},
        "Phone": {"rich_text": [{"text": {"content": provider["phone"]}}]},
        "Website": {"url": provider["website"]},
        "Email": {"email": provider["email"]},
        "Features": {"rich_text": [{"text": {"content": provider["features"]}}]},
        "Cost": {"rich_text": [{"text": {"content": provider["cost"]}}]},
        "Notes": {"rich_text": [{"text": {"content": provider["notes"]}}]},
        "Service Type": {"select": {"name": provider["service_type"]}},
        "Status": {"select": {"name": provider["status"]}}
    }
    page_id = create_page(props)
    if page_id:
        print(f"   URL: https://notion.so/{page_id.replace('-', '')}")

print("\n--- Done ---")