#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
parent_page_id = "30dd323b-89ec-8064-ba6e-c5ca7689ed67"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

payload = {
    "parent": {"type": "page_id", "page_id": parent_page_id},
    "title": [
        {"type": "text", "text": {"content": "Northern Beaches Nursing Homes"}}
    ],
    "properties": {
        "Name": {"title": {}},
        "Address": {"rich_text": {}},
        "Phone": {"rich_text": {}},
        "Website": {"url": {}},
        "Email": {"email": {}},
        "Features": {"rich_text": {}},
        "Cost": {"rich_text": {}},
        "Notes": {"rich_text": {}},
        "Service Type": {
            "select": {
                "options": [
                    {"name": "Nursing Home", "color": "blue"},
                    {"name": "Retirement Village with Aged Care", "color": "green"},
                    {"name": "Aged Care Facility", "color": "purple"}
                ]
            }
        },
        "Status": {
            "select": {
                "options": [
                    {"name": "Not Contacted", "color": "gray"},
                    {"name": "Contacted", "color": "yellow"},
                    {"name": "Visited", "color": "orange"},
                    {"name": "Shortlisted", "color": "blue"},
                    {"name": "Rejected", "color": "red"},
                    {"name": "Selected", "color": "green"}
                ]
            }
        },
        "Last Updated": {"last_edited_time": {}},
    }
}

print("Creating database...")
resp = requests.post("https://api.notion.com/v1/databases", headers=headers, json=payload)
if resp.status_code == 200:
    db = resp.json()
    db_id = db["id"]
    print(f"✅ Database created with ID: {db_id}")
    print(f"   Title: {db.get('title', [{}])[0].get('text', {}).get('content', '')}")
    print(f"   URL: https://notion.so/{db_id.replace('-', '')}")
    print(f"   Properties: {list(db.get('properties', {}).keys())}")
    # Save ID to file for later reference
    with open("nursing_homes_db_id.txt", "w") as f:
        f.write(db_id)
else:
    print(f"❌ Error {resp.status_code}: {resp.text[:500]}")