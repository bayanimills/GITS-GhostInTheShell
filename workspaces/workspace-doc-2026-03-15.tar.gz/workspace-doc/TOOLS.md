# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.

## AgentMail

- **Inbox:** `ewm-contact@agentmail.to` (display name "Aloysius Bexley")
- **API key:** `AGENTMAIL_API_KEY` environment variable
- **Python SDK:** `agentmail` (installed in workspace‑aria venv)
- **Monitor script:** `scripts/monitor_agentmail.py`
- **Send script:** `scripts/send_agentmail.py`
- **State file:** `state/agentmail_last_seen.txt`
- **Cron job:** AgentMail Monitor (removed as of 2026‑02‑21)
- **Usage:** Monitor for new emails; notifications sent to Telegram.

## Autonomous Workflow System (AWS)

- **Status**: Active (24/7 autonomous operation with presence‑aware graduated autonomy)
- **Task queue**: `aws-task-queue.md` (includes meta‑learning nightly extraction pattern)
- **Telegram status**: `aws-telegram-status.json` (enabled by default, single‑message updates)
- **Reporting policy**: No‑report‑on‑success default; 12‑hour completion reports at 07:00/19:00 local
- **Cron schedule**: Every 30 minutes for task checks; 07:00/19:00 for completion reports
- **Manual pause**: `touch ~/.openclaw-autonomy-pause` / `rm ~/.openclaw-autonomy-pause`
- **Configuration docs**: `docs/config/aws-reporting-policy.md`
