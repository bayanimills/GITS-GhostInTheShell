#!/usr/bin/env python3
"""
Create Dart tasks for high‑priority end‑of‑life items and link them to Notion.
"""
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from scripts.dart_client import DartClient
import json
import requests
import time

# Load Notion key for updating
NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
NOTION_HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

# High‑priority tasks
high_priority = [
    {
        'title': 'Update Will – Edward Mills',
        'description': 'Ensure will reflects current wishes, executor appointed.',
        'dueAt': '2026-03-01',
        'tags': ['patient-edward-mills', 'end-of-life', 'legal'],
        'notion_task': 'Update Will'
    },
    {
        'title': 'Create Advance Care Directive – Edward Mills',
        'description': 'Document preferences for medical treatment, DNR if desired.',
        'dueAt': '2026-03-01',
        'tags': ['patient-edward-mills', 'end-of-life', 'medical'],
        'notion_task': 'Create Advance Care Directive'
    },
    {
        'title': 'Organise Power of Attorney – Edward Mills',
        'description': 'Both financial and medical POA.',
        'dueAt': '2026-03-01',
        'tags': ['patient-edward-mills', 'end-of-life', 'legal'],
        'notion_task': 'Organise Power of Attorney'
    }
]

def create_dart_tasks():
    """Create Dart tasks and return mapping notion_task -> dart_id."""
    client = DartClient()
    mapping = {}
    for item in high_priority:
        print(f'Creating Dart task: {item["title"]}')
        try:
            task = client.create_task(
                title=item['title'],
                description=item['description'],
                dartboard='Edward Mills/Tasks',
                tags=item['tags'],
                dueAt=item['dueAt']
            )
            dart_id = task.get('id')
            if dart_id:
                mapping[item['notion_task']] = dart_id
                print(f'  → Dart ID: {dart_id}')
            else:
                print(f'  ✗ No ID returned')
        except Exception as e:
            print(f'  ✗ Error: {e}')
    return mapping

def update_notion_with_dart_id(notion_task_name, dart_id):
    """Find the Notion page for the given task name and update its Dart Task ID."""
    # Query the End-of-Life Planning database for the task
    db_id = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'
    url = f'https://api.notion.com/v1/databases/{db_id}/query'
    resp = requests.post(url, headers=NOTION_HEADERS, json={})
    if resp.status_code != 200:
        print(f'Query failed: {resp.text}')
        return False
    results = resp.json().get('results', [])
    target_page = None
    for page in results:
        props = page.get('properties', {})
        task_title = props.get('Task', {}).get('title', [{}])[0].get('text', {}).get('content', '')
        if task_title == notion_task_name:
            target_page = page
            break
    if not target_page:
        print(f'Notion page not found for "{notion_task_name}"')
        return False
    page_id = target_page['id']
    # Update Dart Task ID property
    update_url = f'https://api.notion.com/v1/pages/{page_id}'
    payload = {
        'properties': {
            'Dart Task ID': {'rich_text': [{'text': {'content': dart_id}}]}
        }
    }
    update_resp = requests.patch(update_url, headers=NOTION_HEADERS, json=payload)
    if update_resp.status_code == 200:
        print(f'  Updated Notion with Dart ID {dart_id}')
        return True
    else:
        print(f'  Notion update failed: {update_resp.text}')
        return False

def main():
    print('Creating Dart tasks for high‑priority end‑of‑life items...')
    mapping = create_dart_tasks()
    if not mapping:
        print('No Dart tasks created.')
        return
    print('\nUpdating Notion with Dart Task IDs...')
    for notion_task, dart_id in mapping.items():
        update_notion_with_dart_id(notion_task, dart_id)
        time.sleep(0.2)
    print('\n✅ Done.')

if __name__ == '__main__':
    main()