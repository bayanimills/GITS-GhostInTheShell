#!/usr/bin/env python3
import os
import requests
import json
import time

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

database_id = "84d36add-88f4-43df-a1bf-f9d7e99cf23f"

medications = [
    {
        "name": "Amlodipine",
        "dose": "5 mg",
        "frequency": "daily",
        "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
        "notes": "For hypertension"
    },
    {
        "name": "Perindopril",
        "dose": "5 mg",
        "frequency": "daily",
        "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
        "notes": "For hypertension"
    },
    {
        "name": "Apixaban",
        "dose": "5 mg",
        "frequency": "twice daily",
        "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
        "notes": "For atrial fibrillation (anticoagulant)"
    },
    {
        "name": "Aspirin",
        "dose": "100 mg",
        "frequency": "daily",
        "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
        "notes": "Antiplatelet"
    },
    {
        "name": "Atorvastatin",
        "dose": "20 mg",
        "frequency": "at night",
        "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
        "notes": "For hypercholesterolaemia"
    },
    {
        "name": "Metoprolol",
        "dose": "25 mg",
        "frequency": "twice daily",
        "doctor": "Dr. G. M. Tomlinson (The Cottage Surgery)",
        "notes": "Rate control"
    }
]

def add_medication(med):
    payload = {
        "parent": {"database_id": database_id},
        "properties": {
            "Name": {"title": [{"text": {"content": med["name"]}}]},
            "Dose": {"rich_text": [{"text": {"content": med["dose"]}}]},
            "Frequency": {"select": {"name": med["frequency"]}},
            "Prescribing Doctor": {"rich_text": [{"text": {"content": med["doctor"]}}]},
            "Status": {"select": {"name": "Active"}},
            "Notes": {"rich_text": [{"text": {"content": med["notes"]}}]}
        }
    }
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    return resp

for med in medications:
    print(f"Adding {med['name']}...")
    resp = add_medication(med)
    if resp.status_code >= 400:
        print(f"  Error: {resp.status_code} - {resp.text}")
    else:
        print(f"  Success")
    time.sleep(0.2)

print("Done.")