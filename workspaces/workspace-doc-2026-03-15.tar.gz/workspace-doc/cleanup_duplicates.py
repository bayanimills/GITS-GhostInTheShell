#!/usr/bin/env python3
"""
Clean duplicate pages in Notion Patient Tasks database.
Keep the oldest page (by created_time) for each Dart Task ID.
"""
import requests
import os
import json
from datetime import datetime

NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}
DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"

def query_all():
    url = f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query"
    payload = {}
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(30, 60))
    resp.raise_for_status()
    data = resp.json()
    return data.get("results", [])

def archive_page(page_id):
    """Archive (soft delete) a page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"archived": True}
    resp = requests.patch(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    return resp.json()

def main(dry_run=True):
    pages = query_all()
    print(f"Total pages: {len(pages)}")
    
    # Group by Dart Task ID
    by_task = {}
    for p in pages:
        props = p.get("properties", {})
        dart_id_prop = props.get("Dart Task ID", {})
        rich_text = dart_id_prop.get("rich_text", [])
        dart_id = rich_text[0].get("text", {}).get("content") if rich_text else None
        if not dart_id:
            continue
        name_prop = props.get("Name", {}).get("title", [])
        name = name_prop[0].get("text", {}).get("content") if name_prop else "No name"
        page_id = p.get("id")
        created = p.get("created_time")
        by_task.setdefault(dart_id, []).append({
            "page_id": page_id,
            "name": name,
            "created": created,
            "full": p
        })
    
    # Identify duplicates
    duplicates_to_archive = []
    for dart_id, entries in by_task.items():
        if len(entries) > 1:
            print(f"\n{dart_id}: {len(entries)} entries")
            # Sort by created time (oldest first)
            entries.sort(key=lambda x: x["created"])
            # Keep the oldest
            keep = entries[0]
            print(f"  Keep: {keep['page_id']} (created {keep['created']})")
            for entry in entries[1:]:
                print(f"  Archive: {entry['page_id']} (created {entry['created']})")
                duplicates_to_archive.append(entry)
    
    if not duplicates_to_archive:
        print("\nNo duplicates to archive.")
        return
    
    print(f"\nTotal duplicates to archive: {len(duplicates_to_archive)}")
    if dry_run:
        print("DRY RUN - no changes will be made.")
        return
    
    confirm = input("Proceed with archiving? (yes/no): ")
    if confirm.lower() != 'yes':
        print("Aborted.")
        return
    
    for i, entry in enumerate(duplicates_to_archive):
        try:
            print(f"Archiving {i+1}/{len(duplicates_to_archive)}: {entry['page_id']} - {entry['name']}")
            archive_page(entry['page_id'])
            print("  Done")
        except Exception as e:
            print(f"  Error: {e}")
    
    print("\nCleanup completed.")

if __name__ == "__main__":
    main()