#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/agent/.openclaw/workspace-doc/scripts')
from dart_client import DartClient
import json

client = DartClient()
task_id = "q4opiLJMS5fu"
task = client.get_task(task_id)
print("Current task:")
print(json.dumps(task, indent=2))

# Update due date to Monday March 2, 2026 (date only) and add note
description = task.get('description', '')
if "Reminder deferred to Monday 2 March 2026" not in description:
    description += "\n\nReminder deferred to Monday 2 March 2026 (cron set)."
updated = client.update_task(task_id, dueAt="2026-03-02", description=description)
print("\nUpdated task:")
print(json.dumps(updated, indent=2))