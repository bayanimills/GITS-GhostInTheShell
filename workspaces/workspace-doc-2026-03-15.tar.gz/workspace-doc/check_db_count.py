#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

resp = requests.post(f"https://api.notion.com/v1/databases/{db_id}/query", headers=headers, json={})
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Total pages in database: {len(results)}")
    for page in results:
        props = page.get('properties', {})
        name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', 'No name')
        service_type = props.get('Service Type', {}).get('select', {}).get('name', '')
        print(f"  - {name} [{service_type}]")
else:
    print(f"Error {resp.status_code}: {resp.text[:500]}")