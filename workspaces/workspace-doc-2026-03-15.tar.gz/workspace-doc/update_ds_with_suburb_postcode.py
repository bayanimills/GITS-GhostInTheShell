#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# 1. Fetch current data source
resp = requests.get(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers)
if resp.status_code != 200:
    print(f"Failed to fetch data source: {resp.text}")
    exit(1)

ds = resp.json()
current_props = ds.get('properties', {})
print(f"Current properties: {list(current_props.keys())}")

# 2. Add Suburb and Postcode
new_props = {
    "Suburb": {"rich_text": {}},
    "Postcode": {"rich_text": {}},
}

updated_props = {**current_props, **new_props}
print(f"Updated property count: {len(updated_props)}")

payload = {
    "properties": updated_props
}

print("Patching data source...")
resp = requests.patch(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers, json=payload)
if resp.status_code == 200:
    updated = resp.json()
    print("✅ Data source updated successfully.")
    print(f"   Properties: {list(updated.get('properties', {}).keys())}")
else:
    print(f"❌ Error {resp.status_code}: {resp.text[:500]}")