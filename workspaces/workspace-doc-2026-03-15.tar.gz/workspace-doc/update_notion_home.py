#!/usr/bin/env python3
import requests
import os
import sys

NOTION_API_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
DATABASE_ID = '37691f15-655f-4a54-a3eb-915692442433'
HEADERS = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json',
}

def find_page(dart_task_id):
    """Return page ID for given Dart Task ID."""
    filter_payload = {
        "filter": {
            "property": "Dart Task ID",
            "rich_text": {"equals": dart_task_id}
        }
    }
    resp = requests.post(
        f'https://api.notion.com/v1/databases/{DATABASE_ID}/query',
        headers=HEADERS,
        json=filter_payload
    )
    if resp.status_code != 200:
        print(f"Query failed: {resp.status_code} {resp.text[:200]}")
        return None
    data = resp.json()
    results = data.get('results', [])
    if not results:
        print(f"No page found for Dart Task ID {dart_task_id}")
        return None
    page = results[0]
    print(f"Found page: {page['id']} - {page.get('properties', {}).get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', '')}")
    return page['id']

def update_page(page_id, status='Done'):
    """Update page status."""
    update_payload = {
        "properties": {
            "Status": {"select": {"name": status}}
        }
    }
    resp = requests.patch(
        f'https://api.notion.com/v1/pages/{page_id}',
        headers=HEADERS,
        json=update_payload
    )
    if resp.status_code == 200:
        print(f"Updated page {page_id} to status {status}")
    else:
        print(f"Update failed: {resp.status_code} {resp.text[:200]}")

if __name__ == '__main__':
    task_id = 'lj6yqL6xaarP'  # home safety task
    page_id = find_page(task_id)
    if page_id:
        update_page(page_id, 'Done')
    else:
        sys.exit(1)