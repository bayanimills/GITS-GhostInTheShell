#!/usr/bin/env python3
import os
import requests
import json
import re

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Suburb to postcode mapping (Northern Beaches)
suburb_postcode = {
    "Manly Vale": "2093",
    "Manly": "2095",
    "Balgowlah": "2093",
    "Freshwater": "2096",
    "Seaforth": "2092",
    "Frenchs Forest": "2086",
    "Dee Why": "2099",
    "Narrabeen": "2101",
    "Allambie Heights": "2100",
    "Curl Curl": "2096",
    "Collaroy": "2097",
    "Mona Vale": "2103",
    "Warriewood": "2102",
    "Newport": "2106",
    "Avalon": "2107",
    "Palm Beach": "2108",
    "Clareville": "2109",
    "North Narrabeen": "2101",
    "Elanora Heights": "2101",
    "Ingleside": "2101",
    "Terrey Hills": "2084",
    "Belrose": "2085",
    "Davidson": "2085",
    "Forestville": "2087",
    "Killarney Heights": "2087",
    "Brookvale": "2100",
    "Cromer": "2099",
    "North Curl Curl": "2099",
    "North Manly": "2095",
    "Oxford Falls": "2100",
    "Queenscliff": "2096",
    "Fairlight": "2094",
    "Clontarf": "2093",
    "North Balgowlah": "2093",
    "Balgowlah Heights": "2093",
    "Collaroy Plateau": "2097",
    "Narraweena": "2099",
    "Wheeler Heights": "2097",
    "Beacon Hill": "2100",
    "Cottage Point": "2084",
    "Church Point": "2105",
    "Bayview": "2104",
    "Scotland Island": "2105",
    "Great Mackerel Beach": "2108",
    "Coasters Retreat": "2108",
    "Lovett Bay": "2105",
    "Elvina Bay": "2105",
    "Morning Bay": "2108",
    "Bilgola": "2107",
    "Bilgola Plateau": "2107",
    "Whale Beach": "2108",
    "Warriewood": "2102",
    "Mona Vale": "2103",
    "Newport": "2106",
    "Avalon": "2107",
    "Palm Beach": "2108",
}

def extract_suburb_postcode(address):
    """Extract suburb and postcode from address string."""
    if not address:
        return None, None
    # Pattern: suburb before NSW, postcode after NSW
    match = re.search(r'([A-Za-z\s]+)\s+NSW\s+(\d{4})', address)
    if match:
        suburb = match.group(1).strip()
        postcode = match.group(2).strip()
        return suburb, postcode
    # Fallback: try to find suburb in mapping by checking if suburb name appears in address
    for sub, pc in suburb_postcode.items():
        if sub.lower() in address.lower():
            return sub, pc
    return None, None

# Fetch all pages
print("Fetching pages...")
resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query", headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Failed to fetch pages: {resp.text}")
    exit(1)

data = resp.json()
pages = data.get('results', [])
print(f"Found {len(pages)} pages")

for page in pages:
    page_id = page['id']
    props = page.get('properties', {})
    name = props.get('Name', {}).get('title', [{}])[0].get('text', {}).get('content', '')
    address_obj = props.get('Address', {}).get('rich_text', [])
    address = address_obj[0].get('text', {}).get('content', '') if address_obj else ''
    suburb_obj = props.get('Suburb', {}).get('rich_text', [])
    postcode_obj = props.get('Postcode', {}).get('rich_text', [])
    
    # If suburb or postcode already filled, skip
    if suburb_obj or postcode_obj:
        print(f"Page {name} already has suburb/postcode data, skipping")
        continue
    
    suburb, postcode = extract_suburb_postcode(address)
    if suburb and postcode:
        print(f"{name}: suburb={suburb}, postcode={postcode}")
        # Update page
        update_payload = {
            "properties": {
                "Suburb": {
                    "rich_text": [{"type": "text", "text": {"content": suburb}}]
                },
                "Postcode": {
                    "rich_text": [{"type": "text", "text": {"content": postcode}}]
                }
            }
        }
        update_resp = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=update_payload)
        if update_resp.status_code == 200:
            print(f"  Updated")
        else:
            print(f"  Failed: {update_resp.status_code} {update_resp.text[:200]}")
    else:
        print(f"{name}: could not extract suburb/postcode from address: {address}")

print("Done.")