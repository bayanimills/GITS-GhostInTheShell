#!/usr/bin/env python3
import os
import requests
import json

api_key_path = os.path.expanduser("~/.config/notion/api_key")
with open(api_key_path) as f:
    api_key = f.read().strip()

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
}

# Get bot user
print("Fetching bot user...")
resp = requests.get("https://api.notion.com/v1/users/me", headers=headers)
if resp.status_code == 200:
    user = resp.json()
    print(f"  Name: {user.get('name')}")
    print(f"  Type: {user.get('type')}")
    print(f"  Workspace: {user.get('workspace_name')}")
    print(f"  Workspace ID: {user.get('workspace_id')}")
else:
    print(f"  Error {resp.status_code}: {resp.text[:200]}")

# Search for pages/databases with "Northern Beaches"
print("\nSearching for 'Northern Beaches'...")
resp = requests.post("https://api.notion.com/v1/search",
                     headers=headers,
                     json={"query": "Northern Beaches"})
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"  Found {len(results)} objects")
    for obj in results:
        obj_type = obj.get('object')
        title = ""
        if obj_type == 'database':
            title = obj.get('title', [{}])[0].get('text', {}).get('content', 'Untitled')
        elif obj_type == 'page':
            title = obj.get('properties', {}).get('title', {}).get('title', [{}])[0].get('text', {}).get('content', 'Untitled')
        print(f"  - {obj_type}: {title} ({obj.get('id')})")
        if obj_type == 'database':
            # print properties
            props = obj.get('properties', {})
            print(f"    Properties: {list(props.keys())}")
else:
    print(f"  Error {resp.status_code}: {resp.text[:200]}")