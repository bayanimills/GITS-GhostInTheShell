import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def search_notion(query):
    url = 'https://api.notion.com/v1/search'
    payload = {'query': query}
    resp = requests.post(url, headers=HEADERS, json=payload)
    resp.raise_for_status()
    return resp.json()

results = search_notion('Edward Mills')
print(json.dumps(results, indent=2))