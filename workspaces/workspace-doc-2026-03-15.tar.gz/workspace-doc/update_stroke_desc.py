#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
stroke_id = 'YhH8uggrObRf'

task = client.get_task(stroke_id)
current_desc = task.get('description', '')

# Load JSON block
with open('docs/stroke_event_data.json', 'r') as f:
    json_data = json.load(f)

json_block = f'\n\n```json\n{json.dumps(json_data, indent=2)}\n```'

if 'stroke_event_data' in current_desc:
    print("JSON block already present.")
else:
    new_desc = current_desc + json_block
    try:
        updated = client.update_task(stroke_id, description=new_desc)
        print("✅ Stroke task description updated with JSON block.")
    except Exception as e:
        print(f"Error updating task: {e}")