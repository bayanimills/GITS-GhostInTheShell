#!/usr/bin/env python3
import os
import requests
import json
import sys

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

query = sys.argv[1] if len(sys.argv) > 1 else "Patient Dashboard"
payload = {"query": query, "filter": {"property": "object", "value": "page"}}
resp = requests.post("https://api.notion.com/v1/search", headers=headers, json=payload)
if resp.status_code == 200:
    data = resp.json()
    results = data.get('results', [])
    print(f"Found {len(results)} pages matching '{query}':")
    for r in results:
        page_id = r['id']
        parent_type = r['parent']['type']
        parent_id = r['parent'][parent_type + '_id']
        title = ""
        if 'properties' in r:
            # try to get title property
            for prop_name, prop in r['properties'].items():
                if prop['type'] == 'title':
                    title = prop['title'][0]['text']['content'] if prop['title'] else ""
                    break
        else:
            # maybe icon or cover
            icon = r.get('icon', {})
            if 'emoji' in icon:
                title = icon['emoji'] + " " + (r.get('title', '') or '')
        print(f"  - {page_id} (parent {parent_type} {parent_id}) {title}")
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)