import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def add_property(data_source_id, prop_key, prop_def):
    """Add a single property to a data source."""
    url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
    resp = requests.get(url, headers=HEADERS)
    if resp.status_code != 200:
        print(f'Failed to get data source: {resp.text}')
        return
    ds = resp.json()
    props = ds.get('properties', {})
    if prop_key in props:
        print(f'Property {prop_key} already exists')
        return
    props[prop_key] = prop_def
    patch_payload = {'properties': props}
    patch_resp = requests.patch(url, headers=HEADERS, json=patch_payload)
    print(f'PATCH status: {patch_resp.status_code}')
    if patch_resp.status_code == 200:
        print(f'Added property {prop_key}')
    else:
        print(f'Error: {patch_resp.text}')

# Add Contact Info to End-of-Life Planning
add_property('562af9af-f953-4bdb-92d7-ebb0c3020f4c',
             'Contact Info',
             {'name': 'Contact Info', 'type': 'rich_text', 'rich_text': {}})

# Add Related Person to After-Death Checklist
add_property('7343ed8d-de9a-42ae-a787-c18f686dac1e',
             'Related Person',
             {'name': 'Related Person', 'type': 'rich_text', 'rich_text': {}})

print('\nDone.')