#!/usr/bin/env python3
import json
import sys
from collections import defaultdict

with open('/tmp/cron.json', 'r') as f:
    data = json.load(f)

jobs = data.get('jobs', [])
print(f"Total cron jobs: {len(jobs)}")

# Group by schedule pattern
schedule_groups = defaultdict(list)
for job in jobs:
    sched = job.get('schedule', {})
    kind = sched.get('kind')
    if kind == 'cron':
        key = f"cron:{sched.get('expr')}"
    elif kind == 'every':
        key = f"every:{sched.get('everyMs')}ms"
    elif kind == 'at':
        key = f"at:{sched.get('at')}"
    else:
        key = 'unknown'
    schedule_groups[key].append(job)

print("\nSchedule groups (size > 1):")
for key, group in schedule_groups.items():
    if len(group) > 1:
        print(f"\n{key} ({len(group)} jobs)")
        for job in group[:5]:
            print(f"  - {job.get('name')} (agent: {job.get('agentId')})")
        if len(group) > 5:
            print(f"  ... and {len(group)-5} more")

# Group by agent
agent_groups = defaultdict(list)
for job in jobs:
    agent = job.get('agentId', 'unknown')
    agent_groups[agent].append(job)

print("\n\nAgent distribution:")
for agent, group in sorted(agent_groups.items(), key=lambda x: len(x[1]), reverse=True):
    print(f"  {agent}: {len(group)} jobs")

# Group by payload message (if agentTurn)
payload_groups = defaultdict(list)
for job in jobs:
    payload = job.get('payload', {})
    if payload.get('kind') == 'agentTurn':
        msg = payload.get('message', '')
        # Normalize: remove workspace paths?
        simplified = msg[:100].replace('\n', ' ')
        key = f"msg:{simplified}"
        payload_groups[key].append(job)

print("\n\nPayload message groups (size > 1):")
for key, group in payload_groups.items():
    if len(group) > 1:
        print(f"\n{key} ({len(group)} jobs)")
        for job in group[:3]:
            print(f"  - {job.get('name')} (agent: {job.get('agentId')})")

# Identify potential consolidations:
# 1. Jobs with same schedule across different agents but similar purpose (e.g., AWS reports)
# 2. Jobs with same agent and similar schedule (e.g., hourly digest + something else)
print("\n\n--- Potential Consolidation Opportunities ---")

# Find jobs with same schedule and similar payload pattern across agents
for sched_key, group in schedule_groups.items():
    if len(group) <= 1:
        continue
    # Check if they are across different agents
    agents = set(job.get('agentId') for job in group)
    if len(agents) > 1:
        # Could be cross‑agent consolidation
        print(f"\nCross‑agent schedule {sched_key}:")
        for job in group:
            print(f"  - {job.get('name')} (agent: {job.get('agentId')})")

# Look for jobs with "AWS", "report", "digest", "daily", "weekly", "hourly"
keywords = ['aws', 'report', 'digest', 'daily', 'weekly', 'hourly', 'morning', 'night', 'check']
print("\n\nJobs with common keywords:")
for kw in keywords:
    matches = [job for job in jobs if kw.lower() in job.get('name', '').lower()]
    if matches:
        print(f"\n'{kw}':")
        for job in matches:
            print(f"  - {job.get('name')} (agent: {job.get('agentId')})")