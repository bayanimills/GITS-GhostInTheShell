#!/usr/bin/env python3
import json
import os
import subprocess
import sys

def run_cmd(cmd):
    print(f"Running: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
    return result

def main():
    # Load cron jobs
    with open('/tmp/cron_full.json', 'r') as f:
        data = json.load(f)
    jobs = data['jobs']
    print(f"Total jobs: {len(jobs)}")
    
    # Separate enabled/disabled
    enabled = [j for j in jobs if j.get('enabled')]
    disabled = [j for j in jobs if not j.get('enabled')]
    print(f"Enabled: {len(enabled)}")
    print(f"Disabled: {len(disabled)}")
    
    # Option 1: Remove disabled jobs (ask first)
    if disabled:
        print("\n=== Disabled jobs (candidates for removal) ===")
        for j in disabled[:20]:
            print(f"{j.get('name')} (id: {j.get('id')})")
        print(f"... and {len(disabled)-20} more.")
        answer = input("Remove all disabled jobs? (y/N): ").strip().lower()
        if answer == 'y':
            for j in disabled:
                run_cmd(f"openclaw cron remove --id {j['id']}")
            print("Removed disabled jobs.")
    else:
        print("No disabled jobs.")
    
    # Group enabled jobs by schedule and payload pattern
    groups = {}
    for j in enabled:
        s = j.get('schedule', {})
        key = (s.get('kind'), s.get('expr'), s.get('everyMs'), s.get('tz'), j.get('payload', {}).get('kind'))
        groups.setdefault(key, []).append(j)
    
    print("\n=== Groups with potential consolidation ===")
    for key, group in groups.items():
        if len(group) > 1:
            print(f"\nGroup: {key}")
            for j in group:
                print(f"  - {j.get('name')} (agent: {j.get('agentId')})")
                msg = j.get('payload', {}).get('message', '')
                if msg:
                    print(f"    {msg[:100]}")
    
    # Identify AWS 12h Completion Reports
    aws_reports = [j for j in enabled if 'AWS 12h Completion Report' in j.get('name', '')]
    if len(aws_reports) > 1:
        print(f"\n=== Found {len(aws_reports)} AWS 12h Completion Reports ===")
        # Could consolidate into one job that loops over workspaces
        workspaces = []
        for j in aws_reports:
            msg = j.get('payload', {}).get('message', '')
            # Extract workspace path
            import re
            match = re.search(r'OPENCLAW_WORKSPACE=(/home/agent/\.openclaw/workspace-\w+)', msg)
            if match:
                workspaces.append(match.group(1))
            else:
                workspaces.append('unknown')
        print("Workspaces:", workspaces)
        # Create a consolidated script
        script_content = '''#!/bin/bash
# Consolidated AWS 12h Completion Report
workspaces="%s"
for ws in $workspaces; do
    OPENCLAW_WORKSPACE=$ws python3 /home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/aws-completion-report.py
done
''' % ' '.join(workspaces)
        print("\nConsolidated script would run for workspaces.")
        # Ask to replace
        answer = input("Replace with single consolidated job? (y/N): ").strip().lower()
        if answer == 'y':
            # Remove existing AWS report jobs
            for j in aws_reports:
                run_cmd(f"openclaw cron remove --id {j['id']}")
            # Create new consolidated job
            cmd = '''openclaw cron add --name "Consolidated AWS 12h Completion Report" \\
                --schedule '{"kind":"cron","expr":"0 7,19 * * *","tz":"Australia/Sydney"}' \\
                --payload '{"kind":"agentTurn","message":"Run consolidated AWS reports"}'
                '''
            # Actually need to create a script file and reference it.
            print("Need to implement script creation.")
    
    # Identify morning standups (8am)
    morning = [j for j in enabled if j.get('schedule', {}).get('expr') == '0 8 * * *' and 'Australia/Sydney' in str(j.get('schedule', {}).get('tz'))]
    if len(morning) > 1:
        print(f"\n=== Found {len(morning)} morning jobs at 8am Sydney ===")
        for j in morning:
            print(f"  - {j.get('name')} (agent: {j.get('agentId')})")
        print("Could be batched into a single job.")
    
    print("\nAnalysis complete.")

if __name__ == '__main__':
    main()