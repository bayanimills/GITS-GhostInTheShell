# Edward Mills — Patient Dashboard

## Overview
- Patient: Edward William Mills
- DOB: 1934-07-19
- Acute event: Stroke (onset 2026-02-18)
- Primary coordinator: Doc (Aloyious)
- Executive contact: Bayani Mills

## Current Status
- Hospital: Royal North Shore Hospital — Neurology
- Symptoms: right-sided weakness, left facial droop
- Medications noted: apixaban, aspirin

## Next Steps (short)
- Schedule neurology follow-up (within 1-2 weeks)
- Start or confirm rehabilitation/physio sessions
- Medication reconciliation and check for contraindications
- Family support schedule (assign tasks for transport/visits)

## Appointments
- (Auto-sync from Google Calendar when authorized)

## Medications
- apixaban
- aspirin

## Tasks (synced from DartAI)
- Edward-related tasks will populate here once Notion sync enabled.

## Notes & Documents
- stroke_event_data.json: clinical snapshot and timestamps

## Audit
- Last sync attempt: (timestamped in sync logs)


*This page is a scaffolded Patient Dashboard. When Notion sync is enabled, I will populate 'Appointments', 'Tasks' and 'Next Steps' automatically from DartAI and calendar sources.*
