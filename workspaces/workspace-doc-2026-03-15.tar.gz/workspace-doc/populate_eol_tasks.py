import os
import json
import requests
import time

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

# Database IDs
EOL_DB_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'
AD_DB_ID = '2da34361-3539-4f92-83af-f74587e09c1c'

# Pre-death sample tasks
eol_tasks = [
    {'Task': 'Update Will', 'Category': 'Legal', 'Status': 'Not Started', 'Priority': 'High', 'Notes': 'Ensure will reflects current wishes, executor appointed.', 'Due Date': '2026-03-01'},
    {'Task': 'Create Advance Care Directive', 'Category': 'Medical', 'Status': 'Not Started', 'Priority': 'High', 'Notes': 'Document preferences for medical treatment, DNR if desired.', 'Due Date': '2026-03-01'},
    {'Task': 'Organise Power of Attorney', 'Category': 'Legal', 'Status': 'Not Started', 'Priority': 'High', 'Notes': 'Both financial and medical POA.', 'Due Date': '2026-03-01'},
    {'Task': 'List all financial accounts', 'Category': 'Financial', 'Status': 'Not Started', 'Priority': 'Medium', 'Notes': 'Bank accounts, investments, insurance policies, superannuation.', 'Due Date': '2026-03-07'},
    {'Task': 'Compile digital passwords', 'Category': 'Digital', 'Status': 'Not Started', 'Priority': 'Medium', 'Notes': 'Secure password manager or encrypted list.', 'Due Date': '2026-03-07'},
    {'Task': 'Discuss funeral wishes', 'Category': 'Funeral', 'Status': 'Not Started', 'Priority': 'Medium', 'Notes': 'Burial/cremation, service details, music, readings.', 'Due Date': '2026-03-07'},
    {'Task': 'Notify family of location of important documents', 'Category': 'Personal', 'Status': 'Not Started', 'Priority': 'Low', 'Notes': 'Will, insurance, property titles, etc.', 'Due Date': '2026-03-14'},
]

# Post-death sample tasks
ad_tasks = [
    {'Task': 'Obtain Medical Certificate of Cause of Death', 'Category': 'Immediate (24h)', 'Status': 'Not Started', 'Priority': 'Critical', 'Notes': 'From attending doctor or hospital.', 'Due Date': ''},
    {'Task': 'Contact funeral home', 'Category': 'Immediate (24h)', 'Status': 'Not Started', 'Priority': 'Critical', 'Notes': 'Arrange collection of body and discuss funeral arrangements.', 'Due Date': ''},
    {'Task': 'Notify immediate family and close friends', 'Category': 'Immediate (24h)', 'Status': 'Not Started', 'Priority': 'High', 'Notes': 'Phone calls, then formal notifications.', 'Due Date': ''},
    {'Task': 'Register death', 'Category': 'Within Week', 'Status': 'Not Started', 'Priority': 'High', 'Notes': 'At local registry, need medical certificate.', 'Due Date': ''},
    {'Task': 'Arrange funeral service', 'Category': 'Within Week', 'Status': 'Not Started', 'Priority': 'High', 'Notes': 'Coordinate with funeral home, set date/time.', 'Due Date': ''},
    {'Task': 'Notify bank and financial institutions', 'Category': 'Within Week', 'Status': 'Not Started', 'Priority': 'Medium', 'Notes': 'Provide death certificate, freeze accounts.', 'Due Date': ''},
    {'Task': 'Cancel utilities, subscriptions', 'Category': 'Within Month', 'Status': 'Not Started', 'Priority': 'Medium', 'Notes': 'Electricity, phone, streaming services.', 'Due Date': ''},
    {'Task': 'Apply for probate', 'Category': 'Long-term', 'Status': 'Not Started', 'Priority': 'Medium', 'Notes': 'If estate value exceeds threshold.', 'Due Date': ''},
    {'Task': 'Distribute assets according to will', 'Category': 'Long-term', 'Status': 'Not Started', 'Priority': 'Low', 'Notes': 'After probate granted.', 'Due Date': ''},
]

def add_page(database_id, task, db_type='eol'):
    """Add a page to Notion database."""
    # Map task dict to Notion property format
    props = {}
    for key, value in task.items():
        if key == 'Task':
            props['Task'] = {'title': [{'text': {'content': value}}]}
        elif key == 'Category':
            props['Category'] = {'select': {'name': value}}
        elif key == 'Status':
            props['Status'] = {'select': {'name': value}}
        elif key == 'Priority':
            props['Priority'] = {'select': {'name': value}}
        elif key == 'Due Date' and value:
            props['Due Date'] = {'date': {'start': value}}
        elif key == 'Notes':
            props['Notes'] = {'rich_text': [{'text': {'content': value}}]}
    # Add optional empty properties
    optional = ['Assigned To', 'Completed Date', 'Documents', 'Dart Task ID', 'Related Person', 'Contact Info']
    for opt in optional:
        if opt not in props:
            if opt == 'Completed Date':
                props[opt] = {'date': None}
            elif opt == 'Documents':
                props[opt] = {'files': []}
            else:
                props[opt] = {'rich_text': []}
    # Remove Contact Info for eol, Related Person for after-death? We'll keep both.
    # Send request
    payload = {
        'parent': {'database_id': database_id},
        'properties': props
    }
    url = 'https://api.notion.com/v1/pages'
    resp = requests.post(url, headers=HEADERS, json=payload)
    if resp.status_code != 200:
        print(f'Error adding {task.get("Task")}: {resp.text}')
        return False
    return True

def main():
    print('Populating End-of-Life Planning database...')
    for task in eol_tasks:
        if add_page(EOL_DB_ID, task, 'eol'):
            print(f'  ✓ {task["Task"]}')
        else:
            print(f'  ✗ {task["Task"]}')
        time.sleep(0.2)  # rate limit
    
    print('\nPopulating After-Death Checklist database...')
    for task in ad_tasks:
        if add_page(AD_DB_ID, task, 'ad'):
            print(f'  ✓ {task["Task"]}')
        else:
            print(f'  ✗ {task["Task"]}')
        time.sleep(0.2)
    
    print('\n✅ Task population complete.')

if __name__ == '__main__':
    main()