#!/usr/bin/env python3
"""
Update Dart tasks based on user instructions:
1. Mark stale tasks as Done
2. Update Dart end-of-life tasks to reflect Notion's Completed status
3. Deduplicate Will/Advance Care Directive/Power of Attorney entries
"""
import os
import sys
import requests
import json
from datetime import datetime, timezone

# Add scripts directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'scripts'))
from dart_client import DartClient

# Notion API setup
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Database IDs
END_OF_LIFE_DB_ID = "d83a5dff-506f-4368-9c49-4c11b50ce33d"

def mark_stale_tasks_done():
    """Mark stale (>7 days) To-do tasks as Done."""
    client = DartClient()
    resp = client.list_tasks()
    tasks = resp.get('results', [])
    
    stale_ids = []
    for t in tasks:
        updated = t.get('updatedAt')
        if not updated:
            continue
        updated_dt = datetime.fromisoformat(updated.replace('Z', '+00:00'))
        delta = datetime.now(timezone.utc) - updated_dt
        if delta.days >= 7 and t.get('status') == 'To-do':
            stale_ids.append((t['id'], t['title']))
    
    print(f"Found {len(stale_ids)} stale To-do tasks:")
    for task_id, title in stale_ids:
        print(f"  - {task_id}: {title[:60]}")
    
    # Update to Done
    for task_id, title in stale_ids:
        update_data = {
            "status": "Done",
            "summary": f"Marked Done per user instruction (stale >7 days)."
        }
        resp = client.update_task(task_id, update_data)
        if resp.get('status') == 'Done':
            print(f"✓ Updated {task_id} to Done")
        else:
            print(f"✗ Failed to update {task_id}: {resp}")

def query_notion_completed_tasks():
    """Query Notion End-of-Life Planning database for Completed tasks."""
    url = f"https://api.notion.com/v1/databases/{END_OF_LIFE_DB_ID}/query"
    payload = {
        "filter": {
            "property": "Status",
            "select": {
                "equals": "Completed"
            }
        }
    }
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload)
    if resp.status_code != 200:
        print(f"Notion query failed: {resp.status_code}")
        print(resp.text)
        return []
    
    data = resp.json()
    results = data.get('results', [])
    completed = []
    for page in results:
        props = page.get('properties', {})
        task_name = props.get('Task', {}).get('title', [{}])[0].get('text', {}).get('content', 'No name')
        dart_id = props.get('Dart Task ID', {}).get('rich_text', [{}])[0].get('text', {}).get('content', '')
        if dart_id:
            completed.append((dart_id.strip(), task_name))
    return completed

def update_dart_from_notion():
    """Update Dart tasks to Done if corresponding Notion task is Completed."""
    completed = query_notion_completed_tasks()
    print(f"Found {len(completed)} Completed tasks in Notion:")
    for dart_id, task_name in completed:
        print(f"  - {dart_id}: {task_name}")
    
    if not completed:
        return
    
    client = DartClient()
    for dart_id, task_name in completed:
        # First check current status
        task = client.get_task(dart_id)
        if task.get('status') == 'Done':
            print(f"✓ {dart_id} already Done")
            continue
        
        update_data = {
            "status": "Done",
            "summary": f"Marked Done (Notion status: Completed)."
        }
        resp = client.update_task(dart_id, update_data)
        if resp.get('status') == 'Done':
            print(f"✓ Updated {dart_id} to Done")
        else:
            print(f"✗ Failed to update {dart_id}: {resp}")

def deduplicate_end_of_life_tasks():
    """Identify duplicate Will/Advance Care Directive/Power of Attorney tasks."""
    client = DartClient()
    resp = client.list_tasks()
    tasks = resp.get('results', [])
    
    # Filter for Edward Mills tasks
    edward_tasks = [t for t in tasks if t.get('dartboard', '').startswith('Edward Mills/') or 'patient-edward-mills' in t.get('tags', [])]
    
    # Look for duplicates in title
    from collections import defaultdict
    title_map = defaultdict(list)
    for t in edward_tasks:
        title = t['title'].lower()
        title_map[title].append((t['id'], t['status']))
    
    duplicates = {title: ids for title, ids in title_map.items() if len(ids) > 1}
    if duplicates:
        print("Duplicate task titles found:")
        for title, ids in duplicates.items():
            print(f"  '{title}':")
            for tid, status in ids:
                print(f"    - {tid} ({status})")
        print("\nConsider merging or archiving duplicates.")
    else:
        print("No exact duplicate titles found.")
    
    # Also check for similar keywords
    keywords = ['will', 'advance care directive', 'power of attorney']
    keyword_matches = defaultdict(list)
    for t in edward_tasks:
        title_lower = t['title'].lower()
        for kw in keywords:
            if kw in title_lower:
                keyword_matches[kw].append((t['id'], t['title'], t['status']))
    
    print("\nTasks by keyword:")
    for kw, matches in keyword_matches.items():
        print(f"  {kw}: {len(matches)} tasks")
        for tid, title, status in matches:
            print(f"    - {tid}: {title} ({status})")

if __name__ == '__main__':
    print("=== Dart Task Updates ===\n")
    
    print("1. Marking stale tasks as Done...")
    mark_stale_tasks_done()
    
    print("\n2. Updating Dart from Notion Completed status...")
    update_dart_from_notion()
    
    print("\n3. Checking for duplicates...")
    deduplicate_end_of_life_tasks()
    
    print("\n=== Done ===")