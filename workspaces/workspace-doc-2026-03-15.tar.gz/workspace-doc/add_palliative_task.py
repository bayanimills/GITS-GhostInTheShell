import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

db_id = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'
payload = {
    'parent': {'database_id': db_id},
    'properties': {
        'Task': {'title': [{'text': {'content': 'Arrange palliative care assessment'}}]},
        'Category': {'select': {'name': 'Medical'}},
        'Status': {'select': {'name': 'Not Started'}},
        'Priority': {'select': {'name': 'High'}},
        'Notes': {'rich_text': [{'text': {'content': 'Given Edward’s current decline (unable to sit up, lift limbs, requires feeding), refer to palliative care team for symptom management and advance care planning.'}}]},
        'Due Date': {'date': {'start': '2026-02-25'}},
        'Assigned To': {'rich_text': []},
        'Completed Date': {'date': None},
        'Documents': {'files': []},
        'Dart Task ID': {'rich_text': []},
        'Related Person': {'rich_text': []}
    }
}

url = 'https://api.notion.com/v1/pages'
resp = requests.post(url, headers=HEADERS, json=payload)
print(f'Status: {resp.status_code}')
if resp.status_code == 200:
    print('Task added: Arrange palliative care assessment')
else:
    print(resp.text)