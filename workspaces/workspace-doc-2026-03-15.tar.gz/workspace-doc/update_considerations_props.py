#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

database_id = "c61993b6-ef26-428b-9e7e-607c0646e771"

# Get database to find data source
resp = requests.get(f"https://api.notion.com/v1/databases/{database_id}", headers=headers)
if resp.status_code != 200:
    print(f"Error fetching database: {resp.text}")
    sys.exit(1)
db = resp.json()
data_source_id = db["data_sources"][0]["id"]
print(f"Data source ID: {data_source_id}")

# Update data source properties (title property already exists as "Name")
payload = {
    "properties": {
        "Category": {
            "select": {
                "options": [
                    {"name": "Medical", "color": "red"},
                    {"name": "Appointment", "color": "blue"},
                    {"name": "Medication", "color": "green"},
                    {"name": "Care Coordination", "color": "orange"},
                    {"name": "Financial", "color": "purple"},
                    {"name": "Legal", "color": "brown"},
                    {"name": "Family", "color": "pink"}
                ]
            }
        },
        "Priority": {
            "select": {
                "options": [
                    {"name": "High", "color": "red"},
                    {"name": "Medium", "color": "yellow"},
                    {"name": "Low", "color": "gray"}
                ]
            }
        },
        "Due Date": {"date": {}},
        "Status": {
            "select": {
                "options": [
                    {"name": "Pending", "color": "yellow"},
                    {"name": "In Progress", "color": "blue"},
                    {"name": "Completed", "color": "green"},
                    {"name": "Deferred", "color": "gray"}
                ]
            }
        },
        "Notes": {"rich_text": {}},
        "Source": {
            "select": {
                "options": [
                    {"name": "Dart", "color": "blue"},
                    {"name": "Manual", "color": "orange"},
                    {"name": "Checklist", "color": "green"}
                ]
            }
        },
        "Linked Task ID": {"rich_text": {}}
    }
}

resp = requests.patch(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers, json=payload)
print(f"Status: {resp.status_code}")
if resp.status_code == 200:
    ds = resp.json()
    print("Updated data source")
    if 'properties' in ds:
        print("Properties:")
        for key, val in ds['properties'].items():
            print(f"  {key}: {val}")
else:
    print(resp.text)