#!/usr/bin/env python3
import json

with open('/tmp/cron.json', 'r') as f:
    data = json.load(f)

for job in data.get('jobs', []):
    name = job.get('name', '')
    if 'Notion Sync' in name or 'Weekly Review' in name:
        print(f"{job.get('id')} | {name}")
        print(f"  delivery: {json.dumps(job.get('delivery', {}), indent=4)}")
        print(f"  lastStatus: {job.get('state', {}).get('lastStatus')}")
        print()