import json
import sys

# The cron list output is truncated, but we have the full JSON in memory.
# We'll load from stdin
data = json.load(sys.stdin)
jobs = data['jobs']

enabled = [j for j in jobs if j.get('enabled')]
disabled = [j for j in jobs if not j.get('enabled')]

print(f"Total jobs: {len(jobs)}")
print(f"Enabled: {len(enabled)}")
print(f"Disabled: {len(disabled)}")

# Group by schedule pattern and payload kind
from collections import defaultdict
groups = defaultdict(list)
for j in enabled:
    key = (j.get('schedule', {}).get('kind'), 
           j.get('schedule', {}).get('expr', j.get('schedule', {}).get('everyMs', '')),
           j.get('payload', {}).get('kind'),
           j.get('agentId'))
    groups[key].append(j)

print("\n=== Groups with more than 1 job ===")
for key, group in groups.items():
    if len(group) > 1:
        print(f"\nKey: {key}")
        for j in group:
            print(f"  - {j.get('name')} (id: {j.get('id')})")
            print(f"    payload: {j.get('payload', {}).get('message', '')[:80]}")

# Also group by name pattern
print("\n=== Jobs with similar names ===")
name_groups = defaultdict(list)
for j in enabled:
    name = j.get('name', '')
    name_groups[name].append(j)
for name, group in name_groups.items():
    if len(group) > 1:
        print(f"{name}: {len(group)} duplicates")

# List disabled jobs that could be removed
print("\n=== Disabled jobs (candidates for removal) ===")
for j in disabled[:10]:  # limit
    print(f"{j.get('name')} (id: {j.get('id')})")