#!/usr/bin/env python3
import os
import requests
import json

NOTION_KEY = open("/home/agent/.config/notion/api_key").read().strip()
DATASOURCE_ID = "eec8bbe9-0cbe-4abe-8b82-04124bebe030"
HEADERS = {
    "Authorization": f"Bearer {NOTION_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json"
}

def query_database():
    url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}/query"
    response = requests.post(url, headers=HEADERS, json={})
    if response.status_code != 200:
        print(f"Query failed: {response.status_code} {response.text}")
        return []
    data = response.json()
    return data.get("results", [])

def update_page(page_id, properties):
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    response = requests.patch(url, headers=HEADERS, json=payload)
    if response.status_code == 200:
        print(f"Updated page {page_id}")
    else:
        print(f"Update failed: {response.status_code} {response.text}")

def main():
    pages = query_database()
    for page in pages:
        props = page.get("properties", {})
        name_obj = props.get("Name", {}).get("title", [])
        if not name_obj:
            continue
        name = name_obj[0].get("plain_text", "")
        if "Rafaela" in name:
            # Update relationship to Sister-in-Law
            update_page(page["id"], {
                "Relationship": {"rich_text": [{"text": {"content": "Sister-in-Law"}}]}
            })
            print(f"Updated Rafaela to Sister-in-Law")
        elif "Brent" in name:
            update_page(page["id"], {
                "Relationship": {"rich_text": [{"text": {"content": "Brother-in-Law (SIL husband)"}}]}
            })
            print(f"Updated Brent to Brother-in-Law (SIL husband)")

if __name__ == "__main__":
    main()