#!/usr/bin/env python3
"""
Create simple Patient Dashboard page with links to databases.
"""
import os
import requests
import json
from datetime import datetime

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

parent_page_id = "30dd323b-89ec-8064-ba6e-c5ca7689ed67"

# Database IDs and names
databases = [
    ("Patient Tasks", "37691f15-655f-4a54-a3eb-915692442433"),
    ("Medical Events", "30dd323b-89ec-8152-99a3-c4d72376bdeb"),
    ("Edward's Timeline", "09952de0-76e4-4399-8d07-5b7fe0813733"),
    ("Northern Beaches Nursing Homes", "6088ea51-fa49-4102-a6fb-250eccc9f1ad"),
]

# Build children blocks
children = [
    {
        "object": "block",
        "type": "heading_1",
        "heading_1": {
            "rich_text": [{"text": {"content": "Patient Dashboard – Edward Mills"}}]
        }
    },
    {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [
                {"text": {"content": "This dashboard centralises all information about Edward Mills' care journey. Use the links below to access each database."}}
            ]
        }
    },
    {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
            "rich_text": [{"text": {"content": "Databases"}}]
        }
    },
]

for name, db_id in databases:
    url = f"https://notion.so/{db_id.replace('-', '')}"
    children.append({
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [
                {"text": {"content": f"• {name}: "}},
                {"text": {"content": "Open", "link": {"url": url}}}
            ]
        }
    })

# Add checklist link
children.extend([
    {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
            "rich_text": [{"text": {"content": "Checklist"}}]
        }
    },
    {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [
                {"text": {"content": "Aged care transition checklist is maintained in the "}},
                {"text": {"content": "aged-care-transition skill"}},
                {"text": {"content": ". Each step can be tracked as a Dart task."}}
            ]
        }
    },
    {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
            "rich_text": [{"text": {"content": "Notes"}}]
        }
    },
    {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [
                {"text": {"content": "Data is synced automatically with Dart. Last updated "}},
                {"text": {"content": datetime.now().strftime("%Y-%m-%d")}},
                {"text": {"content": "."}}
            ]
        }
    }
])

payload = {
    "parent": {"type": "page_id", "page_id": parent_page_id},
    "properties": {
        "title": {
            "title": [
                {"text": {"content": "Patient Dashboard – Edward Mills"}}
            ]
        }
    },
    "children": children
}

resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
if resp.status_code == 200:
    page = resp.json()
    print(f"Created dashboard page:")
    print(f"Page ID: {page['id']}")
    print(f"URL: {page.get('url')}")
    # Save info
    with open('dashboard_info.json', 'w') as f:
        json.dump(page, f, indent=2)
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)