#!/usr/bin/env python3
import os
import sys
import requests
import json
import time

# Load Dart API token from .env
env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val

# Notion API
api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}
CONSIDERATIONS_DB_ID = "c61993b6-ef26-428b-9e7e-607c0646e771"

# Dart API
DART_TOKEN = os.getenv("DART_API_TOKEN")
if not DART_TOKEN:
    print("DART_API_TOKEN not set")
    sys.exit(1)
DART_HEADERS = {
    "Authorization": f"Bearer {DART_TOKEN}",
    "Content-Type": "application/json",
}

def fetch_dart_tasks():
    """Fetch tasks related to Edward Mills."""
    url = "https://app.dartai.com/api/v0/public/tasks/list"
    params = {"limit": 200}
    resp = requests.get(url, headers=DART_HEADERS, params=params)
    resp.raise_for_status()
    data = resp.json()
    tasks = data.get("results", [])
    # Filter: either tagged patient-edward-mills, or subtask of stroke task, or tagged stroke-followup
    stroke_id = "YhH8uggrObRf"
    edward_tasks = []
    for t in tasks:
        tags = t.get("tags", [])
        parent = t.get("parentId")
        if "patient-edward-mills" in tags:
            edward_tasks.append(t)
        elif parent == stroke_id:
            edward_tasks.append(t)
        elif "stroke-followup" in tags:
            edward_tasks.append(t)
    return edward_tasks

def map_dart_to_consideration(task):
    """Map Dart task to Notion consideration properties."""
    title = task.get("title", "Untitled")
    status = task.get("status", "To-do")
    priority = task.get("priority", "")
    due_date = task.get("dueAt")
    tags = task.get("tags", [])
    task_id = task.get("id")
    
    # Status mapping
    status_map = {
        "To-do": "Pending",
        "Doing": "In Progress",
        "Done": "Completed"
    }
    notion_status = status_map.get(status, "Pending")
    
    # Priority mapping
    priority_map = {
        "Critical": "High",
        "High": "High",
        "Medium": "Medium",
        "Low": "Low"
    }
    notion_priority = priority_map.get(priority, "Medium")
    
    # Category inference
    category = "Medical"
    if "appointment" in [t.lower() for t in tags]:
        category = "Appointment"
    elif "medication" in [t.lower() for t in tags]:
        category = "Medication"
    elif "family" in [t.lower() for t in tags]:
        category = "Family"
    elif "financial" in [t.lower() for t in tags]:
        category = "Financial"
    elif "legal" in [t.lower() for t in tags]:
        category = "Legal"
    
    # Build properties
    props = {
        "Name": {"title": [{"text": {"content": title}}]},
        "Category": {"select": {"name": category}},
        "Priority": {"select": {"name": notion_priority}},
        "Status": {"select": {"name": notion_status}},
        "Source": {"select": {"name": "Dart"}},
        "Linked Task ID": {"rich_text": [{"text": {"content": task_id}}]}
    }
    if due_date:
        props["Due Date"] = {"date": {"start": due_date}}
    # Notes could include tags
    if tags:
        props["Notes"] = {"rich_text": [{"text": {"content": ", ".join(tags)}}]}
    return props

def add_consideration(props):
    """Add consideration entry to Notion database."""
    url = "https://api.notion.com/v1/pages"
    payload = {
        "parent": {"database_id": CONSIDERATIONS_DB_ID},
        "properties": props
    }
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload)
    return resp

def main():
    print("Fetching Dart tasks...")
    tasks = fetch_dart_tasks()
    print(f"Found {len(tasks)} Edward Mills tasks.")
    
    for task in tasks:
        title = task.get("title")
        task_id = task.get("id")
        print(f"Processing: {title} ({task_id})")
        props = map_dart_to_consideration(task)
        resp = add_consideration(props)
        if resp.status_code >= 400:
            print(f"  Error: {resp.status_code} - {resp.text}")
        else:
            print(f"  Added")
        time.sleep(0.2)
    
    print("Done.")

if __name__ == "__main__":
    main()