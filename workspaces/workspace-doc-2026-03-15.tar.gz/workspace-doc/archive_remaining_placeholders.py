#!/usr/bin/env python3
import os
import requests
import json
import time

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

print("Fetching all pages...")
resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
                     headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Error fetching pages: {resp.text}")
    exit(1)

pages = resp.json().get('results', [])
print(f"Total pages: {len(pages)}")

to_archive = []
for page in pages:
    pid = page['id']
    archived = page.get('archived', False)
    props = page.get('properties', {})
    notes_obj = props.get('Notes', {}).get('rich_text', [])
    notes = notes_obj[0].get('text', {}).get('content', '') if notes_obj else ''
    website = props.get('Website', {}).get('url', '')
    is_placeholder = ('agedcareguide.com.au' not in website) and ('Source: agedcareguide.com.au' not in notes)
    if is_placeholder and not archived:
        to_archive.append(pid)

print(f"Found {len(to_archive)} placeholder pages not yet archived.")

if not to_archive:
    print("All placeholder pages already archived.")
    exit(0)

archived_count = 0
for pid in to_archive:
    print(f"Archiving {pid}...")
    resp = requests.patch(f"https://api.notion.com/v1/pages/{pid}",
                          headers=headers,
                          json={"archived": True})
    if resp.status_code == 200:
        archived_count += 1
        print(f"  Archived")
    else:
        print(f"  Failed: {resp.status_code} {resp.text[:200]}")
    time.sleep(0.3)

print(f"\nArchived {archived_count} placeholder pages.")