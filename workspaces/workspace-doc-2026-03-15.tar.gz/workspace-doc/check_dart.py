#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json
from datetime import datetime

client = DartClient()

# Get stroke task
stroke_id = 'YhH8uggrObRf'
try:
    stroke = client.get_task(stroke_id)
    print(f"Stroke Task: {stroke.get('title')}")
    print(f"Status: {stroke.get('status')}")
    print(f"Updated: {stroke.get('updatedAt')}")
    print(f"Subtasks: {len(stroke.get('subtasks', []))}")
    # Check description for JSON block
    desc = stroke.get('description', '')
    if 'stroke_event_data' in desc:
        print("✓ JSON block present")
    else:
        print("✗ JSON block missing")
    print()
except Exception as e:
    print(f"Error fetching stroke task: {e}")

# List recent tasks for Edward Mills (filter by tag maybe)
try:
    tasks = client.list_tasks(limit=20)
    edward_tasks = [t for t in tasks if 'patient-edward-mills' in t.get('tags', [])]
    print(f"Edward Mills tasks: {len(edward_tasks)}")
    for t in edward_tasks[:5]:
        print(f"  - {t['title']} ({t['status']}) updated {t.get('updatedAt')}")
except Exception as e:
    print(f"Error listing tasks: {e}")

# Check if any tasks are stale (>7 days)
try:
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    stale = []
    for t in edward_tasks:
        updated = datetime.fromisoformat(t['updatedAt'].replace('Z', '+00:00'))
        age = (now - updated).days
        if age > 7:
            stale.append((t['title'], age))
    if stale:
        print(f"\n⚠️  Stale tasks (>7 days):")
        for title, age in stale:
            print(f"   {title} ({age} days)")
    else:
        print("\n✅ No stale tasks")
except Exception as e:
    print(f"Error checking staleness: {e}")