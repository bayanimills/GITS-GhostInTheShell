#!/usr/bin/env python3
"""
Fix Dart tasks per user request:
1. Mark stale Edward Mills tasks as Done
2. Update Dart end-of-life tasks to reflect Notion's Completed status
3. Deduplicate Will/Advance Care Directive/Power of Attorney entries
"""
import os
import sys
import requests
import json
from datetime import datetime, timezone

# Add scripts directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'scripts'))
from dart_client import DartClient

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Database IDs
END_OF_LIFE_DB_ID = "d83a5dff-506f-4368-9c49-4c11b50ce33d"

def get_edward_mills_tasks(client):
    """Get all Edward Mills tasks."""
    resp = client.list_tasks()
    tasks = resp.get('results', [])
    edward_tasks = []
    for t in tasks:
        if t.get('dartboard', '').startswith('Edward Mills/'):
            edward_tasks.append(t)
        elif 'patient-edward-mills' in t.get('tags', []):
            edward_tasks.append(t)
    return edward_tasks

def mark_stale_edward_tasks_done():
    """Mark stale (>7 days) Edward Mills To-do tasks as Done."""
    client = DartClient()
    edward_tasks = get_edward_mills_tasks(client)
    
    stale = []
    for t in edward_tasks:
        updated = t.get('updatedAt')
        if not updated:
            continue
        updated_dt = datetime.fromisoformat(updated.replace('Z', '+00:00'))
        delta = datetime.now(timezone.utc) - updated_dt
        if delta.days >= 7 and t.get('status') == 'To-do':
            stale.append((t['id'], t['title'], delta.days))
    
    print(f"Found {len(stale)} stale Edward Mills To-do tasks:")
    for task_id, title, days in stale:
        print(f"  - {task_id}: {title[:60]} ({days} days)")
    
    # Update to Done
    for task_id, title, days in stale:
        try:
            resp = client.update_task(task_id, status="Done")
            if resp.get('status') == 'Done':
                print(f"✓ Updated {task_id} to Done")
            else:
                print(f"✗ Failed to update {task_id}: {resp}")
        except Exception as e:
            print(f"✗ Error updating {task_id}: {e}")

def update_dart_from_notion_completed():
    """Update Dart tasks to Done if corresponding Notion task is Completed."""
    # Query Notion for Completed tasks with Dart Task ID
    url = f"https://api.notion.com/v1/databases/{END_OF_LIFE_DB_ID}/query"
    payload = {
        "filter": {
            "property": "Status",
            "select": {
                "equals": "Completed"
            }
        }
    }
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload)
    if resp.status_code != 200:
        print(f"Notion query failed: {resp.status_code}")
        print(resp.text)
        return
    
    data = resp.json()
    results = data.get('results', [])
    completed = []
    for page in results:
        props = page.get('properties', {})
        task_name = props.get('Task', {}).get('title', [{}])[0].get('text', {}).get('content', 'No name')
        dart_id_prop = props.get('Dart Task ID', {}).get('rich_text', [{}])
        dart_id = dart_id_prop[0].get('text', {}).get('content', '') if dart_id_prop else ''
        if dart_id:
            completed.append((dart_id.strip(), task_name))
    
    print(f"Found {len(completed)} Completed tasks in Notion:")
    for dart_id, task_name in completed:
        print(f"  - {dart_id}: {task_name}")
    
    if not completed:
        return
    
    client = DartClient()
    for dart_id, task_name in completed:
        try:
            # Check current status
            task = client.get_task(dart_id)
            if task.get('status') == 'Done':
                print(f"✓ {dart_id} already Done")
                continue
            
            resp = client.update_task(dart_id, status="Done")
            if resp.get('status') == 'Done':
                print(f"✓ Updated {dart_id} to Done")
            else:
                print(f"✗ Failed to update {dart_id}: {resp}")
        except Exception as e:
            print(f"✗ Error updating {dart_id}: {e}")

def check_duplicates():
    """Check for duplicate Will/Advance Care Directive/Power of Attorney tasks."""
    client = DartClient()
    edward_tasks = get_edward_mills_tasks(client)
    
    keywords = ['will', 'advance care directive', 'power of attorney', 'poa', 'advance directive']
    keyword_matches = {kw: [] for kw in keywords}
    
    for t in edward_tasks:
        title_lower = t['title'].lower()
        for kw in keywords:
            if kw in title_lower:
                keyword_matches[kw].append((t['id'], t['title'], t['status']))
    
    print("\nTasks by keyword:")
    for kw, matches in keyword_matches.items():
        if matches:
            print(f"\n  {kw.upper()}: {len(matches)} tasks")
            for tid, title, status in matches:
                print(f"    - {tid}: {title} ({status})")
    
    # Suggest deduplication
    duplicate_titles = {}
    for t in edward_tasks:
        title = t['title'].lower()
        duplicate_titles.setdefault(title, []).append(t['id'])
    
    exact_duplicates = {title: ids for title, ids in duplicate_titles.items() if len(ids) > 1}
    if exact_duplicates:
        print("\n⚠️  EXACT DUPLICATE TITLES:")
        for title, ids in exact_duplicates.items():
            print(f"  '{title}':")
            for tid in ids:
                print(f"    - {tid}")
        print("\nConsider merging or archiving duplicates.")
    else:
        print("\nNo exact duplicate titles found.")

if __name__ == '__main__':
    print("=== Dart Task Fixes ===\n")
    
    print("1. Marking stale Edward Mills tasks as Done...")
    mark_stale_edward_tasks_done()
    
    print("\n2. Updating Dart from Notion Completed status...")
    update_dart_from_notion_completed()
    
    print("\n3. Checking for duplicates...")
    check_duplicates()
    
    print("\n=== Done ===")