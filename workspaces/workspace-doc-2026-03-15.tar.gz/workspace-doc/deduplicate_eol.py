#!/usr/bin/env python3
import os
import requests
import json
from datetime import datetime

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'
DRY_RUN = False  # Set to False to actually delete/update

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

def get_prop(page, prop_name, prop_type):
    prop = page.get('properties', {}).get(prop_name, {})
    if prop.get('type') != prop_type:
        return None
    if prop_type == 'title':
        titles = prop.get('title', [])
        if titles:
            return titles[0].get('plain_text', '')
        return ''
    elif prop_type == 'select':
        select = prop.get('select', {})
        if select is None:
            return None
        return select.get('name')
    elif prop_type == 'date':
        date = prop.get('date')
        if date is None:
            return None
        return date.get('start')
    elif prop_type == 'rich_text':
        rich_text = prop.get('rich_text', [])
        if rich_text:
            return rich_text[0].get('plain_text', '')
        return ''
    else:
        return None

def set_prop(prop_name, prop_type, value):
    if prop_type == 'select':
        return {'select': {'name': value}}
    elif prop_type == 'date':
        return {'date': {'start': value}}
    elif prop_type == 'title':
        return {'title': [{'text': {'content': value}}]}
    elif prop_type == 'rich_text':
        return {'rich_text': [{'text': {'content': value}}]}
    else:
        return {}

def fetch_all_pages():
    """Fetch all pages from database"""
    url = f'https://api.notion.com/v1/databases/{DATABASE_ID}/query'
    all_pages = []
    cursor = None
    while True:
        payload = {}
        if cursor:
            payload['start_cursor'] = cursor
        response = requests.post(url, headers=headers, json=payload)
        if response.status_code != 200:
            print(f"Error fetching pages: {response.status_code} {response.text}")
            break
        data = response.json()
        all_pages.extend(data.get('results', []))
        cursor = data.get('next_cursor')
        if not cursor:
            break
    return all_pages

def delete_page(page_id):
    url = f'https://api.notion.com/v1/pages/{page_id}'
    response = requests.delete(url, headers=headers)
    return response.status_code == 200

def update_page(page_id, properties):
    url = f'https://api.notion.com/v1/pages/{page_id}'
    payload = {'properties': properties}
    response = requests.patch(url, headers=headers, json=payload)
    return response.status_code == 200

def main():
    pages = fetch_all_pages()
    print(f"Found {len(pages)} pages")
    
    # Group by task name
    groups = {}
    for page in pages:
        task = get_prop(page, 'Task', 'title')
        if not task:
            continue
        groups.setdefault(task, []).append(page)
    
    # Identify duplicates
    duplicates = {task: pages for task, pages in groups.items() if len(pages) > 1}
    if duplicates:
        print(f"\nDuplicate tasks ({len(duplicates)}):")
        for task, pages in duplicates.items():
            print(f"  {task}: {len(pages)} copies")
    
    # Decide which to keep (earliest due date, or first)
    to_delete = []
    for task, pages in groups.items():
        if len(pages) == 1:
            continue
        # Sort by due date (None last), then by page ID
        def sort_key(p):
            due = get_prop(p, 'Due Date', 'date')
            if due:
                try:
                    return (0, datetime.fromisoformat(due).timestamp())
                except:
                    return (1, 0)
            return (2, p['id'])
        pages.sort(key=sort_key)
        # Keep first
        keep = pages[0]
        for page in pages[1:]:
            to_delete.append(page)
        print(f"Keeping page {keep['id']} for '{task}' (due: {get_prop(keep, 'Due Date', 'date')})")
    
    # Delete duplicates
    if to_delete:
        print(f"\nWill delete {len(to_delete)} duplicate pages")
        for page in to_delete:
            task = get_prop(page, 'Task', 'title')
            if DRY_RUN:
                print(f"  [DRY RUN] Would delete page {page['id']} ('{task}')")
            else:
                if delete_page(page['id']):
                    print(f"  Deleted page {page['id']} ('{task}')")
                else:
                    print(f"  Failed to delete page {page['id']} ('{task}')")
    else:
        print("\nNo duplicates to delete")
    
    # Update status for Will and Funeral tasks
    print("\nUpdating status for Will and Funeral tasks:")
    will_updated = False
    funeral_updated = False
    for task_name, pages in groups.items():
        if 'will' in task_name.lower():
            for page in pages:
                if page in to_delete:
                    continue  # will be deleted
                task = get_prop(page, 'Task', 'title')
                print(f"  Found '{task}' (page {page['id']})")
                if DRY_RUN:
                    print(f"    [DRY RUN] Would update status to 'Completed'")
                else:
                    props = {'Status': set_prop('Status', 'select', 'Completed')}
                    if update_page(page['id'], props):
                        print(f"    Updated status to 'Completed'")
                        will_updated = True
                    else:
                        print(f"    Failed to update")
                break  # only first remaining page
        if 'funeral' in task_name.lower() or 'funeral wishes' in task_name.lower():
            for page in pages:
                if page in to_delete:
                    continue
                task = get_prop(page, 'Task', 'title')
                print(f"  Found '{task}' (page {page['id']})")
                if DRY_RUN:
                    print(f"    [DRY RUN] Would update status to 'Completed'")
                else:
                    props = {'Status': set_prop('Status', 'select', 'Completed')}
                    if update_page(page['id'], props):
                        print(f"    Updated status to 'Completed'")
                        funeral_updated = True
                    else:
                        print(f"    Failed to update")
                break
    
    print("\nSummary:")
    print(f"  Duplicate pages to delete: {len(to_delete)}")
    print(f"  Will task updated: {will_updated}")
    print(f"  Funeral task updated: {funeral_updated}")
    if DRY_RUN:
        print("\n*** DRY RUN - no changes made. Set DRY_RUN=False to execute. ***")

if __name__ == '__main__':
    main()