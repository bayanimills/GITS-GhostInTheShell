#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
db_id = "6088ea51-fa49-4102-a6fb-250eccc9f1ad"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

payload = {
    "parent": {"database_id": db_id},
    "properties": {
        "Name": {
            "title": [
                {"text": {"content": "BaptistCare Northern Beaches Aged Care"}}
            ]
        }
    }
}

print("Creating page...")
resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
if resp.status_code == 200:
    page = resp.json()
    print(f"✅ Page created: {page['id']}")
    print(f"   URL: https://notion.so/{page['id'].replace('-', '')}")
else:
    print(f"❌ Error {resp.status_code}: {resp.text[:500]}")