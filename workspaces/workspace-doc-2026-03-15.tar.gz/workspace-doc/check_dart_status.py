#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json
from datetime import datetime, timezone

def iso_to_datetime(iso: str) -> datetime:
    # Remove trailing Z and convert to offset-aware
    iso = iso.replace('Z', '+00:00')
    return datetime.fromisoformat(iso)

client = DartClient()

print("## Dart Status Check - Edward Mills Stroke Event\n")

# 1. Stroke task
stroke_id = 'YhH8uggrObRf'
try:
    stroke = client.get_task(stroke_id)
    print(f"**Stroke Task**: [{stroke['title']}]({stroke['htmlUrl']})")
    print(f"  • Status: {stroke['status']}")
    updated = iso_to_datetime(stroke['updatedAt'])
    now = datetime.now(timezone.utc)
    age_days = (now - updated).days
    print(f"  • Updated: {stroke['updatedAt']} ({age_days} days ago)")
    desc = stroke.get('description', '')
    if 'stroke_event_data' in desc:
        print("  • JSON tracking block: ✓ present")
    else:
        print("  • JSON tracking block: ✗ missing")
    print()
except Exception as e:
    print(f"Error fetching stroke task: {e}")
    sys.exit(1)

# 2. Subtasks (tasks with parentId = stroke_id)
try:
    all_tasks = client.list_tasks(limit=100)
    results = all_tasks.get('results', [])
    subtasks = [t for t in results if t.get('parentId') == stroke_id]
    print(f"**Subtasks**: {len(subtasks)} found")
    for st in subtasks:
        print(f"  • [{st['title']}]({st['htmlUrl']}) – {st['status']}")
        updated = iso_to_datetime(st['updatedAt'])
        age = (now - updated).days
        if age > 7:
            print(f"    ⚠️  Stale ({age} days)")
    print()
except Exception as e:
    print(f"Error fetching subtasks: {e}")

# 3. Other Edward Mills tasks (tag patient-edward-mills)
try:
    edward_tasks = [t for t in results if 'patient-edward-mills' in t.get('tags', [])]
    print(f"**All Edward Mills tasks**: {len(edward_tasks)} total")
    # Group by status
    by_status = {}
    for t in edward_tasks:
        by_status.setdefault(t['status'], []).append(t)
    for status, tasks in by_status.items():
        print(f"  • {status}: {len(tasks)}")
    print()
except Exception as e:
    print(f"Error grouping tasks: {e}")

# 4. Check for tasks created today
try:
    today = now.date()
    recent = []
    for t in results:
        created = iso_to_datetime(t['createdAt']).date()
        if created == today:
            recent.append(t)
    if recent:
        print(f"**New tasks today**: {len(recent)}")
        for t in recent:
            print(f"  • [{t['title']}]({t['htmlUrl']}) – {t['status']}")
    else:
        print("**New tasks today**: none")
    print()
except Exception as e:
    print(f"Error checking recent tasks: {e}")

# 5. Comments on stroke task (if endpoint exists)
try:
    # Use client._request to fetch comments
    comments = client._request('GET', f'/comments/list?taskId={stroke_id}')
    comment_items = comments.get('results', []) if isinstance(comments, dict) else comments
    print(f"**Comments on stroke task**: {len(comment_items)}")
    for c in comment_items[:3]:
        text = c.get('text', '').replace('\n', ' ')[:80]
        print(f"  • {c.get('createdBy', {}).get('name', 'Unknown')}: {text}...")
    if len(comment_items) > 3:
        print(f"  ... and {len(comment_items) - 3} more")
    print()
except Exception as e:
    print(f"Could not fetch comments (API may not support): {e}")

# 6. Overall stale check (>7 days)
try:
    stale = []
    for t in edward_tasks:
        updated = iso_to_datetime(t['updatedAt'])
        age = (now - updated).days
        if age > 7:
            stale.append((t['title'], age, t['htmlUrl']))
    if stale:
        print("⚠️ **Stale tasks (>7 days without update)**")
        for title, age, url in stale:
            print(f"  • [{title}]({url}) – {age} days")
    else:
        print("✅ All Edward Mills tasks updated within the last 7 days.")
except Exception as e:
    print(f"Error in stale check: {e}")

print("\n---\n*Check completed at {}*".format(now.isoformat()[:19]))