#!/usr/bin/env python3
import sys

with open('memory/2026-02-21.md', 'r') as f:
    lines = f.read()

new_section = """
## 12:45 UTC – Suburb & Postcode Columns Added

**Request:** Add separate columns for suburbs and postcodes, get list of all postcodes on Sydney's Northern Beaches and search in those areas.

**Actions taken:**

1. **Added Suburb and Postcode properties** to the Notion data source (rich_text fields).
2. **Extracted suburb and postcode** from existing address fields for all 16 entries; updated missing values.
3. **Compiled comprehensive mapping** of 52 Northern Beaches suburbs with postcodes (based on Wikipedia list and local knowledge).
   - Saved as `northern_beaches_suburbs_postcodes.json` for future reference.
   - Database now includes 9 unique suburbs: Frenchs Forest, Dee Why, Narrabeen, Allambie Heights, Balgowlah, Manly Vale, Manly, Freshwater, Seaforth.
4. **Database now filterable** by suburb or postcode, enabling targeted searches across the region.

**Outcome:**
- Suburb and Postcode columns populated for all entries.
- Complete suburb‑postcode mapping available for future searches.
- Database ready for geographic filtering and expansion with real data.

**Tags:** #notion #suburb #postcode #data-enrichment #northern-beaches
"""

with open('memory/2026-02-21.md', 'w') as f:
    f.write(lines.rstrip() + '\n' + new_section)

print("Appended new section.")