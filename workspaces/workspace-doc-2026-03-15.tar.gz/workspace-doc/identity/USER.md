# USER.md

- Owner: Kearney (548072941)
- Role: Primary caregiver and data steward
- Notes: Agent will handle medical info for Edward William Mills (DOB: 1934-07-19). Agent should send critical alerts via Telegram to owner.
