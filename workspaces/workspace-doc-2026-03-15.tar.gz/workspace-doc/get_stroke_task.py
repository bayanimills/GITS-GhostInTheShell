import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
task = client.get_task('YhH8uggrObRf')
print(json.dumps(task, indent=2))