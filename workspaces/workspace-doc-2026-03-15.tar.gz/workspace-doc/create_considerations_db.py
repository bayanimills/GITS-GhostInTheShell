#!/usr/bin/env python3
import os
import requests
import json
import sys

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

PAGE_ID = "30dd323b-89ec-8064-ba6e-c5ca7689ed67"

def get_child_databases():
    """Return list of child database blocks on the page."""
    url = f"https://api.notion.com/v1/blocks/{PAGE_ID}/children"
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    data = resp.json()
    dbs = []
    for block in data.get("results", []):
        if block.get("type") == "child_database":
            title = block.get("child_database", {}).get("title", "")
            dbs.append({"id": block["id"], "title": title})
    return dbs

def create_considerations_database():
    """Create Considerations database."""
    payload = {
        "parent": {"type": "page_id", "page_id": PAGE_ID},
        "title": [{"text": {"content": "Considerations"}}],
        "is_inline": True,
        "properties": {
            "Consideration": {"title": {}},
            "Category": {
                "select": {
                    "options": [
                        {"name": "Medical", "color": "red"},
                        {"name": "Appointment", "color": "blue"},
                        {"name": "Medication", "color": "green"},
                        {"name": "Care Coordination", "color": "orange"},
                        {"name": "Financial", "color": "purple"},
                        {"name": "Legal", "color": "brown"},
                        {"name": "Family", "color": "pink"}
                    ]
                }
            },
            "Priority": {
                "select": {
                    "options": [
                        {"name": "High", "color": "red"},
                        {"name": "Medium", "color": "yellow"},
                        {"name": "Low", "color": "gray"}
                    ]
                }
            },
            "Due Date": {"date": {}},
            "Status": {
                "select": {
                    "options": [
                        {"name": "Pending", "color": "yellow"},
                        {"name": "In Progress", "color": "blue"},
                        {"name": "Completed", "color": "green"},
                        {"name": "Deferred", "color": "gray"}
                    ]
                }
            },
            "Notes": {"rich_text": {}},
            "Source": {
                "select": {
                    "options": [
                        {"name": "Dart", "color": "blue"},
                        {"name": "Manual", "color": "orange"},
                        {"name": "Checklist", "color": "green"}
                    ]
                }
            },
            "Linked Task ID": {"rich_text": {}}
        }
    }
    url = "https://api.notion.com/v1/databases"
    resp = requests.post(url, headers=headers, json=payload)
    resp.raise_for_status()
    db = resp.json()
    return db

def main():
    # Check if Considerations database already exists
    dbs = get_child_databases()
    considerations_db = None
    for db in dbs:
        if db["title"] == "Considerations":
            considerations_db = db
            print(f"Considerations database already exists: {db['id']}")
            break
    if not considerations_db:
        print("Creating Considerations database...")
        db = create_considerations_database()
        considerations_db = {"id": db["id"], "title": db["title"][0]["text"]["content"]}
        print(f"Created database: {considerations_db['id']}")
    else:
        # Fetch existing entries to avoid duplicates (simplistic)
        pass
    
    print("Considerations database ready.")
    print("Next step: populate with considerations from Dart tasks and checklist.")

if __name__ == "__main__":
    main()