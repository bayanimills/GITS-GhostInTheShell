import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

database_id = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'
url = f'https://api.notion.com/v1/databases/{database_id}'
resp = requests.get(url, headers=HEADERS)
print(f'Status: {resp.status_code}')
if resp.status_code == 200:
    db = resp.json()
    print('Properties:')
    for key, prop in db.get('properties', {}).items():
        print(f'  {key}: {prop.get("type")}')
    print('\nFull:')
    print(json.dumps(db, indent=2))
else:
    print(resp.text)