import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

def update_data_source(data_source_id, new_properties):
    """Add new properties to a data source."""
    # Get current properties
    url = f'https://api.notion.com/v1/data_sources/{data_source_id}'
    resp = requests.get(url, headers=HEADERS)
    if resp.status_code != 200:
        print(f'Failed to get data source: {resp.text}')
        return False
    ds = resp.json()
    existing = ds.get('properties', {})
    # Merge
    for key, prop in new_properties.items():
        if key not in existing:
            existing[key] = prop
        else:
            print(f'Property {key} already exists')
    # Update
    patch_payload = {'properties': existing}
    patch_resp = requests.patch(url, headers=HEADERS, json=patch_payload)
    print(f'PATCH status: {patch_resp.status_code}')
    if patch_resp.status_code != 200:
        print(f'Error: {patch_resp.text}')
        return False
    print('Update successful')
    return True

# Properties for End-of-Life Planning
eol_new_props = {
    'Category': {
        'name': 'Category',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Medical', 'color': 'red'},
                {'name': 'Financial', 'color': 'green'},
                {'name': 'Personal', 'color': 'purple'},
                {'name': 'Digital', 'color': 'orange'},
                {'name': 'Funeral', 'color': 'brown'}
            ]
        }
    },
    'Status': {
        'name': 'Status',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'On Hold', 'color': 'orange'}
            ]
        }
    },
    'Priority': {
        'name': 'Priority',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'High', 'color': 'red'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'blue'}
            ]
        }
    },
    'Due Date': {'name': 'Due Date', 'type': 'date', 'date': {}},
    'Assigned To': {'name': 'Assigned To', 'type': 'rich_text', 'rich_text': {}},
    'Notes': {'name': 'Notes', 'type': 'rich_text', 'rich_text': {}},
    'Completed Date': {'name': 'Completed Date', 'type': 'date', 'date': {}},
    'Documents': {'name': 'Documents', 'type': 'files', 'files': {}},
    'Dart Task ID': {'name': 'Dart Task ID', 'type': 'rich_text', 'rich_text': {}},
    'Related Person': {'name': 'Related Person', 'type': 'rich_text', 'rich_text': {}}
}

# Properties for After-Death Checklist
ad_new_props = {
    'Category': {
        'name': 'Category',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Immediate (24h)', 'color': 'red'},
                {'name': 'Within Week', 'color': 'orange'},
                {'name': 'Within Month', 'color': 'yellow'},
                {'name': 'Long-term', 'color': 'green'},
                {'name': 'Legal', 'color': 'blue'},
                {'name': 'Financial', 'color': 'purple'},
                {'name': 'Administrative', 'color': 'pink'}
            ]
        }
    },
    'Status': {
        'name': 'Status',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Not Started', 'color': 'gray'},
                {'name': 'In Progress', 'color': 'yellow'},
                {'name': 'Completed', 'color': 'green'},
                {'name': 'Delegated', 'color': 'blue'}
            ]
        }
    },
    'Priority': {
        'name': 'Priority',
        'type': 'select',
        'select': {
            'options': [
                {'name': 'Critical', 'color': 'red'},
                {'name': 'High', 'color': 'orange'},
                {'name': 'Medium', 'color': 'yellow'},
                {'name': 'Low', 'color': 'green'}
            ]
        }
    },
    'Due Date': {'name': 'Due Date', 'type': 'date', 'date': {}},
    'Assigned To': {'name': 'Assigned To', 'type': 'rich_text', 'rich_text': {}},
    'Notes': {'name': 'Notes', 'type': 'rich_text', 'rich_text': {}},
    'Completed Date': {'name': 'Completed Date', 'type': 'date', 'date': {}},
    'Contact Info': {'name': 'Contact Info', 'type': 'rich_text', 'rich_text': {}},
    'Documents': {'name': 'Documents', 'type': 'files', 'files': {}},
    'Dart Task ID': {'name': 'Dart Task ID', 'type': 'rich_text', 'rich_text': {}}
}

print('Updating End-of-Life Planning data source...')
eol_ds_id = '562af9af-f953-4bdb-92d7-ebb0c3020f4c'
if update_data_source(eol_ds_id, eol_new_props):
    print('✓ End-of-Life Planning updated')
else:
    print('✗ Failed')

print('\nUpdating After-Death Checklist data source...')
ad_ds_id = '7343ed8d-de9a-42ae-a787-c18f686dac1e'
if update_data_source(ad_ds_id, ad_new_props):
    print('✓ After-Death Checklist updated')
else:
    print('✗ Failed')