# Cron Job Pattern for Reliable Reminders

This document details the exact cron‑job configuration that ensures reminders deliver as proactive Telegram messages (not just system events).

## Why This Pattern Works

- **Isolated session**: The job runs in a separate agent session, allowing it to send messages independently.
- **Agent‑turn payload**: The agent receives a message instructing it to send a Telegram message.
- **Announce delivery**: The job’s output is announced to the specified channel as a normal chat message.
- **No session‑history contamination**: The isolated session doesn’t carry the main session’s context, reducing token usage.

## JSON Schema (for direct cron tool calls)

```json
{
  "name": "Descriptive name",
  "schedule": {
    "kind": "at",
    "at": "2026-02-22T03:00:00.000Z"
  },
  "sessionTarget": "isolated",
  "payload": {
    "kind": "agentTurn",
    "message": "Send Telegram message: 'Reminder: Your text here.'",
    "model": "deepseek/deepseek-reasoner",
    "thinking": "off",
    "timeoutSeconds": 30
  },
  "delivery": {
    "mode": "announce",
    "channel": "telegram",
    "to": "548072941",
    "bestEffort": true
  },
  "deleteAfterRun": true,
  "enabled": true
}
```

## Schedule Variants

### One‑shot at a specific time

```json
"schedule": {
  "kind": "at",
  "at": "2026-02-22T14:00:00+11:00"
}
```

The `at` field accepts:
- ISO 8601 timestamps (with or without timezone)
- Relative times: `"20m"`, `"1h"` (the plus sign `+` is not required; the script automatically strips it if provided)
- Natural language (parsed by the OpenClaw scheduler): `"2pm"`, `"tomorrow 9am"`

### Recurring with an interval

```json
"schedule": {
  "kind": "every",
  "everyMs": 3600000,
  "anchorMs": 1708574400000
}
```

- `everyMs`: interval in milliseconds (e.g., 3600000 = 1 hour)
- `anchorMs` (optional): start time in milliseconds since epoch; if omitted, the first run starts at the next whole interval after job creation.

### Cron expression

```json
"schedule": {
  "kind": "cron",
  "expr": "0 9 * * *",
  "tz": "Australia/Sydney"
}
```

- `expr`: standard 5‑field cron (minutes hours day‑of‑month month day‑of‑week)
- `tz`: IANA timezone name (optional, defaults to UTC)

## Delivery Configuration

The `delivery` block controls how the reminder reaches the user:

```json
"delivery": {
  "mode": "announce",
  "channel": "telegram",
  "to": "548072941",
  "bestEffort": true
}
```

- `mode`: Must be `"announce"` for proactive messages.
- `channel`: The channel plugin name (`telegram`, `signal`, `whatsapp`, etc.).
- `to`: The recipient identifier (Telegram chat ID, phone number, Discord channel ID).
- `bestEffort`: If `true`, the job won’t fail if delivery temporarily fails.

If `delivery` is omitted, the job will still run but won’t send a message unless the agent inside the job calls `message` tool itself.

## Common Mistakes

### Using `sessionTarget: "main"` with `payload.kind: "systemEvent"`

This only injects text into the session log; no Telegram message is sent.

**Incorrect:**
```json
"sessionTarget": "main",
"payload": {
  "kind": "systemEvent",
  "text": "Reminder: Get cushion"
}
```

**Correct:** Use isolated + agentTurn.

### Forgetting `delivery.mode: "announce"`

Without `announce`, the agent’s output stays in the isolated session and never reaches the user.

### Wrong `channel` or `to` values

- `channel` must match the configured channel plugin (case‑sensitive).
- `to` must be a valid destination for that channel (e.g., Telegram chat ID, not a username).

## Testing the Pattern

You can test a reminder immediately with `--wake now`:

```bash
openclaw cron add \
  --name "Test reminder" \
  --at "1m" \
  --session isolated \
  --message "Send Telegram message: 'Reminder: This is a test.'" \
  --announce \
  --to "548072941" \
  --delete-after-run \
  --wake now
```

The job will run in one minute and deliver the message.

## Debugging

If a reminder doesn’t arrive:

1. Check the job’s run history:
   ```bash
   openclaw cron runs <jobId>
   ```
2. Look for errors in the gateway logs (if accessible).
3. Verify the `channel` and `to` match an active session.

## See Also

- OpenClaw CLI: `openclaw cron add --help`
- `scripts/set_reminder.py` – ready‑to‑use wrapper script