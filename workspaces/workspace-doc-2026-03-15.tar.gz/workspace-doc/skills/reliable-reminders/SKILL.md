---
name: reliable-reminders
description: Set reliable one‑time or recurring reminders that deliver as proper Telegram messages (not just system events). Use when an agent needs to schedule a reminder for the user, ensuring the notification arrives as a proactive message via the configured channel (Telegram, Signal, etc.). This skill provides the correct cron‑job pattern with isolated agent‑turn and announce delivery, avoiding the pitfall of system‑event‑only reminders.
---

# Reliable Reminders

## Overview

This skill provides a proven pattern and ready‑to‑use script for scheduling reminders that **actually notify the user** via Telegram (or other configured channels). It fixes the common pitfall where reminders are created as system‑event‑only cron jobs, which merely inject text into the session log without sending a proactive message.

The skill uses the OpenClaw CLI to create an **isolated agent‑turn job with announce delivery**, ensuring the reminder appears as a normal chat message exactly when scheduled.

## Quick Start

To schedule a reminder that sends a Telegram message at a specific time:

```bash
python3 scripts/set_reminder.py "Get a small cushion for dad" --at "2pm"
```

Or directly with the OpenClaw CLI:

```bash
openclaw cron add \
  --name "Cushion reminder" \
  --at "2pm" \
  --session isolated \
  --message "Send Telegram message: 'Reminder: Get a small cushion for dad.'" \
  --announce \
  --to "548072941" \
  --delete-after-run
```

## When to Use This Skill

Use this skill when:

- The user asks for a reminder (e.g., “remind me to…”)
- You need to schedule a one‑time or recurring notification
- The reminder must arrive as a visible Telegram message (not just a system event)
- You want to avoid the “missed notification” feedback

Do **not** use this skill for:
- Internal session notes (use `systemEvent` with `sessionTarget="main"`)
- Background tasks that don’t need user notification

## Script Usage

The `scripts/set_reminder.py` script wraps the OpenClaw CLI for convenience.

### Installation

No installation needed—the script runs with the workspace’s Python environment.

### Arguments

```
usage: set_reminder.py [-h] [--at AT] [--every EVERY] [--name NAME] [--to TO] message

positional arguments:
  message               Reminder text (will be prefixed with "Reminder: ")

optional arguments:
  -h, --help            show this help message and exit
  --at AT               When to run (ISO timestamp, "2pm", "tomorrow 9am", "+20m")
  --every EVERY         Recurring interval (e.g., "1h", "30m")
  --name NAME           Job name (default: "Reminder")
  --to TO               Delivery destination (Telegram chat ID, default: "548072941")
```

Note: The script automatically strips a leading '+' from the `--at` value (e.g., '+20m' becomes '20m') because the OpenClaw CLI expects duration without a plus sign.

### Examples

**One‑time reminder at 2pm today:**
```bash
python3 scripts/set_reminder.py "Pick up groceries" --at "2pm"
```

**Reminder in 20 minutes:**
```bash
python3 scripts/set_reminder.py "Call the doctor" --at "+20m"
```

**Recurring reminder every day at 9am:**
```bash
python3 scripts/set_reminder.py "Take medication" --every "24h" --at "09:00"
```

**Custom destination:**
```bash
python3 scripts/set_reminder.py "Water the plants" --at "18:00" --to "123456789"
```

## Manual Pattern (for direct cron tool calls)

If you prefer to call the cron tool directly from an agent, use this JSON payload:

```json
{
  "name": "Descriptive name",
  "schedule": { "kind": "at", "at": "2026-02-22T03:00:00.000Z" },
  "sessionTarget": "isolated",
  "payload": {
    "kind": "agentTurn",
    "message": "Send Telegram message: 'Reminder: Your text here.'"
  },
  "delivery": {
    "mode": "announce",
    "channel": "telegram",
    "to": "548072941"
  },
  "deleteAfterRun": true
}
```

Key points:
- `sessionTarget` must be `"isolated"`
- `payload.kind` must be `"agentTurn"`
- The `message` should start with `"Send Telegram message: 'Reminder: …'"`
- `delivery.mode` must be `"announce"` with `channel` and `to` set
- Use `deleteAfterRun: true` for one‑shot reminders

## Troubleshooting

**The reminder didn’t arrive as a Telegram message:**
- Ensure `sessionTarget` is `"isolated"` (not `"main"`)
- Ensure `delivery.mode` is `"announce"` (or `--announce` flag)
- Check that `channel` and `to` match the user’s active channel

**The reminder fired but I only saw a `[System: …]` message:**
- You used `sessionTarget="main"` with `payload.kind="systemEvent"`. Switch to the isolated agent‑turn pattern.

**I'm getting duplicate reminder messages:**
- This can happen if the cron job already has `announce` delivery and the agent also converts the system event. Ensure you are not manually converting cron completion messages for jobs that already send their own notifications.

**I want to cancel a reminder:**
Use `openclaw cron rm <jobId>` or delete via the cron tool in the agent session.

## Resources

### scripts/set_reminder.py
The main utility script. See the script’s `--help` for full details.

### references/cron_pattern.md
Detailed breakdown of the cron job configuration with examples for different schedules (one‑shot, recurring, cron expressions).