#!/usr/bin/env python3
"""
Set a reliable reminder that delivers as a Telegram message.

This script wraps `openclaw cron add` with the correct pattern for
isolated agent‑turn jobs with announce delivery, ensuring the reminder
arrives as a proactive Telegram message (not just a system event).
"""

import subprocess
import sys
import argparse
import shlex
import json
import os

DEFAULT_TO = "548072941"  # Default Telegram chat ID

def run_openclaw(args):
    """Run openclaw with given argument list."""
    cmd = ["openclaw"] + args
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Error running openclaw: {e.stderr}", file=sys.stderr)
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        description="Schedule a reminder that sends a Telegram message.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "Get a small cushion for dad" --at "2pm"
  %(prog)s "Call the doctor" --at "+20m"
  %(prog)s "Take medication" --every "24h" --at "09:00"
  %(prog)s "Water the plants" --at "18:00" --to "123456789"
"""
    )
    parser.add_argument(
        "message",
        help='Reminder text (will be prefixed with "Reminder: ")'
    )
    parser.add_argument(
        "--at",
        help='When to run (ISO timestamp, "2pm", "tomorrow 9am", "+20m")'
    )
    parser.add_argument(
        "--every",
        help='Recurring interval (e.g., "1h", "30m"). Requires --at for start time.'
    )
    parser.add_argument(
        "--name",
        default="Reminder",
        help='Job name (default: "Reminder")'
    )
    parser.add_argument(
        "--to",
        default=DEFAULT_TO,
        help=f'Delivery destination (Telegram chat ID, default: {DEFAULT_TO})'
    )
    
    args = parser.parse_args()
    
    if not args.at:
        print("Error: --at is required.", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    # Build the openclaw cron add command
    cmd_args = ["cron", "add"]
    cmd_args.extend(["--name", args.name])
    # Strip leading '+' because openclaw expects duration without plus
    clean_at = args.at.lstrip('+') if args.at.startswith('+') else args.at
    cmd_args.extend(["--at", clean_at])
    if args.every:
        cmd_args.extend(["--every", args.every])
    cmd_args.extend(["--session", "isolated"])
    # The agent message must start with "Send Telegram message: 'Reminder: ...'"
    full_message = f"Send Telegram message: 'Reminder: {args.message}'"
    cmd_args.extend(["--message", full_message])
    cmd_args.extend(["--announce"])
    cmd_args.extend(["--to", args.to])
    cmd_args.extend(["--delete-after-run"])
    
    print(f"Scheduling reminder: {args.message}")
    print(f"  At: {args.at}" + (f" (every {args.every})" if args.every else ""))
    if args.at != clean_at:
        print(f"  (Note: stripped leading '+')")
    print(f"  To: {args.to}")
    
    output = run_openclaw(cmd_args)
    if output:
        print(output)
    else:
        print("✅ Reminder scheduled.")

if __name__ == "__main__":
    main()