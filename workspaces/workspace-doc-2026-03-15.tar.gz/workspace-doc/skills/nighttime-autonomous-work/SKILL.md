---
name: nighttime-autonomous-work
version: 2.0.0
description: 24/7 autonomous task execution with presence-aware graduated autonomy. Extends nighttime-only system to continuous operation with safety boundaries, permission levels based on user presence, and resource-aware scheduling.
metadata:
  openclaw:
    emoji: "🌙🤖"
    category: automation
    requires:
      bins: ["python3", "cron"]
---

# Nighttime Autonomous Work Skill 🌙

## Purpose
Enables agents to autonomously execute queued tasks during nighttime hours (23:00-07:00 local time) with persistent tracking, periodic check-ins every 2 hours, and safety boundaries that prevent destructive actions or external communications.

## When to Use This Skill
Use this skill when:
- You have approved autonomous work to perform during overnight hours
- You need persistent tracking of task completion across multiple check-ins
- You want to ensure safety boundaries are respected (internal optimization only)
- You need to integrate with the agent-autonomy-kit task queue system

## When NOT to Use This Skill
- For time-sensitive tasks requiring immediate human review
- For tasks involving external communications or destructive actions
- When working outside the designated nighttime hours (23:00-07:00)
- For one-off tasks better handled through direct execution

## Core Concepts

## Governance Gate Policy (AWS3 Production)
**Status**: Applied as of AWS3 production release (2026-02-24)
- **Governance gates are deprecated** for AWS3 production. 
- **No /gov_* dependencies**: All `/gov_*` invocation dependencies have been removed from AWS execution paths.
- **No blocking on governance**: AWS task execution does not block on governance plugin checks.
- **AWS-native safety only**: Safety maintained via:
  - Task safety checks (internal/non-destructive)
  - Permission levels (presence-aware graduated autonomy)
  - Retry/backoff mechanisms with circuit-breaker
  - Status telemetry (human-visible monitoring)
- **Documentation updated**: All references to governance gating removed from AWS documentation.
- **Validation**: `autonomous-check.py` compiles and runs without governance dependencies.

### 1. Persistent Task Tracking
- `aws-task-queue.md` file tracks all tasks with status (pending, in-progress, completed, blocked)
- Each task includes timestamps (created, started, completed), priority, context, and permission requirements
- File is updated after each task execution with execution results and permission level used

### 2. Presence-Aware Graduated Autonomy
- **Presence source**: Consumes normalized decision-card input from adapter hooks (session probing retained only as compatibility fallback)
- **ACTIVE** (<5m since last message): User actively engaged
- **IDLE** (5-60m since last message): User potentially nearby  
- **ABSENT** (>60m since last message): User away/occupied
- **NIGHTTIME** (23:00-07:00): Full autonomy regardless of presence

### 3. Permission-Level Execution
- **read-only**: Observe/assess orchestration state (non-intrusive tasks)
- **internal-write**: Cleanup, organize, document (workspace-only changes)
- **external-read**: Consume adapter-provided inputs (e.g., decision cards), not direct scraping/intelligence
- **external-write**: Commit, push, send (external communications) – *restricted for safety*
- **full-autonomy**: All internal/non-destructive tasks (nighttime or absent)

### 4. Resource-Aware Scheduling
- Monitors system load (CPU, memory) before task execution
- Throttles or delays tasks when system resources are constrained
- Respects API rate limits and network availability
- Adaptive scheduling based on historical execution patterns

### 4.5 Orchestration-Only Boundary (AWS3)
- AWS core is an **orchestrator**, not an intelligence/scraping engine.
- Presence and autonomy decisions should come from a **decision-card adapter hook**.
- Preferred decision-card locations:
  - `$AWS_DECISION_CARD_PATH`
  - `$OPENCLAW_WORKSPACE/aws-decision-card.json`
  - `$OPENCLAW_WORKSPACE/orchestration/decision-card.json`
  - `~/.openclaw/agents/<agent>/aws-decision-card.json`
- Legacy session probing remains only as backward-compatible fallback during migration.

### 5. Safety Boundaries
- **Internal only**: No external communications, API calls, or config changes without explicit permission
- **Non-destructive**: No file deletions, permission changes, or irreversible actions
- **Rollback capability**: All file changes tracked with ability to revert
- **Time-aware**: Full autonomy only during nighttime or when user absent
- **Manual override**: Create `~/.openclaw-autonomy-pause` to temporarily suspend autonomy

### 6. Integration with Agent-Autonomy-Kit
- Can pull tasks from `tasks/QUEUE.md` if `aws-task-queue.md` is empty
- Follows similar Ready/In Progress/Blocked/Done status model
- Compatible with proactive heartbeat patterns
- Cross-agent coordination through central task registry (future)

## Templates & Tools

### Autonomous Activities Template (`aws-task-queue.md`)
```markdown
# Autonomous Work - [DATE]

## Summary
- **Status**: [Active/Completed]
- **Last check-in**: [TIMESTAMP]
- **Tasks completed**: X of Y
- **Next check-in**: [TIMESTAMP]
- **Current permission level**: [read-only/internal-write/full-autonomy]
- **Presence detection**: [ACTIVE/IDLE/ABSENT/NIGHTTIME]

## Tasks

### [PRIORITY] [TASK TITLE]
- **Status**: pending/in-progress/completed/blocked
- **Created**: [TIMESTAMP]
- **Started**: [TIMESTAMP]
- **Completed**: [TIMESTAMP]
- **Description**: [Brief task description]
- **Context**: [Relevant context or references]
- **Safety check**: [Internal/non-destructive verified]
- **Permission required**: [read-only/internal-write/external-read/external-write] (default: read-only)
- **Tags**: [#optional-tags #permission-level #category]

### High Update USER.md with reasoning framework
- **Status**: pending
- **Created**: 2026-02-22 22:36 AEST
- **Started**: 
- **Completed**: 
- **Description**: Update agent's USER.md with reasoning-framework guidance
- **Context**: PRJ-20260222-7143 Systematic Reasoning Protocol Rollout
- **Safety check**: internal/non-destructive verified
- **Permission required**: internal-write
- **Tags**: #documentation #reasoning-framework #internal-write

### Medium Agent coordination status update
- **Status**: completed
- **Created**: 2026-02-22 22:52 AEST
- **Started**: 2026-02-23 13:39 AEST
- **Completed**: 2026-02-23 13:39 AEST
- **Description**: Check sessions_list for active agents, review subagents status
- **Context**: Delegation agent needs awareness of ecosystem for effective task assignment
- **Safety check**: internal/non-destructive verified
- **Permission required**: read-only
- **Tags**: #agent-coordination #monitoring #read-only
- **Execution result**: generic_placeholder
- **Permission level**: internal-write
```

### Autonomous Workflow Script (`autonomous-check.py`)
```python
#!/usr/bin/env python3
"""
Autonomous Workflow System (AWS) v2.0 - 24/7 presence-aware autonomy.
Extends NAWS v1.0 with graduated permission levels based on user presence.
"""
import sys
import os
import datetime
import subprocess
from pathlib import Path

# Configuration
WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/home/agent/.openclaw/workspace"))
ACTIVITIES_FILE = WORKSPACE / "aws-task-queue.md"
MEMORY_DIR = WORKSPACE / "memory"
LOG_DIR = WORKSPACE / "logs"
LOG_DIR.mkdir(exist_ok=True)
CRON_LOG = LOG_DIR / "autonomous-check.log"

# Presence detection thresholds (minutes)
PRESENCE_THRESHOLDS = {
    "ACTIVE": 5,     # User active if message < 5 minutes ago
    "IDLE": 60,      # User idle if message 5-60 minutes ago  
    "ABSENT": 60     # User absent if message > 60 minutes ago
}

# Permission levels mapping
PERMISSION_LEVELS = {
    "ACTIVE": "read-only",
    "IDLE": "internal-write", 
    "ABSENT": "full-autonomy",
    "NIGHTTIME": "full-autonomy"
}

def main():
    """Main autonomous check-in function."""
    # 1. Check manual override
    if check_manual_override():
        logger.info("Autonomy manually paused. Exiting.")
        return 0
    
    # 2. Determine presence level and permission
    presence_level = get_presence_level()
    current_permission = get_current_permission_level(presence_level)
    
    # 3. Parse activities file, find next pending task matching permission
    task = get_next_pending_task(tasks, current_permission)
    if not task:
        logger.info("No pending tasks matching current permission level.")
        return 0
    
    # 4. Execute task with safety boundaries
    result = execute_task_safely(task, current_permission)
    
    # 5. Update activities file and log to memory
    update_task_status(task, result, current_permission)
    log_to_memory(task, result, current_permission)
    
    return 0 if result.get("success") else 1

if __name__ == "__main__":
    sys.exit(main())
```

### Legacy Nighttime Script (`nighttime-check.py`)
The original nighttime-only script remains available for backward compatibility. It runs only during 23:00-07:00 window and doesn't include presence detection or permission levels. Recommended for users who prefer time-bound autonomy only.

### Migration from Nighttime to 24/7 Autonomous
To upgrade from NAWS v1.0 to AWS v2.0:

1. **Update cron job**: Change script reference from `nighttime-check.py` to `autonomous-check.py`
2. **Add permission tags**: Update tasks in `aws-task-queue.md` with `Permission required` field
3. **Test presence detection**: Run `autonomous-check.py --dry-run` to verify detection works
4. **Monitor logs**: Check `logs/autonomous-check.log` for permission level transitions
5. **Set manual override**: Create `~/.openclaw-autonomy-pause` if needed for temporary pause

## Technical Enhancements & Robustness

The AWS skill has been enhanced with focus on five key reliability dimensions:

### 1. Sub‑Agent‑First Delegation Robustness
- **Circuit‑breaker pattern**: Delegation failures trigger progressive backoff and temporary suspension to prevent cascade failures.
- **Configurable retries**: Retry counts, timeouts, and backoff multipliers are adjustable per effort class (low‑effort, reasoning, heavy‑lift, coding‑heavy).
- **State persistence**: Delegation failure state is stored in `aws-delegation-state.json` to maintain continuity across script invocations.
- **Fallback handling**: If delegation fails, tasks are logged and a safe local placeholder is applied, ensuring task‑queue progression.

### 2. Model Routing Policy Quality
- **Configurable model mapping**: Model preferences for each effort class are defined in `aws‑telegram‑status.json` under `model_policy`.
- **Global fallback chain**: A `fallback_order` list provides a prioritized model fallback sequence independent of effort classification.
- **Dynamic classification**: Task classification now respects configurable mappings, falling back to sensible hard‑coded defaults.

### 3. Error Handling & Fallback Reliability
- **Learning Flag System integration**: Repeated delegation failures are suppressed using the Learning Flag registry (7‑day suppression).
- **Safe file‑edit wrapper**: `apply_file_edit_with_context` includes graceful fallback to direct write when the contextual‑edit script is unavailable.
- **Handler exception isolation**: Each task handler is wrapped in a try‑catch that logs the error and returns a structured failure result.
- **Presence‑aware alerting**: `conditional_alert` ensures that status updates and warnings are not duplicated.

### 4. Configuration & Migration Safety
- **Nested defaults**: Configuration loading merges missing keys with safe defaults at both top‑level and nested policy levels.
- **Migration helpers**: Legacy file names (`nighttime‑activities.md`) are automatically renamed to the current standard (`aws‑task‑queue.md`).
- **Atomic writes**: Configuration files are written atomically (via temporary file) to avoid corruption.
- **Backward compatibility**: The script can operate in both NAWS‑compatible (nighttime‑only) and AWS 24/7 modes.

### 5. Telemetry & Status Clarity
- **Active sub‑agent detection**: The status report now lists sub‑agents via `openclaw sessions list --json`, showing age and label.
- **Hash‑based duplicate suppression**: Status messages are only updated when content actually changes, reducing noise.
- **Permission‑level transparency**: Each completed task is tagged with the permission level used for execution.
- **Next‑check indication**: The status message includes the time of the next scheduled check (30‑minute intervals).

## Step-by-Step Workflow

### 1. Initial Setup (24/7 Autonomous)
```bash
# Clone/copy skill to your workspace
cp -r /home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/* .

# Create autonomous activities file from template
cp aws-task-queue.md.template aws-task-queue.md

# Customize with tasks and permission requirements
nano aws-task-queue.md

# Install cron job for 24/7 operation (every 30 minutes for testing, every 2 hours for production)
./setup-autonomous-cron.sh  # New script for AWS v2.0
```

### 2. Task Planning & Permission Tagging
- **Categorize tasks** by required permission level:
  - `#read-only`: Orchestration-state inspection and monitoring (always allowed)
  - `#internal-write`: Documentation, organization, cleanup (requires IDLE or ABSENT)
  - `#external-read`: Adapter-fed inputs (decision cards/metadata), not direct scraping (requires ABSENT/NIGHTTIME)
  - `#external-write`: Git commits, notifications (restricted, manual approval)
- **Set priorities**: High (urgent), Medium (normal), Low (background)
- **Verify safety**: All tasks must pass internal/non-destructive check

### 3. 24/7 Autonomous Execution
- **Cron triggers** `autonomous-check.py` on schedule (default: every 2 hours)
- **Presence detection**: Script reads adapter-produced decision card (legacy session probing fallback during migration)
- **Permission calculation**: Determines allowed operations based on presence + time
- **Task selection**: Picks highest-priority pending task matching current permission
- **Execution**: Runs task with safety boundaries and error handling
- **Logging**: Updates `aws-task-queue.md` and logs to `memory/YYYY-MM-DD.md`

### 4. Continuous Monitoring & Adjustment
- **Review logs**: Check `logs/autonomous-check.log` for permission transitions and errors
- **Adjust thresholds**: Modify `PRESENCE_THRESHOLDS` in script if detection is too sensitive/insensitive
- **Pause autonomy**: Create `~/.openclaw-autonomy-pause` when manual work needed
- **Task progress**: Monitor completion rates, adjust permission tags as needed

### 5. Nighttime-Only Mode (Legacy Compatibility)
If you prefer nighttime-only operation:
- Use `nighttime-check.py` instead of `autonomous-check.py`
- Cron schedule: `0 23,1,3,5 * * *` (23:00, 01:00, 03:00, 05:00)
- No presence detection or permission levels
- Simpler but less flexible

## Integration with OpenClaw Ecosystem

### Migration from WORKFLOW_AUTO.md to Autonomous Workflow System
The Autonomous Workflow System (AWS) extends and replaces the WORKFLOW_AUTO.md pattern for automated task execution:

| WORKFLOW_AUTO.md Pattern | Autonomous Workflow System Equivalent |
|--------------------------|---------------------------------------|
| **Nighttime Operations** | 24/7 presence‑aware autonomy |
| **Manual task queue** | Dynamic permission‑based task selection |
| **Time‑based triggers** | Presence‑detection triggers + cron |
| **Agent‑specific templates** | Central skill with workspace‑specific configuration |
| **Manual safety review** | Automated permission validation + safety boundaries |

**Migration steps**:
1. **Replace WORKFLOW_AUTO.md nighttime section** with reference to this skill
2. **Convert agent‑specific tasks** to `nighttime‑activities.md` with permission tags
3. **Update cron jobs** from custom scripts to `autonomous‑check.py`
4. **Add presence detection** configuration to agent workspace
5. **Test permission transitions** with dry‑run before full deployment

### Memory Framework
- Each task execution logged to `memory/YYYY‑MM‑DD.md` with `#autonomous‑work` tag
- Presence level and permission recorded for audit trail
- Failed tasks flagged with error details for review

### File‑Editing Protocol
- All file changes made during autonomous work include descriptive comments
- Changes are reversible with backup copies created before modification
- Follows comment‑consistency patterns from file‑editing‑protocol skill
- Permission‑level validation ensures write operations only when allowed

### Project Management
- Complex autonomous work items can reference project IDs (e.g., `PRJ‑20260222‑7143`)
- Progress tracked against project milestones
- Autonomous work can include project‑specific tasks (template updates, documentation)
- Resource‑aware scheduling prevents project interference

### Agent Coordination
- Kaira agent manages versioning and rollout of this skill
- Multi‑agent autonomous coordination through central task registry (future)
- Conflict avoidance: agents check task registry before claiming work
- Presence detection shared across agents for ecosystem‑wide permission consistency

### System Message Handling
When operating within the OpenClaw ecosystem, agents should handle system‑generated messages gracefully:

**Post‑Compaction Audit Protocol**:
- **Silent handling**: When system posts "⚠️ Post‑Compaction Audit" warnings, read the required files (`WORKFLOW_AUTO.md` and `memory/YYYY‑MM‑DD.md`) without verbose confirmation
- **No‑clutter principle**: Avoid adding boilerplate verification messages that create repetitive clutter in conversations
- **Focus on substance**: Respond to the user's actual query, not system housekeeping messages
- **Verification complete**: Consider audit satisfied once files are read; no need to announce completion

**Implementation pattern**:
```python
# Pseudo‑code for agent behavior
if message.contains("Post‑Compaction Audit"):
    read("WORKFLOW_AUTO.md")
    read(f"memory/{today}.md")
    # Continue with user's actual query
    # No verbose "✅ Audit satisfied" output
```

**Full documentation**: See [`system‑message‑handling.md`](system‑message‑handling.md) for detailed protocol and examples.

This protocol reduces noise while maintaining system integrity requirements.

## Safety Protocols

### Execution Boundaries
1. **Presence boundary**: Permission levels restrict operations based on user engagement
2. **Time boundary**: Full autonomy allowed during nighttime (23:00-07:00) regardless of presence
3. **Action boundary**: Internal optimization only (no external comms without explicit permission)
4. **Destruction boundary**: No deletions, permission changes, or irreversible actions
5. **Scope boundary**: Only within workspace directory (no system changes)
6. **Resource boundary**: Throttle tasks when system load exceeds thresholds

### Emergency Stop
- **Immediate pause**: Create `~/.openclaw-autonomy-pause` file (takes effect on next check‑in)
- **Remove cron job**: `crontab -e` and delete autonomous‑check line
- **Delete task queue**: Remove `nighttime‑activities.md` to halt all pending work
- **Manual intervention**: Direct session access to stop running processes
- **Graceful shutdown**: Set all tasks to `blocked` status to preserve state

### Rollback Procedure
```bash
# View backup of changed files
find /home/agent/.openclaw/workspace -name "*.backup.*" -mtime -1

# Restore from backup
cp file.backup.12345678 file
```

## Cron Configuration

### 24/7 Autonomous Schedule (Recommended)
```cron
# Every 2 hours for production, every 30 minutes for testing
*/30 * * * * cd '/home/agent/.openclaw/workspace' && OPENCLAW_WORKSPACE='/home/agent/.openclaw/workspace' python3 '/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/autonomous-check.py' >> '/home/agent/.openclaw/workspace/logs/autonomous-check.log' 2>&1

# Production (every 2 hours)
# 0 */2 * * * cd '/home/agent/.openclaw/workspace' && OPENCLAW_WORKSPACE='/home/agent/.openclaw/workspace' python3 '/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/autonomous-check.py' >> '/home/agent/.openclaw/workspace/logs/autonomous-check.log' 2>&1
```

### Nighttime-Only Schedule (Legacy)
```cron
# Nighttime autonomous work check-ins (23:00, 01:00, 03:00, 05:00)
0 23,1,3,5 * * * cd '/home/agent/.openclaw/workspace' && OPENCLAW_WORKSPACE='/home/agent/.openclaw/workspace' python3 '/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/nighttime-check.py' >> '/home/agent/.openclaw/workspace/logs/nighttime-check.log' 2>&1
```

### Installation Scripts
**For 24/7 autonomous system** (`setup-autonomous-cron.sh`):
```bash
#!/bin/bash
# Adds autonomous-check cron job to current user's crontab
CRON_LINE="*/30 * * * * cd '/home/agent/.openclaw/workspace' && OPENCLAW_WORKSPACE='/home/agent/.openclaw/workspace' python3 '/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/autonomous-check.py' >> '/home/agent/.openclaw/workspace/logs/autonomous-check.log' 2>&1"
(crontab -l 2>/dev/null | grep -v "autonomous-check"; echo "$CRON_LINE") | crontab -
echo "24/7 autonomous workflow cron job installed (every 30 minutes)."
```

**For nighttime-only system** (`setup-cron.sh` - legacy):
```bash
#!/bin/bash
# Adds nighttime-check cron job to current user's crontab
CRON_LINE="0 23,1,3,5 * * * cd '/home/agent/.openclaw/workspace' && OPENCLAW_WORKSPACE='/home/agent/.openclaw/workspace' python3 '/home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/nighttime-check.py' >> '/home/agent/.openclaw/workspace/logs/nighttime-check.log' 2>&1"
(crontab -l 2>/dev/null | grep -v "nighttime-check"; echo "$CRON_LINE") | crontab -
echo "Nighttime autonomous work cron job installed."
```

## Validation Commands (AWS3 Orchestration Boundary)

```bash
# 1) Syntax check
python3 -m py_compile autonomous-check.py

# 2) Dry run (no task execution)
python3 autonomous-check.py --dry-run

# 3) Confirm decision-card adapter hook exists
grep -n "load_decision_card\|get_presence_level_from_decision_card" autonomous-check.py
```

Expected output signals:
- `py_compile` returns exit code `0` and no stderr.
- Dry-run log includes either:
  - `Presence sourced from decision card: ...` (adapter path active), or
  - `Decision card unavailable; running compatibility presence detection...` (fallback path).
- Grep returns function definitions/usages for adapter-hook flow.

## Adoption Guide

For ecosystem‑wide deployment, refer to [ADOPTION‑GUIDE.md](ADOPTION‑GUIDE.md).

## Version History
- **1.0.0** (2026-02-22): Initial release with persistent tracking, safety boundaries, cron integration
- **2.0.0** (2026-02-23): 24/7 Autonomous Workflow System with presence‑aware graduated autonomy, permission‑level execution, resource‑aware scheduling, migration from WORKFLOW_AUTO.md patterns
- **2.0.1** (2026-02-24): Telegram single-message status toggle (`aws-telegram-status.json`) with edit-in-place updates to reduce chat clutter; status scope limited to this agent's AWS tasks and spawned sub-agents; enabled by default on install/migration
- **2.0.2** (2026-02-24): Added model-routing policy defaults (DeepSeek Chat/Reasoner, Kimi heavy-lift, Codex coding-heavy) plus fallback ordering and generic-path error-handled routing metadata
- **2.0.3** (2026-02-24): Added sub-agent-first delegation policy for generic tasks with orchestrator handoff + fallback handling (`delegation_policy`)
- **2.0.4** (2026-02-26): Standardized observability policy — no-report-on-success default and built-in 12-hour completion reports at 07:00/19:00 local via `aws-completion-report.py` + installer cron wiring
- **Future**: Cross‑agent coordination, calendar integration, predictive scheduling, dashboard reporting

---
*Created as part of PRJ‑20260222‑7143 Systematic Reasoning Protocol Rollout*
*Autonomous Workflow System v2.0 developed by Kaira (delegation agent)*
*Maintainer: The Architect (main agent)*
*Rollout coordination: Kaira (delegation agent)*