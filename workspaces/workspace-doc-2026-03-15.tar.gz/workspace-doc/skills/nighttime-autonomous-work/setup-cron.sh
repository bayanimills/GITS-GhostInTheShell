#!/bin/bash
# Nighttime autonomous work cron job installer
# Version: 1.0.0

set -e

WORKSPACE="${OPENCLAW_WORKSPACE:-/home/agent/.openclaw/workspace}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRON_LINE="0 23,1,3,5 * * * cd '$WORKSPACE' && python3 '$SCRIPT_DIR/nighttime-check.py' >> '$WORKSPACE/logs/nighttime-check.log' 2>&1"

echo "=== Nighttime Autonomous Work Cron Installer ==="
echo "Workspace: $WORKSPACE"
echo "Script dir: $SCRIPT_DIR"
echo

# Create logs directory
mkdir -p "$WORKSPACE/logs"

# Check current crontab
echo "Current crontab:"
crontab -l 2>/dev/null || echo "(no crontab)"
echo

# Check if already installed
if crontab -l 2>/dev/null | grep -q "nighttime-check.py"; then
    echo "Nighttime check cron job already installed."
    echo "To update, first remove with: crontab -e"
    exit 0
fi

# Confirm installation
echo "Proposed cron schedule:"
echo "  Runs at 23:00, 01:00, 03:00, 05:00 Sydney time (every 2 hours during nighttime)"
echo "  Executes: $CRON_LINE"
echo
read -p "Install cron job? (y/N): " -n 1 -r
echo

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Installation cancelled."
    exit 0
fi

# Install
echo "Installing cron job..."
(crontab -l 2>/dev/null; echo "$CRON_LINE") | crontab -

# Verify
echo "Verifying installation..."
if crontab -l | grep -q "nighttime-check.py"; then
    echo "✅ Cron job installed successfully."
    echo
    echo "Next steps:"
    echo "1. Create nighttime-activities.md in your workspace"
    echo "2. Add tasks with safety check: 'internal/non-destructive verified'"
    echo "3. First check-in will run at 23:00 Sydney time"
else
    echo "❌ Installation may have failed. Check manually with: crontab -l"
    exit 1
fi