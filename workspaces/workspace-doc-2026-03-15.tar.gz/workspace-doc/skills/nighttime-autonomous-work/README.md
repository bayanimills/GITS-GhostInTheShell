# Nighttime Autonomous Work Skill 🌙

Autonomous nighttime task execution with persistent tracking and periodic check-ins.

## Quick Start

1. **Copy skill to your workspace:**
   ```bash
   cp -r /home/agent/.openclaw/workspace/skills/nighttime-autonomous-work/* .
   ```

2. **Create `nighttime-activities.md` from template:**
   ```bash
   cp nighttime-activities.md.template nighttime-activities.md
   # Edit with your tasks
   nano nighttime-activities.md
   ```

3. **Install cron job:**
   ```bash
   ./setup-cron.sh
   ```

4. **Verify:**
   ```bash
   crontab -l | grep nighttime-check
   ```

## Key Features

- **Persistent tracking**: `nighttime-activities.md` tracks task status
- **Periodic check-ins**: Runs every 2 hours during nighttime (23:00-07:00)
- **Safety boundaries**: Internal/non-destructive operations only
- **Integration**: Compatible with agent-autonomy-kit task queue
- **Logging**: Tasks logged to daily memory file with `#nighttime-work` tag

## Safety Protocol

All tasks must pass safety check:
- ✅ **Internal**: No external communications
- ✅ **Non-destructive**: No deletions or irreversible changes
- ✅ **Time-bound**: Only 23:00-07:00 window
- ✅ **Rollback**: Changes can be reverted

## Task Handlers

Built-in handlers for common task types:
- `Update USER.md` files
- `Create cron jobs`
- `Skill audits` (SPICE framework)
- `Clean memory` files
- `Create skills`
- `Update WORKFLOW_AUTO.md`

## Customization

Add your own handlers to `nighttime-check.py`:
```python
def handle_custom_task(task: Dict) -> Dict:
    # Your implementation
    return {'success': True, 'output': '...', 'error': '', 'action': 'custom'}
```

Add to handlers dictionary:
```python
handlers = {
    # ... existing handlers
    'Custom pattern': handle_custom_task,
}
```

## Monitoring

- **Log file**: `logs/nighttime-check.log`
- **Memory entries**: `memory/YYYY-MM-DD.md` with `#nighttime-work` tag
- **Cron status**: `crontab -l`

## Troubleshooting

**Cron not running:**
- Check timezone: script uses Sydney time (AEST)
- Verify cron installation: `crontab -l`
- Check logs: `tail -f logs/nighttime-check.log`

**Task not executing:**
- Verify safety check: must include "internal/non-destructive verified"
- Check task pattern matches handler
- Review Python error in log

**Outside nighttime window:**
- Script only runs 23:00-07:00 Sydney time
- For testing: temporarily modify `NIGHT_START`/`NIGHT_END` in script

## Integration with WORKFLOW_AUTO.md

Add to your `WORKFLOW_AUTO.md`:
```markdown
## Nighttime Autonomous Operations

1. Create `nighttime-activities.md` with queued tasks
2. Install cron job (`setup-cron.sh`) for 2-hour check-ins
3. Implement task handlers in `nighttime-check.py`
4. Log progress to `memory/YYYY-MM-DD.md`
```

## Version History

- **1.0.0** (2026-02-22): Initial release with core functionality
- **Future**: Multi-agent coordination, dashboard, enhanced handlers

---
*Created as part of PRJ-20260222-7143 Systematic Reasoning Protocol Rollout*
*Maintainer: The Architect (main agent)*
*Rollout coordination: Kaira (delegation agent)*