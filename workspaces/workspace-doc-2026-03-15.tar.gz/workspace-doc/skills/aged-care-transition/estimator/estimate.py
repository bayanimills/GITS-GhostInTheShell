#!/usr/bin/env python3
"""
Aged care cost estimator.
Calculates approximate RAD, daily fees, means‑tested fees based on asset/income input.
Uses simplified My Aged Care formulas (2024 thresholds).
"""
import sys
import argparse
import json

# Constants (approximate 2024 values)
BASIC_DAILY_FEE = 60.86  # 85% of single age pension
MAX_RAD = 550_000  # maximum RAD a facility can charge
INCOME_THRESHOLD_SINGLE = 32_331
ASSET_THRESHOLD_HOMEOWNER = 197_735
ASSET_THRESHOLD_NON_HOMEOWNER = 357_735
DAILY_FEE_CAP_ANNUAL = 33_638
LIFETIME_CAP = 161_327

def calculate_means_tested_fee(annual_income: float, assets: float, homeowner: bool) -> dict:
    """
    Calculate means‑tested care fee for residential aged care.
    Returns dict with daily fee, annual fee, etc.
    """
    # Step 1: Determine asset threshold
    if homeowner:
        asset_threshold = ASSET_THRESHOLD_HOMEOWNER
    else:
        asset_threshold = ASSET_THRESHOLD_NON_HOMEOWNER

    # Step 2: Calculate income contribution
    if annual_income <= INCOME_THRESHOLD_SINGLE:
        income_contribution = 0
    else:
        income_contribution = (annual_income - INCOME_THRESHOLD_SINGLE) * 0.5

    # Step 3: Calculate asset contribution
    if assets <= asset_threshold:
        asset_contribution = 0
    elif assets <= asset_threshold + 173_000:  # for each $1000 above threshold
        asset_contribution = (assets - asset_threshold) / 1000 * 1.0
    else:
        asset_contribution = 173.0 + (assets - asset_threshold - 173_000) / 1000 * 2.0

    # Convert to daily (divide by 364)
    daily_income_contribution = income_contribution / 364
    daily_asset_contribution = asset_contribution / 364

    total_daily_means_tested = daily_income_contribution + daily_asset_contribution

    # Apply caps
    annual_means_tested = total_daily_means_tested * 364
    if annual_means_tested > DAILY_FEE_CAP_ANNUAL:
        annual_means_tested = DAILY_FEE_CAP_ANNUAL
        total_daily_means_tested = DAILY_FEE_CAP_ANNUAL / 364

    # Lifetime cap not calculated here (tracked separately)

    return {
        "daily_means_tested_fee": round(total_daily_means_tested, 2),
        "annual_means_tested_fee": round(annual_means_tested, 2),
        "income_contribution": round(income_contribution, 2),
        "asset_contribution": round(asset_contribution, 2),
        "daily_income_component": round(daily_income_contribution, 2),
        "daily_asset_component": round(daily_asset_contribution, 2),
    }

def calculate_rad_dap(rad_amount: float, max_rad: float = MAX_RAD) -> dict:
    """
    Calculate DAP equivalent for a given RAD.
    DAP = RAD × MPIR / 365. MPIR (Maximum Permissible Interest Rate) ~ 8.34% (2024).
    """
    mpir = 8.34 / 100  # 8.34%
    daily_dap = rad_amount * mpir / 365
    monthly_dap = daily_dap * 30.44
    annual_dap = daily_dap * 365
    return {
        "rad": round(rad_amount, 2),
        "dap_daily": round(daily_dap, 2),
        "dap_monthly": round(monthly_dap, 2),
        "dap_annual": round(annual_dap, 2),
        "mpir_percent": 8.34
    }

def main():
    parser = argparse.ArgumentParser(description="Estimate aged care costs.")
    parser.add_argument("--assets", type=float, required=True, help="Total assessable assets ($)")
    parser.add_argument("--income", type=float, required=True, help="Annual assessable income ($)")
    parser.add_argument("--homeowner", action="store_true", help="Is homeowner (home exempt for 2 years)")
    parser.add_argument("--rad", type=float, help="Proposed RAD amount ($). If not provided, estimate based on average.")
    parser.add_argument("--output", choices=["text", "json"], default="text")
    args = parser.parse_args()

    # Basic daily fee
    basic_daily = BASIC_DAILY_FEE
    basic_annual = basic_daily * 365

    # Means‑tested fee
    means = calculate_means_tested_fee(args.income, args.assets, args.homeowner)

    # RAD / DAP
    if args.rad is None:
        # Assume average RAD for Northern Beaches (placeholder)
        rad = 450_000
    else:
        rad = args.rad
    rad_dap = calculate_rad_dap(rad)

    # Extra service fees (placeholder)
    extra_daily = 0  # could be $20‑$100

    # Total daily fee
    total_daily = basic_daily + means["daily_means_tested_fee"] + rad_dap["dap_daily"] + extra_daily

    result = {
        "basic_daily_fee": basic_daily,
        "basic_annual_fee": round(basic_annual, 2),
        "means_tested_fee": means,
        "rad_dap": rad_dap,
        "extra_service_fee_daily": extra_daily,
        "total_daily_fee": round(total_daily, 2),
        "total_monthly_fee": round(total_daily * 30.44, 2),
        "total_annual_fee": round(total_daily * 365, 2),
        "assumptions": {
            "homeowner": args.homeowner,
            "assets": args.assets,
            "income": args.income,
            "rad_assumed": rad,
            "mpir_percent": 8.34,
            "basic_daily_fee_source": "85% of single age pension (2024)",
            "note": "This is an estimate only. Actual fees depend on facility, exact means test, and government updates."
        }
    }

    if args.output == "json":
        print(json.dumps(result, indent=2))
    else:
        print("=" * 60)
        print("AGED CARE COST ESTIMATE")
        print("=" * 60)
        print(f"Assets: ${args.assets:,.2f}")
        print(f"Income: ${args.income:,.2f}")
        print(f"Homeowner: {args.homeowner}")
        print()
        print("DAILY FEES")
        print(f"  Basic daily fee: ${basic_daily:.2f}")
        print(f"  Means‑tested care fee: ${means['daily_means_tested_fee']:.2f}")
        print(f"  Accommodation (DAP): ${rad_dap['dap_daily']:.2f}")
        print(f"  Extra service fees: ${extra_daily:.2f}")
        print(f"  TOTAL DAILY: ${total_daily:.2f}")
        print()
        print("ACCOMMODATION PAYMENT")
        print(f"  RAD: ${rad:,.2f} (or DAP ${rad_dap['dap_daily']:.2f} daily)")
        print(f"  MPIR: {rad_dap['mpir_percent']}%")
        print()
        print("ANNUAL TOTALS")
        print(f"  Basic fees: ${basic_annual:,.2f}")
        print(f"  Means‑tested: ${means['annual_means_tested_fee']:,.2f}")
        print(f"  DAP: ${rad_dap['dap_annual']:,.2f}")
        print(f"  TOTAL ANNUAL: ${result['total_annual_fee']:,.2f}")
        print()
        print("NOTE: This is a simplified estimate. Use My Aged Care fee calculator for official figures.")

if __name__ == "__main__":
    main()