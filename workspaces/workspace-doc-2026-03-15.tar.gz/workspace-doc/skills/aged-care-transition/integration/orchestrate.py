#!/usr/bin/env python3
"""
Orchestration script for aged‑care transition skill.
Loads patient profile, suggests next steps, updates checklist, and integrates with Dart/Notion.
"""
import os
import sys
import json
from pathlib import Path

# Add parent directories for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_profile(patient_id="edward_mills"):
    """Load patient profile JSON."""
    profile_path = Path(__file__).parent.parent / "profile" / f"{patient_id}.json"
    with open(profile_path) as f:
        return json.load(f)

def suggest_next_step(profile):
    """Based on profile, suggest next logical step."""
    status = profile["assessment_status"]
    timeline = profile["transition_timeline"]
    if not status["acat_referred"]:
        return "ACAT referral", "Request ACAT assessment via hospital social worker."
    if not status["acat_assessed"]:
        return "ACAT assessment", "Attend ACAT assessment; provide medical documents."
    if not status["approval_type"]:
        return "Wait for approval", "Await ACAT approval letter (1‑2 weeks)."
    if not profile["financial"]["has_financial_advisor"]:
        return "Financial advice", "Consult My Aged Care financial advisor."
    # Default: start searching
    return "Facility search", "Use Notion database to shortlist facilities."

def main():
    print("Aged‑care Transition Orchestrator")
    print("=" * 50)
    profile = load_profile()
    print(f"Patient: {profile['full_name']} ({profile['date_of_birth']})")
    print(f"Current step: {profile['transition_timeline']['current_step']}")
    print()
    # Suggest next step
    step_title, step_desc = suggest_next_step(profile)
    print("Suggested next step:")
    print(f"  {step_title}")
    print(f"  {step_desc}")
    print()
    # Checklist integration
    checklist_path = Path(__file__).parent.parent / "checklist" / "checklist.md"
    if checklist_path.exists():
        print(f"Checklist: {checklist_path}")
        # Could call next_step.py here
    # Notion database status
    print("Notion database: Northern Beaches Nursing Homes")
    print("  (Use skills/aged-care-transition/matcher/match.py to search)")
    # Cost estimator reminder
    print()
    print("Cost estimation:")
    print("  Run: python3 skills/aged-care-transition/estimator/estimate.py --assets ... --income ...")
    print()
    print("To proceed, run:")
    print("  python3 skills/aged-care-transition/checklist/next_step.py --next")
    print("  python3 skills/aged-care-transition/checklist/next_step.py --create-dart")

if __name__ == "__main__":
    main()