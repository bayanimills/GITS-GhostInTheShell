#!/bin/bash
# Load patient profile (default: Edward Mills) and print summary.

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PATIENT_ID="${1:-edward_mills}"
PROFILE_FILE="$SCRIPT_DIR/profile/$PATIENT_ID.json"

if [[ ! -f "$PROFILE_FILE" ]]; then
    echo "Profile not found: $PROFILE_FILE"
    exit 1
fi

echo "Patient profile: $PATIENT_ID"
echo "---"
jq -r '. | "Name: \(.full_name)\nDOB: \(.date_of_birth)\nConditions: \(.medical_summary.primary_conditions | join(", "))\nMedications: \(.medical_summary.medications | join(", "))\nMobility: \(.medical_summary.mobility)\nCurrent step: \(.transition_timeline.current_step)"' "$PROFILE_FILE"