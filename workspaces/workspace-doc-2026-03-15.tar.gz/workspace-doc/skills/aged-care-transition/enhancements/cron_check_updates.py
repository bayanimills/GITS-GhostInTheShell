#!/usr/bin/env python3
"""
Cron job: check for updates in Northern Beaches nursing homes database.
Compares current Notion entries with previous snapshot; logs changes.
"""
import os
import sys
import json
import hashlib
from pathlib import Path
from datetime import datetime

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_notion_api_key():
    path = os.path.expanduser("~/.config/notion/api_key")
    with open(path) as f:
        return f.read().strip()

def fetch_current_entries():
    """Fetch all active pages from Notion, return list of simplified entries."""
    import requests
    api_key = load_notion_api_key()
    data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    resp = requests.post(
        f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
        headers=headers,
        json={"page_size": 100}
    )
    if resp.status_code != 200:
        print(f"Error fetching entries: {resp.status_code} {resp.text[:500]}", file=sys.stderr)
        return []
    pages = resp.json().get("results", [])
    # Filter out archived
    pages = [p for p in pages if not p.get("archived", False)]
    entries = []
    for page in pages:
        props = page.get("properties", {})
        name_obj = props.get("Name", {}).get("title", [])
        name = name_obj[0].get("text", {}).get("content", "").strip() if name_obj else ""
        suburb_obj = props.get("Suburb", {}).get("rich_text", [])
        suburb = suburb_obj[0].get("text", {}).get("content", "").strip() if suburb_obj else ""
        postcode_obj = props.get("Postcode", {}).get("rich_text", [])
        postcode = postcode_obj[0].get("text", {}).get("content", "").strip() if postcode_obj else ""
        entries.append({
            "id": page["id"],
            "name": name,
            "suburb": suburb,
            "postcode": postcode,
            "updated": page.get("last_edited_time", "")
        })
    return entries

def hash_entries(entries):
    """Compute a hash of entries for change detection."""
    data = json.dumps(entries, sort_keys=True)
    return hashlib.sha256(data.encode()).hexdigest()

def load_previous_snapshot(snapshot_path):
    """Load previous snapshot if exists."""
    if snapshot_path.exists():
        with open(snapshot_path) as f:
            return json.load(f)
    return {"hash": "", "entries": [], "timestamp": ""}

def save_snapshot(snapshot_path, entries, hash_val):
    """Save snapshot to file."""
    snapshot = {
        "hash": hash_val,
        "entries": entries,
        "timestamp": datetime.now().isoformat()
    }
    with open(snapshot_path, "w") as f:
        json.dump(snapshot, f, indent=2)

def main():
    import requests
    # Path for snapshot storage
    snapshot_dir = Path(__file__).parent / "snapshots"
    snapshot_dir.mkdir(exist_ok=True)
    snapshot_path = snapshot_dir / "nursing_homes_snapshot.json"
    
    # Fetch current entries
    entries = fetch_current_entries()
    if not entries:
        print("No entries fetched.", file=sys.stderr)
        return
    
    current_hash = hash_entries(entries)
    previous = load_previous_snapshot(snapshot_path)
    
    if current_hash == previous.get("hash", ""):
        print("No changes detected.", file=sys.stderr)
        return
    
    # Changes detected
    print(f"Changes detected! Previous hash {previous.get('hash', 'none')}, current {current_hash}", file=sys.stderr)
    # Compare entries
    old_entries = {e["id"]: e for e in previous.get("entries", [])}
    new_entries = {e["id"]: e for e in entries}
    
    added = [e for id, e in new_entries.items() if id not in old_entries]
    removed = [e for id, e in old_entries.items() if id not in new_entries]
    
    # Log changes to memory file
    today = datetime.now().strftime("%Y-%m-%d")
    memory_path = Path(__file__).parent.parent.parent.parent / "memory" / f"{today}.md"
    with open(memory_path, "a") as f:
        f.write(f"\n### {datetime.now().isoformat()} – Nursing Homes Database Update\n")
        if added:
            f.write("**Added facilities:**\n")
            for e in added:
                f.write(f"- {e['name']} ({e['suburb']} {e['postcode']})\n")
        if removed:
            f.write("**Removed facilities:**\n")
            for e in removed:
                f.write(f"- {e['name']} ({e['suburb']} {e['postcode']})\n")
        if not added and not removed:
            f.write("(Hash changed but no adds/removes detected – possibly property updates.)\n")
        f.write("\n")
    
    # Save new snapshot
    save_snapshot(snapshot_path, entries, current_hash)
    
    # Optional: send notification via AgentMail
    # (implement if needed)
    
    print(f"Logged changes. Added: {len(added)}, Removed: {len(removed)}", file=sys.stderr)

if __name__ == "__main__":
    main()