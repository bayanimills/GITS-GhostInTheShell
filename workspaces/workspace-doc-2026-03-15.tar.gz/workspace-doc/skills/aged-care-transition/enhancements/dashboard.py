#!/usr/bin/env python3
"""
Progress dashboard generator.
Creates an HTML dashboard showing checklist status, facility shortlist, cost estimate.
"""
import os
import sys
import json
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_profile(patient_id="edward_mills"):
    """Load patient profile JSON."""
    profile_path = Path(__file__).parent.parent / "profile" / f"{patient_id}.json"
    with open(profile_path) as f:
        return json.load(f)

def get_checklist_status():
    """Parse checklist.md and return steps with completion."""
    checklist_path = Path(__file__).parent.parent / "checklist" / "checklist.md"
    with open(checklist_path) as f:
        lines = f.readlines()
    steps = []
    current_phase = ""
    for line in lines:
        line = line.rstrip()
        if line.startswith("## Phase"):
            current_phase = line.replace("## ", "").strip()
        if line.startswith("- ["):
            checked = line[3] == "x"
            # Extract title and description
            import re
            match = re.match(r"^- \[[ x]\] \*\*(.*?)\*\* – (.*)", line)
            if match:
                title = match.group(1).strip()
                desc = match.group(2).strip()
            else:
                # fallback
                title = line[6:].split("–")[0].strip("* ")
                desc = line[6:].split("–")[1] if "–" in line else ""
            steps.append({
                "phase": current_phase,
                "title": title,
                "description": desc,
                "checked": checked
            })
    return steps

def get_facility_shortlist():
    """Run matcher to get facilities (limit 5)."""
    matcher_path = Path(__file__).parent.parent / "matcher" / "match.py"
    # Run as subprocess to get JSON output
    try:
        result = subprocess.run(
            [sys.executable, str(matcher_path), "--output", "json"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return data[:5]  # limit to 5
    except Exception as e:
        print(f"Error getting facilities: {e}", file=sys.stderr)
    return []

def get_cost_estimate(profile):
    """Run cost estimator with profile financial data."""
    estimator_path = Path(__file__).parent.parent / "estimator" / "estimate.py"
    # Extract assets/income from profile (placeholder)
    assets = profile["financial"].get("home_value_estimate", 0) + profile["financial"].get("other_assets", 0)
    income = profile["financial"].get("annual_income", 0)
    homeowner = profile["financial"].get("home_owner", False)
    if assets == 0 and income == 0:
        return None
    try:
        result = subprocess.run(
            [sys.executable, str(estimator_path), "--assets", str(assets),
             "--income", str(income), "--homeowner" if homeowner else ""],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            # Parse the text output (could switch to JSON output)
            lines = result.stdout.split("\n")
            # We'll just capture a few lines
            estimate = []
            for line in lines:
                if line.strip() and "DAILY" in line or "TOTAL" in line:
                    estimate.append(line.strip())
            return estimate[:5]
    except Exception as e:
        print(f"Error getting cost estimate: {e}", file=sys.stderr)
    return None

def generate_html(profile, checklist, facilities, cost_estimate):
    """Generate HTML dashboard."""
    today = datetime.now().strftime("%d/%m/%Y")
    name = profile["full_name"]
    dob = profile["date_of_birth"]
    
    # Checklist HTML
    checklist_html = ""
    for step in checklist:
        checkbox = "✓" if step["checked"] else "◻"
        checklist_html += f"""
        <div class="step { 'checked' if step['checked'] else '' }">
            <span class="checkbox">{checkbox}</span>
            <div>
                <strong>{step['title']}</strong><br>
                <small>{step['description']}</small>
                <span class="phase">{step['phase']}</span>
            </div>
        </div>"""
    
    # Facilities HTML
    facilities_html = ""
    for f in facilities:
        facilities_html += f"""
        <div class="facility">
            <strong>{f['name']}</strong><br>
            <small>{f['suburb']} {f['postcode']}</small><br>
            <small>{f['service_type']} • {f['status']}</small>
        </div>"""
    
    # Cost estimate HTML
    cost_html = ""
    if cost_estimate:
        for line in cost_estimate:
            cost_html += f"<div>{line}</div>"
    else:
        cost_html = "<div>No financial data provided.</div>"
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Aged‑Care Transition Dashboard – {name}</title>
    <style>
        body {{ font-family: sans-serif; margin: 2em; background: #f9f9f9; }}
        .container {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 2em; }}
        .panel {{ background: white; padding: 1.5em; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; }}
        h2 {{ color: #555; font-size: 1.2em; border-bottom: 2px solid #ddd; padding-bottom: 0.5em; }}
        .step {{ display: flex; margin-bottom: 1em; padding: 0.8em; border-left: 4px solid #ccc; }}
        .step.checked {{ border-left-color: #4CAF50; background: #f0fff0; }}
        .checkbox {{ font-size: 1.5em; margin-right: 0.5em; }}
        .phase {{ font-size: 0.8em; color: #888; float: right; }}
        .facility {{ margin-bottom: 1em; padding: 0.8em; border: 1px solid #ddd; border-radius: 4px; }}
        .facility small {{ color: #666; }}
    </style>
</head>
<body>
    <h1>Aged‑Care Transition Dashboard</h1>
    <p><strong>{name}</strong> (DOB: {dob}) • Generated {today}</p>
    
    <div class="container">
        <div class="panel">
            <h2>Checklist Progress</h2>
            {checklist_html}
        </div>
        <div class="panel">
            <h2>Facility Shortlist</h2>
            {facilities_html}
        </div>
        <div class="panel">
            <h2>Cost Estimate</h2>
            {cost_html}
        </div>
    </div>
    
    <footer style="margin-top: 3em; font-size: 0.9em; color: #777;">
        <p>Dashboard generated by Aged‑Care Transition Skill. Data sources: Notion, agedcareguide.com.au.</p>
    </footer>
</body>
</html>"""
    return html

def main():
    parser = argparse.ArgumentParser(description="Generate progress dashboard.")
    parser.add_argument("--patient", default="edward_mills", help="Patient ID")
    parser.add_argument("--output", default="dashboard.html", help="Output HTML file")
    args = parser.parse_args()

    profile = load_profile(args.patient)
    checklist = get_checklist_status()
    facilities = get_facility_shortlist()
    cost_estimate = get_cost_estimate(profile)
    html = generate_html(profile, checklist, facilities, cost_estimate)

    with open(args.output, "w") as f:
        f.write(html)
    print(f"Dashboard written to {args.output}", file=sys.stderr)
    print(f"Open file://{os.path.abspath(args.output)} in your browser.")

if __name__ == "__main__":
    main()