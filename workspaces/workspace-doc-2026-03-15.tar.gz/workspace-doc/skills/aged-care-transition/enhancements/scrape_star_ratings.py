#!/usr/bin/env python3
"""
Scrape Star Ratings from agedcareguide.com.au and update Notion pages.
"""
import os
import sys
import json
import time
import requests
from datetime import datetime
from pathlib import Path

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_notion_api_key():
    path = os.path.expanduser("~/.config/notion/api_key")
    with open(path) as f:
        return f.read().strip()

def get_all_pages():
    """Fetch all pages from the data source."""
    api_key = load_notion_api_key()
    data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    resp = requests.post(
        f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
        headers=headers,
        json={"page_size": 100}
    )
    if resp.status_code != 200:
        print(f"Error fetching pages: {resp.status_code} {resp.text[:500]}", file=sys.stderr)
        return []
    pages = resp.json().get("results", [])
    # Filter out archived
    pages = [p for p in pages if not p.get("archived", False)]
    return pages

def extract_rating_from_page(browser_target_id, profile="openclaw"):
    """
    Use browser automation to extract star rating from current page.
    Returns float or None.
    """
    # We'll implement this later; for now placeholder
    # We'll need to import browser tool, but we can't directly call.
    # Instead, we'll rely on external script or use web_fetch.
    # For now, return None.
    return None

def update_page_rating(page_id, star_rating, complaints=None, staffing=None):
    """Update Notion page with new star rating and last updated."""
    api_key = load_notion_api_key()
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    payload = {
        "properties": {
            "Star Rating": {
                "number": float(star_rating) if star_rating is not None else None
            },
            "Last Updated": {
                "date": {"start": datetime.now().isoformat() + "Z"}
            }
        }
    }
    if complaints is not None:
        payload["properties"]["Complaints"] = {
            "rich_text": [{"type": "text", "text": {"content": complaints}}]
        }
    if staffing is not None:
        payload["properties"]["Staffing"] = {
            "rich_text": [{"type": "text", "text": {"content": staffing}}]
        }
    resp = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=payload)
    if resp.status_code == 200:
        print(f"Updated page {page_id} with rating {star_rating}", file=sys.stderr)
        return True
    else:
        print(f"Failed to update page {page_id}: {resp.status_code} {resp.text[:200]}", file=sys.stderr)
        return False

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Scrape star ratings and update Notion.")
    parser.add_argument("--dry-run", action="store_true", help="Dry run, don't update")
    parser.add_argument("--limit", type=int, default=5, help="Max number of pages to process")
    args = parser.parse_args()
    
    pages = get_all_pages()
    print(f"Found {len(pages)} active pages.", file=sys.stderr)
    processed = 0
    for page in pages[:args.limit]:
        page_id = page["id"]
        props = page.get("properties", {})
        name_obj = props.get("Name", {}).get("title", [])
        name = name_obj[0].get("text", {}).get("content", "").strip() if name_obj else ""
        website = props.get("Website", {}).get("url", "")
        if not website or "agedcareguide.com.au" not in website:
            print(f"Skipping {name} (non‑agedcareguide URL)", file=sys.stderr)
            continue
        print(f"Processing {name}...", file=sys.stderr)
        # Here we would scrape the website
        # For now, simulate
        star_rating = None
        if args.dry_run:
            print(f"  Dry‑run: would scrape {website}", file=sys.stderr)
        else:
            # TODO: actual scraping
            pass
        if star_rating is not None and not args.dry_run:
            update_page_rating(page_id, star_rating)
        processed += 1
        time.sleep(1)  # be polite
    print(f"Processed {processed} pages.", file=sys.stderr)

if __name__ == "__main__":
    main()