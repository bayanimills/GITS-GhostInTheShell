#!/usr/bin/env python3
"""
ACAT referral template generator.
Creates a draft letter for GP/hospital social worker to refer Edward Mills for ACAT assessment.
"""
import os
import sys
import json
import argparse
from datetime import datetime
from pathlib import Path

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_profile(patient_id="edward_mills"):
    """Load patient profile JSON."""
    profile_path = Path(__file__).parent.parent / "profile" / f"{patient_id}.json"
    with open(profile_path) as f:
        return json.load(f)

def generate_acat_letter(profile, output_format="txt"):
    """Generate ACAT referral letter."""
    today = datetime.now().strftime("%d/%m/%Y")
    # Extract relevant data
    name = profile["full_name"]
    dob = profile["date_of_birth"]
    gp = profile["key_contacts"]["gp"]
    gp_name = gp.get("name", "Dr. [GP Name]")
    gp_clinic = gp.get("clinic", "[Clinic]")
    conditions = ", ".join(profile["medical_summary"]["primary_conditions"])
    medications = "; ".join(profile["medical_summary"]["medications"])
    mobility = profile["medical_summary"]["mobility"]
    cognitive = profile["medical_summary"]["cognitive_status"]
    # Family contact
    family = profile["key_contacts"]["family"]
    primary_family = next((f for f in family if f.get("primary_decision_maker")), {})
    family_name = primary_family.get("name", "[Family Member]")
    family_relationship = primary_family.get("relationship", "[Relationship]")

    # Letter template
    letter = f"""
{ gp_name }
{ gp_clinic }

Dear Dr. { gp_name.split()[-1] },

**RE: ACAT Referral for { name } (DOB: { dob })**

I am writing to request an Aged Care Assessment Team (ACAT) assessment for the above patient.

**Clinical Summary:**
- Primary conditions: { conditions }
- Current medications: { medications }
- Mobility: { mobility }
- Cognitive status: { cognitive }

**Recent Hospitalisation:**
Patient was admitted to Royal North Shore Hospital on 18/02/2026 with a suspected stroke. Discharge planning is underway, and a high‑care residential aged‑care placement is likely required.

**Care Needs:**
- 24‑hour nursing care
- Assistance with transfers, personal care, medication management
- Dementia‑capable environment (mild cognitive impairment suspected)
- Stroke rehabilitation services

**Family Support:**
Primary contact: { family_name } ({ family_relationship }).

**Request:**
Please refer { name } for an ACAT assessment for permanent residential aged care (high‑care) and/or a Home Care Package if appropriate.

I am available to discuss further if needed.

Yours sincerely,

[Your Name]
[Your Position]
[Contact Details]

Date: { today }
"""
    return letter.strip()

def main():
    parser = argparse.ArgumentParser(description="Generate ACAT referral letter.")
    parser.add_argument("--patient", default="edward_mills", help="Patient ID")
    parser.add_argument("--output", help="Output file path (default: stdout)")
    parser.add_argument("--format", choices=["txt", "md", "html"], default="txt")
    args = parser.parse_args()

    profile = load_profile(args.patient)
    letter = generate_acat_letter(profile, args.format)

    if args.output:
        with open(args.output, "w") as f:
            f.write(letter)
        print(f"ACAT referral letter saved to {args.output}", file=sys.stderr)
    else:
        print(letter)

if __name__ == "__main__":
    main()