#!/usr/bin/env python3
"""
Update Notion data source with additional properties for enhancements.
Adds Star Rating, Complaints, Staffing, Risk Score, Last Updated.
"""
import os
import sys
import json
import requests

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_notion_api_key():
    """Read Notion API key from standard location."""
    path = os.path.expanduser("~/.config/notion/api_key")
    with open(path) as f:
        return f.read().strip()

def update_data_source_properties():
    """Add new properties to the Northern Beaches Nursing Homes data source."""
    api_key = load_notion_api_key()
    data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    
    # 1. Fetch current data source
    print("Fetching current data source...", file=sys.stderr)
    resp = requests.get(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers)
    if resp.status_code != 200:
        print(f"Error fetching data source: {resp.status_code} {resp.text[:500]}", file=sys.stderr)
        return False
    ds = resp.json()
    current_props = ds.get("properties", {})
    print(f"Current properties: {list(current_props.keys())}", file=sys.stderr)
    
    # 2. Define new properties
    new_props = {
        "Star Rating": {
            "type": "number",
            "number": {"format": "number"}
        },
        "Complaints": {
            "type": "rich_text",
            "rich_text": {}
        },
        "Staffing": {
            "type": "rich_text",
            "rich_text": {}
        },
        "Risk Score": {
            "type": "number",
            "number": {"format": "number"}
        },
        "Last Updated": {
            "type": "date",
            "date": {}
        }
    }
    
    # Merge (keep existing, add new)
    updated_props = {**current_props, **new_props}
    print(f"Updated property count: {len(updated_props)}", file=sys.stderr)
    
    # 3. Patch data source
    payload = {
        "properties": updated_props
    }
    print("Patching data source...", file=sys.stderr)
    resp = requests.patch(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers, json=payload)
    if resp.status_code == 200:
        updated = resp.json()
        print(f"✅ Data source updated successfully.", file=sys.stderr)
        print(f"   Properties: {list(updated.get('properties', {}).keys())}", file=sys.stderr)
        return True
    else:
        print(f"❌ Error {resp.status_code}: {resp.text[:500]}", file=sys.stderr)
        return False

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Update Notion data source with enhancement properties.")
    parser.add_argument("--dry-run", action="store_true", help="Show planned changes without applying")
    args = parser.parse_args()
    
    if args.dry_run:
        print("Dry‑run: would add Star Rating, Complaints, Staffing, Risk Score, Last Updated.", file=sys.stderr)
        return
    success = update_data_source_properties()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()