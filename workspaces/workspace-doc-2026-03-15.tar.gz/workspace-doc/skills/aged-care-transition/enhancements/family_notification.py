#!/usr/bin/env python3
"""
Family notification via AgentMail.
Sends progress updates to family contacts listed in patient profile.
"""
import os
import sys
import json
import argparse
from pathlib import Path

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

try:
    import agentmail
    AGENTMAIL_AVAILABLE = True
except ImportError:
    AGENTMAIL_AVAILABLE = False

def load_profile(patient_id="edward_mills"):
    """Load patient profile JSON."""
    profile_path = Path(__file__).parent.parent / "profile" / f"{patient_id}.json"
    with open(profile_path) as f:
        return json.load(f)

def send_update(profile, subject, body, dry_run=False):
    """
    Send an email update to family contacts.
    Returns list of recipients.
    """
    family = profile["key_contacts"]["family"]
    recipients = []
    for contact in family:
        email = contact.get("email", "").strip()
        if email and "@" in email:
            recipients.append(email)
    if not recipients:
        return []
    
    if dry_run or not AGENTMAIL_AVAILABLE:
        print(f"Dry‑run: would send to {recipients}", file=sys.stderr)
        print(f"Subject: {subject}", file=sys.stderr)
        print(f"Body:\n{body}", file=sys.stderr)
        return recipients
    
    # Actually send via AgentMail
    # Sender is configured via environment variable AGENTMAIL_API_KEY
    # The default sender is ewm-contact@agentmail.to
    try:
        # Use agentmail's send function (check documentation)
        # For now, we'll assume a simple send via SMTP not configured.
        # We'll use the agentmail.Client
        client = agentmail.Client()
        # This is a placeholder; adjust based on actual SDK
        response = client.send(
            to=recipients,
            subject=subject,
            body=body
        )
        print(f"Sent email to {recipients}, response: {response}", file=sys.stderr)
    except Exception as e:
        print(f"Failed to send email: {e}", file=sys.stderr)
        return []
    return recipients

def main():
    parser = argparse.ArgumentParser(description="Send family notification.")
    parser.add_argument("--patient", default="edward_mills", help="Patient ID")
    parser.add_argument("--subject", required=True, help="Email subject")
    parser.add_argument("--body", required=True, help="Email body")
    parser.add_argument("--dry-run", action="store_true", help="Dry run, don't actually send")
    parser.add_argument("--update-type", choices=["checklist", "facility", "cost", "general"], default="general", help="Type of update")
    args = parser.parse_args()

    if not AGENTMAIL_AVAILABLE:
        print("Warning: agentmail module not installed. Running in dry‑run mode.", file=sys.stderr)
        args.dry_run = True

    profile = load_profile(args.patient)
    recipients = send_update(profile, args.subject, args.body, args.dry_run)
    if recipients:
        print(f"Notification sent to {len(recipients)} recipient(s).")
    else:
        print("No valid email recipients found.")

if __name__ == "__main__":
    main()