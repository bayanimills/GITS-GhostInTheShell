#!/usr/bin/env python3
"""
Risk scoring for aged care facilities.
Compute risk score based on Star Rating, Complaints, Staffing (if available).
"""
import os
import sys
import json
import requests
from pathlib import Path

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_notion_api_key():
    path = os.path.expanduser("~/.config/notion/api_key")
    with open(path) as f:
        return f.read().strip()

def get_all_pages():
    """Fetch all active pages from Notion."""
    api_key = load_notion_api_key()
    data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    resp = requests.post(
        f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
        headers=headers,
        json={"page_size": 100}
    )
    if resp.status_code != 200:
        print(f"Error fetching pages: {resp.status_code} {resp.text[:500]}", file=sys.stderr)
        return []
    pages = resp.json().get("results", [])
    pages = [p for p in pages if not p.get("archived", False)]
    return pages

def compute_risk_score(star_rating, complaints_text, staffing_text):
    """
    Compute risk score 0‑10 (0 = low risk, 10 = high risk).
    If data missing, return None.
    """
    score = 0
    # Star rating: lower rating → higher risk
    if star_rating is not None:
        # Star rating is 0‑5? Actually 1‑5 stars. Assume 5 is best.
        # Convert to risk: 5 stars → 0 risk, 1 star → 10 risk
        risk_from_stars = (5 - star_rating) * 2.5  # max 10
        score += risk_from_stars
    # Complaints: if text contains numbers, parse; else assume unknown
    if complaints_text and isinstance(complaints_text, str):
        # Very simple: if complaints mentioned, add 3 risk
        if any(word in complaints_text.lower() for word in ["complaint", "investigation", "sanction"]):
            score += 3
    # Staffing: if low staffing mentioned, add risk
    if staffing_text and isinstance(staffing_text, str):
        if "short" in staffing_text.lower() or "low" in staffing_text.lower():
            score += 4
    # Cap at 10
    if score > 10:
        score = 10
    return round(score, 1)

def update_page_risk_score(page_id, risk_score):
    """Update Notion page with risk score."""
    api_key = load_notion_api_key()
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    payload = {
        "properties": {
            "Risk Score": {
                "number": float(risk_score)
            }
        }
    }
    resp = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=payload)
    if resp.status_code == 200:
        print(f"Updated page {page_id} with risk score {risk_score}", file=sys.stderr)
        return True
    else:
        print(f"Failed to update page {page_id}: {resp.status_code} {resp.text[:200]}", file=sys.stderr)
        return False

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Compute and update risk scores for facilities.")
    parser.add_argument("--dry-run", action="store_true", help="Dry run, don't update")
    args = parser.parse_args()
    
    pages = get_all_pages()
    print(f"Found {len(pages)} active pages.", file=sys.stderr)
    
    updated = 0
    for page in pages:
        page_id = page["id"]
        props = page.get("properties", {})
        # Extract star rating
        star_obj = props.get("Star Rating", {}).get("number")
        star_rating = star_obj if star_obj is not None else None
        # Extract complaints
        complaints_obj = props.get("Complaints", {}).get("rich_text", [])
        complaints = complaints_obj[0].get("text", {}).get("content", "") if complaints_obj else ""
        # Extract staffing
        staffing_obj = props.get("Staffing", {}).get("rich_text", [])
        staffing = staffing_obj[0].get("text", {}).get("content", "") if staffing_obj else ""
        
        # If no data, skip
        if star_rating is None and not complaints and not staffing:
            continue
        
        risk_score = compute_risk_score(star_rating, complaints, staffing)
        if risk_score is None:
            continue
        
        if args.dry_run:
            name_obj = props.get("Name", {}).get("title", [])
            name = name_obj[0].get("text", {}).get("content", "").strip() if name_obj else ""
            print(f"Dry‑run: {name} -> risk score {risk_score}", file=sys.stderr)
        else:
            if update_page_risk_score(page_id, risk_score):
                updated += 1
    
    print(f"Updated {updated} pages with risk scores.", file=sys.stderr)

if __name__ == "__main__":
    main()