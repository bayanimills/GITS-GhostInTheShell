#!/usr/bin/env python3
"""
Facility matcher for aged-care-transition skill.
Queries Notion database of Northern Beaches nursing homes and filters by criteria.
"""
import os
import sys
import json
import requests
from typing import List, Dict, Any

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def load_notion_api_key() -> str:
    """Read Notion API key from standard location."""
    path = os.path.expanduser("~/.config/notion/api_key")
    with open(path) as f:
        return f.read().strip()

def query_notion_database(filters: Dict[str, Any] = None) -> List[Dict]:
    """
    Query the Northern Beaches Nursing Homes data source.
    Returns list of pages with properties.
    """
    api_key = load_notion_api_key()
    data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2025-09-03",
        "Content-Type": "application/json",
    }
    payload = {"page_size": 100}
    resp = requests.post(
        f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
        headers=headers,
        json=payload
    )
    if resp.status_code != 200:
        print(f"Error querying Notion: {resp.status_code} {resp.text[:500]}", file=sys.stderr)
        return []
    results = resp.json().get("results", [])
    # Filter out archived pages
    results = [r for r in results if not r.get("archived", False)]
    return results

def filter_facilities(
    facilities: List[Dict],
    suburbs: List[str] = None,
    service_type: str = None,
    min_star_rating: float = None
) -> List[Dict]:
    """Apply filters to facility list."""
    filtered = []
    for page in facilities:
        props = page.get("properties", {})
        # Suburb filter
        if suburbs:
            suburb_obj = props.get("Suburb", {}).get("rich_text", [])
            suburb = suburb_obj[0].get("text", {}).get("content", "").strip() if suburb_obj else ""
            if suburb not in suburbs:
                continue
        # Service Type filter
        if service_type:
            st_obj = props.get("Service Type", {}).get("select", {})
            st = st_obj.get("name", "").strip()
            if st != service_type:
                continue
        # Star Rating filter (placeholder – not yet in database)
        if min_star_rating is not None:
            # TODO: integrate Star Ratings when available
            pass
        filtered.append(page)
    return filtered

def format_facility(page: Dict) -> Dict[str, Any]:
    """Extract relevant fields into a clean dict."""
    props = page.get("properties", {})
    name_obj = props.get("Name", {}).get("title", [])
    name = name_obj[0].get("text", {}).get("content", "").strip() if name_obj else ""
    address_obj = props.get("Address", {}).get("rich_text", [])
    address = address_obj[0].get("text", {}).get("content", "").strip() if address_obj else ""
    suburb_obj = props.get("Suburb", {}).get("rich_text", [])
    suburb = suburb_obj[0].get("text", {}).get("content", "").strip() if suburb_obj else ""
    postcode_obj = props.get("Postcode", {}).get("rich_text", [])
    postcode = postcode_obj[0].get("text", {}).get("content", "").strip() if postcode_obj else ""
    website = props.get("Website", {}).get("url", "")
    service_type_obj = props.get("Service Type", {}).get("select", {})
    service_type = service_type_obj.get("name", "")
    status_obj = props.get("Status", {}).get("select", {})
    status = status_obj.get("name", "")
    notes_obj = props.get("Notes", {}).get("rich_text", [])
    notes = notes_obj[0].get("text", {}).get("content", "").strip() if notes_obj else ""
    return {
        "name": name,
        "address": address,
        "suburb": suburb,
        "postcode": postcode,
        "website": website,
        "service_type": service_type,
        "status": status,
        "notes": notes,
        "page_id": page.get("id")
    }

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Match aged care facilities to patient criteria.")
    parser.add_argument("--suburb", action="append", help="Suburb(s) to filter by")
    parser.add_argument("--service-type", help="Service type (e.g., 'Nursing Home')")
    parser.add_argument("--min-rating", type=float, help="Minimum Star Rating (not yet implemented)")
    parser.add_argument("--output", choices=["json", "table", "csv"], default="table")
    args = parser.parse_args()

    print("Querying Notion database...", file=sys.stderr)
    facilities = query_notion_database()
    print(f"Found {len(facilities)} active facilities.", file=sys.stderr)

    filtered = filter_facilities(
        facilities,
        suburbs=args.suburb,
        service_type=args.service_type,
        min_star_rating=args.min_rating
    )
    print(f"Filtered to {len(filtered)} facilities.", file=sys.stderr)

    formatted = [format_facility(f) for f in filtered]

    if args.output == "json":
        print(json.dumps(formatted, indent=2))
    elif args.output == "table":
        # Simple ASCII table
        if not formatted:
            print("No facilities match criteria.")
            return
        print(f"{'Name':40} {'Suburb':15} {'Service Type':20} {'Status':15}")
        print("-" * 90)
        for f in formatted:
            print(f"{f['name'][:38]:40} {f['suburb'][:13]:15} {f['service_type'][:18]:20} {f['status'][:13]:15}")
    elif args.output == "csv":
        import csv
        writer = csv.writer(sys.stdout)
        writer.writerow(["Name", "Suburb", "Postcode", "Address", "Website", "Service Type", "Status"])
        for f in formatted:
            writer.writerow([f["name"], f["suburb"], f["postcode"], f["address"],
                             f["website"], f["service_type"], f["status"]])

if __name__ == "__main__":
    main()