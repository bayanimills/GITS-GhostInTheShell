# Aged Care Costs & Fees

_Source: agedcareguide.com.au/aged-care-costs_

## Residential Aged Care

### 1. Accommodation Payment
- **RAD** – Refundable Accommodation Deposit (lump sum). Fully refundable when leaving.
- **DAP** – Daily Accommodation Payment (daily interest on RAD). Non‑refundable.
- **Combination** – Part RAD, part DAP.
- **Maximum RAD** set by government; facility can charge lower.

### 2. Daily Fees
- **Basic daily fee** – Covers living costs (meals, utilities). Set at 85% of single age pension.
- **Means‑tested care fee** – Additional fee based on income & assets assessment. Annual & lifetime caps apply.
- **Extra service fees** – For premium rooms or additional services (e.g., hairdressing, wine with meals).

### 3. Means Test
- **Income test** – Includes pension, super, rental income.
- **Asset test** – Includes home (if not occupied by partner), investments, savings.
- **Home exempt** for first 2 years (if occupied by partner or carer).
- **Outcomes:** No fee, partial fee, full fee.

## Home Care Packages

### 1. Package Levels
| Level | Annual subsidy (approx) |
|-------|-------------------------|
| 1     | $10,000                |
| 2     | $18,000                |
| 3     | $35,000                |
| 4     | $53,000                |

### 2. Fees
- **Basic daily fee** – Up to 17.5% of single age pension.
- **Income‑tested fee** – Additional fee based on means test. Annual & lifetime caps.

## Dementia & Respite Care
- Similar fee structure to residential care.
- Respite daily fee same as basic daily fee; may have additional charges for extra services.

## Financial Advice
- **Free financial advice** via My Aged Care (face‑to‑face or phone).
- **Fee calculators** available on My Aged Care website.
- **Consider:** Selling home to fund RAD; impact on age pension.

## For Edward Mills (estimated)
- **Home ownership:** Yes (Northern Beaches). Exempt for 2 years if partner remains?
- **Assets:** Likely above threshold → means‑tested care fee applicable.
- **Next step:** Complete My Aged Care fee estimator with actual figures.