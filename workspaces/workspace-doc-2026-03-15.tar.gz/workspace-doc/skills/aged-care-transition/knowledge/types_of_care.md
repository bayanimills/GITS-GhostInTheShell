# Types of Aged Care

_Source: agedcareguide.com.au/types-of-care_

## 1. Home Care
- **Home Care Packages (HCP)** – Four levels (1–4) providing different funding amounts.
- **Services:** personal care, nursing, allied health, meals, transport, social support.
- **Assessment:** ACAT assessment required.
- **Provider management:** Choose a provider who manages your package.

## 2. Residential Aged Care (Nursing Homes)
- **High‑care** – 24‑hour nursing care, assistance with most daily activities.
- **Low‑care** (now called “residential care”) – Some assistance, but more independent.
- **Accommodation payment:** RAD (Refundable Accommodation Deposit) or DAP (Daily Accommodation Payment) or combination.
- **Daily fees:** Basic daily fee + means‑tested care fee + extra service fees.

## 3. Dementia Care
- **Specialised dementia units** – Secure environments, trained staff, tailored activities.
- **Design principles:** Wayfinding cues, safe outdoor spaces, reduced noise.
- **Costs:** Similar to residential care; may have extra fees for specialised design.

## 4. Respite Care
- **Short‑term care** – In‑home or residential, for carers needing a break or during recovery.
- **Eligibility:** ACAT assessment for planned respite; emergency respite available.
- **Funding:** Government‑subsidised up to 63 days per financial year.

## 5. Palliative Care
- **End‑of‑life care** – Pain management, comfort, psychological support.
- **Can be delivered** at home, in hospital, or in residential aged care.
- **Funding:** Part of residential care package or via palliative care programs.

## 6. Transition Care
- **Short‑term care** (up to 12 weeks) after hospital stay, to regain independence.
- **Goal:** Avoid premature permanent residential care.
- **Assessment:** Hospital team refers to ACAT.

## For Edward Mills (stroke 2026‑02‑18)
- **Immediate need:** Transition care (if available) or high‑care residential with rehabilitation.
- **Long‑term likely:** High‑care nursing home with dementia‑capable staff.
- **Consider:** Respite for family carer support during transition.