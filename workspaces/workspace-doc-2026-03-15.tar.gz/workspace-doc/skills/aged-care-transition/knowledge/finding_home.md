# Finding an Aged Care Home

_Source: agedcareguide.com.au/finding-a-home_

## Steps

### 1. Search
- **Use My Aged Care ‘Find a provider’** or agedcareguide.com.au.
- **Filter by:** location, care type, specialisations (dementia, palliative).
- **Check Star Ratings** and recent compliance reports.

### 2. Shortlist
- **Visit each facility** (at least 2–3).
- **Consider:** proximity to family, public transport, visiting hours.
- **Look for:** cleanliness, odour, staff‑resident interaction, activities.

### 3. Visit Questions
**General:**
- What are the accommodation payment options (RAD/DAP)?
- What is the basic daily fee? Extra service fees?
- What is the staff‑to‑resident ratio? Staff turnover?
- How are medications managed?
- What allied health services are onsite (physio, podiatry, OT)?

**Clinical:**
- How are acute medical issues handled (GP visits, hospital transfer)?
- Is there a dementia‑specific wing? Secure outdoor space?
- What rehabilitation services are available (post‑stroke)?
- How are care plans developed and reviewed?

**Lifestyle:**
- What social activities are offered?
- Can residents personalise their rooms?
- What are meal options? Special diets?
- Are pets allowed? Visitors’ hours?

### 4. Application
- **Submit expression of interest** (EOI) to each facility.
- **Provide:** ACAT approval letter, medical summary, medication list.
- **Waitlist** common; may need to accept first available suitable bed.

### 5. Move‑in
- **Sign Resident Agreement** (read carefully).
- **Pay accommodation deposit** (RAD) and first month’s fees.
- **Attend orientation** – meet staff, other residents.
- **Review care plan** within first 2 weeks.

## For Edward Mills
- **Priority suburbs:** Northern Beaches (Manly Vale, Manly, Balgowlah, Freshwater, Seaforth, etc.).
- **Specialisations needed:** Stroke rehabilitation, dementia capability, 24‑hour nursing.
- **Family involvement:** Multiple visits with checklist.
- **Timeline:** Start searching while ACAT assessment pending.