# Aged Care Rights & Standards

_Sources: agedcareguide.com.au/aged-care-rights, aged-care-standards, aged-care-complaints, aged-care-advocacy_

## Charter of Aged Care Rights (15 rights)
1. Safe and high‑quality care.
2. Treated with dignity and respect.
3. Maintain identity and culture.
4. Live without abuse and neglect.
5. Informed about care and services.
6. Access to personal information.
7. Control over personal decisions.
8. Independence.
9. Stay connected with community.
10. Have a person of choice (advocate).
11. Complain without fear.
12. Have complaints resolved fairly.
13. Have personal information protected.
14. Give feedback on the Charter.
15. Have these rights upheld.

## Aged Care Quality Standards (8 standards)
1. **Consumer dignity and choice** – Respect for identity, culture, diversity.
2. **Ongoing assessment and planning** – Care plans reviewed regularly.
3. **Personal and clinical care** – Safe, effective, appropriate care.
4. **Services and supports for daily living** – Nutrition, hydration, cleanliness.
5. **Organisation’s service environment** – Safe, clean, comfortable.
6. **Feedback and complaints** – Easy to complain, timely resolution.
7. **Human resources** – Skilled, qualified staff.
8. **Organisational governance** – Leadership, risk management, compliance.

## Making a Complaint
- **To the provider first** – Use their complaints process.
- **If unresolved:** Aged Care Quality and Safety Commission (ACQSC) – 1800 951 822.
- **Independent advocacy:** Older Persons Advocacy Network (OPAN) – 1800 700 600.
- **Legal support:** Legal Aid, community legal centres.

## Star Ratings
- **Introduced 2022** – 1‑to‑5 star rating for residential aged care homes.
- **Four sub‑ratings:** Compliance, quality measures, resident experience, staffing.
- **Publicly available** on My Aged Care website and agedcareguide.com.au.
- **Use when shortlisting:** Prefer 4‑ or 5‑star homes.

## For Edward Mills
- **Ensure** any chosen facility complies with Standards, has high Star Rating.
- **Family role:** Be aware of rights; advocate if needed.
- **Document** any concerns; use complaints process if necessary.