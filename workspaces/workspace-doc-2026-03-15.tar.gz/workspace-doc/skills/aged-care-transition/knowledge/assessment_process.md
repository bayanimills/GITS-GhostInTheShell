# Aged Care Assessment Process

_Source: agedcareguide.com.au/aged-care-assessment_

## ACAT / ACAS
- **ACAT** – Aged Care Assessment Team (for residential care & home care packages).
- **ACAS** – Aged Care Assessment Service (same, but some states use different name).
- **Purpose:** Determine eligibility and recommend appropriate level of care.

## Referral
- **Who can refer:** GP, hospital social worker, family, self.
- **How:** Online via My Aged Care, phone (1800 200 422), or through hospital.
- **Urgent assessments** available (e.g., hospital discharge).

## Assessment
- **Where:** Usually at home or in hospital.
- **Who:** Nurse, social worker, allied health professional.
- **Questions:** Medical needs, mobility, cognition, support network, preferences.
- **Documents needed:** Medical history, medication list, income/assets details.

## Outcomes
1. **Approved for residential care** – high‑care or low‑care.
2. **Approved for home care package** – level 1–4.
3. **Approved for respite care** – days per year.
4. **Referred to other services** (e.g., Commonwealth Home Support Programme).

## Approval Letter
- **Received within 1–2 weeks.**
- **Valid:** 12 months (home care) / 6 months (residential care).
- **Next steps:** Find a provider/facility; approval does not guarantee a place.

## For Edward Mills
- **Current status:** In hospital (RNSH) post‑stroke.
- **Action:** Request ACAT referral via hospital social worker **immediately**.
- **Goal:** Approval for high‑care residential (with dementia capability) and/or transition care.
- **Note:** Stroke survivors often need 24‑hour nursing; ACAT will consider rehabilitation needs.