# Aged Care Transition Checklist

For patient: **Edward Mills** (DOB 1934‑07‑19)

## Phase 1: Assessment & Planning
- [ ] **ACAT referral** – Request via hospital social worker (RNSH).
- [ ] **Gather documents** – Medical summary, medication list, GP details.
- [ ] **Financial assessment** – Estimate assets/income for means test.
- [ ] **Family meeting** – Discuss preferences, location, budget.

## Phase 2: Facility Search
- [ ] **Search facilities** – Use Notion database (Northern Beaches Nursing Homes).
- [ ] **Shortlist 3–5 facilities** – Filter by suburb, service type, specialisations.
- [ ] **Visit facilities** – Use question list from `finding_home.md`.
- [ ] **Compare costs** – Use cost estimator for each facility's RAD/DAP.

## Phase 3: Application & Approval
- [ ] **Submit expressions of interest** – Apply to shortlisted facilities.
- [ ] **Provide ACAT approval letter** – Once received.
- [ ] **Waitlist management** – Follow up weekly.
- [ ] **Accept offer** – When suitable bed becomes available.

## Phase 4: Financial & Legal
- [ ] **Resident Agreement review** – Read carefully, seek advice if needed.
- [ ] **Arrange RAD/DAP payment** – Decide lump sum vs daily payments.
- [ ] **Update Centrelink** – Notify change of circumstances.
- [ ] **Power of Attorney / Guardianship** – Ensure in place.

## Phase 5: Move‑in
- [ ] **Pack personal items** – Label belongings.
- [ ] **Arrange transport** – Ambulance or family car.
- [ ] **Orientation day** – Meet staff, other residents.
- [ ] **Care plan meeting** – Within first 2 weeks.

## Phase 6: Post‑move
- [ ] **Monitor adjustment** – Visit regularly, watch for signs of distress.
- [ ] **Review care plan** – After 1 month.
- [ ] **Provide feedback** – To facility and family.
- [ ] **Update records** – In Notion, Dart, memory files.

---
*Each step can be linked to a Dart subtask under the stroke event (`YhH8uggrObRf`).*