#!/usr/bin/env python3
"""
Aged‑care transition checklist manager.
Reads checklist.md, suggests next step, optionally creates Dart subtask.
"""
import os
import sys
import re
import json
from typing import List, Dict
from pathlib import Path

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

CHECKLIST_PATH = Path(__file__).parent / "checklist.md"

def parse_checklist() -> List[Dict]:
    """Parse checklist.md into structured steps."""
    with open(CHECKLIST_PATH, "r") as f:
        lines = f.readlines()
    steps = []
    current_phase = ""
    for line in lines:
        line = line.rstrip()
        # Phase header
        if line.startswith("## Phase"):
            current_phase = line.replace("## ", "").strip()
        # Checklist item
        match = re.match(r"^- \[([ x])\] \*\*(.*?)\*\* – (.*)", line)
        if match:
            checked = match.group(1) == "x"
            title = match.group(2).strip()
            description = match.group(3).strip()
            steps.append({
                "phase": current_phase,
                "title": title,
                "description": description,
                "checked": checked,
                "raw": line
            })
    return steps

def get_next_unchecked_step(steps: List[Dict]) -> Dict:
    """Return the first unchecked step."""
    for step in steps:
        if not step["checked"]:
            return step
    return None

def mark_step_checked(step_title: str, steps: List[Dict]) -> bool:
    """Update checklist.md by marking a step as checked."""
    with open(CHECKLIST_PATH, "r") as f:
        content = f.read()
    # Find the line with this title (simplistic)
    lines = content.split("\n")
    for i, line in enumerate(lines):
        if step_title in line and line.startswith("- [ ]"):
            lines[i] = line.replace("- [ ]", "- [x]")
            with open(CHECKLIST_PATH, "w") as f:
                f.write("\n".join(lines))
            return True
    return False

def create_dart_subtask(step: Dict, parent_task_id: str = "YhH8uggrObRf") -> bool:
    """Create a Dart subtask for this step."""
    try:
        from scripts.dart_client import DartClient
    except ImportError:
        print("Error: Dart client not found. Skipping Dart subtask creation.", file=sys.stderr)
        return False
    client = DartClient()
    title = f"Aged‑care transition: {step['title']}"
    description = f"{step['description']}\n\nPhase: {step['phase']}\nPatient: Edward Mills"
    tags = ["patient-edward-mills", "aged-care-transition"]
    try:
        task = client.create_task(
            title=title,
            description=description,
            tags=tags,
            parent_id=parent_task_id
        )
        print(f"Created Dart subtask: {task.get('htmlUrl')}", file=sys.stderr)
        return True
    except Exception as e:
        print(f"Failed to create Dart subtask: {e}", file=sys.stderr)
        return False

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Manage aged‑care transition checklist.")
    parser.add_argument("--list", action="store_true", help="List all steps")
    parser.add_argument("--next", action="store_true", help="Show next uncompleted step")
    parser.add_argument("--complete", help="Mark a step as completed by title substring")
    parser.add_argument("--create-dart", action="store_true", help="Create Dart subtask for next step")
    parser.add_argument("--dart-parent", default="YhH8uggrObRf", help="Parent Dart task ID")
    args = parser.parse_args()

    steps = parse_checklist()
    if args.list:
        for step in steps:
            status = "✓" if step["checked"] else " "
            print(f"{status} {step['phase']}: {step['title']}")
        return

    if args.next:
        next_step = get_next_unchecked_step(steps)
        if next_step:
            print(f"Next step: {next_step['title']}")
            print(f"Phase: {next_step['phase']}")
            print(f"Description: {next_step['description']}")
            if args.create_dart:
                create_dart_subtask(next_step, args.dart_parent)
        else:
            print("All steps completed!")
        return

    if args.complete:
        # Find step matching substring
        matched = None
        for step in steps:
            if args.complete.lower() in step["title"].lower():
                matched = step
                break
        if matched:
            if mark_step_checked(matched["title"], steps):
                print(f"Marked step as completed: {matched['title']}")
            else:
                print("Could not update checklist file.")
        else:
            print(f"No step matching '{args.complete}' found.")
        return

    # Default action: show next step
    next_step = get_next_unchecked_step(steps)
    if next_step:
        print(f"Next step: {next_step['title']}")
        print(f"Phase: {next_step['phase']}")
        print(f"Description: {next_step['description']}")
    else:
        print("All steps completed.")

if __name__ == "__main__":
    main()