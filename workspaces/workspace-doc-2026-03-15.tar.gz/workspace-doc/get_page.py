#!/usr/bin/env python3
import os
import requests
import json
import sys

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

page_id = sys.argv[1] if len(sys.argv) > 1 else "30dd323b-89ec-8064-ba6e-c5ca7689ed67"
resp = requests.get(f"https://api.notion.com/v1/pages/{page_id}", headers=headers)
if resp.status_code == 200:
    page = resp.json()
    print(json.dumps(page, indent=2))
else:
    print(f"Error: {resp.status_code}")
    print(resp.text)