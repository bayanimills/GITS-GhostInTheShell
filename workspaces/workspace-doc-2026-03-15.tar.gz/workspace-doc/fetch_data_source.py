#!/usr/bin/env python3
import os
import requests
import json

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
}

print(f"Fetching data source {data_source_id}...")
resp = requests.get(f"https://api.notion.com/v1/data_sources/{data_source_id}", headers=headers)
if resp.status_code == 200:
    ds = resp.json()
    print(json.dumps(ds, indent=2, default=str))
else:
    print(f"Error {resp.status_code}: {resp.text[:500]}")