#!/usr/bin/env python3
import os
import requests
import json
from datetime import datetime

NOTION_API_KEY = os.environ.get('NOTION_API_KEY', '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')
DATABASE_ID = 'd83a5dff-506f-4368-9c49-4c11b50ce33d'
DRY_RUN = False  # Set to True to preview

headers = {
    'Authorization': f'Bearer {NOTION_API_KEY}',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
}

def get_prop(page, prop_name, prop_type):
    prop = page.get('properties', {}).get(prop_name, {})
    if prop.get('type') != prop_type:
        return None
    if prop_type == 'title':
        titles = prop.get('title', [])
        if titles:
            return titles[0].get('plain_text', '')
        return ''
    elif prop_type == 'select':
        select = prop.get('select', {})
        if select is None:
            return None
        return select.get('name')
    elif prop_type == 'date':
        date = prop.get('date')
        if date is None:
            return None
        return date.get('start')
    elif prop_type == 'rich_text':
        rich_text = prop.get('rich_text', [])
        if rich_text:
            return rich_text[0].get('plain_text', '')
        return ''
    else:
        return None

def fetch_all_pages():
    url = f'https://api.notion.com/v1/databases/{DATABASE_ID}/query'
    all_pages = []
    cursor = None
    while True:
        payload = {}
        if cursor:
            payload['start_cursor'] = cursor
        response = requests.post(url, headers=headers, json=payload)
        if response.status_code != 200:
            print(f"Error fetching pages: {response.status_code} {response.text}")
            break
        data = response.json()
        all_pages.extend(data.get('results', []))
        cursor = data.get('next_cursor')
        if not cursor:
            break
    return all_pages

def archive_page(page_id):
    url = f'https://api.notion.com/v1/pages/{page_id}'
    payload = {'archived': True}
    response = requests.patch(url, headers=headers, json=payload)
    if response.status_code == 200:
        return True
    else:
        print(f"  Archive failed: {response.status_code} {response.text}")
        return False

def main():
    pages = fetch_all_pages()
    print(f"Found {len(pages)} pages")
    
    # Group by task name
    groups = {}
    for page in pages:
        task = get_prop(page, 'Task', 'title')
        if not task:
            continue
        groups.setdefault(task, []).append(page)
    
    duplicates = {task: pages for task, pages in groups.items() if len(pages) > 1}
    if duplicates:
        print(f"\nDuplicate tasks ({len(duplicates)}):")
        for task, pages in duplicates.items():
            print(f"  {task}: {len(pages)} copies")
    
    # Decide which to keep (earliest due date, or first)
    to_archive = []
    for task, pages in groups.items():
        if len(pages) == 1:
            continue
        # Sort by due date (None last), then by page ID
        def sort_key(p):
            due = get_prop(p, 'Due Date', 'date')
            if due:
                try:
                    return (0, datetime.fromisoformat(due).timestamp())
                except:
                    return (1, 0)
            return (2, p['id'])
        pages.sort(key=sort_key)
        # Keep first
        keep = pages[0]
        for page in pages[1:]:
            to_archive.append(page)
        print(f"Keeping page {keep['id']} for '{task}' (due: {get_prop(keep, 'Due Date', 'date')})")
    
    # Archive duplicates
    if to_archive:
        print(f"\nWill archive {len(to_archive)} duplicate pages")
        for page in to_archive:
            task = get_prop(page, 'Task', 'title')
            if DRY_RUN:
                print(f"  [DRY RUN] Would archive page {page['id']} ('{task}')")
            else:
                if archive_page(page['id']):
                    print(f"  Archived page {page['id']} ('{task}')")
                else:
                    print(f"  FAILED to archive page {page['id']} ('{task}')")
    else:
        print("\nNo duplicates to archive")
    
    # Verify remaining pages count
    if not DRY_RUN and to_archive:
        remaining = fetch_all_pages()
        print(f"\nRemaining pages after archiving: {len(remaining)}")
        # List tasks
        print("Remaining tasks:")
        for page in remaining:
            task = get_prop(page, 'Task', 'title')
            status = get_prop(page, 'Status', 'select')
            due = get_prop(page, 'Due Date', 'date')
            print(f"  {task} | {status} | due {due}")

if __name__ == '__main__':
    main()