#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, '.')
from scripts.dart_client import DartClient
import json

client = DartClient()
stroke_id = 'YhH8uggrObRf'

# Fetch current task
task = client.get_task(stroke_id)
current_desc = task.get('description', '')

# Load JSON block
with open('docs/stroke_event_data.json', 'r') as f:
    json_data = json.load(f)

json_block = f'\n\n```json\n{json.dumps(json_data, indent=2)}\n```'

# Check if JSON block already exists
if 'stroke_event_data' in current_desc:
    print("JSON block already present, skipping.")
else:
    new_desc = current_desc + json_block
    # Update task
    payload = {
        'description': new_desc
    }
    # Use client._request to PATCH
    resp = client._request('PATCH', f'/tasks/{stroke_id}', json=payload)
    print("✅ Stroke task description updated with JSON block.")
    print(resp)