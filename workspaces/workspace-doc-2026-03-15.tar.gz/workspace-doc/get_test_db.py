import os
import json
import requests

NOTION_KEY = open(os.path.expanduser('~/.config/notion/api_key')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {NOTION_KEY}',
    'Notion-Version': '2025-09-03',
    'Content-Type': 'application/json'
}

database_id = '4992c9b2-2bd6-4d6d-b960-fcff37cf00cb'
url = f'https://api.notion.com/v1/databases/{database_id}'
resp = requests.get(url, headers=HEADERS)
print(f'Status: {resp.status_code}')
if resp.status_code == 200:
    db = resp.json()
    print('Properties:')
    for key, prop in db.get('properties', {}).items():
        print(f'  {key}: {prop.get("type")}')
    print('\nFull properties:')
    print(json.dumps(db.get('properties', {}), indent=2))
else:
    print(resp.text)