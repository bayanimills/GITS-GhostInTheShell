#!/usr/bin/env python3
"""
Sync Dart tasks to Notion with duplicate cleanup.
If multiple Notion pages exist for the same Dart Task ID, keep the oldest and archive the rest.
"""
import os
import sys
import requests
import json
import time
from datetime import datetime

# Load .env file for DART_API_TOKEN
env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))
from scripts.dart_client import DartClient

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}
DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"
DATABASE_ID = "37691f15-655f-4a54-a3eb-915692442433"
STROKE_TASK_ID = "YhH8uggrObRf"

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
    sys.stdout.flush()

def request_with_retry(method, url, **kwargs):
    """Make HTTP request with retry on timeout or 5xx."""
    max_retries = 2
    for attempt in range(max_retries):
        try:
            resp = requests.request(method, url, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.exceptions.Timeout:
            log(f"  Timeout on attempt {attempt+1}/{max_retries}")
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)
        except requests.exceptions.HTTPError as e:
            if e.response.status_code >= 500:
                log(f"  Server error {e.response.status_code} on attempt {attempt+1}/{max_retries}")
                if attempt == max_retries - 1:
                    raise
                time.sleep(2 ** attempt)
            else:
                raise
    raise RuntimeError("Should not reach here")

def query_notion_database(filter_dict=None):
    """Query Notion database using data_source_id."""
    url = f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query"
    payload = {}
    if filter_dict:
        payload["filter"] = filter_dict
    resp = request_with_retry("POST", url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    data = resp.json()
    return data.get("results", [])

def update_page(page_id, properties):
    """Update an existing page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    resp = request_with_retry("PATCH", url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    return resp.json()

def create_page_in_database(properties):
    """Create a new page in the database."""
    url = "https://api.notion.com/v1/pages"
    payload = {
        "parent": {"database_id": DATABASE_ID},
        "properties": properties,
    }
    resp = request_with_retry("POST", url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    return resp.json()

def archive_page(page_id):
    """Archive (soft delete) a page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"archived": True}
    resp = request_with_retry("PATCH", url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    return resp.json()

def dart_task_to_notion_properties(task):
    """Convert Dart task to Notion properties."""
    title = task.get("title", "Untitled")
    status = task.get("status", "To-do")
    priority = task.get("priority", "Medium")
    due_at = task.get("dueAt")
    tags = task.get("tags", [])
    task_id = task.get("id")
    parent_id = task.get("parentId")
    
    phase = "General"
    if "stroke-followup" in tags:
        phase = "Stroke Follow-up"
    elif parent_id == STROKE_TASK_ID:
        phase = "Stroke Follow-up"
    elif "patient-edward-mills" in tags:
        phase = "Patient Management"
    
    due_date = None
    if due_at:
        try:
            if "T" in due_at:
                due_date = due_at.split("T")[0]
            else:
                due_date = due_at
        except:
            pass
    
    properties = {
        "Name": {"title": [{"text": {"content": title}}]},
        "Status": {"select": {"name": status if status in ["To-do", "Doing", "Done"] else "To-do"}},
        "Priority": {"select": {"name": priority if priority else "Medium"}},
        "Phase": {"select": {"name": phase}},
        "Dart Task ID": {"rich_text": [{"text": {"content": task_id}}]},
        "Tags": {"multi_select": [{"name": tag} for tag in tags if tag not in ["patient-edward-mills", "stroke-followup"]]},
    }
    if due_date:
        properties["Due Date"] = {"date": {"start": due_date}}
    
    return properties

def sync_dart_tasks(limit=None):
    """Main sync function with duplicate cleanup."""
    client = DartClient()
    log("Fetching tasks from Dart...")
    response = client.list_tasks(limit=200)
    all_tasks = response.get("results", []) if isinstance(response, dict) else response
    log(f"Total tasks fetched from Dart: {len(all_tasks)}")
    
    edward_tasks = []
    for t in all_tasks:
        tags = t.get("tags", [])
        parent = t.get("parentId")
        if "patient-edward-mills" in tags:
            edward_tasks.append(t)
        elif parent == STROKE_TASK_ID:
            edward_tasks.append(t)
        elif "stroke-followup" in tags:
            edward_tasks.append(t)
    
    log(f"Found {len(edward_tasks)} Edward Mills tasks in Dart.")
    if limit:
        edward_tasks = edward_tasks[:limit]
        log(f"Limiting to {limit} tasks for debugging.")
    
    stats = {"synced": 0, "archived": 0, "errors": 0}
    
    # For each task, sync
    for i, task in enumerate(edward_tasks):
        try:
            task_id = task["id"]
            log(f"Syncing task {i+1}/{len(edward_tasks)}: {task['title']} ({task_id})")
            # Check if already exists in Notion
            filter_prop = {
                "property": "Dart Task ID",
                "rich_text": {"contains": task_id}
            }
            log(f"  Querying Notion...")
            existing = query_notion_database(filter_prop)
            log(f"  Found {len(existing)} existing pages")
            
            # If multiple pages, keep oldest, archive others
            if len(existing) > 1:
                log(f"  Duplicates detected, cleaning up...")
                # Sort by created_time
                existing.sort(key=lambda p: p.get("created_time"))
                keep_page = existing[0]
                archive_pages = existing[1:]
                for dup in archive_pages:
                    dup_id = dup["id"]
                    log(f"  Archiving duplicate page {dup_id}")
                    try:
                        archive_page(dup_id)
                        stats["archived"] += 1
                    except Exception as e:
                        log(f"  Warning: failed to archive {dup_id}: {e}")
                # Update list to just the kept page
                existing = [keep_page]
                log(f"  Kept page {keep_page['id']}")
            
            properties = dart_task_to_notion_properties(task)
            if existing:
                page_id = existing[0]["id"]
                log(f"  Updating existing page {page_id}")
                update_page(page_id, properties)
            else:
                log(f"  Creating new page")
                create_page_in_database(properties)
            stats["synced"] += 1
            log(f"  Done")
            # Delay between tasks
            if i < len(edward_tasks) - 1:
                time.sleep(2)
        except Exception as e:
            stats["errors"] += 1
            log(f"  Error syncing task {task_id}: {e}")
            import traceback
            traceback.print_exc()
    
    log("Sync completed successfully.")
    log(f"Summary: {stats['synced']} tasks synced, {stats['archived']} duplicate pages archived, {stats['errors']} errors.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, help="Limit number of tasks to sync")
    args = parser.parse_args()
    try:
        sync_dart_tasks(limit=args.limit)
    except Exception as e:
        log(f"Fatal error during sync: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)