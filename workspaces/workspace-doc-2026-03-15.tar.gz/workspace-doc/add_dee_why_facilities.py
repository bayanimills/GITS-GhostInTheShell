#!/usr/bin/env python3
import os
import requests
import json
import re

api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
data_source_id = "00214de4-4ab4-4421-9eba-f05a66043aab"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Data from Dee Why search
extracted = [
    {
        "name": "Elizabeth Jenkins Place Aged Care Centre",
        "location": "AGED CARE HOME\\nElizabeth Jenkins Place Aged Care Centre\\nCollaroy, NSW 2097",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/elizabeth-jenkins-place-aged-care-centre"
    },
    {
        "name": "Anglicare Marcus Loane House",
        "location": "AGED CARE HOME\\nAnglicare Marcus Loane House\\nWarriewood, NSW 2102",
        "provider": "Anglicare",
        "url": "https://www.agedcareguide.com.au/anglicare-marcus-loane-house"
    },
    {
        "name": "Woodport Aged Care Centre",
        "location": " SUPPORT AT HOME PROGRAM\\nWoodport Aged Care Centre\\nErina, NSW 2250",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/woodport-aged-care-centre"
    },
    {
        "name": "Macquarie Lodge Aged Care Centre",
        "location": " IN HOME CARE\\nMacquarie Lodge Aged Care Centre\\nArncliffe, NSW 2205",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/macquarie-lodge-aged-care-centre"
    },
    {
        "name": "Narraweena Grove Care Community",
        "location": "AGED CARE HOME\\nNarraweena Grove Care Community\\nNarraweena, NSW 2099",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/narraweena-grove-care-community"
    },
    {
        "name": "Pacific Lodge Aged Care Centre",
        "location": "AGED CARE HOME\\nPacific Lodge Aged Care Centre\\nCollaroy, NSW 2097",
        "provider": "The Salvation Army Aged Care",
        "url": "https://www.agedcareguide.com.au/pacific-lodge-aged-care-centre"
    },
    {
        "name": "Manly Vale Aged Care",
        "location": "AGED CARE HOME\\nManly Vale Aged Care\\nManly Vale, NSW 2093",
        "provider": "Hardi Aged Care",
        "url": "https://www.agedcareguide.com.au/manly-vale-aged-care"
    },
    {
        "name": "Uniting Wesley Heights Manly",
        "location": "AGED CARE HOME\\nUniting Wesley Heights Manly\\nManly, NSW 2095",
        "provider": "Uniting Residential Care",
        "url": "https://www.agedcareguide.com.au/uniting-wesley-heights-manly"
    },
    {
        "name": "Manly Hillside Care Community",
        "location": "AGED CARE HOME\\nManly Hillside Care Community\\nNorth Manly, NSW 2100",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/manly-hillside-care-community"
    },
    {
        "name": "Narrabeen Glades Care Community",
        "location": "AGED CARE HOME\\nNarrabeen Glades Care Community\\nWarriewood, NSW 2102",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/narrabeen-glades-care-community"
    },
    {
        "name": "Mona Vale View Care Community",
        "location": "AGED CARE HOME\\nMona Vale View Care Community\\nMona Vale, NSW 2103",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/mona-vale-view-care-community"
    },
    {
        "name": "Uniting Wesley Gardens Belrose",
        "location": "AGED CARE HOME\\nUniting Wesley Gardens Belrose\\nBelrose, NSW 2085",
        "provider": "Uniting Residential Care",
        "url": "https://www.agedcareguide.com.au/uniting-wesley-gardens-belrose"
    },
    {
        "name": "Calvary Corymbia",
        "location": "AGED CARE HOME\\nCalvary Corymbia\\nBelrose, NSW 2085",
        "provider": "Calvary",
        "url": "https://www.agedcareguide.com.au/calvary-corymbia"
    },
    {
        "name": "Bupa Seaforth",
        "location": "AGED CARE HOME\\nBupa Seaforth\\nSeaforth, NSW 2092",
        "provider": "Bupa Aged Care",
        "url": "https://www.agedcareguide.com.au/bupa-seaforth"
    },
    {
        "name": "Bayview Treetops Care Community",
        "location": "AGED CARE HOME\\nBayview Treetops Care Community\\nBayview, NSW 2104",
        "provider": "Opal HealthCare",
        "url": "https://www.agedcareguide.com.au/bayview-treetops-care-community"
    }
]

def extract_suburb_postcode(location):
    lines = location.split('\\n')
    for line in lines:
        match = re.search(r'([A-Za-z\s]+),\s*NSW\s+(\d{4})', line)
        if match:
            suburb = match.group(1).strip()
            postcode = match.group(2).strip()
            return suburb, postcode
    return None, None

# Fetch existing pages to avoid duplicates
print("Fetching existing pages...")
resp = requests.post(f"https://api.notion.com/v1/data_sources/{data_source_id}/query",
                     headers=headers, json={"page_size": 100})
if resp.status_code != 200:
    print(f"Error fetching pages: {resp.text}")
    exit(1)

existing_names = set()
for page in resp.json().get('results', []):
    props = page.get('properties', {})
    name_obj = props.get('Name', {}).get('title', [])
    if name_obj:
        existing_names.add(name_obj[0].get('text', {}).get('content', '').strip())

print(f"Existing entries: {len(existing_names)}")

added = 0
for item in extracted:
    suburb, postcode = extract_suburb_postcode(item['location'])
    if not suburb or not postcode:
        continue
    # Filter only Northern Beaches suburbs (postcode range 2084-2109)
    if not (2084 <= int(postcode) <= 2109):
        continue
    if item['name'] in existing_names:
        print(f"Skipping duplicate: {item['name']}")
        continue
    
    payload = {
        "parent": {"database_id": "6088ea51-fa49-4102-a6fb-250eccc9f1ad"},
        "properties": {
            "Name": {
                "title": [{"type": "text", "text": {"content": item['name']}}]
            },
            "Address": {
                "rich_text": [{"type": "text", "text": {"content": f"{suburb}, NSW {postcode}"}}]
            },
            "Website": {
                "url": item['url']
            },
            "Service Type": {
                "select": {"name": "Nursing Home"}
            },
            "Status": {
                "select": {"name": "Not Contacted"}
            },
            "Suburb": {
                "rich_text": [{"type": "text", "text": {"content": suburb}}]
            },
            "Postcode": {
                "rich_text": [{"type": "text", "text": {"content": postcode}}]
            },
            "Notes": {
                "rich_text": [{"type": "text", "text": {"content": f"Provider: {item['provider']}. Source: agedcareguide.com.au"}}]
            }
        }
    }
    
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=payload)
    if resp.status_code == 200:
        added += 1
        print(f"Added: {item['name']}")
    else:
        print(f"Failed to add {item['name']}: {resp.status_code} {resp.text[:200]}")

print(f"\nTotal added: {added}")