#!/usr/bin/env python3
import os
import requests
import json

NOTION_KEY = open("/home/agent/.config/notion/api_key").read().strip()
DATASOURCE_ID = "eec8bbe9-0cbe-4abe-8b82-04124bebe030"
HEADERS = {
    "Authorization": f"Bearer {NOTION_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json"
}

def get_data_source():
    url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}"
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        print(f"Failed to get data source: {response.status_code} {response.text}")
        return None
    return response.json()

def update_data_source(new_properties):
    url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}"
    payload = {"properties": new_properties}
    response = requests.patch(url, headers=HEADERS, json=payload)
    if response.status_code == 200:
        print("Data source updated successfully")
        return response.json()
    else:
        print(f"Update failed: {response.status_code} {response.text}")
        return None

def main():
    data = get_data_source()
    if not data:
        return
    props = data["properties"]
    # Get current Relationship select options
    rel_prop = props["Relationship"]
    print("Current Relationship property:", json.dumps(rel_prop, indent=2))
    options = rel_prop["select"]["options"]
    # Check if Sister-in-Law and Brother-in-Law already exist
    sister_exists = any(opt["name"] == "Sister-in-Law" for opt in options)
    brother_exists = any(opt["name"] == "Brother-in-Law" for opt in options)
    if sister_exists and brother_exists:
        print("Options already exist.")
    else:
        # Add new options
        new_options = options.copy()
        if not sister_exists:
            new_options.append({"name": "Sister-in-Law", "color": "brown"})
        if not brother_exists:
            new_options.append({"name": "Brother-in-Law", "color": "brown"})
        # Update the property
        new_props = {"Relationship": {"select": {"options": new_options}}}
        update_data_source(new_props)
    # Now update the pages
    query_url = f"https://api.notion.com/v1/data_sources/{DATASOURCE_ID}/query"
    response = requests.post(query_url, headers=HEADERS, json={})
    if response.status_code != 200:
        print(f"Query failed: {response.status_code} {response.text}")
        return
    pages = response.json().get("results", [])
    for page in pages:
        props = page.get("properties", {})
        name_obj = props.get("Name", {}).get("title", [])
        if not name_obj:
            continue
        name = name_obj[0].get("plain_text", "")
        page_id = page["id"]
        if "Rafaela" in name:
            update_url = f"https://api.notion.com/v1/pages/{page_id}"
            payload = {"properties": {"Relationship": {"select": {"name": "Sister-in-Law"}}}}
            resp = requests.patch(update_url, headers=HEADERS, json=payload)
            if resp.status_code == 200:
                print(f"Updated Rafaela to Sister-in-Law")
            else:
                print(f"Failed: {resp.status_code} {resp.text}")
        elif "Brent" in name:
            update_url = f"https://api.notion.com/v1/pages/{page_id}"
            payload = {"properties": {"Relationship": {"select": {"name": "Brother-in-Law"}}}}
            resp = requests.patch(update_url, headers=HEADERS, json=payload)
            if resp.status_code == 200:
                print(f"Updated Brent to Brother-in-Law")
            else:
                print(f"Failed: {resp.status_code} {resp.text}")

if __name__ == "__main__":
    main()