#!/usr/bin/env python3
import requests
import os
api_key = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
headers = {
    "Authorization": f"Bearer {api_key}",
    "Notion-Version": "2025-09-03",
}
database_id = "37691f15-655f-4a54-a3eb-915692442433"
url = f"https://api.notion.com/v1/databases/{database_id}"
resp = requests.get(url, headers=headers)
print(f"Status: {resp.status_code}")
if resp.status_code != 200:
    print(resp.text)
else:
    import json
    db = resp.json()
    print(f"Title: {db.get('title', [{}])[0].get('text', {}).get('content')}")
    print(f"Parent: {db.get('parent')}")