# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Bayani
- **What to call them:** Bayani
- **Pronouns:** he/him
- **Timezone:** Australia/Sydney
- **Communication style:** not yet set
- **Preferred contact hours:** not yet set
- **Urgency threshold:** not yet set
- **Sleep Window:** 23:00-07:00 local time (12:00-20:00 UTC)
- **Notes:** 

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
---

_This file is yours to evolve. As you learn about me, update it._