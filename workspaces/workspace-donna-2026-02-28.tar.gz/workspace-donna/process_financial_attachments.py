#!/usr/bin/env python3
"""
Process financial email attachments and upload to Nextcloud.

This script:
1. Searches for emails with financial labels (Finance/Invoices, Finance/Receipts, Finance/Statements)
2. Downloads attachments using gog CLI
3. Uploads to Nextcloud via WebDAV
4. Adds 'Archived-to-Nextcloud' label to processed emails

Requires:
- gog CLI with Gmail access
- Nextcloud WebDAV credentials (from Aria workspace)
- curl for WebDAV uploads
"""

import os
import sys
import json
import subprocess
import tempfile
import re
from datetime import datetime
from pathlib import Path

# Configuration
WORKSPACE = "/home/agent/.openclaw/workspace-donna"
STATE_FILE = os.path.join(WORKSPACE, "memory/gmail_nextcloud_state.json")
LOG_FILE = os.path.join(WORKSPACE, "memory/gmail_nextcloud.log")
ACCOUNT = "bayanimills@gmail.com"

# Nextcloud WebDAV configuration (from Aria's monitor-nextcloud-folders.py)
NEXTCLOUD_BASE_URL = "https://nextcloud.blkstr.io/remote.php/dav/files/aria"
NEXTCLOUD_USER = "aria"
NEXTCLOUD_PASS = "agent12345aria"

# Nextcloud folder mappings
# Maps Gmail labels to Nextcloud folder paths
LABEL_TO_NEXTCLOUD = {
    # New Finance hierarchy (business)
    "Finance/Invoices/Business": "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Invoices/",
    "Finance/Receipts/Business": "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Receipts/",
    "Finance/Statements/Business": "/_private/businesses/Finmills%20Pty%20Ltd/Accounting/Statements/",
    # New Finance hierarchy (personal)
    "Finance/Invoices/Personal": "/_private/personal/Finances/Invoices/",
    "Finance/Receipts/Personal": "/_private/personal/Finances/Receipts/",
    "Finance/Statements/Personal": "/_private/personal/Finances/Statements/",
    # Legacy receipt labels (to be migrated)
    "Receipt": "/_private/personal/Finances/Receipts/",
    "Consumer/Food Receipts": "/_private/personal/Finances/Receipts/Food/",
    "Crypto/Crypto Receipts": "/_private/personal/Finances/Receipts/Crypto/",
}

# Financial labels to process (should match label_rules.json)
FINANCIAL_LABELS = list(LABEL_TO_NEXTCLOUD.keys())

# Label to add after successful processing
PROCESSED_LABEL = "Archived-to-Nextcloud"

def run_cmd(cmd, timeout=60, cwd=None):
    """Run shell command and return stdout, stderr, returncode."""
    try:
        result = subprocess.run(
            cmd,
            shell=True if isinstance(cmd, str) else False,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124
    except Exception as e:
        return "", str(e), 1

def log_message(message, level="INFO"):
    """Log message to log file and print to stdout."""
    timestamp = datetime.now().isoformat()
    log_entry = f"{timestamp} [{level}] {message}"

    # Print to stdout
    print(f"[{level}] {message}")

    # Append to log file
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(log_entry + "\n")

def load_state():
    """Load processing state from JSON file."""
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            return {"processed_threads": {}, "last_run": None}
    return {"processed_threads": {}, "last_run": None}

def save_state(state):
    """Save processing state to JSON file."""
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def get_emails_with_label(label, max_results=50):
    """Get emails with specific label using gog CLI."""
    # gog gmail search "label:Finance/Invoices/Business" --max 50 --json --account
    cmd = ["gog", "gmail", "search", f"label:{label}", "--max", str(max_results), "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)

    if rc != 0:
        log_message(f"Failed to search for label {label}: {stderr}", "ERROR")
        return []

    try:
        data = json.loads(stdout)
        threads = data.get("threads")
        if threads is None:
            return []
        return threads
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse gog output for {label}: {e}", "ERROR")
        return []

def get_message_details(message_id):
    """Get full message details including attachments."""
    cmd = ["gog", "gmail", "message", message_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)

    if rc != 0:
        log_message(f"Failed to get message {message_id}: {stderr}", "ERROR")
        return None

    try:
        return json.loads(stdout)
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse message details for {message_id}: {e}", "ERROR")
        return None

def download_attachment(message_id, attachment_id, filename):
    """Download attachment using gog CLI."""
    # gog gmail attachment <messageId> <attachmentId>
    cmd = ["gog", "gmail", "attachment", message_id, attachment_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=120)

    if rc != 0:
        log_message(f"Failed to download attachment {attachment_id} from {message_id}: {stderr}", "ERROR")
        return None

    # Save to temporary file
    temp_dir = tempfile.gettempdir()
    filepath = os.path.join(temp_dir, filename)

    try:
        with open(filepath, "wb") as f:
            f.write(stdout.encode('utf-8') if isinstance(stdout, str) else stdout)
        log_message(f"Downloaded attachment to {filepath} ({os.path.getsize(filepath)} bytes)")
        return filepath
    except Exception as e:
        log_message(f"Failed to save attachment {filename}: {e}", "ERROR")
        return None

def ensure_nextcloud_directory(folder_path):
    """Ensure Nextcloud directory exists via WebDAV MKCOL."""
    # Remove trailing slash for MKCOL? Keep slash.
    url = f"{NEXTCLOUD_BASE_URL}{folder_path}"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-X", "MKCOL",
        url
    ]
    stdout, stderr, rc = run_cmd(cmd, timeout=30)
    if rc == 0:
        log_message(f"Created directory: {folder_path}")
        return True
    elif "405" in stderr:  # Method Not Allowed - directory already exists
        log_message(f"Directory already exists: {folder_path}")
        return True
    else:
        log_message(f"Failed to create directory {folder_path}: {stderr}", "WARNING")
        return False

def upload_to_nextcloud(filepath, nextcloud_folder, filename):
    """Upload file to Nextcloud via WebDAV using curl."""
    # URL encode the filename
    import urllib.parse
    encoded_filename = urllib.parse.quote(filename)

    # Full destination URL
    dest_url = f"{NEXTCLOUD_BASE_URL}{nextcloud_folder}{encoded_filename}"

    # curl -u user:pass -T localfile "https://nextcloud/remote.php/dav/files/aria/path/to/file"
    cmd = [
        "curl", "-s", "-u", f"{NEXTCLOUD_USER}:{NEXTCLOUD_PASS}",
        "-T", filepath,
        dest_url
    ]

    stdout, stderr, rc = run_cmd(cmd, timeout=60)

    if rc != 0:
        log_message(f"Failed to upload {filename} to {dest_url}: {stderr}", "ERROR")
        return False

    log_message(f"Successfully uploaded {filename} to {nextcloud_folder}")
    return True

def add_label_to_thread(thread_id, label):
    """Add label to thread using gog CLI."""
    cmd = ["gog", "gmail", "labels", "modify", "--add", label, thread_id, "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)

    if rc != 0:
        log_message(f"Failed to add label {label} to thread {thread_id}: {stderr}", "ERROR")
        return False

    log_message(f"Added label {label} to thread {thread_id}")
    return True

def process_email_thread(thread, label, state):
    """Process a single email thread (check for attachments, upload, label)."""
    thread_id = thread.get("id")

    # Skip if already processed
    if thread_id in state.get("processed_threads", {}):
        log_message(f"Thread {thread_id} already processed, skipping")
        return 0, 0

    # Get message details (get first message in thread)
    messages = thread.get("messages", [])
    if not messages:
        # Fetch thread details
        thread_details = get_thread_details(thread_id)
        if not thread_details:
            log_message(f"Failed to fetch thread details for {thread_id}", "WARNING")
            return 0, 0
        messages = thread_details.get("messages", [])
    if not messages:
        log_message(f"No messages found in thread {thread_id}", "WARNING")
        return 0, 0
    message_id = messages[0].get("id")
    if not message_id:
        log_message(f"No message ID found for thread {thread_id}", "WARNING")
        return 0, 0

    message = get_message_details(message_id)
    if not message:
        return 0, 0

    # Check for attachments
    attachments = message.get("attachments", [])
    if not attachments:
        log_message(f"No attachments in thread {thread_id}, skipping")
        # Mark as processed anyway to avoid rechecking
        state["processed_threads"][thread_id] = {
            "processed_at": datetime.now().isoformat(),
            "label": label,
            "attachments_count": 0
        }
        return 0, 0

    log_message(f"Found {len(attachments)} attachments in thread {thread_id}")

    # Get Nextcloud folder for this label
    nextcloud_folder = LABEL_TO_NEXTCLOUD.get(label)
    if not nextcloud_folder:
        log_message(f"No Nextcloud folder mapping for label {label}", "ERROR")
        return 0, 0

    # Process each attachment
    successful_uploads = 0
    for i, att in enumerate(attachments):
        att_id = att.get("id")
        att_name = att.get("filename", f"attachment_{i}.bin")
        att_size = att.get("size", 0)

        log_message(f"Processing attachment {i+1}/{len(attachments)}: {att_name} ({att_size} bytes)")

        # Download attachment
        temp_file = download_attachment(message_id, att_id, att_name)
        if not temp_file:
            continue

        # Upload to Nextcloud
        if upload_to_nextcloud(temp_file, nextcloud_folder, att_name):
            successful_uploads += 1

        # Clean up temp file
        try:
            os.remove(temp_file)
        except OSError:
            pass

    # If any uploads succeeded, add processed label
    if successful_uploads > 0:
        if add_label_to_thread(thread_id, PROCESSED_LABEL):
            state["processed_threads"][thread_id] = {
                "processed_at": datetime.now().isoformat(),
                "label": label,
                "attachments_count": successful_uploads,
                "nextcloud_folder": nextcloud_folder
            }

    return len(attachments), successful_uploads

def get_thread_details(thread_id):
    """Get thread details including messages using gog CLI."""
    cmd = ["gog", "gmail", "thread", thread_id, "--json", "--account", ACCOUNT]
    stdout, stderr, rc = run_cmd(cmd, timeout=60)
    if rc != 0:
        log_message(f"Failed to get thread {thread_id}: {stderr}", "ERROR")
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as e:
        log_message(f"Failed to parse thread details for {thread_id}: {e}", "ERROR")
        return None

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Process financial email attachments to Nextcloud")
    parser.add_argument("--dry-run", action="store_true", help="Scan and detect but don't download/upload")
    parser.add_argument("--label", help="Process specific label only")
    parser.add_argument("--max-per-label", type=int, default=20, help="Max emails per label to process")
    args = parser.parse_args()

    log_message(f"Starting financial attachment processing (dry-run={args.dry_run})")

    # Load state
    state = load_state()

    # Determine which labels to process
    labels_to_process = [args.label] if args.label else FINANCIAL_LABELS

    total_threads = 0
    total_attachments = 0
    total_uploads = 0

    for label in labels_to_process:
        log_message(f"Processing label: {label}")

        # Check if label exists in Nextcloud mapping
        if label not in LABEL_TO_NEXTCLOUD:
            log_message(f"Label {label} not configured for Nextcloud upload, skipping", "WARNING")
            continue

        # Get emails with this label
        threads = get_emails_with_label(label, args.max_per_label)
        log_message(f"Found {len(threads)} threads with label {label}")

        if args.dry_run:
            for thread in threads:
                thread_id = thread.get("id")
                message_count = len(thread.get("messages", []))
                log_message(f"  DRY RUN: Would process thread {thread_id} ({message_count} messages)")
                total_threads += 1
            continue

        # Process each thread
        for thread in threads:
            attachments_found, uploads_successful = process_email_thread(thread, label, state)
            total_threads += 1
            total_attachments += attachments_found
            total_uploads += uploads_successful

    # Update state
    state["last_run"] = datetime.now().isoformat()
    if not args.dry_run:
        save_state(state)

    # Summary
    log_message(f"Processing complete: {total_threads} threads, {total_attachments} attachments, {total_uploads} successful uploads")

    if args.dry_run:
        log_message("DRY RUN: No actual downloads/uploads performed")

if __name__ == "__main__":
    main()