#!/usr/bin/env python3
"""
Archive promotional emails with 3-day delay for top eight domains.
Domains with delay: e.kogan.com, cluborange.org, email.livenation.com.au,
edm2.umart.com.au, buckettys.com.au, coinspot.com.au, au.enews.bp.email, thinlizzy.com.au
All other promotional emails are archived immediately.
"""
import subprocess
import sys
import json
import datetime
import re
import argparse
from pathlib import Path

ACCOUNT = "bayanimills@gmail.com"
GOG = "/home/agent/.linuxbrew/bin/gog"
DELAY_DAYS = 3
DELAY_SECONDS = DELAY_DAYS * 24 * 60 * 60

# Top eight domains from analysis (Feb 27 2026)
DELAY_DOMAINS = {
    'e.kogan.com',
    'cluborange.org',
    'email.livenation.com.au',
    'edm2.umart.com.au',
    'buckettys.com.au',
    'coinspot.com.au',
    'au.enews.bp.email',
    'thinlizzy.com.au',
}

def run_gog(args):
    cmd = [GOG] + args + ["--account", ACCOUNT]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode == 0:
            return True, result.stdout.strip()
        else:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"Timeout: {' '.join(cmd)}", file=sys.stderr)
        return False, "timeout"

def extract_domain(sender):
    """Extract domain from From field, e.g., 'Kogan <email@e.kogan.com>' -> 'e.kogan.com'"""
    # Look for email pattern
    match = re.search(r'@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', sender)
    if match:
        return match.group(1).lower()
    # Fallback: take everything after @ if present
    if '@' in sender:
        return sender.split('@')[-1].strip('>').lower()
    return ''

def parse_date(date_str):
    """Parse DATE column (e.g., '2026-02-21 17:54') to datetime."""
    try:
        return datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M")
    except ValueError:
        # If parsing fails, assume now (conservative)
        return datetime.datetime.now()

def main():
    parser = argparse.ArgumentParser(description='Archive promotional emails with 3-day delay for top domains.')
    parser.add_argument('--dry-run', action='store_true', help='Dry run, do not archive')
    parser.add_argument('--max', type=int, default=500, help='Maximum threads to fetch')
    args = parser.parse_args()
    
    print(f"Promotional archiving with {DELAY_DAYS}-day delay for top domains — {datetime.datetime.now().isoformat()}")
    if args.dry_run:
        print("DRY RUN - no changes will be made")
    
    # Fetch all promotional threads in inbox
    success, output = run_gog(["gmail", "search", "in:inbox category:promotions", "--max", str(args.max), "--json"])
    if not success:
        print("Failed to fetch promotional threads.")
        return
    
    data = json.loads(output)
    threads = data.get("threads", [])
    print(f"Found {len(threads)} promotional threads in inbox.")
    sys.stdout.flush()
    
    # Separate into immediate archive vs delayed
    immediate_ids = []
    delayed_ids = []
    stats = {
        'total': len(threads),
        'immediate': 0,
        'delayed_domain': 0,
        'delayed_recent': 0,
        'delayed_archive': 0,
        'errors': 0,
    }
    
    now = datetime.datetime.now()
    for thread in threads:
        thread_id = thread["id"]
        sender = thread.get("from", "")
        date_str = thread.get("date", "")
        domain = extract_domain(sender)
        
        if domain in DELAY_DOMAINS:
            stats['delayed_domain'] += 1
            # Check date
            received = parse_date(date_str)
            age = now - received
            if age.total_seconds() >= DELAY_SECONDS:
                # Old enough, archive
                delayed_ids.append(thread_id)
                stats['delayed_archive'] += 1
            else:
                # Too recent, keep in inbox
                stats['delayed_recent'] += 1
                # Optionally log
                print(f"  Keeping recent ({age.days}d{age.seconds//3600}h) from {domain}: {thread.get('subject','')[:50]}")
                sys.stdout.flush()
        else:
            # Archive immediately
            immediate_ids.append(thread_id)
            stats['immediate'] += 1
    
    print(f"Stats: {stats['immediate']} immediate, {stats['delayed_archive']} delayed (old), {stats['delayed_recent']} delayed (recent)")
    sys.stdout.flush()
    
    if args.dry_run:
        print(f"Dry run: would archive {len(immediate_ids)} immediate, {len(delayed_ids)} delayed threads.")
        # Show some examples
        for i, thread in enumerate(threads[:5]):
            domain = extract_domain(thread.get('from',''))
            print(f"  {thread['id']}: {domain} - {thread.get('subject','')[:60]}")
        return
    
    # Archive immediate batch
    if immediate_ids:
        print(f"Archiving {len(immediate_ids)} immediate threads...")
        batch_size = 5
        for i in range(0, len(immediate_ids), batch_size):
            batch = immediate_ids[i:i+batch_size]
            gog_args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
            success, _ = run_gog(gog_args)
            if not success:
                stats['errors'] += 1
                print(f"Error archiving batch {i//batch_size + 1}")
    
    # Archive delayed batch (old enough)
    if delayed_ids:
        print(f"Archiving {len(delayed_ids)} delayed threads (older than {DELAY_DAYS} days)...")
        batch_size = 5
        for i in range(0, len(delayed_ids), batch_size):
            batch = delayed_ids[i:i+batch_size]
            gog_args = ["gmail", "labels", "modify"] + batch + ["--remove", "INBOX"]
            success, _ = run_gog(gog_args)
            if not success:
                stats['errors'] += 1
                print(f"Error archiving delayed batch {i//batch_size + 1}")
    
    # Final check
    success, output = run_gog(["gmail", "search", "in:inbox category:promotions", "--max", "10", "--json"])
    if success:
        data = json.loads(output)
        remaining = len(data.get("threads", []))
        print(f"Remaining promotional threads in inbox: {remaining}")
    else:
        print("Could not verify remaining threads.")
    
    print("Done.")

if __name__ == "__main__":
    main()