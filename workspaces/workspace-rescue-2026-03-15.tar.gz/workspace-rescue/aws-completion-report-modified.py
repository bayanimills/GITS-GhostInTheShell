#!/usr/bin/env python3
"""Generate and send 24-hour AWS completion reports (daily style).

Originally reviewed 12-hour windows, updated to 24-hour daily check (2026-03-05).
Rationale: AWS completion reports are now scheduled once daily (7pm Sydney time)
to avoid resource contention with other agent reports that run in morning staggered schedule.
All agent reports (aria, doc, donna, shelley, main, rescue) previously ran 7:00-7:35am
causing simultaneous resource requests. Moving Kaira's report to evening distributes load.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import subprocess, sys, os
from pathlib import Path


WORKSPACE = Path(__import__("os").environ.get("OPENCLAW_WORKSPACE", str(Path.home() / ".openclaw/workspace")))
QUEUE_FILE = WORKSPACE / "aws-task-queue.md"
LOG_FILE = WORKSPACE / "logs/autonomous-check.log"
CFG_FILE = WORKSPACE / "aws-telegram-status.json"

TIME_RE = re.compile(r"\*\*Completed\*\*:\s*(.+)")
TITLE_RE = re.compile(r"^###\s+(.+)$")


def parse_completed_within(hours: int = 24):
    """Parse tasks completed within the last N hours (default 24 for daily report).
    
    Changed from 12 to 24 hours on 2026-03-05 when report schedule moved from
    twice-daily (7am/7pm) to once-daily (7pm only) to avoid morning resource contention.
    """
    if not QUEUE_FILE.exists():
        return []

    now = dt.datetime.now()
    window_start = now - dt.timedelta(hours=hours)

    completed = []
    current_title = None
    for raw in QUEUE_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        t = raw.strip()
        m_title = TITLE_RE.match(t)
        if m_title:
            current_title = m_title.group(1)
            continue

        m_comp = TIME_RE.search(t)
        if m_comp and current_title:
            val = m_comp.group(1).strip()
            if not val:
                continue
            try:
                # Handle possible timezone abbreviation like "AEDT"
                parts = val.split()
                if len(parts) >= 2:
                    dt_str = ' '.join(parts[:2])
                    when = dt.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
                else:
                    when = dt.datetime.strptime(val, "%Y-%m-%d %H:%M")
            except ValueError:
                continue
            if window_start <= when <= now:
                completed.append((current_title, when))

    completed.sort(key=lambda x: x[1])
    return completed


def parse_failures_within(hours: int = 24):
    """Parse failures within the last N hours (default 24 for daily report).
    
    Changed from 12 to 24 hours on 2026-03-05 when report schedule moved from
    twice-daily (7am/7pm) to once-daily (7pm only) to avoid morning resource contention.
    """
    if not LOG_FILE.exists():
        return []
    now = dt.datetime.now()
    window_start = now - dt.timedelta(hours=hours)
    out = []
    for line in LOG_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()[-500:]:
        # log format starts with YYYY-MM-DD HH:MM:SS,mmm
        if len(line) < 19:
            continue
        ts_raw = line[:19]
        try:
            ts = dt.datetime.strptime(ts_raw, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        if ts < window_start:
            continue
        if "ERROR" in line or "failed" in line.lower() or "no-task-handler" in line.lower():
            out.append((ts, line.strip()))
    return out


def load_chat_target():
    if not CFG_FILE.exists():
        return None
    try:
        cfg = json.loads(CFG_FILE.read_text(encoding="utf-8"))
        return cfg.get("chat_id")
    except Exception:
        return None


def send_report(message: str, target: str):
    cmd = [
        "/home/agent/.local/bin/openclaw",
        "message",
        "send",
        "--channel",
        "telegram",
        "--target",
        str(target),
        "--message",
        message,
    ]
    return subprocess.run(cmd, capture_output=True, text=True, timeout=30)


def build_report():
    """Build the 24-hour AWS completion report.
    
    Uses 24-hour windows (changed from 12-hour) as reports are now daily
    and scheduled at 7pm Sydney time to avoid morning resource contention.
    """
    completed = parse_completed_within(24)
    failures = parse_failures_within(24)
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = [f"📋 AWS 24h Completion Report ({now})"]
    if completed:
        lines.append("\nCompleted tasks (last 24h):")
        for title, when in completed:
            lines.append(f"✅ {when.strftime('%H:%M')} — {title}")
    else:
        lines.append("\nNo AWS tasks completed in the last 24 hours.")

    if failures:
        lines.append("\nIssues observed (last 24h):")
        for ts, l in failures[:4]:
            short = l.split(" - ")[-1]
            lines.append(f"⚠️ {ts.strftime('%H:%M')} — {short[:140]}")
        status = "YELLOW"
    else:
        lines.append("\nNo failures/stoppages detected in the last 24 hours.")
        status = "GREEN"

    lines.append(f"\nStatus: {status}")
    return "\n".join(lines)


def main():
    msg = build_report()
    target = load_chat_target()
    
    if target:
        # Try to send via Telegram
        res = send_report(msg, target)
        if res.returncode == 0:
            # Success: only log a brief confirmation, do not print full report
            now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[{now}] AWS 24h report sent via Telegram")
            return 0
        else:
            # Telegram send failed; fallback to cron delivery by printing report
            print(f"Warning: Failed to send report: {res.stderr.strip()}")
            print(msg)
            return 1
    else:
        # No Telegram target configured; rely on cron delivery
        print(msg)
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
