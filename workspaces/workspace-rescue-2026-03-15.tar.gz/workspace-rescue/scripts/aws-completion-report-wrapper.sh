#!/bin/bash
# Wrapper for AWS completion report that ensures openclaw is in PATH
export PATH="/home/agent/.local/bin:$PATH"
export OPENCLAW_WORKSPACE="/home/agent/.openclaw/workspace-rescue"
cd "$OPENCLAW_WORKSPACE"
python3 /home/agent/.openclaw/workspace-rescue/aws-completion-report-modified.py