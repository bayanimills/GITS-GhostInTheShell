#!/usr/bin/env python3
"""
Sync Dart tasks to Notion Patient Tasks database.
"""
import os
import sys
import requests
import json
import time
from datetime import datetime, timezone

# Load .env file for DART_API_TOKEN
env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, val = line.split("=", 1)
                os.environ[key] = val
else:
    print(f"Warning: .env file not found at {env_path}")

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))
from scripts.dart_client import DartClient

# Notion API
NOTION_API_KEY = open(os.path.expanduser("~/.config/notion/api_key")).read().strip()
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

# Database IDs (from created database)
DATABASE_ID = "37691f15-655f-4a54-a3eb-915692442433"
DATA_SOURCE_ID = "f38f43f7-b2c8-4477-ae3d-7d17fa724891"

# Stroke task ID (parent)
STROKE_TASK_ID = "YhH8uggrObRf"

# Status mapping from Dart to Notion (Dart status values are exactly "To-do", "Doing", "Done")
STATUS_MAP = {
    "To-do": "To-do",
    "Doing": "Doing",
    "Done": "Done",
}

def query_notion_database(filter_dict=None):
    """Query Notion database using data_source_id."""
    url = f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query"
    payload = {}
    if filter_dict:
        payload["filter"] = filter_dict
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    data = resp.json()
    return data.get("results", [])

def create_page_in_database(properties):
    """Create a new page in the database."""
    url = "https://api.notion.com/v1/pages"
    payload = {
        "parent": {"database_id": DATABASE_ID},
        "properties": properties,
    }
    resp = requests.post(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    return resp.json()

def update_page(page_id, properties):
    """Update existing page."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    resp = requests.patch(url, headers=NOTION_HEADERS, json=payload, timeout=(10, 30))
    resp.raise_for_status()
    return resp.json()

def dart_task_to_notion_properties(task):
    """Convert Dart task object to Notion properties."""
    # Title
    title = task.get("title", "Untitled")
    # Status
    dart_status = task.get("status", "To-do")
    notion_status = STATUS_MAP.get(dart_status, "To-do")
    # Due date (field is dueAt)
    due_date = task.get("dueAt")
    # Tags
    tags = task.get("tags", [])
    # Dart Task ID
    task_id = task.get("id")
    # Priority field (string)
    priority = task.get("priority")
    # Phase - try to infer from tags or default None
    phase = None
    for tag in tags:
        if tag.startswith("phase-"):
            phase = tag.replace("phase-", "").capitalize()
            break
    # Build properties
    props = {
        "Name": {
            "title": [
                {"text": {"content": title}}
            ]
        },
        "Status": {
            "select": {"name": notion_status}
        },
        "Dart Task ID": {
            "rich_text": [
                {"text": {"content": task_id}}
            ]
        },
        "Last Synced": {
            "date": {"start": datetime.now(timezone.utc).isoformat()}
        }
    }
    if due_date:
        # dueAt might be ISO string
        props["Due Date"] = {"date": {"start": due_date}}
    if tags:
        props["Tags"] = {
            "multi_select": [{"name": tag} for tag in tags]
        }
    if phase:
        props["Phase"] = {"select": {"name": phase}}
    if priority:
        # Map priority values to our select options (High, Medium, Low, Critical?)
        priority_map = {
            "Critical": "High",
            "High": "High",
            "Medium": "Medium",
            "Low": "Low"
        }
        mapped = priority_map.get(priority, priority)
        props["Priority"] = {"select": {"name": mapped}}
    return props

def sync_dart_tasks():
    """Main sync function."""
    client = DartClient()
    # Fetch Edward Mills tasks (filter by tag)
    response = client.list_tasks(limit=200)
    all_tasks = response.get("results", []) if isinstance(response, dict) else response
    print(f"Total tasks fetched from Dart: {len(all_tasks)}")
    # Include tasks tagged patient-edward-mills, subtasks of stroke task, or stroke-followup
    edward_tasks = []
    for t in all_tasks:
        tags = t.get("tags", [])
        parent = t.get("parentId")
        if "patient-edward-mills" in tags:
            edward_tasks.append(t)
        elif parent == STROKE_TASK_ID:
            edward_tasks.append(t)
        elif "stroke-followup" in tags:
            edward_tasks.append(t)
    print(f"Found {len(edward_tasks)} Edward Mills tasks in Dart.")
    # Optional limit for debugging
    import os
    limit = os.environ.get('SYNC_LIMIT')
    if limit:
        limit = int(limit)
        edward_tasks = edward_tasks[:limit]
        print(f"Limiting to {limit} tasks for debugging.")
    
    # For each task, sync
    for task in edward_tasks:
        try:
            task_id = task["id"]
            print(f"Syncing task: {task['title']} ({task_id})")
            # Check if already exists in Notion
            filter_prop = {
                "property": "Dart Task ID",
                "rich_text": {"contains": task_id}
            }
            existing = query_notion_database(filter_prop)
            properties = dart_task_to_notion_properties(task)
            if existing:
                # Update existing page
                page_id = existing[0]["id"]
                print(f"  Updating existing page {page_id}")
                update_page(page_id, properties)
            else:
                # Create new page
                print(f"  Creating new page")
                create_page_in_database(properties)
            print(f"  Done")
            time.sleep(0.5)  # Rate limit avoidance
        except Exception as e:
            print(f"  ERROR syncing task {task.get('id')}: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print("Sync completed.")

if __name__ == "__main__":
    try:
        sync_dart_tasks()
    except Exception as e:
        print(f"Error during sync: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)